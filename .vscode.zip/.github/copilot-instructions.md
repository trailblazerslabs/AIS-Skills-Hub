# Metcash AIS Skills Hub

Skills, custom agents, prompts, and MCP configurations for AI coding agents working on
Metcash Azure Integration Services (AIS) interfaces.

> **Selective context injection:** Load only the skills your current task needs.
> Loading all skills at once dilutes agent attention and wastes tokens.

---

## AIS Integration Skills

<skill>
<name>ais-interface-status</name>
<description>Metcash AIS interface status tracker — the standing "where did we leave off" record for a single interface, checked at the START of every SDLC skill and updated at the END of every one. USE FOR: resuming an interface across sessions without re-deriving its history from git log or chat scrollback; answering "what's the status of EAII-{n}"; recording which SDLC phase is done, what's still open, and what real evidence (Confluence attachments, ADO search results) was already fetched so it isn't re-fetched. Cross-cutting Ways of Working practice — every AIS SDLC skill reads outputs/{InterfaceID}/status.md first and writes to it last, not just this skill. Triggers: "what's the status of EAII", "where did we leave off", "resume this interface", "interface status".</description>
<file>.github/skills/ais-interface-status/SKILL.md</file>
</skill>

<skill>
<name>ais-design-intake</name>
<description>Metcash AIS design intake — the NO-TSD EXCEPTION path only, never the default for a new interface. USE FOR: reading FSD (mandatory) and inferring technical decisions ONLY when the user has explicitly confirmed no TSD will ever be produced for this interface. The default for every new interface is metcash-tsd-generator \u2192 ais-codegen-readiness \u2014 do not reach for this skill just because an FSD is available or generation would be faster. Produces a Design Intake Questionnaire and stops for explicit approval before any codegen skill runs \u2014 same propose/evidence/gap/stop pattern as ais-codegen-readiness, just for the no-TSD path. When a TSD already exists (or could be generated), use metcash-tsd-generator + ais-codegen-readiness instead \u2014 do not run both paths. Triggers: "no TSD and none will be generated", "skip TSD generation", "design intake" (only after explicit user confirmation that no TSD applies).</description>
<file>.github/skills/ais-design-intake/SKILL.md</file>
</skill>

<skill>
<name>ais-codegen-readiness</name>
<description>Metcash AIS codegen readiness gate. USE FOR: the step between an approved TSD and any code generation skill — resolves target repo, resource name(s), field-level mapping cross-check against the raw Mapping Manifest, and (for interfaces with a legacy TIBCO implementation) a cross-check against the actual TIBCO source. Runs the same propose/evidence/gap/stop pattern as metcash-tsd-generator's own intake-questionnaire. Mandatory prerequisite for the codegen skills whenever a TSD exists — replaces ais-design-intake for that path. Triggers: "ready to generate code", "codegen readiness", "resolve repo and resource name", "before generating code from TSD".</description>
<file>.github/skills/ais-codegen-readiness/SKILL.md</file>
</skill>

<skill>
<name>ais-documentation</name>
<description>Metcash AIS interface documentation generator. USE FOR: generating technical specifications, data flow docs, assumption logs, field mapping tables, and change summaries for Azure Integration interfaces. Triggers: "generate documentation", "create spec", "interface documentation", "technical specification", "document this interface", "write assumption log", "data flow diagram".</description>
<file>.github/skills/ais-documentation/SKILL.md</file>
</skill>

<skill>
<name>ais-logicapp-codegen</name>
<description>Metcash AIS Logic App Standard workflow code generator. USE FOR: generating Logic App workflow JSON, connection references, parameters, and app settings for AIS interfaces. Derives all naming from the reference workspace. Triggers: "generate logic app", "create workflow", "logic app code", "workflow json", "HTTP trigger workflow", "Service Bus workflow".</description>
<file>.github/skills/ais-logicapp-codegen/SKILL.md</file>
</skill>

<skill>
<name>ais-functionapp-codegen</name>
<description>Metcash AIS C# .NET 10 Function App transformation code generator. USE FOR: generating Service-Bus-triggered transformation functions following the real production 3-project split (host Function project + .Common project + Tests project). Reuses existing project and shared types. Triggers: "generate function app", "create function", "transformation code", "C# function", "sorting function", "data transformation".</description>
<file>.github/skills/ais-functionapp-codegen/SKILL.md</file>
</skill>

<skill>
<name>ais-datafactory-codegen</name>
<description>Metcash AIS Azure Data Factory pipeline code generator. USE FOR: generating ADF pipeline JSON, parameterized datasets, Managed Identity linked services, and triggers for bulk data movement and batch scenarios. Triggers: "generate ADF", "data factory pipeline", "ADF pipeline", "data integration pipeline", "bulk data movement".</description>
<file>.github/skills/ais-datafactory-codegen/SKILL.md</file>
</skill>

<skill>
<name>ais-unit-test-cases</name>
<description>Metcash AIS unit test case generator. USE FOR: preparing a pre-generation coverage intake questionnaire, then (only after approval) generating unit-test-cases.csv for Logic App, Function App, and ADF interfaces. A separate approved readiness questionnaire gates shared ADO Test Plan/Suite/Case creation. Triggers: "generate test cases", "unit test", "test scenarios", "test matrix", "unit-test-cases.csv".</description>
<file>.github/skills/ais-unit-test-cases/SKILL.md</file>
</skill>

<skill>
<name>ais-test-execution</name>
<description>Metcash AIS test execution skill. USE FOR: actually running the unit test cases against a deployed Logic App, Function App, ADF pipeline, or Service Bus-triggered interface in a non-prod environment (dev/sit/uat), firing the trigger via Azure CLI/HTTP and capturing the real outcome. Never run against PRD. Triggers: "run the unit tests", "execute test cases", "test this interface", "trigger a test run", "send a test message".</description>
<file>.github/skills/ais-test-execution/SKILL.md</file>
</skill>

<skill>
<name>ais-test-results-to-ado</name>
<description>Metcash AIS test results recorder. USE FOR: recording the executed outcomes from ais-test-execution as Test Results against the existing ADO Test Plan/Suite/Cases, completing the Test Run, and posting a pass/fail summary comment on the EAII work item. Never creates a duplicate Test Plan. Triggers: "record test results", "upload results to ado", "update ado test run", "mark test cases pass/fail", "close the test run".</description>
<file>.github/skills/ais-test-results-to-ado/SKILL.md</file>
</skill>

<skill>
<name>ais-code-review</name>
<description>Metcash AIS code reviewer. USE FOR: reviewing Logic App workflows, C# Function App code, and ADF pipelines against AIS standards, naming conventions, OWASP Top 10 security, and SMC observability requirements. Produces a structured findings report. Triggers: "code review", "review my workflow", "review my function", "validate my code", "check my logic app", "security review".</description>
<file>.github/skills/ais-code-review/SKILL.md</file>
</skill>

<skill>
<name>metcash-tsd-generator</name>
<description>Metcash AIS Technical Specification Document generator. USE FOR: producing a TSD from an approved FSD plus Mapping Manifest, using the seven approved production TSDs in reference-corpus/ as the design authority. Selects the correct AIS architecture archetype (APIM-only, APIM + Logic App, Function App event-driven, file/MFT batch), asks the user to confirm design decisions, then generates the full §1–§15 TSD with architecture, network, process flow and sequence diagrams. Triggers: "create a TSD", "generate a technical specification", "produce TSD from FSD", "write the technical design", "technical solution design".</description>
<file>.github/skills/metcash-tsd-generator/SKILL.md</file>
</skill>

<skill>
<name>confluence-publish-rich-content</name>
<description>Publish or update rich content (headings, tables, code blocks and embedded diagram images) on a Confluence Cloud page via browser automation when no working Confluence MCP/API write path is available. USE FOR: "publish this to Confluence", "update the Confluence page with the latest TSD/ADR/doc" for a markdown document that has tables, code blocks or images; covers updating an existing page and creating a page from a template via Make a copy. DO NOT USE FOR: plain-text-only edits.</description>
<file>.github/skills/confluence-publish-rich-content/SKILL.md</file>
</skill>

<skill>
<name>ais-deployment-runsheet</name>
<description>Metcash AIS Deployment Runsheet guide. USE FOR: creating, understanding, or updating a Confluence deployment runsheet for any AIS interface across any environment (ST1, UT1, SIT, PRD). Covers page structure, mandatory sections, login and access prerequisites, resource naming per environment, status macros, and end-to-end deployment checklist. Uses Atlassian MCP to create and update Confluence pages, and ADO MCP to verify pipeline readiness. Triggers: "deployment runsheet", "how to deploy", "runsheet", "deployment checklist", "how to run deployment", "what do I need to deploy", "create runsheet".</description>
<file>.github/skills/ais-deployment-runsheet/SKILL.md</file>
</skill>
<skill>
<name>ais-runsheet-review</name>
<description>Metcash AIS deployment-runsheet reviewer. USE FOR: critically reviewing an existing runsheet against its approved TSD, refreshed code/pipeline baseline, environment checklist and evidence; retrospective audits of approved examples. DO NOT USE FOR: generating or publishing runsheets, triggering pipelines, or authorizing deployment. Triggers: "review this runsheet", "review existing deployment runsheet", "runsheet quality review", "audit deployment checklist", "check runsheet against TSD and code".</description>
<file>.github/skills/ais-runsheet-review/SKILL.md</file>
</skill>

<skill>
<name>ais-debug-azure</name>
<description>Metcash AIS Azure resource debugger. USE FOR: investigating failures in Logic App workflows, Function Apps, Azure Data Factory pipelines, Service Bus queues, and APIM APIs. Covers log analysis, run history inspection, configuration validation, dead-letter investigation, APIM policy/backend tracing, and root cause identification — using Azure CLI plus cross-resource Application Insights KQL queries as the primary diagnostic tool. Always confirms the az login tenant and asks for resource type/environment/correlation ID before investigating; never guesses or defaults to PRD. Uses ADO MCP to read run histories, Azure SQL MCP for data validation, and Azure CLI/App Insights for diagnostics. Produces a structured diagnosis report with recommended fixes. Triggers: "debug", "investigate failure", "logic app failed", "function app error", "ADF pipeline failed", "service bus dead letter", "apim failing", "application insights", "kql", "why is it failing", "diagnose", "troubleshoot", "check logs", "production issue".</description>
<file>.github/skills/ais-debug-azure/SKILL.md</file>
</skill>

<skill>
<name>ais-smc-failure-retrieval</name>
<description>At the start of DEV unit-test execution, retrieve the SMC error baseline for one EAII interface after the ADO test suite is complete and before the first test trigger. Optionally filter and group by Observation ID. Uses the executing user's authenticated local Edge session; POSTs the filtered list and GETs each item by numeric Id. Does not copy cookies, diagnose Azure resources, or access other environments. Triggers: "retrieve SMC errors before unit tests", "get SMC baseline after ADO suite", "trace SMC by Observation ID".</description>
<file>.github/skills/ais-smc-failure-retrieval/SKILL.md</file>
</skill>

<skill>
<name>skill-creator</name>
<description>Guide for creating new skills for the Metcash AIS Skills Hub. USE FOR: creating a new SKILL.md, agent persona, or prompt template. Covers frontmatter structure, naming conventions, registration steps, and anti-patterns. Triggers: "create a skill", "add a new skill", "new skill template", "skill creator", "write a SKILL.md".</description>
<file>.github/skills/skill-creator/SKILL.md</file>
</skill>

<skill>
<name>mcp-usage-guide</name>
<description>Metcash AIS MCP usage guide. USE FOR: understanding which MCP server to activate for each engineering activity — reading FSD/TSD from Confluence (Atlassian MCP), reading TIBCO source from GitHub (GitHub MCP), managing ADO work items / repos / test plans / pipelines (ADO MCP), querying Azure SQL (Azure SQL MCP), looking up Azure documentation (Microsoft Docs MCP), and persisting session context (memory MCP). Load this skill before any task that reads from or writes to an external system. Triggers: "which MCP", "use MCP", "read FSD from confluence", "read TIBCO from GitHub", "create ADO work item", "create test plan", "create PR via MCP", "query database", "lookup Azure docs", "MCP routing".</description>
<file>.github/skills/mcp-builder/SKILL.md</file>
</skill>

<skill>
<name>ais-daily-start</name>
<description>Metcash AIS daily start check. USE FOR: the first thing to run at the start of a work session — confirms Azure/MCP auth is actually usable (not just "Connected"), and shows git status for this skills-hub repo plus every Metcash interface repo already cloned locally. No MCP calls, no ADO calls, no network fetch by default — local git + a single az CLI call only. Does not clone anything new (see code-corpus/initial-setup-checklist.md for one-time setup). Triggers: "daily start", "start of day", "morning check", "what should I continue with", "check my repos", "git status all repos", "am I logged in", "daily status".</description>
<file>.github/skills/ais-daily-start/SKILL.md</file>
</skill>

<skill>
<name>azure-local-auth</name>
<description>Metcash AIS local Azure authentication guide. USE FOR: connecting GitHub Copilot agent and MCP servers to Azure resources without interactive MFA on every session. Covers VS Code Azure Account extension sign-in, Azure SQL DB via Invoke-Sqlcmd with AccessToken, Azure Storage via az CLI auth-mode login, and user-assigned managed identity patterns. Triggers: "how to login to azure", "azure auth", "connect to azure", "azure account", "mcp azure login", "azure mfa", "azure sign in", "local azure auth", "managed identity", "connect to sql", "connect to storage", "list blobs", "query sql db".</description>
<file>.github/skills/azure-local-auth/SKILL.md</file>
</skill>

---

## TIBCO Conversion Skills

Run these skills in order for TIBCO-to-Azure conversion work:

<skill>
<name>tibco-azure-nfr-recommendation</name>
<description>Use this skill first for TIBCO-to-Azure work when the user needs architecture-fit, non-functional-requirement analysis, or a recommendation on whether the interface should be implemented with Logic App Standard only, Logic App Standard plus local transformation code, or another Azure pattern. Trigger it before code generation whenever the user mentions performance, payload size, throughput, best fit, architecture choice, or asks what the right target shape is.</description>
<file>.github/skills/tibco-azure-nfr-recommendation/SKILL.md</file>
</skill>

<skill>
<name>tibco-azure-converter</name>
<description>Use this skill for TIBCO-to-Azure Logic App workspace code generation after the NFR and architecture-fit analysis is complete. Trigger it when the user wants to generate a Logic App Standard workspace (workflows, connections, parameters, and any required local transformation code) for one or more destinations, derived from a reference workspace, and produce conversion outputs, assumptions, and unit-test CSV files. Do not use this skill for initial architecture recommendation or deployment planning.</description>
<file>.github/skills/tibco-azure-converter/SKILL.md</file>
</skill>

<skill>
<name>tibco-azure-deployment-guidance</name>
<description>Use this skill after TIBCO-to-Azure code generation when the user needs deployment planning, packaging guidance, resource group selection, pipeline alignment, or Azure environment placement for the generated workspace. Do not use it for architecture recommendation or code generation.</description>
<file>.github/skills/tibco-azure-deployment-guidance/SKILL.md</file>
</skill>

---

## Squad 20 Engineering Skills

Domain knowledge derived from scanning Squad 20 repositories in METCASHDevOps.
Load the appropriate skill before generating or reviewing any Squad 20 integration code.

<skill>
<name>squad20-engineering-overview</name>
<description>Squad 20 engineering overview. USE FOR: understanding the overall tech stack, platform domains, environment structure, and integration patterns used by Squad 20. Read this first when starting any Squad 20 task. Triggers: "squad 20", "metcash ais", "what is squad 20", "platform overview", "ais tech stack".</description>
<file>skills/squad20-engineering-overview.md</file>
</skill>

<skill>
<name>squad20-naming-conventions</name>
<description>Squad 20 Azure resource, pipeline, and code naming conventions. USE FOR: generating correctly named resources, app settings, Service Bus topics/queues, ADF pipelines, linked services, APIM APIs, and ADO variable groups. Triggers: "naming convention", "resource name", "what should I name", "pipeline name", "linked service name", "topic name".</description>
<file>skills/squad20-naming-conventions.md</file>
</skill>

<skill>
<name>logic-app-skill</name>
<description>Squad 20 Logic App Standard workspace patterns. USE FOR: understanding workspace layout (Pattern A vs B), connections.json structure, parameters.json structure, workflow naming, app settings keys, and pipeline conventions for Logic App deployments. Triggers: "logic app standard", "workflow.json", "connections.json", "parameters.json", "logic app workspace", "service bus trigger workflow".</description>
<file>skills/logic-app-skill.md</file>
</skill>

<skill>
<name>azure-function-skill</name>
<description>Squad 20 Azure Function App (.NET 8 Isolated) patterns. USE FOR: Program.cs DI setup, ISmcLogger injection, function trigger file structure, AppSetting.cs, Constants.cs, standalone vs co-located workspace patterns, and pipeline conventions. Triggers: "function app", "net 8 function", "isolated worker", "program.cs", "ismclogger", "function trigger".</description>
<file>skills/azure-function-skill.md</file>
</skill>

<skill>
<name>azure-data-factory-skill</name>
<description>Squad 20 Azure Data Factory patterns. USE FOR: ADF pipeline naming (pl_), linked service naming (ls_), dataset naming (ds_), factory JSON structure, parent/child pipeline patterns, and integration runtime types. Triggers: "azure data factory", "ADF pipeline", "linked service", "pl_ naming", "ls_ naming", "delta pipeline", "full load pipeline".</description>
<file>skills/azure-data-factory-skill.md</file>
</skill>

<skill>
<name>azure-service-bus-skill</name>
<description>Squad 20 Azure Service Bus patterns. USE FOR: namespace naming (nonprod/prod), topic naming (domain.service.env.sbt), queue naming (.sbq), SMC queue env mapping (sit/uat/ppd → uat), Logic App Service Bus connection patterns, and app settings keys. Triggers: "service bus", "topic name", "queue name", "service bus connection", "sbt naming", "SMC queue".</description>
<file>skills/azure-service-bus-skill.md</file>
</skill>

<skill>
<name>api-management-apiops-skill</name>
<description>Squad 20 APIM gen-3 APIOps patterns. USE FOR: API naming (platform-service-v1), API path in APIM, backend naming, named value naming (interfaceid, func-key, wf-sig), policy fragment usage, APIOps gen-3 folder structure, APIM service naming (ae1 suffix), and adding/updating APIs. Triggers: "APIM", "API management", "APIOps", "add API", "update policy", "named value", "backend", "api information", "policy fragment".</description>
<file>skills/api-management-apiops-skill.md</file>
</skill>

<skill>
<name>azure-devops-work-items</name>
<description>Squad 20 ADO work item conventions ("way of working"). USE FOR: EAII ID format and usage, work item types, variable group naming, service connection naming, build naming, agent pools, shared pipeline template references, and SonarQube integration. Triggers: "work item", "EAII", "variable group", "service connection", "agent pool", "ado pipeline", "sonarqube".</description>
<file>.github/skills/azure-devops-work-items/SKILL.md</file>
</skill>

<skill>
<name>azure-devops-repository-pr</name>
<description>Squad 20 repository and pull request conventions ("way of working"). USE FOR: repository naming, branch naming (main, release, feature/EAII-ID), PR title format (EAII-{number}: description), PR checklist, creating branches via ADO MCP, creating PRs via ADO MCP, and expected file changes per PR type. Triggers: "pull request", "create PR", "branch naming", "repository convention", "merge to main", "PR title".</description>
<file>.github/skills/azure-devops-repository-pr/SKILL.md</file>
</skill>

<skill>
<name>squad20-platform-domain-patterns</name>
<description>Squad 20 platform domain details (B2B, B2C, Enabling, Corporate, RMN, ALMNZ, Data). USE FOR: understanding which repositories, APIs, backends, named values, and typical integration patterns belong to each platform domain. Triggers: "B2B", "B2C", "enabling platform", "RMN", "corporate", "which repo", "domain patterns", "platform domain".</description>
<file>skills/squad20-platform-domain-patterns.md</file>
</skill>

<skill>
<name>squad20-scan-summary</name>
<description>Squad 20 repository scan summary. USE FOR: seeing which repositories have been scanned, what patterns were found, what inconsistencies exist, and which repos still need deeper scanning. Also lists all skill files created from the scan. Triggers: "scan summary", "what repos were scanned", "what was found", "what patterns exist", "gaps in knowledge".</description>
<file>skills/squad20-scan-summary.md</file>
</skill>

---

## Global Rules
- **Mandatory questionnaire stops before generated SDLC artifacts:** stop for explicit approval of `intake-questionnaire.md` before generating a TSD; stop for explicit approval of `codegen-readiness-questionnaire.md` before generating code; stop for explicit approval of `unit-test-generation-intake-questionnaire.md` before generating the unit-test CSV; stop again for explicit approval of `unit-test-readiness-questionnaire.md` before any shared ADO test-plan/suite/case writes; and stop for explicit approval of `runsheet-intake-questionnaire.md` before generating a runsheet or creating/updating its Confluence page. Approval at one stage never carries into the next. Do not infer a bypass from “quality test”; only a direct, per-run user instruction can authorize a local evaluation exception, and it never authorizes deployment or shared-system writes.
- **Inline intake gate for every generator:** Before generating or updating a TSD, code, test CSV, documentation artifact, runsheet, or conversion output, read the applicable source documents, status, repo/code and existing artifacts first. Identify only missing, ambiguous or conflicting facts. For each, show a proposed answer, its evidence/source, confidence or conflict, and impact; ask the user inline with `vscode_askQuestions` to confirm or modify it. Offer an explicit “unknown / keep blocked” response for unresolved critical facts. Record answers and provenance in the skill's existing questionnaire or assumptions artifact. If that question tool is unavailable, ask in chat and stop. Do not generate the downstream artifact until required answers are confirmed; then retain any separate explicit questionnaire/artifact approval stop defined by that skill. No response is not approval, and facts already evidenced in the TSD, repo or approved shared roster must not be re-asked.
- **Every `ais-logicapp-codegen` run must compare its generated workspace with the closest production `origin/main` Logic App before handoff.** Run `check_logicapp.py` and `compare_logicapp.py` on every generation, classify intentional design differences separately from defects, fix defects, and rerun both checks. Record the production repo/SHA and findings in `outputs/<InterfaceID>/code-quality-comparison.md`. This is a local source-quality gate only; it does not authorize deployment, runtime tests, ADO writes, commit, or push.
- **Human review gates apply after automated gates:** TSD review/approval before codegen readiness; code review must include build and unit-test status; a separately reviewed runsheet is required before each SIT, UAT/UT1, or PRD deployment; a PRD readiness runbook is required before PRD or a Ready-for-PRD claim. Percentages never override Critical/High findings, failed build/tests, missing mandatory evidence, or explicit deployment authorization.
- **`ais-unit-test-cases` has two separate approval stops:** an approved `unit-test-generation-intake-questionnaire.md` is required before generating `unit-test-cases.csv`; after CSV review, an approved `unit-test-readiness-questionnaire.md` is required before writing any shared ADO Test Plan/Suite/Cases. The CSV expands the TSD's own §5.x.10.2 scenarios; do not re-derive them when present.

- **⛔ Cross-cutting Ways of Working rule, applies to every skill in this section: check `outputs/<InterfaceID>/status.md` first, update it last.** Before starting any phase for an interface, check whether this file exists and read its Quick Resume + Open Gaps sections before doing anything else — before re-reading the FSD, before re-deriving a decision, before asking the user something the file already answers. After completing any phase, update the file's checklist row, Quick Resume, and Open Gaps — see `ais-interface-status`. If the interface has no `status.md` yet, create one from the template and backfill it rather than skipping this step. This exists because two real gaps in this project were caused by a decision's rationale living only in chat scrollback, not in any durable file — see `ais-interface-status`'s own SKILL.md for the full incident.
- **⛔ Default path for every new interface, no exceptions unless the user explicitly overrides: FSD → `metcash-tsd-generator` (produces an approved TSD in `tsd/<InterfaceID>/`) → `ais-codegen-readiness` → codegen skills.** Do not skip TSD generation just because an FSD (and Mapping/Manifest/transcript) are available — those four inputs are exactly what `metcash-tsd-generator` needs, so having them is a reason to run it, not a reason to shortcut past it. `ais-design-intake` (the no-TSD path) exists only for the rare case the user explicitly says no TSD will ever be produced for this interface — never choose it by default, and never choose it just because it is faster. If unsure which path applies, ask the user rather than defaulting to the shortcut.
- **Never invoke `ais-logicapp-codegen`, `ais-functionapp-codegen`, or `ais-datafactory-codegen` without the right pre-condition met first.** For the (default) TSD path that's an **approved** `codegen-readiness-questionnaire.md` from `ais-codegen-readiness`. For the exception no-TSD path that's an **approved** Design Intake Questionnaire from `ais-design-intake` — an unapproved one is not sufficient either way. Never run both for the same interface, and never let a codegen skill invent a repo name or resource name when the required artifact doesn't confirm one.
- **`outputs/<InterfaceID>/` is documents-only — questionnaires, CSVs, logs, reports, `assumptions.md`. It never holds generated code.** Generated code (Logic App JSON, C# Function App code, ADF pipeline JSON, and the TIBCO conversion overlay) always goes into a real local clone of the target ADO repo (`C:\Users\<you>\source\repos\<RepoName>`, branch `feature/EAII-<number>-<description>`) — resolved by `ais-codegen-readiness` (or noted in the TIBCO path by `tibco-azure-converter` itself, since there the reference workspace already is the production repo). Never auto-commit or auto-push that branch — leave it as local, uncommitted changes for the user to review.
- **`metcash-tsd-generator` requires an approved FSD.** Never generate a TSD without one; a Mapping Manifest is strongly recommended. The approved TSD corpus in `reference-corpus/` is the design authority — never invent structure, naming, or infrastructure values.
- Interface IDs must match `EAII-{number}` (example: `EAII-107`). Never proceed without one.
- Never invent naming conventions. Read the reference workspace first.
- **`ais-unit-test-cases` expands the TSD's own §5.x.10.2 test scenarios — never re-derives categories from scratch when they exist.** Real ADO structure: one shared Test Plan "AIS Migration" → "Phase 2" → "Unit Testing" → one flat suite per interface (`UT_EAII-{number} - {InterfaceName}`), never a new plan per interface and never a suite per category.
- **Never run `ais-test-execution` against a PRD resource.** Non-prod environments only (dev/sit/uat/ut1).
- Log every assumption to `outputs/<InterfaceID>/assumptions.md`.
- SMC observability logging is required in all Logic App workflows and ADF pipelines.
- All service-to-service authentication uses Managed Identity — never connection strings with keys.
- **An MCP server showing "Connected" does not mean its tools are usable.** Azure DevOps/Azure MCP servers authenticate via the local `az login` session — check `az account show` is on the `metcash.onmicrosoft.com` tenant before trusting a "Connected" status; see `azure-local-auth`.
- **⛔ Mandatory pre-condition: Azure DevOps MCP and GitHub MCP must both be verified reachable before generating a TSD, generating any code, or generating unit test cases.** This is a hard gate, not a nice-to-have — see `azure-local-auth`'s pre-flight check. `metcash-tsd-generator`, `ais-codegen-readiness`, and `ais-unit-test-cases` each check this at their own Step 0; do not skip it because a prior skill in the same session already checked it for a *different* interface.
- **For a migration interface, the legacy TIBCO source's repo name and entry-point file(s) must be found and recorded in the TSD itself** (§5.x.1.1, via `metcash-tsd-generator` Step 0.6), not left only in a later skill's questionnaire — `ais-codegen-readiness`'s TIBCO cross-check (its questionnaire §5) and code/unit-test generation both depend on that repo already being named in the approved TSD.

---

## MCP Server Routing

Six MCP servers are configured in `.vscode/mcp.json`. Use this table to determine which server
to activate for each engineering activity. Load the `mcp-usage-guide` skill for full details.

| Engineering Activity | MCP Server to Use |
|---|---|
| Read FSD or TSD from Confluence | `com.atlassian/atlassian-mcp-server-metcash` |
| Create or update Confluence documentation / runsheets | `com.atlassian/atlassian-mcp-server-metcash` |
| Read TIBCO source from GitHub | `github` |
| Read reference Logic App workspace from METCASHDevOps | `microsoft/azure-devops-mcp-metcash` |
| Create / update ADO work items, tasks, or bugs | `microsoft/azure-devops-mcp-metcash` |
| Create ADO test plan, suite, or test cases | `microsoft/azure-devops-mcp-metcash` |
| Record test run results against an existing ADO test plan | `microsoft/azure-devops-mcp-metcash` |
| Create branch or pull request | `microsoft/azure-devops-mcp-metcash` |
| Run or monitor ADO pipelines | `microsoft/azure-devops-mcp-metcash` |
| Search or update ADO wikis | `microsoft/azure-devops-mcp-metcash` |
| Query Azure SQL (B2B UT1 environment) | `azure-sql-b2b-ut1` |
| Look up Azure Logic App / ADF / Function App schemas | `microsoft-docs` |
| Persist context across a multi-step session | `memory` |

> **Always attempt to retrieve FSD/TSD from Confluence via Atlassian MCP before asking the user
> to paste document content manually.**

> **Always attempt to read the reference workspace from ADO MCP before asking the user to provide
> file paths manually.**

## Reference Templates

- **Primary reference workspace** — Logic App Standard with inline transformation code:
  `Metcash-AIS-Data-Metproducts-Workspace/` (Logic App in `LogicApp/`, functions in `Function/`)
- **Fallback Logic App template:** [reference-templates/logic-apps/workflow.template.json](../reference-templates/logic-apps/workflow.template.json)
- **Test case template:** [reference-templates/tests/unit-test-cases.template.csv](../reference-templates/tests/unit-test-cases.template.csv)