---
name: Design Intake
description: "NO-TSD EXCEPTION path only, never the default — use ONLY after explicitly confirming no TSD will ever be produced for this interface. Reads and validates an FSD before generating any AIS interface code, producing a Design Intake Questionnaire. The default for every new interface is /create-tsd then /codegen-readiness."
argument-hint: "Interface ID, for example EAII-254"
mode: agent
---

# AIS Design Intake — FSD Reader (no-TSD EXCEPTION path)

> **⛔ This is an exception path, not a default choice.** The default for every new interface is
> `metcash-tsd-generator` → `ais-codegen-readiness` (FSD → approved TSD → codegen) — do not use
> this prompt just because an FSD is on hand or generation would be faster. Only continue here
> after the user has **explicitly confirmed** no TSD will ever be produced for this interface.
>
> **If a TSD already exists** (`tsd/<InterfaceID>/*.md`), use `ais-codegen-readiness` instead —
> it reads the TSD directly plus resolves the repo/resource name and TIBCO cross-check that this
> skill doesn't do.

Use the `ais-design-intake` skill to validate the FSD and produce a **Design Intake Questionnaire** before any code generation begins.

Interface ID: $ARGUMENTS

---

## What to provide

1. **FSD path or content** — mandatory. Paste the file path or the document content directly into chat.
2. **Target generation type** — Logic App workflow / Function App / ADF pipeline / combination.

---

## What this produces

- Validated Design Intake Questionnaire saved to `outputs/<InterfaceID>/design-intake-questionnaire.md`
- Interface ID, trigger type, source/target systems, business rules, NFRs, field mappings
- List of assumptions and any gaps that must be resolved before code generation

> **This step is mandatory.** No code generation skill (`ais-logicapp-codegen`, `ais-functionapp-codegen`, `ais-datafactory-codegen`) will run without a Design Intake Questionnaire.
