---
name: Deployment Runsheet
description: "Complete the approved runsheet intake, then draft or publish an AIS deployment runsheet for a named environment."
argument-hint: "Interface ID and environment, for example EAII-254 SIT"
mode: agent
---

# AIS Deployment Runsheet

Use the `ais-deployment-runsheet` skill to create or update a Confluence deployment runsheet.

Interface ID and environment: $ARGUMENTS

Read `outputs/<EAII-ID>/status.md` first. Review the approved TSD, current code and pipeline YAML,
existing same-interface runsheet, and user-designated shared roster before asking anything. Ask
inline only about unresolved facts, with proposed value, evidence, impact, and confirm/correct/
unknown choices. Record answers in `outputs/<EAII-ID>/runsheet-intake-questionnaire.md`; stop for
explicit approval before drafting or creating/updating a Confluence page. Preserve the fixed
production section order and roster exactly; only the developer name varies. Update status last.

---

## Azure CLI — Pre-deployment Validation Steps

> These are checklist examples, not intake commands. Do not execute them while preparing a draft;
> any live validation requires separate authorization for the named environment and resource.

### 1. Verify Azure login

```bash
az account show
az account set --subscription "<SubscriptionName>"
```

### 2. Confirm Logic App resource exists

```bash
az logicapp show \
  --name "<LogicAppName>" \
  --resource-group "<ResourceGroup>" \
  --query "{name:name, state:properties.state}" \
  --output table
```

### 3. Confirm Key Vault secrets are provisioned

```bash
az keyvault secret list \
  --vault-name "<KeyVaultName>" \
  --query "[].{name:name}" \
  --output table
```

### 4. Confirm Managed Identity role assignments

```bash
az role assignment list \
  --assignee "<ManagedIdentityClientId>" \
  --output table
```

### 5. Confirm Service Bus namespace and topic

```bash
az servicebus topic show \
  --namespace-name "<Namespace>" \
  --name "<TopicName>" \
  --resource-group "<ResourceGroup>" \
  --query "{name:name, status:properties.status}" \
  --output table
```

---

## What to provide

- EAII ID
- Target environment: ST1 / UT1 / SIT / PRD
- Change Request number (or TBD)
- Interface resource names (Logic App, Key Vault, Service Bus, Resource Group)
- Deployment start/end dates
- Approved shared roster source and assigned developer's exact full name (do not substitute fixed roster names/roles)

---

## What this produces

A reviewed local intake questionnaire, followed only after explicit approval by a structured runsheet with:
- Pre-deployment checklist
- Step-by-step deployment sequence with status macros
- Rollback plan
- Post-deployment verification steps
