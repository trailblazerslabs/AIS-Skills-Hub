---
name: Deployment Runsheet Review
description: Review an existing AIS deployment runsheet against its approved TSD, current code, pipeline evidence, and environment checklist.
argument-hint: "Interface ID, environment, and runsheet link/path, for example EAII-529 SIT <link>"
mode: agent
---

# Environment Runsheet Review

Review the exact runsheet revision for $ARGUMENTS using
`.github/skills/ais-runsheet-review/SKILL.md` and
`review-gates/templates/deployment-runsheet-review.template.md`.

1. Read `outputs/<EAII-ID>/status.md` first. Establish whether this is an active environment
   gate or a retrospective audit; do not apply active deployment approval to an archive review.
2. Compare the runsheet with the approved TSD, refreshed current-code baseline, exact promotion
   artifact/build, each independently deployed component's pipeline/run, change record, and
   environment-specific checklist. Keep `origin/main` distinct from the promotion artifact.
3. Treat missing evidence as a finding. Never infer build, test, approval, deployment, or live
   Confluence state. Record TSD/code conflicts and required owner decisions explicitly.
4. Save an active review to
   `outputs/<EAII-ID>/deployment-runsheet-review-<ENV>.md`; for a retrospective audit, use
   `review-gates/corpus/runsheets/reviews/` and label it `RETROSPECTIVE — NOT DEPLOYMENT APPROVAL`.
   Report Critical/High findings before the score. Active PASS requires 100% of applicable
   mandatory checks, complete evidence, required sign-offs, and no unresolved Critical/High
   findings; otherwise mark BLOCKED.
5. Update interface status last. Do not edit or publish the runsheet, update ADO/Confluence, run
   a pipeline, or authorize deployment as part of this review.

If the interface, environment, review mode, or exact runsheet revision is unclear, ask only for
that missing scope. Missing operational evidence is a blocker, not a reason to guess.