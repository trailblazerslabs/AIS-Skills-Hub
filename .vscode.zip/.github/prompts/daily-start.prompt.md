---
name: Daily Start
description: "Start-of-day check: confirm Azure/MCP auth is actually usable, and show git status for this repo and every Metcash interface repo already cloned locally. No MCP calls, no ADO calls, no network fetch by default."
mode: agent
---

# AIS Daily Start

Use the `ais-daily-start` skill.

Run the script directly:

```powershell
pwsh .github/skills/ais-daily-start/scripts/daily-start.ps1
```

Then summarize the output as 2–3 concrete observations (auth OK or not, anything uncommitted
you should know about, any branch with no upstream) — don't just repeat the raw text back.

If this is your first time on this machine and no repos show up under Section 3, see
[`code-corpus/initial-setup-checklist.md`](../../code-corpus/initial-setup-checklist.md) for the
one-time clone step first — this check never clones anything itself.
