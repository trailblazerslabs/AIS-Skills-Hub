---
name: TSD Review
description: Critically review a generated AIS TSD against its approved inputs, reference corpus, and TSD review gate.
argument-hint: "Interface ID and TSD path, for example EAII-529 tsd/EAII-529/Technical Specification.md"
mode: agent
---

# TSD Review Gate

Review the generated TSD for $ARGUMENTS using the TSD Review Gate in
`.github/skills/metcash-tsd-generator/SKILL.md` Step 7.5 and
`review-gates/templates/tsd-review-checklist.template.md`.

1. Read `outputs/<EAII-ID>/status.md` first. Identify the exact TSD revision and confirm the
   generation quality checks are complete. Read the approved FSD, available Mapping and Mapping
   Manifest, assumptions, diagrams, and relevant approved corpus evidence.
2. Run the TSD `quality_review.py` check using the current skill's documented command. Record its
   score separately from the human checklist score; never average them.
3. Score each checklist dimension only from cited evidence. Missing or unverified evidence earns
   zero. Report Critical/High findings first, with exact section, evidence, impact, and correction
   owner. Do not edit the TSD or continue to codegen readiness during the review.
4. Save `outputs/<EAII-ID>/tsd-review-checklist.md`. PASS requires at least 90%, no unresolved
   Critical/High findings, and mandatory evidence. Otherwise mark BLOCKED or return for correction.
5. Stop for explicit TSD review approval before `ais-codegen-readiness`. Approval permits only the
   separate readiness step; it does not approve code generation. Update the interface status last.

If the TSD revision, input approval, or review scope is ambiguous, ask only the necessary
clarifying question. Treat unavailable evidence as a finding; never infer a pass.