---
name: Create Metcash TSD
description: "Generate a Metcash AIS Technical Specification Document (TSD) end-to-end from the standard four-file input set (FSD, Mapping, Mapping Manifest, FSD Walkthrough Transcript) using the metcash-tsd-generator skill and its approved TSD reference corpus."
argument-hint: "Interface ID, for example EAII-374"
agent: agent
---

Generate a Metcash TSD by following, in order:
- Skill (the entire flow lives here): [metcash-tsd-generator/SKILL.md](../skills/metcash-tsd-generator/SKILL.md)
- Reference corpus (design authority): `reference-corpus/converted/` and `.github/skills/metcash-tsd-generator/references/01-09.md`
- Diagram templates: `.github/skills/metcash-tsd-generator/templates/diagrams/*.drawio`

Interface ID: $ARGUMENTS

---

## Before you start

Read `outputs/<Interface ID>/status.md` first when it exists. Preserve existing TSD outputs; if a
TSD already exists, ask whether this is a review/update or a new revision before overwriting any
artifact. Do not delete existing files as an automatic generation step.

Confirm the four Input Contract files exist for this Interface ID, staged at
`tsd-inputs/<Interface ID>/source/`:

1. FSD (Confluence MHTML `.doc`)
2. Mapping — field-level (Confluence MHTML `.doc`)
3. Mapping Manifest (Confluence MHTML `.doc`)
4. FSD Walkthrough Transcript (Teams recording `.docx`)

If any are missing, stop and ask the user rather than proceeding on a partial set.

## Run the skill's steps in order — do not skip or reorder

1. **Step 0 (Intake)** — stage + convert all four files (`mhtml_to_md.py` for the three `.doc`
   files, `transcript_to_md.py` for the transcript). Read the FSD, Mapping, and Manifest in full.
2. **Step 0.5 (Mine the transcript)** — build the cited Decisions table BEFORE asking the user
   anything. Every row needs a Turn/speaker/timestamp citation.
3. **Step 0.75 (mandatory pause, default mechanism for Steps 1 + 2)** — only after Steps 0 and 0.5
   are fully complete (all four inputs read, transcript mined). Generate
   `tsd-inputs/<Interface ID>/intake-questionnaire.md` with the archetype recommendation and every
   open Step 2 question, **each pre-filled with a proposed answer and its rationale** — never a
   blank field. Never generate this file before intake is complete — it must reflect evidenced
   understanding of the FSD/Mapping/Manifest/transcript, not a blank generic form. **Stop and wait
   — do not proceed to Step 3 until the user explicitly approves the questionnaire**, whether
   unchanged or edited. This is the default path; only skip it for a live chat conversation if the
   user explicitly asks to answer live instead.
4. **Step 1 (Archetype selection)** ⏸️ — recommend A/B/C/D with FSD + transcript evidence and the
   closest corpus precedent. Wait for user confirmation. *(Skipped if Step 0.75 was used.)*
5. **Step 2 (Design decisions)** ⏸️ — ask only the questions the FSD and transcript leave open;
   present the rest as confirmed-from-transcript with citations. Wait for answers.
   *(Skipped if Step 0.75 was used.)*
6. **Step 3 (Generate)** — populate `templates/TSD.template.md` section by section per
   `references/06-fsd-to-tsd-traceability.md`, using `references/04` for boilerplate and
   `references/05` for the SMC tables. Never fabricate a gap — mark it
   `*<To be confirmed — [what] from [whom]>*`.
7. **Step 4 (Naming verification)** — every Azure resource name from `references/03` first,
   `microsoft_docs_search` only for gaps the corpus doesn't cover.
8. **Step 5 (Diagrams)** — one multi-page `.drawio` in N2 style from the templates, per
   `references/08-diagram-conventions.md`, plus a PNG export per page embedded in the TSD.
9. **Step 6 (Quality gates)** — run all of 6.1–6.7, including the mechanistic
   `check_tables.py` pass and the `tsd-comparer` peer diff against the closest corpus TSD.
10. **Step 7 (Deliverables checklist)** — confirm every item before handing over.
11. **Step 7.5 (TSD Review Gate)** — after all generation quality checks pass, complete
   `review-gates/templates/tsd-review-checklist.template.md`, run the separate human review,
   and stop for explicit TSD review approval before codegen readiness. TSD review approval does
   not approve code generation; the codegen-readiness questionnaire remains a separate gate.

## Output

`tsd/<IntegrationName>/Technical Specification - <IDs> - <Source> to <Target>.md` plus diagrams
and `assumptions.md`, per the skill's Output Location section.
