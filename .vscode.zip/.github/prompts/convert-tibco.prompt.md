---
name: Convert TIBCO Interface
description: "Convert a TIBCO interface to Azure artifacts by running NFR analysis first and then the additive TIBCO-to-Azure converter skill against the local reference workspace."
argument-hint: "Interface ID, for example EAII-254"
agent: agent
---

Convert a TIBCO interface to Azure by following:
- Workspace instructions: [copilot-instructions.md](../copilot-instructions.md)
- Step 1 skill: [tibco-azure-nfr-recommendation](../skills/tibco-azure-nfr-recommendation/SKILL.md)
- Step 2 skill: [tibco-azure-converter](../skills/tibco-azure-converter/SKILL.md)

Interface ID: $ARGUMENTS

---

## STEP 0 — Run NFR Analysis First (MANDATORY)

Before starting any conversion work, collect the non-functional requirements and architecture-fit inputs first.

**Ask first:**
1. **TIBCO source**: Git repository URL or local path to TIBCO BWP files
2. **Target destination(s)**: Which target system(s) from TIBCO BWP? (e.g., Sorted, PE, Corporate)
3. **Reference workspace**: Confirm using default (`C:\Users\sathyja\Source\repos\Metcash.AIS.Data.Metproducts`) or specify another
4. **Payload size**: Typical and peak message or file size
5. **Volume and concurrency**: Request rate, batch frequency, or concurrent runs
6. **Latency expectation**: Real-time, near-real-time, batch, or scheduled
7. **Reliability and support constraints**: Retry, idempotency, failure handling, logging, and operational expectations

Produce an explicit architecture recommendation first. Only then proceed to code generation.

This prompt is for the additive, structure-preserving conversion path only. Do not ask the user to choose a mode here.

---

## Required steps:
1. Run the NFR recommendation step first and confirm:
   - approved target architecture
   - whether direct target JSON should be used for JSON-first targets
   - any payload, throughput, reliability, or operational constraints that affect implementation
2. Read the primary reference workspace configured in the workspace instructions:
   - List the workspace root to discover the inner subfolder and actual file/folder structure
   - Read all `workflow.json` files found under the workspace
   - Read all `connections.*.json` and `parameters.*.json` files found
   - Read all `appsettings.*.json`, workspace metadata files (`.code-workspace`, `.sln`, `.csproj`, `host.json`, `.funcignore`, `.gitignore`, `.vscode/`), and test assets found
   - Read any transformation code files (entry point, helpers, mappers, models) discovered in the workspace
   - If pipeline YAML files exist in the AIS source/reference workspace, read them and plan matching renamed pipeline files for the converted output
   - Build the Style Inventory before writing any output
3. Extract the Style Inventory from the workspace before writing any code.
4. Ask for a TIBCO Git repository URL if one is not provided.
5. Validate that Interface ID uses `EAII-{number}` format, for example `EAII-254`.
6. Read the TIBCO source from the provided Git repository URL.
7. Identify what mapping changes relative to the reference workspace while preserving the existing scaffold.
8. Generate converted output for the requested interface.
   - Output the FULL mirrored workspace scaffold with existing files preserved plus the new interface files added in place.
   - Merge `connections.*.json`, `parameters.*.json`, and `appsettings.*.json` per environment instead of outputting only the new interface slice.
   - If pipeline YAML files exist in the AIS source/reference workspace, include converted Azure deployment pipeline files in the output and rename them to match the generated deployment unit.
   - Keep machine-readable files valid; use placeholder values like `<SET_...>` instead of comments inside JSON.
   - For JSON-first targets, prefer direct target JSON generation unless the approved architecture or downstream contract requires an intermediate XML representation.
9. Generate `unit-test-cases.csv` using [reference-templates/tests/unit-test-cases.template.csv](../../reference-templates/tests/unit-test-cases.template.csv).
10. Write all outputs to `outputs/<InterfaceID>/` mirroring the workspace folder layout.
11. Include `assumptions.md`, `conversion-notes.md`, and `change-summary.md` for inferred behavior and file status tracking.

## Additive Conversion Requirements

These requirements always apply in this prompt:
1. **Understand existing AIS code FIRST** — read and document all existing workflows before touching TIBCO
2. **Extract ONLY target-specific logic** from TIBCO BWP (e.g., Sorted model, its REST service, XML parser)
3. **Create SEPARATE new workflow** — do not remove existing workflows from the output workspace
4. **Preserve the full deployable scaffold**:
   - Copy the reference workspace root files, project/solution files, `.vscode/`, ignore files, and test assets into `outputs/<InterfaceID>/`
   - Add new code to the existing Function project structure unless the reference workspace already uses multiple projects
   - Preserve existing config keys still used by existing workflows, for example existing Azure Function app keys
   - If AIS source pipeline YAML exists, generate `pipelines/` files in the output with renamed deployment identifiers and updated workspace/artifact paths
5. **Merge environment config files**:
   - `connections.*.json` = existing + new entries in one valid file per environment
   - `parameters.*.json` = existing + new parameter objects in one valid file per environment
   - `appsettings.*.json` = existing + new settings in one valid file per environment
   - Use explicit placeholder values like `<SET_...>` for unknown deployment values; do not insert comments into JSON
6. **Document in assumptions.md**:
   - All TIBCO logic PICKED (with target file)
   - All TIBCO logic IGNORED (with reason: exists in AIS / not for target)
   - All NEW code added to AIS (with file paths)
   - All EXISTING code preserved (unchanged)
   - All AIS source pipeline YAML files used and the generated Azure pipeline files derived from them
   - Any retained intermediate XML representation and why it could not be removed
7. **Generate change-summary.md** — quick overview with `[EXISTING]`, `[NEW]`, `[MERGED]` markers
8. **Output complete, build-ready code** — both existing (unchanged) and new together

## Build-Ready Output Requirements

The output MUST be immediately buildable and deployable:
1. **Output structure = Input reference workspace structure** — same folder names, same file locations
2. **Include ALL files** — every file from reference workspace must be present
3. **New files in correct locations** — new workflow alongside existing workflows, new mappers in Mappers/ folder
4. **Merged configuration files** — connections.json, parameters.json with existing + new entries in ONE file
5. **File status markers** — track `[EXISTING]`, `[NEW]`, or `[MERGED]` in `change-summary.md`; do not insert comments into JSON/XML files
6. **No manual reorganization needed** — user can copy output and build/deploy directly

If no interface ID is provided, or if it does not match `EAII-{number}`, ask for a valid one before generating output.