---
mode: agent
description: Generate technical documentation for a Metcash AIS integration interface.
---

# AIS Interface Documentation

Use the `ais-documentation` skill to generate the following documents for this interface:

Read interface status, the approved TSD, current code, and existing documentation first. Ask inline
only about missing, ambiguous, or conflicting facts, with proposed answers, evidence/source, and
impact; allow confirm, correction, or unknown/blocked. Record answers and provenance in
`assumptions.md`. Stop if required facts remain unresolved.

1. Technical specification (`spec.md`) — overview, data flow, field mapping, NFR, error handling, observability
2. Assumption log (`assumptions.md`) — all assumptions made, with impact statements
3. Data flow diagram (Mermaid) — source → processing → target with error paths shown
4. Change summary (`change-summary.md`) — if this is an update to an existing interface

Write outputs to `outputs/<InterfaceID>/`.
Use the interface ID, name, source system, and target system from context.
If the interface ID is not yet known, ask before proceeding.
