---
mode: agent
description: Review AIS integration code and its production, build, and unit-test evidence against Metcash AIS standards.
argument-hint: "Interface ID and repo/branch, for example EAII-529 feature/EAII-529"
---

# AIS Code Review

Use the `ais-code-review` skill to review the generated code for $ARGUMENTS. Read
`outputs/<EAII-ID>/status.md` first and use the exact target repo, branch, and commit SHA.

Before giving a verdict, record the TSD review disposition, production comparison baseline/report,
calibrated checker output, exact build/package result, unit-test CSV coverage, code-level test
result, ADO test-case status, and non-production execution status. Missing evidence is `NOT RUN`,
never PASS. Follow every applicable review dimension in the skill, including OWASP security and
SMC observability. Critical/High findings, failed checks/build, or required tests not passing block
PASS regardless of score.

Save the full scored report to `outputs/<EAII-ID>/code-review-report.md` using
`reference-templates/code-review/review-report.template.md`. List findings before the summary,
include severity/evidence/impact/recommendation, and update interface status last. Do not edit the
reviewed code, write to ADO/Confluence, run a deployment pipeline, or deploy.
