---
name: Build Review
description: Review local build/package and unit-test evidence for an AIS interface without triggering a remote pipeline or deployment.
argument-hint: "Interface ID and repo/branch, for example EAII-529 Metcash.AIS.Data.Metproducts feature/EAII-529"
mode: agent
---

# Build and Test Evidence Review

Review build evidence for $ARGUMENTS. This is a local evidence gate feeding the full
`ais-code-review`; it does not replace that review or authorize a merge, pipeline run, or deploy.

1. Read `outputs/<EAII-ID>/status.md` first. Identify the exact repo, branch, commit SHA, TSD
   review disposition, and promotion candidate. Do not treat `origin/main` as the promotion
   artifact.
2. Inspect the applicable pipeline YAML, project/solution configuration, existing build logs,
   package/artifact identifiers, and test results. Keep application, APIOps/API, and IaC builds
   separate when they are independently deployed.
3. Do not queue or trigger a remote pipeline. If a local build is explicitly requested, inspect
   the repository instructions and run only the relevant local build command. For .NET tests,
   follow the `run-tests` skill to detect the SDK/test platform and use the correct command; do
   not guess framework flags. Do not run deployed-resource or PRD tests.
4. Record each applicable result as PASS, FAIL, NOT RUN, or N/A with exact commit/build ID,
   command or pipeline, configuration/TFM, warnings/errors, artifact identity, and evidence path.
   Missing or unverified evidence is NOT RUN, never PASS.
5. Save `outputs/<EAII-ID>/build-review-report.md` with the evidence matrix, findings, blockers,
   and a build-gate disposition. Update the interface status last. The full code review must still
   include this report and unit-test status before any PASS verdict.

If the target commit or applicable build evidence cannot be identified, ask for the missing
scope/evidence or mark the review BLOCKED. Do not access another ADO organization or write to ADO.