---
name: New AIS Interface (Full Workflow)
description: "End-to-end AIS interface flow: approved TSD and review → readiness → code/build/tests → documentation and code review → environment runsheet review."
argument-hint: "Interface ID, for example EAII-254"
mode: agent
---

# New AIS Interface — End-to-End Workflow

Follow this guided workflow to deliver a complete new AIS integration interface from design documents to generated artifacts.

Interface ID: $ARGUMENTS

---

## Folder structure — read this before anything else

`outputs/<InterfaceID>/` is **documents only** — questionnaires, CSVs, reports, logs. It never
holds generated code. **Generated code always goes into a real local clone of the target ADO
repo** (`C:\Users\<you>\source\repos\<RepoName>`, on branch
`feature/EAII-<number>-<short-description>`) — resolved and created in Phase 1 below, then
written into by Phase 2. If any step is about to write code under `outputs/`, stop — that's
wrong, go back and resolve the real repo clone first.

Each generator asks inline about only missing, ambiguous, or conflicting facts, showing the
proposed answer, evidence, impact, and confirm/correct/unknown choices. Record answers in the
applicable questionnaire or assumptions file and stop while required facts remain unresolved.
Separate approval gates still apply: TSD intake, human TSD review, codegen readiness, unit-test
CSV generation, and ADO test readiness. Approval at one stage never carries into another.

---

## Phase 1 — TSD (default, mandatory) or Design Intake (explicit exception only)

Check whether a TSD already exists at `tsd/<InterfaceID>/`:

- **⛔ Default for every new interface, no exceptions unless the user explicitly overrides:**
  run `metcash-tsd-generator` first (FSD + Mapping + Mapping Manifest + walkthrough transcript
  → `tsd/<InterfaceID>/*.md`), complete human TSD review and obtain approval, then run
  `ais-codegen-readiness`. Having an FSD (and Mapping/Manifest/
  transcript) ready is a reason to run `metcash-tsd-generator`, not a reason to skip it — do not
  shortcut straight to `ais-design-intake` just because generation would be faster.
  `ais-codegen-readiness` then resolves the target repo (**clones/reuses it under
  `C:\Users\<you>\source\repos\<RepoName>` and creates the feature branch there** — this is where
  code will actually be written, not `outputs/`), resource name(s), a field-mapping cross-check
  against the raw Mapping Manifest, a Kudu-based network connectivity pre-check against the TSD's
  target endpoint (existing hosts only), and — if the TSD names a legacy TIBCO implementation —
  a TIBCO source cross-check.
  ⛔ **TSD review and `ais-codegen-readiness` each stop for explicit approval** — never let
  codegen guess a repo, resource name, archetype, or destination folder. Outputs:
  `tsd/<InterfaceID>/*.md`, `outputs/<InterfaceID>/tsd-review-checklist.md`, then
  `outputs/<InterfaceID>/codegen-readiness-questionnaire.md`
- **`ais-design-intake` — no-TSD EXCEPTION path, only after the user explicitly confirms no TSD
  will ever be produced for this interface.** Do not choose this path on your own initiative;
  ask the user if it's unclear which path applies.
  - Provide the **FSD** (mandatory)
  - Confirm the target: Logic App / Function App / ADF / combination
  Output: `outputs/<InterfaceID>/design-intake-questionnaire.md`

Never run both for the same interface.

---

## Phase 2 — Code Generation

Based on the approved architecture in the readiness questionnaire or intake summary, run the appropriate skill:

| Pattern | Skill |
|---|---|
| Logic App workflow only | `ais-logicapp-codegen` |
| Logic App + C# transformation | `ais-logicapp-codegen` then `ais-functionapp-codegen` |
| Bulk/batch data movement | `ais-datafactory-codegen` |

**All generated code goes into the real repo clone + branch resolved in Phase 1** — never into
`outputs/<InterfaceID>/`. Leave the changes as local, uncommitted edits on that branch; do not
commit, push, or open a PR yet — that's a separate, explicit step (see Phase 6).

---

## Phase 3 — Unit Test Cases

Run `ais-unit-test-cases`:
- Expands the TSD's own §5.x.10.2 scenarios using the actual generated code. Resolve missing
  expected-result or test-data facts inline, then stop for approval of
  `unit-test-generation-intake-questionnaire.md` before creating `unit-test-cases.csv`.
- After the CSV is reviewed, create `unit-test-readiness-questionnaire.md` and stop for separate
  approval before any shared ADO write.
- Only after that second approval: create **one flat suite** `UT_EAII-<number> - <InterfaceName>` inside
  the existing shared Test Plan **"AIS Migration" → "Phase 2" → "Unit Testing"** (never a new
  Test Plan per interface, never a suite per category), with one Test Case per CSV row, and
  writes the resulting IDs to `outputs/<InterfaceID>/ado-test-case-creation-result.json`

---

## Phase 4 — Documentation

Run `ais-documentation`:
- Generates `spec.md`, `assumptions.md`, data-flow diagram, `change-summary.md` — all in
  `outputs/<InterfaceID>/` (these are genuinely documents, so this one does belong there)

---

## Phase 5 — Code Review

Run `/build-review` for local build/package and unit-test evidence, then `/code-review` on the
generated files **in the real repo clone from Phase 1/2**. The code review must record the exact
repo, branch, commit, production comparison, build and unit-test statuses. Missing evidence is
NOT RUN, not PASS. Save reports under `outputs/<InterfaceID>/`; do not deploy.

---

## Phase 6 — Deployment Runsheet and Environment Review

After code review and release preparation, run `/deployment-runsheet` to complete its inline
questionnaire and stop for approval before drafting or publishing. Run `/runsheet-review`
separately for each SIT, UAT/UT1, or PRD runsheet. PRD readiness needs its own 100% runbook review;
readiness is not deployment authorization.

## Phase 7 — Commit, Push, PR

Run `azure-devops-repository-pr` to commit and push the changes already sitting on the branch
created in Phase 1, and open the PR — the branch itself is not created here, it already exists.

---

## Checklist

- [ ] FSD provided and validated
- [ ] TSD generated via `metcash-tsd-generator` and approved at `tsd/<InterfaceID>/*.md` (default path) — unless the user explicitly confirmed the no-TSD exception path
- [ ] Human TSD review approved before codegen readiness on the default path
- [ ] Either an approved `codegen-readiness-questionnaire.md` (TSD path) or `design-intake-questionnaire.md` (explicit no-TSD exception) exists — repo, branch, and resource name confirmed, never guessed
- [ ] Code generated into the **real repo clone + branch** from Phase 1 — not `outputs/<InterfaceID>/`
- [ ] `unit-test-cases.csv` generated, `unit-test-readiness-questionnaire.md` approved by you, real ADO Test Suite/Cases created under the shared "AIS Migration" → "Phase 2" → "Unit Testing" plan
- [ ] Code review PASS verdict obtained
- [ ] Build/unit-test evidence recorded; environment runsheet review completed for the target deployment
- [ ] PR raised following `azure-devops-repository-pr` conventions
