---
name: Azure Local Auth Setup
description: "Set up local Azure authentication for GitHub Copilot agent and MCP servers using VS Code Azure Account extension. Includes Azure CLI login steps."
mode: agent
---

# Azure Local Authentication Setup

Use the `azure-local-auth` skill to connect GitHub Copilot agent and all Azure MCP servers to your Azure resources without repeated MFA prompts.

---

## Azure CLI — Quick Auth Steps

> Run these from your **Metcash Dev Box terminal** or VS Code integrated terminal.

### 1. Check current Azure CLI login status

```bash
az account show
```

If not logged in, proceed to step 2.

### 2. Login interactively (MFA once per session)

```bash
az login --tenant metcash.onmicrosoft.com
```

Complete MFA in the browser, then return to the terminal.

### 3. Set correct subscription

```bash
az account list --output table
az account set --subscription "<SubscriptionName>"
```

### 4. Verify token cache is active

```bash
az account get-access-token --output json
```

---

## VS Code Azure Account Extension (recommended for MCP servers)

1. Press `Ctrl+Shift+P` → **Azure: Sign In**
2. Complete MFA in the browser window that opens
3. Select tenant: **metcash.onmicrosoft.com**
4. After sign-in, press `Ctrl+Shift+P` → **MCP: List Servers** → restart each Azure MCP server

---

## Managed Identity Pattern

For Logic App, Function App, and ADF code generation, all service-to-service authentication uses **user-assigned managed identities**. Never use connection strings with storage keys.

The specific identity name and resource group will be provided at code-generation time by the `ais-logicapp-codegen`, `ais-functionapp-codegen`, or `ais-datafactory-codegen` skill.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| MCP server shows "unauthenticated" | Restart the MCP server after VS Code Azure Account sign-in |
| `az` returns 401 | Re-run `az login --tenant metcash.onmicrosoft.com` |
| Wrong subscription selected | Run `az account set --subscription "<name>"` |
| Token expired mid-session | Run `az account get-access-token` to refresh |
