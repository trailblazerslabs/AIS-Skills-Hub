---
name: Unit Test Cases
description: "Generate a unit-test-cases.csv for an AIS interface covering happy path, error path, boundary, and business logic scenarios."
argument-hint: "Interface ID, for example EAII-254"
mode: agent
---

# AIS Unit Test Case Generator

Use the `ais-unit-test-cases` skill after code generation (Phase 2). First review and approve the
coverage intake questionnaire before CSV generation. After reviewing the CSV, approve the separate
ADO-readiness questionnaire before any shared ADO Test Plan/Suite/Case write.

Interface ID: $ARGUMENTS

---

## If a TSD exists, its §5.x.10.2 scenarios are the mandatory baseline

Do not re-derive categories from scratch when a TSD exists — every TSD test scenario becomes at
least one CSV row, enriched with detail from the real generated code (retry constants, actual
error codes, real class/method names) and the codegen-readiness questionnaire's TIBCO
cross-check, if one ran. Only add genuinely new cases for gaps the TSD didn't cover. The
categories/minimums below are the floor for interfaces with **no** TSD scenarios to start from,
not a target to cap at.

## What to provide

- Interface name and brief description
- The TSD's own §5.x.10.2 scenarios (if a TSD exists) — the baseline, not optional context
- The actual generated code, in the real repo clone + branch from `ais-codegen-readiness`
- Trigger type (HTTP / Service Bus / Timer / Blob)
- Input payload sample or schema
- Key transformation rules (sort keys, deduplication, null handling)
- Target system and expected output shape

---

## What this produces

- `outputs/<InterfaceID>/unit-test-generation-intake-questionnaire.md` — ⛔ stops here for
  explicit approval before the CSV is created
- `outputs/<InterfaceID>/unit-test-cases.csv` — generated only after the first approval
- `outputs/<InterfaceID>/unit-test-readiness-questionnaire.md` — ⛔ a separate approval stop
  before any shared ADO write

Covers all four test categories (floor, not a cap, when no TSD scenarios exist to start from):

| Category | Min Cases |
|---|---|
| Happy Path | 3–5 |
| Error Path | 3–5 |
| Boundary | 2–3 |
| Business Logic | 2–4 |

---

## CSV columns

```
TestCaseID, InterfaceID, InterfaceName, Category, ScenarioName,
InputDescription, ExpectedOutput, ValidationPoints, Priority, Status, Notes
```

---

## After you approve: real ADO Test Plan Integration

Creates **one flat suite** `UT_EAII-<number> - <InterfaceName>` (no sub-suites per category)
inside the existing shared Test Plan **"AIS Migration" → "Phase 2" → "Unit Testing"** — never a
new Test Plan per interface. One Test Case per CSV row, with a real `Microsoft.VSTS.TCM.Steps`
(action/expected-result) structure, not one combined description. Result IDs are written to
`outputs/<InterfaceID>/ado-test-case-creation-result.json` for `ais-test-results-to-ado` to
read later.

> Every generated interface **must** have a test case CSV, and its questionnaire approved,
> before raising a PR.
