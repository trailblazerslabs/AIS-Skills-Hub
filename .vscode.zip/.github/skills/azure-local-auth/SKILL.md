---
name: azure-local-auth
description: |
  Metcash AIS local Azure authentication guide. USE FOR: connecting GitHub Copilot agent
  and MCP servers (Azure SQL, Azure MCP) to Azure resources without interactive MFA on
  every session. Covers VS Code Azure Account extension sign-in, Azure SQL DB via
  Invoke-Sqlcmd with AccessToken, and Azure Storage via az CLI auth-mode login.
  DO NOT USE FOR: production deployments, CI/CD pipelines, or service principal provisioning.
  Triggers: "how to login to azure", "azure auth", "connect to azure", "azure account",
  "mcp azure login", "azure mfa", "azure sign in", "local azure auth", "connect to sql",
  "connect to storage", "list blobs", "query sql db".
---

# Azure Local Authentication for AIS Development

## Azure DevOps uses SEPARATE auth from Azure resources — do not conflate them

**`az login --tenant metcash.onmicrosoft.com` only covers Azure Resource Manager calls**
(Azure CLI resource commands, the Azure SQL/Storage sections below, `azure-sql-b2b-ut1` MCP).
It does **not** determine which Azure DevOps organization `az repos`/`az boards`/`az rest`
(against `dev.azure.com`) or `git clone`/`git pull` against an ADO remote will authenticate as.

This machine may have cached credentials for other Azure DevOps organizations from unrelated
work (confirmed via `cmdkey /list`, which shows separately cached Git Credential Manager entries
per org). Each org's credential is cached independently by GCM the first time you clone/push
against it —
switching the active `az login` tenant does **not** switch which ADO org credential is used.

**Before doing any ADO work, confirm the right org's credential is actually cached:**
```powershell
cmdkey /list | Select-String "dev.azure.com/METCASHDevOps"
```
If it's missing, the first `git clone`/`az repos list` call against `METCASHDevOps` will prompt
an interactive browser sign-in (via GCM) — let it complete once; it's cached from then on and
is independent of the `az login` tenant used for Azure resources.

`az repos`/`az boards`/`az rest` against `dev.azure.com` were confirmed in practice to work
using the current `az login` AAD session's token (via `az account get-access-token --resource
499b84ac-1321-427f-aa17-267ca6975798`) — so CLI/REST calls *do* follow the active az login,
while plain `git clone`/`git pull` over HTTPS follows GCM's own separately-cached per-org
credential. Don't assume one implies the other is also correctly scoped.

### The `azure-devops-mcp-metcash` MCP server has the same dependency, and hides its failure

Confirmed 2026-09-19: this MCP server (and likely `github` and any other stdio server that
authenticates via the local Azure CLI credential) authenticates using whatever AAD tenant
`az login` currently holds. If that's the wrong tenant (e.g. still on a personal/other-client
subscription from earlier work), the server **still reports "✔ Connected" in `claude mcp
list`** — that only proves the stdio transport/handshake succeeded — but it exposes **zero
tools** to `ToolSearch`, because it can't get a Metcash-scoped ADO token to enumerate anything.
This looks exactly like a tool-indexing bug and wastes a lot of time if misdiagnosed as one.

**Diagnostic order, cheapest first:**
1. `az account show` — is the signed-in user on `metcash.onmicrosoft.com` (a `*.metcash.com`
   user)? If not, that's the whole problem — restarting Claude Code or the MCP server will not
   fix it.
2. Fix it: `az login --tenant metcash.onmicrosoft.com` (browser MFA — the user has to do this
   step interactively; a plain assistant/CLI session cannot complete it).
3. Re-check `ToolSearch` for the server's tools once. If they still don't appear despite the
   correct tenant now being active, stop investigating and use the REST fallback below instead
   of retrying — this is a separate, currently-unexplained tool-indexing issue.

**REST fallback that needs no PAT** — reuses the same `az login` session, scoped to Azure
DevOps's own resource ID:
```powershell
$token = az account get-access-token --resource "499b84ac-1321-427f-aa17-267ca6975798" --query accessToken -o tsv
$headers = @{ Authorization = "Bearer $token" }
# use $headers for Invoke-RestMethod calls against https://dev.azure.com/METCASHDevOps/... _apis/...
# then: $token = $null   — never write a raw token to a file
```
Don't assume an existing PAT-shaped env var (e.g. `AZDO_PAT`) is valid for `METCASHDevOps`
without testing it against a real read call first — one found in this environment returned 401
(it was scoped to something unrelated). See `ais-unit-test-cases` and `ais-test-results-to-ado`
for this pattern applied end-to-end (suite/test-case creation, test run creation).

## ⛔ Metcash tenant only (rule 2026-10-04)

Work for this repo uses **only** the Metcash tenant `4e8bf66f-8b02-4b25-9c5a-8ae5ba17b931` (`sathyja@metcash.com`). No other
tenant or account may stay signed in to the Azure CLI. At the start of any session and before any Azure / MCP / ADO work:

```powershell
az account list --all --query "[?tenantId!='4e8bf66f-8b02-4b25-9c5a-8ae5ba17b931'].{user:user.name,tenant:tenantId}" -o tsv
```

If that prints anything, run `az logout --username <user>` for each user listed, then
`az account set --subscription COREIT-SERVICES-AIS-NPR` and confirm `az account show` shows the Metcash tenant. If no Metcash
account is signed in, stop and ask the user to run `az login --tenant 4e8bf66f-8b02-4b25-9c5a-8ae5ba17b931` themselves (MFA);
never sign in to another tenant to "make it work". Signing out is local and reversible; the VS Code Azure Account extension
and MCP servers hold their own sessions, so check **Azure: Sign Out** there too.

## ⛔ Mandatory Pre-Flight Check — required before generating a TSD, generating code, or generating unit test cases

`metcash-tsd-generator`, `ais-codegen-readiness` (and the `ais-*-codegen` skills it gates), and
`ais-unit-test-cases` all point here as a **hard pre-condition** — do not start generating any of
those three deliverables until both are confirmed working. This is a governance gate, not an
optimization: work items, PRs, and test suites all live in ADO, and the TIBCO source cross-check
(where applicable) lives in GitHub, so both must actually be reachable before real generated
output can be trusted.

1. **Azure DevOps MCP (`azure-devops-mcp-metcash`)** — confirm it's Connected AND exposes tools
   via `ToolSearch`. If Connected but zero tools appear, this is almost always the tenant
   mismatch above — run the diagnostic order (steps 1–3) before assuming anything else is wrong.
   If tools still don't appear after the correct tenant is confirmed active, fall back to the
   REST pattern above rather than blocking — the REST fallback counts as "verified working."
2. **GitHub MCP (`github`)** — confirm it's Connected AND exposes tools via `ToolSearch`. Same
   tenant-mismatch failure mode applies (it authenticates off the same local credential state).
   If it's not usable and no fallback exists for the specific read needed (e.g. the TIBCO source
   cross-check in `ais-codegen-readiness` Step 4), **stop and say so explicitly** — do not
   silently skip a TIBCO cross-check because GitHub MCP is unavailable.
3. Only once both are confirmed (via MCP tools directly, or the ADO REST fallback for #1) may
   the calling skill proceed past its own Step 0 / mandatory pre-condition check.

## Method: VS Code Azure Account Extension (Recommended)

This is the preferred method for local development. MFA is completed **once** in the
browser and the token is reused silently by all Azure MCP servers and the Azure SDK
(`DefaultAzureCredential`) for the duration of the VS Code session.

### Steps

1. **Install the extension** (already installed in this workspace):
   - Extension ID: `ms-vscode.azure-account`

2. **Sign in**:
   - Press `Ctrl+Shift+P` → type **Azure: Sign In**
   - A browser window opens — complete MFA with `m-sathyja@metcash.onmicrosoft.com`
   - Select tenant: **metcash.onmicrosoft.com**

3. **Restart Azure MCP servers** after sign-in:
   - Press `Ctrl+Shift+P` → **MCP: List Servers**
   - Select each Azure MCP server → **Restart**

---

## Assigning Managed Identities to Resources

When generating Logic App, Function App, or ADF code, always use **user-assigned managed identities** — the specific identity names and resource group will be provided at code generation time.

```json
"identity": {
  "type": "UserAssigned",
  "userAssignedIdentities": {
    "/subscriptions/<subscription-id>/resourceGroups/<resource-group>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<identity-name-kv>": {},
    "/subscriptions/<subscription-id>/resourceGroups/<resource-group>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/<identity-name-sta>": {}
  }
}
```

**Never use connection strings or access keys** — all access must go through managed identity.

---

## Alternative Auth Methods (if Azure Account extension is unavailable)

### Azure CLI (browser-based — MFA once per session)

> **Do NOT use `--use-device-code`** — device code login is blocked by Metcash conditional access policies.

```powershell
# Standard browser login (opens browser automatically)
az login --tenant metcash.onmicrosoft.com
```

After login, set the correct subscription:
```powershell
az account set --subscription <subscription-id>
```

---

## Azure SQL MCP Server (`azure-sql-b2b-ut1`)

The SQL MCP server requires a **separate token scope** for `https://database.windows.net/`.
The standard `az login` does **not** pre-cache this scope — you must request it explicitly.

### Login steps (run in this order before starting the SQL MCP server)

```powershell
# Step 1 — browser login (do NOT use --use-device-code)
az login --tenant metcash.onmicrosoft.com

# Step 2 — set the UT1 subscription
az account set --subscription 77ac2e54-5ee2-45dd-9954-9343e56840e9

# Step 3 — pre-cache the SQL token (browser popup — do NOT use device code)
az login --scope "https://database.windows.net//.default" --tenant metcash.onmicrosoft.com

# Step 4 — verify token is cached
az account get-access-token --resource "https://database.windows.net/" --query accessToken -o tsv
```

> Step 3 opens a browser window. Complete MFA there. Once the token is cached Step 4 will return a JWT string (long token, not an error).

### Then restart the MCP server

Press `Ctrl+Shift+P` → **MCP: List Servers** → select `azure-sql-b2b-ut1` → **Restart**

---

### Querying SQL directly from PowerShell (without MCP)

Use `Invoke-Sqlcmd` with `-AccessToken` — this passes the cached az CLI token directly and **does not trigger a second MFA prompt**.

```powershell
# Check first: Get-Module -ListAvailable -Name SqlServer
# If not already installed, STOP and confirm with the user before running the install below —
# do not install it unprompted.
Install-Module -Name SqlServer -Force -AllowClobber -Scope CurrentUser

# Query
Import-Module SqlServer
$token = az account get-access-token --resource "https://database.windows.net/" --query accessToken -o tsv
Invoke-Sqlcmd -ServerInstance "t3-met-b2b-ut1-ae-sql.database.windows.net" `
              -Database "b2b-integration-ut1-sqldb" `
              -AccessToken $token `
              -Query "SELECT TOP 10 TABLE_NAME FROM INFORMATION_SCHEMA.TABLES ORDER BY TABLE_NAME"
```

> **Do NOT use `sqlcmd -G`** — it triggers `ActiveDirectoryInteractive` which opens its own separate MFA browser popup and does not reuse the cached az CLI token.

#### Important: avoid JSON truncation

`Invoke-Sqlcmd` truncates string columns at 4000 chars by default. Always add `-MaxCharLength` when reading large JSON payloads:

```powershell
Invoke-Sqlcmd ... -MaxCharLength 2000000 -Query "SELECT JSONPayload FROM ..."
```

---

## Azure Storage Account — az CLI (`--auth-mode login`)

No extra token scope needed. The standard `az login` token is sufficient.
The `--auth-mode login` flag tells the CLI to use your Azure AD identity instead of a storage key.

### Known Storage Accounts

| Environment | Subscription | Storage Account | Resource Group |
|---|---|---|---|
| PRD | `6cf73e4a-a0ad-47ec-8dc0-9ccb87d6a5ee` (COREIT-SERVICES-AIS-PRD) | `t3productinfoprdaesta01` | `t3-met-ais-prd-ae1-rsg-b2b` |
| UT1 | `77ac2e54-5ee2-45dd-9954-9343e56840e9` (COREIT-SERVICES-AIS-UT1) | `t3productinfout1aesta01` | `t3-met-ais-ut1-ae1-rsg-b2b` |

### Connect and list containers

```powershell
# Set subscription (use PRD or UT1 sub ID from table above)
az account set --subscription 6cf73e4a-a0ad-47ec-8dc0-9ccb87d6a5ee

# List containers
az storage container list --account-name t3productinfoprdaesta01 --auth-mode login -o table

# List blobs in a container
az storage blob list --account-name t3productinfoprdaesta01 --container-name smartmedia --auth-mode login --query "[].{name:name, size:properties.contentLength, modified:properties.lastModified}" -o table

# Download a blob
az storage blob download --account-name t3productinfoprdaesta01 --container-name smartmedia --name "<blob-path>" --file "C:\Temp\output.json" --auth-mode login

# Upload a blob
az storage blob upload --account-name t3productinfoprdaesta01 --container-name smartmedia --name "<blob-path>" --file "C:\Temp\input.json" --auth-mode login --overwrite
```

### Known containers

| Storage Account | Container | Purpose |
|---|---|---|
| `t3productinfoprdaesta01` | `smartmedia` | SmartMedia product JSON payloads (PRD) |
| `t3productinfoprdaesta01` | `cloudinary` | Cloudinary processed records (PRD) |
| `t3productinfout1aesta01` | `smartmedia` | SmartMedia product JSON payloads (UT1) |
| `t3productinfout1aesta01` | `cloudinary` | Cloudinary processed records (UT1) |

### SQL server details

| Key | Value |
|---|---|
| Server | `t3-met-b2b-ut1-ae-sql.database.windows.net` |
| Database | `b2b-integration-ut1-sqldb` |
| Subscription | `77ac2e54-5ee2-45dd-9954-9343e56840e9` (COREIT-SERVICES-AIS-UT1) |
| Auth user | `m-sathyja@metcash.onmicrosoft.com` |

---

### Azure Developer CLI
```powershell
azd auth login --tenant-id metcash.onmicrosoft.com
```

### Service Principal via `.env` (no MFA — requires App Registration from Azure admin)
Create a `.env` file in the workspace root (add to `.gitignore`):
```
AZURE_TENANT_ID=metcash.onmicrosoft.com
AZURE_CLIENT_ID=<app-registration-client-id>
AZURE_CLIENT_SECRET=<client-secret>
```
Then reference in `.vscode/mcp.json` server config:
```json
"envFile": "${workspaceFolder}/.env"
```
