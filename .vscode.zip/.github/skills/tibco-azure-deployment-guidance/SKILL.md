---
name: tibco-azure-deployment-guidance
description: >
  Use this skill after TIBCO-to-Azure code generation when the user needs deployment planning,
  packaging guidance, resource group selection, pipeline alignment, or Azure environment placement
  for the generated workspace. Do not use it for architecture recommendation or code generation.
---

# TIBCO Azure Deployment Guidance

This skill is a post-generation flow. It must not generate conversion code and it must not be used
to decide the initial architecture.

## Purpose

- validate that the generated workspace is ready for deployment planning
- determine the correct Azure environment placement and packaging approach
- align pipeline and resource naming guidance with the chosen Azure target

## Required inputs

Collect these before giving deployment guidance:

| Input | Mandatory | Notes |
|---|---|---|
| Generated overlay location | Yes | The real repo clone + branch `tibco-azure-converter` wrote into (`C:\Users\<you>\source\repos\<RepoName>`, `feature/EAII-<number>-<description>`) — read `outputs/<InterfaceID>/OVERLAY.md` first to find it, don't assume the code itself is in `outputs/` |
| Approved architecture summary | Yes | Output from the NFR skill |
| Target Azure environment | Yes | Example: DEV, SIT, UAT, PRD |
| Resource group or platform convention | Yes | Use the current team convention, do not guess |
| Subscription or tenant constraints | Optional | If needed for deployment packaging |
| Pipeline reference files | Optional | Use existing pipeline files if they exist in the reference workspace |

Before producing guidance, read the generated overlay, approved NFR decision, and available
pipeline/resource evidence. For any required environment, resource-group, packaging, or promotion
fact that remains missing or conflicting, use `vscode_askQuestions` inline with the proposed answer,
evidence/source and impact; allow confirm, correct, or unknown/keep blocked. Do not re-ask facts
already established by the overlay or approved NFR. Record confirmed answers and provenance in the
guidance. If a required fact remains unknown, stop and identify the blocker instead of guessing.

## Workflow

1. Read the generated overlay in the real repo clone (per `OVERLAY.md`) and confirm it matches
   the approved architecture.
2. Read any existing pipeline YAMLs or deployment manifests from the reference workspace.
3. Identify the correct deployment unit, resource group convention, package naming, and required
   placeholders.
4. Return deployment guidance without changing architecture decisions.

## Guardrails

- Do not generate conversion code in this skill.
- Do not revisit architecture choice unless the generated output clearly conflicts with the approved
  NFR decision.
- If deployment planning exposes an architecture mismatch, send the work back to the NFR or code
  generation step instead of patching around it.

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `mcp_azure_devops2_repo_get_file_content` | ADO MCP | Read existing pipeline YAML templates from reference workspace |
| `mcp_azure_devops2_pipelines_get_build_definitions` | ADO MCP | List existing pipeline definitions for the target repo |
| `com.atlassian/atlassian-mcp-server-metcash` | Atlassian MCP | Link to or create deployment runsheet in Confluence |
| `memory` | Retrieve entity | Load NFR recommendation summary stored by `tibco-azure-nfr-recommendation` |

> After generating deployment guidance, pass the runsheet structure to `ais-deployment-runbook`
> to create the Confluence deployment page via Atlassian MCP.