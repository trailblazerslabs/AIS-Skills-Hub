---
name: azure-devops-work-items
description: |
  Squad 20 Azure DevOps work item, board, and pipeline conventions. USE FOR: the EAII ID
  format and usage, work item types (Epic/Feature/Story/Task/Bug), repository naming,
  branching, variable group naming, service connection naming, build naming, agent pools,
  shared pipeline template references, and SonarQube integration. This is a "way of working"
  skill — day-to-day backlog and pipeline conventions, not code generation.
  DO NOT USE FOR: creating branches or PRs (use azure-devops-repository-pr), generating
  Logic App, Function App, or ADF code (use the ais-*-codegen skills).
  Triggers: "work item", "EAII", "variable group", "service connection", "agent pool",
  "ado pipeline", "sonarqube", "create a task", "create a bug", "ado work item".
---

# Azure DevOps Work Items and Boards Skill — Squad 20

> Status: Observed — derived from repository naming, workflow folder names, and Azure DevOps project structure in METCASHDevOps/Squad 20.

---

## Interface ID Format

```
EAII-{number}
```

| Component | Value |
|---|---|
| Prefix | `EAII` (Enterprise AIS Interface ID) |
| Number | Sequential integer (e.g., `107`, `254`, `432`) |

**Rule:** Every integration interface must have an EAII ID before implementation begins. The EAII ID is the canonical reference for:
- Logic App workflow folder names (`EAII-432-consentsubscriber-braze-tt`)
- Parameters (`paramPIMToPEProductChangesInterfaceId: "EAII-254"`)
- APIM named values (`b2c-store-inventory-bulk-delete-interfaceid`)
- SMC observability logging
- ADO work items and test plans

---

## ADO Project

| Setting | Value |
|---|---|
| Organisation | `METCASHDevOps` |
| Project | `Squad 20` |
| URL | `https://dev.azure.com/METCASHDevOps/Squad%2020/` |

---

## Repository Naming Convention

```
Metcash.AIS.{Platform}.{Service}
```

| Platform | Examples |
|---|---|
| `B2B` | `Metcash.AIS.B2B.Cloudinary`, `Metcash.AIS.B2B.Datafactory` |
| `B2C` | `Metcash.AIS.B2C.Delivery`, `Metcash.AIS.B2C.Pricing` |
| `Enabling` | `Metcash.AIS.Enabling.Notifications`, `Metcash.AIS.Enabling.R2W` |
| `Corp` | `Metcash.AIS.Corp.Giftcard`, `Metcash.AIS.Corp.RPA.DocMgmt` |
| `RMN` | `Metcash.AIS.RMN`, `Metcash.AIS.RMN.01.Datafactory` |
| `ALMNZ` | `Metcash.AIS.ALMNZ.Consignments`, `Metcash.AIS.ALMNZ.WMS` |
| `Data` | `Metcash.AIS.Data.Metproducts` |
| `Shared` | `Metcash.AIS.Shared.Copilot`, `Metcash.AIS.DevOps` |

---

## Branching Conventions

| Branch | Purpose |
|---|---|
| `main` | Default branch — production-ready or latest trunk |
| `release_{yyyyMMdd}` | Release cut branches (e.g., `release_200617`) |
| `feature/{description}` | Feature work branches (e.g., `feature/pim-to-pe-ai-code`) |
| `develop` | **[Inferred]** Integration branch (not confirmed in all repos) |

**Observed:** `main`, `release_200617`, `feature/pim-to-pe-ai-code` in `Metcash.AIS.Data.Metproducts`.
See `azure-devops-repository-pr` for the full branch/PR skill.

---

## Work Item Types

Standard Azure Boards work item types (ADO default):
- **Epic** — Large cross-sprint initiatives (e.g., TIBCO → Azure migration)
- **Feature** — Delivery scope for an interface or capability
- **User Story** — Individual deliverable (one interface = one story, typically)
- **Task** — Sub-work within a story
- **Bug** — Defects and test failures

---

## Variable Groups (Pipelines)

```
t3-ais_{interface}_{env}
```

**Example:** `t3-ais_pim2pe_dev`

Variable groups hold environment-specific secrets and configuration values. Access via:
```yaml
variables:
  - group: t3-ais_{interface}_{env}
```

---

## Service Connections (SPN)

```
SPN-t3-met-ais-{env}
```

**Examples:** `SPN-t3-met-ais-dev`, `SPN-t3-met-ais-prd`

Used in pipeline service connections for Azure resource deployments.

---

## Build Naming

```
$(Build.DefinitionName)_$(Build.SourceBranchName)_RunID$(Build.BuildId)_Date$(Year:yyyy).$(Month).$(DayOfMonth)$(Rev:.rr)
```

Set in pipeline YAML as `name:` at the pipeline root.

---

## Agent Pools

| Pool | Environment |
|---|---|
| `Metcash-ALZ-VMSS-Windows-NON-PROD` | dev, sit, uat, ppd |
| **[Inferred]** `Metcash-ALZ-VMSS-Windows-PROD` | prd |

---

## Shared Pipeline Templates Repository

Shared CI/CD templates live in `Metcash.AIS.DevOps`. Reference them from interface-specific pipelines:

```yaml
resources:
  repositories:
    - repository: Metcash.AIS.DevOps
      type: git
      name: Squad 20/Metcash.AIS.DevOps
      ref: refs/heads/main
```

Templates available:
- `pipelines/templates/logicapp-ci-template.yml`
- `pipelines/templates/logicapp-pr-template.yml`
- `pipelines/templates/logicapp-ci-sonarqube-template.yml`
- `pipelines/templates/logicapp-pr-sonarqube-template.yml`
- `pipelines/templates/logicapp_build_template.yml`
- `pipelines/templates/functionapp_build_template.yml`
- `pipelines/templates/v2/` (newer versions of above)

---

## SonarQube Integration

CI and PR pipelines include SonarQube analysis via:
- `logicapp-ci-sonarqube-template.yml`
- `logicapp-pr-sonarqube-template.yml`

Do not skip SonarQube in CI pipelines.

---

## Creating a New Work Item (Guidelines)

When creating a new interface work item:

1. Link to the parent Feature/Epic.
2. Include the EAII ID in the title or custom field.
3. Reference the target repository in description.
4. Include acceptance criteria referencing DEV/SIT/UAT environments.
5. Link pipeline runs as build artifacts when available.

Tools: `mcp_azure_devops2_wit_create_work_item`, `mcp_azure_devops2_wit_add_child_work_items`
(to link to parent), `mcp_azure_devops2_wit_add_work_item_comment` (status updates),
`mcp_azure_devops2_search_workitem` (find existing items by EAII ID or text before creating one).

---

## Observed Evidence

| Repository | File Path | Pattern Observed |
|---|---|---|
| `Metcash.AIS.RMN` | `/logic-app/.../EAII-432-consentsubscriber-braze-tt/` | EAII ID in workflow folder names |
| `Metcash.AIS.Data.Metproducts` | `/LogicApp/Parameters/parameters.dev.json` | EAII ID in parameters (`EAII-254`) |
| `Metcash.AIS.Data.Metproducts` | `/pipelines/pim2peLA.yml` | Variable group naming |
| `Metcash.AIS.DevOps` | `/pipelines/templates/` | Shared template catalog |
| `Metcash.AIS.B2B.Datafactory` | `/factory/t3-met-ais-dev-ae-adf-01.json` | Repository naming convention |

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `microsoft/azure-devops-mcp-metcash` | `wit_get_work_item` | Read a work item by ID |
| `microsoft/azure-devops-mcp-metcash` | `search_workitem` | Search work items by EAII ID or text |
| `microsoft/azure-devops-mcp-metcash` | `wit_create_work_item` | Create Epic/Feature/Story/Task/Bug |
| `microsoft/azure-devops-mcp-metcash` | `wit_update_work_item` | Update a field or status |
| `microsoft/azure-devops-mcp-metcash` | `wit_add_work_item_comment` | Post a status update comment |
| `microsoft/azure-devops-mcp-metcash` | `wit_add_child_work_items` | Link parent/child work items |
| `memory` | Retrieve entity | Load EAII ID and interface metadata from session |
