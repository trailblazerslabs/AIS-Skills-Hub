#!/usr/bin/env python3
"""Lint a generated Function App repo against the Squad 20 PRODUCTION pattern (.NET isolated worker).

Calibrated on the `main` branch (the only branch the PRD pipeline stage deploys from) of
Metcash.AIS.Data.Metproducts (2026-09-09) and Metcash.AIS.Data.MDMSupplierInfo (2026-09-22): both must pass with
0 errors. Metcash.AIS.B2B.Cloudinary (2026-07-16) is the older style (net8, different composition) and is expected
to raise findings: new code follows the Metproducts / MDMSupplierInfo shape. See code-corpus/production-snapshot.md.

Usage:
    python check_functionapp.py <repo clone dir> [--name Metcash.AIS.Data.Foo] [--strict]

Static checks only (file layout, csproj, Program.cs composition, function/service shape, settings, pipeline). It does
not compile; run `dotnet build` and the test project as well.
Exit code 1 on any error (or any warning with --strict).
"""
import argparse
import json
import re
import sys
from pathlib import Path

PKGS = ["Microsoft.Azure.Functions.Worker", "Microsoft.Azure.Functions.Worker.Sdk",
        "Microsoft.Azure.Functions.Extensions.ServiceBus".replace("Functions.Extensions", "Functions.Worker.Extensions"),
        "Microsoft.ApplicationInsights.WorkerService", "Azure.Identity"]
TRIGGERS = ("ServiceBusTrigger", "BlobTrigger", "HttpTrigger", "TimerTrigger", "QueueTrigger")
SECRET_RE = re.compile(r"(AccountKey=|SharedAccessKey=|;Password=|password\s*=\s*\"[^\"]+\"|client_?secret\s*=\s*\"[^\"]+\")", re.I)


def read(p):
    return Path(p).read_text(encoding="utf-8-sig", errors="replace")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("repo")
    ap.add_argument("--name")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    root = Path(a.repo)
    out = []

    def add(level, rule, where, msg):
        out.append((level, rule, where, msg))

    fa = root / "FunctionApp"
    if not fa.is_dir():
        add("error", "FN-01", "FunctionApp", "no FunctionApp/ folder")
        return finish(out, a)
    hosts = [p for p in fa.iterdir() if p.is_dir() and not p.name.endswith(".Common") and (p / "Program.cs").exists()]
    if not hosts:
        add("error", "FN-01", "FunctionApp", "no host project with Program.cs under FunctionApp/")
        return finish(out, a)
    host = next((h for h in hosts if a.name and h.name == a.name), hosts[0])
    name = host.name
    common = fa / f"{name}.Common"
    tests = root / "Tests" / f"{name}.Tests"
    hp = host.name

    # ---- FN-01 layout
    for rel, desc in ((f"FunctionApp/{name}/Program.cs", "Program.cs"), (f"FunctionApp/{name}/host.json", "host.json"),
                      (f"FunctionApp/{name}/{name}.csproj", "host csproj"), (f"FunctionApp/{name}.Common/{name}.Common.csproj", "Common csproj"),
                      (f"FunctionApp/{name}.Common/Configuration/AppSettings.cs", "strongly-typed AppSettings"),
                      (f"FunctionApp/{name}.sln", "solution")):
        if not (root / rel).exists():
            add("error", "FN-01", rel, f"missing {desc} (3-project layout: host, .Common, .Tests)")
    if not (common / "Services" / "Interfaces").is_dir():
        add("error", "FN-01", f"{name}.Common", "missing Services/Interfaces (every service has an interface)")
    if not (common / "Models" / "Smc").is_dir():
        add("warning", "FN-01", f"{name}.Common", "no Models/Smc (SMC observation models)")
    if not tests.is_dir():
        add("error", "FN-01", "Tests", f"missing Tests/{name}.Tests")

    # ---- FN-02 csproj
    cs = host / f"{name}.csproj"
    if cs.exists():
        t = read(cs)
        fw = re.search(r"<TargetFramework>([^<]+)", t)
        if not fw or fw.group(1) != "net10.0":
            add("error", "FN-02", cs.name, f"TargetFramework must be net10.0 (production Function Apps), found {fw.group(1) if fw else 'none'}")
        if "<OutputType>Exe</OutputType>" not in t or "<AzureFunctionsVersion>v4" not in t:
            add("error", "FN-02", cs.name, "isolated worker needs OutputType Exe and AzureFunctionsVersion v4")
        for p in PKGS:
            if p not in t:
                add("error", "FN-02", cs.name, f"missing package reference {p}")

    # ---- FN-03 Program.cs composition
    prog = host / "Program.cs"
    if prog.exists():
        t = read(prog)
        for pat, msg in ((r"ConfigureFunctionsWorkerDefaults", "ConfigureFunctionsWorkerDefaults()"),
                         (r"Configure<AppSettings>", "services.Configure<AppSettings>(...) with the flat / Values: fallback"),
                         (r"AddApplicationInsightsTelemetryWorkerService", "AddApplicationInsightsTelemetryWorkerService()"),
                         (r"DefaultAzureCredential", "DefaultAzureCredential (managed identity) for Azure SDK clients"),
                         (r"IServiceBusFunctionExecutor", "IServiceBusFunctionExecutor registration (cross-cutting executor)"),
                         (r"ISmcService", "ISmcService registration")):
            if not re.search(pat, t):
                add("error", "FN-03", "Program.cs", f"missing {msg}")
        if SECRET_RE.search(t):
            add("error", "FN-03", "Program.cs", "secret literal in Program.cs; use Key Vault references in app settings")
        if re.search(r"new HttpClient\(", t):
            add("error", "FN-03", "Program.cs", "use AddHttpClient<T>() instead of new HttpClient()")

    # ---- FN-04 functions
    fdir = host / "Functions"
    fns = [p for p in fdir.glob("*.cs")] if fdir.is_dir() else []
    if not fns:
        add("error", "FN-04", "Functions", "no function classes under Functions/")
    sb_used = False
    for f in fns:
        t = read(f)
        if "[Function(" not in t:
            add("error", "FN-04", f.name, "no [Function(\"Name\")] attribute")
        if not any(tr in t for tr in TRIGGERS):
            add("error", "FN-04", f.name, "no recognised trigger attribute")
        if "ServiceBusTrigger" in t:
            sb_used = True
            if "IServiceBusFunctionExecutor" not in t or "ExecuteAsync" not in t:
                add("error", "FN-04", f.name, "Service Bus function must delegate to IServiceBusFunctionExecutor.ExecuteAsync (try/catch, SMC, settlement)")
            if "ServiceBusMessageActions" not in t:
                add("error", "FN-04", f.name, "Service Bus function must take ServiceBusMessageActions (explicit complete / dead-letter)")
            m = re.search(r'Connection\s*=\s*"([^"]+)"', t)
            if m and ("Endpoint=" in m.group(1) or "SharedAccess" in m.group(1)):
                add("error", "FN-04", f.name, "Service Bus Connection must be an app-setting prefix, not a connection string")
        if re.search(r"new HttpClient\(", t):
            add("error", "FN-04", f.name, "use an injected typed client, not new HttpClient()")
        if SECRET_RE.search(t):
            add("error", "FN-04", f.name, "secret literal")

    # ---- FN-10 / FN-11 / FN-12 Service Bus function conventions (identical in both production Function Apps)
    app_cs = common / "Configuration" / "AppSettings.cs"
    app_text = read(app_cs) if app_cs.exists() else ""
    env_vals = {}
    for env in ("dev", "sit", "uat", "prod", "prd"):
        pe = root / "pipelines" / "appsettings" / f"{env}.local.settings.json"
        if pe.exists():
            try:
                env_vals[env] = json.loads(read(pe)).get("Values", {})
            except Exception:  # noqa: BLE001
                pass
    for f in fns:
        t = read(f)
        if "ServiceBusTrigger" not in t:
            continue
        m = re.search(r"\[ServiceBusTrigger\((.*?)\)\]", t, re.S)
        args = m.group(1) if m else ""
        lits = re.findall(r'"([^"]*)"', args)
        names = [x for x in lits if x != "ServiceBusConnection"][:2]
        for x in names:
            if not re.fullmatch(r"%\w+%", x):
                add("error", "FN-10", f.name, f"topic / subscription / queue name `{x}` is a literal; use a %SettingName% placeholder resolved from app settings")
        if 'Connection = "ServiceBusConnection"' not in t and "Connection=\"ServiceBusConnection\"" not in t:
            add("error", "FN-10", f.name, 'Service Bus trigger must use Connection = "ServiceBusConnection" (identity-based connection prefix)')
        iid = re.search(r"settings\.Value\.(SmcInterfaceId\w+)", t)
        if not iid:
            add("error", "FN-10", f.name, "interface id must come from AppSettings.SmcInterfaceIdEAII<n> (settings.Value.SmcInterfaceIdEAII<n>), not a literal")
        elif not re.search(r"\b" + iid.group(1) + r"\b", app_text):
            add("error", "FN-12", f.name, f"AppSettings.cs has no property `{iid.group(1)}`")
        for ph in [x.strip("%") for x in names if re.fullmatch(r"%\w+%", x)]:
            if not re.search(r"\b" + ph + r"\b", app_text):
                add("error", "FN-11", f.name, f"placeholder %{ph}% has no matching property in AppSettings.cs")
            for env, vals in env_vals.items():
                if ph not in vals:
                    add("error", "FN-11", f"{env}.local.settings.json", f"placeholder %{ph}% (used by {f.stem}) is not defined for {env}")
        if not re.search(r"nameof\(" + re.escape(f.stem) + r"\)", t):
            add("warning", "FN-10", f.name, "pass nameof(<FunctionClass>) as the function name to ExecuteAsync (telemetry and SMC naming)")

    # ---- FN-05 services
    sdir = common / "Services"
    ifaces = {p.stem for p in (sdir / "Interfaces").glob("*.cs")} if (sdir / "Interfaces").is_dir() else set()
    for s in sdir.glob("*.cs") if sdir.is_dir() else []:
        t = read(s)
        if f"I{s.stem}" not in ifaces and not re.search(r"static class", t):
            add("error", "FN-05", s.name, f"no interface I{s.stem} in Services/Interfaces")
        if re.search(r"new HttpClient\(", t):
            add("error", "FN-05", s.name, "use an injected HttpClient / IHttpClientFactory")
        if SECRET_RE.search(t):
            add("error", "FN-05", s.name, "secret literal")
        for u in re.findall(r'"(https?://[^"{]+)"', t):
            # XML / XSLT namespace identifiers are not endpoints
            if any(h in u.lower() for h in ("schemas.", "w3.org", "xmlns", "microsoftonline", "management.azure", "tibco.com", "namespaces",
                                            "xslt", "custom-functions", ".xsd", "/schema", "stibosystems", "ibm.com/mdm", "/step", "metcash.com.au/")) or u.endswith("\\"):
                continue
            add("error", "FN-05", s.name, f"hard-coded URL `{u[:70]}`; read it from AppSettings")

    # ---- FN-06 settings
    for env in ("dev", "sit", "uat", "prod", "prd"):
        p = root / "pipelines" / "appsettings" / f"{env}.local.settings.json"
        if not p.exists():
            continue
        try:
            v = json.loads(read(p)).get("Values", {})
        except Exception as e:  # noqa: BLE001
            add("error", "FN-06", p.name, f"invalid JSON: {e}")
            continue
        if v.get("FUNCTIONS_WORKER_RUNTIME") not in (None, "dotnet-isolated"):
            add("error", "FN-06", p.name, "FUNCTIONS_WORKER_RUNTIME must be dotnet-isolated")
        for k, val in v.items():
            is_secret_key = re.search(r"(password|secret|connectionstring|accesskey|appkey|apikey|subscriptionkey|key$)", k, re.I)                 and not re.search(r"(url|uri|name|header|endpoint)$", k, re.I)
            sv = str(val).strip()
            if is_secret_key and sv and "@Microsoft.KeyVault(" not in sv and not re.fullmatch(r"[A-Za-z]+(-[A-Za-z]+)+", sv):
                add("error", "FN-06", p.name, f"`{k}` looks like a secret but is not a Key Vault reference (@Microsoft.KeyVault(VaultName=...;SecretName=...))")
        if env in ("prod", "prd"):
            for k, val in v.items():
                if re.search(r"(-dv1-|-st1-|-ut1-|\.dev\.|\.dv1\.)", str(val)):
                    add("error", "FN-06", p.name, f"prod setting `{k}` points at a non-prod resource")
    if not any((root / "pipelines" / "appsettings").glob("*.local.settings.json")):
        add("error", "FN-06", "pipelines/appsettings", "no <env>.local.settings.json files")

    # ---- FN-07 host.json
    hj = host / "host.json"
    if hj.exists() and sb_used:
        t = read(hj)
        v5 = re.search(r'"autoCompleteMessages"\s*:\s*false', t)
        v4 = re.search(r'"autoComplete"\s*:\s*false', t)
        if not v5 and not v4:
            add("error", "FN-07", "host.json", "Service Bus triggers must disable automatic completion (the executor settles messages): extensions.serviceBus.autoCompleteMessages=false")
        elif v4 and not v5:
            add("warning", "FN-07", "host.json", "messageHandlerOptions.autoComplete is the extension 4.x schema (ignored by 5.x); the 5.x key is extensions.serviceBus.autoCompleteMessages. Production still uses the 4.x key: raise it as a platform change, do not edit a shared host.json in an interface change")

    # ---- FN-08 tests
    if tests.is_dir():
        tcount = len(list(tests.rglob("*Tests.cs")))
        if tcount < 1:
            add("error", "FN-08", tests.name, "no *Tests.cs files")
        elif sdir.is_dir() and tcount < max(1, len([p for p in sdir.glob("*.cs")]) // 3):
            add("warning", "FN-08", tests.name, f"only {tcount} test files for {len(list(sdir.glob('*.cs')))} services")

    # ---- FN-08b test pairing (Metproducts convention: Functions/<Class>FunctionTests.cs and Services/<Class>ServiceTests.cs)
    if tests.is_dir():
        tnames = [p.name.lower() for p in tests.rglob("*Tests.cs")]
        for f in fns:
            if f.stem != "HealthCheck" and not any(f.stem.lower() in n for n in tnames):
                add("warning", "FN-08", tests.name, f"no test file for function {f.stem} (production Metproducts has <Function>FunctionTests.cs)")
        for sv in (sdir.glob("*Service.cs") if sdir.is_dir() else []):
            if sv.stem != "BlobService" and not any(sv.stem.lower() in n for n in tnames):
                add("warning", "FN-08", tests.name, f"no test file for service {sv.stem}")

    # ---- FN-09 pipeline
    pipes = list((root / "pipelines").glob("*fnapp.yml"))
    if not pipes:
        add("error", "FN-09", "pipelines", "no pipelines/<name>fnapp.yml")
    for p in pipes:
        t = read(p)
        if "refs/heads/main" not in t:
            add("error", "FN-09", p.name, "the PRD stage must be gated on refs/heads/main")
    return finish(out, a)


def finish(out, a):
    for lvl, rule, where, msg in out:
        print(f"{lvl.upper():7} {rule} [{where}] {msg}")
    errs = sum(1 for o in out if o[0] == "error")
    warns = sum(1 for o in out if o[0] == "warning")
    print(f"-- {errs} error(s), {warns} warning(s)")
    sys.exit(1 if errs or (a.strict and warns) else 0)


if __name__ == "__main__":
    main()
