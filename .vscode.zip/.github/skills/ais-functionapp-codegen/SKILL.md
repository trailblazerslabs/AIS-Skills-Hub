---
name: ais-functionapp-codegen
description: |
  Metcash AIS C# .NET 10 Function App transformation code generator. USE FOR: generating
  Service-Bus-triggered transformation functions following the real production 3-project split
  (host Function project + a .Common project + a Tests project), including sorting, grouping,
  aggregation, field mapping, and data enrichment logic. Reuses existing project files,
  namespaces, and shared types from the reference workspace. DO NOT USE FOR:
  Logic App workflow generation (use ais-logicapp-codegen), standalone Azure Function App
  projects, or architecture recommendation.
  Triggers: "generate function app", "create function", "transformation code", "C# function",
  "sorting function", "aggregation function", "data transformation", "local function code".
---

# AIS Function App Transformation Code Generator

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — check what's already generated before starting, update Phase 3's row
> on completion.

Generate C# .NET 10 Service-Bus-triggered transformation functions, following the real
production pattern confirmed across two independent repos (`Metcash.AIS.Data.Metproducts` and
`Metcash.AIS.Data.MDMSupplierInfo` — see
[`code-corpus/patterns/01-function-app-pattern.md`](../../../code-corpus/patterns/01-function-app-pattern.md)
for the full evidence). A new interface is an **additive overlay**: add new classes, never create a new `.csproj` or a second `AppSettings` class, and **extend the shared files additively without
changing the behaviour of any existing interface**, proving it with the baseline test count (all tests that passed before still pass). The known extension points are `AppSettings.cs`, `Program.cs`,
the four `pipelines/appsettings/<env>.local.settings.json` files, `SmcService` display names (`FunctionDisplayNames`), `ProcessingResult` (flags with a default that keeps today's behaviour), the
test `.csproj` fixture globs and the README. Anything else in `Common/` (the executor, existing services) needs an explicit reason in `assumptions.md` and a test that shows the old behaviour is unchanged.

---

## ⛔ Mandatory Pre-condition — Codegen Readiness

> An approved TSD whose repo, branch and resource names are resolved satisfies the readiness pre-condition when no `codegen-readiness-questionnaire.md` exists yet (EAII-529 was generated that way). Items the TSD or its gap register still marks open are **never invented**: see "Open items" in Step 4.

**Do not generate any code until the relevant pre-condition below is met** — which one depends
on whether this interface has a TSD:

| Interface has... | Required artifact | Check | Action if missing |
|---|---|---|---|
| A TSD (`tsd/<InterfaceID>/*.md` exists) | **Approved** `outputs/<InterfaceID>/codegen-readiness-questionnaire.md` | Found and marked approved | **Stop.** Ask the user to run `ais-codegen-readiness` and approve it first — repo and resource name must be resolved before any code is written, never guessed. |
| No TSD | **Approved** `outputs/<InterfaceID>/design-intake-questionnaire.md` | Found and marked approved | **Stop.** Ask the user to run `ais-design-intake` and approve it first — never proceed on an unapproved questionnaire. |

> Whichever artifact applies provides the field mappings, transformation requirements, repo, and
> resource name needed below — do not re-ask for information already captured in it.

### Inline Gap Resolution Before Generation

Review the approved questionnaire, TSD/design evidence, current repo and production reference
before asking anything. For each codegen-critical fact still missing, ambiguous or conflicting
(for example payload/schema, trigger/subscription, transformation rule or downstream behavior),
use `vscode_askQuestions` inline with a proposed answer, evidence/source and impact; allow confirm,
correct, or unknown/keep blocked. Do not ask again for established facts. Record answers and
provenance in the existing readiness/design-intake questionnaire and `assumptions.md`. If an
answer materially changes an approved questionnaire, stop and obtain explicit approval of the
revised questionnaire before writing code. If a critical answer remains unknown, stop generation.

---

## Required Inputs

> Sourced from the Design Intake Questionnaire. If any item is missing from the summary, ask only for that specific gap.

- Interface ID matching `EAII-{number}`
- The shared repo this interface belongs to (reuse an existing one whenever the FSD/TSD says
  this interface shares a workload with a sibling interface — see `azure-devops-repository-pr`
  for the repo-reuse convention). Real reference repos:
  `C:\Users\jagae\source\repos\Metcash.AIS.Data.Metproducts-main` and
  `C:\Users\jagae\source\repos\Metcash.AIS.Data.MDMSupplierInfo` (both confirmed `main`-branch
  production code)
- Input payload schema or sample XML/JSON, and the trigger (Service Bus topic/subscription name)
- Transformation requirements (sort keys, group-by fields, target schema)
- Downstream target: HTTP endpoint (with retry/non-retryable-status behavior) or another
  mechanism

Resolve any missing input using the inline gap process above; do not fill it by inference without
the user's confirmation.

## Workflow

### Step 1 — Read the production reference

The reference is **code live in production** (`main` of the Squad 20 repos; the PRD stage of every pipeline runs only from `refs/heads/main`):
`Metcash.AIS.Data.Metproducts` (EAII-254/282/283/284/385) and `Metcash.AIS.Data.MDMSupplierInfo` (EAII-301/302/516/517), both .NET 10 isolated worker with
identical composition. Do **not** copy `Metcash.AIS.B2B.Cloudinary` (older net8 style) or any `release/*` / `feature/*` branch. Inventory, SHAs and what is
not live: [`code-corpus/production-snapshot.md`](../../../code-corpus/production-snapshot.md); verified composition:
[`code-corpus/patterns/01-function-app-pattern.md`](../../../code-corpus/patterns/01-function-app-pattern.md) (update 2026-10-04). Run `git fetch` and
`git log origin/main -5` on the clone first; if `main` moved, read what changed.

Read the reference repo's `FunctionApp/` tree before generating any code. Derive:
- Root namespace (e.g., `Metcash.AIS.Data.Metproducts`)
- The existing `.csproj` files (host project + `.Common` project) — reuse them, never create new ones
- The existing `AppSettings` class shape — extend it, never create a second one
- The existing `IServiceBusFunctionExecutor` implementation — reuse it as-is, don't reimplement
  per interface
- Existing shared types (`ProcessingResult`, `LogMessage`) and utilities (`SmcDateFormatter`)

### Step 2 — Plan the Function

Determine, following the real 3-project split:
- Function class name: `<InterfaceName>` (e.g. `CorporateItemToSorted`) — thin, no logic
- Service interface + class: `I<InterfaceName>Service` / `<InterfaceName>Service` — all the
  business logic lives here, with signature
  `Task<ProcessingResult> ProcessAsync(string blobUrl, string correlationId, List<LogMessage> logMessages)`
- Whether a gating check is needed before calling the downstream system
  (`IXxxGatingService.IsAvailableAsync()` — see pattern doc) — if the downstream system can be
  known-unavailable, add one; return `ProcessingResult.Skipped(...)` rather than failing
- New `AppSettings` properties needed, added to the *existing* class under a
  `// EAII-{number} — <short name>` comment block, following the existing sectioning

### Step 3 — Generate Code

**Write into the real repo clone resolved by `ais-codegen-readiness`** — the local path and
feature branch recorded in the approved questionnaire's §1 (e.g.
`C:\Users\jagae\source\repos\<RepoName>`, branch `feature/EAII-<number>-<description>`) — never
into `outputs/<InterfaceID>/`. Leave the change as local, uncommitted edits on that branch; do
not commit or push (that's a separate, explicit step).

**File structure to produce, relative to the clone root (extends the existing repo, doesn't
create a new project):**

```
FunctionApp/<RepoName>/Functions/<InterfaceName>.cs                        ← Function entry point (thin)
FunctionApp/<RepoName>.Common/Services/I<InterfaceName>Service.cs          ← Service interface
FunctionApp/<RepoName>.Common/Services/<InterfaceName>Service.cs           ← Service implementation
Tests/<RepoName>.Tests/Functions/<InterfaceName>FunctionTests.cs           ← Function-level test
Tests/<RepoName>.Tests/Services/<InterfaceName>ServiceTests.cs             ← Service-level test
```

**Function entry point (thin — delegates everything to the shared executor):**

```csharp
using Metcash.AIS.Data.<RepoName>.Common.Configuration;
using Metcash.AIS.Data.<RepoName>.Common.Executor;
using Metcash.AIS.Data.<RepoName>.Common.Services.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Options;

namespace Metcash.AIS.Data.<RepoName>.Functions;

/// <summary>
/// EAII-{number} - <one-line business purpose>.
/// Trigger: Service Bus topic %{Name}TopicName% / %{Name}SubscriptionName%
/// </summary>
public class <InterfaceName>
{
    private readonly I<InterfaceName>Service _service;
    private readonly IServiceBusFunctionExecutor _executor;
    private readonly string _smcInterfaceId;

    public <InterfaceName>(
        I<InterfaceName>Service service,
        IServiceBusFunctionExecutor executor,
        IOptions<AppSettings> settings)
    {
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _executor = executor ?? throw new ArgumentNullException(nameof(executor));
        _smcInterfaceId = settings.Value.SmcInterfaceId{InterfaceEaiiNumber};
    }

    [Function("<InterfaceName>")]
    public Task RunAsync(
        [ServiceBusTrigger("%{Name}TopicName%", "%{Name}SubscriptionName%", Connection = "ServiceBusConnection")]
        ServiceBusReceivedMessage message,
        ServiceBusMessageActions actions,
        FunctionContext context)
        => _executor.ExecuteAsync(message, actions, context, _smcInterfaceId,
            nameof(<InterfaceName>), _service.ProcessAsync);
}
```

**Never** put try/catch, telemetry, SMC logging, or message completion/dead-lettering logic in
the Function class itself — `IServiceBusFunctionExecutor.ExecuteAsync` already does all of that
for every interface in the repo. Reuse the existing executor; do not write a new one.

**Service implementation — the real shape (see the pattern doc for the full annotated example):**

```csharp
public class <InterfaceName>Service : I<InterfaceName>Service
{
    // constructor takes: IBlobService, any gating/http services this interface needs,
    // the transform service, IOptions<AppSettings>, TelemetryClient, ILogger<T>

    public async Task<ProcessingResult> ProcessAsync(string blobUrl, string correlationId, List<LogMessage> logMessages)
    {
        // 1. Gating check first (if applicable) — return ProcessingResult.Skipped(...) and stop
        // 2. Download source payload from blob; append a LogMessage per stage (StageID "1.00", ...)
        // 3. Transform; on failure, log a LogMessage and rethrow (let the executor's catch handle it)
        // 4. Retry loop around the outbound call (MaxRetries = 3, RetryDelay = 2s):
        //    - HttpStatusCode.BadRequest (or other known non-retryable status) → return
        //      ProcessingResult.Failure(...) immediately, don't burn retries
        //    - other failure → log "Retrying" and loop
        //    - exhausted → ProcessingResult.Failure($"... failed after {MaxRetries} attempts...")
        // 5. Success path → ProcessingResult.Success(itemNumber, outputBlobUrl)
    }
}
```

`ProcessingResult` (already exists in `<RepoName>.Common/Models/`) is the shared result envelope
— `IsSuccess`, `Status` (`"Success"`/`"Skipped"`/`"Failed"`), `ItemNumber`, `OutputBlobUrl`,
`ErrorMessage`, `ErrorCode`, with static factories `.Success(...)`/`.Skipped(...)`/`.Failure(...)`.
**Do not invent a `TransformationOutput<T>` envelope** — that type does not exist in either real
repo; reuse `ProcessingResult`.

### Step 4 — Add DI Registration

Append to the *existing* `Program.cs` composition root (do not rewrite the whole file), grouped
under a comment for this interface, matching the existing sectioning exactly:

```csharp
// EAII-{number} — <short name>
services.AddScoped<I<InterfaceName>Service, <InterfaceName>Service>();
```

If this interface needs a new HTTP-calling dependency, register it as a typed client
(`services.AddHttpClient<TService>(...)`), not a bare injected `HttpClient`. Shared/infra
services (`SmcService`, `BlobService`, the executor) are already registered as singletons —
never re-register them.

### Step 3b — Service shapes beyond "one XML blob, one POST" (found generating EAII-529 from its TSD)

The default template (one XML blob, transform, one POST) covers the corporate-item and supplier interfaces. A **file-staged, multi-call** interface (EAII-529: flat PRD_JRN file in blob, six XML payloads, three
Stibo endpoints) needs these additions. Put helpers in sub-folders (`Services/<Interface>/`) or make them `static`; the checker expects an interface for every top-level `Services/*.cs`.

* **Outcome mapping (settlement).** Three outcomes, not two. Success or skip: complete. **Technical failure** (token, 401/403 after refresh, 5xx or timeout after retries, unexpected error): dead-letter, file stays in `in/`.
  **Data error** (invalid file, 400/422): SMC records Failed, the file moves to `error/`, and the message is **completed** because a replay can never succeed. Return `ProcessingResult.DataError(message, code)`:
  it sets `CompleteMessageOnFailure`, which the executor honours (default `false`, so every existing `Failure(...)` still dead-letters). If `DataError` is missing in the repo, add it (an approved extension point) and add
  the executor test shown in `Tests/.../Executor/ServiceBusFunctionExecutorEaii529Tests.cs`.
* **Exception codes.** The TSD's `EAIInnn-nnn` codes are the codes in `ProcessingResult` and SMC, including the catch-all (`-099`): catch unexpected exceptions in the service, `TrackException`, return `Failure("...", "EAIInnn-099")`.
  Do not rely on the executor's catch (it reports code `500` and raw exception text, which production deliberately keeps out of SMC).
* **File lifecycle.** A small blob service (`IBlobFileLifecycleService`): download with metadata (a 404 returns `null`), write metadata, move `in/` to `archive/` or `error/` with the managed identity. The event subscription must filter on `in/` so the moves
  never re-trigger. **Duplicate delivery** (blob no longer in `in/`): log a warning, complete the message, no downstream call.
* **Ordered multi-call delivery with resume.** Send in the TSD's order; after each call write the record type to the source blob's metadata; a replay skips the types already delivered and retries only what is left (including a failed archive move).
* **Tokens.** Do not reuse the shared singleton `TokenService` when the TSD says the token is per run: write a per-run token service (one request per file, refreshed only near expiry or once on a 401/403, not counted as a retry attempt). Detect an unresolved
  Key Vault reference (the setting still starts with `@Microsoft.KeyVault(`) as a secret-read failure.
* **Retry.** Values come from settings (`<Interface>RetryCount`, `RetryDelaySeconds`, `HttpTimeoutSeconds`), never from constants; the TSD's table overrides the template's 3 x 2 s. Status handling: 408 and 5xx transient; network error and timeout map to different codes;
  401/403 refresh once; **400/422 data error; every other 4xx is a technical failure and is not retried** (the template's "other failure: retry" would retry a 404 or 415). Inject `TimeProvider` and use `Task.Delay(delay, timeProvider)` so 3 x 5 s is testable in milliseconds.
* **Session-enabled subscriptions.** `IsSessionsEnabled = true` on the trigger; ordering comes from one session id; `maxConcurrentSessions` (default 8) applies, `maxConcurrentCalls` does not; the session lock renews for `maxAutoLockRenewalDuration` (default 5 min), so a long retry chain
  can lose the lock: record it as a limitation. Infrastructure (the session-enabled subscription, the Event Grid filter, the `SessionId` static property) is outside the code and must be listed as a deployment dependency.
* **Settlement setting (verified against Microsoft Learn, 2026-10-05).** On Service Bus extension 5.x the host.json key is `extensions.serviceBus.autoCompleteMessages`; `messageHandlerOptions.autoComplete` is the **4.x** schema and is ignored by 5.x. Microsoft says to set
  `AutoCompleteMessages = false` on the trigger attribute when using `ServiceBusMessageActions` (that property is not in the pinned `Worker.Extensions.ServiceBus` 5.16.0; it needs a newer package). Production `host.json` still carries the 4.x key, so the executor's explicit settlement is what keeps it working.
  Do not change a shared `host.json` inside an interface PR: raise it as a platform change (set `autoCompleteMessages: false` and upgrade the package, then set the attribute).
* **SMC limits.** `SmcService` can record only Success or Failed and the keys CorrelationId and ItemNumber. A TSD "Non-Success" (duplicate, warning) is recorded as Success with a warning stage; extra reference keys (file name) travel in `ItemNumber`. State this deviation in `assumptions.md` and, if the business needs it, raise a shared change to add a warning status.
* **Stage numbering** for multi-call runs: `4.<recordType><call>` style ids so SMC timelines compare across interfaces.
* **Payload logging.** If the TSD prohibits logging payloads, honour it even when `EnablePayloadDiagnosticLogging` is on.


**Settings files and open items (Step 4 also covers these).** Every interface adds its keys to all four `pipelines/appsettings/{dev,sit,uat,prod}.local.settings.json` files (`merge-app-settings.yml` adds and updates, it never removes keys).
Topic and subscription names are `%<Name>TopicName%` / `%<Name>SubscriptionName%` placeholders defined in `AppSettings.cs` and in every environment file (checker `FN-10`, `FN-11`); `SmcInterfaceIdEAII<n>` is an `AppSettings` property
(in production only `dev` carries it). A value the TSD leaves open (endpoint, client id, timeout) is a key that is **present with an empty value**, numeric settings are `int?` so an empty value binds, and the open item with its owner goes to `assumptions.md`;
never invent a URL. A function that must not run until cut-over ships with `"AzureWebJobs.<FunctionName>.Disabled": "true"`. Secrets are `@Microsoft.KeyVault(VaultName=...;SecretName=...)`. The test project copies only the fixture types it lists:
add `Fixtures\**\*.txt` (or `.csv`) when the interface uses flat files.

### Step 4b — Run the production-calibrated check (mandatory)

```powershell
python .github\skills\ais-functionapp-codegen\tools\check_functionapp.py <clone>
dotnet build <clone>\FunctionApp\<Name>.sln ; dotnet test <clone>\Tests\<Name>.Tests
```
0 errors required. The checker verifies the 3-project layout, `net10.0` isolated worker, `Program.cs` composition (`Configure<AppSettings>`, Application Insights,
`DefaultAzureCredential`, `IServiceBusFunctionExecutor`, `ISmcService`), that every Service Bus function delegates to the executor and takes `ServiceBusMessageActions`,
that every service has an interface, no `new HttpClient()`, no hard-coded endpoints or secrets, Key Vault references in the settings files, `autoComplete=false` (4.x key, warns) or `autoCompleteMessages=false`,
and a PRD stage gated on `main`. It was calibrated to pass on Metproducts and MDMSupplierInfo `main`. It does not compile or run tests.

### Step 5 — Log Assumptions

Write `outputs/<InterfaceID>/assumptions.md` with every assumption about input schema,
null handling, sort order, type conversions, and which HTTP status codes are treated as
non-retryable for this interface's downstream call.

## Coding Rules

- Do not create a new `.csproj` — reuse the existing host + `.Common` projects.
- Reuse the existing `ProcessingResult` envelope and `IServiceBusFunctionExecutor` — never
  duplicate either.
- Reuse the existing `AppSettings` class — add properties to it, grouped by interface with a
  comment header; never create a second settings class.
- Use `Newtonsoft.Json` for deserialization unless the reference repo uses `System.Text.Json` —
  check the actual repo, don't assume.
- All public methods must be synchronous or fully async (no `.Result` or `.Wait()`).
- LINQ must not buffer unbounded collections into memory — use streaming where possible.
- A gating check (if the downstream system can be known-unavailable) happens *before* any
  transform or I/O work, and returns `Skipped`, not `Failed`.
- Non-retryable HTTP statuses (e.g. `400 BadRequest`) must return `Failure` immediately, not
  loop through the retry budget.
- Log a `LogMessage` with a `StageID` for every meaningful processing stage — this is what SMC
  displays as the interface's stage timeline; don't collapse multiple stages into one log entry.
- No hardcoded connection strings or credentials — `BlobServiceClient` and similar clients use
  `DefaultAzureCredential()`.

## Unit Test Pattern

Confirmed real toolchain: **xUnit** + **Moq** + **FluentAssertions** (not bare `Assert.*`). Full
annotated examples in
[`code-corpus/unit-tests/index.md`](../../../code-corpus/unit-tests/index.md). Generate **two**
test classes per interface, matching the real split:

**Function-level test** (`Tests/<RepoName>.Tests/Functions/<InterfaceName>FunctionTests.cs`) —
mocks the Service *and* the Executor; asserts only that the Function wires the trigger to the
executor with the correct interface ID and delegate. Does not test business logic.

```csharp
public class <InterfaceName>FunctionTests
{
    private readonly Mock<I<InterfaceName>Service> _service = new();
    private readonly Mock<IServiceBusFunctionExecutor> _executor = new();
    private readonly IOptions<AppSettings> _options = Options.Create(new AppSettings
    {
        SmcInterfaceId{InterfaceEaiiNumber} = "EAII-{number}"
    });

    [Fact]
    public async Task RunAsync_ValidMessage_ShouldCallExecutorWithCorrectInterfaceId()
    {
        // Arrange: ServiceBusModelFactory.ServiceBusReceivedMessage(body: ...) for the fake message
        // Act: call sut.RunAsync(...)
        // Assert: _executor.Verify(e => e.ExecuteAsync(message, actions, context, "EAII-{number}",
        //   nameof(<InterfaceName>), It.IsAny<Func<...>>()), Times.Once);
    }
}
```

**Service-level test** (`Tests/<RepoName>.Tests/Services/<InterfaceName>ServiceTests.cs`) —
mocks only I/O-boundary dependencies (Blob, Http, Gating); uses the **real** transform service
(not mocked); asserts against specific field values from a realistic inline sample payload
(C# 11 raw string literal), not just "no exception thrown". Cover at minimum: the gating-skip
path, the happy path, and the transform-and-post path with a captured-payload assertion. Add a
`*FixtureFolderTests.cs` data-driven test (iterating a `Fixtures/<Interface>/` folder) instead of
many individual `[Fact]`s once a transform has more than a handful of real-world input variants.

### Tests for a TSD-driven interface

Name test methods after the TSD test cases (`TC001_...` for TSD `TC-001`) so traceability can be checked by a script; split by component (parser, each renderer, token, HTTP, blob lifecycle, orchestration, executor outcome, settings binding)
instead of "two classes per interface". Some TSD cases cannot be unit tests (session ordering, the Event Grid filter): cover them with a design-time assertion and list them for the integration test. Production Metproducts pairs
`Functions/<Class>FunctionTests.cs` with `Services/<Class>ServiceTests.cs`; the checker warns when either is missing (`FN-08`).

## References

- [`code-corpus/patterns/01-function-app-pattern.md`](../../../code-corpus/patterns/01-function-app-pattern.md) — full real-code evidence for every pattern above
- [`code-corpus/unit-tests/index.md`](../../../code-corpus/unit-tests/index.md) — full real test examples
- [`code-corpus/production-snapshot.md`](../../../code-corpus/production-snapshot.md) — what is live in production
- [`code-corpus/codegen-eval/`](../../../code-corpus/codegen-eval/) — held-out and end-to-end evaluations of this skill
- `tools/check_functionapp.py` — production-calibrated static check
