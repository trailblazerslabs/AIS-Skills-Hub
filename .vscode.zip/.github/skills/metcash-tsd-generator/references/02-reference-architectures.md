# AIS Reference Architectures

Four archetypes observed across the approved corpus. Pick the **simplest archetype that satisfies
the FSD**, then justify the choice — and the rejection of the next-simplest — in §5.x.5.

---

## Decision table

Evaluate top to bottom. The first row whose conditions all hold is the archetype.

| # | Archetype | Trigger | Transformation complexity | Volume / latency | Precedent |
|---|---|---|---|---|---|
| **A** | **APIM-only** | Synchronous inbound REST or SOAP | Field extraction, protocol translation, XSLT/Liquid response transform — expressible in policy | Low volume, sub-5s latency, stateless, idempotent | TSD-EAII-333, TSD-EAII-289 |
| **B** | **APIM + Logic App Standard** | Synchronous inbound REST | Multi-step orchestration, SOAP envelope construction, WS-Security, conditional branching | Low–medium volume, sub-10s latency | TSD-EAII-297 |
| **C** | **Function App (event-driven)** | Service Bus subscription (pull) | Non-trivial mapping, record splitting, flat-file rendering, per-message enrichment calls | Medium–high volume, asynchronous | TSD-EAII-284/283/282/385, TSD-EAII-301/302/516/517 |
| **D** | **File / MFT batch** | Scheduled or file-arrival | Bulk transform to flat file | Batch, file-based delivery via GoAnywhere | TSD-EAII-301 (EIM leg) |
| **B+C+D** | **Hybrid: sync upload, async translate** | Synchronous REST upload of a file/payload | File transform after the reply (decompress, map, render flat file) | Very low volume, receipt-only latency | TSD-EAII-304 (revised) |

Archetypes combine. C+D is common: a Function App writes a flat file to Blob and GoAnywhere
delivers it onward. **The decision table is a first filter only** - it is first-match and cannot express
EAII-304 (synchronous inbound REST, but asynchronous processing). Use the next section to decide.

---

## A — APIM-only

**Shape:** Consumer → App Gateway → APIM (inbound/backend/outbound/on-error policies) → Target API

```
Consumer ──HTTPS──> App Gateway ──> APIM ──HTTPS/mTLS──> Target API
                                     │
                                     ├──> Key Vault (Managed Identity)
                                     ├──> Application Insights
                                     └──> SMC (send-request policy)
```

**Characteristics**
- All logic lives in APIM policy: `inbound` (extract/validate/rewrite), `backend`, `outbound`
  (parse/transform/format), `on-error` (fault construction + error logging)
- Transformation via XPath, C# policy expressions, XSLT 1.0, or Liquid templates
- No compute resource; no App Service Plan for the integration itself
- SMC logging via `send-request` policy actions
- Secrets via APIM Named Values backed by Key Vault, or direct Key Vault access via APIM's
  system-assigned managed identity

**Required components:** APIM (existing shared), Key Vault, Application Insights, Log Analytics,
Virtual Network.

**Constraints to record in §12:** APIM forward-request timeout default 300s; inline
transformation body size limit ~256 KB non-streaming; APIM supports XSLT 1.0 only.

**When to reject:** multi-call orchestration, long-running work, stateful correlation, payloads
over ~256 KB, or transformation that would make the policy unmaintainable.

---

## B — APIM + Logic App Standard

**Shape:** Consumer → App Gateway → APIM → Logic App Standard workflow → Target

```
Consumer ──HTTPS──> App Gateway ──> APIM ──> Logic App Standard (HTTP Request trigger)
                                     │              │
                                     │              ├──> Target (SOAP/REST, mTLS / WS-Security)
                                     │              ├──> Key Vault (Managed Identity)
                                     └──> SMC       └──> Application Insights
```

**Characteristics**
- APIM owns OAuth 2.0 enforcement, request validation, routing, rate limiting, fault shaping
- Logic App owns orchestration: validation, transaction ID generation, transform, backend
  invocation, response mapping, audit logging, exception handling
- Workflows are **stateless** unless durability is explicitly required. Stateless needs the
  Service Bus trigger on **PeekLock with an explicit complete/dead-letter and queue-level retry
  (`maxDeliveryCount`, DLQ)**; **stateful** is justified when SMC resubmission is the retry
  mechanism (a Logic App can be resubmitted from SMC, a Function App cannot). State the choice
  and the reason in §5.x.5; do not leave it implied
- Trigger concurrency is a design decision: degree of parallelism (max 100) with max waiting
  runs at the lowest allowed value (10) unless the TSD says otherwise; state it in §4.5 / §5.x.5
- Prefer one Compose / one variable-initialisation action over a chain of single-purpose actions
- **Workflow count is NOT always one-per-operation.** Default to **one workflow per Logic App**
  with an internal switch/routing action (e.g. `Switch on Operation Type`) when several related
  operations share the same trigger shape, target system, and lifecycle (e.g. several REST
  endpoints on the same APIM API, all calling the same backend). Only split into separate
  workflows when operations have materially different triggers, SLAs, or release cadence.
  **Verify against the FSD/transcript and, where available, sibling interfaces before assuming
  either model** — do not default to "one workflow per operation" without evidence.
- Retry: set an explicit `retryPolicy` on every action (an unset policy silently defaults to 4
  retries; use `none` when no retry is intended). Start from the **Retry and resilience rules**
  in the cross-cutting table below, then adjust per use case and connector, with the reason in §4.5.1
- Logic App accessed privately; APIM is the only public-facing surface

**Required components:** APIM, Logic App Standard, App Service Plan, Key Vault, Application
Insights, Log Analytics, Virtual Network, Private Endpoints.

**On-premises/hybrid connectivity (e.g. DB2/AS-400, SQL Server on-prem):** Logic App Standard's
**built-in connectors** (DB2, SQL, etc.) reach on-premises systems directly over the existing
AIS Spoke VNet's approved enterprise network path (VNet Integration, Private Endpoints, NSGs,
Route Tables) — this is the default assumption. **Do NOT introduce an "On-premises Data
Gateway" as a new first-class, diagrammed, resource-inventoried component** (own row in §4.3,
§6.1.1, §6.5/§6.6, RBAC, Key Vault secret description, diagram node) unless the FSD/TSD inputs
give **concrete evidence** that a new dedicated gateway is being provisioned. The On-premises
Data (or Power Platform) Gateway is a distinct Azure resource used by Power Platform/Logic Apps
*Consumption* connectors — it is generally not part of the Logic App Standard built-in-connector
hybrid pattern. If a gateway genuinely exists as shared infrastructure, mention it once in prose
(§5.1.6.3.6 Service Provider, one line: name / owning team / purpose) — never as a provisioned,
diagrammed, or inventoried component of this interface.

**§6.5 must include** the Workflow Details table:
`Workflow Name | Workflow Type | Runtime | Hosting Model | Trigger Type | Outbound Service | Retry Policy | Response`.

---

## C — Function App, event-driven (the current preferred pattern for new work)

**Shape:** Source → (MFT) → Blob → Event Grid → Service Bus topic → per-interface subscription →
Function → Target

```
Source ──SFTP──> GoAnywhere ──HTTPS──> Blob Storage
                                          │ BlobCreated
                                          ▼
                                    Event Grid System Topic
                                          │ (MI: SB Data Sender)
                                          ▼
                              Service Bus Topic  data.<workload>.{env}.sbt
                                 ├── to<target>.<itemtype>  ──> Function A ──> Target A
                                 ├── to<target>.<itemtype>  ──> Function B ──> Target B
                                 └── …
```

**Characteristics**
- Azure Function App, **isolated worker, .NET 10**, one shared host per environment
- **One Service Bus topic, one subscription per interface** — never one topic per interface
- Item-type differentiation by blob path / Event Grid subject filter + subscription filter
- Service Bus trigger is a **pull** trigger — no public inbound HTTP surface
- Shared library per workload (`Metcash.AIS.Data.<Workload>.Common`) providing: XML
  deserialisation, SMC observation wrapper, retry policy, Key Vault access, and a
  `ServiceBusFunctionExecutor` that owns correlation ID generation, telemetry, and SMC logging
- Per-interface function + per-interface service class + optional token service
- Retry: Polly, transient 5xx/network only, no retry on non-retryable 4xx. Existing corpus
  functions use 3 attempts / fixed 2 s; **for new work start from the retry rules in the
  cross-cutting table** (max 2 for calls internal to Azure) and record any deviation in §4.5.1
- Failure: **explicit dead-letter on first delivery**
  (`ServiceBusMessageActions.DeadLetterMessageAsync`) rather than relying on Service Bus
  redelivery — this is the dominant corpus policy and guarantees no silent loss. A Function App
  cannot be resubmitted from SMC, so PeekLock with an explicit complete/dead-letter is how it is
  recovered; when the Stibo/downstream lock rule applies, cap `maxConcurrentCalls` at 1
  (dead-letter replays included)
- SMC: a **single complete observation per invocation**
  (`StartObservation` with `IsObservationComplete = true`), always in a `finally` block
- All Azure-to-Azure auth by System-Assigned Managed Identity (SAMI)

**Variant C2 — reference/pointer messages.** The Service Bus message carries only an identifier
or blob pointer; the Function calls the source system's REST API to fetch the full payload per
message (TSD-EAII-301/302/516/517). Use when the source is an API rather than a file drop.

**Required components:** Function App, App Service Plan, Service Bus (topic + subscriptions),
Event Grid System Topic, Storage Account + blob container, Key Vault (AIS-owned), Key Vault
(SMC-owned, existing), APIM (SMC gateway only), Application Insights, Log Analytics, Virtual
Network, Private Endpoints, Private DNS Zones, NSGs.

---

## D — File / MFT batch

**Shape (outbound):** Function or Logic App renders a flat file → Blob Storage → GoAnywhere →
target SFTP.

**Shape (inbound):** Source SFTP → GoAnywhere → Blob Storage → Event Grid → Service Bus → Function.

**Characteristics**
- GoAnywhere MFT is the Metcash-standard intermediary for all file-based source/target legs
- §5.x.4 GoAnywhere Requirements is a short description only (no field table; GoAnywhere is MFT-team owned and out
  of scope for AIS development): what is picked up and delivered, the hand-over location and the file name pattern.
  GoAnywhere generates the SMC ID and carries it in the file name; the first AIS component reads it and uses it as
  `ParentObservationID` for every SMC observation of the flow
- File naming and column ordering are contract detail — take from the Mapping Manifest, and
  treat a real sample file as the authority on field order for delimited targets
- Blob retention window (90 days default) supports SMC-driven replay

---

## Cross-cutting design defaults

Apply unless the FSD contradicts them; record any deviation in §5.x.5.

| Concern | Default | Evidence |
|---|---|---|
| Azure-to-Azure auth | System-Assigned Managed Identity | 7/7 |
| Secret storage | Azure Key Vault, referenced by name; never inline | 7/7 |
| Transport | HTTPS / TLS 1.2+ everywhere | 7/7 |
| Public access | Disabled on Storage, Key Vault, Service Bus; private endpoints in HSENS | 7/7 |
| Inbound exposure | APIM only; Function Apps have no inbound HTTP surface | 7/7 |
| Retry and resilience rules (async, call internal to Azure) | Maximum 2 retries, 2-3 s interval (Logic App action minimum is 5 s, so 5 s). Retry only steps that matter (e.g. the Function App call); not variable init, config fetch or blob write. Depends on use case and connector, so record the reason in §4.5.1 | Transcripts 2026-10-09 / 10-12 |
| Retry (external system, async) | Per use case; start at 2, never the platform default | Transcripts 2026-10-09 |
| Retry (sync) | None inside actions (the retry wait breaks the response-time NFR); consumer retries. Allow only where the FSD latency budget demonstrably absorbs it, and say so | A-archetype; 2026-10-09 |
| Retry budget vs lock | Cumulative worst-case retry time of a run must be below the Service Bus PeekLock duration (default 60 s); otherwise cut retries or raise the lock duration, and show the arithmetic | 2026-10-09 / 10-12 |
| Retry on Stibo / PE procedure calls | None | EAII-374 call 2026-10-09 |
| Failure disposition | Explicit dead-letter on first delivery, or Service Bus redelivery to `maxDeliveryCount` (e.g. 5 x 5 min) when automatic retry is preferred over manual SMC resubmission | C-archetype; 2026-10-12 |
| SMC load | Every attempt writes a start and an exit SMC entry; count them when choosing queue-level retries | 2026-10-12 |
| Downstream sequencing | Calls to the same downstream item are serial with a 2-3 s pause; invoke only the operations present in the input (not every operation TIBCO called); one file/message at a time where the target locks items (concurrency 1, DLQ replays included) | EAII-374 call 2026-10-09 |
| Concurrency | State the limit (Logic App parallelism max 100, max waiting runs 10; Function `maxConcurrentCalls`); cap concurrent connections to any target (PE/TIBCO: 1000); consider shared App Service Plan load | 2026-10-09 / 10-12 |
| Timeouts | Every outbound call has an explicit timeout (Function: HttpClient timeout + cancellation token; Logic App: action timeout); the timeout must be proven by a test, not assumed. Long-running-thread kill duration is per interface | 2026-10-09 |
| Logic App vs Function App | Logic App orchestrates; for synchronous or high-volume flows lean Function App (timeout/cancellation control, opaque connectors such as DB2). Decide per interface and record the reason | 2026-10-09 |
| Performance test | Mandatory before the CR: volume stated per day **and** peak window; test at the peak (or 24 h compressed to 30-60 min), real files with distinct names, evidence attached to the deployment; owner is the testing team; a non-prod limitation (e.g. single PE non-prod) is recorded | 2026-10-09 / 10-12 |
| Observability | SMC (business) + Application Insights (technical) + Azure Monitor (platform) | 7/7 |
| Correlation | GUID per message, propagated end-to-end; `ParentObservationID` from inbound `TRANSACTIONID` where present; for a GoAnywhere-delivered file it is the SMC ID carried in the file name (generated by GoAnywhere), used for the entire flow | C-archetype; 2026-10 review |
| Environments | DV1 / ST1 / UT1 / PRD | 6/7 (PREPROD added in 1/7) |
| IaC | Bicep in `metcash-ais-infrastructure` | C-archetype |
| CI/CD | Azure DevOps; PR → DV1 automated; ST1/UT1/PRD gated | 7/7 |

---

## Archetype → §4.3 Required Components matrix

| Component | A | B | C | D |
|---|:-:|:-:|:-:|:-:|
| Azure API Management | ● | ● | ○ (SMC gateway only) | ○ |
| Azure Logic Apps Standard | | ● | | ○ |
| Azure Function App (isolated .NET) | | | ● | ● |
| Azure App Service Plan | | ● | ● | ● |
| Azure Service Bus (topic + subscriptions) | | | ● | ● |
| Azure Event Grid System Topic | | | ● | ● |
| Azure Storage Account + blob container | | | ● | ● |
| Azure Key Vault (AIS-owned) | ● | ● | ● | ● |
| Azure Key Vault (SMC/enabling, existing) | ● | ● | ● | ● |
| Azure Application Insights | ● | ● | ● | ● |
| Azure Log Analytics Workspace | ● | ● | ● | ● |
| Azure Virtual Network | ● | ● | ● | ● |
| Private Endpoints / Private DNS Zones / NSGs | ○ | ● | ● | ● |
| Azure Application Gateway (existing) | ● | ● | | |
| GoAnywhere MFT (existing) | | | ○ | ● |

● required ○ conditional


---

## How to choose: ingress x engine x egress (learned from the approved 374 and 304)

Decide three things independently, then read the archetype off the combination. Record each decision, its
evidence, and the rejected alternative in the questionnaire (section 1) and later in §5.x.5.

| Question | Options | Evidence to look for |
|---|---|---|
| **Ingress** - how does work arrive? | synchronous API call / event or file drop / schedule | FSD §3.x.1 process description, §3.x.3 endpoints, walkthrough ("synchronous call", "batch", "file-based interface") |
| **Engine** - what runs the logic? | APIM policy / Logic App Standard / Function App / combination | transformation complexity (FSD + Mapping), volume + payload size (FSD §3.x.6), what has **already been proven** (374 Turn 13: "PE connectivity we have tried from Logic App, not from Function App"), complexity rating from the walkthrough (374 Turn 27-28: "very simple, very small number of fields") |
| **Egress** - how is the result delivered? | synchronous reply / API push / MFT file / database call | FSD §3.x.3 target, §3.x.2 target schema, GoAnywhere mentions |

| Ingress | Engine | Egress | Archetype | Precedent |
|---|---|---|---|---|
| sync API | APIM policy only | sync reply / API | **A** | 333, 289 |
| sync API | APIM + one Logic App (switch on operation) | DB2 / SOAP / API call | **B** | 297, **374** (DB2 built-in connector, one Logic App for four operations) |
| sync API (upload) | APIM -> shared Function stores blob; Event Grid -> Service Bus **queue** -> Logic App + inline Function | MFT file via GoAnywhere | **B+C+D hybrid** | **304** (revised) |
| file drop / event | Event Grid -> Service Bus topic -> Function | API / file | **C** | 284, 301 |
| schedule / file | Function or Logic App renders flat file -> Blob | MFT file | **D** | 301 (EIM leg) |

### Decision signals the transcripts add (use them before asking the user)

| Signal | Effect on the design | Where seen |
|---|---|---|
| Changing the **consumer** is a change request / funding issue | Prefer lift-and-shift of the legacy interaction pattern (keep file/GoAnywhere or API shape); do not propose an API where the consumer is a file-based batch | 374 Turn 18-25 ("lift and shift is easier") |
| Connectivity to the target is **already proven** from one runtime | Use that runtime (Logic App for PE/AS-400) | 374 Turn 13 |
| Volume tiny, payload < 1 KB, mapping "very simple" | Logic App or APIM, not a Function App | 374 Turn 10, 27 |
| Several related operations, same target, no sequencing between them | One Logic App with an internal switch, one APIM collection, **one interface ID** | 374 Turn 35, 87, 98 |
| FSD says "retain the two-phase model" and the upload must reply fast | Sync upload + async translation with a queue between them | 304 FSD §1.2 |
| An existing shared component already does the job (EAII-367 `UploadBlob`) | Reuse it; do not create a new upload function | 304 |
| Exactly one consumer of the async message | Service Bus **queue** (304). Topic + one subscription per interface when fan-out is plausible (C archetype, 301/284) | 304 vs 284/301 |
| Source/target is on-premises (AS/400, DB2) | Logic App built-in connector over the existing VNet path; **no** On-premises Data Gateway unless the inputs show a new one is being provisioned | 374 (FSD floated a gateway; the approved TSD did not use one) |

### Archetype presets used by the intake scanner

`tools/intake/required-facts.json` -> `archetype_presets` maps the chosen archetype to design flags (`apim`,
`logic_app`, `blob_staging`, `service_bus`, `goanywhere`, ...). Component flags for the specific source/target
(`db2`, `rest_target`, `file_target`) are added with `--flags`. The flags decide which facts the developer must
supply (storage account, container/folder, queue name, GoAnywhere details, DB2 host/schema, repo, ...).
