# Post-generation checklist (run after every TSD is generated, before it goes for approval)

Tick every box or write why it does not apply. Items marked **[auto]** are answered by a tool; the rest need a person (or the
agent reading the output). Metcash tenant / `METCASHDevOps` only throughout (see `azure-local-auth`, `mcp-builder`).

## A. Automatic gates [auto]

| # | Check | Command | Pass when |
|---|---|---|---|
| A1 | Inputs staged and converted (4 files) | `ls tsd-inputs/<ID>/converted` | FSD, MAP, MANIFEST, transcript present |
| A2 | Intake gate | `intake_gaps.py check tsd-inputs/<ID>/intake-questionnaire.md` | `OK`, no 🟥 left |
| A3 | Tables well-formed | `reference-corpus/_tools/check_tables.py "<tsd>"` | `OK` |
| A4 | TSD lint | `tools/tsd_lint/check_tsd.py "<tsd>" --inputs ... --corpus ...` | 0 errors, 0 warnings (or each justified) |
| A5 | Quality scorecard | `tools/tsd_lint/quality_review.py "<tsd>" --inputs ... --archetype <A-D> --flags ... --diagrams ... --out quality-review.md` | overall >= 90, no failed `error` row |
| A6 | Diagram lint | `tools/diagrams/lint_drawio.py <file>.drawio` | 0 errors on icon pages |
| A7 | Every image exists and is numbered 01.. in document order | covered by A5 `DG-01/02` | pass |
| A8 | No secret values | covered by A5 `SEC-01` | pass |
| A9 | Auth is Metcash only | `az account list --all --query "[?tenantId!='4e8bf66f-8b02-4b25-9c5a-8ae5ba17b931']" -o tsv` | prints nothing |

## B. Content review (read the document, not the score)

- [ ] Archetype matches the FSD trigger, volume and latency; the rejected archetypes are named with a reason (§5.x.5).
- [ ] §1.1 says migration or net-new and names the legacy platform; §5.x.1.1 names the legacy artefacts and the TIBCO repo (or TBC with the reason).
- [ ] **Crisp, progressive, no duplication:** §1 is a short overview (what/why/scope/what the reader will find) with no process, mapping, volume or design detail; §4.1 does not restate §1.1; the same fact is not written in §1, §4.1, §5 and the FSD extract; detail appears once in the section that owns it and elsewhere is cross-referenced; paragraphs that a table or list would show more clearly are converted.
- [ ] Every FSD scenario, exception, known issue, NFR and endpoint appears (A5 traceability) **and** the TSD adds the failures its own design creates (APIM backend 503/504, DB credential rejected, request-transform failure, invalid operation id).
- [ ] No figure that is not in the inputs (availability, TPS, retention, timeouts): each is from the FSD or `*<To be confirmed — what from whom>*`.
- [ ] Business outcomes (non-zero return code, "no rows") are separated from transport exceptions.
- [ ] Coordination, transaction boundary and state are stated (never `NA`); retry / dead-letter policy has a rationale and says where it differs from an FSD figure.
- [ ] **Resilience and performance (transcripts 2026-10-09 / 10-12):** §4.5.1 is a per-action retry table (internal/external, sync/async, count, interval, reason) with no platform-default retry, none inside synchronous actions, max 2 for async calls internal to Azure (or the reason it differs), and the cumulative worst case is shown against the PeekLock duration (`KB-R01`); stateful vs stateless, Logic App vs Function App, concurrency/parallelism and the downstream connection limit, timeouts and the one-at-a-time/pause rule for targets that lock items are decided in §5.x.5 (`KB-R02`); §4.5 states daily volume **and** peak window, and the performance-test plan (peak or compressed load, real files, owner, ADO card, non-prod limitation).
- [ ] Consumer impact is explicit: what the consumer must change, who owns it, by when (or TBC with owner).
- [ ] Every open gap in the questionnaire reappears in §12 / §13 with an owner; no gap was silently dropped.
- [ ] Resource names are spelled one way in §3.2, §4.3, §5.x.6.1, §6.1.1, §6.5, §6.6 and every diagram; the Logic App / workflow names match the repo (section D).
- [ ] Endpoint paths are the same string in §5.x.6.3.5, §5.x.10.2, §6.5 and the diagrams.
- [ ] Security: secret **names** inventoried in §6.3.2, each Key Vault has an RBAC row in §6.3.3, nothing sensitive logged (§6.3.1).
- [ ] Standing infrastructure tables (VNet, subnets, App Gateway, APIM) are copied from `03-naming-and-infrastructure.md`, not retyped; known corpus conflicts are flagged.
- [ ] §9.3 names repo, branch, PR title, runsheet and rollback; §10 follows the FSD service tier.
- [ ] §15 checklist is the verbatim boilerplate.
- [ ] **Shared dependencies (ref 12):** §3.2 Environment Segregation names Key Vaults, Service Bus namespaces, the SMC queue and the env mapping; §6.6 lists every Key Vault and namespace used; §6.3.3 has RBAC rows for each dependency edge; §6.5 has a private endpoint for every Key Vault incl. the enabling one; the HUB vs AIS subscription is noted (`XR-07`, `XR-09`, `KB-S01..S05`).
- [ ] **No avoidable TBC:** retention, XREF access, inbound auth and SMC onboarding names are filled from evidence or defaults (`KB-D01..D04`); §4.1.2 links FSD, Mapping and Manifest (`TR-12`); §6.5 has the Workflow Details table (`KB-B01`).
- [ ] **Described once:** shared ingestion content lives only in its own §5.1 (`XR-08`).
- [ ] **Gap register:** `gap_register.py check` prints OK; every resolved gap is reflected everywhere the TSD describes its topic.
- [ ] **Standalone document:** no questionnaire references, no gap/question ids (G1, Q2, A3, TBC-1), no "§3A", no transcript turn numbers anywhere in the TSD (`internal-reference`); decisions and open items are stated in plain words.
- [ ] **GoAnywhere:** §5.x.4 is a short description with no field table; it states the SMC ID generated by GoAnywhere, carried in the file name and used as `ParentObservationID` for the whole flow, and the same rule appears in the SMC observation steps.
- [ ] **FSD process image (§4.1.1)** and every PNG have a white background, not black (`DG-13`); open them to confirm.

## C. Diagrams (open every PNG)

- [ ] One page per slot: system context (simple block diagram, opens §4.1), process flow (simple style), architecture, network, communication, plus the sequence PNG. The system context shows only the participating applications/systems and their high-level interaction.
- [ ] Each APIM operation is its own node on the architecture page; the OAuth identity provider has both arrows on every page that has APIM.
- [ ] External systems sit outside every container; no overlapping text; no page wider than ~2100 px at 100 % (A5 `DG-03`).
- [ ] Spec JSON saved next to the `.drawio` and `_meta.spec_author_model` names the model that wrote it.
- [ ] Every Key Vault (incl. enabling) appears on architecture, network (with private endpoint) and communication pages (`DG-11`); the process flow shows the SMC step (`DG-10`); every icon page has the legend (`DG-12`).

## D. Reconcile with the code that already exists (repo and branch)

Do this before the TSD is approved, and again before `ais-codegen-readiness`. Use git on the local clone (no MCP unless it is
verified as `METCASHDevOps`):

```powershell
git -C <clone> fetch origin --prune
git -C <clone> branch -r | Select-String "<EAII-nnn>|<workload>"
python .github\skills\metcash-tsd-generator\tools\code_scan\scan_logicapp.py <clone> origin/<branch> --env dev
```

- [ ] **Repo**: the workload repo (`Metcash.AIS.Data.<Workload>`) and the existing `feature/EAII-<nnn>-...` branch are named exactly as they exist (not as the TSD would like them).
- [ ] **Workflow / function names, kind** (Stateful or Stateless), trigger and the header that selects an operation match §5.x.6.1, §6.5 Workflow Details and the diagrams.
- [ ] **Backend access** (connector action: stored procedure vs query, connection name) matches §5.x.2.1; an assumption that the code has since proved (or disproved) is closed in §13.
- [ ] **Backend host, schema, user, port per environment** from `AppSettings` / `Parameters` match §6.4; where the code and an approved TSD disagree, the code is the as-built fact and the conflict is raised.
- [ ] **Secrets**: the Key Vault secret names and the way they are consumed (app-setting Key Vault reference vs runtime read) match §6.3.2 / §6.3.3.
- [ ] **Retry and timeout** in the workflow actions match §4.5.1 and §5.x.5 (explicit `retryPolicy`, retry counts, intervals, timeouts, trigger concurrency, `maxConcurrentCalls`, workflow kind), or the difference is a recorded decision with an owner.
- [ ] **Observability pattern** (APIM `startObservation`, observation stages, Service Bus SMC queue) matches §5.x.6.3.1-2 and §5.x.7; the SMC queue / namespace is in §6.1.1.
- [ ] **Status-code mapping and error strings** in the code are reflected in §5.x.6.3.3 (and any code with no TSD row is added).
- [ ] **Pipeline and app-settings files** (`pipelines/*.yml`, `AppSettings/appsettings.<env>.json`) are named in §9.3; environment tokens (`dv1` vs `dev`) match.
- [ ] A code gap or TSD gap found here is logged with an owner; the TSD is not edited to hide it.

## E. Hand-over

- [ ] `tsd/<Name>/quality-review.md` attached; failed rows justified.
- [ ] Questionnaire approved by a human (not simulated) and the version used is recorded.
- [ ] Open gaps list (kind A transcript-unresolved, kind B identified) sent to the owners named in §13.
- [ ] `outputs/<ID>/status.md` updated (phase done, open gaps, evidence already fetched).
- [ ] No Pet Supermarket / non-Metcash organisation, tenant or MCP server was used at any step.
