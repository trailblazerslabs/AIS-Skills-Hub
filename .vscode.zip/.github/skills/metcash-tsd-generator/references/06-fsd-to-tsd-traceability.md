# FSD → TSD Traceability Map

Empirical mapping derived from the seven approved FSD/TSD pairs. Use this to drive population and
to run the §6.2 traceability quality gate.

The FSD structure is: §1 Document Overview (1.1 Business context, 1.2 Integration description,
1.3 Horizon Impact Assessment, 1.4 Known Issues, 1.5 Glossary), §2 Scope (2.1/2.2/2.3),
§3 Requirements Overview (§3.x per interface, 3.x.1–3.x.11), §4 Appendices, §5 Approval Checklist.

---

## Primary map

| FSD source | → TSD target | Transformation applied |
|---|---|---|
| §1.1 Business context | §1.1 Background | Add migration-vs-net-new framing, name the legacy platform, name the target AIS component |
| §1.2 Integration description | §1.2 Document Purpose, §4.1 | Restate as technical purpose; bold the service, source, target, AIS component |
| §1.2 architecture diagram | §4.1.1 Process Diagram from FSD | **Copy the `.drawio` + `.png`; do not redraw** |
| §1.3 Horizon Impact Assessment | §5.x.5 Design Considerations, §9.1 Transition Period, §13 Assumptions | RED/AMBER ratings drive the approval path and cut-over sequencing. RED → state the Horizon Platform Owner / Business Process Owner approval requirement |
| §1.4 Known Issues | §2.2 Out of Scope (if not addressed) **or** §5.x.5 Design Considerations (if addressed) **or** §5.x.10.2 (test scenario) | Every known issue must land in exactly one of these three |
| §1.5 Glossary | §1.3 Glossary | Copy, then extend with Azure services, protocols, and TSD-introduced acronyms; re-sort |
| §2.1 In Scope | §2.1 In Scope | Restate as technical work items naming the implementing AIS component. Add SMC onboarding, Key Vault, Managed Identity lines |
| §2.2 Out of Scope | §2.2 Out of Scope | Add technical boundaries (no historical data migration, no target API changes) |
| §2.3 Limitations and Constraints | §12 Limitations and Constraints, §5.x.5 | Add the standing Azure platform limits |
| §3.x heading | §5.x heading | `## 5.x EAII-nnn - <Interface Description>` |
| §3.x.1.1 Process Diagram | §5.x.1.2 (as-is) and input to §5.x.2.2 (proposed) | |
| §3.x.1.2 Process Description | §5.x.2.1 Description of Process(es) | **Convert to numbered steps, each naming its Azure component** — this is the core translation of the whole document |
| §3.x.1.3 Known Issues | §5.x.5 Design Considerations, §2.2, §5.x.10.2 | Same rule as §1.4 |
| §3.x.2 Interface requirements / Mapping details | §5.x.6.3.7 Communications Data Structures, §4.1.2 links, §8.1 | Mapping doc links go in §4.1.2 and §5.x.6.3.7 |
| §3.x.3 API Endpoint(s) information | §5.x.6.3.5 Service Operations, §5.x.6.3.6 Service Provider, §7.1 Communication Components, §6.2 | Endpoint paths, verbs, auth, content types |
| §3.x.4 Interface Service Level (Gold/Silver/Bronze) | §10 Disaster Recovery, §4.5 NFR Availability row | Tier drives DR strategy and the availability SLA figure (e.g. `95% (Silver SLA)`) |
| §3.x.5 Interface Data Classification | §6.3.1 Data Handling and Encryption | Classification + field-level logging restrictions |
| §3.x.6 Non-functional requirements | §4.5 NFRs, §5.x.7.2 SMC Load Estimations, §5.x.8 Monitoring, §6.5 sizing, §8.5 retention | Volume → load estimations; latency → alert thresholds; reliability → SKU and DR |
| §3.x.7 Exception handling | §5.x.6.3.3 Exceptions | **1:1 scenario mapping** + mandatory `-099` catch-all. Assign exception codes and categories |
| §3.x.8 Integration Component Monitoring | §5.x.8 Monitoring | Add concrete thresholds, windows, recipients |
| §3.x.9 Reporting | §5.x.9 Reporting | Usually `N/A - standard AIS platform reporting applies` |
| §3.x.10 Relevant context considerations | §5.x.5 Design Considerations, §9.1 Transition Period, §13 Assumptions | Dependencies → §13; cut-over context → §9.1 |
| §3.x.11 Test scenarios | §5.x.10.2 Unit Testing, and the **Test Scenario** column of §5.x.6.3.2 Audit | Re-issue as **TC-nnn** (sequential, ADO import shape); keep each FSD id (T1, T2…) in the `FSD ref` column; the audit table cites TC ids |
| §4 Appendices — sample payloads | §5.x.6.3.7 Sample Files, §5.x.6.3.8 Input/Output, §5.x.10.2 Location of Sample Messages | Reference by filename |
| §4 Appendices — schemas | §5.x.6.3.7 Input/Output Schema, §8.1 Data Model | Filenames only, no source-tree paths |

---

## Mapping Manifest → TSD

| Manifest content | → TSD target |
|---|---|
| Source system, format, schema path(s) | §5.x.6.3.7 Input Schema, §5.x.6.3.8 Input |
| Target system, format, schema path(s) | §5.x.6.3.7 Output Schema, §5.x.6.3.8 Output |
| Record types (HDR, COR, LOC, DTL…) | §5.x.6.3.7 one row per record type; §5.x.2.1 splitting/rendering steps |
| Branching (discriminator + values) | §5.x.2.1 conditional steps; §5.x.5 design consideration |
| DataFormat resources / column ordering | §5.x.6.3.7 Description; §8.1 |
| Sample payload paths | §5.x.6.3.7 Sample Files; §5.x.10.2 Location Of Sample Messages |
| Transformation entry points | §5.x.6.2 Services (the components that will carry the mapping logic) |
| Pass-through interfaces (no mapping) | §5.x.6.3.7 states byte-for-byte pass-through, no validation surface |

---

## TSD sections with no FSD source

These are authored from platform standards, not from the FSD. Take them from
[04-standard-boilerplate.md](04-standard-boilerplate.md) and
[03-naming-and-infrastructure.md](03-naming-and-infrastructure.md).

| TSD § | Source |
|---|---|
| §1.2 Document Purpose | Boilerplate + integration identity |
| §3.1, §3.2 | Metcash principles/standards + integration-specific justification |
| §4.2 Technical standard and requirements | Boilerplate, adjusted to protocols in use |
| §4.3 Required Components | Archetype → components matrix |
| §4.4 Environmental Requirement | Environments Strategy |
| §4.5.1 Retry Strategy | Archetype defaults + rationale |
| §5.x.3 Coordination | Derived from the archetype (sync/async, transaction boundaries, statelessness) |
| §5.x.6.1 Component List | Archetype → components matrix + naming reference |
| §5.x.10.1 Development and Integration Strategy | Boilerplate |
| §6.1.1, §6.2.1, §6.2.2, §6.3.2, §6.3.3, §6.5, §6.6 | Infrastructure reference |
| §7.1 Communication Components | Derived from §6.2 + §5.x.2.1 |
| §8.2–8.4 | `NA` unless a database is in scope |
| §9.2, §9.3 | Boilerplate |
| §11 Support Documentation | Placeholder until go-live |
| §14 Reference Documents | Standing links + integration-specific docs |
| §15 Approval Checklist | Verbatim boilerplate |

---

## Traceability gate checklist

Run before handover. Every line must be provable.

- [ ] FSD interface count == TSD §5.x block count (for the confirmed in-scope set)
- [ ] Every FSD §3.x.7 row → a §5.x.6.3.3 row
- [ ] §5.x.6.3.3 contains a `-099` catch-all
- [ ] Every FSD §3.x.11 scenario (T1..Tn) → at least one §5.x.10.2 `TC-nnn` row whose `FSD ref` cites it
- [ ] Every §5.x.6.3.2 Audit row cites a real `TC-nnn` from §5.x.10.2
- [ ] Test cases beyond the FSD (auth 401/403, rate limit, correlation, SMC success/failure, timeouts, large result sets) are added and carry `FSD ref` = `—`
- [ ] No FSD figure is silently replaced: every override (retries, timeouts, paths, error codes) is a §5.x.5 Design Consideration with its rationale
- [ ] Every value the FSD does not contain (storage account, container/folder, repo, public path, queue/topic, GoAnywhere hand-over location and file name/SMC ID position, DB2 host/schema, SMC names) traces to a questionnaire §3A answer
- [ ] Every FSD §3.x.6 NFR category → §4.5 or §5.x.7.2 or §5.x.8
- [ ] FSD §3.x.4 GSB tier → §10 DR strategy and §4.5 availability figure
- [ ] FSD §3.x.5 classification → §6.3.1
- [ ] Every FSD §1.4 / §3.x.1.3 known issue → §2.2, §5.x.5, or §5.x.10.2
- [ ] FSD §1.3 Horizon rating reflected in §9.1 / §13 where RED or AMBER
- [ ] Every mapping document referenced by the Manifest → linked in §4.1.2
