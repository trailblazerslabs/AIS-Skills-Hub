# TSD Diagram Conventions

> **UPDATE 2026-10-02 (reviewer comments on EAII-536..541):** (1) the §5.x.2.2 **Process Flow** is the *simple* style of the approved EAII-374 process diagram (coloured boxes, no icons, no step circles, no legend) built by `../tools/diagrams/build_simple_flow.py`; the numbered step circles, SMC dots and legend rules in this file now apply to the icon-style pages only. (2) **§2 Scope has no image**: the `Interface Scope Overview` page is no longer produced. **UPDATE 2026-10-03:** (3) pages that include an APIM call show the OAuth 2.0 identity provider node with a "get token" arrow from the caller and a "validate token" arrow from APIM (sequence diagrams: an IdP participant with the token request and the key fetch); (4) a separate ingestion interface has its own process-flow page and its own sequence diagram, named `EAII-XXX Process Flow` / `EAII-XXX Sequence` until the id is assigned.

> **STATUS 2026-10-02 — the "N2 style" in this file is superseded.** The approved diagrams in 297/304/374/514 do
> **not** use the pastel N2 palette described below; they use embedded/bundled Azure icons, dashed `#0066CC` 2px
> nested containers, magenta `#ce3bae` resource names, blue `#2395FF` numbered step circles, dark-red `#990000` SMC
> observation dots, black/green/red arrows and dashed boxes around external systems. That style - and the exact icon
> inventory - is implemented in `../tools/diagrams/` (`icons.json`, `build_drawio.py`, `lint_drawio.py`,
> `render_drawio.py`, `SPEC.md`). Use those tools; the sections below are kept as history and for the numbered-step,
> page-naming (§2), edge-label (§5.3) and environment-token (§9) rules, which still apply.
>
> Also corrected: the claim that the draw.io Desktop CLI cannot render embedded data-URI images or bundled
> `img/lib/...` icons is **false** for the approved files (verified by rendering all pages of 297/304/374/514); the real
> failure mode was icon paths that do not exist (e.g. `azure2/general/Cloud.svg`). Every icon in `icons.json`
> is proven to render (`render_drawio.py --icon-test`).

Derived from 8 `.drawio` files / 26 pages supplied as the approved diagram corpus
(`reference-corpus/source/diagrams/`). Per-page XML dumps are in
`reference-corpus/_analysis/drawio/`.

---

## 1. The two styles in the corpus — use N2

| | **N2 style (USE THIS)** | Legacy image style (do not use for new work) |
|---|---|---|
| Files | `EAII-289-AD-N2`, `EAII-289-ND-N2`, `EAII-289-ProcessFlow`, `EAII-333-AD-N2` | `EAII-284…`, `EAII-297`, `EAII-304`, `EAII-514-updated-1` |
| Icons | `img/lib/azure2/**` SVG references | base64 data-URI images embedded per shape |
| Page size | 11–35 KB | 25–265 KB per page (1.7 MB total for one file) |
| Palette | Consistent pastel system (§3) | Ad-hoc; `fillColor=none` with vendor-brand icons |
| Icon libraries | Azure2 only, plus 2 non-Azure exceptions (§4) | Mixed AWS / Azure / SAP / Alibaba / Kubernetes |
| Structure | Explicit Subscription → RSG → VNet → Subnet nesting | Flat with decorative icons |

**Rule: generate all new diagrams in N2 style.** It is compact, diffable, renders without embedded
binaries, and encodes the Metcash subscription/network topology explicitly.

Start from the templates:

| Slot | Template |
|---|---|
| §6.1 Physical Architecture | `templates/diagrams/architecture-diagram.template.drawio` |
| §6.2 Network Connectivity | `templates/diagrams/network-diagram.template.drawio` |
| §5.x.2.2 Process Flow | `../tools/diagrams/build_simple_flow.py` (simple style) |
| All three in one file + §7.1 Communication | `templates/diagrams/architecture-network-communication.template.drawio` |

---

## 1a. Alternative style discovered in production — 4-lane swimlane (verify before defaulting to N2)

A genuine human-authored, approved production TSD (EAII-374, STIBO→PE) was found to use a
**different, simpler style** than any of the 8 corpus files above — not represented in the
corpus at the time N2 was selected as "the" standard. Treat N2 as the default only until this is
resolved; **ask the user, or check for a same-domain/recent sibling interface, before assuming N2
is still current practice.**

Swimlane style characteristics:

- 4 horizontal lanes, left→right: **External / Source**, **Azure Hub / API Layer**,
## 1a. RETRACTED — swimlane style claim was a misread; real evidence points to nested containment

**Earlier revision of this doc claimed a "4-lane swimlane" style was found in a human-authored
EAII-374 TSD. That was wrong — it was inferred from viewing a flattened PNG image embedded in the
Word/Confluence export, not the actual diagram source, and the description of "lanes" does not
match the real source file.** The actual hand-drawn `.drawio` source files for this exact
interface were later found at `Doc/Temp/374_Network Diagram.drawio` and
`Doc/Temp/374_Process Diagram_v1.drawio` (2026-09 discovery). Ground truth from that source:

- **Nested dashed-rectangle containment** (VNet/Resource-Group-style boxes), the same family as
  N2 — NOT swimlanes. There is no lane structure, no legend, no solid/dashed sync-vs-async edge
  convention in the real file.
- Icons are **base64 data-URI embedded PNGs** per shape (the corpus's "legacy image style", e.g.
  `EAII-297`) rather than N2's `img/lib/azure2/**` SVG path references. **Do not treat "legacy
  image style" as universally deprecated** — it is demonstrably still used in at least one real,
  recent production diagram. Prefer N2 for maintainability (diffable, no embedded binaries) but
  do not assume it is the only acceptable style without checking.
- Confirms: all four STIBO operations (App Gateway → 4 named APIM operations) converge into
  **one single Logic App** (labelled `MetProductERPServiceOperations` in the diagram) — corroborates
  the "one workflow, internal switch" model over "one workflow per operation".
- **Do not trust resource names shown in a draft/found diagram over the approved Word/Confluence
  TSD text.** This particular `.drawio` uses stale/placeholder names (`met-askross-{env}-ae-logic`,
  `b2b-{env}-ae-kv01`) that do **not** match the same interface's approved TSD text
  (`t3-met-data-metproducts-{env}-ae-logic`, `t3data{env}ae1kv01`) — the diagram was very likely a
  draft/template reused from another interface and not fully relabelled. **When a diagram source
  and the accompanying prose document disagree on a resource name, the point of accompany the same
  approval package's rendered/prose TSD is more likely authoritative; flag the conflict to the user
  rather than silently picking one.**
- The APIM operation names shown in the diagram (`ItemSupplierChange`, `ListTTGForVendor`,
  `updateVendorStatus`, `validatePackChange`) are the internal `X-Operation-Type` routing values,
  not necessarily the final public REST resource paths — confirm the actual public path from the
  TSD's Service Operations table (§5.1.6.3.5), not from the diagram alone.

**Net guidance:** default to **N2-style nested containment** (§1) for new diagrams. Treat any
"simpler flat/swimlane" style claim as unverified unless corroborated by an actual `.drawio` source
file (not a flattened image) for a directly comparable, recent, approved interface.

---

## 2. Page naming and file organisation

Corpus page names, in order:

| Order | Page name | TSD section |
|---|---|---|
| 1 | `System Context` (simple block diagram: participating applications/systems and high-level interaction only; no Azure detail) *(`Interface Scope Overview` is no longer produced: §2 Scope is text only)* | §4.1 |
| 2 | `{EAII-nnn} Process Flow` or `Process Flow Design` | §5.x.2.2 |
| 3 | `Architecture Diagram` | §6.1 |
| 4 | `Network Diagram` | §6.2 |
| 5 | `Communication Diagram` | §7.1 |

**One `.drawio` file per TSD, multi-page** is the dominant pattern (5 of 8 files). For
multi-interface TSDs, add one Process Flow page per interface named `{EAII-nnn} Process Flow`.

Use `Communication Diagram` (space, not hyphen) — the corpus has both, space form is in the
newer N2 files.

---

## 3. Standard palette

### 3.1 Containment layers (architecture and network diagrams)

Nesting order is **Subscription → Resource Group → VNet → Subnet → resource icon**.
Every container gets a matching Azure2 icon badge at its top-left and a separate `text` label cell.

| Layer | fillColor | strokeColor | strokeWidth | dashed | Label colour |
|---|---|---|---|---|---|
| Subscription — HUB | `#dae8fc` | `#1a5276` | 2 | no | `#1a5276` |
| Subscription — AIS | `#f4ecf7` | `#7d3c98` | 2 | no | `#7d3c98` |
| Resource Group — network | `#fef9e7` | `#b7950b` | 1 | yes | `#b7950b` |
| Resource Group — generic | `#f5f5f5` or `#f9f9f9` | `#666666` / `#999999` | 1 | yes | `#555555` |
| Virtual Network | `#e8f5e9` | `#2e7d32` | 1 | yes | `#2e7d32` |
| Subnet | `#ffffff` | `#0066CC` | 1 | yes | `#0066CC` |
| External / on-premises source | `#fef9e7` | `#b7950b` | 2 | no | — |

Container style stem:
`rounded=1;whiteSpace=wrap;html=1;fillColor=…;strokeColor=…;strokeWidth=…;dashed=…;verticalAlign=top;align=left;spacingLeft=10;spacingTop=5;arcSize=5;`

Resource icon labels use font colour `#6C3483`, bold resource name, then a smaller
`font-size:7px`–`8px` line for IPs or descriptive detail.

### 3.2 Zone boxes (process flow diagrams)

Actor zones are rounded, dashed with `dashPattern=12 12`, and carry a separate `text` label cell
plus an Azure2 icon.

| Zone | fillColor | strokeColor |
|---|---|---|
| Consumer / source system | `#dae8fc` | `#6c8ebf` |
| Integration platform (APIM / Function / Logic App) | `#fff2cc` | `#d6b656` |
| Target / external system | `#d5e8d4` | `#82b366` |
| SMC | `#e6d0de` | `#996185` |
| Key Vault | `#f0f0f0` | `#666666` |

Inner detail boxes (solid, not dashed):

| Purpose | fillColor | strokeColor |
|---|---|---|
| Policy / processing step | `#f5f5f5` | `#666666` |
| Backend call | `#dae8fc` | `#6c8ebf` |
| Operations list | `#e8f5e9` | `#2e7d32` |
| Error / on-error policy | `#f8cecc` | `#b85450` |
| Note callout (`shape=note;size=10`) | `#fff2cc` | `#d6b656` |
| Legend / SLA box | `#ffffff` | `#000000` |

### 3.3 Title bar

Every page opens with a full-width title cell:

```
style="text;html=1;align=center;verticalAlign=middle;whiteSpace=wrap;rounded=0;fillColor=#dae8fc;strokeColor=#6c8ebf;"
value="<b><font style='font-size: 16px;'>{EAII-nnn} - {Interface} - {Diagram Type}</font></b>"
```

---

## 4. Icons

Azure resources use Azure2 SVG references — **never embedded data URIs**.

| Resource | Icon path |
|---|---|
| Resource Group | `img/lib/azure2/general/Resource_Groups.svg` |
| Subscription | `img/lib/azure2/general/Subscriptions.svg` |
| Virtual Network | `img/lib/azure2/networking/Virtual_Networks.svg` |
| Subnet | `img/lib/azure2/networking/Subnet.svg` |
| Application Gateway | `img/lib/azure2/networking/Application_Gateways.svg` |
| API Management | `img/lib/azure2/integration/API_Management_Services.svg` |
| Key Vault | `img/lib/azure2/security/Key_Vaults.svg` |
| Application Insights | `img/lib/azure2/devops/Application_Insights.svg` |
| Function App | `img/lib/azure2/compute/Function_Apps.svg` |
| Storage Account | `img/lib/azure2/storage/Storage_Accounts.svg` |
| Service Bus (namespace) | `img/lib/azure2/integration/Service_Bus.svg` |
| Event Grid (subscription/topic) | `img/lib/azure2/integration/Event_Grid_Subscriptions.svg` |
| App Service Plan | `img/lib/azure2/app_services/App_Service_Plans.svg` |
| Consumer workstation | `img/lib/azure2/other/Workstation.svg` |

**There is no `img/lib/azure2/general/Cloud.svg`.** An earlier version of this table listed it —
verified false by extracting the real file index from the installed draw.io desktop app's
`app.asar` bundle (581 real `azure2/**` paths, no `Cloud.svg` among them); using it produces a
broken "missing image" placeholder in every renderer, silently. **External / non-Azure enterprise
systems (PE/AS400, GoAnywhere MFT, Stibo, SMC, or any other third-party/on-prem system) do not get
an Azure icon at all** — use the plain colored box from §3.2 "Zone boxes" (or the container-layer
row "External / on-premises source" in §3.1), text label only, no `image=` style property. This is
the corpus's own convention, confirmed directly in `EAII-284`, `EAII-297`, `EAII-514`, and
`EAII-333`'s real `.drawio` source files — none of them put an icon on these boxes.

Icon shape stem:
`image;aspect=fixed;html=1;points=[];align=center;fontSize=9;image={path};verticalLabelPosition=bottom;verticalAlign=top;`

Container badge icons are 22×22 with no label; resource icons are 40–50 px with a label below.

`img/lib/azure2/**` is draw.io's own bundled Azure2 stencil library — these paths resolve
internally inside any standard draw.io install/web app (`app.diagrams.net`) and are **not**
external or unverified dependencies. There is no local `azure2-complete-catalog.txt` file in
this workspace — do not block on trying to find or verify against one. The path table above was
extracted directly from a real approved corpus `.drawio` file (`TSD-EAII-284_283_282_385`) and
can be trusted as-is; when a resource type isn't in this table, use the same
`img/lib/azure2/<category>/<Name>.svg` naming convention (category names match the Azure2 stencil
shelf categories: `general`, `compute`, `storage`, `networking`, `security`, `integration`,
`app_services`, `devops`, `databases`, `web`, `other`) and confirm it visually renders during the
Step 6.8 browser render check rather than second-guessing the path format itself.

Also built into draw.io (not a plain icon, but a stencil shape — use where a plain icon doesn't
fit, e.g. a Service Bus topic/subscription glyph):
`shape=mxgraph.azure.service_bus_topics_and_subscriptions;fillColor=#00BEF2;strokeColor=none;`

Two sanctioned non-Azure2 shapes appear in the N2 corpus:

| Purpose | Style |
|---|---|
| On-premises system / user | `shape=mxgraph.kubernetes.icon2;prIcon=user;fillColor=#2875E2;strokeColor=#ffffff` |
| External SaaS cloud (only if a cloud glyph is truly wanted alongside the box) | `shape=mxgraph.azure.cloud;fillColor=#00BEF2;strokeColor=none` |

Both of these are **native mxgraph stencil shapes**, not `image=` file-path references — they are
bundled directly in draw.io's shape registry and always render, unlike a broken/nonexistent
`img/lib/...svg` path. Default to the plain colored box (no shape at all) per §3.2 first; only
reach for `mxgraph.azure.cloud` if the diagram specifically calls for a cloud glyph.

SMC has no standard icon — the corpus uses a small embedded SVG. Reuse the SMC cell verbatim from
`templates/diagrams/architecture-network-communication.template.drawio` rather than re-creating it.

---

## 4a. Layout and spacing (visual QA — read this before finalizing any diagram)

An XML-valid `.drawio` file (per `inspect_drawio.py`) can still render poorly. These are real
issues found only by actually opening the file in a renderer (see Step 6.8 in SKILL.md) and
looking at it — do not skip that check:

- Leave at least 20–30px of clear space between an icon's label (especially
  `labelPosition=right` or `verticalLabelPosition=bottom` labels) and the next neighboring icon
  or edge. Two icons placed edge-to-edge with outward-facing labels will visually collide.
- Every dashed containment/grouping box (subscription, resource group, VNet, subnet, function
  group, etc.) must be sized with enough margin to fully enclose the icons and labels nested
  inside it — measure the actual rendered content bounds, don't estimate from geometry alone.
- Keep every element — including "External / SaaS" target-system boxes and the legend — within
  the page's `pageWidth`/`pageHeight`. An element placed beyond the page bounds may still parse
  fine in XML but will be cropped or missing from a normal export, print, or screenshot.
- Route edges to avoid doubling back through unrelated boxes; prefer a single clean orthogonal
  path. If an edge must cross the canvas (e.g., Function App → external target on the far right),
  give it explicit waypoints that travel through open space, not through other containers.
- After building or editing a diagram, render it (Step 6.8) and fix any overlap/containment/
  off-page issues found before considering the diagram done — `inspect_drawio.py`'s vertex/edge
  counts passing is not sufficient sign-off.

---

## 5. Edges

All edges use `edgeStyle=orthogonalEdgeStyle;rounded=1;orthogonalLoop=1;jettySize=auto;html=1`.

### 5.1 Process flow edge semantics

| Flow | strokeColor | Width | Dash |
|---|---|---|---|
| Request | `#0050ef` | 2 | solid |
| Response | `#82b366` | 2 | `dashed=1` |
| Audit / monitoring (SMC) | `#996185` | 1 | `dashed=1;dashPattern=8 4` |
| Credential access (Key Vault) | `#666666` | 1 | `dashed=1;dashPattern=8 4 1 4` |

### 5.2 Network / architecture edge semantics

| Flow | strokeColor | Width | Notes |
|---|---|---|---|
| External inbound | `#b7950b` | 2 | `startArrow=classic` for bidirectional |
| Internal Azure-to-Azure | `#2e7d32` | 2 | |
| External outbound | `#c0392b` | 2 | |
| Telemetry | `#6C3483` | 1 | `dashed=1;dashPattern=3 3` |
| Intra-subnet link | `#0066CC` | 1 | |

### 5.3 Edge labels

Network and architecture edges are labelled with **protocol and port**:

```
<b>SOAP/HTTPS</b><br>Port 443
<b>REST/HTTPS (mTLS)</b><br>Port 443
```

Font size 8–9, coloured to match the edge stroke. Labels are child `edgeLabel` cells with an
`mxPoint` offset — this is the one place the corpus deviates from the `fsd-diagrams` "inline
labels only" rule, and it is acceptable here because the offset is explicit.

---

## 6. Numbered step markers (process flow only)

Sequential steps are `ellipse` markers with a separate `text` label cell beside them:

| Direction | Style |
|---|---|
| Request steps | `ellipse;whiteSpace=wrap;html=1;aspect=fixed;fillColor=#0050ef;fontColor=#ffffff;strokeColor=#001DBC;fontSize=12;` |
| Response steps | `ellipse;whiteSpace=wrap;html=1;aspect=fixed;fillColor=#82b366;fontColor=#ffffff;strokeColor=#36712e;fontSize=12;` |

The numbers must correspond 1:1 to the numbered steps in TSD §5.x.2.1. **This breaks silently
when a diagram is reused or restored rather than built fresh** — e.g. restoring a prior commit's
`.drawio`, or copying a template from a different interface — because the restored diagram keeps
whatever step count it originally had, which may not match a since-rewritten prose list (found on
EAII-529: a restored diagram had 5 markers against a from-scratch-regenerated 9-step prose list).
Always re-count markers against the *current* §5.x.2.1 text, every time a diagram is reused, not
just when it's built new. Steps with no distinct external edge of their own (e.g. an in-process
classification/routing step, or a credential/token-acquisition step resolved via an existing
edge to Key Vault) still get their own marker — place it near the relevant icon or along the
existing edge rather than inventing a new edge, so the count stays 1:1 without cluttering the
layout.

---

## 7. Mandatory page furniture

Every **process flow** page carries, bottom-right:

1. **SLA / volume box** — `Service Level: {tier} ({n}%)`, `Volume: {profile}`, white fill, black stroke
2. **Legend box** — white fill, black stroke, containing:
   - blue ellipse `N` → "Sequential Process Step (Request)"
   - green ellipse `N` → "Sequential Process Step (Response)"
   - blue solid arrow → "Request Flow"
   - green dashed arrow → "Response Flow"
   - purple dashed arrow → "Audit/Monitoring Flow (SMC)"
   - grey dash-dot arrow → "Credential Access (Key Vault)"

Include only the legend rows that actually appear on the page.

---

## 8. Canvas and model settings

```xml
<mxGraphModel dx="1888" dy="931" grid="0" gridSize="10" guides="1" tooltips="1"
              connect="1" arrows="1" fold="1" page="0" pageScale="1"
              pageWidth="1600" pageHeight="900" math="0" shadow="0">
```

- `grid="0"` — grid off
- `pageWidth="1600" pageHeight="900"` for process flow and architecture; widen for network
- Wrap in `<mxfile host="..."><diagram name="..." id="...">…</diagram></mxfile>`
- Pages may be stored uncompressed (readable `mxGraphModel`) or deflate+base64 — either opens
  correctly; write uncompressed so diffs are reviewable

---

## 9. Environment tokens in diagrams

Diagrams are **environment-generic**: label resources with `{env}` rather than a concrete
environment, e.g. `t3-met-core-{env}-ae1-apim`, `t3data{env}ae1kv01`,
`t2-met-ais-{env}-ae1-net-01`. Concrete per-environment values belong in TSD §6.1.1 / §6.6 tables,
not in the diagram.

Exception: fixed platform IPs are shown literally (`Public: 20.42.203.106`,
`Private: 10.247.1.71`) because they do not vary by the `{env}` token within a tier.

---

## 10. Pre-flight checklist

- [ ] N2 style used; no embedded base64 data URIs except the sanctioned SMC icon
- [ ] Every Azure icon path uses the `img/lib/azure2/<category>/<Name>.svg` convention (§4) —
      these are draw.io's own bundled icons, not external files needing separate verification
- [ ] Containment nesting complete: Subscription → RSG → VNet → Subnet → resource
- [ ] All resource labels use `{env}` tokens matching §6.1.1
- [ ] Every edge has `edgeStyle=orthogonalEdgeStyle`
- [ ] Every network/architecture edge labelled with protocol + port
- [ ] Process flow step numbers match §5.x.2.1 numbered steps
- [ ] Legend and SLA boxes present on process flow pages
- [ ] Page names match the §2 convention
- [ ] No orphan shapes — every resource icon has at least one edge or sits inside a container
- [ ] File is valid XML, no UTF-8 BOM
- [ ] **Diagram actually rendered and visually inspected (SKILL.md Step 6.8)** — no overlapping
      labels/icons, no containment box that fails to enclose its contents, no element or edge
      positioned outside the page bounds. `inspect_drawio.py` passing is necessary but not
      sufficient — it does not check any of this.
- [ ] No mojibake in any label (e.g. `ÔÇö` instead of `—`) — a symptom of a codepage-unsafe
      clipboard tool corrupting the XML on its way into the browser (SKILL.md Step 6.8.2); compare
      non-ASCII character counts between the source `.drawio` and what actually rendered
- [ ] Exported to PNG **from the Step 6.8 live browser session** (`File → Export as → PNG...`,
      200% zoom) and embedded in the TSD with a relative path — not from the desktop CLI (SKILL.md
      Step 5 explains why the CLI export is unreliable and must not be the deliverable)
