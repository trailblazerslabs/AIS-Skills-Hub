# Known Defects in the Approved TSDs

The approved TSDs are the **structural and design authority** (section layout, table shapes, naming,
infrastructure facts, how an architect turns an FSD into a design). They are not defect-free. When
generating, take the structure and the decisions, **not** the defects below. Found 2026-10-02 by tracing
EAII-374 and the revised EAII-304 from their FSDs, Mapping Manifests and (374) walkthrough transcript.

## EAII-374 STIBO to PE (`TSD-EAII-374`)

| # | Where | Defect | What to do instead |
|---|---|---|---|
| 1 | §4.2 NFR table | States 99.9% availability, 100 requests/min peak, 20 concurrent. The FSD (§3.1.4, §3.1.6) says Silver 95% and marks scalability/performance testing "N" | Every NFR figure must trace to the FSD. Unknown = `*<To be confirmed>*`, never invented |
| 2 | §3.2 patterns table | Copied from EAII-304: mentions liquor suppliers, an "upload REST endpoint", Azure Functions, Event Grid and Service Bus - none of which exist in 374 | Write each pattern row for this interface, naming its components. A noun from another interface is a defect |
| 3 | §3.1 | Bullet list instead of the IDP-001..006 table with a per-row "why it applies" | Use the IDP table |
| 4 | §5.1 heading | "SOH/SOO/TTG Product Information" - the legacy TIBCO folder name, not the interface title | Use the FSD §3.1 title |
| 5 | §10, §12 | Template placeholders left in (`Capture any specific disaster recovery requirements...`, empty table) | Fill from FSD §3.x.4 (Silver DR) or state the standard-platform position explicitly |
| 6 | §5.1.7 | Two subsections numbered 5.1.7.1 (Integration Onboarding, SMC Load Estimations) | Number the second 5.x.7.2 |
| 7 | §6.3.2 | No Key Vault Secrets Inventory although a DB2 credential secret is read from Key Vault | Inventory every secret *name* |
| 8 | §6.4 | DV1 and ST1 both `IDSCTLP24`/`MDMUSERP24`; component list (§5.1.6.1) shows `IDSCTLP25` for the same environments | Cross-check §5.x.6.1 against §6.4 - same fact, one value |
| 9 | §5.1.10.2 vs §5.1.6.3.5 | Test cases use the full path `/eis/pe/v1/api/item-supplier-changes`; the Service Operations table lists only `/item-supplier-changes` and the base path is never stated once | State base path + operation path once in §5.x.6.3.5 and use that exact string in tests and diagrams |
| 10 | Contract | FSD says "preserve the API contract"; the TSD changes every public path and records it only as a §13 assumption | State the contract change as a Design Consideration with the consumer-impact owner |

Good decisions to **reuse** from 374: one Logic App with an internal switch on operation type (walkthrough
Turn 87); DB2 built-in connector over the existing VNet path - no On-premises Data Gateway; separate
business-result rows (HTTP 200, non-zero return code) from transport-exception rows in §5.x.6.3.3;
27 coded exceptions `EAII374-nnn` with `-099` catch-all.

## EAII-304 Liquor Suppliers to EIM (revised `TSD-EAII-304`)

| # | Where | Defect | What to do instead |
|---|---|---|---|
| 1 | §5.1.6.3.6 | Names an "Upload Orchestrator Logic App"; the §5.1.2.1 design has APIM calling the shared `UploadBlob` Function directly | Component names must match across §5, §6, diagrams |
| 2 | §5.1.6.2 vs §5.1.6.3 | Two services listed (Upload, Translation) but only the Upload service has a `5.1.6.3` block | One block per listed service, or the collapsed form for >1 interface |
| 3 | §5.1.2.1 step 7 | Says "uploads both the PSV file" - the trigger file was dropped but the sentence still implies two files | Re-read prose after a design change; the FSD's trigger file must be an explicit decision |
| 4 | §5.1.6.3.3 | Codes `HTTP-401`, `IBADIRECTS-ERR-UNHANDLED` instead of the corpus `EAII304-nnn` scheme; FSD codes `IBADIRECTS-ERR-001..004` dropped without a note | Use `EAII<nnn>-<seq>`; carry or retire each FSD code explicitly |
| 5 | §5.1.7.1 | Two subsections numbered 5.1.7.1 | Number the second 5.x.7.2 |
| 6 | §6.5 SENS table | Logic App named `t3-met-ibadirects-{env}-ae-logic` while §5.1.6.1/RBAC use `t3-met-b2b-ibadirects-{env}-ae-logic` | One spelling everywhere (gate 6.3) |
| 7 | §6.5 | PRD spoke VNet written `pr1` in 304 and `prd` in 374 | Known corpus conflict - confirm with Enterprise Networking |
| 8 | §6.5 API URLs | Display text and link target disagree (all point at `/eis/azureblobmgmt/v1`) | Verify link targets |
| 9 | §4.1.1 | FSD "Proposed High Level Architecture" image used; no TIBCO-to-AIS delta explanation | Fine as precedent; add the delta in §5.x.5 |
| 10 | Retries | FSD: 10 storage retries; TSD: 3 retries + Service Bus delivery count - override not recorded as a Design Consideration | Record every override of an FSD figure with its rationale |

Good decisions to **reuse** from 304: reuse of the shared `UploadBlob` Function (EAII-367) instead of a new
upload component; Service Bus **queue** (not topic) when there is exactly one consumer; the complete
GoAnywhere requirements block (§5.1.4.1) with the SMC GoAnywhere onboarding table; per-folder retention table
with lifecycle-management rule steps in §8.5; explicit synchronous-vs-asynchronous coordination in §5.1.3.

## Values that were never in the FSD (why intake must ask)

| Fact | In FSD? | In approved TSD? |
|---|---|---|
| Storage account name | no (304, 374) | 304: 14 places |
| Container / folder paths | partly (304 FSD: `IBADirects/in|toeim|archive|error`) | yes, spelled `ToEIM` |
| Repository name | no | yes (component list, §9.3) |
| Public API path | legacy path only | changed |
| Service Bus queue/topic name | no | yes |
| GoAnywhere poll interval, paths, naming, SMC fields | assumption only ("to be confirmed") | full table |
| DB2 host / schema / user per environment | no | yes (§6.4) |
| SMC business process / application names | no | yes (§5.x.7.1) |

These drive `tools/intake/required-facts.json`.
