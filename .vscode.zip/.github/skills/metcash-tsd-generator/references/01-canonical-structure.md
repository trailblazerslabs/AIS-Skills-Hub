# TSD Canonical Structure

Derived from 7 approved Metcash TSDs. Frequency shows how many of the 7 contain the section.

## Rules

- **Mandatory** sections appear in every TSD, in this order, with this numbering. Never omit,
  never reorder, never renumber.
- **Conditional** sections are added when the trigger condition is met. They are an evolution of
  the base template and appear in the newest/richest TSDs — treat them as *expected* for any new
  TSD unless the trigger is genuinely absent.
- `NA` is an acceptable value for a mandatory section. An empty section is not.

---

## Front matter (before §1)

Every TSD opens with:

1. `# Technical Specification - <IDs> - <Source> to <Target>`
2. Table of Contents
3. `| **TSD Author** | |` table
4. Document Approver table — 4 fixed roles:

| Role | Frequency |
|---|---|
| Integration Platform Representative | 7/7 |
| Integration Platform Operations | 7/7 |
| Solution Architect | 7/7 |
| Test Manager | 7/7 |

---

## §1 Document Overview — 7/7

| § | Title | Freq | Notes |
|---|---|---|---|
| 1.1 | Background | 7/7 | Must state migration-vs-net-new and name the legacy platform. Overview only: one short paragraph, no process, mapping, volume or design detail (written once in §4.1 / §5 / §6) |
| 1.2 | Document Purpose | 7/7 | One paragraph; bolds the service name, source, target, and AIS component |
| 1.3 | Glossary | 7/7 | Table `Term \| Description`; 10–25 rows; alphabetical |

## §2 Scope — 7/7

| § | Title | Freq | Notes |
|---|---|---|---|
| 2.1 | In Scope | 7/7 | Bulleted technical work items, each naming its AIS component |
| 2.2 | Out of Scope | 7/7 | Includes "Known Issue NOT addressed" lines where applicable |

An unnumbered scope-overview diagram may be embedded between §2 and §2.1 (2/7).

## §3 Compliance — 7/7

| § | Title | Freq | Notes |
|---|---|---|---|
| 3.1 | Architecture Principles | 7/7 | Link + **IDP table** (4/7). Table form is the better pattern. |
| 3.2 | Standards, Guidelines and Patterns | 7/7 | Link + **Patterns table** (4/7) + 4 standards sub-tables (2/7) |

§3.2 sub-tables, when present (unnumbered, bold-headed):
`Naming Standards`, `Service Bus — Topic/Subscriptions`, `Security Controls`,
`Environment Segregation`, `Error Handling and Monitoring`.

## §4 Requirements Overview — 7/7

| § | Title | Freq | Notes |
|---|---|---|---|
| 4.1 | Business Process Requirement and Integration | 7/7 | Opens the end-to-end system view with the simple `System Context` block diagram, then 2-4 sentences of business process that do not repeat §1.1 |
| 4.1.1 | Process Diagram from FSD | 6/7 | Embed the FSD's diagram; do not redraw |
| 4.1.2 | Functional Specification Document | 6/7 | Table `Title \| Link`; add Mapping doc rows |
| 4.2 | Technical standard and requirements | 7/7 | Title case varies; keep template casing |
| 4.3 | Required Components | 7/7 | Bulleted (4/7) or table `Component \| Purpose` (3/7) — prefer table |
| 4.4 | Environmental Requirement | 7/7 | Bulleted (5/7) or table `Label \| Suffix \| Purpose` (2/7) |
| **4.5** | **Non-Functional Requirements** | **1/7** | **Conditional** — include when FSD §3.x.6 has quantified NFRs |
| **4.5.1** | **Retry Strategy** | **1/7** | **Conditional** — include with §4.5; must state rationale |

## §5 Integration Overview and Implementation — 7/7

**§5.x is duplicated per interface.** Corpus range: 1 to 4 interface blocks per TSD.
Heading format: `## 5.x <EAII-nnn> - <Interface Description>`.

| § | Title | Freq | Notes |
|---|---|---|---|
| 5.x.1 | As-is Process(es) | 7/7 | |
| 5.x.1.1 | Description of Process(es) | 7/7 | Legacy artefact names permitted here only — for a migration, also name the TIBCO **source repo** and entry-point file(s) (from Step 0.6's discovery), not just the artefact names |
| 5.x.1.2 | Process Flow Diagram | 6/7 | Optional if no legacy diagram exists |
| 5.x.2 | Proposed Process(es) | 7/7 | |
| 5.x.2.1 | Description of Process(es) | 7/7 | **Numbered steps, each naming its Azure component** |
| 5.x.2.2 | Process Flow Diagram | 7/7 | |
| 5.x.2.3 | Sequence Diagram | 7/7 | |
| 5.x.2.4 | PlantUML | 7/7 | Inline code block mirroring 5.x.2.3 |
| 5.x.3 | Coordination | 7/7 | |
| 5.x.3.1 | Transaction Boundaries | 6/7 | |
| 5.x.3.2 | State Management | 6/7 | |
| 5.x.4 | GoAnywhere Requirements | 6/7 | Description only, no field table (MFT-team owned, out of AIS scope): hand-over location, file name contract, SMC ID in the file name used as `ParentObservationID`. `N/A` when MFT not used. 1/7 replaces with `API Endpoint Information` |
| 5.x.5 | Design Considerations | 7/7 | **Numbered decisions with rationale** — highest-value section |
| 5.x.6 | Service High Level Design | 7/7 | |
| 5.x.6.1 | Component List | 7/7 | Two column sets — see below |
| 5.x.6.2 | Services | 7/7 | Named services/functions/workflows with one-line responsibility |
| 5.x.6.3 | *Service block* | 7/7 | Two shapes — see below |
| 5.x.7 | SMC Onboarding | 7/7 | |
| 5.x.7.1 | Integration Onboarding | 7/7 | Field/Value table — see SMC reference |
| 5.x.7.2 | SMC Load Estimations | 6/7 | Numbered `5.1.7.1` in 3/7 (a defect — use `5.x.7.2`) |
| 5.x.8 | Monitoring | 7/7 | Health probe, alert rules with thresholds + recipient, dashboard |
| 5.x.9 | Reporting | 7/7 | Usually `N/A - standard AIS platform reporting applies` |
| 5.x.10 | Integration and Testing Requirements | 7/7 | |
| 5.x.10.1 | Development and Integration Strategy | 7/7 | Verbatim boilerplate |
| 5.x.10.2 | Unit Testing | 9/9 | **TC-nnn rows in ADO import shape**: `ID \| Work Item Type \| Title \| Step Action \| Step Expected \| FSD ref` (374 shape + traceability column). Older corpus TSDs used `ADO Test Case ID \| Description \| Location Of Sample Messages` - do not use for new work |

### §5.x.6.1 Component List — two accepted column sets

**A. Interface-centric** (APIM / Logic App archetypes):

`Interface ID | Process | Component | Component Type | Change Type | Repository`

**B. Resource-centric** (Function App archetype — richer, preferred for new work):

`Component | Azure Resource Provider | Purpose`

### §5.x.6.3 — two accepted shapes

**Full per-service block** (4/7) — heading is the *service name*, e.g. `5.1.6.3 *EAII-333 Payment Capture API*`:

| § | Title |
|---|---|
| 5.x.6.3.1 | Logging |
| 5.x.6.3.2 | Audit |
| 5.x.6.3.3 | Exceptions |
| 5.x.6.3.4 | Service consumers |
| 5.x.6.3.5 | Service Operations |
| 5.x.6.3.6 | Service Provider |
| 5.x.6.3.7 | Communications Data Structures |
| 5.x.6.3.8 | Input/Output |
| 5.x.6.3.9 | Fulfillment Services |

**Collapsed block** (3/7) — heading `5.x.6.3 Audit, Logging & Exceptions`, with only
`.1 Logging`, `.2 Audit`, `.3 Exceptions` (+ occasionally `.4 Service Consumers`,
`.5 Input / Output`). Used when the TSD covers several interfaces and the full block would
repeat 4×.

**Rule:** single-interface TSD → full block. Multi-interface TSD → collapsed block, with
`5.x.6.2.1 Communication Data Structure` carrying the schema/mapping detail.

## §6 Architecture Overview — 7/7

| § | Title | Freq | Notes |
|---|---|---|---|
| 6.1 | Physical Architecture Diagram | 6/7 | |
| **6.1.1** | **Azure Resource Inventory** | **1/7** | **Conditional — include always for new work.** Per-env resource name matrix |
| 6.2 | Network Connectivity | 7/7 | Diagram + connection table |
| **6.2.1** | **VNet and Subnet Reference** | **2/7** | **Conditional — include always** |
| **6.2.2** | **Component Network Table** | **2/7** | **Conditional — include always** |
| 6.3 | Security | 7/7 | Bulleted control statements |
| 6.3.1 | Data Handling and Encryption | 4/7 | 1/7 uses `Component Connection Authentication` at 6.3.1 |
| **6.3.2** | **Key Vault Secrets Inventory** | **1/7** | **Conditional — include when secrets exist** |
| **6.3.3** | **Identity Inventory — Managed Identity RBAC** | **1/7** | **Conditional — include when MI used.** Table columns MUST be `Source \| Target \| Identity \| RBAC Role` preceded by the literal bold line `**Complete RBAC Assignments (`Microsoft.Authorization/roleAssignments`):**` — verbatim across every corpus TSD that has this section (EAII-297, -304, -514, -289). Every Key Vault in §6.3.2 needs a matching row here. |
| **6.3.4** | **External Dependency Ownership and SLA** | **1/7** | **Conditional — include when external systems exist** |
| 6.4 | Infrastructure Support | 7/7 | Often `NA`/"Standard AIS platform infrastructure support applies", but when **this interface's own FSD** documents source/target-system connectivity details (AS/400 DB2 schema+host+username per env, mainframe LU, DB connection owner, etc.) transcribe them verbatim into an `Env \| Target \| Endpoint \| Resource Path` table — do not drop them as "not directly called by this interface". **Never transcribe such values from a screenshot/example shown for a DIFFERENT interface or as a formatting reference** — verify the exact values appear in `tsd-inputs/<this-interface>/converted/` before using them; if they don't, the section is `NA` for this interface (found wrong in EAII-529: AS/400 DB2 hostnames/schemas from another interface's TSD were mistakenly transcribed as this interface's own data). |
| 6.5 | Infrastructure Requirements | 7/7 | `Component \| Non-Prod \| Prod \| New/Existing` |
| **6.6** | **Infrastructure Resource Details** | **2/7** | **Conditional — include always.** Resource / RG / Subscription / VNet / Subnet / IP |

§6.5 and §6.6 additionally carry the standing network tables (App Gateway, APIM, AIS Spoke VNet,
SENS/HSENS subnets, Hub subnets) reproduced verbatim from
[03-naming-and-infrastructure.md](03-naming-and-infrastructure.md).

## §7 Communication Overview — 7/7

| § | Title | Freq |
|---|---|---|
| 7.1 | Communication Components | 7/7 |

Table shape `Component \| Source \| Destination \| Protocol \| Port \| Authentication`,
or per-environment base URL tables for API-exposed interfaces.

## §8 Data Architecture — 7/7

| § | Title | Freq | Typical value |
|---|---|---|---|
| 8.1 | Data Model | 7/7 | `NA` unless relational |
| 8.2 | Stored Procedures | 7/7 | `NA` |
| 8.3 | Stored Procedure Triggers | 7/7 | `NA` |
| 8.4 | Database Technical Specification | 7/7 | `NA` |
| 8.5 | Data Retention | 7/7 | |
| 8.5.1 | Data Retention Procedures | 6/7 | |
| 8.5.1.1 | Data storage and retention | 6/7 | Table `Data \| Location \| Retention` |
| 8.5.2 | Data Backup | 6/7 | |
| 8.5.3 | Data Destruction Procedures | 6/7 | |
| 8.5.3.1 | Data destruction metrics and timeframes | 5/7 | |
| 8.5.3.2 | State process for data/system destruction | 5/7 | |

## §9 Deployment and Monitoring Considerations — 7/7

| § | Title | Freq |
|---|---|---|
| 9.1 | Transition Period | 7/7 |
| 9.2 | Deployment Preference | 7/7 |
| 9.3 | Deployment Environment Migration | 7/7 | Boilerplate source-control statement + `metcash-ais-infrastructure` Bicep repo line, **plus a concrete repository recommendation for THIS interface's own code**: check `azure-devops-repository-pr`'s repo list and the corpus TSD for the same workload family (e.g. sibling interfaces sharing a workload name like `metproducts`) for an existing repo/shared-library to reuse before assuming a new repo is needed. Include the suggested branch name (`feature/{EAII-ID}-{description}`) and PR title format too. |

## §10–§15

| § | Title | Freq | Notes |
|---|---|---|---|
| 10 | Disaster Recovery | 7/7 | Drive from FSD §3.x.4 GSB tier |
| 11 | Support Documentation | 7/7 | Support handover links; include the editable multi-page I/O diagram source as a relative link and embed it as a packaged object in the Word export |
| 12 | Limitations and Constraints | 7/7 | Table `Sr. No \| Description \| Limitation/Constraint \| Remarks` |
| 13 | Assumptions | 7/7 | Numbered list, or `NA` |
| 14 | Reference Documents and Architecture | 7/7 | Bulleted links (4/7) or table `Document \| Link` (3/7) |
| **14.1** | **External Dependencies** | **1/7** | Conditional |
| 15 | TSD Approval Checklist | 6/7 | **Verbatim** 32-row checklist — see boilerplate reference |

---

## Known corpus defects — do not replicate

| Defect | Seen in | Correct form |
|---|---|---|
| `5.1.7.1 SMC Load Estimations` (duplicate of Integration Onboarding number) | 3/7 | `5.x.7.2` |
| Section title case drift (`Technical standard` vs `Technical Standards`) | 3 variants | Use template casing |
| `6.3.1a Data Handling and Encryption` | 1/7 | `6.3.5` or renumber cleanly |
| Trailing typo in prose (`…MetProms (EAII-385).df`) | 1/7 | Proofread |
| §15 missing entirely | 1/7 | Always include |
| Confluence media-CDN URLs pasted as section references | 1/7 | Use plain section references |
