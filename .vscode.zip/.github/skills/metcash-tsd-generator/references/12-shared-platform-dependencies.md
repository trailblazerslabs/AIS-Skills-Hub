# Shared platform dependencies, defaults and evidence rules

Added 2026-10-04 from the developer's manual corrections to the EAII-536..541 TSD. Everything here is a rule the generator
applies **without being asked**; the developer should never have to request a shared resource, a default or a repeated
convention by hand.

## 1. Evidence precedence (decide in this order, record which level you used)

1. **FSD and walkthrough transcript** for this interface (authoritative for business behaviour and for any value they state).
2. **Source repositories** that already implement the pattern (git on a local Metcash clone: workflows, `connections.json`,
   `parameters.*.json`, `appsettings.*.json`, pipelines). Research here **before** writing a permanent `*<To be confirmed>*`.
3. **Approved precedent TSDs** (reference corpus) for the same pattern.
4. **Platform defaults** (this file, `03-naming-and-infrastructure.md`).
5. Generic archetype text. Never above 1-4.

A `*<To be confirmed>*` is allowed only after levels 1-4 were tried and the item is classed **ask** or **external** (section 6).

## 2. Standing SMC dependency block (every interface that logs to SMC)

Derive these from the interface's real dependencies, not only from the resources the workload owns. Each line must appear in every
place listed in the right-hand column.

| Dependency | Name / pattern | Must appear in |
|---|---|---|
| APIM SMC API | APIM `t3-met-core-{apim-env}-ae1-apim`, API `smc-v1` (start observation) | §5.x.6.3.1, §7.1, diagrams |
| SMC observation queue | `smc.endobservation.{smc-env}.sbq` | §3.2 Environment Segregation, §5.x.6.1, §6.1.1, §6.3.3, §6.6, §7.1, diagrams |
| SMC Service Bus namespace (AIS) | `t2-met-{npr\|prd}-ae-sb-001` (seen in the EAII-374 code `appsettings.dev.json`) | §3.2, §6.1.1, §6.6 |
| Input Service Bus namespace (HUB), when the interface consumes from the hub | `t1-met-{npr\|prd}-ae-sb-001` (`03-naming-and-infrastructure.md`) | §3.2, §6.1.1, §6.3.3, §6.6 |
| Enabling / SMC Key Vault | `t3enabling{env}ae1kv01`, secret `SMC-API-Subscription-Key` | §3.2, §4.3, §6.1.1, §6.2.2, §6.3.2, §6.3.3, §6.5 private endpoints, §6.6, diagrams |

**SMC environment mapping** (queue name token): `dv1 -> dev`, `st1 -> uat`, `ut1 -> uat`, `prd -> prd`. State it as its own row in
§3.2 Environment Segregation.

> Namespace conflict: `03-naming-and-infrastructure.md` names the non-prod namespace `t1-met-npr-ae-sb-001`; the EAII-374 code reads
> the SMC queue from `t2-met-npr-ae-sb-001`. Both are shown above; confirm which namespace each queue lives on before approval.

**Cross-subscription boundary.** The hub Service Bus namespace is in `COREIT-SERVICES-HUB-*`; the Logic App, Storage and Key Vaults
are in `COREIT-SERVICES-AIS-*`. Say so in §6.1.1 (Notes), §6.3.3 and §6.6 because it decides RBAC scope.

## 3. RBAC derived from dependencies (§6.3.3)

One row per dependency edge, `Source | Target | Identity | RBAC Role`:

| Dependency edge | Role |
|---|---|
| Logic App SAMI -> own Key Vault `t3data{env}ae1kv01` | Key Vault Secrets User |
| Logic App SAMI -> enabling Key Vault `t3enabling{env}ae1kv01` (when it reads the SMC key) | Key Vault Secrets User *(pending SMC / Enabling team grant)* |
| APIM MI -> enabling Key Vault (SMC subscription key named value) | Key Vault Secrets User |
| Logic App SAMI -> SMC observation queue | Azure Service Bus Data Sender |
| APIM MI -> SMC observation queue (when APIM sends observations) | Azure Service Bus Data Sender |
| Logic App SAMI -> hub input namespace / queue / topic (cross-subscription) | Azure Service Bus Data Receiver |
| Logic App SAMI -> Application Insights | Monitoring Metrics Publisher |

## 4. Private endpoints (§6.5)

Every Key Vault named in §6.3.2 has a private-endpoint row (`{resource}-pe`, sub-resource `vault`, zone
`privatelink.vaultcore.azure.net`), **including the enabling Key Vault** the Logic App reads for SMC. Add rows for Service Bus
namespaces and Application Insights when they are reached privately.

## 5. Platform defaults and precedents (apply, then record an assumption; do not open a gap)

| Item | Default / precedent | Source |
|---|---|---|
| Inbound authentication | OAuth 2.0 client-credentials JWT, `validate-jwt_v1` in APIM, Entra ID | AIS platform default (all approved APIM TSDs) |
| Archive / error retention | archive 90 days, error 30 days, Storage lifecycle-management rule | EAII-304 (IBA Directs) |
| SMC XREF access | APIM API `smc-v1`, operation `getXrefData`, **APIM subscription key (not Managed Identity)** | `Metcash.CoreSys.Storeline` Logic App workflows + `connections.json` (developer, 2026-10) |
| SMC onboarding names | known or directly askable: propose from the sibling interface of the same source/target; never blank or TBC | EAII-374 / 529 / 536..541 TSDs |
| Interface Type / notification | Sender; IntegrationSupport@metcash.com; Grouping ID = EAII id | corpus |

## 6. Classify every open gap (intake and TSD)

| Class | Meaning | What the generator does |
|---|---|---|
| research | answer exists in a repo, the corpus or ADO | do the research, cite the file / commit, close the gap |
| default | a platform default or precedent fits and nothing contradicts it | apply it, cite the precedent, record an assumption, close the gap |
| ask | only a stakeholder can say (names, dates, owners) | keep `*<To be confirmed — what from whom>*` with the named owner |
| external | owned outside the interface (PE team, networking, Stibo) | close as out of scope **with the owner and the dependency recorded** (§12 / §13) |

Only **ask** and **external** items may remain as `*<To be confirmed>*` in the final TSD.

## 7. Shared ingestion interface (`EAII-XXX`) is described once

The common ingestion interface has its own §5.1 with the full §5.x.1 to §5.x.10 content and its own diagrams. Every target
interface (§5.2 onward) carries only what is specific to it and **points to §5.1** for token validation, request validation,
publish and HTTP replies: no repeated prose, no repeated process-flow or sequence diagram of the ingest step. `quality_review.py`
fails `XR-08` when a long paragraph is copied between two interface sections.

## 8. Diagram semantics that must match across diagram types

- SMC: if the sequence diagram shows Begin / End SMC observations, the process-flow page has an SMC node and arrow too (`DG-10`).
- Key Vault: the architecture, network and communication pages each show every Key Vault the Logic App or APIM really reads,
  including the enabling Key Vault (`DG-11`).
- Legend: generated automatically on icon-style pages by `build_drawio.py` (SMC observation dot, green synchronous, black one-way,
  red failure / SMC, grey dashed secret, step number).
- Routing: never hand-write waypoints or `exit` / `entry` anchors; `build_simple_flow.py` routes from node geometry and
  `build_drawio.py` routes around icons and labels, so a longer label or an extra row cannot leave a stale waypoint.

## 9. Gap register (traceability from intake to TSD and back)

`tsd-inputs/<ID>/gap-register.json` is the single list of gaps: `id` (Q1, G1, TBC-1 ...), `class`, `status`
(`open`, `resolved`, `defaulted`, `closed-external`), `decision`, `evidence`, `tsd_sections`, `owner`. Use
`tools/intake/gap_register.py resolve <id> ...` whenever a refinement closes a gap; `sync` rewrites the questionnaire's gap table
from the register and `check` fails when the TSD and the register disagree. `quality_review.py` runs `check` automatically when
the register exists.
