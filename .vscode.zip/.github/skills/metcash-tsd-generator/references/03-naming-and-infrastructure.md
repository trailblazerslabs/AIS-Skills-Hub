# Naming Conventions and Metcash Infrastructure Facts

All values transcribed from the approved TSD corpus. **Reproduce verbatim — never invent a VNet,
subnet, IP, subscription, resource group, or APIM name.** Where the corpus disagrees with itself,
the conflict is flagged.

**Hosting platform fact (confirmed, user 2026-09-20): Squad 20's Function Apps and Logic Apps
all run inside a shared, privately-hosted App Service Environment v3 (ASE v3, ILB) per
environment.** Every Function App/Logic App host in the same environment (DV1/ST1/UT1/PRD) shares
the same VNet/subnet egress path. This matters for `ais-codegen-readiness`'s Step 3.5 network
connectivity pre-check: a Kudu-based connectivity test can be run from **any existing sibling
host already deployed in that environment**, not only from the exact target host — a brand-new
Function App that doesn't exist yet will land on the same shared network path once deployed, so
an existing sibling's Kudu result is equally valid evidence. Do not assume the check is
unavailable just because the target host is new.

**Before choosing a `{workload}` token for a new interface, check for reuse first.** Search the
corpus/ADO for sibling interfaces that share the same source system or business domain (e.g. all
STIBO-sourced interfaces, all supplier-master interfaces). If a workload token is already
established for that domain (e.g. `metproducts` for STIBO→PE/reference-data interfaces), **reuse
it** rather than inventing a new one per interface — Metcash groups related interfaces under one
shared workload/domain resource footprint (one Logic App, one App Insights, etc. hosting multiple
related workflows), not a dedicated resource set per interface. Only propose a new token when no
related interface exists, and confirm with the user before finalizing.

---

## 1. Resource naming patterns

General pattern: `{tier-prefix}-{scope}-{workload}-{env}-{region}-{resource-type}`

| Resource | Pattern | Examples |
|---|---|---|
| Function App | `t3-met-{workload}-{env}-ae-func` | `t3-met-metproducts-dv1-ae-func`, `t3-met-mdmsupplierinfo-prd-ae-func` |
| Logic App Standard | `t3-met-{domain}-{workload}-{env}-ae-logic` | `t3-met-data-suppliercontract-dv1-ae-logic` |
| App Service Plan | `t3-{domain}-{env}-ae-asp01` | `t3-data-dv1-ae-asp01` |
| Application Insights | `{parent-resource-name}-ai` | `t3-met-metproducts-dv1-ae-func-ai` |
| Log Analytics Workspace | `t3-met-{workload}-{env}-ae-law` | shared per env in most cases |
| API Management | `t3-met-core-{apim-env}-ae1-apim` | `t3-met-core-dev-ae1-apim` |
| Application Gateway | `t1-met-core-{npr\|prd}-ae1-apg-01` | `t1-met-core-npr-ae1-apg-01` |
| Storage Account | `t3{domain}{env}aesta01` (no hyphens) | `t3datadv1aesta01`, `t3dataprdaesta01` |
| Key Vault (AIS/data) | `t3{domain}{env}ae1kv01` (no hyphens) | `t3datadv1ae1kv01`, `t3dataprdae1kv01` |
| Key Vault (enabling/SMC) | `t3enabling{env}ae1kv01` | `t3enablingdv1ae1kv01`, `t3enablingdevae1kv01` |
| Service Bus namespace | `t1-met-{npr\|prd}-ae-sb-001` | `t1-met-npr-ae-sb-001`, `t1-met-prd-ae-sb-001` |
| Service Bus topic | `data.{workload}.{env}.sbt` | `data.metproducts.dv1.sbt`, `data.SupplierInfoFromMDM.prd.sbt` |
| Service Bus subscription | `to{target}.{itemtype}` | `tosorted.corporateitem`, `toindipim.corporateitem`, `toeaim.supplierinfo`, `topim.supplierinfo` |
| Service Bus queue | `…{name}.sbq` | |
| Event Grid System Topic | `{workload}` on the storage account | `metproducts` |
| Virtual Network (AIS spoke) | `t2-met-ais-{env}-ae1-net-01` | `t2-met-ais-dv1-ae1-net-01` |
| Virtual Network (hub) | `t1-met-core-{npr\|prd}-ae1-net-hub` | |
| Private Endpoint | `{resource-name}-pe` | `t3datadv1ae1kv01-pe` |
| Resource Group (AIS data) | `t3-met-ais-{env}-ae1-rsg-data` | |
| Resource Group (AIS b2b) | `t3-met-ais-{env}-ae1-rsg-b2b` | |
| Resource Group (AIS enabling) | `t3-met-ais-{env}-ae1-rsg-enabling` | |
| Resource Group (AIS SMC) | `t3-met-ais-{env}-ae1-rsg-smc` | |
| Resource Group (APIM) | `t3-met-core-{env}-ae1-rsg-apim` | |
| Resource Group (hub net) | `t1-met-core-{env}-ae1-rsg-net` | |
| Resource Group (Service Bus) | `t1-met-core-{npr\|prd}-ae1-rsg-sbus` | |
| Function name (C#) | PascalCase `{Entity}To{Target}` | `SupplierItemToSorted`, `CorporateItemToIndiPIM`, `MDMSupplierInfoToEIM` |
| Service class | `{FunctionName}Service` | `CorporateItemToIndiPIMService` |
| Shared library | `Metcash.AIS.Data.{Workload}.Common` | `Metcash.AIS.Data.Metproducts.Common` |
| Logic App workflow | PascalCase verb-noun | `GetNewSupplierNumber`, `ReleaseReservedSupplierNumber` |
| Exception code | `EAII{nnn}-{seq}` | `EAII284-001` … `EAII284-099` |

### Environment tokens — mind the two schemes

| Scheme | Used by | DEV | SIT | UAT | PROD |
|---|---|---|---|---|---|
| `{env}` (AIS resources) | Function App, Logic App, Storage, Key Vault, VNet, RG | `dv1` | `st1` | `ut1` | `prd` |
| `{apim-env}` (core/hub resources) | APIM, App Gateway, hub RGs | `dev` | `sit` | `uat` | `prd` |

Enabling Key Vault appears as both `t3enablingdv1ae1kv01` and `t3enablingdevae1kv01` across the
corpus — confirm the correct scheme with the platform team for the specific environment.

### Subscriptions

| Subscription | Contains |
|---|---|
| `COREIT-SERVICES-AIS-{ENV}` | AIS spoke resources: Function/Logic Apps, Storage, data Key Vaults, AIS VNets |
| `COREIT-SERVICES-AIS-NPR` | Enabling Key Vault (non-prod) |
| `COREIT-SERVICES-HUB-{ENV}` | APIM, Application Gateway, hub VNet, hub Service Bus |

> **Cross-subscription note:** the non-prod Service Bus namespace `t1-met-npr-ae-sb-001` lives in
> `COREIT-SERVICES-HUB-NPR`, a *different subscription* to every other AIS resource. Call this out
> in §6.1.1 — it affects RBAC assignment scope.

---

## 2. AIS Spoke Virtual Networks

| Environment | Virtual Network | Address Space |
|---|---|---|
| DV1 | `t2-met-ais-dv1-ae1-net-01` | 10.247.80.0/21 |
| ST1 | `t2-met-ais-st1-ae1-net-01` | 10.247.88.0/21 |
| UT1 | `t2-met-ais-ut1-ae1-net-01` | 10.247.96.0/21 |
| PRD | `t2-met-ais-prd-ae1-net-01` (also written `t2-met-ais-pr1-ae1-net-01`) | 10.249.32.0/21 |

> Corpus conflict: PROD spoke VNet appears as both `…-prd-…` and `…-pr1-…`. Confirm before use.

## 3. Subnets

| Subnet | Purpose |
|---|---|
| **SENS** | Application subnet — Function App / Logic App VNet integration |
| **HSENS** | Private Endpoint subnet — Storage, Key Vault, Service Bus private endpoints |
| **ECCS2** | APIM — DEV and PRD |
| **ECCS3** | APIM — SIT |
| **ECCS4** | APIM — UAT |
| **ECIS1** | Application Gateway — L7 ingress to APIM and backend services |

### SENS (application subnet)

| Environment | VNet Address Space | SENS |
|---|---|---|
| DV1 | 10.247.80.0/21 | 10.247.86.0/24 |
| ST1 | 10.247.88.0/21 | 10.247.92.0/24 |
| UT1 | 10.247.96.0/21 | 10.247.98.0/24 |
| PRD | 10.249.32.0/21 | 10.249.38.0/23 |

### HSENS (private endpoint subnet)

| Environment | HSENS |
|---|---|
| DV1 | 10.247.80.0/23 |
| ST1 | 10.247.100.0/23 |
| UT1 | 10.247.88.0/23 |
| PRD | 10.249.32.0/23 |

> Corpus conflict: two TSDs swap the ST1 and UT1 HSENS ranges. Both list DV1 = 10.247.80.0/23 and
> PRD = 10.249.32.0/23. One TSD also cites HSENS as `10.247.85.0`. Verify with Enterprise
> Networking before publishing.

## 4. Hub subnets — APIM

| Env | VNet | Subnet | CIDR | Public IP | Private IP |
|---|---|---|---|---|---|
| Dev | `t1-met-core-npr-ae1-net-hub` | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| Sit | `t1-met-core-npr-ae1-net-hub` | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| Uat | `t1-met-core-npr-ae1-net-hub` | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| Prd | `t1-met-core-prd-ae1-net-hub` | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

## 5. Application Gateway

| Environment | VNet | Subnet | Public IP | Private IP |
|---|---|---|---|---|
| Dev / SIT / UAT | `t1-met-core-npr-ae1-net-hub` | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | `t1-met-core-prd-ae1-net-hub` | ECIS1 | 4.200.110.27 | 10.249.1.72 |

Resource names: `t1-met-core-npr-ae1-apg-01` (non-prod), `t3-met-core-prd-ae1-apg-01` (prod).
One TSD cites the generic form `t1-met-core-{env}-ae1-apg-01` in
`t1-met-core-{env}-ae1-rsg-net`.

## 6. API Management

| Environment | Resource Name | VNet | Address Space |
|---|---|---|---|
| DEV | `t3-met-core-dev-ae1-apim` | `t1-met-core-npr-ae1-net-hub` | 10.247.1.0/26 |
| SIT | `t3-met-core-sit-ae1-apim` | `t1-met-core-npr-ae1-net-hub` | 10.247.3.0/26 |
| UAT | `t3-met-core-uat-ae1-apim` | `t1-met-core-npr-ae1-net-hub` | 10.247.3.64/26 |
| PRD | `t3-met-core-prd-ae1-apim` | `t1-met-core-prd-ae1-net-hub` | 10.249.1.0/26 |

APIM operates in **internal VNet mode**. Application Insights for APIM:
`t3-met-core-{env}-ae1-appi-apim` (also written `t3-met-core-{env}-ae-apim-ai`).

### APIM gateway URLs

`https://cloud-api-{env}-internal.metcash.com` where `{env}` ∈ `dev | sit | uat | preprod | prd`.

### API path convention

`/{domain}/{service}/v{n}/{Operation}` — e.g. `/eis/abnlookup/v1/SearchByABN`,
`/newsupplier/v1`, `/releasesupplier/v1`.

---

## 7. SKU and tier defaults

| Component | Non-Prod | Prod |
|---|---|---|
| Function App / App Service Plan | Consumption or EP1 (confirm with DevOps) | EP1 Premium — VNet integration, no cold start |
| Logic App Standard | Standard, stateless workflows, dedicated ASP | Standard |
| API Management | Standard (shared instance) | Standard / Premium |
| Service Bus namespace | Standard | Premium (private endpoint) |
| Storage Account | Standard LRS | Standard GRS |
| Key Vault | Standard | Premium (HSM) |
| Application Insights | Standard | Standard |

## 8. Standing platform statements

Reproduce these in §6.5 / §6.6 for any archetype using private connectivity:

> Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to
> provide secure, private connectivity to Azure PaaS resources. All services are accessible only
> through their private IP addresses within the Virtual Network, with **Public Network Access
> disabled** on each target resource. Private Endpoints are used in preference to public endpoints
> to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the
> attack surface and eliminating exposure to the public Internet.
>
> Private DNS Zone integration (`Microsoft.Network/privateDnsZones`) ensures DNS queries resolve
> to the private IP address associated with each Private Endpoint. All Private DNS Zones are
> linked to both the Hub Virtual Network and the AIS Spoke Virtual Network.

> **Network Security Controls**
> - Access to Azure resources is controlled using Managed Identity and Azure RBAC.
> - All network communication follows the enterprise Hub-and-Spoke networking architecture.
> - Public network access is disabled.
> - Access is restricted through Private Endpoints.
> - Authentication is performed using Microsoft Entra ID and Managed Identity.
> - Access is governed through Azure RBAC following the principle of least privilege.
> - Secrets are retrieved at runtime and are never persisted within the application.

## 9. RBAC roles used

| Identity | Target | Role |
|---|---|---|
| Function App SAMI | Service Bus namespace | Azure Service Bus Data Receiver |
| Function App SAMI | Storage Account | Storage Blob Data Reader (add Contributor if writing) |
| Function App SAMI | Key Vault (AIS) | Key Vault Secrets User |
| Function App SAMI | Key Vault (SMC/enabling) | Key Vault Secrets User — **granted by the SMC team** |
| Event Grid System Topic | Service Bus topic | Azure Service Bus Data Sender |
| Logic App MI | Key Vault | Key Vault Secrets User |
| APIM system-assigned MI | Key Vault (both) | Key Vault Secrets User |

## 10. Common Key Vault secret names

| Secret | Vault | Purpose |
|---|---|---|
| `SMC-API-Subscription-Key` | SMC / enabling | APIM subscription key for SMC `StartObservation` |
| `{Target}ClientId` / `{Target}ClientSecret` | AIS / data | OAuth 2.0 client credentials |
| `{Target}Scope` | AIS / data | OAuth 2.0 scope |
| `{Target}CertificateThumbprint` | AIS / data | mTLS client certificate thumbprint |

Secret **values** are never written into a TSD.

---

## 11. Repositories and pipelines

| Artefact | Location |
|---|---|
| Function App source | Azure DevOps repo per workload |
| Function App pipeline | `pipelines/{workload}fnapp.yml` |
| Infrastructure (Bicep) | `metcash-ais-infrastructure` |
| APIM policies / API definitions / XSLT | Azure DevOps repo (APIOps) |
| Promotion path | PR → DV1 (automated) → ST1 → UT1 → PRD (gated per Environments Strategy) |
