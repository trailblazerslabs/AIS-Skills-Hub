# Mining the Walkthrough Transcript

The FSD Walkthrough Transcript is a Teams meeting recording export, converted to speaker-turn
markdown by `reference-corpus/_tools/transcript_to_md.py`
(`**Turn N — Speaker** *(mm:ss)*` followed by the utterance). It captures the solution architect
and team **settling design questions verbally**, often before the FSD prose is updated to match.

Treat it as a primary source with the same evidence-based discipline as the FSD: extract only
what was actually said, cite the Turn/speaker/timestamp, and never upgrade a hedge, a question, or
a debated point into a stated decision.

---

## What to extract

Scan for these six categories. Not every transcript will contain all of them.

### 1. Archetype / technology decisions

Phrases that settle Logic App vs Function App vs APIM-only, sync vs async, or similar:

> "Logic App should be okay." / "Logic App should be fine." / "...we have tried it from Logic App,
> not from Function App."

→ Feeds **Step 1** (Architecture Archetype Selection) directly. If the transcript settles the
archetype, present it to the user as confirmed rather than re-deriving it from the FSD alone —
but still show the FSD evidence alongside it per Step 1's format.

### 2. Legacy topology detail (for §5.x.1 As-is)

> "In the legacy implementation, the integration consists of two TIBCO services. There's a BWCE
> service which is used as a proxy, and then a BW6 service that calls the actual PE stored
> procedures."

→ Often more precise than the FSD's §3.x.1.1 prose, because the architect is describing the code
directly. Prefer the transcript's technical detail for §5.x.1.1, cited alongside the FSD.

### 3. Scope inclusions / exclusions

> "The service does have a fifth operation called get new customer number, which exists in the
> legacy service, but it's already been implemented as part of a separate credit application
> interface. So it's out of scope for this migration."

→ Feeds **§2.2 Out of Scope**. This is exactly the kind of boundary that is easy to miss from the
FSD alone because the FSD may only describe the four in-scope operations without explaining why a
fifth was dropped.

### 4. Risk / compliance signals

> "Horizon Impact is red, because both PE and the source PIM are red applications, and any
> interfaces involving them are also red."

→ Feeds **§1.3 Horizon Impact Assessment** cross-check and **§9.1 Transition Period** /
**§13 Assumptions** (approval path).

### 5. Volume / complexity qualifiers

> "The number of calls are also less, and the size of the message is also less." /
> "This one is simple... very small number of fields."

→ Feeds **§4.5 NFRs** and **§5.x.7.2 SMC Load Estimations** when the FSD's NFR section is
quantified loosely or not at all. A qualitative transcript statement ("simple", "low volume")
is not sufficient by itself to fill an NFR table cell — pair it with any number mentioned, and
mark the rest `*<To be confirmed>*` rather than inventing a figure.

### 6. Error-handling / sequencing decisions

> "All separate individual API calls, no sequence." / "If one fails... we'll send a failure back."
> / "It is synchronous, synchronous call. So whatever response we will send it back."

→ Feeds **§5.x.3 Coordination** (sync/async) and **§5.x.6.3.3 Exceptions**.

---

## Extraction discipline

1. **Cite every row.** `Turn N, Speaker, mm:ss`. A decision without a citation does not go in the
   TSD.
2. **Distinguish decision from discussion.** A question ("do we need Logic App or Function?")
   followed by a one-word answer ("Logic App should be okay") is a decision. Two people debating
   without resolving is not — surface it as an open item in §13 Assumptions instead.
3. **Don't resolve contradictions silently.** If the transcript says one thing and the FSD says
   another, present both to the user in Step 2 rather than picking one.
4. **Speech-to-text noise.** Transcripts are auto-generated and contain mis-transcribed product
   names (e.g. a PIM vendor name rendered as an unrelated word), false starts, and filler words.
   Read for intent, not literal transcription — but never paraphrase away a number, a system name,
   or a yes/no answer.
5. **Watch for merged turns.** The converter occasionally folds a short interjection from a second
   speaker into the preceding turn (see SKILL.md Notes). If a turn's text contains a second
   `Name  mm:ss` pattern mid-paragraph, split it mentally before citing.

---

## Worked example — EAII-374 (STIBO to PE)

From `tsd-inputs/EAII-374/converted/_EAII-374---STIBO-to-PE---FSD-Walkthrough.md`:

| Topic | Decision | Cited from |
|---|---|---|
| Archetype | Logic App Standard, not Function App — "the number of calls are also less, and the size of the message is also less" | Turn 10–11, Jagadeesh Sathyanarayanan / Magesh Parthasarathy, 15:14–15:29 |
| Precedent | PE connectivity has previously been proven from Logic App, not Function App | Turn 13, Magesh Parthasarathy, 15:35 |
| Legacy topology | BWCE proxy service + BW6 backend calling PE stored procedures; proxy layer is dropped in the AIS design | Turn 2, Vladimir Gurieff, 0:08 |
| Scope exclusion | 5th operation ("get new customer number") already implemented under a separate credit-application interface | Turn 2, Vladimir Gurieff, 0:08 |
| Data access pattern | Mostly stored procedures; at least one direct table query | Turn 7–8, Jagadeesh Sathyanarayanan / Magesh Parthasarathy, 14:57–15:03 |
| Mapping complexity | "Very simple, very, very small number of fields" | Turn 18, Vladimir Gurieff, 18:40 |
| Call sequencing | Four separate, independent API calls; no sequencing dependency between them | Turn 20–24, Jagadeesh Sathyanarayanan / Vladimir Gurieff / Magesh Parthasarathy, 18:52–19:25 |
| Coordination | Synchronous request-reply; failure returned directly in the response | Turn 25–27, Jagadeesh Sathyanarayanan / Magesh Parthasarathy, 19:28–19:31 |
| Horizon Impact | RED — both PE and the source PIM are RED applications | Turn 2, Vladimir Gurieff, 0:08 |

Every one of these settles a Step 2 question that would otherwise require asking the user —
present them as confirmations with citations instead.
