# Reference Corpus Index

Nine approved Metcash TSDs (EAII-374 and the revised EAII-304 added 2026-10), nine FSDs, nine Mapping Manifests, two field-level Mappings, one walkthrough transcript. All exported from Confluence as
MHTML and converted to Markdown with `reference-corpus/_tools/mhtml_to_md.py`.

**Locations**
- Originals: `reference-corpus/source/{tsd,fsd,manifests}/`
- Converted: `reference-corpus/converted/{tsd,fsd,manifests}/<CODE>/<CODE>.md` + `images/`
- Cross-section slices: `reference-corpus/_analysis/`

---

## TSD corpus

| Code | Title | Archetype | Interfaces | Size | Use as precedent for |
|---|---|---|---|---|---|
| `TSD-EAII-333` | EAII-333 — Storeline to CCC (Campbells Payment) | **A** APIM-only | 1 | 970 ln / 7 img / 35 tbl | The cleanest single-interface exemplar. Full 9-subsection §5.1.6.3 block. SOAP→REST protocol translation, mutual TLS, synchronous request-reply, conditional response formatting |
| `TSD-EAII-289` | EAII-289 — MDM to ATO (ABN/ACN lookup) | **A** APIM-only | 1 (4 operations) | 1060 / 9 / 37 | Multi-operation single API. Has §4.5 NFRs + §4.5.1 Retry Strategy and §6.6 Infrastructure Resource Details. XSLT-in-APIM transformation. Public data classification |
| `TSD-EAII-297` | EAII-297 — Metconnect ↔ Supplier MDM (Get/Release Supplier Number) | **B** APIM + Logic App | 1 (2 operations) | 1116 / 9 / 40 | The Logic App Standard exemplar. Workflow Details table, WS-Security/SOAP backend, stateless workflows, RED Horizon rating handling |
| `TSD-EAII-304` *(revised, approved)* | EAII-304 — Liquor Suppliers to EIM | **B+C+D hybrid** (sync APIM upload via shared `UploadBlob` Function; Event Grid -> Service Bus queue -> Logic App + inline Function; GoAnywhere to EIM) | 1 | ~1200 / 8 / 38 | The only hybrid. Full GoAnywhere requirements block (§5.1.4.1, added in the revision), per-folder retention + lifecycle rule (§8.5), explicit sync/async coordination (§5.1.3). See `10-known-defects-in-approved-tsds.md` |
| `TSD-EAII-374` | EAII-374 — STIBO to PE (Item & Vendor Validation) | **B** APIM + one Logic App, DB2 built-in connector | 1 (4 operations) | ~1100 / 16 / 33 test cases | Synchronous DB2/AS-400 target; one workflow with a switch on operation type; 27 coded exceptions incl. business-result rows; §6.4 DB2 environment table; no gateway. Has real FSD + Mapping + Manifest + **walkthrough transcript** in the corpus (`converted/transcripts/`) so it doubles as the worked example for Step 0.5 mining. See `10-known-defects-in-approved-tsds.md` |
| `TSD-EAII-514` | EAII-514 — Sorted to PE (realtime pricing) | **A/B** synchronous API | 1 | 1506 / 13 / 45 | Synchronous API exposed through APIM with a real-time latency budget |
| `TSD-EAII-301_302_516_517` | Supplier MDM → EIM, PIM, Food Sorted, ALM Sorted | **C** Function App (pointer messages) | 4 | 1742 / 18 / 60 | **Gold standard for multi-interface event-driven.** Variant C2 (reference/pointer message + live MDM fetch). Per-interface differentiated retry/DLQ policy. Mixed target auth (none / mTLS / OAuth 2.0). Collapsed §5.x.6.3 block |
| `TSD-EAII-284_283_282_385` | STIBO → IndiPIM, Sorted ×2, Retail Express | **C** Function App (blob event) | 4 | 2037 / 19 / 59 | **Gold standard for infrastructure depth.** The only TSD with §6.1.1 Azure Resource Inventory, §6.2.1/6.2.2 network tables, §6.3.2 Key Vault Secrets Inventory, §6.3.3 Identity Inventory, §6.3.4 External Dependency Ownership. Resource-centric §5.x.6.1 component list |

### Precedent selection

| If the new interface is… | Use as primary precedent |
|---|---|
| Synchronous REST/SOAP proxy, policy-only | `TSD-EAII-333` |
| Synchronous multi-operation API with XSLT transform | `TSD-EAII-289` |
| Synchronous with orchestration / SOAP backend | `TSD-EAII-297` |
| Event-driven, single interface | `TSD-EAII-284_283_282_385` §5.1 |
| Event-driven, multi-interface | `TSD-EAII-301_302_516_517` |
| File/MFT delivery | the EIM leg of `TSD-EAII-301…`; for a synchronous upload that feeds a file pipeline use `TSD-EAII-304` |
| Synchronous API to an on-premises DB2/AS-400 via Logic App | `TSD-EAII-374` |
| Sync upload + async translate + GoAnywhere onward | `TSD-EAII-304` |
| Anything needing full infrastructure/security depth | `TSD-EAII-284_283_282_385` §6 |

---

## FSD corpus

| Code | Title | Paired TSD |
|---|---|---|
| `FSD-EAII-284_283_282_385` | STIBO to Multiple Targets | `TSD-EAII-284_283_282_385` |
| `FSD-EAII-289` | MDM Supplier to ATO | `TSD-EAII-289` |
| `FSD-EAII-297` | Metconnect to Supplier MDM — Get/Clear Supplier Number | `TSD-EAII-297` |
| `FSD-EAII-301_517_516` | Supplier MDM to EIM, ALM Sorted, Food Sorted | `TSD-EAII-301_302_516_517` |
| `FSD-EAII-302` | Supplier MDM to STIBO | folded into `TSD-EAII-301_302_516_517` |
| `FSD-EAII-304` | Liquor Suppliers to EIM | `TSD-EAII-304` |
| `FSD-EAII-374` | STIBO to PE | `TSD-EAII-374` |
| `FSD-EAII-333` | Campbells Retailers to Sorted | `TSD-EAII-333` |
| `FSD-EAII-514` | Sorted to PE | `TSD-EAII-514` |

**Naming drift to be aware of:** the FSD and TSD titles diverge for two pairs —
FSD *"Campbells Retailers to Sorted"* vs TSD *"Storeline to CCC"*, and FSD *"Get/Clear"* vs TSD
*"Get/Release"*. Confirm the intended title in Step 2 of the skill rather than assuming.

**Scope drift:** the EAII-301 FSD covers 301/517/516 while its TSD covers 301/302/516/517,
absorbing the separate EAII-302 FSD. A TSD may legitimately span more interfaces than one FSD.

---

## Mapping Manifest corpus

| Code | Title |
|---|---|
| `MANIFEST-EAII-283_282` | STIBO to Multiple Targets |
| `MANIFEST-EAII-289` | Metcash Internal to ATO |
| `MANIFEST-EAII-297` | Metconnect to Supplier MDM — Get/Release Supplier Number |
| `MANIFEST-EAII-301_517_516` | Supplier MDM to EIM, ALM Sorted, Food Sorted |
| `MANIFEST-EAII-302` | MDM to PIM (STIBO) |
| `MANIFEST-EAII-304` | Liquor Suppliers to EIM |
| `MANIFEST-EAII-333` | Campbells Retailers to Sorted |
| `MANIFEST-EAII-514` | Sorted to PE |
| `MANIFEST-EAII-374` | Stibo to PE |

## Field-level Mapping corpus and transcripts

| Code | Title |
|---|---|
| `MAP-EAII-304` | IBA Directs ALM Orders - Liquor Suppliers to EIM (`converted/mappings/`) |
| `MAP-EAII-374` | PE Item & Vendor Validation - Stibo to PE (`converted/mappings/`) |
| `EAII-374-FSD-Walkthrough` | Teams transcript - worked example of decisions mined with turn citations (`converted/transcripts/`) |

---

## Diagram corpus

`reference-corpus/source/diagrams/` — 8 `.drawio` files, 26 pages. Per-page XML dumps in
`reference-corpus/_analysis/drawio/`. Conventions derived in
[08-diagram-conventions.md](08-diagram-conventions.md).

| File | Pages | Style | Contents |
|---|---|---|---|
| `EAII-289-AD-N2.drawio` | 1 | **N2** | Architecture Diagram — **template source** |
| `EAII-289-ND-N2.drawio` | 1 | **N2** | Network Diagram — **template source** |
| `EAII-289-ProcessFlow.drawio` | 1 | **N2** | Process Flow — **template source** |
| `EAII-333-AD-N2.drawio` | 3 | **N2** | Architecture, Network, Communication — **template source** |
| `EAII-284+…+STIBO+to+Multiple+Targets.drawio` | 8 | legacy | Interface Scope Overview, 4 × Process Flow, Architecture, Network, Communication |
| `EAII-297.drawio` | 4 | legacy | Process Flow Design, Architecture, Network, Communication |
| `EAII-304.drawio` | 4 | legacy | Process Flow Design, Architecture, Network, Communication |
| `EAII-514-updated-1.drawio` | 4 | legacy | Process Flow Design, Architecture, Network, Communication |
| `EAII-374-Network-Diagram.drawio` / `EAII-374-Process-Diagram-v1.drawio` | 1 each (identical content) | legacy | STIBO -> App Gateway -> 4 APIM operations -> one Logic App -> DB2. **Contains stale draft names** (`met-askross-{env}-ae-logic`, `b2b-{env}-ae-kv01`) that do not match the approved TSD text - do not copy names from it |

**Superseded 2026-10-02:** diagrams are no longer started from these templates. The approved visual
style actually used in 297/304/374/514 (embedded and bundled Azure icons, dashed `#0066CC` containers,
magenta resource names, blue numbered steps, red SMC dots) is reproduced by `tools/diagrams/build_drawio.py`
from a JSON spec, using the icon inventory in `tools/diagrams/icons.json` extracted from these files. The
original files remain the visual ground truth; render them with `tools/diagrams/render_drawio.py`.

---

## Sample payloads

`reference-corpus/source/payloads/` — STIBO product exports (`alm_160726/`,
`metcash_open_full_160726/`) and a transformed batch output. Ownership not yet confirmed against
an EAII ID; relocate to `sample_payloads/<EAII> - <Interface>/source_samples/` once confirmed.

---

## Live TSD request staging (`tsd-inputs/`)

Separate from the approved reference corpus. Each new TSD request supplies the four Input
Contract files (SKILL.md), staged and converted per EAII-ID:

```
tsd-inputs/<EAII-ID>/
  source/       # original .doc (MHTML) x3 + .docx (Teams transcript) x1, untouched
  converted/    # FSD-EAII-<ID>/, MAP-EAII-<ID>/, MANIFEST-EAII-<ID>/, <transcript>.md
```

**Worked example:** `tsd-inputs/EAII-374/` (STIBO to PE) — first live run of the full 4-file
pipeline, proves `mhtml_to_md.py` (naming-collision fix: `Mapping Manifest` → `MANIFEST-`,
`Mapping` → `MAP-`) and `transcript_to_md.py` (paragraph soft-line-break flattening fix) against
real input. See [09-transcript-mining.md](09-transcript-mining.md) for the decisions mined from
its transcript.

---

## Tooling

| Script | Purpose |
|---|---|
| `reference-corpus/_tools/mhtml_to_md.py` | Convert Confluence "Export to Word" MHTML (`.doc`) — FSD, Mapping, Mapping Manifest, TSD — to Markdown, extracting embedded diagrams as PNG by magic-byte sniffing. Prefixes output folders by doc type (`FSD-`, `MAP-`, `MANIFEST-`, `TSD-`) using short `EAII-nnn` names to stay inside Windows MAX_PATH |
| `reference-corpus/_tools/transcript_to_md.py` | Convert a Teams meeting-recording transcript (`.docx`) into numbered speaker-turn Markdown. Flattens python-docx's embedded soft-line-breaks before splitting into turns |
| `reference-corpus/_tools/slice_sections.py` | Extract matching numbered sections from every converted document into a single cross-corpus comparison file |
| `reference-corpus/_tools/check_tables.py` | Verify every markdown table has a consistent column count (header/separator/rows) — run against every generated TSD before handover |
| `reference-corpus/_tools/inspect_drawio.py` | List pages, decompress content, and summarise shape/style vocabulary of `.drawio` files |
| `reference-corpus/_tools/summarise_page.py` | Print every cell (id, label, style) of one dumped diagram page — used to read icon/style vocabulary in detail |

```powershell
python reference-corpus\_tools\mhtml_to_md.py <file-or-dir> --outdir <outdir>
python reference-corpus\_tools\transcript_to_md.py <file-or-dir> --outdir <outdir>
python reference-corpus\_tools\slice_sections.py --docs reference-corpus\converted\tsd --sections "^6(\.|$)" --out reference-corpus\_analysis\tsd-sec-6.md
python reference-corpus\_tools\check_tables.py <generated-tsd.md>
python reference-corpus\_tools\inspect_drawio.py <file-or-dir> [--dump <outdir>]
```

---

## Corpus statistics

| Metric | Value |
|---|---|
| TSDs scanned | 9 (100%) |
| FSDs scanned | 9 (100%) |
| Mapping Manifests scanned | 9 (100%) |
| Diagram assets extracted | 232 PNG (80 from TSDs) |
| §1–§4.4 structural conformance | 7/7 |
| §5.x.1–§5.x.10 structural conformance | 7/7 |
| §6–§14 structural conformance | 7/7 |
| §15 present | 6/7 |
| Archetype distribution | A ×3, B ×2 (297, 374), C ×2, B+C+D hybrid ×1 (304) |

## Known corpus gaps

| Gap | Impact | Mitigation |
|---|---|---|
| Conflicting HSENS ranges for ST1/UT1 across two TSDs | Wrong subnet could be published | Flagged in the infrastructure reference; verify with Enterprise Networking |
| PROD spoke VNet appears as both `-prd-` and `-pr1-` | Naming ambiguity | Flagged; confirm before use |
| Enabling Key Vault uses both `{env}` schemes (`dv1` vs `dev`) | Wrong vault name | Flagged; confirm per environment |
| `5.1.7.1` used twice (Integration Onboarding and Load Estimations) in 3/7 | Numbering defect | Use `5.x.7.2`; do not replicate |
| No ADF-based TSD in the corpus | No precedent for Data Factory archetypes | Fall back to `ais-datafactory-codegen` and `azure-data-factory-skill` |
| ~~No TSD covering a database-backed integration~~ | **Closed by 374**: §8.2-8.4 list the stored procedures and the DB2 built-in connector trigger | Use 374 as the precedent |
| Approved TSDs contain defects (see `10-known-defects-in-approved-tsds.md`) | Copying them propagates them | Take structure and decisions, not the listed defects |
