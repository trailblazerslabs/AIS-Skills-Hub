# Standard Boilerplate

Blocks reproduced verbatim (or near-verbatim) across the approved corpus. Copy these rather than
re-authoring. Substitute only the `{tokens}`.

---

## Standing Confluence references

| Reference | URL |
|---|---|
| Integration Design Principles - v1.0 | `https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0` |
| AIS (Azure Integration Services) | `https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services` |
| Guidelines | `https://metcash.atlassian.net/wiki/spaces/MAP/pages/1668874252/Guidelines` |
| Environments Strategy | `https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy` |
| SMC User Guide | `https://metcash.atlassian.net/wiki/x/ZQBbfw` |
| Audit, Logging and Exception Management with SMC | `https://metcash.atlassian.net/wiki/x/BQC_dg` |

---

## Document Approver table (front matter)

```markdown
| **Document Approver** | **Approver Role** |
| --- | --- |
| *<name>* | Integration Platform Representative |
| *<name>* | Integration Platform Operations |
| *<name>* | Solution Architect |
| *<name>* | Test Manager |
```

---

## §1.2 Document Purpose

> The primary purpose of this document is to outline the specifics, requirements, and steps
> pertaining to the integration of the **{Service Name}** service between **{Source System}**
> (source) and **{Target System}** (target) via **{Primary AIS Component}**.

---

## §3.1 Architecture Principles

Opening line (all 7):

> The following Metcash principles will apply:
>
> - [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

Then the IDP table. **Write an integration-specific justification in every row** — generic text is
a review failure. Note the corpus uses two competing code sets; pick one and stay consistent.

```markdown
| Code | Principle | Why It Applies to This Requirement |
| --- | --- | --- |
| IDP-001 | Generic and Reusable | *<what shared library / abstraction makes this reusable>* |
| IDP-002 | Decoupled Integrations | *<what decouples producer from consumer>* |
| IDP-003 | Integrated Security | *<OAuth/MI/Key Vault specifics>* |
| IDP-004 | Resilient and Recoverable | *<retry, DLQ, replay specifics>* |
| IDP-005 | Observability | *<SMC + App Insights specifics>* |
```

Alternative code set seen in TSD-EAII-297: `IDP-004 Standardization`, `IDP-005 Resilient and
Recoverable`, `IDP-006 Observability`.

---

## §3.2 Standards, Guidelines and Patterns

```markdown
The following standards, guidelines and patterns will apply:

| Pattern Name | Implementation Description |
| --- | --- |
| {Azure Function App \| Azure Logic Apps \| API Management Service} | *<how it is used here>* |
| API Management Service | *<gateway role, or "SMC gateway only">* |
| Retry and Resilience | *<policy, attempts, delay, DLQ behaviour>* |
| Logging and Observability | Logging and telemetry are captured using **Application Insights** and **SMC**, providing visibility into request execution, response status, correlation IDs, and exception details. |
| Security Abstraction | Secrets and credentials are stored in **Azure Key Vault** and accessed via Managed Identity. *<auth mechanism per target>*. No hardcoded credentials anywhere in source, pipeline variables, or committed appsettings. |
| Standardization and Governance | All interfaces comply with Metcash integration standards: consistent Azure resource naming, standardised error handling, and structured JSON/XML payloads per target contract. |

Information related to all Standards, Guidelines and Patterns refer

- [Guidelines](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1668874252/Guidelines)
- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)
```

Follow with the four standards sub-tables: **Naming Standards**, **Security Controls**,
**Environment Segregation**, **Error Handling and Monitoring** — populated from
[03-naming-and-infrastructure.md](03-naming-and-infrastructure.md).

### Security Controls sub-table

```markdown
| Control | Implementation |
| --- | --- |
| Managed Identity | System-Assigned Managed Identity (SAMI) enabled on the {resource} in all environments |
| Key Vault | All secrets and credentials in Azure Key Vault; referenced via Key Vault reference syntax in appsettings |
| RBAC | Least-privilege RBAC; SAMI granted only required roles per resource (see §6.3) |
| External API auth | *<mTLS / OAuth 2.0 client credentials / WS-Security / none, per target>* |
| Secret hygiene | No secrets in source code, pipeline variables, or committed appsettings files; all secrets via Key Vault references |
```

### Environment Segregation sub-table

```markdown
| Standard | Detail |
| --- | --- |
| Environment identifiers | `dv1` (DEV), `st1` (SIT), `ut1` (UAT), `prd` (PRD) |
| Resource groups | `t3-met-ais-{env}-ae1-rsg-{domain}` per environment |
| Service Bus namespaces | Non-production (DV1/ST1/UT1): `t1-met-npr-ae-sb-001` · Production: `t1-met-prd-ae-sb-001` |
| {Compute} instances | One per environment (`{name-pattern}`) |
```

---

## §4.2 Technical standard and requirements

Standard block for REST/SOAP interfaces:

```markdown
**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol
- WSDL 1.1 for SOAP web service contract
- SOAP 1.2 for SOAP web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization
- X509 digital certificate based for authentication, authorization as well as message encryption
```

For event-driven interfaces, replace with a protocol/format bullet list (XML, JSON, SFTP,
HTTPS TLS 1.2+, OAuth 2.0 Client Credentials, mTLS, Azure Managed Identity, Service Bus,
Function App, APIM, Key Vault, SMC Gen 3).

---

## §4.4 Environmental Requirement

```markdown
The following environments will be used for this interface:

- Development (DEV)
- System Integration Testing (SIT)
- User Acceptance Test (UAT)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).
```

Table variant:

```markdown
| Label (Pipeline) | Resource Suffix | Purpose |
| --- | --- | --- |
| DEV | `dv1` | Development and initial integration testing |
| SIT | `st1` | System Integration Testing |
| UAT | `ut1` | User Acceptance Testing |
| PROD | `prd` | Production |
```

---

## §5.x.1 As-is — net-new interfaces

> New integration — no as-is process.

---

## §5.x.4 GoAnywhere Requirements

Description only (no field table; GoAnywhere is MFT-team owned and out of scope for AIS development): what GoAnywhere picks up and delivers, the hand-over location, the file name contract, and the SMC ID rule — GoAnywhere generates the SMC ID, carries it in the file name, and AIS uses it as `ParentObservationID` for the whole flow.

When GoAnywhere is not used: `N/A — GoAnywhere is not used in this interface.`

---

## §5.x.6.3.x Logging preamble

```markdown
As per SMC specification and below information to be logged

1. Interface ID = **{EAII-nnn}**
2. As below spreadsheet
```

## §5.x.6.3.x Audit preamble

> All critical events and exceptions within the integration interface are logged and managed using
> the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and
> effective error handling. For further information, refer to *Audit, Logging and Exception
> Management with SMC*.
>
> It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the
> integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and
> performance monitoring.

```markdown
| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for Azure resources. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |
```

---

## §5.x.10.1 Development and Integration Strategy

```markdown
*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.
```

## §5.x.10.2 Unit Testing preamble

```markdown
Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

*Make sure to include scenarios for any known issues to be addressed.*

| **ID** | **Work Item Type** | **Title** | **Step Action** | **Step Expected** | **FSD ref** |
| --- | --- | --- | --- | --- | --- |
| **TC-001** | Test Case | **Verify {scenario}** | {action} | {expected} | {T1 / —} |

Ids are `TC-nnn`, sequential across the whole TSD (a multi-interface TSD does not restart at TC-001 per interface). Keep the FSD id (T1, T2...) in the `FSD ref` column. End the section with `**Location of sample messages:** {path}`.
```

---

## §9.3 Deployment Environment Migration

```markdown
*All source code is managed under source control (currently Github or Azure Devops Repo).*

*Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure.*

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PROD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.
```

---

## §12 Limitations and Constraints — standing rows

```markdown
| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | Azure function can accept the request data up to 100 MB. | The HTTP request length is limited to 100 MB (104,857,600 bytes), and the URL length is limited to 4 KB (4,096 bytes) | https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger |
```

APIM-archetype standing rows:

| Constraint | Detail |
|---|---|
| APIM forward-request timeout | Default 300 seconds |
| APIM inline transformation body size | ~256 KB for non-streaming |
| APIM XSLT version | XSLT 1.0 only; use Liquid for complex transforms |
| Key Vault secret rotation | Manual unless auto-rotation configured |

---

## §14 Reference Documents and Architecture — standing links

```markdown
- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)
```

APIM-archetype additions: APIM policies reference, Transform API, XSLT policy, Named Values /
Key Vault integration.

---

## §15 TSD Approval Checklist — REPRODUCE VERBATIM

Do not modify, summarise, reword, or regenerate. Pre-fill the answer column with `Y`; leave
row 28 blank unless the EAI Interface Catalogue entry is confirmed.

```markdown
*To approve the document, please leave a comment with the word "Approved" in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver's satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |
```

---

## Default notification recipient

`IntegrationSupport@metcash.com` — used for all integration error notifications across the corpus.
