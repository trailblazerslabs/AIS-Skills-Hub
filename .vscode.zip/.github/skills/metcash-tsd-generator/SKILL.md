---
name: metcash-tsd-generator
description: 'Generate a Metcash AIS Technical Specification Document (TSD) from the standard four-file input set: an approved FSD, a field-level Mapping document, a Mapping Manifest, and the FSD walkthrough meeting transcript. Derives all structure, design patterns, naming, infrastructure facts, and boilerplate from the approved TSD reference corpus in reference-corpus/. Use when asked to "create a TSD", "generate a technical specification", "produce TSD from FSD", "write the technical design", or when an FSD + Mapping + Mapping Manifest + walkthrough transcript are supplied for technical design. Selects the correct AIS architecture archetype (APIM-only, APIM + Logic App, Function App event-driven, or file/MFT batch) and asks the user to confirm design decisions before generating.'
---

# Metcash AIS TSD Generator

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — read its Quick Resume/Open Gaps before starting Step 0, then set this
> phase's row to Done (with the TSD's path) and refresh Quick Resume once §15 is complete.

Generates a Technical Specification Document from an approved FSD and Mapping Manifest, using
nine approved production TSDs as the design authority.

## When to Use This Skill

- The user supplies an FSD (and usually a Mapping Manifest) and asks for a TSD
- The user asks to convert a functional specification into a technical design
- The user asks to update or extend an existing TSD against a revised FSD

## When NOT to Use This Skill

- No FSD exists — generate the FSD first (`tibco-to-fsd` or `ba-to-fsd`)
- Comparing two TSDs — use `tsd-comparer`
- Field-level mapping documents — use `tibco-to-fsd-mapping`
- Logic App / Function App / ADF *code* generation — use the AIS codegen skills

## Prerequisites

Every TSD request comes with **four input files** (the Input Contract — see below). Diagram
templates and the reference corpus are already bundled with this skill; nothing else is required
to start.

- Reference corpus present at `reference-corpus/converted/` with the derived references in
  `.github/skills/metcash-tsd-generator/references/`
- Diagram templates at `templates/diagrams/` and the conventions in
  [references/08-diagram-conventions.md](references/08-diagram-conventions.md)
- **draw.io Desktop** (`C:\Program Files\draw.io\draw.io.exe`) for local PNG rendering of the
  diagrams built by `tools/diagrams/build_drawio.py` (Step 5). **Verified 2026-10-02:** the desktop CLI
  renders both bundled `img/lib/...` icons and embedded data-URI images correctly on the approved
  corpus files, so no browser session is needed for the render/verify loop. The older claim that the
  CLI export was unreliable applied to hand-written XML using icon paths that do not exist
  (e.g. `azure2/general/Cloud.svg`); every icon in `tools/diagrams/icons.json` is proven to render
  (`render_drawio.py --icon-test`). A browser (Playwright / `claude-in-chrome`) remains a fallback
  for opening the file in `app.diagrams.net` if draw.io Desktop is missing - ask before installing.
- `pandoc` for the `.docx` export (Step 7), and a local PlantUML renderer (Java + a `plantuml.jar`,
  commonly already present via a VS Code/Cursor extension) for the sequence diagram (Step 7).

**Tooling hard-stop rule (applies everywhere in this skill):** if a required tool is missing —
Playwright/browser automation, pandoc, Java, a PlantUML jar, or anything else — **do not install
it yourself and do not silently work around it with a lesser method.** Stop, tell the user exactly
what's missing and why it's needed, and ask them to confirm before installing anything or
proceeding on an alternate path. This includes package-manager installs (`winget`, `pip`, `npm`,
etc.) — even a normally-safe one — and it includes swapping the Step 5 render for a lesser method
(e.g. hand-editing XML, or exporting from a file the builder did not produce).

## Input Contract

Every TSD generation request supplies exactly these four documents. Expect them every time —
do not ask the user to explain the set, only to confirm which EAII-ID(s) they cover.

| # | File | Format | Drives |
|---|---|---|---|
| 1 | **FSD** | Confluence MHTML export (`.doc`) | §1, §2, §4.1, all of §5, §6.3, §8.5, §10, §12 |
| 2 | **Mapping** (field-level) | Confluence MHTML export (`.doc`) | §5.x.6.3.7, §5.x.6.3.8, §8.1 |
| 3 | **Mapping Manifest** | Confluence MHTML export (`.doc`) | §5.x.6.3.7 schema/record-type summary, transformation entry points |
| 4 | **FSD Walkthrough Transcript** | Teams meeting recording export (`.docx`) | §5.x.5 Design Considerations, §13 Assumptions — **pre-answers Step 2 questions** |

The transcript is not boilerplate — it is a live design conversation between the solution
architect and the team, and routinely settles the archetype choice, retry/error-handling
approach, and scope boundaries **before** the FSD prose is updated to reflect them. Mine it before
asking the user anything in Step 2.

## Core Principles

1. **The corpus is the design authority.** Structure, table shapes, naming, infrastructure
   values, and boilerplate come from the approved TSDs — never invented. When the corpus is
   silent, say so; do not fabricate a convention.
2. **Evidence-based content.** Every functional claim traces to the FSD; every field-level claim
   traces to the Mapping Manifest; every infrastructure value traces to
   [references/03-naming-and-infrastructure.md](references/03-naming-and-infrastructure.md).
3. **Best-fit design, explicitly justified.** Pick the architecture archetype that fits the FSD's
   trigger, payload, volume, and latency profile — then state *why* in §5.x.5 Design
   Considerations. Do not default to the most complex option.
4. **Technical specificity is mandatory.** A TSD that says "as per standard" or leaves an empty
   table has failed. Every section either carries concrete technical detail or an explicit
   `*<To be confirmed — [exactly what is needed and from whom]>*`.
5. **Never fabricate secrets or endpoints.** Secret *names* and endpoint *patterns* are required;
   secret *values* are forbidden. Unknown values become `*<To be confirmed>*`.
6. **Template structure is fixed.** §1–§15 in order. Sections are never removed or reordered.
   Optional subsections (§4.5, §6.1.1, §6.2.1–2, §6.3.2–4, §6.6, §14.1) are added per
   [references/01-canonical-structure.md](references/01-canonical-structure.md).
7. **Evidence precedence, research before TBC.** Decide in this order: FSD + transcript, then the git history of
   source repos that already implement the pattern, then approved precedent TSDs, then platform defaults
   ([references/12-shared-platform-dependencies.md](references/12-shared-platform-dependencies.md)). A permanent
   `*<To be confirmed>*` is allowed only for items that need a decision or an external party. Never make the developer ask
   for a shared resource, a default or a repeated convention by hand.

---

## Instructions

### Step 0: Intake ⏸️ USER INTERACTION REQUIRED

**0.0 ⛔ Mandatory: verify ADO MCP + GitHub MCP access.** Run the pre-flight check in
[`azure-local-auth`](../azure-local-auth/SKILL.md#-mandatory-pre-flight-check--required-before-generating-a-tsd-generating-code-or-generating-unit-test-cases)
before touching the input files. Do not generate a TSD with either MCP unverified — TSD work
items live in ADO and a legacy TIBCO source (when one exists, see Step 0.6) is read via GitHub MCP.

**0.1 Locate the four inputs.** They typically arrive together in a drop folder (historically
`Doc/Temp/`). Identify the EAII-ID(s) from the filenames and stage them:

```powershell
New-Item -ItemType Directory -Force -Path "tsd-inputs\<EAII-ID>\source" | Out-Null
Move-Item -LiteralPath "<drop-folder>\*EAII-<ID>*" -Destination "tsd-inputs\<EAII-ID>\source" -Force
```

If fewer than four files are present, or one doesn't match the Input Contract, stop and ask the
user rather than proceeding on a partial set — silently treating a missing Mapping or Manifest as
"not applicable" produces an under-specified TSD.

**0.2 Convert every file to markdown.**

```powershell
# FSD, Mapping, and Mapping Manifest are Confluence MHTML exports
python reference-corpus\_tools\mhtml_to_md.py "tsd-inputs\<EAII-ID>\source" --outdir "tsd-inputs\<EAII-ID>\converted"

# The walkthrough transcript is a real Teams-exported .docx
python reference-corpus\_tools\transcript_to_md.py "tsd-inputs\<EAII-ID>\source" --outdir "tsd-inputs\<EAII-ID>\converted"
```

This produces `FSD-EAII-<ID>/`, `MAP-EAII-<ID>/`, `MANIFEST-EAII-<ID>/`, and a transcript `.md` —
verify all four landed before continuing (`mhtml_to_md.py` will fail loudly per file rather than
silently skip one; check its output).

**0.3 Read the FSD in full.** Extract, per interface:
interface ID + business name, source/target systems, trigger and schedule, payload format and
size, transformation summary, API endpoints (FSD §3.x.3), GSB service level (§3.x.4), data
classification (§3.x.5), NFRs (§3.x.6), exception scenarios (§3.x.7), monitoring (§3.x.8),
reporting (§3.x.9), context/assumptions (§3.x.10), test scenarios (§3.x.11), known issues
(§1.4 and §3.x.1.3), and the Horizon Impact rating (§1.3).

**0.4 Read the Mapping and Mapping Manifest.** Extract schemas, record types, branching, sample
payload paths, and the transformation entry points.

**0.5 Delete existing output for this integration.**

```powershell
Remove-Item -Path "tsd/<IntegrationName>" -Recurse -Force -ErrorAction SilentlyContinue
```

Never accept an existing TSD as "already done" and never read one as source material.

---

### Step 0.5: Mine the Walkthrough Transcript ⏸️ BEFORE ASKING THE USER ANYTHING

Read the converted transcript in full. It is a speaker-turn markdown
(`**Turn N — Speaker** *(mm:ss)*`) produced by `transcript_to_md.py`. Read
[references/09-transcript-mining.md](references/09-transcript-mining.md) for the phrase
patterns to scan for, then build a **Decisions Extracted from Walkthrough** table:

```
| Topic | Decision | Cited from |
|---|---|---|
| Archetype | Logic App Standard (not Function App) — low call volume, small payload | Turn 11, Magesh Parthasarathy, 15:29 |
| Legacy topology | BWCE proxy + BW6 backend calling PE stored procedures — proxy layer dropped in AIS | Turn 2, Vladimir Gurieff, 0:08 |
| Scope | 5th operation (get new customer number) already built under a separate credit-application interface — excluded | Turn 2, Vladimir Gurieff, 0:08 |
```

Every row **must** cite a Turn number, speaker, and timestamp — never paraphrase a decision
without the citation, and never present a hedge or a debated point as a settled decision.

**Every Step 2 question this table already answers is skipped in Step 2** — present it to the
user as "confirmed from the walkthrough" with the citation, not as a question. Only ask Step 2
questions the transcript leaves open.

---

### Step 0.6: Legacy TIBCO Source Discovery (migration interfaces only) ⛔ MANDATORY WHEN APPLICABLE

Skip entirely for a net-new interface (no legacy platform being replaced). For a **migration**
interface, find and record the real TIBCO source **before** writing the questionnaire — do not
leave the repo/entry-point unresolved and hope codegen finds it later.

1. Check the FSD and the Step 0.5 transcript-mining table first — the SME walkthrough often
   already names the TIBCO process/repo (e.g. "BWCE proxy + BW6 backend" style references). If a
   repo name and entry-point file are already stated there with a citation, use them directly.
2. If not already named, use GitHub MCP to find it: `search_repositories` for the interface's
   TIBCO application name (from the FSD's legacy-platform description), then `list_directory` on
   the matched repo's root and `get_file_contents` on the likely entry point(s) (`.process`,
   `.bwp`) to confirm it's the right one — read only the interface(s) in scope, never the whole
   repo. This is the same discovery pattern `tibco-azure-nfr-recommendation` already uses.
3. Record the result — **repo name, entry-point file(s), and how it was found** (cited transcript
   turn, or GitHub MCP search) — as its own line in the intake questionnaire (§1.5, see template)
   and, once approved, verbatim into the generated TSD's §5.x.1.1 Description of Process(es)
   alongside the other legacy artefact names, per
   [references/01-canonical-structure.md](references/01-canonical-structure.md). This is what
   `ais-codegen-readiness`'s own TIBCO cross-check (§5 of its questionnaire) reads back later —
   without it recorded here, that cross-check has nothing to consult.
4. If GitHub MCP can't find a confident match, **do not guess a repo name.** Record it as an open
   gap (kind A) in the questionnaire and TSD §13 Assumptions instead — the same rule as any other
   unresolved TBC.

---

### Step 0.7: Research Before TBC, and the Gap Register ⛔ MANDATORY (rule 2026-10-04)

Found on EAII-536..541: the developer had to ask for XREF access, retention, inbound auth, SMC names, the enabling Key Vault,
private endpoints and RBAC rows one by one. They were all derivable. Before the questionnaire is written:

1. **Classify every open item** as `research` (answer is in a repo, git history, corpus or platform default), `default` (apply
   the platform default, record an assumption), `ask` (needs a developer decision), or `external` (owned by another team).
   Only `ask` and `external` items may stay `*<To be confirmed — what from whom>*` in the TSD.
2. **Research items**: read the sibling repos with git on the local clones (for example `Metcash.CoreSys.Storeline`
   `connections.json` / workflows for SMC XREF, the same workload's `appsettings.*.json` for namespaces and queues). Cite the file
   and branch as evidence. Never call an ADO MCP tool for this; the clone and `git log` / `git show` are enough.
   **Research never lowers a 🟥 NEEDS INPUT fact (rule 2026-10-04).** The facts `workload`, `repo` (with the suggested branch and PR
   title), `storage_account`, `queue_topic`, `smc_names`, `consumer_change` and `target_endpoints` are the developer's decisions. What
   you found in a sibling repo, git history, the corpus or a platform default goes into §3A as a **Researched proposal** beside the
   question, which the developer can copy or overwrite, but the fact stays 🟥 with `⟪ fill in ⟫` until the developer answers it. In
   `intake_gaps.py scan --prefill` put the research under `answer` / `note` and **never set `"answered_by": "user"`**; only a value the
   developer actually wrote, in chat or by editing the file, may carry that flag. Say so in your hand-off message: list the
   facts still blocking, never describe the gate as nearly clear because of your own proposals.
3. **Derive shared dependencies** from [references/12-shared-platform-dependencies.md](references/12-shared-platform-dependencies.md):
   the standing SMC block (APIM `smc-v1`, observation queue, SMC and hub Service Bus namespaces, enabling Key Vault), the SMC
   environment mapping, the RBAC rows and the private-endpoint rows they imply, and the cross-subscription note.
4. **Register every gap** and keep it consistent through every refinement:

```powershell
python .github\skills\metcash-tsd-generator\tools\intake\gap_register.py init  tsd-inputs\<EAII-ID>   # from the questionnaire gap table
python .github\skills\metcash-tsd-generator\tools\intake\gap_register.py resolve tsd-inputs\<EAII-ID> G2 --decision "<what was decided>" --evidence "<file / branch / turn>"
python .github\skills\metcash-tsd-generator\tools\intake\gap_register.py sync  tsd-inputs\<EAII-ID>   # rewrites the questionnaire gap block
python .github\skills\metcash-tsd-generator\tools\intake\gap_register.py check tsd-inputs\<EAII-ID> "<tsd-file>"
```

   The TSD is a standalone document and never cites the gap register: no `G2`/`Q3`/`TBC-1` ids, no "questionnaire", no "§3A", no
   transcript turn numbers. State the decision or fact itself; an unresolved item reads `*<To be confirmed — [what] from [whom]>*`.
   When a gap is resolved, find the topic in the TSD and update **every** place (design decision, §12 limitation, §13 assumption)
   in the same change, then run `check`. A resolved gap that the TSD still describes as open is a defect.

---

### Step 0.75: Editable Intake Questionnaire ⏸️ MANDATORY PAUSE — default mechanism for Steps 1 + 2

**Hard precondition: never generate this file until Steps 0.1–0.5 above are fully complete** — all
four inputs staged and converted, the FSD read in full (0.3), the Mapping/Manifest read in full
(0.4), and the transcript mined into the cited Decisions table (0.5). The questionnaire must
reflect genuine, evidenced understanding of this specific interface, not a generic blank form
handed out before reading anything. If you have not yet read the FSD/Mapping/Manifest/transcript,
go back and do that first — do not shortcut intake by producing the questionnaire early.

**This is the default intake flow for Steps 1 and 2:** after reviewing all source evidence, use
`vscode_askQuestions` inline for each unresolved, ambiguous, or conflicting design decision. Each
question must show the proposed answer, evidence citation, and impact if unanswered, with a clear
way to confirm, correct, or leave the item blocked. Batch independent questions; ask dependent
questions in sequence. Incorporate the user's answers and provenance into the questionnaire.
Settled source facts are presented as evidence, not re-asked. Once the inline question round is
complete, write:

`tsd-inputs/<EAII-ID>/intake-questionnaire.md`, from
[templates/intake-questionnaire.template.md](templates/intake-questionnaire.template.md).

**Every question and the archetype selection must carry a proposed answer, not a blank field.**
For each one, work out the best-supported answer from the FSD, Mapping/Manifest, transcript, and
corpus precedent, and write it in as the pre-filled "Proposed:" value — the same rigor Step 1/2
would apply live. Never leave a question with only a bare default label and no reasoning; state
*why* that answer is proposed (evidence or corpus precedent), so the user can approve it at a
glance or override it with a one-line edit.

Populate it with:
- The Step 1 archetype recommendation, evidence, and closest corpus precedent, pre-filled as the
  proposed choice
- The Step 0.5 Decisions Extracted table (confirmed items, for awareness only — not questions)
- The Step 0.6 Legacy TIBCO Source finding (§1.5 of the template), for migration interfaces only
- One numbered question block per **still-open** Step 2 question, each with a proposed answer and
  its rationale pre-filled, ready to accept or overwrite. Where a question concerns a non-trivial
  runtime mechanism (e.g. a content-based router, a partial-failure/retry strategy, a
  concurrency/singleton constraint), don't stop at a one-line proposal — work out and write in the
  concrete step-by-step design (what dispatches on what, where state is held, what the failure
  path does), the same depth §5.x.5 Design Considerations would need, so the user is approving a
  real design, not just a label
- **An "Open Questions & Gaps" table** (see below) — this is mandatory, not optional

**The Open Questions & Gaps table.** Beyond the Q&A list, always include a dedicated table of
items that are **not fully settled** by the four inputs, split explicitly into two kinds:

- **(A) Transcript-unresolved** — a decision point the SMEs raised live but never actually
  answered on record (e.g. "we'll check the code and get back to you" with no follow-up
  visible in the transcript, or an explicit "let's take it up during the technical discussion").
  Do not silently treat these as settled just because a document elsewhere states a value —
  cross-reference the document's claim against the live uncertainty and flag the gap explicitly
  if the transcript never actually closes it.
- **(B) Copilot-identified** — a gap or risk you noticed while cross-reading the FSD, Mapping,
  Manifest, and transcript together that nobody raised live: e.g. a record type with zero
  production sample coverage, a stated business constraint (like "singleton" or "one at a time")
  that doesn't automatically hold in the target Azure runtime model and needs an explicit
  mechanism decision, or two documents that appear to contradict each other until read closely
  (in which case, resolve it yourself from the evidence and say so — mark it resolved, not open,
  but still show your reasoning so the user can sanity-check it).

Every row must have: a one-line description of the gap, its evidence citation (Turn/speaker/
timestamp for transcript items; FSD/Mapping §-reference for document items), and either a
recommended action (for genuinely open items) or the resolution and supporting evidence (for
items you resolved yourself). These rows are not disposable — they must reappear in the generated
TSD as explicit `*<To be confirmed>*` entries in §12 Limitations and/or §13 Assumptions (Core
Principle 4), never silently dropped once the questionnaire is approved.

**Facts the design needs (§3A of the questionnaire) — forced, design-driven inputs.** After the
archetype is proposed, generate the "missing facts" section so the developer is made to supply what
the FSD never contains. In the approved 304/374 pairs the storage account, container/folder names, repo
name, public API path, Service Bus name, GoAnywhere details and DB2 host/schema are **never** in the
FSD but **always** stated in the TSD:

```powershell
python .github\skills\metcash-tsd-generator\tools\intake\intake_gaps.py scan tsd-inputs\<EAII-ID>\converted `
    --archetype <A|B|C|D|hybrid-async-upload> [--flags +db2,+goanywhere,+file_target] `
    --out tsd-inputs\<EAII-ID>\intake-facts.md
```

Paste the output into the questionnaire as §3A. Which facts are asked depends on the design
(`tools/intake/required-facts.json`): a blob container/folder is asked for only when files are staged
in Blob Storage, DB2 details only for a DB2 target, GoAnywhere fields only when MFT is in the design,
the repo only when there is Logic App / Function App / ADF code, and so on. Markers: 🟥 NEEDS INPUT
(cannot be guessed — blocks generation), 🟧 CONFIRM (evidence found or a value can be proposed —
does not block), ⬜ RECOMMENDED, ✅ FOUND. **Re-run `scan` whenever the archetype or a component
changes**, and never invent a 🟥 value: leave it for the developer. A blocking fact (`level: block` in `required-facts.json`) may be
lowered only by value-bearing evidence in the four inputs (the heading then carries `src:inputs`) or by the developer's own answer
(`src:user`); `intake_gaps.py check` fails any other 🟧/✅ heading on a blocking fact.

**Gate (mandatory before Step 3):**

```powershell
python .github\skills\metcash-tsd-generator\tools\intake\intake_gaps.py check tsd-inputs\<EAII-ID>\intake-questionnaire.md
```

It must print `OK`. If it prints `BLOCKED`, list the 🟥 items to the user and stop.

**Then stop. Do not proceed to Step 3 under any circumstances until the user has explicitly told
you the questionnaire is filled in / approved.** Tell the user the file is ready, where it is, and
that generation is paused until they respond. Proposed answers are recommendations for the user to
review, not silent defaults you may act on without confirmation — even if the user goes quiet,
do not assume the proposed answers are accepted and continue on your own.

**Re-read the questionnaire right before generating.** On a shared feature branch teammates edit the answers after the file was produced (EAII-536..541: resource names, blob paths and the lookup mechanism changed the day after generation). Run `git pull` (fast-forward only) and re-read the file at the start of Step 1, and again before the final push. If an answer changes the design (for example a Table Storage lookup replaced by SMC XREF, or GoAnywhere marked "Not Required"), update the diagram specs and every section that names the component; do not patch only the text. Answers that contradict the FSD are the user's decision: apply them, and record the conflict in §5.x.5 and §13.

When the user confirms, re-read the file in full, treat every line (whether left as proposed or
edited) as the confirmed answer, and proceed. If an edited answer conflicts with FSD/transcript
evidence, flag the conflict back to the user rather than silently overriding one or the other.

Inline questions are the interaction used to complete Steps 1 and 2; do not launch a second,
duplicate question loop after the questionnaire is written. The questionnaire remains the
durable review record and its explicit approval remains required before TSD generation.

---

### Step 1: Architecture Archetype Selection ⏸️ USER INTERACTION REQUIRED (live-chat alternative)

Run this step live only if the user explicitly asked to answer questions in chat instead of via
the Step 0.75 questionnaire file. Otherwise Step 0.75 already covers this.

Read [references/02-reference-architectures.md](references/02-reference-architectures.md) and
select the archetype using the decision table there. Then present your recommendation to the user
with the evidence behind it:

```
Recommended archetype: B — APIM + Logic App Standard
Evidence from FSD:
  - Trigger: synchronous REST call from Salesforce (FSD §3.1.1)
  - Transformation: JSON → SOAP envelope + response mapping (Manifest §2)
  - Volume: < 1 TPS, ad-hoc (FSD §3.1.6)
  - Latency: P95 < 5s (FSD §3.1.6)
Closest corpus precedent: TSD-EAII-297 (Salesforce → IBM MDM, APIM + Logic App)
Rejected: Archetype A (APIM-only) — SOAP envelope construction and multi-step
  orchestration exceed what is maintainable in APIM policy alone.
```

**Ask the user to confirm or override.** Do not proceed until confirmed.

---

### Step 2: Design Decision Questions ⏸️ USER INTERACTION REQUIRED (live-chat alternative)

Run this step live only if the user explicitly asked to answer questions in chat instead of via
the Step 0.75 questionnaire file. Otherwise Step 0.75 already covers this — do not run both.

Ask these with `askQuestions`, **one at a time**, skipping any the FSD or the **walkthrough
transcript** already answers unambiguously — present transcript-sourced answers as confirmations
with their citation rather than re-asking. Record every answer — they become §5.x.5 Design
Considerations and §13 Assumptions.

| # | Question | Default if unanswered |
|---|---|---|
| 1 | Confirm the TSD title: `Technical Specification - <IDs> - <Source> to <Target>` — use the FSD's system names or the TSD system names? | FSD system names |
| 2 | Which interfaces from the FSD are in scope for this TSD? (multi-interface FSDs may split) | All |
| 3 | Workload name for Azure resource naming (the `{workload}` token, e.g. `metproducts`, `mdmsupplierinfo`, `suppliercontract`) | Derive from FSD business name; flag as TBC |
| 4 | New or existing Function App / Logic App / APIM instance? If existing, which? | New; flag as TBC |
| 5 | Target system authentication: mTLS, OAuth 2.0 client credentials, OAuth 2.0 password grant, WS-Security, API key, or none? | From FSD §3.x.3; else TBC |
| 6 | Failure policy: dead-letter immediately on first delivery, or Service Bus redelivery to `maxDeliveryCount` (e.g. 5 x 5 min) so a transient failure recovers without manual SMC resubmission? Note each attempt writes 2 SMC entries | Dead-letter immediately for Function Apps; for a Logic App, stateless + PeekLock + `maxDeliveryCount` where SMC resubmission is not the recovery path (see ref 02 cross-cutting rules) |
| 7 | Retry policy per action: count, interval, sync or async, internal (Azure) or external, and the cumulative worst case against the PeekLock duration | Async internal: max 2, 2-3 s (Logic App minimum 5 s); sync: none; Stibo/PE procedure: none; set `retryPolicy` explicitly, never the platform default. Adjust per use case/connector and give the reason |
| 8 | Source payload retention window in Blob Storage | 90 days (corpus default); 30 days seen once |
| 9 | Environments: DV1/ST1/UT1/PRD, or does this interface include PREPROD? | DV1/ST1/UT1/PRD |
| 10 | §5.x.6.3 shape: full 9-subsection per-service block, or collapsed `Audit, Logging & Exceptions`? | Full block if 1 service; collapsed if >1 interface in the doc |
| 11 | Publish to Confluence when complete, and/or create ADO test cases from §5.x.10.2? See Step 8 for the publish procedure. | Markdown only |
| 12 | Synchronous or asynchronous, and the response-time budget? Logic App vs Function App rationale (orchestration only, DB2/opaque connector, timeout/cancellation control)? | From FSD latency/trigger; record the reason in §5.x.5 |
| 13 | Logic App state: stateless (PeekLock, explicit complete, queue retry) or stateful (SMC resubmission needed)? Function App: PeekLock explicit complete/dead-letter? | Stateless where not critical; stateful only with the SMC-resubmission reason |
| 14 | Concurrency and throttling: trigger parallelism / max waiting runs / `maxConcurrentCalls`, one file or message at a time, pause between downstream calls, max concurrent connections to the target, App Service Plan impact? | Stated limit (parallelism 100 / waiting 10 for a Logic App); concurrency 1 and 2-3 s pause where the target locks items |
| 15 | Volume and performance test: daily volume **and** peak window (`TBC from whom` if unknown), planned load (24 h compressed to 30-60 min, 2-5x peak), file source, non-prod limitation, test owner and ADO card? | Peak window TBC; test owner = testing team; ADO card per interface |

---

### Step 3: Generate the TSD

Create `tsd/<IntegrationName>/Technical Specification - <IDs> - <Source> to <Target>.md` from
[templates/TSD.template.md](templates/TSD.template.md).

Populate section by section using
[references/06-fsd-to-tsd-traceability.md](references/06-fsd-to-tsd-traceability.md) for the
FSD→TSD source map and
[references/04-standard-boilerplate.md](references/04-standard-boilerplate.md) for every block
that is reproduced verbatim across the corpus.

**Section-specific rules** (each exists because of a defect found in an approved or generated TSD — see
[references/10-known-defects-in-approved-tsds.md](references/10-known-defects-in-approved-tsds.md)):

*Values the FSD never contains come from the approved questionnaire §3A (`tools/intake`) — never invent them.*

- **§1.1 Background** — **rewrite, do not paste the FSD paragraph.** §1 is an overview only (what the document is about, its
  purpose, scope and what the reader will find): one short paragraph of about 4-6 lines stating migration vs net-new,
  the legacy platform if migrating, the business purpose in one sentence, the AIS component and the systems by name.
  No process steps, mappings, volumes, NFR/retry figures or design reasoning here; each of those is written once, in
  the section that owns it (see *Progressive structure, no duplication* below).
- **§1.3 Glossary** — copy from FSD §1.5, then extend with every Azure service, protocol and acronym the TSD
  introduces. Sort alphabetically. Corpus glossaries run 10–25 rows.
- **§2.1 In Scope** — restate FSD scope *as technical work items*, each naming the implementing AIS component.
  Include SMC onboarding, Key Vault integration and Managed Identity as explicit lines.
- **§2.2 Out of Scope** — FSD §2.2 plus boundaries the walkthrough settled (e.g. the 374 fifth operation already
  built elsewhere), plus `Known Issue NOT addressed:` lines for any FSD known issue not designed for.
- **§3.1 Architecture Principles** — the IDP table; one row per *applicable* principle; the "why it applies"
  cell names **this interface's** components. Never reuse another interface's text.
- **§3.2 Standards, Guidelines and Patterns** — every pattern row describes a component that is also in §4.3
  (check: `pattern-component-not-in-4.3`). Naming Event Grid / Service Bus / Functions when the design has none is a
  copy-paste defect. Plus the four standards sub-tables with the concrete resource names.
- **§4.2 / §4.5 NFRs** — **every figure traces to the FSD**; the availability figure is the FSD service-tier figure
  (Silver = 95%). Anything the FSD does not state is `*<To be confirmed>*`, never invented (check: `nfr-not-in-inputs`).
  §4.5.1 Retry Strategy states the rationale; when it differs from an FSD figure (retries, timeout), say so. It is a
  per-action table (internal/external, sync/async, count, interval, cumulative vs PeekLock duration, reason) built from
  the retry rules in ref 02; §4.5 also states peak volume/window, concurrency and the performance-test plan.
- **§4.3 Required Components** — only what this design uses; Key Vault, Application Insights, Log Analytics and VNet
  always; Component | Purpose table.
- **§5.x.1 As-is** — migrations: legacy artefact names (`.bwp`, `.wsdl`, `.xsd`), the TIBCO repo and entry points
  recorded in questionnaire §1.5. Net-new: "New integration — no as-is process."
- **§5.x.2.1 Proposed Process** — numbered steps naming the Azure component performing each. For a two-phase
  design (EAII-304: synchronous upload, asynchronous translation) use labelled phases, each numbered from 1. The
  simple process-flow diagram shows the same components in the same order (it has no step circles, see Step 5).
- **§5.x.3 Coordination** — **never `NA`.** State synchronous / asynchronous / both, the transaction boundary and where
  state lives (blob folders, queue). A request-reply interface says it holds no state; it still says it.
- **§5.x.4 GoAnywhere** — a short description only; **do not generate the GoAnywhere requirements table** (GoAnywhere is configured by
  the MFT team and is out of scope for AIS development). Say what is picked up and delivered, the hand-over location and the
  file name pattern, and state that GoAnywhere generates the SMC ID, carries it in the file name, and the first AIS component
  uses it as `ParentObservationID` for every SMC observation of the whole flow. `N/A — GoAnywhere is not used` only when truly absent.
- **§5.x.5 Design Considerations** — numbered decisions with rationale, carrying every questionnaire answer and every
  rejected alternative, **plus every override of an FSD figure or contract** (retry counts, timeouts, error codes,
  public path) and the consumer impact owner (questionnaire fact `consumer_change`). It also carries the Step 2 answers 12-15:
  sync/async and Logic App vs Function App reason, stateful vs stateless, concurrency/throttling and the downstream limit.
- **§5.x.6.1 Component List** — column set per [01-canonical-structure.md](references/01-canonical-structure.md);
  the `Repository` column names the real ADO repo from questionnaire §3A (never `NA` for code).
- **§5.x.6.2 / 6.3 Services** — one `5.x.6.3` block per service listed in §5.x.6.2 (or the collapsed form for
  multi-interface TSDs). A listed service with no block is a defect.
- **§5.x.6.3.3 Exceptions** — every FSD §3.x.7 scenario maps to a row, split by stage, plus the mandatory
  `EAII<nnn>-099` catch-all. Codes are **always `EAII<nnn>-<seq>`** (never `HTTP-nnn` / `*-ERR-*`); if the FSD defined
  codes, state which TSD code retires each. Business outcomes that are not transport errors (non-zero return code
  with HTTP 200, "no rows") get their own Business rows. **Beyond the FSD list, add the rows the design itself creates**
  (found by comparing a generated TSD with the approved 374; `quality_review.py` rules KB-B04..B08): for an APIM + Logic App
  design the **APIM → Logic App backend unavailable / timeout (HTTP 502 / 503 / 504)**; for a database target the **DB
  credential rejected** and **DB user not authorised for the object**; a **request-transformation failure** (cast / padding
  / mapping before the call); and, when one workflow switches on an operation id, an **invalid or missing operation id** row.
  Mark each row not in the FSD as "added by this TSD". Do not add a rate-limit (429) row unless the FSD or questionnaire states a limit.
- **§5.x.6.3.5 Service Operations** — the template columns include the exact **Endpoint** path; state the base path
  once and use that exact string in §5.x.10.2 and every diagram.
- **§5.x.7.1 / 5.x.7.2** — full SMC field list from [05-smc-observability-patterns.md](references/05-smc-observability-patterns.md)
  with names from questionnaire §3A; Load Estimations is **5.x.7.2** (never a second 5.x.7.1); figures only from the FSD.
- **§5.x.10.2 Unit Testing** — **test cases are `TC-nnn`** (sequential from TC-001, ADO import shape `ID | Work Item Type
  | Title | Step Action | Step Expected | FSD ref`), identical to what `ais-unit-test-cases` creates. Each FSD scenario
  T1..Tn is covered by ≥ 1 TC and cited in `FSD ref`; add TCs for what the FSD omits (auth 401/403, rate limit,
  correlation, SMC success/failure, timeouts, large results). §5.x.6.3.2 Audit rows cite TC ids.
- **§6** — infrastructure values verbatim from
  [03-naming-and-infrastructure.md](references/03-naming-and-infrastructure.md); never invent a VNet, subnet, IP,
  subscription or resource group. §6.4 per-environment endpoints/schemas come from the FSD or questionnaire §3A and must
  match §5.x.6.1 exactly. §6.3.2 inventories every secret *name* the design reads.
- **§8.2–8.4** — `NA` unless a database is called; for a DB2/SQL target list the stored procedures / table functions
  (§8.2) and the connector that triggers them (§8.3), as in the approved 374.
- **§8.5 Data Retention** — one row per blob folder with its retention in days, and the lifecycle-management rule steps
  in §8.5.3.2 (approved 304). Never a bare `NA` when data is staged.
- **§9.3** — names the ADO repository, a suggested branch `feature/{EAII-ID}-{description}` and PR title, and points to the
  per-environment deployment runsheet (`ais-deployment-runsheet`) with the rollback approach (redeploy the previous tagged
  release of the workflow / APIM revision) — the approved 374 had this and a generated TSD missed it.
- **§6.5 compute hosting** — state the compute host and SKU per environment: Squad 20 Logic Apps / Function Apps run on a
  shared App Service Environment v3 plan (`03-naming-and-infrastructure.md`); the approved 374 gave ASP `I1V2` non-prod /
  `I2V2` prod and APIM Developer / Premium, while 297 gave Standard. The two disagree, so write the host and plan name from
  `03` and put the SKU as `*<To be confirmed — SKU per environment from the platform team>*` rather than choosing one.
- **§5.x.2.3 / 2.4 sequence for several operations** — when the operations call different backend objects, the PlantUML has
  one `== <Operation> ==` group per operation (or one group naming all of them with each object) plus a failure group
  (invalid token / invalid request); a single generic flow that never names an operation fails `XR-05`.
- **§10 / §12 / §13** — §10 from the FSD service-tier text (never the template sentence); §12 from FSD §2.3 plus the
  standing Azure limits (or one row stating none were found); §13 carries the consumer-change assumption with its owner and
  every questionnaire §4 gap as `*<To be confirmed — [what] from [whom]>*`.
- **Shared and platform dependencies (rule 2026-10-04, all sections)** — derive them from [references/12](references/12-shared-platform-dependencies.md), not only from what the workload owns: §3.2 Environment Segregation names the Key Vaults, Service Bus namespaces, the SMC queue and the `dv1/st1/ut1/prd -> dev/uat/uat/prd` mapping; §6.6 lists every Key Vault and namespace used (shared ones included); §6.3.3 has the RBAC rows for every dependency edge (Logic App and APIM to the enabling Key Vault, Logic App to the SMC queue); §6.5 has a private-endpoint row for every Key Vault in §6.3.2 including the enabling one; §6.1.1 notes the HUB vs AIS subscription when a hub namespace is used. Checks: `XR-07`, `XR-09`, `KB-S01..S05`.
- **§4.1.2 links** — one row per document with its Confluence URL from the intake `source_docs` (the FSD links the Mapping page: it must appear, `TR-12`); an unknown link is `*<To be confirmed — from {who}>*`, never blank.
- **§6.5 Workflow Details by default** — for every Logic App / Function design give the table Workflow Name, Type (Stateful/Stateless), Runtime, Hosting, Trigger, Outbound service, Retry, Response (one column per workflow), not prose (`KB-B01`).
- **Progressive structure, no duplication (TSD review comment, 2026-10-12)** — the TSD reads overview first, then detail section by section, and every fact lives in one place. §1 overview (short; no detail) → §2 scope → §4.1 starts the end-to-end system view with the `System Context` block diagram (participating applications/systems and their high-level interaction only), followed by 2-4 sentences of business process that do not repeat §1.1 → §5 integration flow and processing logic → §6 onwards infrastructure and technical detail. Later sections refer back ("see §5.1.2") instead of restating; if a sentence already appears in §1.1, §4.1, §5 or the FSD extract, delete one copy. Crisp and scannable: prefer a table or numbered list to a paragraph, one idea per sentence, no filler.
- **Describe a shared ingestion interface once** — the common ingestion content lives only in its own §5.1; §5.2 and later say "performed by the ingestion interface, see §5.1" and add only what differs (`XR-08` fails on repeated paragraphs).
- **No avoidable TBC** — retention (§8.5.1.1: 90 days archive / 30 days error, EAII-304), XREF access (APIM `smc-v1` `getXrefData`, subscription key from the enabling Key Vault), inbound authentication (OAuth 2.0 JWT, `validate-jwt_v1`) and the SMC onboarding names are filled from evidence or the platform default with an assumption recorded (`KB-D01..D04`).
- **§15** — copy the approval checklist verbatim from the boilerplate reference. Do not regenerate, summarise or
  reword it.

---

### Step 4: Azure Naming Verification

Before finalising any Azure resource name:

1. Apply the Metcash pattern from
   [references/03-naming-and-infrastructure.md](references/03-naming-and-infrastructure.md) —
   this takes precedence over generic Microsoft guidance because it is what the corpus uses.
2. For any resource type not covered by the corpus, call `microsoft_docs_search` with
   `"define your naming convention Azure resources abbreviation recommendations"` and apply the
   returned abbreviation. Do not guess from memory.
3. Cross-check every name against §6.1.1, §6.5, and §6.6 so the same resource is spelled
   identically everywhere in the document.

---

### Step 5: Diagrams

**Diagrams are built, not drawn.** Models are good at deciding *what* is on a diagram and bad at
placing 40 shapes and routing edges by hand (that is what produced edges through icons, markers on
labels and containers cutting through resources in the first generated TSDs). So the model writes a
small JSON **spec**, and `tools/diagrams/` turns it into a `.drawio` in the approved Metcash style:

| Tool | Job |
|---|---|
| `tools/diagrams/icons.json` + `assets/` | The only icons allowed - taken from the approved 297/304/374/514 diagrams (Azure icons, APIM operation hexagon, App Gateway, SMC, GoAnywhere, DB2/AS400, STIBO, ...). Never use a name not in this file; never an external URL |
| `tools/diagrams/build_drawio.py spec.json out.drawio` | Grid layout, nested dashed-blue containers, magenta resource names, blue step circles, red SMC dots, automatic edge routing around icons/labels/titles, auto-widened grid, wrapped edge labels |
| `tools/diagrams/lint_drawio.py out.drawio --steps N` | Geometry lint: edge-through-icon, overlaps, marker-on-label, container-border cuts, mojibake, external icons, step count == §5.x.2.1 |
| `tools/diagrams/render_drawio.py out.drawio outdir` | Local PNG export of every page via the draw.io CLI (scale 2) |
| `tools/diagrams/diagram_quality.py --drawio out.drawio` | Geometry neatness summary; require zero crossings, shared lanes and errors. Spec-scoring mode is the EAII-529 benchmark, not a generic resource inventory check |
| `tools/diagrams/autolayout.py` | Experimental opt-in layout search only; not part of normal generation. Proxy scores can disagree with actual geometry and `--real` can be slow; always rebuild, lint and inspect results |
| `tools/diagrams/SPEC.md`, `specs/EAII-374.sample.json` | Spec reference and a worked 4-page example |

The approved look (do not deviate): nested **dashed `#0066CC` 2px** containers (Azure badge → subscription →
resource group / VNet / subnet), resource names in **magenta `#ce3bae` bold 10px** below each icon,
**black** one-way arrows, **green** two-way arrows for synchronous HTTP, **red** arrows to SMC,
**blue `#2395FF`** numbered step circles, **dark-red `#990000`** dots on components that write SMC
observations, dashed boxes around external source/target systems. Pages (one `.drawio`, in this order):

| Slot | Page name |
|---|---|
| §4.1 System Context | `System Context` — **simple block diagram**, built with `build_simple_flow.py`: one box per participating application/system (source, AIS as a single box, target, shared services such as SMC or the identity provider only when they are an interface party) and a few labelled arrows for the high-level interaction. No Azure resource detail, operations, steps, subscriptions or VNets |
| §5.x.2.2 Process Flow | `{EAII-nnn} Process Flow` (one per interface) — **simple style**, built with `build_simple_flow.py` |
| §6.1 Physical Architecture | `Architecture Diagram` |
| §6.2 Network Connectivity | `Network Diagram` |
| §7.1 Communication | `Communication Diagram` |

**The process flow is deliberately simple (reviewer rule, 2026-10-02).** §5.x.2.2 uses the style of the approved EAII-374 process diagram: a title and one-line subtitle, coloured rounded boxes with no icons and no step circles, the APIM box listing its operations or policy steps, the Logic App box listing its actions, and a handful of labelled arrows (`tools/diagrams/build_simple_flow.py`, sample `tools/diagrams/specs/EAII-538.simple-process.sample.json`). It shows source, gateway, APIM, bus, workflow, lookup, storage, MFT and target only: no Key Vault, Application Insights, SMC dots, subscriptions or VNet containers. Those belong on the Architecture, Network and Communication pages, which keep the icon style (`build_drawio.py`). Keep titles to 28 characters, box lines to 34 and edge labels to 22.

**§2 Scope carries no diagram (reviewer rule, 2026-10-02).** In Scope and Out of Scope are text only: bullets that name the implementing component. Do not generate an `Interface Scope Overview` page or place any image in §2, even for a multi-interface TSD; the overview belongs in §1.1 Background as a short paragraph and in §4.1, which opens with the `System Context` block diagram.

**A common ingestion interface gets its own §5.x section (user rule, 2026-10-03).** When the questionnaire or the user says a shared entry point (for example an APIM-only ingest that publishes to a topic for several target interfaces) is a separate interface with its own EAII id, even if the FSD does not list it, give it its own `## 5.x` block with the full §5.x.1 to §5.x.10 structure, placed **before** the target interfaces (so the targets shift to 5.2, 5.3 and so on). Put the ingest-only content there (token validation, request validation, publish, HTTP replies, exceptions such as 400, 401, 500, its test cases, its SMC onboarding, its own process flow and sequence diagram) and remove it from the target sections; the target steps then say "performed by the ingestion interface, see §5.1". Use the literal id `EAII-XXX` while the number is unassigned, add an open gap for the missing EAII number, and mention it in §1.1 and §2. Test ids stay sequential across the whole TSD, so the ingestion tests come first. Fix every `§5.n` cross-reference after the renumbering.

**Show OAuth wherever APIM validates a token (user rule, 2026-10-03).** Every process flow, architecture, network and communication diagram and every sequence diagram that includes an APIM call shows the OAuth 2.0 identity provider (Entra ID unless the questionnaire says otherwise) as its own node or participant, with two arrows: the caller requests a token from it, and APIM validates the token against it (OpenID configuration and signing keys). Label the policy by its real name (for example `validate-jwt_v1`). Outbound calls that use a managed identity are labelled "managed identity", not OAuth.

Two slots are not generated: §4.1.1 (copy the FSD's own process image into `images/`, flattened onto a white background if it has transparency so it does not render black, and checked with `view_image`) and the
§5.x.2.3 sequence diagram (PlantUML, rendered locally as before).

**Procedure (every page, every archetype):**

1. Write the spec for the page from the confirmed design (questionnaire) and TSD text: resource names
   from §6.1.1/§6.5, numbered steps from §5.x.2.1 (**1:1, same count**; internal steps go on the node as `"step": N`).
2. Architecture, Network, Communication: `build_drawio.py` → `lint_drawio.py`. Process flows: `build_simple_flow.py` (no lint; the render is the check).
   **Fix every ERROR** by changing the spec (never by hand-editing coordinates in the XML); read WARNs.
3. `render_drawio.py`, **open every PNG and look at it** (vision check): overlapping text, arrows that are
   hard to follow, anything the lint cannot see. Re-spec and repeat until clean.
4. Copy PNGs to `tsd/<Name>/images/NN.png` in document order; keep the spec JSON beside the `.drawio` so
   the diagram can be regenerated when the TSD changes.

The archetype changes which components appear, never the conventions. Do not use the draw.io Desktop CLI
on hand-written XML with icon paths you have not verified; the builder only emits catalogued icons.

**Model choice.** The model's job is only the spec. Evaluate candidates with
`tools/diagrams/model-eval/` (`PROMPT.md` → candidate JSON → `score_spec.py`); see its README for the
current leaderboard. Image-generation models are the wrong tool: the deliverable is an editable `.drawio`
whose text must match resource names exactly.

**Pinned diagram model (user choice, 2026-10-04).** Use `Claude Opus 5.5 (copilot)` for diagram spec authoring and subsequent layout repairs. Delegate this step with `runSubagent` and its explicit `model` argument. Give it the approved design, exact resource inventory, `SPEC.md`, and the applicable approved diagram style. Save the authored JSON before building. This is a user-selected model, not a claim that it won the benchmark; the single-run comparison showed crossings in its raw output.

This pin covers every authored diagram input: icon-page JSON, simple process-flow JSON and sequence-diagram PlantUML, including repairs. The parent model may still handle intake and TSD prose. Do not delegate verbatim copies of FSD images or deterministic build/render commands just to attach model attribution.

**Auto does not switch the parent model.** A skill's markdown cannot change the Copilot Chat model picker, and SKILL.md has no supported model-selection frontmatter. Auto may orchestrate the task, but the explicit subagent model pins diagram work to Opus. If that model or model-specific delegation is unavailable, stop and ask the user to select Opus 5.5 manually; never silently substitute another model or infer model identity from a generated reply.

**Layout acceptance.** Build, lint, render and inspect all pages before replacing document images. Require zero errors, zero `edges-cross` and zero `edges-share-lane` findings, no overlapping containers or labels, and readable resource names at document size. Use the actual builder/linter output to judge repairs, not a proxy score. Prefer a small spec repair with a focused rebuild over an unbounded layout search; preserve all required components and dependency edges. If the checks fail, retain the last accepted images and report the failed checks.

**Record the model on every session (rule 2026-10-04).** Every spec JSON carries `"_meta": {"interface", "run", "spec_author_model", "note"}`. `quality_review.py` fails the diagram dimension (`DG-04`) when `spec_author_model` is missing. If the session cannot run the recommended model, write the model that actually authored the spec and say so in the quality report; do not leave it blank, and do not claim the recommended model was used. Re-score a different model only through `model-eval`.

**Do not seed a spec from the answer.** `model-eval/PROMPT.md` and `specs/EAII-374.sample.json` contain the *approved* EAII-374 diagram content (resource names, workflow name, layout). Use them only to evaluate models. When generating a spec for 374 (or any interface whose approved diagram is in a sample), learn the JSON format from a *different* sample (`EAII-304.sample.json`, `EAII-538.simple-process.sample.json`).

**Diagram completeness rules (found comparing run 1 with the approved 374):**
- **One `apim-operation` node per operation** on the Architecture page (up to 6; above that, group by resource and list the rest in `sub`). One APIM node saying "4 operations" hides what the approved diagram shows (`DG-07`).
- **A page wider than 4200 px at the default render scale 2 (about 2100 px at 100%) is unreadable in Word** (`DG-03`): lower the column count (two rows, as in `SPEC.md` layout lessons) and align nodes that connect with a short edge in the same column (`autowiden` stretches the whole page when two nodes with long labels sit less than one column apart), and keep node labels short.
- Put an external system (Stibo, PE) **outside** every container column range; the container is the bounding box of its members, so a node whose column is inside that range is drawn inside the container.
- Where APIM validates an OAuth token, show two identity-provider arrows: token request and token validation (`DG-05`, `DG-06`). Do not invent inbound OAuth for an APIM used only as an SMC subscription-key gateway; record that applicability exception in the quality report.
- **Key Vaults are shown wherever they are used (rule 2026-10-04):** every Key Vault in §6.3.2, including the enabling / SMC Key Vault, is a node on the Architecture, Network (with its private endpoint) and Communication pages (`DG-11`).
- **The process flow shows the SMC logging step** as a node whenever the sequence diagram or §5.x.7 calls SMC (`DG-10`).
- **Legend and routing are automatic:** `build_drawio.py` adds the legend (`legend-*` cells, `DG-12`) and routes edges itself. Do not add `exit`/`entry`/`via` waypoints in a process-flow spec; use them only for a layout the auto-router cannot solve, and expect a builder warning.

---

### Step 6: Quality Gates

Run every check. Prefer mechanistic checks over visual inspection for text/tables — but
diagrams are the exception: XML-structural validation (`inspect_drawio.py`) only proves the
file parses, it does NOT prove the diagram looks correct. Diagrams require an actual visual
render check - see the Step 5 procedure and gate 6.8.

**6.1 Template conformance**
- [ ] §1–§15 all present, correctly numbered, in template order
- [ ] No section added, removed, or reordered relative to the template
- [ ] §15 checklist matches the boilerplate byte-for-byte
- [ ] **Check every NUMBERED SUB-subsection too, not just top-level §1–§15** — sparse-looking
      sections are the easiest place to silently drop a whole subsection. In particular verify
      **§8.5 Data Retention (with 8.5.1/8.5.1.1/8.5.2/8.5.3/8.5.3.1/8.5.3.2) is present** — it's
      documented as mandatory (7/7 corpus presence, see `01-canonical-structure.md`) but is easy
      to skip because §8 otherwise looks like a short, mostly-`NA` section for interfaces with no
      database. If this interface has Blob Storage staging (source/archive/error paths), §8.5.1.1
      needs a `Data | Location | Retention` table covering every one of those paths — cross-check
      against whatever archive/error/retention detail is already stated elsewhere in the TSD
      (§4.5, §5.x Design Considerations, §6.3.5) rather than leaving §8.5 as a bare `NA`.
      (Found missing entirely in EAII-529's first draft.)
- [ ] **Confirm the ToC (bulleted outline near the top of the file) lists every subsection you
      just verified in the body** — a body section can be complete while its ToC entry is still
      missing or stale; check both, not just the body.

**6.2 FSD traceability**
- [ ] Every in-scope FSD interface has a §5.x block
- [ ] Every FSD §3.x.7 exception scenario appears in §5.x.6.3.3, plus the `-099` catch-all
- [ ] Every FSD §3.x.11 scenario (T1..Tn) is covered by ≥ 1 `TC-nnn` row in §5.x.10.2 (cited in `FSD ref`); TC ids are sequential and §5.x.6.3.2 Audit rows cite them
- [ ] Every FSD §3.x.6 NFR is addressed in §4.5 or §5.x.7.1
- [ ] Every FSD §1.4 / §3.x.1.3 known issue is either designed for or explicitly listed in §2.2
      as not addressed
- [ ] FSD §3.x.4 GSB rating drives §10 Disaster Recovery
- [ ] **§9.3 names a concrete ADO repository for this interface's own code**, not just the
      generic "source code is managed under source control" boilerplate — if this interface
      shares a workload with existing sibling interfaces (check `azure-devops-repository-pr`'s
      repo list and any corpus TSD for the same workload name), recommend reusing
      that repo and any shared library it already has, rather than silently omitting a repo
      suggestion or assuming a brand-new repo. Include a suggested branch name
      (`feature/{EAII-ID}-{description}`) and PR title format too.

**6.3 Cross-reference consistency**
- [ ] §4.3 components ≡ §5.x.6.1 component list ≡ §6.1.1 inventory ≡ §6.5 infrastructure ≡
      diagram components
- [ ] Every Key Vault secret named in §5/§6.3.1 appears in §6.3.2
- [ ] Every RBAC role implied by §6.3.1 appears in §6.3.3
- [ ] **Every Key Vault named in §6.3.2 (Key Vault Secrets Inventory) has at least one matching
      grant row in §6.3.3 (Identity Inventory / RBAC Assignments)** — check this Key-Vault-by-
      Key-Vault, not just role-by-role. It is valid for the grant to be `*<To be confirmed —
      pending SMC/enabling team approval>*`, but the row must exist. (Found missing in
      EAII-529 first draft: SMC/enabling Key Vault was listed as a secret source but had no
      RBAC row at all.)
- [ ] **Every FSD-documented API endpoint (exact path, method, query parameters, auth) is
      restated verbatim in a dedicated Service Operations table** in the relevant §5.x.6.3
      subsection — a generic "HTTP POST — Item Status/Price" row that only names the
      operation, without the literal path/query string from the FSD, is NOT sufficient.
      (Found missing in EAII-529 first draft — added as a new §5.x.6.3.5 subsection; renumber
      the following Input/Output subsection accordingly.)
- [ ] **§6.3.3's RBAC table uses the exact corpus column format `Source | Target | Identity |
      RBAC Role`, preceded by the literal bold line `**Complete RBAC Assignments
      (`Microsoft.Authorization/roleAssignments`):**`** — this exact heading text is verbatim
      across every corpus TSD that has this section (EAII-297, -304, -514, -289). A table with
      different column names (e.g. `Managed Identity | Target Resource | RBAC Role | Scope |
      Assigned By`) or missing the bold heading line does not meet the bar, even if the same
      information is present. (Found wrong in EAII-529 first draft.)
- [ ] **§6.4 Infrastructure Support is not defaulted to "Standard AIS platform infrastructure
      support applies" / `NA` when this interface's own FSD actually documents
      source/target-system connectivity details** (AS/400 DB2 schema+host+username per
      environment, mainframe LU, DB connection owner, etc.) — transcribe those into an `Env |
      Target | Endpoint | Resource Path` table verbatim. This applies even when the interface's
      own data path doesn't call that endpoint directly (e.g. file-drop via MFT) — §6.4
      documents the source system's support/connectivity reference, not just this interface's
      transport. **Conversely, never transcribe such values from a screenshot or example shown
      for a DIFFERENT interface** — cross-check every value against `tsd-inputs/<this-
      interface>/converted/` before using it; if it isn't there, it doesn't belong in this TSD,
      no matter how plausible it looks. (Found wrong both ways in EAII-529: missing at first,
      then wrongly populated with another interface's AS/400 DB2 details after being shown as a
      style example.)
- [ ] Every connection in §6.2 appears in §7.1 with matching protocol/port/auth
- [ ] Resource names spelled identically in §3.2, §6.1.1, §6.5, §6.6

**6.4 Insufficient-detail sweep** (apply the `tsd-comparer` standard to your own output)
- [ ] No empty tables
- [ ] No bare "TBD" — every gap is `*<To be confirmed — [what] from [whom]>*`
- [ ] No untouched template boilerplate placeholders
- [ ] Every diagram slot filled or explicitly marked N/A with a reason
- [ ] NFRs quantified, not qualitative

**6.5 Security**
- [ ] No secret values, connection strings, passwords, certificate keys, or tokens
- [ ] Secret *names* present in §6.3.2; values absent
- [ ] Data classification from FSD §3.x.5 reflected in §6.3.1

**6.6 Mechanistic checks**

```powershell
# No unresolved placeholders left from the template
(Select-String -Path "<tsd-file>" -Pattern '\[Solution Component Function\]|\[Source\]|\[Target\]|<\*.*\*>').Count

# Every markdown table has a consistent column count
python reference-corpus\_tools\check_tables.py "<tsd-file>"

# TSD quality gate: duplicate heading numbers, missing §8.5, template leftovers, exception-code scheme + -099,
# TC-nnn ids, SMC field completeness, one resource spelled two ways, NFR figures not in the FSD, §3.2 patterns naming
# components absent from §4.3, NA coordination / GoAnywhere, empty §10/§12
python .github\skills\metcash-tsd-generator\tools\tsd_lint\check_tsd.py "<tsd-file>" `
    --inputs tsd-inputs\<EAII-ID>\converted --corpus reference-corpus\converted\tsd

# The questionnaire gate must still pass (no 🟥 left unanswered)
python .github\skills\metcash-tsd-generator\tools\intake\intake_gaps.py check tsd-inputs\<EAII-ID>\intake-questionnaire.md
```

`check_tsd.py` must report **0 errors**; address or justify every warning. `step-count` (INFO) is the `N` for
`lint_drawio.py --steps N` in gate 6.8. (Validated 2026-10-02 against the approved 304 and 374: it reproduces their
documented defects — duplicate 5.1.7.1, invented 99.9%, patterns copied from another interface, non-EAII codes, missing TC ids.)

**6.7 Peer diff and quality scorecard (mandatory)** — run the scorecard, then compare with the closest approved TSD:

```powershell
python .github\skills\metcash-tsd-generator\tools\tsd_lint\quality_review.py "<tsd-file>" `
    --inputs tsd-inputs\<EAII-ID>\converted --archetype <A|B|C|D> --flags "+db2,+switch,migration" `
    --diagrams tsd\<Name>\diagrams [--benchmark <approved-tsd.md>] --out tsd\<Name>\quality-review.md
```

It scores seven dimensions (mechanical lint, knowledge-base coverage from `tools/tsd_lint/kb-checklist.json`, FSD traceability,
cross-reference consistency, security, diagrams incl. model attribution, and the gap register when `gap-register.json` sits beside the inputs) and names the standard behind each failed check.
Target: overall >= 90 and **no failed `error` item**; every remaining failure is either fixed or justified in the report.
`--benchmark` adds a token-level diff against an approved TSD for the same interface (code spans, exception codes, HTTP
statuses): triage the missing tokens by hand, because an approved TSD also holds invented values (see `10-known-defects`).
**Limits of the score:** it measures conformance to this skill's own knowledge base, so a TSD written by the skill will score
high by construction; the independent evidence is the benchmark diff and human review. When a benchmark review finds a real
gap, add a rule to `kb-checklist.json` (as KB-B05..B08 were added) so the next run is checked for it. Calibration
(2026-10-04): the approved 374 scores 39 / 100, a generated 374 scores 93 / 100.

Also run `tsd-comparer` against the closest corpus TSD (named in Step 1) and report gaps with severity before handing over.

**6.9 Post-generation checklist and code reconciliation (mandatory)** — tick every item in
[references/11-post-generation-checklist.md](references/11-post-generation-checklist.md). Section D finds the repo and branch that
already hold this interface's code and compares them with the TSD using
`tools/code_scan/scan_logicapp.py` (git only, no MCP). Found 2026-10-04 on EAII-374: the built branch
`feature/EAII-374-pe-item-and-vendor-validation` of `Metcash.AIS.Data.Metproducts` proved or contradicted eight things the TSD
had assumed (workflow name and Stateful kind, `X-Operation-Type` header, DB2 `storedProcedure` action returning OUT parameters,
schema / user, Key Vault secret names, 3 x 5 s retry, SMC end-observation sent through a Service Bus queue, status-code mapping).
The code is the as-built fact; a conflict is raised to the owner, never silently copied either way.

**6.8 Diagram gate (mandatory — do not skip)**

Diagrams are checked mechanically AND visually; `inspect_drawio.py` alone only proves the XML parses.

- [ ] `lint_drawio.py <file>.drawio` reports **0 errors** on every icon-style page (Architecture, Network, Communication); process-flow pages are built with `build_simple_flow.py` and checked by looking at the PNG: simple, readable, no overlapping text.
- [ ] Icon pages have zero `edges-cross` and `edges-share-lane` findings; rendered containers, labels and icons do not overlap. A high aggregate score does not waive this gate.
- [ ] No image in §2 Scope (In Scope / Out of Scope are text only)
- [ ] Every page rendered with `render_drawio.py` and each PNG actually opened and looked at
- [ ] Only catalogued icons (`icons.json`); no external image URLs; no mojibake in any label
- [ ] Resource names on the diagrams spelled identically to §3.2, §6.1.1, §6.5, §6.6
- [ ] The spec JSON is saved next to the `.drawio` (regeneration, not hand edits, is how a diagram changes)
- [ ] If an approved/previous diagram for the same interface exists (`git log` on the `.drawio`/`images/`),
      compare against it first - only regenerate what is stale

If draw.io Desktop is unavailable, fall back to opening the built `.drawio` in `app.diagrams.net`
(browser tool) and exporting PNG from there - ask the user before installing anything.

---

### Step 7: Deliverables Checklist

- [ ] TSD markdown at `tsd/<IntegrationName>/Technical Specification - <IDs> - <Source> to <Target>.md`
- [ ] One multi-page `.drawio` containing: System Context, Architecture Diagram, Network Diagram, Communication Diagram, and one Process Flow page per interface
- [ ] §11 Support Documentation contains a relative link to that editable `.drawio` I/O diagram source. In the Word export, attach the same file as an embedded packaged object displayed as an icon under §11 using `tools/docx/embed_diagram_object.ps1` (Word `InlineShapes.AddOLEObject` with `Package`, `LinkToFile=false`); verify the file is embedded, not linked to a machine-local path. If native Word automation is unavailable, stop and report the missing prerequisite rather than silently substituting a path-only link.
- [ ] **`tsd/<IntegrationName>/images/` folder, self-contained, numbered sequentially in the order
      images appear in the TSD** (`01.png`, `02.png`, ...) — copy any FSD images the TSD embeds
      into this folder too (don't leave the TSD pointing at `tsd-inputs/.../images/...`); every
      `.drawio` page gets its PNG from `tools/diagrams/render_drawio.py` (Step 5), copied here and
      renamed in document order. Keep the spec JSON next to the `.drawio`.
- [ ] PNG export per page, embedded with correct relative paths (`images/NN.png`, not an absolute
      or `tsd-inputs`-relative path)
- [ ] **Sequence diagram per interface, actually rendered to PNG in `images/` — not just left as a
      PlantUML text block.** Check for a local renderer before assuming one is unavailable: VS
      Code's PlantUML extension typically ships a jar (e.g.
      `%USERPROFILE%\.vscode\extensions\jebbs.plantuml-*\plantuml.jar`, or `.cursor\extensions\`
      equivalent) and Java is commonly already installed (`java -version`). Render with:
      `java -jar "<path-to-plantuml.jar>" -tpng "<file>.puml" -o <output-dir>`. **If neither Java
      nor a `plantuml.jar` can be found anywhere on the machine, stop and ask the user** how they
      want to proceed (install Java + PlantUML, use an online renderer they approve, or accept the
      diagram as an unrendered text block for now) — do not install Java/PlantUML yourself and do
      not silently leave the sequence diagram unrendered. **Gotcha:** a
      `title` directive can only be a single line — a second bare line after `title ...` is a
      syntax error; use `\n` inside the one-line title (`title Line 1\nLine 2`) for a multi-line
      title, not a second physical line. Insert the rendered PNG into `images/` at its correct
      sequential position (in document-appearance order) and renumber every image after it —
      don't just append it at the end.
- [ ] FSD process diagram copied into the TSD folder (into `images/`, per above)
- [ ] Diagram pre-flight checklist passed (08-diagram-conventions.md §10)
- [ ] Do not create enlarged/cropped duplicate raster detail views of diagrams. Keep one full-page PNG per diagram page and make the diagram itself readable at full-page scale; correct the source layout/rendering if labels do not fit.
- [ ] All `.drawio` valid XML, BOM-free, N2 style, no orphan shapes
- [ ] `assumptions.md` listing every assumption and TBC, with owner
- [ ] Peer-diff report against the closest corpus TSD
- [ ] `tsd/<IntegrationName>/quality-review.md` from `quality_review.py` (Step 6.7), overall >= 90, no failed error item
- [ ] **`.docx` export for Confluence import**: `pandoc "<tsd-file>.md" -f gfm -t docx -o
      "<tsd-file>.docx" --resource-path=. --toc --toc-depth=3 --standalone` (run from the TSD's
      own folder so relative `images/` paths resolve). **Check for pandoc first (`pandoc
      --version`) — if it isn't installed, stop and ask the user to confirm before installing it**
      (e.g. `winget install --id JohnMacFarlane.Pandoc -e`); do not install it unprompted. Once
      confirmed and installed, refresh PATH in the current shell session
      (`$env:Path = [System.Environment]::GetEnvironmentVariable(...)`) before invoking it.
      **Pandoc's raw output is not good enough on its own — always apply
      these post-processing fixes before handing over, they are not optional polish:**
      1. **Flatten, then auto-crop every diagram PNG** in `images/`. First flatten any PNG with an alpha channel onto white
         (transparent PNGs such as the FSD process diagram render with a black background in Word):
         `bg = Image.new("RGBA", im.size, "white"); im = Image.alpha_composite(bg, im.convert("RGBA")).convert("RGB")`,
         overwrite in place, and open the result to confirm the background is white (`quality_review.py` `DG-13`). Then auto-crop (PIL:
         bounding-box of non-white content +
         ~15px padding, overwrite in place) *before* running pandoc — pandoc embeds images at
         their native pixel dimensions, so excess whitespace in the export directly shrinks the
         visible diagram content once placed in a fixed-width Word frame.
      2. **Explicit page setup** — pandoc's default docx leaves the section page size/margins
         completely unset (`None` in python-docx), which renders inconsistently. Set it
         explicitly post-conversion: `section.page_width/page_height` = A4 (`Cm(21.0)`,
         `Cm(29.7)`), margins `Cm(2.5)` left/right, `Cm(2.0)` top/bottom.
      3. **Table borders** — pandoc's only table style (`Table`) has no visible borders/grid
         lines by default, which is why tables look broken once opened. For every
         `document.tables`, inject a `w:tblBorders` element into `tbl.tblPr` (single, sz=4,
         color 000000, all 6 edges: top/left/bottom/right/insideH/insideV) via
         `docx.oxml.OxmlElement`/`qn()` — python-docx has no high-level API for this, it must be
         raw OXML. Also set `w:tblW` to `type="pct" w:w="5000"` (100%) with `w:tblLayout
         type="fixed"` so tables consistently span the full content width instead of
         autofit-to-content.
      4. **Image width cap matches the real content width**, not a guessed value — recompute
         it from the page setup you just set (`page_width - left_margin - right_margin`, e.g.
         21.0 − 2.5 − 2.5 = 16.0cm = 6.30in for the A4 setup above) and resize any inline shape
         wider than that down to it (preserving aspect ratio), never upscale smaller ones.
      Verify after every step: `len(Document(path).inline_shapes)` matches the markdown's image
      count, every `document.tables` entry has a `tblBorders` element, section page metrics read
      back as set, and the document reopens without error. **python-docx reopening is not proof
      that Microsoft Word can open the file.** It accepted EAII-523/522 while its generated
      section breaks were invalid nested paragraphs (2026-10-05).
      5. **Word structure and openability gate:** run
        `python .github/skills/metcash-tsd-generator/tools/tsd_lint/validate_docx.py "<tsd-file>.docx" --expected-images <count>`.
        Require `OK` before handover. This targeted checker verifies package/XML integrity,
        internal relationship targets, paragraph/section placement and table-property order;
        it is not a complete OOXML schema validator or renderer. Insert section breaks beside
        the containing body-level `w:p`, never beside a `w:r` or `w:drawing` inside it. Locate
        the paragraph with `inline.xpath("ancestor::w:p[1]")[0]`, not a guessed parent count.
        Keep `w:tblPr` schema order: borders precede shading/layout/cell margins/table look;
        use `insert_element_before` rather than appending borders/layout after `w:tblLook`.
        The final body-level `w:sectPr` remains the final body child.
        When Microsoft Word is available, open the final artifact read-only **without repair**
         and attempt a local PDF export with a bounded timeout. Record native-open and PDF
         results separately; a stalled/failed PDF export does not establish rendered layout.
         Inspect rendered pagination/image fit separately when
        claiming layout quality. Use a dedicated automation instance, never force-kill the
        user's Word session; never install Word/LibreOffice or use a cloud converter without
        approval. If no native application/schema renderer is available, disclose that
        openability/rendering is unverified instead of claiming the structural checks prove it.
      **If the docx is open in Word/VS Code, pandoc will fail with a permission-denied error** —
      ask the user to close it before regenerating, don't force-kill their process.

---

### Step 8: Publish to Confluence (only if Step 2 Q11 confirmed this)
### Step 7.5: TSD Review Gate — mandatory before Codegen Readiness

After all Step 7 deliverables and validation are complete, fill
[`review-gates/templates/tsd-review-checklist.template.md`](../../../review-gates/templates/tsd-review-checklist.template.md)
and save it as `outputs/<EAII-ID>/tsd-review-checklist.md`. Use the approved TSD corpus and the
curated [`review-gates/README.md`](../../../review-gates/README.md) evidence index. Run and record
the `quality_review.py` result separately; do not average its automated corpus-conformance score
with the human review score.

Reviewers read the TSD critically, cite evidence for every checklist score, and put blocking
findings before the summary. PASS requires at least 90% human checklist score, no unresolved
Critical/High finding, and the required evidence attached. Otherwise return it for correction or
mark BLOCKED. **Stop for explicit TSD review approval before `ais-codegen-readiness`**; this
approval only permits the next readiness questionnaire, not code generation. Code generation
still requires its own separately approved questionnaire.

### Step 8: Publish to Confluence (only if Step 2 Q11 confirmed this)
### Step 7.5: TSD Review Gate — mandatory before Codegen Readiness

After all Step 7 deliverables and validation are complete, fill
[`review-gates/templates/tsd-review-checklist.template.md`](../../../review-gates/templates/tsd-review-checklist.template.md)
and save it as `outputs/<EAII-ID>/tsd-review-checklist.md`. Use the approved TSD corpus and the
curated [`review-gates/README.md`](../../../review-gates/README.md) evidence index. Run and record
the `quality_review.py` result separately; do not average its automated corpus-conformance score
with the reviewer score.

Reviewers read the TSD critically, cite evidence for every checklist score, and put blocking
findings before the summary. PASS requires at least 90% human checklist score, no unresolved
Critical/High finding, and the required evidence attached. Otherwise return it for correction or
mark BLOCKED. **Stop for explicit TSD review approval before `ais-codegen-readiness`**; this
approval only permits the next readiness questionnaire, not code generation. Code generation
still requires its own separately approved questionnaire.

### Step 8: Publish to Confluence (only if Step 2 Q11 confirmed this)

Publishing a generated TSD (with its tables, code blocks, and diagram images) into an
existing or new Confluence page is **not** a Confluence MCP/API write — do it via browser
automation using the **[`confluence-publish-rich-content`](../confluence-publish-rich-content/SKILL.md)**
skill. Load that skill and follow it exactly; in particular:

- Convert the TSD `.md` (not the `.docx`) to self-contained HTML via `pandoc
  --embed-resources --standalone`, run from the TSD's own folder so `images/NN.png`
  paths resolve.
- The images **will not survive the rich paste** — Confluence's sanitizer silently drops
  embedded base64 `<img>` tags. Every one of the `images/NN.png` files must be inserted
  individually after the text paste, in document order, per that skill's Step 4 — treat
  this as a mandatory part of the publish, not a follow-up nice-to-have.
- Use the skill's bundled `set_html_clipboard.ps1` (UTF-8-safe) — never a plain
  `Clipboard.SetData(string)` call, which silently corrupts em dashes and other
  non-ASCII characters into `�` with no error (confirmed live on EAII-529's first
  publish attempt — caught only by explicitly checking the pasted text for `�`
  after the fact; the corrupted version had already been published once before the fix).
- After publishing, spot-check the **live page** (not just the editor) for both text
  corruption and image rendering before calling the task done.

---

## Reference Materials

| File | Contents |
|---|---|
| [references/01-canonical-structure.md](references/01-canonical-structure.md) | Section-by-section skeleton, mandatory vs optional, table column sets, corpus frequency |
| [references/02-reference-architectures.md](references/02-reference-architectures.md) | The four AIS archetypes, decision table, and worked precedents |
| [references/03-naming-and-infrastructure.md](references/03-naming-and-infrastructure.md) | Resource naming patterns and the verbatim Metcash network/subscription/VNet facts |
| [references/04-standard-boilerplate.md](references/04-standard-boilerplate.md) | Reusable verbatim blocks, including the §15 approval checklist |
| [references/05-smc-observability-patterns.md](references/05-smc-observability-patterns.md) | SMC onboarding fields, logging/audit/exception table shapes, exception code scheme |
| [references/06-fsd-to-tsd-traceability.md](references/06-fsd-to-tsd-traceability.md) | Empirical FSD§ → TSD§ mapping derived from the corpus |
| [references/07-corpus-index.md](references/07-corpus-index.md) | What each corpus TSD demonstrates and when to use it as precedent |
| [references/08-diagram-conventions.md](references/08-diagram-conventions.md) | N2 diagram style: palette, Azure2 icon paths, edge semantics, page naming, pre-flight checklist |
| [references/09-transcript-mining.md](references/09-transcript-mining.md) | Phrase patterns for extracting settled decisions, rejections, and open risks from the walkthrough transcript |
| [templates/intake-questionnaire.template.md](templates/intake-questionnaire.template.md) | Editable batch-mode questionnaire template for Step 0.75 (archetype confirmation + open Step 2 questions in one file) |
| [references/10-known-defects-in-approved-tsds.md](references/10-known-defects-in-approved-tsds.md) | Defects found in the approved 304/374 TSDs - structural precedent yes, copy-paste no |
| [references/11-post-generation-checklist.md](references/11-post-generation-checklist.md) | Checklist to tick after every generated TSD: automatic gates, content review, diagrams, code reconciliation, hand-over |
| [references/12-shared-platform-dependencies.md](references/12-shared-platform-dependencies.md) | Evidence precedence, the standing SMC dependency block, RBAC / private-endpoint derivation, platform defaults, gap classes |
| [tools/intake/required-facts.json](tools/intake/required-facts.json) + `intake_gaps.py` | Design-driven missing-facts rules (storage/container/repo/endpoints/...), scanner and the pre-generation gate |
| [tools/diagrams/](tools/diagrams/) | Approved-style diagram engine: icon catalog, spec builder, geometry lint, local renderer, model-eval harness |
| [`confluence-publish-rich-content` skill](../confluence-publish-rich-content/SKILL.md) | Step 8's browser-automation procedure for publishing the finished TSD (text + diagrams) to Confluence |

## Output Location

`tsd/<IntegrationName>/` — create if absent. Live per-request inputs (the four Input Contract
files, converted) stage in `tsd-inputs/<EAII-ID>/{source,converted}/`. Raw approved corpus stays
in `reference-corpus/`; never write generated output there.

## Notes

- **Evaluating the generator on an interface that is already in the corpus (regeneration test).** `reference-corpus/converted/tsd/`
  holds the approved TSDs, the derived `references/` were taught from 304 and 374, the intake `starting point` hints name 374 /
  304 values, and `tools/diagrams/model-eval/PROMPT.md` plus `specs/EAII-374.sample.json` contain the approved 374 diagram. So a
  regeneration of 374 or 304 is *not* blind: do not read the approved TSD before generating, do not seed a diagram spec from
  the 374 sample, treat an intake hint that names the interface under test as non-evidence, and say in the report which of
  these leaks could have helped. Fairness aside, the run still finds real gaps (the first 374 regeneration did).
- **Tooling gotchas found 2026-10-04.** Windows PowerShell 5.1 `Set-Content -Encoding UTF8` writes a BOM that broke
  `build_drawio.py` (builders now read `utf-8-sig`; still write BOM-free with `[System.IO.File]::WriteAllText(..., (New-Object
  System.Text.UTF8Encoding $false))`). A Python here-string piped from PowerShell (`@'...'@ | python -`) corrupts non-ASCII
  characters such as the answer markers; write the script to a file and run it. If the ADO / GitHub MCP pre-flight (Step 0.0)
  fails and the user chooses to continue, record the TIBCO repository as `*<To be confirmed>*` with the reason in §5.x.1.1,
  §9.3 and §13, and as an open gap in the questionnaire - never guess it.
- The corpus was produced by the `tibco-to-fsd` → `fsd-to-tsd` skill chain. Where this skill and
  the base `fsd-to-tsd` template disagree, **the corpus wins** — it reflects approved practice.
- UTF-8 without BOM for all file writes:
  `[System.IO.File]::WriteAllText($path, $content, (New-Object System.Text.UTF8Encoding $false))`
- Log every assumption to `tsd/<IntegrationName>/assumptions.md` as you go, not at the end.
- The transcript converter (`transcript_to_md.py`) occasionally merges a short interjection from
  a second speaker into the preceding turn when Teams renders it without a full blank-line
  separator. Spot-check turns that contain an embedded `Name  mm:ss` pattern mid-paragraph before
  citing them.

