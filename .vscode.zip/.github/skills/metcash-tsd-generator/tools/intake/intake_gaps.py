#!/usr/bin/env python3
"""Find the facts the TSD design needs but the inputs do not give, and force the developer to supply them.

  # 1) scan converted inputs and emit the 'Facts the design needs' section for the questionnaire
  python intake_gaps.py scan <converted-dir> [--flags auto|+goanywhere,-db2] [--out section.md] [--json]

  # 2) hard gate before generation: fail while any RED item in the questionnaire is unfilled, or while a
  #    blocking fact was lowered to ORANGE/GREEN without evidence in the inputs or an answer from the user
  python intake_gaps.py check <intake-questionnaire.md>

Provenance rule (2026-10-04): a fact whose level is 'block' stays RED until the DEVELOPER answers it. The only ways it
may be lowered are (a) value-bearing evidence in the FSD/Mapping/Manifest/transcript (heading carries `src:inputs`) or
(b) a prefill entry with "answered_by": "user" (heading carries `src:user`). Anything the agent researched (sibling repos,
git history, corpus, platform defaults) is shown as a 'Researched proposal' on the Answer line's evidence block and the
fact stays RED. The agent never writes "answered_by": "user".

Why: in the approved 304/374 pairs the storage account, container/folder names, repo, public API path,
Service Bus name, GoAnywhere details and DB2 host/schema are never in the FSD but are always in the TSD.
Without this gate the generator either leaves holes or invents values.

Marker legend (also written into the questionnaire):
  RED    NEEDS INPUT   cannot be guessed; generation is blocked until the Answer line is filled
  ORANGE CONFIRM       evidence found or a value can be proposed; confirm or edit (does not block)
  GREY   RECOMMENDED   improves quality; does not block
  GREEN  FOUND         evidence present and unambiguous
Which facts apply depends on the DESIGN (flags): a blob container is only demanded when the design stages
files in Blob Storage; DB2 details only when a DB2 target exists; and so on.
"""
import argparse, json, re, sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):  # Windows consoles default to cp1252 and cannot print the marker emoji
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass

HERE = Path(__file__).parent
RULES = json.loads((HERE / "required-facts.json").read_text(encoding="utf-8"))
M = RULES["markers"]
TOKEN = RULES["fill_in_token"]
ADF_PAT = [r"Data Factory", r"\bADF\b"]


def load_texts(root):
    texts = {}
    for p in sorted(Path(root).rglob("*.md")):
        name = p.name
        # skip generated questionnaires/TSDs: they are outputs, not inputs
        if name.startswith("intake-questionnaire") or name.startswith("Technical Specification"):
            continue
        texts[str(p.relative_to(root))] = p.read_text(encoding="utf-8", errors="ignore").splitlines()
    return texts


def hits(texts, patterns, limit=2):
    out = []
    for f, lines in texts.items():
        for i, line in enumerate(lines, 1):
            for pat in patterns:
                if re.search(pat, line, re.I):
                    snippet = re.sub(r"\s+", " ", line).strip()
                    if len(snippet) > 150:
                        m = re.search(pat, snippet, re.I)
                        s = max(0, (m.start() if m else 0) - 60)
                        snippet = ("…" if s else "") + snippet[s:s + 150] + "…"
                    out.append((Path(f).name, i, snippet))
                    break
            if len(out) >= limit * 3:
                break
    # prefer diverse sources
    seen, pick = set(), []
    for h in out:
        if h[0] not in seen:
            seen.add(h[0])
            pick.append(h)
    for h in out:
        if h not in pick and len(pick) < limit:
            pick.append(h)
    return pick[:limit]


def detect_flags(texts, override, archetype=None):
    flags = {"always"}
    if archetype:
        preset = RULES["archetype_presets"].get(archetype)
        if preset is None:
            sys.exit(f"unknown archetype '{archetype}'. Choose one of: {[k for k in RULES['archetype_presets'] if not k.startswith('_')]}")
        flags.update(preset)
        for tok in (override or "").split(","):
            tok = tok.strip()
            if tok.startswith("+") or (tok and tok[0] not in "+-"):
                flags.add(tok.lstrip("+"))
            elif tok.startswith("-"):
                flags.discard(tok[1:])
        return flags
    # suggestion only: exclude transcripts (they discuss other interfaces / alternatives)
    corpus = {k: v for k, v in texts.items() if not re.search(r"walkthrough|transcript", k, re.I)}
    for name, pats in RULES["flags"].items():
        if name.startswith("_"):
            continue
        n = sum(1 for lines in corpus.values() for l in lines for p in pats if re.search(p, l, re.I))
        if n >= (2 if name in ("apim", "sync_api") else 1):
            flags.add(name)
    if sum(1 for lines in corpus.values() for l in lines for p in ADF_PAT if re.search(p, l, re.I)):
        flags.add("adf")
    for tok in (override or "").split(","):
        tok = tok.strip()
        if tok.startswith("+"):
            flags.add(tok[1:])
        elif tok.startswith("-"):
            flags.discard(tok[1:])
    return flags


def evaluate(texts, flags):
    res = []
    for f in RULES["facts"]:
        why_applies = [a for a in f["applies_when"] if a in flags]
        if not why_applies:
            continue
        ev = hits(texts, f["strong"] + f["patterns"] if f.get("strong") else f["patterns"])
        strong_ev = hits(texts, f["strong"]) if f.get("strong") else ev
        lvl = f["level"]
        if lvl == "block":
            # a bare keyword (e.g. the word "container") is NOT the value; only a value-bearing match
            # ('strong' patterns) downgrades a blocking fact to "confirm". Evidence is still shown.
            status = "confirm" if strong_ev else "block"
        elif lvl == "confirm":
            status = "found" if len(strong_ev) >= 1 and f.get("strong") else ("found" if len(ev) >= 2 else "confirm")
        else:
            status = "found" if ev else "recommend"
        res.append(dict(f, status=status, evidence=ev, because=why_applies))
    return res


def render(res, flags, title="Facts the design needs", prefill=None):
    """prefill: {fact_id: {"status": "confirm", "answer": "...", "source": "Q6"}} - answers the architect already gave in an
    existing questionnaire. They are shown as the Answer (never changed) and downgrade the item so the design stays as written."""
    prefill = prefill or {}
    for r in res:
        pf = prefill.get(r["id"])
        if pf:
            r["prefill"] = pf
            if pf.get("answered_by") == "user":
                r["status"] = pf.get("status", "confirm")
                r["src"] = "user"
            elif r["level"] != "block":
                r["status"] = pf.get("status", "confirm")
        if r["level"] == "block" and r["status"] != "block" and "src" not in r:
            r["src"] = "inputs"
    order = {"block": 0, "confirm": 1, "recommend": 2, "found": 3}
    res = sorted(res, key=lambda r: (order[r["status"]], r["id"]))
    nb = sum(1 for r in res if r["status"] == "block")
    nc = sum(1 for r in res if r["status"] == "confirm")
    L = [f"## 3A. {title} — inputs the FSD / Mapping / Manifest / transcript do not give", ""]
    L.append(f"Design the questions were derived from: `{', '.join(sorted(flags - {'always'})) or 'none'}`. If §1 (archetype) or a component changes, re-run `intake_gaps.py scan` - the list of required facts changes with the design.")
    L.append("")
    L.append("| Marker | Meaning | Blocks generation? |")
    L.append("|---|---|---|")
    L.append(f"| {M['block']} | Cannot be guessed (names, paths, endpoints). **Type the answer on the `Answer:` line.** | **YES** until filled |")
    L.append(f"| {M['confirm']} | Evidence found, or a value can be proposed. Confirm or edit the `Answer:` line. | no |")
    L.append(f"| {M['recommend']} | Improves TSD quality; fill if you can. | no |")
    L.append(f"| {M['found']} | Present in the inputs; shown for awareness. | no |")
    L.append("")
    L.append(f"**{nb} item(s) block generation, {nc} need confirmation.** Not every interface needs every fact: only the ones below apply to this design.")
    L.append("")
    for r in res:
        mark = M[r["status"]]
        src = f" src:{r['src']}" if r.get("src") else ""
        L.append(f"### {mark} · {r['title']}  <!-- fact:{r['id']}{src} -->")
        L.append(f"*Applies because the design has:* `{', '.join(r['because'])}` · *Needed for:* {', '.join(r['sections'])}")
        L.append("")
        L.append(f"**Question:** {r['question']}")
        L.append("")
        if r["evidence"]:
            L.append("**Evidence in the inputs (verify it is complete and current):**")
            for fn, ln, sn in r["evidence"]:
                L.append(f"- `{fn}:{ln}` — {sn}")
        else:
            L.append("**Evidence in the inputs:** *none found in the FSD, Mapping, Manifest or transcript.*")
        L.append("")
        L.append(f"**Starting point:** {r['propose']}")
        L.append("")
        if r.get("prefill") and r["prefill"].get("answer"):
            pf = r["prefill"]
            if r.get("src") == "user":
                L.append(f"**Answered by:** user ({pf.get('source', 'questionnaire')}): {pf['answer']}")
                L.append("")
                L.append(f"**Answer:** {pf.get('answer_line', '*(as decided above - edit only to correct it)*')}")
            else:
                L.append(f"**Researched proposal (NOT an answer; source: {pf.get('source', 'agent research')}) - copy it onto the Answer line if right, or overwrite:** {pf['answer']}")
                L.append("")
                L.append(f"**Answer:** {TOKEN}" if r["status"] == "block" else "**Answer:** *(leave as the starting point above, or replace)*")
        elif r.get("prefill") and r["prefill"].get("note"):
            pf = r["prefill"]
            L.append(f"**What the questionnaire / FSD already covers, and what is still missing:** {pf['note']}")
            L.append("")
            L.append(f"**Answer:** {TOKEN}" if r["status"] == "block" else "**Answer:** *(leave as the starting point above, or replace)*")
        elif r["status"] == "block":
            L.append(f"**Answer:** {TOKEN}")
        elif r["status"] == "confirm":
            L.append("**Answer:** *(leave as the starting point above, or replace)*")
        elif r["status"] == "recommend":
            L.append("**Answer:** *(optional)*")
        else:
            L.append("**Answer:** *(as found above)*")
        L.append("")
    return "\n".join(L)


BLOCK_IDS = {f["id"] for f in RULES["facts"] if f["level"] == "block"}


def check(path):
    txt = Path(path).read_text(encoding="utf-8")
    bad = []
    blocks = re.split(r"(?m)^(?=### )", txt)
    for b in blocks:
        head = b.splitlines()[0] if b else ""
        fm = re.search(r"<!-- fact:(\w+)(?: src:(\w+))? -->", head)
        if head.startswith("### ") and fm and fm.group(1) in BLOCK_IDS and M["block"] not in head:
            title = re.sub(r"<!--.*?-->", "", head[4:]).strip()
            if fm.group(2) not in ("inputs", "user"):
                bad.append(f"{title} (lowered from NEEDS INPUT with no `src:inputs` evidence or `src:user` answer - restore the red marker)")
            elif fm.group(2) == "user":
                ans = re.search(r"(?m)^\*\*Answer:\*\*(.*)$", b)
                v = ans.group(1).strip() if ans else ""
                if not v or TOKEN in v or v.startswith("*("):
                    bad.append(f"{title} (marked src:user but the Answer line is empty)")
        if head.startswith("### ") and M["block"] in head:
            ans = re.search(r"(?m)^\*\*Answer:\*\*(.*)$", b)
            val = (ans.group(1).strip() if ans else "")
            if not ans or TOKEN in val or not val or val.startswith("*("):
                title = re.sub(r"<!--.*?-->", "", head[4:]).replace(M["block"] + " · ", "").strip()
                bad.append(title)
    return bad


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan")
    s.add_argument("root")
    s.add_argument("--archetype", help="A|B|C|D|hybrid-async-upload - the design decided in questionnaire section 1 (authoritative)")
    s.add_argument("--flags", default="auto", help="extra design flags, e.g. +db2,+goanywhere,-event_grid")
    s.add_argument("--out")
    s.add_argument("--json", action="store_true")
    s.add_argument("--prefill", help="JSON file {fact_id: {status, answer, source}} of answers already given in the questionnaire")
    c = sub.add_parser("check")
    c.add_argument("questionnaire")
    a = ap.parse_args()
    if a.cmd == "scan":
        texts = load_texts(a.root)
        if not texts:
            sys.exit(f"no .md inputs under {a.root}")
        flags = detect_flags(texts, "" if a.flags == "auto" else a.flags, a.archetype)
        if not a.archetype:
            print("NOTE: flags auto-detected from keywords (a suggestion only). Re-run with --archetype once section 1 is settled.", file=sys.stderr)
        res = evaluate(texts, flags)
        if a.json:
            print(json.dumps([{k: v for k, v in r.items() if k in ("id", "title", "status", "because", "sections")} for r in res], indent=1))
        else:
            prefill = json.loads(Path(a.prefill).read_text(encoding="utf-8")) if a.prefill else None
            out = render(res, flags, prefill=prefill)
            if a.out:
                Path(a.out).write_text(out, encoding="utf-8")
                print(f"wrote {a.out}: {sum(r['status']=='block' for r in res)} blocking, {sum(r['status']=='confirm' for r in res)} to confirm")
            else:
                print(out)
    else:
        bad = check(a.questionnaire)
        if bad:
            print(f"BLOCKED: {len(bad)} required fact(s) still unanswered in {a.questionnaire}:")
            for b in bad:
                print(f"  {M['block']}  {b}")
            sys.exit(1)
        print("OK: every required fact has an answer.")
