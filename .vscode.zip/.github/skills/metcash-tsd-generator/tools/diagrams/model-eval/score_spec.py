#!/usr/bin/env python3
"""Objective score for a candidate model's diagram SPEC (the JSON that build_drawio.py turns into a .drawio).

The model's real job is reading TSD 5.x.2.1 + the resource names and deciding WHAT is in the diagram.
Layout/icons/colours are deterministic (build_drawio.py), so models are compared on:

  validity   10  spec parses, every icon is in icons.json, edges/containers reference real ids, builder succeeds
  nodes      20  gold components present (matched by icon type)
  edges      20  gold connections present (matched by icon-type pairs)
  labels     20  gold resource names appear on the right components
  steps      10  numbered steps are 1..N, contiguous, N == gold N
  layout     20  lint score of the built diagram (no edge-through-icon, overlaps, mojibake, external URLs)

Usage:
  python score_spec.py candidates/<model>.json [--gold gold/EAII-374.process-flow.gold.json] [--page 0]
  python score_spec.py --table candidates/*.json        # side-by-side leaderboard
"""
import argparse, json, re, sys, tempfile
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
import build_drawio as B  # noqa: E402
import lint_drawio as L  # noqa: E402

CAT = json.loads((HERE.parent / "icons.json").read_text(encoding="utf-8"))
ICONS = set(CAT["icons"]) | set(CAT["container_badges"])


def norm(s):
    return re.sub(r"[^a-z0-9{}/]+", "", (s or "").lower())


def steps_of(page):
    out = []
    for e in page.get("edges", []):
        s = e.get("step")
        if s is not None:
            out += s if isinstance(s, list) else [s]
    for n in page.get("nodes", []):
        if n.get("step") is not None:
            out.append(n["step"])
    return sorted(out)


def f1(gold, cand):
    from collections import Counter
    g, c = Counter(gold), Counter(cand)
    tp = sum((g & c).values())
    if not tp:
        return 0.0
    p, r = tp / sum(c.values()), tp / sum(g.values())
    return 2 * p * r / (p + r)


def score(cand_path, gold_path, page_i=0):
    notes = []
    try:
        cand = json.loads(Path(cand_path).read_text(encoding="utf-8-sig"))
        cp = (cand["pages"][page_i] if "pages" in cand else cand)
    except Exception as e:
        return dict(total=0, notes=[f"unparseable spec: {e}"], parts={})
    gp = json.loads(Path(gold_path).read_text(encoding="utf-8-sig"))
    gp = gp["pages"][page_i] if "pages" in gp else gp

    # validity (10)
    valid = 10
    ids = {n.get("id") for n in cp.get("nodes", [])}
    cids = {c.get("id") for c in cp.get("containers", [])}
    for n in cp.get("nodes", []):
        if n.get("icon") not in ICONS:
            valid -= 3
            notes.append(f"unknown icon '{n.get('icon')}'")
    for e in cp.get("edges", []):
        if e.get("from") not in ids or e.get("to") not in ids:
            valid -= 3
            notes.append(f"edge refers to unknown node: {e}")
    for c in cp.get("containers", []):
        for m in c.get("members", []):
            if m not in ids and m not in cids:
                valid -= 3
                notes.append(f"container member '{m}' unknown")
    built = None
    lint_score = 0
    try:
        tmp = Path(tempfile.mkdtemp()) / "cand.drawio"
        B.build_from_dict({"pages": [cp]}, tmp)
        built = tmp
    except SystemExit as e:
        valid = 0
        notes.append(f"builder rejected spec: {e}")
    except Exception as e:  # noqa
        valid = 0
        notes.append(f"builder crashed: {e!r}")
    valid = max(valid, 0)

    # nodes / labels (match by icon type)
    gn = [n["icon"] for n in gp["nodes"]]
    cn = [n["icon"] for n in cp.get("nodes", [])]
    nodes = 20 * f1(gn, cn)
    lab_hits = 0
    lab_total = 0
    for g in gp["nodes"]:
        want = norm(g.get("label"))
        if not want:
            continue
        lab_total += 1
        for c in cp.get("nodes", []):
            if c.get("icon") == g["icon"] and (want in norm(c.get("label")) or norm(c.get("label")) in want and len(norm(c.get("label"))) > 3):
                lab_hits += 1
                break
    labels = 20 * (lab_hits / lab_total if lab_total else 1)

    # edges by icon-type pair
    gi = {n["id"]: n["icon"] for n in gp["nodes"]}
    ci = {n["id"]: n.get("icon") for n in cp.get("nodes", [])}
    ge = [(gi[e["from"]], gi[e["to"]]) for e in gp["edges"]]
    ce = [(ci.get(e["from"]), ci.get(e["to"])) for e in cp.get("edges", [])]
    edges = 20 * f1(ge, ce)

    # steps
    gs, cs = steps_of(gp), steps_of(cp)
    steps = 10 if (gs == cs) else (5 if cs == list(range(1, len(cs) + 1)) and cs else 0)
    if steps < 10:
        notes.append(f"steps {cs} vs expected {gs}")

    # layout via lint
    if built:
        res = L.lint_file(built)
        lint_score = sum(r["score"] for r in res) / len(res) if res else 0
    layout = 20 * lint_score / 100

    parts = dict(validity=valid, nodes=round(nodes, 1), edges=round(edges, 1), labels=round(labels, 1), steps=steps, layout=round(layout, 1))
    return dict(total=round(sum(parts.values()), 1), parts=parts, notes=notes)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cand", nargs="+")
    ap.add_argument("--gold", default=str(HERE / "gold" / "EAII-374.process-flow.gold.json"))
    ap.add_argument("--page", type=int, default=0)
    ap.add_argument("--table", action="store_true")
    a = ap.parse_args()
    rows = []
    for c in a.cand:
        r = score(c, a.gold, a.page)
        rows.append((Path(c).stem, r))
    if a.table or len(rows) > 1:
        print(f"{'candidate':34} {'TOTAL':>6}  valid nodes edges labels steps layout")
        for n, r in sorted(rows, key=lambda x: -x[1]["total"]):
            p = r["parts"]
            print(f"{n:34} {r['total']:6}  " + "  ".join(f"{p.get(k, 0):>5}" for k in ("validity", "nodes", "edges", "labels", "steps", "layout")))
    else:
        n, r = rows[0]
        print(json.dumps(r, indent=1))
