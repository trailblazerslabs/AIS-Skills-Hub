# Diagram-spec task (give this, unchanged, to every candidate model)

> **Evaluation only.** The inputs below are the approved EAII-374 design (resource names, workflow name, steps). Never use this
> file to generate the EAII-374 diagrams for a TSD regeneration or quality test: it hands the model the answer.

You are producing the **spec** for one Metcash AIS TSD diagram. You do NOT draw anything and you do
NOT choose coordinates, colours or icon files. A deterministic builder lays the diagram out in the
approved Metcash style. Your job is to read the design and say **what is in the diagram and how it is connected**.

## Output
Return **only** one JSON object (no prose, no markdown fences):

```
{"pages":[{
  "name": "EAII-374 Process Flow",
  "nodes":      [{"id","icon","label","sub?","col","row","box?","obs?","step?"}],
  "containers": [{"id","label","members":[ids or inner container ids],"badge?"}],
  "edges":      [{"from","to","kind":"flow|sync|smc|secret","label?","step?":N|[N,M]}],
  "texts":      [{"text","col","row"}]
}]}
```

## Rules
1. `icon` must be one of: apim, apim-operation, app-gateway, logic-app, function-app, storage-account,
   storage-container, event-grid, service-bus, service-bus-queue, key-vault, app-insights, aad,
   external-system, private-endpoint, smc, globe, goanywhere, db2, as400, stibo, salesforce,
   azure-badge, legend-success-fail. Inventing an icon name scores zero for that node.
2. `col`/`row` are grid cells (0,1,2... left-to-right, top-to-bottom; halves allowed). Flow runs left to right.
3. `label` is the real Azure resource name from the design, with `{env}` tokens - never a generic name.
   Put a short purpose in `sub`.
4. `kind`: `sync` = request/reply over HTTP (green, two-way arrow), `flow` = one-way, `smc` = logging to SMC (red),
   `secret` = Key Vault credential access (grey dashed).
5. Number the steps so they match the numbered process steps in the design text **1:1** (same count, no gaps).
   A step with no edge of its own (an internal step) goes on the node as `"step": N`.
   A request/response pair that shares one edge uses `"step":[request,response]`.
6. `box: true` on external systems (source/target) gets the approved dashed box. `obs: true` marks a component
   that writes SMC observations.
7. Use containers for the Azure boundary / subscriptions / resource groups / VNets only if the page type needs them.

## Inputs - EAII-374 STIBO to PE, page type: **Process Flow** (TSD 5.1.2.2)

Archetype: APIM + one Logic App Standard (synchronous request-reply). External source: STIBO MDM. Target: PE AS/400 DB2.
Resource names: Application Gateway `t1-met-core-{npr/prd}-ae1-apg-01`; APIM `t3-met-core-{env}-ae-apim`;
Logic App `t3-met-data-metproducts-{env}-ae-logic` (workflow `MetProductERPServiceOperations`);
Key Vault `t3data{env}ae1kv01`; target `PE Database` (IBM AS/400 DB2, stored procedures MDM0055R, MDM0110Q, MDM0140R, MDM0120R).

TSD 5.1.2.1 process steps (verbatim headings):
1. Request Initiation (STIBO) - HTTPS POST with OAuth2 bearer token and JSON payload.
2. Perimeter Security (Application Gateway) - TLS termination and WAF, forwards to APIM.
3. API Management - validates the OAuth2 JWT and request schema, routes to the Logic App HTTP trigger.
4. Workflow Orchestration (Logic App Standard) - initialises variables, parses the request, logs to SMC, switches on operation type.
5. Operation Execution - gets DB2 credentials from Key Vault using the Managed Identity, calls the PE database via the DB2 connector.
6. Response Assembly and Return - JSON response returned through APIM and Application Gateway to STIBO.
7. Observability - correlated telemetry for every step is sent to SMC.
