| model | TOTAL | neatness/40 | structure/30 | names/15 | size/15 | crossings | shared lanes | lint errors |
|---|---|---|---|---|---|---|---|---|
| gemini-3.8-flash | 53.0 | 11 | 27 | 15.0 | 0.0 | 0 | 8 | 1 |
| claude-opus-5.5 | 45.0 | 0 | 30 | 15.0 | 0.0 | 12 | 13 | 1 |
| claude-sonnet-5.5 | 45.0 | 0 | 30 | 15.0 | 0.0 | 13 | 12 | 1 |
| gpt-5.5 | 45.0 | 0 | 30 | 15.0 | 0.0 | 4 | 28 | 3 |
| gpt-6.1-sol | 45.0 | 0 | 30 | 15.0 | 0.0 | 10 | 18 | 2 |
| grok-4.7 | 45.0 | 0 | 30 | 15.0 | 0.0 | 3 | 13 | 0 |

**gemini-3.8-flash** (53.0)
- Network: private endpoints and Key Vaults missing
- Communication: Key Vaults missing
- 01-Architecture-Diagram.png: 7802x2041 aspect 3.82  <-- too wide not compact
- 02-Network-Diagram.png: 7014x2075 aspect 3.38  <-- too wide not compact
- 03-Communication-Diagram.png: 4250x1651 aspect 2.57  <-- too wide
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_7nv_nhed\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_7nv_nhed\png

**claude-opus-5.5** (45.0)
- 01-Architecture-Diagram.png: 6214x1877 aspect 3.31  <-- too wide not compact
- 02-Network-Diagram.png: 7054x2073 aspect 3.40  <-- too wide not compact
- 03-Communication-Diagram.png: 6214x1425 aspect 4.36  <-- too wide not compact
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_etazzxsq\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_etazzxsq\png

**claude-sonnet-5.5** (45.0)
- Communication: Key Vaults missing
- 01-Architecture-Diagram.png: 6618x1933 aspect 3.42  <-- too wide not compact
- 02-Network-Diagram.png: 9524x2009 aspect 4.74  <-- too wide not compact
- 03-Communication-Diagram.png: 5004x1511 aspect 3.31  <-- too wide not compact
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_ypeqqt1b\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_ypeqqt1b\png

**gpt-5.5** (45.0)
- 01-Architecture-Diagram.png: 6580x1863 aspect 3.53  <-- too wide not compact
- 02-Network-Diagram.png: 6178x2365 aspect 2.61  <-- too wide not compact
- 03-Communication-Diagram.png: 3886x1469 aspect 2.65  <-- not compact
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_27ffb_vc\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_27ffb_vc\png

**gpt-6.1-sol** (45.0)
- 01-Architecture-Diagram.png: 7456x3585 aspect 2.08  <-- too wide
- 02-Network-Diagram.png: 7854x2515 aspect 3.12  <-- too wide not compact
- 03-Communication-Diagram.png: 6472x2053 aspect 3.15  <-- too wide not compact
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_zij667op\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_zij667op\png

**grok-4.7** (45.0)
- 01-Architecture-Diagram.png: 5087x2795 aspect 1.82  <-- too wide
- 02-Network-Diagram.png: 6420x2685 aspect 2.39  <-- too wide
- 03-Communication-Diagram.png: 7036x2107 aspect 3.34  <-- too wide not compact
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_cdqfzut7\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_cdqfzut7\png
