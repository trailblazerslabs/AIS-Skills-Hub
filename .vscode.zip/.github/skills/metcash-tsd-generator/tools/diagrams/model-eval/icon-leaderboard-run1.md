| model | TOTAL | neatness/40 | structure/30 | names/15 | size/15 | crossings | shared lanes | lint errors |
|---|---|---|---|---|---|---|---|---|
| grok-4.7 | 60.0 | 0 | 30 | 15.0 | 15.0 | 28 | 11 | 2 |
| gpt-5.5 | 55.0 | 0 | 30 | 15.0 | 10.0 | 6 | 20 | 6 |
| gpt-6.1-sol | 55.0 | 0 | 30 | 15.0 | 10.0 | 12 | 8 | 3 |
| claude-sonnet-5.5 | 44.0 | 0 | 29 | 15.0 | 0.0 | 3 | 13 | 1 |
| gemini-3.8-flash | 42.0 | 0 | 27 | 15.0 | 0.0 | 4 | 11 | 1 |
| claude-opus-5.5 | 0 | None | None | None | None | None | None | None |

**grok-4.7** (60.0)
- 01-Architecture-Diagram.png: 3244x2271 aspect 1.43
- 02-Network-Diagram.png: 3050x2203 aspect 1.38
- 03-Communication-Diagram.png: 3018x1723 aspect 1.75
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_y9hhuvn_\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_y9hhuvn_\png

**gpt-5.5** (55.0)
- 01-Architecture-Diagram.png: 3988x1737 aspect 2.30
- 02-Network-Diagram.png: 3492x1989 aspect 1.76
- 03-Communication-Diagram.png: 3776x1363 aspect 2.77  <-- not compact
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_p73fs_14\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_p73fs_14\png

**gpt-6.1-sol** (55.0)
- 01-Architecture-Diagram.png: 3574x1727 aspect 2.07
- 02-Network-Diagram.png: 5334x2347 aspect 2.27  <-- too wide
- 03-Communication-Diagram.png: 3198x1621 aspect 1.97
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_87exnhus\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_87exnhus\png

**claude-sonnet-5.5** (44.0)
- Communication: Key Vaults missing
- Network Diagram: more than 8 nodes on one row (long strip)
- 01-Architecture-Diagram.png: 5276x1651 aspect 3.20  <-- too wide not compact
- 02-Network-Diagram.png: 5866x2101 aspect 2.79  <-- too wide not compact
- 03-Communication-Diagram.png: 5004x1037 aspect 4.83  <-- too wide not compact
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_ftco2jac\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_ftco2jac\png

**gemini-3.8-flash** (42.0)
- Network: private endpoints and Key Vaults missing
- Communication: Key Vaults missing
- 01-Architecture-Diagram.png: 4226x1501 aspect 2.82  <-- too wide not compact
- 02-Network-Diagram.png: 5884x1523 aspect 3.86  <-- too wide not compact
- 03-Communication-Diagram.png: 3428x1057 aspect 3.24  <-- not compact
- drawio: C:\Users\jagae\AppData\Local\Temp\dq_9isfpso8\icons.drawio
- png: C:\Users\jagae\AppData\Local\Temp\dq_9isfpso8\png

**claude-opus-5.5** (0)
- builder rejected the spec: string indices must be integers, not 'str'
