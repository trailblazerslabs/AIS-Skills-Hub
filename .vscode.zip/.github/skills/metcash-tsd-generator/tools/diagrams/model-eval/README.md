# Choosing the model for TSD diagrams

## Current Model Policy (2026-10-05)

Diagram authoring and repairs are pinned to `Claude Opus 5.5 (copilot)` by user choice. This includes icon-page specs, simple process-flow specs and PlantUML. Auto can orchestrate an explicitly model-pinned subagent, but a skill cannot change the parent chat model. If model-specific delegation is unavailable, stop and request manual selection; do not substitute silently. SKILL.md is the routing authority.

The EAII-529 icon-page comparison is preserved in `PROMPT-icon-pages.md`, `candidates-icon/` and `icon-leaderboard-run1*.md`. These are single-run experimental results, not proof of a universal model winner. The initial report predates the Opus string-text compatibility fix and excludes later candidates; temporary render paths are historical, not portable assets. Files ending in `.auto.json` are transformed experiments, not independent model runs: exclude them when comparing raw candidates.

`../diagram_quality.py --drawio <file>` summarizes geometry for any built icon pages. Its spec-scoring mode has an EAII-529-specific required-name list and workload assumptions; do not apply those inventory scores to other interfaces. Use the interface's approved TSD and the normal build/lint/render gates instead. `../autolayout.py` is an experimental opt-in tool, not the production generation path: proxy-cost improvements did not reliably improve rendered quality, and real-cost search took over 20 minutes. Actual lint and visual inspection govern acceptance.

## What the model actually has to do
Not draw. `build_drawio.py` places everything and routes every arrow in the approved Metcash style from a JSON
**spec**. The model only has to read the design (TSD §5.x.2.1 + resource names) and say **which components exist,
how they connect, and which numbered step belongs where**. That is a structured-extraction task, so the right test is
"how faithful and valid is the spec", not "how pretty is the picture".

* Image-generation models (Imagen/DALL-E/Gemini image output, etc.) are the wrong tool: the output must be an editable
  `.drawio` with exact resource names, and they garble text.
* A **vision** model is only useful for the optional last step - looking at the rendered PNG for anything the lint cannot
  see. It does not need to be the same model that writes the spec.

## How to compare models (works in GitHub Copilot - any model in the picker)
1. Open a fresh Copilot Chat, pick the model, paste the whole of `PROMPT.md`. Ask for JSON only.
2. Save the reply to `candidates/<model-name>.json` (strip code fences if the model added them).
3. `python score_spec.py candidates/*.json` - side-by-side table.
4. Repeat 2-3 times per model (variance matters) and for a second page type (Architecture / Network) by copying the
   prompt and `gold/` file pattern; `score_spec.py --gold <file> --page N` takes any gold.

Score (100): validity 10 (valid icons/ids, builder accepts it) - nodes 20 - edges 20 - labels 20 (real resource names)
- steps 10 (1..N, contiguous, equals the design) - layout 20 (lint of the built diagram).

## Baseline already run (Claude only, one run each, EAII-374 Process Flow)

```
candidate            TOTAL  valid nodes edges labels steps layout
claude-fable-5-1      94.3     10  20.0  20.0   17.1    10   17.2
claude-sonnet-5-5     88.1     10  17.1  16.7   14.3    10   20.0
claude-opus-5-5       87.3     10  17.1  16.7   14.3    10   19.2
claude-haiku-4-5      67.0     10  14.3  13.3   11.4     0   18.0
```

Read this carefully:
* **n = 1 per model, one page type.** Differences of a few points are noise. Haiku's drop is real in kind: it duplicated
  step numbers 5 and 6, which the step check exists to catch.
* The gold spec encodes one architect's choices (e.g. DB2 icon `db2` vs `as400`), so a defensible alternative loses a
  little. Treat sub-5-point gaps as ties.
* **Not run in this historical Process Flow baseline: Gemini, GPT/OpenAI or other non-Claude models.** Later EAII-529 icon-page candidates include GPT, Codex, Gemini and Grok; their scores use a different task and scorer and cannot be compared directly with this table.
* `selftest/` holds deliberately broken specs (invented icon, lost resource name, bad step numbers, stacked layout) that
  prove the scorer separates good from bad. They are not model output.

## Benchmark Decision Rule (Not Model Routing)
Pick the model with the best mean TOTAL over >= 3 runs and 2 page types, provided steps = 10 and validity = 10 on every
run. If two are within ~5 points, prefer the cheaper/faster one. Benchmark results are evidence only: changing the pinned model requires the user's approval, and every generated diagram must still pass actual lint and visual inspection.
