# Prompt: write the three icon-style diagram pages for a TSD (Architecture, Network, Communication)

You are producing a **JSON spec** only. A deterministic tool (`build_drawio.py`) places the shapes, draws the nested dashed containers and routes the
arrows in the approved Metcash style. You decide *what is on each page, where it sits in a 2-D grid, and how the containers nest*.
Reply with **one JSON object and nothing else** (no markdown fences, no commentary).

## Spec format

```
{"pages":[ {"name": "...", "pitch":[colWidth,rowHeight], "nodes":[...], "containers":[...], "edges":[...], "texts":[...]} ]}
```

| Key | Meaning |
|---|---|
| `pages[].name` | exactly `Architecture Diagram`, `Network Diagram`, `Communication Diagram` (in that order) |
| `pitch` | grid pitch in px, use `[170,125]` |
| `nodes[]` | `id`, `icon`, `label` (the resource name, magenta), `sub` (grey second line, max 35 chars), `col`, `row` (grid position, decimals allowed), `box` (true for external systems), `obs` (true on the component that writes SMC observations) |
| `containers[]` | `id`, `label`, `members` (node ids or INNER container ids, inner first), `badge`, `pad` |
| `edges[]` | `from`, `to`, `kind` (`flow` black default, `sync` green two-way, `smc` red, `secret` grey dashed), `label` (max 22 chars) |

Allowed `icon` values: apim, apim-operation, app-gateway, logic-app, function-app, storage-account, event-grid, service-bus, service-bus-queue,
key-vault, app-insights, aad, external-system, private-endpoint, smc, globe, goanywhere, db2, as400, stibo.
Allowed container `badge` values: azure, subscription, resource-group, vnet, subnet, apim.

Builder rules you must respect:
* A container is the **bounding box of its members**. Any node whose grid cell falls inside that box is drawn inside it, so keep external systems
  and unrelated resources outside every container's column and row range.
* Never put two nodes in the same cell. Keep edge labels short; one long label widens the whole page.
* Every resource gets a unique label. Use the exact resource names given below, nothing invented.

## The approved look you must reproduce (human-made reference diagrams EAII-289, 297, 304, 514)

**Architecture Diagram (physical).** One outer `azure` container. Inside it, **subscription containers** (`COREIT-SERVICES-HUB-{NPR/PRD}`,
`COREIT-SERVICES-AIS-{env}`), and inside each subscription **resource-group containers** (badge `resource-group`) that hold the icons of that group's
resources. Application Insights, the Key Vaults and SMC sit in a top row. External systems (source, target, GoAnywhere) are outside the Azure
container, left and right. The page is **compact and roughly 5 to 7 columns by 4 to 5 rows**, aspect ratio about 1.6 : 1. Never a single long row.

**Network Diagram.** Same components and same relative positions as the architecture, but the nesting is
`azure` > `subscription` > `vnet` > `subnet` (SENS for the Function App, HSENS for the private endpoints, hub VNet for APIM), the arrows carry protocol
and port labels (`HTTPS 443`, `AMQP 5671`), and every PaaS resource reached privately has its own `private-endpoint` node in HSENS.

**Communication Diagram.** Simplified. External source on the left, one `azure` boundary with the main components in a two-row flow, SMC top right,
arrows labelled with the protocol (`HTTPS`, `AMQP`, `Connect Direct`). Group nodes in 3 to 5 labelled layer containers without badge.

## Design to draw: EAII-529 PE Product Data to Stibo (event-driven Function App)

Flow: PE (AS/400) drops `PRD_JRN.<job>` on TIBMIP by Connect Direct -> GoAnywhere MFT picks it up and writes it to Blob Storage `in/` ->
Event Grid system topic `metproducts` raises BlobCreated -> Service Bus topic `data.metproducts.{env}.sbt` (subscription `tostibo.peproductdata`,
session enabled) -> Function App `PEProductDataToStibo` pulls it, reads and moves the blob (`in/`, `archive/`, `error/`), reads secrets from Key Vault,
requests an OAuth 2.0 token from Stibo and posts XML to three Stibo endpoints (HTTPS 443), and logs one observation to SMC through APIM API `smc-v1`
(which forwards to the SMC queue). APIM here is only the SMC gateway; it validates no OAuth token.

Resources (use exactly these labels; `{env}` stays literally as written):

| Component | Icon | Label | Sub | Subscription | Resource group |
|---|---|---|---|---|---|
| PE and TIBMIP | external-system (box) | PE / TIBMIP | Connect Direct | outside Azure | - |
| GoAnywhere | goanywhere (box) | GoAnywhere MFT | MFT team | outside Azure | - |
| Storage | storage-account | t3data{env}aesta01 | pe/frompe/productdata | COREIT-SERVICES-AIS-{env} | t3-met-ais-{env}-ae1-rsg-data |
| Event Grid | event-grid | system topic metproducts | BlobCreated on in/ | COREIT-SERVICES-AIS-{env} | t3-met-ais-{env}-ae1-rsg-data |
| Function App (obs) | function-app | t3-met-metproducts-{env}-ae-func | PEProductDataToStibo | COREIT-SERVICES-AIS-{env} | t3-met-ais-{env}-ae1-rsg-data |
| Key Vault data | key-vault | t3data{env}ae1kv01 | Stibo client secret | COREIT-SERVICES-AIS-{env} | t3-met-ais-{env}-ae1-rsg-data |
| Key Vault enabling | key-vault | t3enabling{env}ae1kv01 | SMC-API-Subscription-Key | COREIT-SERVICES-AIS-{env} | t3-met-ais-{env}-ae1-rsg-enabling |
| App Insights | app-insights | t3-met-metproducts-{env}-ae-func-ai | | COREIT-SERVICES-AIS-{env} | t3-met-ais-{env}-ae1-rsg-data |
| Service Bus topic | service-bus | data.metproducts.{env}.sbt | tostibo.peproductdata (session) | COREIT-SERVICES-HUB-{NPR/PRD} | t1-met-core-{npr/prd}-ae1-rsg-sbus |
| APIM (SMC gateway) | apim | t3-met-core-{apim-env}-ae1-apim | smc-v1, SMC gateway only | COREIT-SERVICES-HUB-{NPR/PRD} | t3-met-core-{apim-env}-ae1-rsg-apim |
| SMC queue | service-bus-queue | smc.endobservation.{smc-env}.sbq | | SMC-owned, outside the subscriptions | - |
| SMC | smc | SMC | | outside | - |
| Stibo | stibo (box) | Stibo STEP PIM | Metcash TLS proxy | outside Azure | - |

Network page extras: spoke VNet `t2-met-ais-{env}-ae1-net-01` (subnets `SENS` holds the Function App; `HSENS` holds the private endpoints
`t3data{env}aesta01-pe`, `t1-met-{npr/prd}-ae-sb-001-pe`, `t3data{env}ae1kv01-pe`, `t3enabling{env}ae1kv01-pe`, `t3-met-metproducts-{env}-ae-func-ai-pe`),
hub VNet `t1-met-core-{npr/prd}-ae1-net-hub` (APIM in subnet `ECCS2 / ECCS3 / ECCS4`).

Include in `texts` of the Architecture page: `{env} - dv1, st1, ut1, prd`.

Return the JSON now.
