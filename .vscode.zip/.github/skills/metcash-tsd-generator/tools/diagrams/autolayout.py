#!/usr/bin/env python3
"""Neat layout by search: keep the model's topology (nodes, edges, containers) and move nodes on the grid until the page has no edge
crossings, no shared lanes, nothing inside a container it does not belong to, and a compact shape.

The model decides WHAT is on a page and how containers nest; this step decides WHERE things go. Cost is measured with the real builder
and linter (lint_drawio.py), so the result is what the renderer will draw.

  python autolayout.py in.json out.json [--iters 400] [--seed 7] [--page "Network Diagram"]
"""
import argparse, copy, json, math, random, sys, tempfile
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import build_drawio as B  # noqa: E402
import lint_drawio as L  # noqa: E402

STEP = 0.5
TMP = Path(tempfile.mkdtemp(prefix="al_")) / "p.drawio"


def members_of(page, cid, cmap, seen=()):
    out = set()
    for m in cmap[cid].get("members", []):
        if m in cmap and m not in seen:
            out |= members_of(page, m, cmap, seen + (cid,))
        else:
            out.add(m)
    return out


def cost(page, detail=False):
    try:
        B.build_from_dict({"pages": [copy.deepcopy(page)]}, str(TMP))
        res = L.lint_file(str(TMP))[0]
    except Exception:  # noqa: BLE001
        return (1e9, {}) if detail else 1e9
    c = dict(errors=0, cross=0, lane=0, cuts=0, other=0)
    for sev, code, msg in res["issues"]:
        if code == "edges-cross":
            c["cross"] += 1
        elif code == "edges-share-lane":
            c["lane"] += 1
        elif code == "container-border-cuts":
            c["cuts"] += 1
        elif sev == "error":
            c["errors"] += 1
        else:
            c["other"] += 1
    nodes = {n["id"]: n for n in page["nodes"]}
    cmap = {x["id"]: x for x in page.get("containers", [])}
    intruders = 0
    for cid in cmap:
        mem = members_of(page, cid, cmap)
        ms = [nodes[m] for m in mem if m in nodes]
        if not ms:
            continue
        c0, c1 = min(n["col"] for n in ms) - 0.45, max(n["col"] for n in ms) + 0.45
        r0, r1 = min(n["row"] for n in ms) - 0.45, max(n["row"] for n in ms) + 0.45
        for n in page["nodes"]:
            if n["id"] not in mem and c0 < n["col"] < c1 and r0 < n["row"] < r1:
                intruders += 1
    cols = [n["col"] for n in page["nodes"]]
    rows = [n["row"] for n in page["nodes"]]
    w, h = max(cols) - min(cols) + 1.2, max(rows) - min(rows) + 1.4
    ratio = w / h
    length = 0.0
    for e in page.get("edges", []):
        a, b = nodes.get(e["from"]), nodes.get(e["to"])
        if a and b:
            length += abs(a["col"] - b["col"]) + abs(a["row"] - b["row"])
    total = (60 * c["errors"] + 14 * c["cross"] + 6 * c["lane"] + 25 * c["cuts"] + 3 * c["other"] + 50 * intruders
             + 0.8 * length + 14 * max(0, ratio - 2.1) + 10 * max(0, 1.3 - ratio) + 9 * max(0, w - 9.5))
    c.update(intruders=intruders, ratio=round(ratio, 2), width_cols=round(w, 1))
    return (total, c) if detail else total



def segs_of(route):
    return list(zip(route, route[1:]))


def seg_cross(a, b):
    (p1, p2), (p3, p4) = a, b
    h1, v1 = abs(p1[1] - p2[1]) < 0.5, abs(p1[0] - p2[0]) < 0.5
    h2, v2 = abs(p3[1] - p4[1]) < 0.5, abs(p3[0] - p4[0]) < 0.5
    if h1 and v2:
        hy, hx, vx, vy = p1[1], sorted((p1[0], p2[0])), p3[0], sorted((p3[1], p4[1]))
    elif v1 and h2:
        hy, hx, vx, vy = p3[1], sorted((p3[0], p4[0])), p1[0], sorted((p1[1], p2[1]))
    else:
        return 0, 0
    if hx[0] + 4 < vx < hx[1] - 4 and vy[0] + 4 < hy < vy[1] - 4:
        return 1, 0
    return 0, 0


def collinear(a, b):
    (p1, p2), (p3, p4) = a, b
    if abs(p1[1] - p2[1]) < 0.5 and abs(p3[1] - p4[1]) < 0.5 and abs(p1[1] - p3[1]) < 12:
        return max(0, min(max(p1[0], p2[0]), max(p3[0], p4[0])) - max(min(p1[0], p2[0]), min(p3[0], p4[0])))
    if abs(p1[0] - p2[0]) < 0.5 and abs(p3[0] - p4[0]) < 0.5 and abs(p1[0] - p3[0]) < 12:
        return max(0, min(max(p1[1], p2[1]), max(p3[1], p4[1])) - max(min(p1[1], p2[1]), min(p3[1], p4[1])))
    return 0


def seg_through(seg, box):
    (x1, y1), (x2, y2) = seg
    bx0, by0, bx1, by1 = box
    if abs(y1 - y2) < 0.5:
        return by0 < y1 < by1 and min(max(x1, x2), bx1) - max(min(x1, x2), bx0) > 2
    if abs(x1 - x2) < 0.5:
        return bx0 < x1 < bx1 and min(max(y1, y2), by1) - max(min(y1, y2), by0) > 2
    return False


def cost_fast(page, detail=False):
    px, py = page.get("pitch", [190, 130])
    nodes = {n["id"]: n for n in page["nodes"]}
    pos = {k: (n["col"] * px, n["row"] * py) for k, n in nodes.items()}
    box = {k: (x - 48, y - 40, x + 48, y + 52) for k, (x, y) in pos.items()}
    routes, cross, lane, through = [], 0, 0, 0
    for e in page.get("edges", []):
        if e["from"] not in pos or e["to"] not in pos:
            continue
        a, b = pos[e["from"]], pos[e["to"]]
        cands = []
        if abs(a[0] - b[0]) < 1 or abs(a[1] - b[1]) < 1:
            cands.append([a, b])
        else:
            cands += [[a, (b[0], a[1]), b], [a, (a[0], b[1]), b]]
        best, bc, bd = None, 1e18, None
        for r in cands:
            t = sum(1 for s in segs_of(r) for k, bx in box.items() if k not in (e["from"], e["to"]) and seg_through(s, bx))
            x = l = 0
            for (r2, ends2) in routes:
                if ends2 & {e["from"], e["to"]}:
                    continue
                for s1 in segs_of(r):
                    for s2 in segs_of(r2):
                        x += seg_cross(s1, s2)[0]
                        l += 1 if collinear(s1, s2) > 40 else 0
            c = 50 * t + 14 * x + 6 * l
            if c < bc:
                best, bc, bd = r, c, (t, x, l)
        routes.append((best, {e["from"], e["to"]}))
        through += bd[0]; cross += bd[1]; lane += bd[2]
    cmap = {x["id"]: x for x in page.get("containers", [])}
    mem = {cid: members_of(page, cid, cmap) for cid in cmap}
    intr = overlap = 0
    bb = {}
    for cid, m in mem.items():
        ms = [nodes[i] for i in m if i in nodes]
        if not ms:
            continue
        bb[cid] = (min(n["col"] for n in ms) - 0.5, min(n["row"] for n in ms) - 0.5, max(n["col"] for n in ms) + 0.5, max(n["row"] for n in ms) + 0.5)
        for n in page["nodes"]:
            if n["id"] not in m and bb[cid][0] < n["col"] < bb[cid][2] and bb[cid][1] < n["row"] < bb[cid][3]:
                intr += 1
    ids = list(bb)
    for i, c1 in enumerate(ids):
        for c2 in ids[i + 1:]:
            if mem[c1] <= mem[c2] or mem[c2] <= mem[c1] or mem[c1] & mem[c2]:
                continue
            a, b = bb[c1], bb[c2]
            if min(a[2], b[2]) - max(a[0], b[0]) > 0.1 and min(a[3], b[3]) - max(a[1], b[1]) > 0.1:
                overlap += 1
    cols = [n["col"] for n in page["nodes"]]; rows = [n["row"] for n in page["nodes"]]
    w, h = max(cols) - min(cols) + 1.2, max(rows) - min(rows) + 1.4
    ratio = w / h
    length = sum(abs(pos[e["from"]][0] - pos[e["to"]][0]) / px + abs(pos[e["from"]][1] - pos[e["to"]][1]) / py for e in page.get("edges", []) if e["from"] in pos and e["to"] in pos)
    total = 14 * cross + 6 * lane + 50 * through + 50 * intr + 40 * overlap + 0.8 * length + 14 * max(0, ratio - 2.1) + 10 * max(0, 1.3 - ratio) + 9 * max(0, w - 9.5)
    d = dict(cross=cross, lane=lane, through=through, intruders=intr, container_overlap=overlap, ratio=round(ratio, 2), width_cols=round(w, 1))
    return (total, d) if detail else total


def free(page, nid, col, row):
    for n in page["nodes"]:
        if n["id"] != nid and abs(n["col"] - col) < 0.9 and abs(n["row"] - row) < 0.9:
            return False
    return True


def anneal(page, iters, rng, real=False):
    fn = cost if real else cost_fast
    page = copy.deepcopy(page)
    cur = fn(page)
    best, best_c = copy.deepcopy(page), cur
    ids = [n["id"] for n in page["nodes"]]
    for i in range(iters):
        T = 25 * (1 - i / iters) + 0.5
        nodes = {n["id"]: n for n in page["nodes"]}
        old = {k: (v["col"], v["row"]) for k, v in nodes.items()}
        r = rng.random()
        if r < 0.25 and len(ids) > 1:
            a, b = rng.sample(ids, 2)
            nodes[a]["col"], nodes[a]["row"], nodes[b]["col"], nodes[b]["row"] = old[b][0], old[b][1], old[a][0], old[a][1]
        else:
            a = rng.choice(ids)
            span = 3 if r < 0.7 else 1
            col = round((old[a][0] + rng.choice(range(-span, span + 1)) * STEP) / STEP) * STEP
            row = round((old[a][1] + rng.choice(range(-span, span + 1)) * STEP) / STEP) * STEP
            if col < 0 or row < 0 or (col, row) == old[a] or not free(page, a, col, row):
                continue
            nodes[a]["col"], nodes[a]["row"] = col, row
        new = fn(page)
        if new <= cur or rng.random() < math.exp((cur - new) / T):
            cur = new
            if cur < best_c:
                best, best_c = copy.deepcopy(page), cur
        else:
            for k, (c, rr) in old.items():
                nodes[k]["col"], nodes[k]["row"] = c, rr
    return best, best_c


def normalise(page):
    c0 = min(n["col"] for n in page["nodes"])
    r0 = min(n["row"] for n in page["nodes"])
    for n in page["nodes"]:
        n["col"] = round(n["col"] - c0, 2)
        n["row"] = round(n["row"] - r0 + 1.0, 2)
    for t in page.get("texts", []):
        if isinstance(t, dict):
            t["col"] = 0.3
            t["row"] = 0.2
    return page


def run(spec, iters=400, seed=7, only=None, real=False):
    out = copy.deepcopy(spec)
    report = []
    for i, p in enumerate(out["pages"]):
        if only and p["name"] != only:
            continue
        B.normalize_page(p)
        before, bd = cost_fast(p, True)
        best, after = anneal(p, iters, random.Random(seed + i), real)
        normalise(best)
        after, ad = cost_fast(best, True)
        out["pages"][i] = best
        report.append((p["name"], round(before, 1), round(after, 1), bd, ad))
    return out, report


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--iters", type=int, default=400)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--page")
    ap.add_argument("--real", action="store_true", help="score moves with the real builder and linter (slower, exact)")
    a = ap.parse_args()
    spec = json.loads(Path(a.src).read_text(encoding="utf-8-sig"))
    out, rep = run(spec, a.iters, a.seed, a.page, a.real)
    Path(a.dst).write_text(json.dumps(out, indent=1), encoding="utf-8")
    for name, b, af, bd, ad in rep:
        print(f"{name}: cost {b} -> {af}  before {bd}  after {ad}")
