#!/usr/bin/env python3
"""Build the simple, very high-level PROCESS FLOW diagram (TSD section 5.x.2.2) from a small JSON spec.

This is the style of the approved EAII-374 "Process Diagram_v4": a title and one-line subtitle, coloured rounded
boxes (no icons, no step circles, no containers of Azure subscriptions), nested boxes for APIM / Logic App with the
operations or actions listed inside, and a few labelled arrows. Architecture, Network and Communication pages keep
using build_drawio.py (icon style).

Usage:  python build_simple_flow.py spec.json out.drawio
        python render_drawio.py out.drawio outdir

Spec:
{ "pages": [ { "name": "EAII-536 Process Flow", "title": "EAII-536 | Sorted to Yard", "subtitle": "...",
    "pitch": [270, 130],
    "nodes": [ {"id","kind","title","lines":[...],"children":[{"text","step"}],"col","row","w","h"} ],
    "edges": [ {"from","to","label","bidir":true,"exit":"1,0.5","entry":"0,0.5"} ] } ] }
kinds: source, gateway, apim, bus, logic, store, lookup, mft, target, smc
Position is the node CENTRE = (col*pitch_x, row*pitch_y). A node with children becomes a container whose height grows
with the number of children. Keep titles <= 28 chars, lines <= 34 chars, edge labels <= 22 chars.
"""
import html
import json
import sys
from pathlib import Path

# kind: (fill, stroke, title colour)
KINDS = {
    "source": ("#E8F0FB", "#2F6FDE", "#1E3A8A"),
    "gateway": ("#E8ECFB", "#4F46E5", "#312E81"),
    "apim": ("#F3E8FD", "#9333EA", "#581C87"),
    "bus": ("#E0F7FA", "#0891B2", "#155E75"),
    "logic": ("#E8FBF1", "#059669", "#065F46"),
    "store": ("#E0F2FE", "#0284C7", "#075985"),
    "lookup": ("#FEF3C7", "#D97706", "#92400E"),
    "mft": ("#FFF1E6", "#EA580C", "#9A3412"),
    "target": ("#FDEEEE", "#DC2626", "#991B1B"),
    "smc": ("#EEF2F7", "#475569", "#1E293B"),
}
EDGE = "#475569"
CHILD_H, CHILD_GAP, HEAD_H = 36, 10, 74


def esc(s):
    return html.escape(str(s), quote=True)


def label(title, lines, color):
    v = f'<b style="font-size:13px;color:{color}">{esc(title)}</b>'
    for ln in lines or []:
        v += f'<br><span style="font-size:11px;color:{color}">{esc(ln)}</span>'
    return v


class Page:
    def __init__(self, spec):
        self.spec = spec
        self.px, self.py = spec.get("pitch", [270, 130])
        self.cells, self.n = [], 1
        self.geo = {}

    def nid(self):
        self.n += 1
        return f"s{self.n}"

    def add(self, value, style, x, y, w, h, vertex=True, parent="1", extra=""):
        i = self.nid()
        self.cells.append(f'<mxCell id="{i}" value="{esc(value) if not value.startswith("<") else html.escape(value, quote=True)}" style="{style}" vertex="1" parent="{parent}"><mxGeometry x="{x:.0f}" y="{y:.0f}" width="{w:.0f}" height="{h:.0f}" as="geometry"/></mxCell>')
        return i

    def plan_sides(self, e):
        """Which side of each node the edge leaves / enters, from the real node rectangles (not from fixed anchors)."""
        _, ax, ay, aw, ah = self.geo[e["from"]]
        _, bx, by, bw, bh = self.geo[e["to"]]
        if ax + aw + 10 <= bx:
            return "R", "L"
        if bx + bw + 10 <= ax:
            return "L", "R"
        if ay + ah + 10 <= by:
            return "B", "T"
        if by + bh + 10 <= ay:
            return "T", "B"
        return "R", "L"

    def hits(self, p, q, skip):
        for k, (_, x, y, w, h) in self.geo.items():
            if k in skip:
                continue
            x0, y0, x1, y1 = x - 8, y - 8, x + w + 8, y + h + 8
            if abs(p[1] - q[1]) < 0.5:
                if y0 < p[1] < y1 and min(max(p[0], q[0]), x1) - max(min(p[0], q[0]), x0) > 0:
                    return True
            elif abs(p[0] - q[0]) < 0.5:
                if x0 < p[0] < x1 and min(max(p[1], q[1]), y1) - max(min(p[1], q[1]), y0) > 0:
                    return True
        return False

    def route_edge(self, e, sides, fa, fb, k):
        """Orthogonal route computed from node geometry: straight or elbow when clear, otherwise a lane above / below the nodes
        in between. Recomputed from the rectangles on every build, so a longer label or an extra child row cannot leave a
        stale waypoint behind (the failure the developers hit with hand-written exit/entry points)."""
        ida, idb = e["from"], e["to"]
        _, ax, ay, aw, ah = self.geo[ida]
        _, bx, by, bw, bh = self.geo[idb]
        skip = {ida, idb}
        sa, sb = sides

        def port(x, y, w, h, side, f):
            return {"R": (x + w, y + h * f), "L": (x, y + h * f), "T": (x + w * f, y), "B": (x + w * f, y + h)}[side]

        s, t = port(ax, ay, aw, ah, sa, fa), port(bx, by, bw, bh, sb, fb)
        off = ((k % 5) - 2) * 7
        if sa in "RL" and sb in "RL":
            cand = [s, t] if abs(s[1] - t[1]) < 3 else [s, ((s[0] + t[0]) / 2 + off, s[1]), ((s[0] + t[0]) / 2 + off, t[1]), t]
        elif sa in "TB" and sb in "TB":
            cand = [s, t] if abs(s[0] - t[0]) < 3 else [s, (s[0], (s[1] + t[1]) / 2 + off), (t[0], (s[1] + t[1]) / 2 + off), t]
        else:
            cand = [s, t]
        if all(not self.hits(cand[i], cand[i + 1], skip) for i in range(len(cand) - 1)):
            pts = cand
        else:
            lo, hi = min(s[0], t[0]), max(s[0], t[0])
            between = [g for key, g in self.geo.items() if key not in skip and g[1] + g[3] > lo and g[1] < hi]
            top = min([ay, by] + [g[2] for g in between]) - 40 - abs(off)
            bot = max([ay + ah, by + bh] + [g[2] + g[4] for g in between]) + 40 + abs(off)
            above = [(ax + aw * fa, ay), (ax + aw * fa, top), (bx + bw * fb, top), (bx + bw * fb, by)]
            below = [(ax + aw * fa, ay + ah), (ax + aw * fa, bot), (bx + bw * fb, bot), (bx + bw * fb, by + bh)]
            ok = [p for p in (above, below) if all(not self.hits(p[i], p[i + 1], skip) for i in range(3))]
            pts = min(ok, key=lambda p: sum(abs(p[i + 1][0] - p[i][0]) + abs(p[i + 1][1] - p[i][1]) for i in range(3))) if ok else cand

        def frac(x, y, w, h, p):
            return (round((p[0] - x) / w, 3), round((p[1] - y) / h, 3))

        return frac(ax, ay, aw, ah, pts[0]), frac(bx, by, bw, bh, pts[-1]), pts[1:-1]

    def build(self):
        nodes = self.spec["nodes"]
        for nd in nodes:
            fill, stroke, tcol = KINDS[nd["kind"]]
            kids = nd.get("children", [])
            w = nd.get("w", 200 if kids else 160)
            h = nd.get("h", (HEAD_H + len(kids) * (CHILD_H + CHILD_GAP) + 10) if kids else 84)
            cx, cy = nd["col"] * self.px, nd["row"] * self.py
            x, y = cx - w / 2, cy - h / 2
            style = (f"rounded=1;arcSize={10 if kids else 14};whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};"
                     f"strokeWidth=2;fontFamily=Helvetica;align=center;verticalAlign={'top' if kids else 'middle'};spacingTop={8 if kids else 0};")
            cid = self.add(label(nd["title"], nd.get("lines"), tcol), style, x, y, w, h)
            self.geo[nd["id"]] = (cid, x, y, w, h)
            for k, ch in enumerate(kids):
                cxk, cyk = 14, HEAD_H + k * (CHILD_H + CHILD_GAP)
                txt = (f'<b>{esc(ch["step"])}</b>&nbsp;&nbsp;' if ch.get("step") else "") + esc(ch["text"])
                kstyle = (f"rounded=1;arcSize=18;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor={stroke};strokeWidth=1;"
                          f"fontSize=10;fontColor={tcol};align=left;spacingLeft=8;fontFamily=Helvetica;")
                i = self.nid()
                self.cells.append(f'<mxCell id="{i}" value="{html.escape(txt, quote=True)}" style="{kstyle}" vertex="1" parent="{cid}"><mxGeometry x="{cxk}" y="{cyk}" width="{w - 28}" height="{CHILD_H}" as="geometry"/></mxCell>')
        sides = {}
        for k, e in enumerate(self.spec.get("edges", [])):
            sides[k] = self.plan_sides(e)
        ports = {}
        for k, (sa, sb) in sides.items():
            e = self.spec["edges"][k]
            ports.setdefault((e["from"], sa), []).append((k, "a"))
            ports.setdefault((e["to"], sb), []).append((k, "b"))
        frac = {}
        for plist in ports.values():
            for i, (k, end) in enumerate(plist):
                frac[(k, end)] = (i + 1) / (len(plist) + 1)
        for k, e in enumerate(self.spec.get("edges", [])):
            a, b = self.geo[e["from"]], self.geo[e["to"]]
            if e.get("exit"):
                # legacy manual anchors: kept for old specs, but they do not follow node size changes
                print(f"WARN edge {e['from']}->{e['to']}: manual exit/entry is fragile; delete them to use the automatic router", file=sys.stderr)
                ex, ey = e["exit"].split(",")
                nx, ny = e["entry"].split(",")
                pts = []
            else:
                (ex, ey), (nx, ny), pts = self.route_edge(e, sides[k], frac.get((k, "a"), 0.5), frac.get((k, "b"), 0.5), k)
            style = (f"{'edgeStyle=orthogonalEdgeStyle;orthogonalLoop=1;' if not pts else ''}rounded=0;html=1;strokeColor={EDGE};strokeWidth=2;"
                     f"endArrow=block;endFill=1;{'startArrow=block;startFill=1;' if e.get('bidir') else ''}"
                     f"fontSize=10;fontColor=#334155;labelBackgroundColor=#FFFFFF;exitX={ex};exitY={ey};entryX={nx};entryY={ny};")
            arr = ('<Array as="points">' + "".join(f'<mxPoint x="{x:.0f}" y="{y:.0f}"/>' for x, y in pts) + "</Array>") if pts else ""
            i = self.nid()
            self.cells.append(f'<mxCell id="{i}" value="{esc(e.get("label", ""))}" style="{style}" edge="1" parent="1" source="{a[0]}" target="{b[0]}"><mxGeometry relative="1" as="geometry">{arr}</mxGeometry></mxCell>')
        # title and subtitle above the left-most node
        minx = min(g[1] for g in self.geo.values())
        miny = min(g[2] for g in self.geo.values())
        self.add(f'<b style="font-size:20px;color:#0F172A">{esc(self.spec["title"])}</b>', "text;html=1;align=left;verticalAlign=top;whiteSpace=nowrap;", minx, miny - 100, 900, 30)
        if self.spec.get("subtitle"):
            self.add(f'<span style="font-size:11px;color:#64748B">{esc(self.spec["subtitle"])}</span>', "text;html=1;align=left;verticalAlign=top;whiteSpace=nowrap;", minx, miny - 68, 900, 20)
        return "\n".join(self.cells)


def build(spec_path, out_path):
    spec = json.loads(Path(spec_path).read_text(encoding="utf-8-sig"))
    diagrams = []
    for k, pg in enumerate(spec["pages"]):
        body = Page(pg).build()
        diagrams.append(f'<diagram id="p{k}" name="{esc(pg["name"])}"><mxGraphModel dx="1400" dy="900" grid="0" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="0" pageScale="1" pageWidth="3000" pageHeight="1600" math="0" shadow="0"><root><mxCell id="0"/><mxCell id="1" parent="0"/>\n{body}\n</root></mxGraphModel></diagram>')
    Path(out_path).write_text('<?xml version="1.0" encoding="UTF-8"?>\n<mxfile host="app.diagrams.net" agent="metcash-tsd-generator">' + "".join(diagrams) + "</mxfile>", encoding="utf-8")
    print(out_path)


if __name__ == "__main__":
    build(sys.argv[1], sys.argv[2])
