#!/usr/bin/env python3
"""Diagram quality gate for the three icon-style TSD pages (Architecture, Network, Communication).

Scores a SPEC json (what a model writes) after building it with build_drawio.py, linting it and rendering it. Also usable on a finished
.drawio (`--drawio`) for the visual-neatness part only.

  python diagram_quality.py candidates-icon/*.json [--render] [--out report.md]
  python diagram_quality.py --drawio tsd/X/diagrams/icons.drawio [--render]

Score (100):
  neatness 40  edge crossings (3 each), shared lanes (2), edges through icons / overlaps (10), other lint warnings (1); floor 0
  structure 30 reference style: nested azure > subscription > resource-group (Architecture), vnet > subnet + private endpoints (Network),
               layer containers (Communication), Key Vaults / App Insights / SMC / external systems present, no stacked row
  names     15 required resource names (REQUIRED below) appear as labels
  size      15 (needs --render) page <= 4200 px wide at scale 2 and aspect ratio 1.2 to 2.6 (compact, not a long strip)
"""
import argparse, json, re, subprocess, sys, tempfile
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import build_drawio as B  # noqa: E402
import lint_drawio as L  # noqa: E402

REQUIRED = [
    "t3-met-metproducts-{env}-ae-func", "t3data{env}aesta01", "t3data{env}ae1kv01", "t3enabling{env}ae1kv01",
    "t3-met-metproducts-{env}-ae-func-ai", "data.metproducts.{env}.sbt", "t3-met-core-{apim-env}-ae1-apim",
    "smc.endobservation.{smc-env}.sbq", "COREIT-SERVICES-AIS-{env}", "COREIT-SERVICES-HUB-{NPR/PRD}",
    "t3-met-ais-{env}-ae1-rsg-data", "t3-met-ais-{env}-ae1-rsg-enabling", "t2-met-ais-{env}-ae1-net-01",
    "t1-met-core-{npr/prd}-ae1-net-hub", "SENS", "HSENS", "Stibo", "GoAnywhere", "SMC",
]


def norm(s):
    return re.sub(r"\s+", "", (s or "").lower())


def page_by(spec, name):
    for p in spec.get("pages", []):
        if p.get("name") == name:
            return p
    return {}


def chain_ok(p, outer, mid, inner):
    """true when some container with badge `inner` sits inside one with `mid` inside one with `outer` (via members)."""
    cs = {c["id"]: c for c in p.get("containers", [])}

    def desc(cid, badge, seen=()):
        c = cs.get(cid)
        if not c:
            return False
        return any(cs.get(m, {}).get("badge") == badge or desc(m, badge, seen + (cid,)) for m in c.get("members", []) if m in cs and m not in seen)

    for c in cs.values():
        if c.get("badge") == outer and any(cs.get(m, {}).get("badge") == mid and (inner is None or desc(m, inner)) for m in c.get("members", []) if m in cs):
            return True
        if c.get("badge") == outer and any(desc(m, mid) for m in c.get("members", []) if m in cs):
            return inner is None or any(desc(m, inner) for m in c.get("members", []) if m in cs)
    return False


def structure(spec):
    notes, pts = [], 0
    A, N, C = (page_by(spec, n) for n in ("Architecture Diagram", "Network Diagram", "Communication Diagram"))
    icons = lambda p, i: sum(1 for n in p.get("nodes", []) if n.get("icon") == i)
    badges = lambda p, b: sum(1 for c in p.get("containers", []) if c.get("badge") == b)

    def chk(ok, w, msg):
        nonlocal pts
        if ok:
            pts += w
        else:
            notes.append(msg)

    chk(chain_ok(A, "azure", "subscription", "resource-group"), 5, "Architecture: no azure > subscription > resource-group nesting")
    chk(badges(A, "resource-group") >= 3, 3, "Architecture: fewer than 3 resource-group containers")
    chk(icons(A, "key-vault") >= 2 and icons(A, "app-insights") >= 1 and icons(A, "smc") >= 1, 3, "Architecture: Key Vaults, Application Insights and SMC not all shown")
    chk(sum(1 for n in A.get("nodes", []) if n.get("box")) >= 2, 2, "Architecture: external systems are not drawn as boxes")
    chk(chain_ok(N, "azure", "subscription", "vnet") or chain_ok(N, "subscription", "vnet", "subnet"), 4, "Network: no subscription > vnet > subnet nesting")
    chk(badges(N, "subnet") >= 2 and badges(N, "vnet") >= 2, 3, "Network: needs spoke and hub VNets and SENS / HSENS subnets")
    chk(icons(N, "private-endpoint") >= 4 and icons(N, "key-vault") >= 2, 3, "Network: private endpoints and Key Vaults missing")
    chk(len(C.get("containers", [])) >= 3, 3, "Communication: fewer than 3 layer containers")
    chk(icons(C, "key-vault") >= 2, 2, "Communication: Key Vaults missing")
    # compactness: no page may be a single strip (more than 9 distinct columns in one row band)
    for p in (A, N, C):
        rows = {}
        for n in p.get("nodes", []):
            rows.setdefault(round(n.get("row", 0)), []).append(n.get("col", 0))
        if rows and max(len(v) for v in rows.values()) > 8:
            notes.append(f"{p.get('name')}: more than 8 nodes on one row (long strip)")
            pts -= 1
    chk(len({p.get("name") for p in spec.get("pages", [])} & {"Architecture Diagram", "Network Diagram", "Communication Diagram"}) == 3, 4, "page names are not exactly the three required")
    return max(0, min(30, pts)), notes


def names(spec):
    labels = norm(" ".join(n.get("label", "") + " " + n.get("sub", "") for p in spec.get("pages", []) for n in p.get("nodes", []))) + norm(
        " ".join(c.get("label", "") for p in spec.get("pages", []) for c in p.get("containers", [])))
    hit = [r for r in REQUIRED if norm(r) in labels]
    miss = [r for r in REQUIRED if r not in hit]
    return round(15 * len(hit) / len(REQUIRED), 1), miss


def neat(issues_by_page):
    cross = lane = hard = other = 0
    for _, issues in issues_by_page:
        for sev, code, msg in issues:
            if code == "edges-cross":
                cross += 1
            elif code == "edges-share-lane":
                lane += 1
            elif sev == "error":
                hard += 1
            else:
                other += 1
    return max(0, 40 - 3 * cross - 2 * lane - 10 * hard - other), dict(crossings=cross, shared_lanes=lane, errors=hard, other=other)


def size(drawio, outdir):
    from PIL import Image
    subprocess.run([sys.executable, str(HERE / "render_drawio.py"), str(drawio), str(outdir), "--scale", "2"], capture_output=True, text=True)
    pts, notes = 0, []
    pngs = sorted(Path(outdir).glob("*.png"))
    for p in pngs:
        w, h = Image.open(p).size
        ok_w, ok_r = w <= 4200, 1.2 <= w / h <= 2.6
        pts += (7.5 if ok_w else 3) * (1 if ok_r else 0.6) / 1.5 * 1.0 / (len(pngs) / 3) / 1.0 * 0.5 if False else 0
        notes.append(f"{p.name}: {w}x{h} aspect {w / h:.2f}" + ("" if ok_w and ok_r else "  <-- " + ("too wide " if not ok_w else "") + ("not compact" if not ok_r else "")))
    good = sum(1 for p in pngs if Image.open(p).size[0] <= 4200 and 1.2 <= Image.open(p).size[0] / Image.open(p).size[1] <= 2.6)
    return round(15 * good / max(len(pngs), 1), 1), notes


def score_spec(path, render=False, auto=0):
    spec = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if auto:
        import autolayout as AL
        spec, _ = AL.run(spec, auto)
        Path(path).with_suffix(".auto.json").write_text(json.dumps(spec, indent=1), encoding="utf-8")
    tmp = Path(tempfile.mkdtemp(prefix="dq_"))
    out = tmp / "icons.drawio"
    try:
        B.build_from_dict(spec, str(out))
    except Exception as e:  # noqa: BLE001
        return dict(total=0, notes=[f"builder rejected the spec: {e}"], parts={})
    res = L.lint_file(str(out))
    n_pts, n_stats = neat([(r["page"], r["issues"]) for r in res])
    s_pts, s_notes = structure(spec)
    nm_pts, miss = names(spec)
    sz_pts, sz_notes = (size(out, tmp / "png") if render else (None, []))
    total = n_pts + s_pts + nm_pts + (sz_pts if sz_pts is not None else 0)
    return dict(total=round(total, 1), parts=dict(neatness=n_pts, structure=s_pts, names=nm_pts, size=sz_pts), stats=n_stats,
                notes=s_notes + ([f"missing names: {', '.join(miss)}"] if miss else []) + sz_notes, drawio=str(out), png=str(tmp / "png"), lint=res)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("specs", nargs="*")
    ap.add_argument("--drawio")
    ap.add_argument("--render", action="store_true")
    ap.add_argument("--auto", type=int, default=0, help="run autolayout with N iterations before scoring (also writes <spec>.auto.json)")
    ap.add_argument("--out")
    a = ap.parse_args()
    rows = []
    if a.drawio:
        res = L.lint_file(a.drawio)
        n_pts, st = neat([(r["page"], r["issues"]) for r in res])
        print(f"neatness {n_pts}/40 {st}")
        for r in res:
            for sev, code, msg in r["issues"]:
                print(f"  [{r['page']}] {sev} {code}: {msg}")
        sys.exit(0)
    import glob
    files = [f for g in a.specs for f in (glob.glob(g) or [g])]
    for s in files:
        r = score_spec(s, a.render, a.auto)
        rows.append((Path(s).stem, r))
    rows.sort(key=lambda x: -x[1]["total"])
    L_ = ["| model | TOTAL | neatness/40 | structure/30 | names/15 | size/15 | crossings | shared lanes | lint errors |", "|---|---|---|---|---|---|---|---|---|"]
    for name, r in rows:
        p, st = r.get("parts", {}), r.get("stats", {})
        L_.append(f"| {name} | {r['total']} | {p.get('neatness')} | {p.get('structure')} | {p.get('names')} | {p.get('size')} | {st.get('crossings')} | {st.get('shared_lanes')} | {st.get('errors')} |")
    txt = "\n".join(L_)
    for name, r in rows:
        txt += f"\n\n**{name}** ({r['total']})\n" + "\n".join(f"- {n}" for n in r.get("notes", [])[:12])
        if r.get("drawio"):
            txt += f"\n- drawio: {r['drawio']}\n- png: {r.get('png')}"
    print(txt)
    if a.out:
        Path(a.out).write_text(txt + "\n", encoding="utf-8")

