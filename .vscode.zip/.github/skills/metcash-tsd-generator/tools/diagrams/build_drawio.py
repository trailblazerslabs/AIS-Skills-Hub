#!/usr/bin/env python3
"""Build an approved-style Metcash AIS .drawio from a small JSON spec.

The model supplies WHAT is in the diagram (nodes, containers, edges, steps). This script decides
WHERE things go and HOW they look, so the result is the approved style every time:
  - real icons only, from icons.json (taken from approved corpus diagrams)
  - nested dashed-blue containers (#0066CC, 2px), magenta resource names (#ce3bae, bold 10px)
  - black orthogonal arrows, green two-way arrows for sync HTTP, red arrows for SMC/failure
  - blue numbered step circles (#2395FF), dark-red SMC observation dots (#990000)
  - grid layout + automatic edge routing that avoids icons and labels

Usage:  python build_drawio.py spec.json out.drawio
See specs/*.json for examples and SPEC.md for the schema.
"""
import base64, html, json, math, sys
from pathlib import Path

HERE = Path(__file__).parent
CAT = json.loads((HERE / "icons.json").read_text(encoding="utf-8"))
MAGENTA = "#ce3bae"
BLUE = "#0066CC"
MARK = "#2395FF"
DOT = "#990000"
EDGE = {  # kind -> (stroke, bidirectional, dashed)
    "flow": ("#000000", False, False),
    "sync": ("#43a81f", True, False),
    "smc": ("#d11f1f", False, False),
    "fail": ("#d11f1f", False, True),
    "secret": ("#666666", False, True),
}
CHAR_W = 6.0  # bold 10px Helvetica approx width per char
LINE_H = 13
LABEL_W = 150


def esc(s):
    return html.escape(str(s), quote=True)


class Rect:
    def __init__(self, x, y, w, h):
        self.x, self.y, self.w, self.h = x, y, w, h

    r = property(lambda s: s.x + s.w)
    b = property(lambda s: s.y + s.h)
    cx = property(lambda s: s.x + s.w / 2)
    cy = property(lambda s: s.y + s.h / 2)

    def grow(self, d):
        return Rect(self.x - d, self.y - d, self.w + 2 * d, self.h + 2 * d)

    def union(self, o):
        x, y = min(self.x, o.x), min(self.y, o.y)
        return Rect(x, y, max(self.r, o.r) - x, max(self.b, o.b) - y)


def seg_hits(p, q, rc):
    (x1, y1), (x2, y2) = p, q
    if abs(x1 - x2) < 0.5:
        if rc.x < x1 < rc.r:
            lo, hi = sorted((y1, y2))
            return min(hi, rc.b) - max(lo, rc.y) > 1
        return False
    if abs(y1 - y2) < 0.5:
        if rc.y < y1 < rc.b:
            lo, hi = sorted((x1, x2))
            return min(hi, rc.r) - max(lo, rc.x) > 1
        return False
    return False


def wrap_label(text, width=24):
    """Wrap an edge label on spaces so long labels do not need a long gap."""
    if not text:
        return []
    words, lines, cur = str(text).split(), [], ""
    for w in words:
        if cur and len(cur) + 1 + len(w) > width:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines


def icon_style(name, extra=""):
    spec = CAT["icons"].get(name) or CAT["container_badges"].get(name)
    if spec is None:
        raise SystemExit(f"unknown icon '{name}'. Allowed: {sorted(CAT['icons'])} + badges {sorted(CAT['container_badges'])}")
    base = "aspect=fixed;html=1;points=[];align=center;"
    if "lib" in spec:
        return spec, f"image;{base}image={spec['lib']};{extra}"
    if "shape" in spec:
        return spec, f"shape={spec['shape']};{base}fillColor={spec.get('fill', '#00BEF2')};strokeColor=none;{extra}"
    data = (HERE / "assets" / spec["asset"]).read_bytes()
    ext = spec["asset"].rsplit(".", 1)[-1]
    mime = {"png": "image/png", "jpg": "image/jpeg", "svg": "image/svg+xml"}[ext]
    # draw.io style syntax drops ';base64' (';' separates style keys)
    return spec, f"image;{base}image=data:{mime},{base64.b64encode(data).decode()};{extra}"


class Page:
    def __init__(self, spec):
        self.spec = spec
        self.name = spec["name"]
        self.px, self.py = spec.get("pitch", [200, 150])
        self.ox, self.oy = 120, 120
        self.cells = []
        self.n = 2
        self.nodes = {}
        self.conts = {}
        self.boxes = []  # obstacles for routing
        self.routed = []  # segments already routed (lane-sharing penalty)
        self.exits = []   # (node id, point) of every route start/end, to keep fan edges apart

    def nid(self):
        self.n += 1
        return f"c{self.n}"

    # ---------- layout ----------
    def label_lines(self, text):
        if not text:
            return 0
        lines = 0
        for part in str(text).split("\n"):
            lines += max(1, math.ceil(len(part) * CHAR_W / LABEL_W))
        return lines

    def autowiden(self):
        """Models choose grid cells; make sure the gap between two nodes is wide enough for the edge label,
        its step circles and the arrowheads, so label/marker overlaps cannot come from a tight grid."""
        nodes = {n["id"]: n for n in self.spec["nodes"]}

        def half(n):
            ic = CAT["icons"][n["icon"]]
            w = n.get("w", ic["w"])
            lab = max([len(x) for x in (str(n.get("label", "")).splitlines() + str(n.get("sub", "")).splitlines())] or [0])
            lw = min(LABEL_W, lab * CHAR_W + 8) if (n.get("label") or n.get("sub")) else 0
            return max(w, lw) / 2 + (18 if n.get("box") else 0)

        need_x = self.px
        for e in self.spec.get("edges", []):
            a, b = nodes.get(e["from"]), nodes.get(e["to"])
            if not a or not b:
                continue
            dcol = abs(b["col"] - a["col"])
            if dcol < 0.4:
                continue
            lab = wrap_label(e.get("label", ""))
            lw = max([len(x) for x in lab] or [0]) * 5.6 + 8
            steps = e.get("step")
            nst = 0 if steps is None else (len(steps) if isinstance(steps, list) else 1)
            need = max(lw, 0) + nst * 24 + 56
            need_x = max(need_x, (need + half(a) + half(b)) / dcol)
        self.px = min(need_x, 420)

    def place_nodes(self):
        self.autowiden()
        for nd in self.spec["nodes"]:
            ic, _ = icon_style(nd["icon"])
            w, h = nd.get("w", ic["w"]), nd.get("h", ic["h"])
            cx = self.ox + nd["col"] * self.px
            cy = self.oy + nd["row"] * self.py
            icon = Rect(cx - w / 2, cy - h / 2, w, h)
            text = nd.get("label", "")
            sub = nd.get("sub", "")
            nl = self.label_lines(text) + self.label_lines(sub)
            lab = None
            if nl:
                lw = min(LABEL_W, max(40, max((len(p) for p in (str(text) + "\n" + str(sub)).split("\n")), default=4) * CHAR_W + 8))
                lh = nl * LINE_H + 4
                if nd.get("labelpos") == "top":
                    lab = Rect(cx - lw / 2, icon.y - 4 - lh, lw, lh)
                else:
                    lab = Rect(cx - lw / 2, icon.b + 4, lw, lh)
            coll = icon.union(lab) if lab else icon
            anchor = icon
            box = None
            if nd.get("box"):
                box = coll.grow(18)
                anchor = box
                coll = box
            self.nodes[nd["id"]] = dict(spec=nd, icon=icon, label=lab, coll=coll, anchor=anchor, box=box,
                                        labelside="top" if nd.get("labelpos") == "top" else "bottom")

    def place_containers(self):
        order = self.spec.get("containers", [])
        for ct in order:  # inner containers must be listed before outer ones
            rects = []
            for m in ct["members"]:
                if m in self.nodes:
                    rects.append(self.nodes[m]["coll"])
                elif m in self.conts:
                    rects.append(self.conts[m]["rect"])
                else:
                    raise SystemExit(f"container '{ct['id']}': unknown member '{m}' (list inner containers first)")
            u = rects[0]
            for r in rects[1:]:
                u = u.union(r)
            pad = ct.get("pad", 26)
            top = ct.get("top", 40)
            rc = Rect(u.x - pad, u.y - top, u.w + 2 * pad, u.h + top + pad)
            self.conts[ct["id"]] = dict(spec=ct, rect=rc)

    # ---------- routing ----------
    def obstacles(self, a, b):
        obs = []
        for k, n in self.nodes.items():
            if k in (a, b):
                continue
            obs.append(n["coll"].grow(2))
        for c in self.conts.values():
            tr = self.title_rect(c)
            if tr.w > 0:
                obs.append(tr)
        return obs

    def title_rect(self, c):
        rc = c["rect"]
        label = str(c["spec"].get("label", ""))
        lines = label.split("\n") if label else [""]
        w = min(rc.w - 80, max(len(x) for x in lines) * 6.2 + 16) if label else 0
        return Rect(rc.x + 40, rc.y + 4, max(w, 0), 28)

    def title_bands(self):
        return [Rect(c["rect"].x, c["rect"].y, c["rect"].w, 26) for c in self.conts.values()]

    def spread(self, e):
        """fraction (0..1) along the anchor side for fan-out (source) / fan-in (target) edges."""
        edges = self.spec.get("edges", [])
        outs = [x for x in edges if x["from"] == e["from"]]
        ins = [x for x in edges if x["to"] == e["to"]]
        fs = (outs.index(e) + 1) / (len(outs) + 1) if len(outs) > 1 else 0.5
        ft = (ins.index(e) + 1) / (len(ins) + 1) if len(ins) > 1 else 0.5
        return fs, ft

    def route(self, e):
        """Orthogonal route between two anchors. Tries every allowed (exit side, entry side) pair and
        keeps the cheapest path that avoids other nodes' icon+label boxes. Icons that carry a label
        below them are never entered/left through their bottom (the label sits there)."""
        A, B = self.nodes[e["from"]], self.nodes[e["to"]]
        a, b = A["anchor"], B["anchor"]
        fs, ft = self.spread(e)
        obs = self.obstacles(e["from"], e["to"])
        bands = self.title_bands()

        def sides_ok(n):
            if n["label"] and not n["box"]:
                return tuple(x for x in ("left", "right", "top", "bottom") if x != n["labelside"])
            return ("left", "right", "top", "bottom")

        def pt(r, side, f):
            return {"left": (r.x, r.y + f * r.h), "right": (r.r, r.y + f * r.h),
                    "top": (r.x + f * r.w, r.y), "bottom": (r.x + f * r.w, r.b)}[side]

        def dir_ok(side, p, nxt, entering):
            dx, dy = nxt[0] - p[0], nxt[1] - p[1]
            if entering:  # nxt is the previous point; travel direction is p - nxt
                dx, dy = -dx, -dy
                need = {"left": dx > 0, "right": dx < 0, "top": dy > 0, "bottom": dy < 0}
            else:
                need = {"left": dx < 0, "right": dx > 0, "top": dy < 0, "bottom": dy > 0}
            return need[side] and (abs(dx) + abs(dy)) > 1

        if e.get("via"):
            p0 = pt(a, "right" if b.cx > a.r else "left" if b.cx < a.x else "bottom" if b.cy > a.b else "top", fs)
            p1 = pt(b, "left" if b.cx > a.r else "right" if b.cx < a.x else "top" if b.cy > a.b else "bottom", ft)
            return [p0] + [tuple(v) for v in e["via"]] + [p1], 0
        cands = []
        for s1 in sides_ok(A):
            for s2 in sides_ok(B):
                p0, p1 = pt(a, s1, fs), pt(b, s2, ft)
                h1, h2 = s1 in ("left", "right"), s2 in ("left", "right")
                offs = (0, 30, -30, 60, -60, 90, -90, 130, -130)
                shapes = []
                if h1 and h2:
                    if abs(p0[1] - p1[1]) < 2:
                        shapes.append([p0, p1])
                    for o in offs:
                        mx = (p0[0] + p1[0]) / 2 + o
                        shapes.append([p0, (mx, p0[1]), (mx, p1[1]), p1])
                elif not h1 and not h2:
                    if abs(p0[0] - p1[0]) < 2:
                        shapes.append([p0, p1])
                    for o in offs:
                        my = (p0[1] + p1[1]) / 2 + o
                        shapes.append([p0, (p0[0], my), (p1[0], my), p1])
                elif h1 and not h2:
                    shapes.append([p0, (p1[0], p0[1]), p1])
                else:
                    shapes.append([p0, (p0[0], p1[1]), p1])
                # wrap-around paths (leave top/bottom, travel clear of everything, come back in)
                for path in shapes:
                    if not dir_ok(s1, path[0], path[1], False) or not dir_ok(s2, path[-1], path[-2], True):
                        continue
                    pen = 0 if (s1, s2) in (("right", "left"), ("left", "right"), ("bottom", "top"), ("top", "bottom")) else 8
                    cands.append((path, pen))
        best, bs = None, 1e9
        for path, pen in cands:
            score = pen
            for s_, t_ in zip(path, path[1:]):
                for o in obs:
                    if seg_hits(s_, t_, o):
                        score += 1000
                for bd in bands:
                    if abs(s_[1] - t_[1]) < 1 and seg_hits(s_, t_, bd):
                        score += 60
                for (u, v) in self.routed:
                    if abs(s_[1] - t_[1]) < 1 and abs(u[1] - v[1]) < 1 and abs(s_[1] - u[1]) < 16:
                        if min(max(s_[0], t_[0]), max(u[0], v[0])) - max(min(s_[0], t_[0]), min(u[0], v[0])) > 30:
                            score += 90
                    if abs(s_[0] - t_[0]) < 1 and abs(u[0] - v[0]) < 1 and abs(s_[0] - u[0]) < 16:
                        if min(max(s_[1], t_[1]), max(u[1], v[1])) - max(min(s_[1], t_[1]), min(u[1], v[1])) > 30:
                            score += 40
                # running along a container border looks like a thick line - keep off it
                for c in self.conts.values():
                    cr = c["rect"]
                    for bx_ in (cr.x, cr.r):
                        if abs(s_[0] - t_[0]) < 1 and abs(s_[0] - bx_) < 7 and min(max(s_[1], t_[1]), cr.b) - max(min(s_[1], t_[1]), cr.y) > 20:
                            score += 50
                    for by_ in (cr.y, cr.b):
                        if abs(s_[1] - t_[1]) < 1 and abs(s_[1] - by_) < 7 and min(max(s_[0], t_[0]), cr.r) - max(min(s_[0], t_[0]), cr.x) > 20:
                            score += 50
                # own endpoints' label boxes
                for n in (A, B):
                    if n["label"] and n["label"] is not None:
                        lb = Rect(n["label"].x, n["label"].y, n["label"].w, n["label"].h)
                        if seg_hits(s_, t_, lb):
                            score += 1000
                score += (abs(s_[0] - t_[0]) + abs(s_[1] - t_[1])) * 0.02
            score += (len(path) - 2) * 3
            for (nid_, q) in self.exits:
                for end, nid2 in ((path[0], e["from"]), (path[-1], e["to"])):
                    if nid_ == nid2 and abs(end[0] - q[0]) + abs(end[1] - q[1]) < 22:
                        score += 35
            if score < bs:
                best, bs = path, score
        if bs >= 1000:  # every simple shape collides with something: route around obstacles properly
            hp, hc = self.hanan_route(a, b, A, B, obs, sides_ok(A), sides_ok(B), fs, ft)
            if hp and hc < 5000:
                return hp, hc
        return best, bs

    def hanan_route(self, a, b, A, B, obs, allowed_a, allowed_b, fs, ft):
        """Orthogonal shortest path on the grid formed by obstacle edges (visibility routing).
        Used when the simple candidate shapes all collide with something. Returns (path, cost) or (None, inf)."""
        import heapq

        def pt(r, side, f):
            return {"left": (r.x, r.y + f * r.h), "right": (r.r, r.y + f * r.h),
                    "top": (r.x + f * r.w, r.y), "bottom": (r.x + f * r.w, r.b)}[side]

        outward = {"left": (-1, 0), "right": (1, 0), "top": (0, -1), "bottom": (0, 1)}
        extra = list(obs)
        for n in (A, B):
            if n["label"] is not None:
                extra.append(Rect(n["label"].x, n["label"].y, n["label"].w, n["label"].h))
        best, bc = None, 1e18
        for s1 in allowed_a:
            for s2 in allowed_b:
                p0, p1 = pt(a, s1, fs), pt(b, s2, ft)
                xs = {round(p0[0], 1), round(p1[0], 1)}
                ys = {round(p0[1], 1), round(p1[1], 1)}
                for r in extra:
                    xs.update((round(r.x - 10, 1), round(r.r + 10, 1)))
                    ys.update((round(r.y - 10, 1), round(r.b + 10, 1)))
                for n in self.nodes.values():
                    xs.update((round(n["anchor"].x - 12, 1), round(n["anchor"].r + 12, 1)))
                    ys.update((round(n["anchor"].y - 12, 1), round(n["anchor"].b + 12, 1)))
                # corridors: midpoints between neighbouring grid lines
                xl, yl = sorted(xs), sorted(ys)
                xs.update(round((u + v) / 2, 1) for u, v in zip(xl, xl[1:]) if v - u > 24)
                ys.update(round((u + v) / 2, 1) for u, v in zip(yl, yl[1:]) if v - u > 24)
                xl, yl = sorted(xs), sorted(ys)
                xi = {v: i for i, v in enumerate(xl)}
                yi = {v: i for i, v in enumerate(yl)}
                start = (xi[round(p0[0], 1)], yi[round(p0[1], 1)])
                goal = (xi[round(p1[0], 1)], yi[round(p1[1], 1)])
                blocked_cache = {}

                def blocked(u, v):
                    key = (u, v)
                    if key in blocked_cache:
                        return blocked_cache[key]
                    P = (xl[u[0]], yl[u[1]])
                    Q = (xl[v[0]], yl[v[1]])
                    bad = any(seg_hits(P, Q, o) for o in extra)
                    blocked_cache[key] = bad
                    return bad

                def seg_cost(u, v):
                    P = (xl[u[0]], yl[u[1]])
                    Q = (xl[v[0]], yl[v[1]])
                    c = abs(P[0] - Q[0]) + abs(P[1] - Q[1])
                    for bd in self.title_bands():
                        if abs(P[1] - Q[1]) < 1 and seg_hits(P, Q, bd):
                            c += 80
                    for (u2, v2) in self.routed:
                        if abs(P[1] - Q[1]) < 1 and abs(u2[1] - v2[1]) < 1 and abs(P[1] - u2[1]) < 16:
                            if min(max(P[0], Q[0]), max(u2[0], v2[0])) - max(min(P[0], Q[0]), min(u2[0], v2[0])) > 12:
                                c += 70
                        if abs(P[0] - Q[0]) < 1 and abs(u2[0] - v2[0]) < 1 and abs(P[0] - u2[0]) < 16:
                            if min(max(P[1], Q[1]), max(u2[1], v2[1])) - max(min(P[1], Q[1]), min(u2[1], v2[1])) > 12:
                                c += 70
                    for ct in self.conts.values():
                        cr = ct["rect"]
                        for bx_ in (cr.x, cr.r):
                            if abs(P[0] - Q[0]) < 1 and abs(P[0] - bx_) < 7 and min(max(P[1], Q[1]), cr.b) - max(min(P[1], Q[1]), cr.y) > 12:
                                c += 60
                        for by_ in (cr.y, cr.b):
                            if abs(P[1] - Q[1]) < 1 and abs(P[1] - by_) < 7 and min(max(P[0], Q[0]), cr.r) - max(min(P[0], Q[0]), cr.x) > 12:
                                c += 60
                    return c

                od = outward[s1]
                idir = outward[s2]  # direction pointing OUT of the target; arrival direction is the opposite
                # state: (cell, dir) dir = (dx,dy) of last move
                pq = [(0.0, start, od, [start])]
                seen = {}
                found = None
                while pq:
                    cost, cell, d, path = heapq.heappop(pq)
                    if (cell, d) in seen and seen[(cell, d)] <= cost:
                        continue
                    seen[(cell, d)] = cost
                    if cell == goal and (d == (-idir[0], -idir[1]) or len(path) == 1 and False):
                        found = (cost, path)
                        break
                    for nd in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        if nd == (-d[0], -d[1]):
                            continue
                        if cell == start and len(path) == 1 and nd != od:
                            continue
                        nc = (cell[0] + nd[0], cell[1] + nd[1])
                        if not (0 <= nc[0] < len(xl) and 0 <= nc[1] < len(yl)):
                            continue
                        if blocked(cell, nc):
                            continue
                        step = seg_cost(cell, nc) + (45 if (nd != d and len(path) > 1) else 0)
                        heapq.heappush(pq, (cost + step, nc, nd, path + [nc]))
                if found and found[0] < bc:
                    bc = found[0]
                    pts = [(xl[c[0]], yl[c[1]]) for c in found[1]]
                    simp = [pts[0]]
                    for i in range(1, len(pts) - 1):
                        a_, b_, c_ = simp[-1], pts[i], pts[i + 1]
                        if (abs(a_[0] - b_[0]) < 0.5 and abs(b_[0] - c_[0]) < 0.5) or (abs(a_[1] - b_[1]) < 0.5 and abs(b_[1] - c_[1]) < 0.5):
                            continue
                        simp.append(b_)
                    simp.append(pts[-1])
                    best = simp
        return best, bc

    # ---------- emit ----------
    def add(self, xml):
        self.cells.append(xml)

    def vertex(self, value, style, r, parent="1"):
        i = self.nid()
        self.add(f'<mxCell id="{i}" value="{esc(value)}" style="{style}" vertex="1" parent="{parent}"><mxGeometry x="{r.x:.0f}" y="{r.y:.0f}" width="{r.w:.0f}" height="{r.h:.0f}" as="geometry"/></mxCell>')
        return i

    def text(self, value, r, color=MAGENTA, bold=True, size=10, align="center"):
        st = f"text;html=1;whiteSpace=wrap;align={align};verticalAlign=middle;fontSize={size};fontFamily=Helvetica;fontColor={color};{'fontStyle=1;' if bold else ''}labelBackgroundColor=none;rounded=0;"
        return self.vertex(value, st, r)

    def emit(self):
        sp = self.spec
        self.place_nodes()
        self.place_containers()
        out = {}
        # containers
        for ct in sp.get("containers", []):
            rc = self.conts[ct["id"]]["rect"]
            st = f"whiteSpace=wrap;html=1;fillColor=none;strokeColor={BLUE};strokeWidth=2;dashed=1;rounded=0;"
            i = self.vertex("", st, rc)
            out[ct["id"]] = i
            if ct.get("label"):
                self.text(ct["label"].replace("\n", "<br>"), self.title_rect(self.conts[ct["id"]]), size=10, align="left")
            if ct.get("badge"):
                bs, bst = icon_style(ct["badge"])
                self.vertex("", bst, Rect(rc.x - 6, rc.y - 12, bs["w"], bs["h"]))
        # node boxes (source/target systems keep the approved dashed box)
        for k, n in self.nodes.items():
            if n["box"]:
                self.vertex("", f"whiteSpace=wrap;html=1;fillColor=none;strokeColor={BLUE};strokeWidth=2;dashed=1;rounded=0;", n["box"])
        # edges (explicit waypoints so what the lint sees is what draw.io draws)
        idmap = {}
        for k, n in self.nodes.items():
            sp_, st = icon_style(n["spec"]["icon"], "verticalLabelPosition=bottom;verticalAlign=top;labelPosition=center;")
            idmap[k] = self.vertex("", st, n["icon"])
            if n["spec"].get("obs"):
                ic = n["icon"]
                self.vertex("", f"ellipse;whiteSpace=wrap;html=1;fillColor={DOT};strokeColor=none;aspect=fixed;", Rect(ic.r - 4, (ic.b - 2) if n["labelside"] == "top" else (ic.y - 8), 10, 10))
            if n["label"]:
                txt = "<br>".join(html.escape(x) for x in str(n["spec"].get("label", "")).split("\n"))
                if n["spec"].get("sub"):
                    subtxt = "<br>".join(html.escape(x) for x in str(n["spec"]["sub"]).split("\n"))
                    txt += '<br><font style="font-size:8px;font-weight:normal;color:#666666">' + subtxt + "</font>"
                self.vertex_raw(txt, n["label"], n["spec"].get("labelColor", MAGENTA), "bottom" if n["labelside"] == "top" else "top")
        routes = []
        for e in sp.get("edges", []):
            path, score = self.route(e)
            self.routed.extend(zip(path, path[1:]))
            self.exits += [(e["from"], path[0]), (e["to"], path[-1])]
            kind = e.get("kind", "flow")
            col, bidir, dashed = EDGE[kind]
            bidir = e.get("bidir", bidir)
            st = f"rounded=0;html=1;strokeColor={col};strokeWidth={e.get('width', 1.5)};endArrow=classic;{'startArrow=classic;' if bidir else ''}{'dashed=1;' if dashed else ''}jettySize=auto;"
            pts = "".join(f'<mxPoint x="{x:.0f}" y="{y:.0f}"/>' for x, y in path[1:-1])
            arr = f'<Array as="points">{pts}</Array>' if pts else ""
            i = self.nid()
            sx, sy = path[0]
            tx, ty = path[-1]
            A, B = self.nodes[e["from"]]["anchor"], self.nodes[e["to"]]["anchor"]
            ex = lambda r, p: (round((p[0] - r.x) / max(r.w, 1), 3), round((p[1] - r.y) / max(r.h, 1), 3))
            exx, exy = ex(A, path[0])
            enx, eny = ex(B, path[-1])
            src_id = idmap[e["from"]]
            dst_id = idmap[e["to"]]
            if self.nodes[e["from"]]["box"]:
                src_id = None
            if self.nodes[e["to"]]["box"]:
                dst_id = None
            st += f"exitX={exx};exitY={exy};entryX={enx};entryY={eny};"
            sp_xml = "" if src_id else '<mxPoint x="%d" y="%d" as="sourcePoint"/>' % (sx, sy)
            tp_xml = "" if dst_id else '<mxPoint x="%d" y="%d" as="targetPoint"/>' % (tx, ty)
            geo = '<mxGeometry relative="1" as="geometry">' + sp_xml + tp_xml + arr + '</mxGeometry>'
            srcattr = f' source="{src_id}"' if src_id else ""
            dstattr = f' target="{dst_id}"' if dst_id else ""
            self.add(f'<mxCell id="{i}" value="" style="{st}" edge="1" parent="1"{srcattr}{dstattr}>{geo}</mxCell>')
            routes.append((e, path, score))
        # edge labels + step markers: placed AFTER routing, each on the first free spot
        placed = [n["coll"] for n in self.nodes.values()]
        titles = [self.title_rect(c) for c in self.conts.values() if self.title_rect(c).w > 0]
        placed += titles
        for t in sp.get("texts", []):
            lw = max(60, len(t["text"]) * 6)
            placed.append(Rect(self.ox + t["col"] * self.px - lw / 2, self.oy + t["row"] * self.py - 10, lw, 20))
        allsegs = []
        for e, path, score in routes:
            allsegs += [(i, s_, t_) for i, (s_, t_) in enumerate(zip(path, path[1:]))]

        def overlap(r1, r2):
            return min(r1.r, r2.r) - max(r1.x, r2.x) > 0 and min(r1.b, r2.b) - max(r1.y, r2.y) > 0

        def straddles(r):
            for c in self.conts.values():
                cr = c["rect"]
                inside = r.x >= cr.x and r.r <= cr.r and r.y >= cr.y and r.b <= cr.b
                outside = r.r <= cr.x or r.x >= cr.r or r.b <= cr.y or r.y >= cr.b
                if not inside and not outside:
                    return True
            return False

        for e, path, score in routes:
            if not e.get("label"):
                continue
            lines_ = wrap_label(e["label"])
            lw, lh = max(len(x) for x in lines_) * 5.6 + 8, 14 * len(lines_) + 2
            own = list(zip(path, path[1:]))
            order = sorted(own, key=lambda sg: -(abs(sg[0][0] - sg[1][0]) + abs(sg[0][1] - sg[1][1])))
            cands = []
            for rank, (p, q) in enumerate(order):
                horiz = abs(p[1] - q[1]) < 1
                for fr in (0.5, 0.3, 0.7):
                    mx, my = p[0] + (q[0] - p[0]) * fr, p[1] + (q[1] - p[1]) * fr
                    if horiz:
                        cands += [(Rect(mx - lw / 2, my - lh - 3, lw, lh), rank), (Rect(mx - lw / 2, my + 3, lw, lh), rank)]
                    else:
                        cands += [(Rect(mx + 6, my - lh / 2, lw, lh), rank), (Rect(mx - 6 - lw, my - lh / 2, lw, lh), rank)]
            best, bc = None, 1e9
            for i, (r, rank) in enumerate(cands):
                cost = rank * 2 + i * 0.1
                for (idx, p, q) in allsegs:
                    if seg_hits(p, q, r) or (abs(p[1] - q[1]) < 1 and r.y < p[1] < r.b and min(max(p[0], q[0]), r.r) - max(min(p[0], q[0]), r.x) > 1):
                        cost += 1000
                for o in placed:
                    if overlap(r, o):
                        cost += 1000
                if straddles(r):
                    cost += 60
                if cost < bc:
                    best, bc = r, cost
            self.text("<br>".join(html.escape(x) for x in lines_), best, color="#000000", bold=False, size=10)
            placed.append(best)
        for e, path, score in routes:
            steps = e.get("step")
            if steps is None:
                continue
            steps = steps if isinstance(steps, list) else [steps]
            for k, stp in enumerate(steps):
                spot = None
                for (p, q) in zip(path, path[1:]):
                    d = math.hypot(q[0] - p[0], q[1] - p[1])
                    if d < 24:
                        continue
                    for off in (30, 56, 82, 108, 134, 20):
                        if off > d - 6:
                            continue
                        px, py = p[0] + (q[0] - p[0]) / d * off, p[1] + (q[1] - p[1]) / d * off
                        r = Rect(px - 10, py - 10, 20, 20)
                        if not any(overlap(r, o) for o in placed):
                            spot = (px, py, r)
                            break
                    if spot:
                        break
                if spot is None:
                    p, q = path[0], path[1]
                    d = math.hypot(q[0] - p[0], q[1] - p[1]) or 1
                    spot = (p[0] + (q[0] - p[0]) / d * 30, p[1] + (q[1] - p[1]) / d * 30, None)
                self.marker(stp, spot[0], spot[1])
                placed.append(Rect(spot[0] - 10, spot[1] - 10, 20, 20))
        for k, n in self.nodes.items():
            if n["spec"].get("step") is not None:
                ic = n["icon"]
                self.marker(n["spec"]["step"], ic.x - 6, ic.y - 6)
        for t in sp.get("texts", []):
            lw = max(60, len(t["text"]) * 6)
            cx = self.ox + t["col"] * self.px
            cy = self.oy + t["row"] * self.py
            self.text(t["text"], Rect(cx - lw / 2, cy - 10, lw, 20), size=10)
        self.routes = routes
        self.legend(routes)

    def legend(self, routes):
        """Legend (rule 2026-10-04): every icon-style page explains the conventions it actually uses. Off with spec "legend": false;
        skipped when the page already has a legend-success-fail icon."""
        sp = self.spec
        if sp.get("legend") is False or any(n["spec"].get("icon") == "legend-success-fail" for n in self.nodes.values()):
            return
        kinds = {e.get("kind", "flow") for e in sp.get("edges", [])}
        rows = []
        if any(n["spec"].get("obs") for n in self.nodes.values()):
            rows.append(("dot", "SMC observation point (component writes SMC observations)"))
        if "sync" in kinds:
            rows.append(("sync", "Synchronous request / reply (HTTPS)"))
        if "flow" in kinds:
            rows.append(("flow", "One-way flow / data movement"))
        if "smc" in kinds:
            rows.append(("smc", "Logging to SMC (observations)"))
        if "fail" in kinds:
            rows.append(("fail", "Failure / error path"))
        if "secret" in kinds:
            rows.append(("secret", "Secret / configuration read (Key Vault)"))
        if any(e.get("step") is not None for e in sp.get("edges", [])) or any(n["spec"].get("step") is not None for n in self.nodes.values()):
            rows.append(("step", "Step number (see TSD 5.x.2.1)"))
        if not rows:
            return
        rects = [n["coll"] for n in self.nodes.values()] + [c["rect"] for c in self.conts.values()]
        x0 = min(r.x for r in rects)
        y0 = max(r.b for r in rects) + 36
        w, h = 330, 22 + 20 * len(rows)
        orig_nid, cnt = self.nid, [0]

        def legend_id():
            cnt[0] += 1
            return f"legend-{cnt[0]}"

        self.nid = legend_id
        try:
            self._draw_legend(rows, x0, y0, w, h)
        finally:
            self.nid = orig_nid

    def _draw_legend(self, rows, x0, y0, w, h):
        self.vertex("", "rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#999999;strokeWidth=1;", Rect(x0, y0, w, h))
        self.text("Legend", Rect(x0 + 8, y0 + 2, 60, 18), color="#000000", size=10, align="left")
        for k, (kind, txt) in enumerate(rows):
            cy = y0 + 30 + 20 * k
            if kind == "dot":
                self.vertex("", f"ellipse;whiteSpace=wrap;html=1;fillColor={DOT};strokeColor=none;aspect=fixed;", Rect(x0 + 18, cy - 5, 10, 10))
            elif kind == "step":
                self.marker("1", x0 + 24, cy)
            else:
                col, bidir, dashed = EDGE[kind]
                st = f"rounded=0;html=1;strokeColor={col};strokeWidth=1.5;endArrow=classic;{'startArrow=classic;' if bidir else ''}{'dashed=1;' if dashed else ''}"
                self.add(f'<mxCell id="{self.nid()}" value="" style="{st}" edge="1" parent="1"><mxGeometry relative="1" as="geometry"><mxPoint x="{x0 + 8:.0f}" y="{cy:.0f}" as="sourcePoint"/><mxPoint x="{x0 + 42:.0f}" y="{cy:.0f}" as="targetPoint"/></mxGeometry></mxCell>')
            self.text(txt, Rect(x0 + 52, cy - 9, w - 60, 18), color="#000000", bold=False, size=10, align="left")

    def marker(self, num, cx, cy):
        self.vertex(str(num), f"ellipse;whiteSpace=wrap;html=1;aspect=fixed;fillColor={MARK};strokeColor=none;fontColor=#FFFFFF;fontSize=10;fontStyle=1;fontFamily=Helvetica;spacingTop=2;spacingLeft=2;", Rect(cx - 10, cy - 10, 20, 20))

    def vertex_raw(self, html_value, r, color, valign="top"):
        st = f"text;html=1;whiteSpace=wrap;align=center;verticalAlign={valign};fontSize=10;fontFamily=Helvetica;fontColor={color};fontStyle=1;labelBackgroundColor=none;rounded=0;spacing=0;"
        i = self.nid()
        self.add(f'<mxCell id="{i}" value="{html.escape(html_value, quote=True)}" style="{st}" vertex="1" parent="1"><mxGeometry x="{r.x:.0f}" y="{r.y:.0f}" width="{r.w:.0f}" height="{r.h:.0f}" as="geometry"/></mxCell>')

    def xml(self):
        self.emit()
        body = "".join(self.cells)
        return (f'<diagram name="{esc(self.name)}" id="{esc(self.name.replace(" ", "-"))}"><mxGraphModel dx="1400" dy="900" grid="0" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="0" pageScale="1" pageWidth="1600" pageHeight="1000" math="0" shadow="0"><root><mxCell id="0"/><mxCell id="1" parent="0"/>{body}</root></mxGraphModel></diagram>')


def build(spec_path, out_path):
    return build_from_dict(json.loads(Path(spec_path).read_text(encoding="utf-8-sig")), out_path)


def normalize_page(p):
    """Models write `texts` as plain strings or `{text,col,row}`; accept both."""
    top = min([n.get("row", 0) for n in p.get("nodes", [])] or [0])
    fixed = []
    for i, t in enumerate(p.get("texts", []) or []):
        if isinstance(t, str):
            t = {"text": t, "col": 0.3, "row": top - 0.7 + 0.3 * i}
        fixed.append(t)
    p["texts"] = fixed
    return p


def build_from_dict(spec, out_path):
    pages = spec["pages"] if "pages" in spec else [spec]
    pages = [normalize_page(p) for p in pages]
    xml = '<?xml version="1.0" encoding="UTF-8"?><mxfile host="metcash-tsd-generator">' + "".join(Page(p).xml() for p in pages) + "</mxfile>"
    Path(out_path).write_text(xml, encoding="utf-8")
    return out_path


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    print(build(sys.argv[1], sys.argv[2]))
