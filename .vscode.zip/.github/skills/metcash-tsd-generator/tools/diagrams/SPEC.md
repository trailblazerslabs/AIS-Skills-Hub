# Diagram spec reference

`python build_drawio.py spec.json out.drawio` -> `python lint_drawio.py out.drawio --steps N` -> `python render_drawio.py out.drawio outdir`

| Key | Meaning |
|---|---|
| `pages[].name` | Page name. Use the corpus names: `{EAII-nnn} Process Flow`, `Architecture Diagram`, `Network Diagram`, `Communication Diagram` |
| `pitch` | `[colWidth,rowHeight]` grid pitch in px (default 200x150) |
| `nodes[]` | `id`, `icon` (icons.json), `label` (magenta resource name), `sub` (grey small second line), `col`,`row`, `box` (dashed box for external systems), `obs` (dark-red SMC observation dot), `step` (blue number on the node) |
| `containers[]` | `id`, `label`, `members` (node ids or INNER container ids - list inner first), `badge` (resource-group, subscription, vnet, subnet, workflow, azure, apim), `pad`, `top` |
| `edges[]` | `from`,`to`, `kind` (`flow` black, `sync` green two-way, `smc` red, `fail` red dashed, `secret` grey dashed), `label`, `step` (N or [N,M]), `via` (manual waypoints, rarely needed) |
| `texts[]` | free text such as `{env} - dv1, st1, ut1, prd` |

Rules the builder enforces so the output matches the approved corpus: only icons from `icons.json`; dashed `#0066CC` 2px containers;
magenta `#ce3bae` bold 10px resource names; blue `#2395FF` step circles; `#990000` observation dots; edges routed orthogonally around
icons, labels and container titles; labelled icons are never entered through their bottom (the label sits there); fan-in/fan-out edges
get separate lanes. Keep an external system at least one grid column away from the nearest container border when its edge has a label.

## Layout lessons (EAII-536..541)

* **Page width is set by the longest edge label per grid column.** `autowiden` widens the pitch (up to 420 px) until the longest
  label fits between its two nodes, so one long label stretches the whole page. Keep edge labels to about 25 characters
  ("publish once + Route*", "write file(s)") and move detail into the TSD text.
* **More than about 9 columns: snake the process flow into two rows.** Upper row left to right (source, gateway, APIM, topic,
  subscription), lower row for the workflow, storage and delivery systems. A single 15-column row renders 7,500 px wide and is
  unreadable in Word; the two-row layout is about 4,400 px.
* **Keep `sub` short (about 35 characters) on nodes that carry a step marker or the dark-red observation dot.** A long second line
  makes the label tall and the marker lands on it (`marker-on-label`).
* **Put external systems and delivery steps outside the main container's rows.** The container box is the bounding box of its
  members plus anything laid out inside it; a system placed between member rows ends up drawn inside the container.
* **Fan out vertically, not along one lane.** Several private endpoints to the same resource are clearer as a column next to the
  caller than as a row (avoids `edges-share-lane`).
* **Give every resource a unique label.** Two private endpoints for one storage account need distinct names (`...-pe-blob`,
  `...-pe-table`), otherwise the diagram implies one resource.
* Known linter false positive: `marker-on-label` against a short container title (for example `AIS`) when step 2 sits next to the
  left edge of the container; check the render, and shift the first node about 0.7 column right if the circle touches the title.

## Simple process flow (section 5.x.2.2)

The process-flow page is **not** built with `build_drawio.py`. Use `build_simple_flow.py spec.json out.drawio`, then `render_drawio.py`.
Style of the approved EAII-374 process diagram: title + subtitle, coloured rounded boxes, nested boxes for APIM and the Logic App with their
operations/actions listed inside, labelled arrows (two-way for HTTPS). No icons, no step circles, no containers, no legend.
Node kinds: `source`, `gateway`, `apim`, `bus`, `logic`, `store`, `lookup`, `mft`, `target`. Position = node centre `(col*pitch_x, row*pitch_y)`;
a node with `children` becomes a container. See `specs/EAII-538.simple-process.sample.json` and its PNG. Limits: titles 28 characters, lines 34, edge labels 22.
The layout lessons above apply to the icon-style pages only.
