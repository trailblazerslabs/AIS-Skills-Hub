#!/usr/bin/env python3
"""Geometric lint for TSD .drawio diagrams (works on approved files and model output alike).

Why: inspect_drawio.py only proves the XML parses. The defects seen in generated diagrams
(edges running through icons, step markers sitting on labels, containers cutting through
icons, mojibake, external icon URLs, step-count drift) are geometric, so they are checked here.

Usage:
  python lint_drawio.py <file.drawio> [--steps N] [--json] [--page NAME]
Exit code 0 = no errors (warnings allowed), 1 = errors found.
Score = 100 - 10*errors - 2*warnings (floor 0); printed per page.
"""
import argparse, base64, json, re, sys, urllib.parse, zlib
import xml.etree.ElementTree as ET
from pathlib import Path

HERE = Path(__file__).parent
MOJI = re.compile(r"(Ã.|â€|Ô[ÇÉ]|�)")
NUM = re.compile(r"^\d{1,2}$")


def model(dg):
    m = dg.find("mxGraphModel")
    if m is not None:
        return m
    raw = zlib.decompress(base64.b64decode((dg.text or "").strip()), -15)
    return ET.fromstring(urllib.parse.unquote(raw.decode("utf-8")))


def style_of(s):
    d = {}
    for part in (s or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            d[k] = v
        elif part:
            d.setdefault("_f", []).append(part)
    return d


def strip(v):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", v or "")).strip()


class R:
    def __init__(self, x, y, w, h):
        self.x, self.y, self.w, self.h = x, y, w, h

    @property
    def r(self):
        return self.x + self.w

    @property
    def b(self):
        return self.y + self.h

    @property
    def c(self):
        return (self.x + self.w / 2, self.y + self.h / 2)

    def inter(self, o):
        iw = min(self.r, o.r) - max(self.x, o.x)
        ih = min(self.b, o.b) - max(self.y, o.y)
        return max(iw, 0) * max(ih, 0)

    def area(self):
        return self.w * self.h

    def contains(self, o, tol=1):
        return o.x >= self.x - tol and o.y >= self.y - tol and o.r <= self.r + tol and o.b <= self.b + tol

    def shrink(self, d):
        return R(self.x + d, self.y + d, max(self.w - 2 * d, 1), max(self.h - 2 * d, 1))


def seg_hits(p, q, rect):
    """axis-aligned segment p->q vs rect interior."""
    x1, y1 = p
    x2, y2 = q
    if abs(x1 - x2) < 0.5:  # vertical
        if rect.x < x1 < rect.r:
            lo, hi = sorted((y1, y2))
            return min(hi, rect.b) - max(lo, rect.y) > 1
        return False
    if abs(y1 - y2) < 0.5:  # horizontal
        if rect.y < y1 < rect.b:
            lo, hi = sorted((x1, x2))
            return min(hi, rect.r) - max(lo, rect.x) > 1
        return False
    # diagonal: sample
    n = 20
    for i in range(n + 1):
        t = i / n
        x, y = x1 + (x2 - x1) * t, y1 + (y2 - y1) * t
        if rect.x < x < rect.r and rect.y < y < rect.b:
            return True
    return False


def load_catalog():
    try:
        j = json.loads((HERE / "icons.json").read_text(encoding="utf-8"))
    except Exception:
        return set(), set()
    libs = set()
    for sect in ("icons", "container_badges"):
        for v in j.get(sect, {}).values():
            if "lib" in v:
                libs.add(v["lib"])
            libs.update(v.get("alt_libs", []))
    return libs, set()


def lint_page(name, m, steps=None):
    cells = {}
    for c in m.iter("mxCell"):
        cells[c.get("id")] = c
    V, E = {}, []
    for cid, c in cells.items():
        if str(cid).startswith("legend-"):
            continue  # the generated legend explains conventions; it is not part of the diagram geometry
        st = style_of(c.get("style"))
        g = c.find("mxGeometry")
        if c.get("vertex") == "1" and g is not None and g.get("width"):
            rect = R(float(g.get("x", 0)), float(g.get("y", 0)), float(g.get("width")), float(g.get("height")))
            # resolve parent offset (one level is enough for corpus files)
            par = c.get("parent")
            if par and par in cells and cells[par].get("vertex") == "1":
                pg = cells[par].find("mxGeometry")
                if pg is not None:
                    rect.x += float(pg.get("x", 0))
                    rect.y += float(pg.get("y", 0))
            label = strip(c.get("value"))
            img = st.get("image", "")
            isc = st.get("dashed") == "1" and st.get("fillColor", "none") in ("none", "") and "text" not in st.get("_f", []) and rect.w > 90 and rect.h > 60 and not img
            ismark = "ellipse" in st.get("_f", []) and rect.w <= 26 and rect.h <= 26
            istext = "text" in st.get("_f", []) or (not img and not st.get("shape") and not isc and not ismark and st.get("fillColor", "none") in ("none", "default") and st.get("strokeColor") == "none")
            kind = "container" if isc else "marker" if ismark else "text" if istext else "icon" if (img or st.get("shape")) else "box"
            V[cid] = dict(id=cid, rect=rect, label=label, st=st, kind=kind, img=img, raw=c.get("value") or "")
        elif c.get("edge") == "1":
            E.append((cid, c, st))

    out = []

    def add(sev, code, msg):
        out.append((sev, code, msg))

    # containment-based container detection: any box-like vertex that fully encloses another
    # non-text vertex is a container (covers filled zone boxes and dashed boxes alike)
    for v in V.values():
        if v["kind"] in ("box", "text") and v["rect"].w > 90 and v["rect"].h > 60 and not v["img"]:
            inside = [o for o in V.values() if o is not v and o["kind"] in ("icon", "box") and o["rect"].area() < v["rect"].area() * 0.9 and v["rect"].contains(o["rect"], 2)]
            if inside and (v["kind"] == "box" or v["st"].get("dashed") == "1"):
                v["kind"] = "container"
    solid = [v for v in V.values() if v["kind"] in ("icon", "text", "box") and (v["label"] or v["kind"] != "text")]
    conts = [v for v in V.values() if v["kind"] == "container"]
    marks = [v for v in V.values() if v["kind"] == "marker" and NUM.match(v["label"] or "")]
    dots = [v for v in V.values() if v["kind"] == "marker" and not (v["label"] or "").strip()]

    # L7 mojibake, L8 external urls, L9 catalog
    libs, _ = load_catalog()
    for v in V.values():
        if MOJI.search(v["raw"]):
            add("error", "mojibake", f"garbled text in '{v['label'][:40]}'")
        img = v["img"]
        if img.startswith("http"):
            add("error", "external-icon", f"external image URL on '{v['label'][:30] or v['id']}': {img[:60]}")
        elif img and not img.startswith("data") and libs and img not in libs:
            add("warn", "icon-not-in-catalog", f"{img} is not in tools/diagrams/icons.json")

    # edge geometry
    def anchor(cell, side):
        tid = cell.get(side)
        if tid in V:
            return V[tid]
        return None

    epaths = []
    for cid, c, st in E:
        s, t = anchor(c, "source"), anchor(c, "target")
        g = c.find("mxGeometry")
        pts = []
        if g is not None:
            arr = g.find("Array")
            if arr is not None:
                pts = [(float(p.get("x", 0)), float(p.get("y", 0))) for p in arr.findall("mxPoint")]
        sp = tp = None
        if g is not None:
            for p in g.findall("mxPoint"):
                if p.get("as") == "sourcePoint":
                    sp = (float(p.get("x", 0)), float(p.get("y", 0)))
                if p.get("as") == "targetPoint":
                    tp = (float(p.get("x", 0)), float(p.get("y", 0)))
        if s is None and sp is None or t is None and tp is None:
            continue

        def pt(v, st_, side, other):
            if v is None:
                return None
            r = v["rect"]
            ex, ey = st_.get(f"{'exit' if side == 's' else 'entry'}X"), st_.get(f"{'exit' if side == 's' else 'entry'}Y")
            if ex is not None and ey is not None:
                return (r.x + float(ex) * r.w, r.y + float(ey) * r.h)
            ox, oy = other
            cx, cy = r.c
            if abs(ox - cx) / max(r.w, 1) >= abs(oy - cy) / max(r.h, 1):
                return (r.r if ox > cx else r.x, cy)
            return (cx, r.b if oy > cy else r.y)

        sc = s["rect"].c if s else sp
        tc = t["rect"].c if t else tp
        first = pts[0] if pts else tc
        last = pts[-1] if pts else sc
        p0 = pt(s, st, "s", first) if s else sp
        p1 = pt(t, st, "t", last) if t else tp
        path = [p0] + pts + [p1]
        if not pts and p0 and p1 and abs(p0[0] - p1[0]) > 1 and abs(p0[1] - p1[1]) > 1 and "orthogonal" in st.get("edgeStyle", "") + st.get("edgeStyle", ""):
            mx = (p0[0] + p1[0]) / 2
            path = [p0, (mx, p0[1]), (mx, p1[1]), p1]
        epaths.append((cid, c, s, t, path))

    # L1/L11 edge through node / label
    for cid, c, s, t, path in epaths:
        for a, b in zip(path, path[1:]):
            for v in solid:
                if (s and v["id"] == s["id"]) or (t and v["id"] == t["id"]):
                    continue
                if v["kind"] == "icon" and v["rect"].w < 8:
                    continue
                if seg_hits(a, b, v["rect"].shrink(2)):
                    add("error", "edge-through-node", f"edge {cid} crosses '{v['label'][:30] or v['id']}'")
                    break
            else:
                continue
            break
        # container label band hit (top 24px) - edge running along a container title
        for ct in conts:
            band = R(ct["rect"].x, ct["rect"].y, ct["rect"].w, 22)
            if any(seg_hits(a, b, band.shrink(1)) and abs(a[1] - b[1]) < 1 for a, b in zip(path, path[1:])):
                add("warn", "edge-along-container-title", f"edge {cid} runs along the title band of '{ct['label'][:30] or ct['id']}'")
                break

    # L3 overlaps among visible things
    items = [v for v in V.values() if v["kind"] in ("icon", "text", "box", "marker") and (v["label"] or v["kind"] in ("icon", "box") or v["kind"] == "marker")]
    seen = set()
    for i, a in enumerate(items):
        for b in items[i + 1:]:
            ia = a["rect"].inter(b["rect"])
            if ia <= 0:
                continue
            small = min(a["rect"].area(), b["rect"].area())
            if small <= 0:
                continue
            frac = ia / small
            kinds = {a["kind"], b["kind"]}
            if "box" in kinds and kinds != {"box"}:
                # text inside its own box is normal
                big, sm = (a, b) if a["kind"] == "box" else (b, a)
                if big["rect"].contains(sm["rect"], 2):
                    continue
            if kinds == {"marker"}:
                if frac > 0.1:
                    add("error", "marker-overlap", f"markers '{a['label']}' and '{b['label']}' overlap")
                continue
            if "marker" in kinds:
                other = b if a["kind"] == "marker" else a
                if other["kind"] == "text" and frac > 0.25:
                    add("error", "marker-on-label", f"step marker overlaps label '{other['label'][:30]}'")
                continue
            if frac > 0.2 and (a["id"], b["id"]) not in seen:
                seen.add((a["id"], b["id"]))
                add("error" if frac > 0.5 else "warn", "overlap", f"'{(a['label'] or a['id'])[:25]}' overlaps '{(b['label'] or b['id'])[:25]}' ({int(frac*100)}%)")

    # L4 container enclosure: a container border cutting through a non-container thing
    for ct in conts:
        cr = ct["rect"]
        for v in solid + marks:
            vr = v["rect"]
            if vr.area() == 0 or vr.area() > cr.area() * 0.5:
                continue
            ia = cr.inter(vr)
            if 0.05 * vr.area() < ia < 0.95 * vr.area():
                # straddles the border (partly in, partly out)
                inner = cr.shrink(3)
                if not (inner.inter(vr) >= 0.95 * vr.area()) and ia > 0:
                    # ignore badge-like small items hugging the corner (container badge icons)
                    if v["kind"] == "icon" and vr.w <= 56 and any(abs(vr.c[0] - cx_) < 40 and abs(vr.c[1] - cy_) < 40 for cx_ in (cr.x, cr.r) for cy_ in (cr.y, cr.b)):
                        continue  # container badge icons straddle the corner by design
                    add("warn", "container-border-cuts", f"container '{ct['label'][:25] or ct['id']}' border cuts '{v['label'][:25] or v['id']}'")

    # L10 step markers
    nums = sorted(int(v["label"]) for v in marks)
    if nums:
        if nums != list(range(1, len(nums) + 1)):
            add("error", "marker-sequence", f"step markers are {nums}, expected 1..{len(nums)} with no gaps/duplicates")
        if steps is not None and len(nums) != steps:
            add("error", "marker-count", f"{len(nums)} step markers but TSD 5.x.2.1 has {steps} steps")
    elif steps is not None and any(v["kind"] == "marker" for v in V.values()) is False:
        pass

    # L12 collinear shared lanes
    segs = []
    for cid, c, s, t, path in epaths:
        for a, b in zip(path, path[1:]):
            segs.append((cid, a, b))
    for i, (c1, a1, b1) in enumerate(segs):
        for c2, a2, b2 in segs[i + 1:]:
            if c1 == c2:
                continue
            if abs(a1[1] - b1[1]) < 1 and abs(a2[1] - b2[1]) < 1 and abs(a1[1] - a2[1]) < 14:
                ov = min(max(a1[0], b1[0]), max(a2[0], b2[0])) - max(min(a1[0], b1[0]), min(a2[0], b2[0]))
                if ov > 40:
                    add("warn", "edges-share-lane", f"edges {c1} and {c2} overlap on the same horizontal lane for {int(ov)}px")
            if abs(a1[0] - b1[0]) < 1 and abs(a2[0] - b2[0]) < 1 and abs(a1[0] - a2[0]) < 14:
                ov = min(max(a1[1], b1[1]), max(a2[1], b2[1])) - max(min(a1[1], b1[1]), min(a2[1], b2[1]))
                if ov > 40:
                    add("warn", "edges-share-lane", f"edges {c1} and {c2} overlap on the same vertical lane for {int(ov)}px")

    ends = {cid: {s["id"] if s else None, t["id"] if t else None} for cid, c, s, t, path in epaths}
    crossed = set()
    for i, (c1, a1, b1) in enumerate(segs):
        for c2, a2, b2 in segs[i + 1:]:
            if c1 == c2 or (ends[c1] & ends[c2] - {None}) or (c1, c2) in crossed:
                continue
            h1, v1 = abs(a1[1] - b1[1]) < 1, abs(a1[0] - b1[0]) < 1
            h2, v2 = abs(a2[1] - b2[1]) < 1, abs(a2[0] - b2[0]) < 1
            if h1 and v2:
                hy, hx = a1[1], sorted((a1[0], b1[0])); vx, vy = a2[0], sorted((a2[1], b2[1]))
            elif v1 and h2:
                hy, hx = a2[1], sorted((a2[0], b2[0])); vx, vy = a1[0], sorted((a1[1], b1[1]))
            else:
                continue
            if hx[0] + 3 < vx < hx[1] - 3 and vy[0] + 3 < hy < vy[1] - 3:
                crossed.add((c1, c2))
                add("warn", "edges-cross", f"edges {c1} and {c2} cross each other")

    # dedupe messages
    uniq, seenm = [], set()
    for o in out:
        if o[2] not in seenm:
            seenm.add(o[2])
            uniq.append(o)
    stats = dict(vertices=len(V), edges=len(E), containers=len(conts), markers=len(marks), obs_dots=len(dots))
    return uniq, stats


def lint_file(path, steps=None, page=None):
    root = ET.parse(path).getroot()
    res = []
    for dg in root.iter("diagram"):
        if page and dg.get("name") != page:
            continue
        issues, stats = lint_page(dg.get("name"), model(dg), steps)
        errs = sum(1 for i in issues if i[0] == "error")
        warns = sum(1 for i in issues if i[0] == "warn")
        res.append(dict(page=dg.get("name"), errors=errs, warnings=warns, score=max(0, 100 - 10 * errs - 2 * warns), stats=stats, issues=issues))
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--steps", type=int)
    ap.add_argument("--page")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    res = lint_file(a.file, a.steps, a.page)
    if a.json:
        print(json.dumps(res, indent=1))
    else:
        for r in res:
            print(f"[{r['page']}] score={r['score']} errors={r['errors']} warnings={r['warnings']} {r['stats']}")
            for sev, code, msg in r["issues"]:
                print(f"   {sev.upper():5} {code}: {msg}")
    sys.exit(1 if any(r["errors"] for r in res) else 0)
