#!/usr/bin/env python3
"""Render every page of a .drawio to PNG using the draw.io desktop CLI (no browser needed).

Verified on the approved corpus files: the desktop CLI renders both bundled `img/lib/...` icons and
embedded data-URI images correctly, so the generated diagrams (which use only icons.json entries)
render identically here and in app.diagrams.net.

Usage:
  python render_drawio.py <file.drawio> <outdir> [--scale 2] [--prefix 01]
  python render_drawio.py --icon-test <outdir>     # renders every catalog icon on one page
"""
import argparse, json, re, subprocess, sys, xml.etree.ElementTree as ET
from pathlib import Path

HERE = Path(__file__).parent
EXE_CANDIDATES = [r"C:\Program Files\draw.io\draw.io.exe", "/c/Program Files/draw.io/draw.io.exe", "drawio", "draw.io"]


def find_exe():
    for c in EXE_CANDIDATES:
        if Path(c).exists():
            return c
    sys.exit("draw.io desktop CLI not found. Per the skill's tooling hard-stop rule, ask the user before installing anything.")


def render(drawio, outdir, scale=2, prefix=""):
    exe = find_exe()
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    names = [d.get("name") for d in ET.parse(drawio).getroot().iter("diagram")]
    outs = []
    for i, n in enumerate(names):
        slug = re.sub(r"[^A-Za-z0-9]+", "-", n).strip("-")
        out = outdir / f"{prefix}{i + 1:02d}-{slug}.png"
        r = subprocess.run([exe, "-x", "-f", "png", "-s", str(scale), "-b", "20", "-p", str(i), "-o", str(out), str(drawio)], capture_output=True, text=True, timeout=180)
        if not out.exists():
            print(f"FAILED page {i + 1} {n}: {r.stderr[:200]}", file=sys.stderr)
        else:
            outs.append(out)
    return outs


def icon_test(outdir):
    sys.path.insert(0, str(HERE))
    import build_drawio as b
    cat = json.loads((HERE / "icons.json").read_text(encoding="utf-8"))
    names = list(cat["icons"]) + [("badge:" + k) for k in cat["container_badges"]]
    nodes = []
    for i, n in enumerate(names):
        nodes.append({"id": f"n{i}", "icon": n.replace("badge:", ""), "label": n, "col": i % 6, "row": i // 6})
    spec = {"name": "Icon test", "pitch": [190, 110], "nodes": nodes}
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    f = out / "icon-test.drawio"
    b.build_from_dict(spec, f)
    return render(f, out, prefix="icons-")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("a", nargs="?")
    ap.add_argument("b", nargs="?")
    ap.add_argument("--scale", type=int, default=2)
    ap.add_argument("--prefix", default="")
    ap.add_argument("--icon-test", action="store_true")
    x = ap.parse_args()
    if x.icon_test:
        print("\n".join(map(str, icon_test(x.a or "icon-test-out"))))
    else:
        if not (x.a and x.b):
            sys.exit(__doc__)
        print("\n".join(map(str, render(x.a, x.b, x.scale, x.prefix))))
