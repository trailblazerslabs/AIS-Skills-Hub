param(
    [Parameter(Mandatory = $true)][string]$DocumentPath,
    [Parameter(Mandatory = $true)][string]$DiagramPath
)

$word = $null
$document = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $document = $word.Documents.Open((Resolve-Path $DocumentPath).Path, $false, $false, $false)

    $diagramParagraph = $null
    foreach ($paragraph in $document.Paragraphs) {
        if ($paragraph.Range.Text.Contains([System.IO.Path]::GetFileName($DiagramPath))) {
            $diagramParagraph = $paragraph
            break
        }
    }
    if ($null -eq $diagramParagraph) {
        throw 'Could not find the §11 diagram source link in the Word document.'
    }

    $position = $diagramParagraph.Range.End - 1
    $document.Range($position, $position).InsertAfter([string][char]13)
    $anchor = $document.Range($position + 1, $position + 1)
    $label = [System.IO.Path]::GetFileName($DiagramPath)
    $embedded = $document.InlineShapes.AddOLEObject(
        'Package', (Resolve-Path $DiagramPath).Path, $false, $true, '', 0, $label, $anchor
    )
    if ($embedded.Type -ne 1 -or $embedded.OLEFormat.ClassType -ne 'Package') {
        throw 'The editable diagram was not inserted as an embedded packaged object.'
    }

    $document.Save()
    "Embedded packaged diagram object under §11: $label"
}
finally {
    if ($null -ne $document) {
        $document.Close(0)
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($document) | Out-Null
    }
    if ($null -ne $word) {
        $word.Quit()
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
    }
}