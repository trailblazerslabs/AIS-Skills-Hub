"""Check DOCX package integrity and Word structures affected by TSD post-processing."""

import argparse
import posixpath
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote
from zipfile import BadZipFile, ZipFile


WORD = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
DRAWING = "http://schemas.openxmlformats.org/drawingml/2006/main"
TABLE_ORDER = (
    "tblStyle", "tblpPr", "tblOverlap", "bidiVisual", "tblStyleRowBandSize",
    "tblStyleColBandSize", "tblW", "jc", "tblCellSpacing", "tblInd", "tblBorders",
    "shd", "tblLayout", "tblCellMar", "tblLook", "tblCaption", "tblDescription",
    "tblPrChange",
)


def word_tag(name):
    return f"{{{WORD}}}{name}"


def validate(path, expected_images=None):
    errors = []
    try:
        with ZipFile(path) as archive:
            bad_part = archive.testzip()
            if bad_part:
                errors.append(f"ZIP CRC failure: {bad_part}")
            names = set(archive.namelist())
            for required in ("[Content_Types].xml", "_rels/.rels", "word/document.xml"):
                if required not in names:
                    errors.append(f"Missing required part: {required}")
            for name in sorted(names):
                if not name.endswith((".xml", ".rels")):
                    continue
                try:
                    root = ET.fromstring(archive.read(name))
                except ET.ParseError as error:
                    errors.append(f"Malformed XML {name}: {error}")
                    continue
                if name.endswith(".rels"):
                    base = posixpath.dirname(posixpath.dirname(name))
                    for relationship in root:
                        if relationship.get("TargetMode") == "External":
                            continue
                        target = unquote(relationship.get("Target", "").split("#", 1)[0])
                        if not target:
                            continue
                        resolved = posixpath.normpath(target.lstrip("/") if target.startswith("/") else posixpath.join(base, target))
                        if resolved not in names:
                            errors.append(f"Missing relationship target {name}: {resolved}")
                parents = {child: parent for parent in root.iter() for child in parent}
                for paragraph in root.iter(word_tag("p")):
                    parent = parents.get(paragraph)
                    if parent is not None and parent.tag in (word_tag("p"), word_tag("r")):
                        errors.append(f"Invalid nested paragraph in {name}")
                for section in root.iter(word_tag("sectPr")):
                    parent = parents.get(section)
                    if parent is None:
                        errors.append(f"Detached section properties in {name}")
                    elif parent.tag == word_tag("pPr"):
                        paragraph = parents.get(parent)
                        owner = parents.get(paragraph)
                        if paragraph is None or paragraph.tag != word_tag("p") or owner is None or owner.tag != word_tag("body"):
                            errors.append(f"Section break is not a body-level paragraph in {name}")
                    elif parent.tag != word_tag("body"):
                        errors.append(f"Invalid section-property parent in {name}")
                for properties in root.iter(word_tag("tblPr")):
                    children = [child.tag.removeprefix(f"{{{WORD}}}") for child in properties]
                    positions = [TABLE_ORDER.index(child) for child in children if child in TABLE_ORDER]
                    if positions != sorted(positions):
                        errors.append(f"Table properties out of schema order in {name}")
                if name == "word/document.xml":
                    body = root.find(word_tag("body"))
                    if body is None:
                        errors.append("Missing document body")
                    else:
                        sections = [child for child in body if child.tag == word_tag("sectPr")]
                        if len(sections) != 1 or list(body)[-1].tag != word_tag("sectPr"):
                            errors.append("Final section properties must occur exactly once at the end of the body")
                    count = sum(1 for _ in root.iter(f"{{{DRAWING}}}blip"))
                    if expected_images is not None and count != expected_images:
                        errors.append(f"Inline images: expected {expected_images}, found {count}")
    except (OSError, BadZipFile, RuntimeError) as error:
        errors.append(f"Cannot read DOCX: {error}")
    return list(dict.fromkeys(errors))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path)
    parser.add_argument("--expected-images", type=int)
    arguments = parser.parse_args()
    errors = validate(arguments.docx, arguments.expected_images)
    for error in errors:
        print(f"ERROR: {error}")
    if not errors:
        print("OK: DOCX ZIP, XML, relationships, paragraph/section placement and table-property ordering")
        print("This is a targeted compatibility check, not full OOXML schema or native Word rendering validation.")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())