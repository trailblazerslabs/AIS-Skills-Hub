#!/usr/bin/env python3
"""TSD quality review: standards + knowledge-base coverage + input traceability + cross-references + security + diagrams.

Produces a scorecard (markdown) so a generated TSD can be judged against the same standards every time, and so a skill
change can be shown to move the score. The mechanical gates (check_tsd.py, check_tables.py, lint_drawio.py) remain the
hard gates; this report adds the checks they cannot make: does the TSD cover what the knowledge base says it must,
does it trace to *this* interface's inputs, and are the diagrams complete and attributable to a model.

Usage:
  python quality_review.py <tsd.md> --inputs <tsd-inputs/EAII-ID/converted> --archetype B [--flags +db2,+switch,migration]
        [--diagrams <tsd/EAII-ID/diagrams>] [--benchmark <approved-tsd.md>] [--out report.md] [--json]
"""
import argparse, json, re, struct, subprocess, sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass

HERE = Path(__file__).resolve().parent
SKILL = HERE.parents[1]
sys.path.insert(0, str(HERE))
import check_tsd  # noqa: E402

SEV_ORDER = {"error": 0, "warn": 1, "info": 2}


# ----------------------------------------------------------------------------- parsing helpers
def read(p):
    return Path(p).read_text(encoding="utf-8", errors="ignore")


class Doc:
    def __init__(self, path):
        self.text = read(path)
        self.lines = self.text.split("\n")
        self.hs = check_tsd.headings(self.lines)

    def sec(self, addr):
        """concatenated text of every section whose number matches addr (* = any number)"""
        rx = re.compile("^" + re.escape(addr).replace(r"\*", r"\d+") + "$")
        out = [check_tsd.section(self.lines, self.hs, n) for (_, _, n, _) in self.hs if rx.match(n)]
        out = [o for o in out if o is not None]
        return "\n".join(out) if out else None

    def has(self, addr):
        rx = re.compile("^" + re.escape(addr).replace(r"\*", r"\d+") + "$")
        return any(rx.match(n) for (_, _, n, _) in self.hs)


def tables(text):
    """list of (header_cells, rows) for every markdown table in text"""
    out, cur = [], []
    for l in (text or "").split("\n") + [""]:
        if l.strip().startswith("|"):
            cur.append(l.strip())
        else:
            if len(cur) >= 2:
                cells = lambda r: [c.strip() for c in r.strip().strip("|").split("|")]
                hdr = [re.sub(r"[*`]", "", c) for c in cells(cur[0])]
                rows = [cells(r) for r in cur[2:] if not re.match(r"^\|[\s:|-]+\|$", r)]
                out.append((hdr, rows))
            cur = []
    return out


def norm(s):
    return re.sub(r"[\s*`_]+", " ", s or "").strip().lower()


def envnorm(s):
    return re.sub(r"\{env\}|\{apim-env\}|\{npr/prd\}|\{npr\|prd\}|\b(dv1|st1|ut1|prd|dev|sit|uat|npr)\b|(?<=[a-z])(dv1|st1|ut1|prd)(?=ae)", "ENV", (s or "").lower())


# ----------------------------------------------------------------------------- result collection
class Report:
    def __init__(self):
        self.items = []  # dict(dim, id, ok, weight, sev, msg, detail)

    def add(self, dim, cid, ok, weight, msg, detail="", sev=None):
        self.items.append({"dim": dim, "id": cid, "ok": bool(ok), "weight": weight, "msg": msg, "detail": detail,
                           "sev": sev or ("error" if weight >= 3 else "warn" if weight >= 2 else "info")})

    def score(self, dim):
        its = [i for i in self.items if i["dim"] == dim]
        tot = sum(i["weight"] for i in its)
        got = sum(i["weight"] for i in its if i["ok"])
        return (100.0 * got / tot) if tot else None


# ----------------------------------------------------------------------------- A/D: knowledge-base rules
def run_kb(doc, rep, applies_set):
    rules = json.loads(read(HERE / "kb-checklist.json"))["rules"]
    for r in rules:
        if "*" not in r["applies"] and not (set(r["applies"]) & applies_set):
            continue
        if r.get("when_text") and not re.search(r["when_text"], doc.text):
            continue
        t = r["type"]
        ok, detail = False, ""
        if t == "heading":
            miss = [n for n in r["numbers"] if not doc.has(n)]
            ok, detail = not miss, "missing: " + ", ".join(miss)
        else:
            body = doc.sec(r["section"]) if r.get("section") else doc.text
            if body is None:
                ok, detail = False, f"section {r['section']} not found"
            elif t == "contains":
                miss = [p for p in r["patterns"] if not re.search(p, body)]
                ok, detail = not miss, "not found: " + "; ".join(miss)
            elif t == "any":
                ok = any(re.search(p, body) for p in r["patterns"])
                detail = "none of: " + "; ".join(r["patterns"])
            elif t == "absent":
                ok = not re.search(r["pattern"], body)
                detail = "forbidden text present"
            elif t == "count_ge":
                n = len(re.findall(r["pattern"], body))
                ok, detail = n >= r["n"], f"found {n}, need {r['n']}"
            elif t == "rows_ge":
                n = max([len(rows) for _, rows in tables(body)] or [0])
                ok, detail = n >= r["n"], f"largest table has {n} rows, need {r['n']}"
            elif t == "table_cols":
                ok = any(all(any(c.lower() in h.lower() for h in hdr) for c in r["cols"]) for hdr, _ in tables(body))
                detail = "no table with columns " + ", ".join(r["cols"])
        rep.add("Knowledge-base coverage", r["id"], ok, r["weight"], r["msg"] + f"  [{r['src']}]", "" if ok else detail)


# ----------------------------------------------------------------------------- B: traceability to this interface's inputs
def input_files(inputs):
    d = Path(inputs)
    fsd = next(iter(sorted(d.glob("FSD-*/*.md"))), None)
    mp = next(iter(sorted(d.glob("MAP-*/*.md"))), None)
    mf = next(iter(sorted(d.glob("MANIFEST-*/*.md"))), None)
    tr = next(iter(sorted(d.glob("*Walkthrough*.md"))), None) or next(iter(sorted(p for p in d.glob("*.md"))), None)
    return fsd, mp, mf, tr


def run_trace(doc, rep, inputs):
    fsd_p, map_p, man_p, tr_p = input_files(inputs)
    D = "FSD traceability"
    if not fsd_p:
        rep.add(D, "TR-00", False, 3, "FSD not found in --inputs; traceability not assessed")
        return
    fsd = read(fsd_p)
    mp = read(map_p) if map_p else ""
    T = doc.text

    eps = sorted(set(re.findall(r"`(/[\w/{}.\-]{3,})`", fsd)))
    miss = [e for e in eps if e not in T]
    rep.add(D, "TR-01", not miss, 3, f"every FSD endpoint path appears verbatim in the TSD ({len(eps)} in FSD)", "missing: " + ", ".join(miss))

    names = set()
    for hdr, rows in tables(mp):
        for ci, h in enumerate(hdr):
            if h in ("Source Field Path", "Target Field Name", "Target Field Path"):
                for r in rows:
                    if ci < len(r):
                        v = re.sub(r"[`*]", "", r[ci]).split("/")[-1].strip()
                        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", v):
                            names.add(v)
    miss = sorted(n for n in names if n not in T)
    rep.add(D, "TR-02", not miss, 3, f"every mapped field / parameter name appears in the TSD ({len(names)} in Mapping)", "missing: " + ", ".join(miss[:15]))

    objs = sorted(set(re.findall(r"(?:Stored Procedure|Table Function):\s*([A-Z][A-Z0-9_]{4,})", mp)) | set(re.findall(r"`([A-Z]{2,5}\d{3,}[A-Z]?)`", fsd)))
    s82 = doc.sec("8.2") or ""
    miss = [o for o in objs if o not in s82]
    rep.add(D, "TR-03", not miss if objs else True, 2, f"every database object is listed in 8.2 ({len(objs)} found in inputs)", "missing in 8.2: " + ", ".join(miss))

    tids = sorted(set(re.findall(r"^\|\s*(T\d+)\s*\|", fsd, re.M)), key=lambda x: int(x[1:]))
    s102 = doc.sec("5.*.10.2") or ""
    miss = [t for t in tids if not re.search(rf"\b{t}\b", s102)]
    rep.add(D, "TR-04", not miss, 3, f"every FSD test scenario T1..Tn is cited in the 'FSD ref' column ({len(tids)} in FSD)", "uncovered: " + ", ".join(miss))

    m = re.search(r"Exception handling(.*?)(?=\n###? |\Z)", fsd, re.S)
    scen = []
    if m:
        for hdr, rows in tables(m.group(1)):
            if hdr and hdr[0].lower().startswith("failure"):
                scen = [r[0] for r in rows if r]
    s633 = doc.sec("5.*.6.3.3") or ""
    unmatched = []
    for sc in scen:
        words = [w for w in re.findall(r"[A-Za-z]{5,}", sc.lower())]
        if words and sum(1 for w in words if w in s633.lower()) / len(words) < 0.5:
            unmatched.append(sc)
    rep.add(D, "TR-05", not unmatched, 3, f"every FSD exception scenario has a row in 5.x.6.3.3 ({len(scen)} in FSD)", "no matching row: " + "; ".join(unmatched))

    ki = re.findall(r"^\d+\.\s+\*\*(.+?)\*\*", (re.search(r"## 1\.4 Known Issues(.*?)\n## 1\.5", fsd, re.S) or [None, ""])[1], re.M)
    pool = (doc.sec("2.2") or "") + (doc.sec("5.*.5") or "") + (doc.sec("5.*.1.1") or "")
    miss = []
    for k in ki:
        ws = [w for w in re.findall(r"[A-Za-z]{5,}", k.lower()) if w not in check_tsd.STOP][:4]
        if ws and sum(1 for w in ws if w in pool.lower()) < max(1, len(ws) // 2):
            miss.append(k)
    rep.add(D, "TR-06", not miss, 2, f"every FSD known issue is designed for, listed in 2.2 or tested ({len(ki)} in FSD)", "not found: " + "; ".join(miss))

    tier = re.search(r"^\|\s*(Gold|Silver|Bronze)\b", fsd, re.M)
    s10, s45 = doc.sec("10") or "", doc.sec("4.5") or ""
    ok = bool(tier) and tier.group(1) in s10 and tier.group(1) in s45
    rep.add(D, "TR-07", ok if tier else True, 2, "service tier from FSD drives 10 and 4.5", "tier " + (tier.group(1) if tier else "n/a"))

    vols = sorted(set(re.findall(r"~?\s?[\d,]+(?:-[\d,]+)?/(?:day|month|hour|min)", fsd)))
    miss = [v for v in vols if v.replace("~", "").strip() not in T.replace("–", "-")]
    rep.add(D, "TR-08", not miss, 2, f"every FSD volume figure is carried into the TSD ({len(vols)} found)", "missing: " + ", ".join(miss))

    hz = "RED" if re.search(r"\bRED\b", fsd) else None
    ok = (not hz) or bool(re.search(r"(?i)horizon", (doc.sec("9.1") or "") + (doc.sec("5.*.5") or "")))
    rep.add(D, "TR-09", ok, 1, "Horizon RED rating drives 9.1 / design considerations")

    gl = []
    m = re.search(r"## 1\.5 Glossary(.*?)\n---", fsd, re.S)
    if m:
        for hdr, rows in tables(m.group(1)):
            gl = [norm(r[0]) for r in rows if r]
    s13 = norm(doc.sec("1.3") or "")
    miss = [g for g in gl if g and g not in s13]
    rep.add(D, "TR-10", len(miss) <= max(1, len(gl) // 5), 1, f"FSD glossary carried into 1.3 ({len(gl)} terms)", "missing: " + ", ".join(miss))

    if tr_p:
        cites = len(set(re.findall(r"Turn (\d+)", T)))
        rep.add(D, "TR-11", cites >= 8, 2, "design decisions cite walkthrough turns (>= 8 distinct)", f"{cites} cited")

    ids = sorted(set(re.findall(r"/pages/(\d+)", " ".join(u for u in re.findall(r"https://metcash\.atlassian\.net/wiki/[^\s)>\]]+", fsd) if re.search(r"(?i)mapping", u)))))
    s412 = doc.sec("4.1.2") or ""
    miss = [i for i in ids if i not in s412]
    rep.add(D, "TR-12", not miss, 2, "the Mapping document linked from the FSD is linked in 4.1.2", "page id(s) missing: " + ", ".join(miss))


# ----------------------------------------------------------------------------- C: cross references + security
def run_xref(doc, rep):
    D = "Cross-reference consistency"
    s102, s635, s633, s632 = doc.sec("5.*.10.2") or "", doc.sec("5.*.6.3.5") or "", doc.sec("5.*.6.3.2") or "", doc.sec("5.*.6.3.2") or ""
    defined = set(re.findall(r"\bTC-\d{3}\b", s102))
    cited = set(re.findall(r"\bTC-\d{3}\b", s633 + (doc.sec("5.*.6.3.3") or "")))
    rep.add(D, "XR-01", cited <= defined and bool(cited), 2, "audit rows cite only TC ids that exist in 5.x.10.2", "unknown: " + ", ".join(sorted(cited - defined)))

    paths = set(re.findall(r"(?<![\w.])(/[\w{}\-]+(?:/[\w{}\-.]+)+)", s102))
    miss = sorted(p for p in paths if p not in s635)
    rep.add(D, "XR-02", not miss, 2, "every endpoint used in test cases is the exact string in 5.x.6.3.5", "not in 6.3.5: " + ", ".join(miss))

    kvs = set(re.findall(r"t3[\w{}]*kv\d+", doc.sec("6.3.2") or ""))
    rbac = doc.sec("6.3.3") or ""
    miss = sorted(k for k in kvs if envnorm(k) not in envnorm(rbac))
    rep.add(D, "XR-03", not miss, 2, "every Key Vault in 6.3.2 has an RBAC row in 6.3.3", "no RBAC row: " + ", ".join(miss))

    c43, c611, c65 = doc.sec("4.3") or "", doc.sec("6.1.1") or "", doc.sec("6.5") or ""
    gaps = []
    for kw in ("Key Vault", "Application Insights", "API Management", "Logic App", "Application Gateway"):
        if kw.lower() in c43.lower() and not (kw.lower() in c611.lower() and kw.lower() in c65.lower()):
            gaps.append(kw)
    rep.add(D, "XR-04", not gaps, 2, "components in 4.3 also appear in 6.1.1 and 6.5", "missing: " + ", ".join(gaps))

    ops = [r[0] for hdr, rows in tables(s635) for r in rows if r]
    puml = (doc.sec("5.*.2.4") or "")
    miss = [o for o in ops if norm(re.sub(r"[`*]", "", o)) and not any(w in puml.lower() for w in re.findall(r"[a-z]{5,}", norm(o)))]
    rep.add(D, "XR-05", not miss, 1, "every operation is visible in the PlantUML sequence (or its group)", "absent: " + ", ".join(miss))

    names = set(re.findall(r"`?(t3-met-[\w{}\-]+-ae-logic)`?", doc.text))
    names = {re.sub(r"\{env\}|dv1|st1|ut1|prd", "ENV", n) for n in names}
    rep.add(D, "XR-06", len(names) <= 1, 2, "the Logic App / compute name is spelled one way everywhere", "variants: " + ", ".join(sorted(names)))

    # XR-07 every Key Vault in 6.3.2 has a private-endpoint row (the enabling Key Vault was missing in EAII-536..541)
    pe_rows = "\n".join(l for l in c65.split("\n") if re.search(r"(?i)-pe\b|private endpoint|privatelink", l))
    kv_all = {envnorm(k) for k in re.findall(r"t3[\w{}]*kv\d+", (doc.sec("6.3.2") or "") + c43)}
    miss = sorted(k for k in kv_all if k not in envnorm(pe_rows))
    rep.add(D, "XR-07", not miss, 3, "every Key Vault the interface reads (incl. the enabling / SMC Key Vault) has a private-endpoint row", "no private endpoint row: " + ", ".join(miss))

    # XR-09 shared platform resources appear in 6.6, not only the workload-owned ones
    s66 = envnorm(doc.sec("6.6") or "")
    shared = {envnorm(x) for x in re.findall(r"t3[\w{}]*kv\d+", doc.text)} | {envnorm(x) for x in re.findall(r"t[12]-met-[\w{}-]*-ae-sb-?\d+", doc.text)}
    miss = sorted(x for x in shared if x not in s66)
    rep.add(D, "XR-09", not miss, 3, "6.6 Infrastructure Resource Details lists every Key Vault and Service Bus namespace the interface uses (shared / platform resources too)", "not in 6.6: " + ", ".join(miss))

    # XR-08 shared ingestion content is described once (5.1), not copied into every target section
    seen = {}
    for (_, lvl, n, t) in doc.hs:
        if re.fullmatch(r"5\.\d+", n):
            body = doc.sec(n) or ""
            for para in re.split(r"\n\s*\n", re.sub(r"```.*?```", "", body, flags=re.S)):
                p_ = re.sub(r"\s+", " ", para).strip().lower()
                if len(p_) >= 120 and not p_.startswith(("|", "!", "<", "#")):
                    seen.setdefault(p_, set()).add(n)
    dup = [p_ for p_, ns in seen.items() if len(ns) >= 2]
    rep.add(D, "XR-08", not dup, 3, "no long paragraph is repeated in two interface sections (describe the shared ingestion interface once in 5.1 and reference it)", f"{len(dup)} repeated paragraph(s), e.g. " + (dup[0][:90] if dup else ""))

    sd = "Security"
    bad = re.findall(r"(?i)(?:password|pwd|secret|api[-_]?key|accountkey)\s*[:=]\s*[^\s|`<*)]{6,}", doc.text)
    bad += re.findall(r"Bearer\s+eyJ[\w.\-]+", doc.text)
    rep.add(sd, "SEC-01", not bad, 3, "no secret values, tokens or connection strings in the TSD", "; ".join(bad[:3]))
    rep.add(sd, "SEC-02", bool(re.search(r"Secret Name", doc.sec("6.3.2") or "")) or "key vault" not in doc.text.lower(), 2, "secret names are inventoried in 6.3.2 when Key Vault is used")
    rep.add(sd, "SEC-03", bool(re.search(r"(?i)never log|must not be logged|not logged|never be logged", doc.sec("6.3.1") or "")), 2, "6.3.1 states which fields must never be logged")


# ----------------------------------------------------------------------------- E: diagrams + model attribution
def png_width(p):
    with open(p, "rb") as f:
        h = f.read(24)
    return struct.unpack(">I", h[16:20])[0] if h[:8] == b"\x89PNG\r\n\x1a\n" else 0


def png_has_alpha(p):
    with open(p, "rb") as f:
        h = f.read(26)
    return h[:8] == b"\x89PNG\r\n\x1a\n" and len(h) > 25 and h[25] in (4, 6)


def run_diagrams(doc, rep, ddir, tsd_dir):
    D = "Diagrams"
    imgs = re.findall(r"!\[[^\]]*\]\(([^)]+)\)", doc.text)
    missing = [i for i in imgs if not (tsd_dir / i).exists()]
    rep.add(D, "DG-01", not missing and bool(imgs), 3, "every referenced image exists under images/", "missing: " + ", ".join(missing))
    nums = [int(m.group(1)) for i in imgs for m in [re.search(r"images/(\d+)\.png", i)] if m]
    rep.add(D, "DG-02", nums == sorted(nums) and nums == list(range(1, len(nums) + 1)), 1, "images numbered 01.. in document order")
    wide = [(i, png_width(tsd_dir / i)) for i in imgs if (tsd_dir / i).exists() and png_width(tsd_dir / i) > 4200]
    rep.add(D, "DG-03", not wide, 1, "no diagram wider than 4200 px at render scale 2 (about 2100 px at 100%; unreadable in Word)", ", ".join(f"{i}={w}px" for i, w in wide))
    alpha = [i for i in imgs if (tsd_dir / i).exists() and png_has_alpha(tsd_dir / i)]
    rep.add(D, "DG-13", not alpha, 2, "every PNG is flattened onto a white background (transparent PNGs, e.g. the FSD process diagram, render black in Word)", ", ".join(alpha))
    if not ddir or not Path(ddir).exists():
        rep.add(D, "DG-00", False, 3, "diagram folder with spec JSON not found")
        return
    specs = sorted(Path(ddir).glob("*.spec.json"))
    ops = [r[0] for hdr, rows in tables(doc.sec("5.*.6.3.5") or "") for r in rows if r]
    apim = "api management" in doc.text.lower()
    allp = {}
    for sp in specs:
        d = json.loads(read(sp).lstrip("\ufeff"))
        meta = d.get("_meta", {})
        rep.add(D, f"DG-04:{sp.name}", bool(meta.get("spec_author_model")), 3, f"{sp.name}: the model that authored the spec is recorded (_meta.spec_author_model)", "add _meta.spec_author_model; the skill's recommended spec author is named in SKILL.md Step 5")
        for p in d.get("pages", []):
            allp[p["name"]] = p
    for name, p in allp.items():
        icons = [n.get("icon") for n in p.get("nodes", [])]
        titles = " ".join(n.get("title", "") + n.get("label", "") for n in p.get("nodes", []))
        if apim:
            has_idp = "aad" in icons or re.search(r"(?i)entra|oauth", titles)
            rep.add(D, f"DG-05:{name}", has_idp, 2, f"'{name}' shows the OAuth 2.0 identity provider", "no Entra ID / aad node")
            nid = {n["id"] for n in p.get("nodes", []) if n.get("icon") == "aad" or re.search(r"(?i)entra", n.get("title", "") + n.get("label", ""))}
            e = [x for x in p.get("edges", []) if x["from"] in nid or x["to"] in nid]
            rep.add(D, f"DG-06:{name}", len(e) >= 2, 2, f"'{name}' has both arrows to the identity provider (token request, token validation)", f"{len(e)} edge(s)")
    arch = next((p for n, p in allp.items() if "architecture" in n.lower()), None)
    if arch:
        ic = [n.get("icon") for n in arch["nodes"]]
        need = min(len(ops), 6)
        rep.add(D, "DG-07", ic.count("apim-operation") >= need if apim and need else True, 2, f"Architecture page shows one APIM operation node per operation ({len(ops)} operations in 5.x.6.3.5)", f"{ic.count('apim-operation')} apim-operation node(s)")
        for want in ("key-vault", "app-insights", "smc"):
            rep.add(D, f"DG-08:{want}", want in ic, 1, f"Architecture page shows {want}")
    drawios = [p for p in Path(ddir).glob("*.drawio")]
    # DG-10 the process flow shows the SMC call when the sequence or SMC section says SMC is called
    seq = (doc.sec("5.*.2.4") or "") + (doc.sec("5.*.7") or "")
    proc = next((p for n, p in allp.items() if "process" in n.lower()), None)
    if proc and re.search(r"(?i)\bsmc\b", seq):
        txt = " ".join(str(n.get(k, "")) for n in proc.get("nodes", []) for k in ("id", "title", "label"))
        rep.add(D, "DG-10", bool(re.search(r"(?i)smc", txt)), 2, "process flow includes the SMC logging step (node) because the sequence / 5.x.7 call SMC", "no SMC node in the process flow")
    # DG-11 every Key Vault in 6.3.2 is a node on architecture, network and communication pages
    kvn = {envnorm(k) for k in re.findall(r"t3[\w{}]*kv\d+", doc.sec("6.3.2") or "")}
    if kvn:
        for key in ("architecture", "network", "communication"):
            pg = next((p for n, p in allp.items() if key in n.lower()), None)
            if pg:
                cnt = sum(1 for n in pg.get("nodes", []) if n.get("icon") == "key-vault" or re.search(r"(?i)\bkv\d|key vault", n.get("title", "") + n.get("label", "")))
                rep.add(D, f"DG-11:{key}", cnt >= len(kvn), 2, f"{key} page shows each Key Vault the interface uses ({len(kvn)} in 6.3.2, enabling Key Vault included)", f"{cnt} Key Vault node(s)")
    # DG-12 legend present on every icon page
    for dr in drawios:
        if "process" in dr.name.lower():
            continue
        xml = read(dr)
        pages = xml.count("<diagram ")
        leg = len(set(re.findall(r'<diagram [^>]*>(?:(?!</diagram>).)*?id="legend-', xml, re.S)))
        if pages:
            rep.add(D, f"DG-12:{dr.name}", leg >= pages, 2, f"{dr.name}: every page carries the legend (colour / line meaning)", f"{leg} of {pages} page(s) have legend-* cells; rebuild with the current builder")
    lint = SKILL / "tools" / "diagrams" / "lint_drawio.py"
    for dr in drawios:
        if "process" in dr.name.lower():
            continue
        out = subprocess.run([sys.executable, str(lint), str(dr)], capture_output=True, text=True, encoding="utf-8")
        errs = len(re.findall(r"^\s+ERROR", out.stdout, re.M))
        rep.add(D, f"DG-09:{dr.name}", errs == 0, 3, f"{dr.name}: lint_drawio reports 0 errors", f"{errs} error(s)")


# ----------------------------------------------------------------------------- G: benchmark diff (optional, informational)
def benchmark(doc, bench_path):
    b = read(bench_path)
    toks = set(re.findall(r"`([^`\n]{4,60})`", b)) | set(re.findall(r"\bEAII\d{3}-\d{3}\b", b)) | set(re.findall(r"\bHTTP \d{3}\b|\b(?:4\d\d|5\d\d) [A-Z][a-z]+", b))
    toks = {t.strip() for t in toks if not re.search(r"\{env\}|http", t)}
    missing = sorted(t for t in toks if t.lower() not in doc.text.lower())
    heads_b = {n for (_, _, n, _) in check_tsd.headings(b.split("\n"))}
    heads_c = {n for (_, _, n, _) in doc.hs}
    return len(toks), missing, sorted(heads_b - heads_c)


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tsd")
    ap.add_argument("--inputs")
    ap.add_argument("--archetype", default="B")
    ap.add_argument("--flags", default="")
    ap.add_argument("--diagrams")
    ap.add_argument("--benchmark")
    ap.add_argument("--out")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    doc = Doc(a.tsd)
    rep = Report()
    applies = {a.archetype} | {f.strip() for f in a.flags.split(",") if f.strip()}

    # mechanical lint (reuse)
    for sev, code, msg in check_tsd.check(a.tsd, a.inputs, None):
        if sev in ("error", "warn"):
            rep.add("Mechanical lint (check_tsd)", f"LINT-{code}", False, 3 if sev == "error" else 1, msg, sev=sev)
    if not any(i["dim"].startswith("Mechanical") for i in rep.items):
        rep.add("Mechanical lint (check_tsd)", "LINT-ok", True, 1, "check_tsd.py reports 0 errors and 0 warnings")

    run_kb(doc, rep, applies)
    if a.inputs:
        run_trace(doc, rep, a.inputs)
    run_xref(doc, rep)
    run_diagrams(doc, rep, a.diagrams, Path(a.tsd).parent)
    if a.inputs:
        reg = Path(a.inputs).parent / "gap-register.json"
        if reg.exists():
            gr = HERE.parents[1] / "tools" / "intake" / "gap_register.py"
            out = subprocess.run([sys.executable, str(gr), "check", str(reg.parent), a.tsd], capture_output=True, text=True, encoding="utf-8")
            bad = [l for l in out.stdout.splitlines() if re.match(r"(ERROR|WARN)\s+GR-", l)]
            rep.add("Gap register", "GR", not bad, 2, "every gap in the register is traceable in the TSD and resolved gaps are reflected in the text", "; ".join(bad[:4]))

    dims = []
    for it in rep.items:
        if it["dim"] not in dims:
            dims.append(it["dim"])
    overall = [rep.score(d) for d in dims if rep.score(d) is not None]
    L = [f"# TSD quality review — {Path(a.tsd).name}", "",
         f"Archetype `{a.archetype}`, flags `{a.flags or '-'}`. Overall: **{sum(overall)/len(overall):.0f} / 100**", "",
         "| Dimension | Score | Checks failed |", "|---|---|---|"]
    for d in dims:
        f = [i for i in rep.items if i["dim"] == d and not i["ok"]]
        L.append(f"| {d} | {rep.score(d):.0f} | {len(f)} of {len([i for i in rep.items if i['dim'] == d])} |")
    L += ["", "## Failed checks", "", "| Sev | Id | What the standard requires | Detail |", "|---|---|---|---|"]
    for i in sorted([i for i in rep.items if not i["ok"]], key=lambda x: (SEV_ORDER[x["sev"]], x["id"])):
        L.append(f"| {i['sev']} | {i['id']} | {i['msg']} | {i['detail'][:160]} |")
    if a.benchmark:
        n, miss, hm = benchmark(doc, a.benchmark)
        L += ["", f"## Benchmark coverage vs `{Path(a.benchmark).name}`", "",
              f"{n - len(miss)} of {n} technical tokens (code spans, exception codes, HTTP statuses) in the benchmark also appear here.",
              "Sections numbered in the benchmark but absent here: " + (", ".join(hm) or "none"), "",
              "Tokens only in the benchmark (triage by hand — many are the benchmark's own invented or interface-specific values):", ""]
        L += [f"- `{t}`" for t in miss[:60]]
    out = "\n".join(L) + "\n"
    if a.out:
        Path(a.out).write_text(out, encoding="utf-8", newline="\n")
    if a.json:
        print(json.dumps({"scores": {d: rep.score(d) for d in dims}, "items": rep.items}, indent=1))
    else:
        print(out)
    sys.exit(1 if any(not i["ok"] and i["sev"] == "error" for i in rep.items) else 0)


if __name__ == "__main__":
    main()
