#!/usr/bin/env python3
"""Mechanical quality gate for a generated TSD (.md). Complements check_tables.py and lint_drawio.py.

Every check here exists because the defect was found in a real approved/generated TSD
(see references/10-known-defects-in-approved-tsds.md), so the generator can no longer ship it silently.

Usage:
  python check_tsd.py <tsd.md> [--inputs <tsd-inputs/EAII-ID/converted>] [--corpus reference-corpus/converted/tsd]
                      [--json] [--strict]
  --inputs  enables the checks that compare the TSD with THIS interface's own FSD/Mapping/Manifest/transcript
            (invented NFR figures, other interfaces' nouns)
  --corpus  enables the 'copied from another interface' check
Exit code 1 if any ERROR (or any WARN with --strict).
"""
import argparse, collections, json, re, sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass

ENVISH = {"env", "npr", "prd", "apim-env", "npr/prd", "apim-env}", "workload", "domain", "nnn", "n", "env|", "npr|prd", "npr|prd}", "token"}
SMC_FIELDS = ["Business Process", "Source Business Process", "Source Application", "Destination Business Process",
              "Destination Application", "Interface ID", "Interface Name", "Interface Type", "Interface DataStore", "Tags",
              "Reference Keys", "Notification Type", "Notification Email Address", "Grouping ID", "Correlation Properties",
              "Reprocessing Required"]
STOP = set("""about above after again against already also always another because before being between both cannot could
during each either every first following from further have having into itself might more most must never only other
otherwise over same should since some such than that their them then there these they this those through under until
upon using very were what when where which while with within without would your azure service services system systems
data message messages process processing interface integration platform application applications request response
requests responses logic function functions storage account blob queue topic secret secrets vault monitoring logging
standard standards resource resources design document file files management gateway source target environment
environments endpoint endpoints support supports supported required requirement requirements managed identity access
authentication authorization authorisation security network private public network error errors failure failures
exception exceptions retry retries timeout state workflow workflows trigger triggers transform transformation
transformations mapping mappings schema schemas payload payloads field fields record records output input
""".split())


def read(p):
    return Path(p).read_text(encoding="utf-8", errors="ignore")


def headings(lines):
    out = []
    for i, l in enumerate(lines):
        m = re.match(r"^(#{1,6})\s+\**(\d+(?:\.\d+)*)\.?\s+(.*)$", l)
        if m:
            out.append((i, len(m.group(1)), m.group(2), m.group(3).strip()))
    return out


def section(lines, hs, num):
    """text of the section whose heading number == num (until next heading of same or higher level)"""
    for k, (i, lvl, n, t) in enumerate(hs):
        if n == num:
            end = len(lines)
            for (j, l2, n2, t2) in hs[k + 1:]:
                if l2 <= lvl:
                    end = j
                    break
            return "\n".join(lines[i + 1:end])
    return None


def sections_matching(lines, hs, pattern):
    return [(n, t, section(lines, hs, n)) for (i, lvl, n, t) in hs if re.fullmatch(pattern, n)]


def check(tsd, inputs=None, corpus=None):
    text = read(tsd)
    lines = text.split("\n")
    hs = headings(lines)
    R = []

    def add(sev, code, msg):
        R.append((sev, code, msg))

    ids = sorted(set(re.findall(r"EAII-(\d{3})", "\n".join(lines[:25]))) or set(re.findall(r"EAII-(\d{3})", text[:600])))

    # 1 duplicate heading numbers
    cnt = collections.Counter(n for (_, _, n, _) in hs)
    for n, c in cnt.items():
        if c > 1:
            titles = [t for (_, _, nn, t) in hs if nn == n]
            add("error", "dup-number", f"heading number {n} used {c} times: {titles} (corpus defect: second 5.x.7.1 must be 5.x.7.2)")

    # 2 required top-level sections 1..15 + 8.5
    for n in range(1, 16):
        if not any(h[2] == str(n) and h[1] == 1 for h in hs):
            add("error", "missing-section", f"top-level section {n} is missing")
    for n in ("8.5", "8.5.1", "8.5.1.1", "8.5.2", "8.5.3", "8.5.3.1", "8.5.3.2"):
        if not any(h[2] == n for h in hs):
            add("error", "missing-section", f"§{n} missing (§8.5 Data Retention is mandatory - 9/9 corpus TSDs)")

    # 3 template leftovers: only tokens that actually occur in TSD.template.md are placeholders
    # ({SupplierId}, {SourceFileNameWithoutExtension} etc. are legitimate blob-path tokens)
    tpl = Path(__file__).resolve().parents[2] / "templates" / "TSD.template.md"
    tpl_tokens = set()
    if tpl.exists():
        for t in re.findall(r"\{([A-Za-z][A-Za-z0-9 /_.|-]*)\}", tpl.read_text(encoding="utf-8", errors="ignore")):
            if t.lower() in ENVISH or t.lower().startswith(("env", "npr", "apim")) or "env" in t.lower():
                continue
            tpl_tokens.add(t)
    in_fence = False
    for i, l in enumerate(lines, 1):
        if l.lstrip().startswith("```"):
            in_fence = not in_fence
        if in_fence:
            continue  # PlantUML / JSON samples use {x} as notation
        for m in re.finditer(r"\{([A-Za-z][A-Za-z0-9 /_.|-]*)\}", re.sub(r"`[^`]*`", "", l)):  # `...{pattern}...` is notation, not a leftover
            if m.group(1) in tpl_tokens:
                add("error", "template-placeholder", f"line {i}: unresolved template placeholder {{{m.group(1)}}}")
        if re.search(r"Capture any specific disaster recovery|\{generated section|<!--", l):
            add("warn", "template-leftover", f"line {i}: template text/comment left in: {l.strip()[:70]}")
    if re.search(r"\bTBD\b", text):
        add("warn", "bare-tbd", "bare 'TBD' found - use *<To be confirmed — [what] from [whom]>*")
    internal_ref = re.compile(r"(?i)\b(?:intake|design|approved)[ -]questionnaire|questionnaire\s*(?:§|section)|§\s*3A\b|\bTurn\s+\d+\b|\(\s*(?:G|Q|A|B|TBC)-?\d{1,3}\b[^)]*\)|\b(?:gap|question)\s+(?:G|Q|A|B|TBC)-?\d{1,3}\b")
    in_fence = False
    for i, l in enumerate(lines, 1):
        if l.lstrip().startswith("```"):
            in_fence = not in_fence
        if not in_fence and internal_ref.search(re.sub(r"`[^`]*`", "", l)):
            add("error", "internal-reference", f"line {i}: the TSD cites the questionnaire / a gap id / a transcript turn; state the decision or fact itself: {l.strip()[:70]}")
    m_scope = re.search(r"^# 2 Scope\s*$(.*?)^# 3 ", text, re.S | re.M)
    if m_scope and re.search(r"!\[[^\]]*\]\(", m_scope.group(1)):
        add("error", "scope-image", "§2 Scope contains an image; In Scope / Out of Scope are text only (reviewer rule 2026-10-02)")

    # 4 exception codes
    exc = re.findall(r"EAII(\d{3})-(\d{3})", text)
    if exc:
        nums = {a for a, _ in exc}
        for n in nums:
            if ids and n not in ids:
                add("warn", "exception-code-id", f"exception code prefix EAII{n} does not match this TSD's interface id(s) {ids}")
        if not any(b == "099" for _, b in exc):
            add("error", "no-099", "no EAII<nnn>-099 catch-all exception row")
    else:
        add("error", "no-exception-codes", "no exception codes in EAII<nnn>-<seq> format (HTTP-nnn / ad-hoc codes are a corpus defect)")
    if re.search(r"\bHTTP-\d{3}\b|[A-Z]+-ERR-[A-Z0-9]+", text):
        add("warn", "adhoc-codes", "ad-hoc exception code scheme (HTTP-nnn / *-ERR-*) found; use EAII<nnn>-<seq> and record any retired FSD code")

    # 5 test cases: TC-nnn, sequential, referenced
    for (n, t, body) in sections_matching(lines, hs, r"\d+\.\d+\.10\.2"):
        tcs = re.findall(r"\|\s*\**(TC-\d{3})\**\s*\|", body or "")
        if not tcs:
            add("error", "no-tc", f"§{n}: no TC-nnn test case rows (ADO import shape: ID | Work Item Type | Title | Step Action | Step Expected)")
        else:
            nums = [int(x[3:]) for x in tcs]
            if len(set(nums)) != len(nums):
                add("error", "tc-dup", f"§{n}: duplicate TC ids")
            if nums != list(range(nums[0], nums[0] + len(nums))):
                add("warn", "tc-gap", f"§{n}: TC ids are not sequential: {tcs[:6]}...")
        if re.search(r"^\|\s*\**T\d{1,2}\**\s*\|", body or "", re.M):
            add("error", "legacy-test-ids", f"§{n}: FSD-style T<n> ids used; use TC-nnn (keep the FSD id in the 'FSD ref' column)")
    allowed = set(re.findall(r"\bTC-\d{3}\b", text))
    for (n, t, body) in sections_matching(lines, hs, r"\d+\.\d+\.6\.3\.2"):
        refs = re.findall(r"\b(TC-\d{3}|T\d{1,2})\b", body or "")
        if any(re.fullmatch(r"T\d{1,2}", r) for r in refs):
            add("error", "audit-legacy-ids", f"§{n}: Audit 'Test Scenario' column cites T<n>; cite TC-nnn")

    # 6 SMC onboarding completeness
    for (n, t, body) in sections_matching(lines, hs, r"\d+\.\d+\.7\.1"):
        for f in SMC_FIELDS:
            if not re.search(r"\|\s*\**" + re.escape(f) + r"\**\s*\|", body or ""):
                add("error", "smc-field-missing", f"§{n}: SMC onboarding field '{f}' missing (no field may be omitted)")

    # 7 same resource spelled two ways
    names = set(re.findall(r"\bt[123]-met-[A-Za-z0-9{}/|-]*[A-Za-z0-9}]", text))
    norm = {}
    for nm in names:
        parts = re.split(r"-", re.sub(r"\{[^}]*\}", "ENV", nm))
        norm[nm] = parts
    pairs = []
    keys = sorted(norm)
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            pa, pb = norm[a], norm[b]
            if pa == pb or len(pa) == len(pb):
                continue
            s, l = (pa, pb) if len(pa) < len(pb) else (pb, pa)
            if len(l) - len(s) <= 2 and s[0:2] == l[0:2] and s[-2:] == l[-2:] and all(x in l for x in s):
                pairs.append((a, b))
    for a, b in pairs[:6]:
        add("warn", "name-variants", f"resource appears as both `{a}` and `{b}` - one spelling everywhere (gate 6.3)")

    # 8 GoAnywhere consistency
    ga_mentioned = len(re.findall(r"GoAnywhere", text)) > 2
    for (n, t, body) in sections_matching(lines, hs, r"\d+\.\d+\.4"):
        if ga_mentioned and re.fullmatch(r"\s*\*?(NA|N/A)[.*]?\s*", (body or "").strip() or "NA"):
            add("warn", "goanywhere-na", f"§{n} is NA but GoAnywhere is used elsewhere in the TSD - fill the requirements block")
    for (n, t, body) in sections_matching(lines, hs, r"\d+\.\d+\.3"):
        if re.fullmatch(r"\s*\*?(NA|N/A)[.*]?\s*", (body or "").strip()):
            add("warn", "coordination-na", f"§{n} Coordination is NA - state synchronous/asynchronous, transaction boundaries and state (blob folders/queues)")

    # 9 empty or placeholder DR / limitations
    for num, nm in (("10", "Disaster Recovery"), ("12", "Limitations and Constraints")):
        body = section(lines, hs, num) or ""
        stripped = re.sub(r"[\s|\-*_]", "", body)
        if len(stripped) < 25:
            add("warn", "empty-section", f"§{num} {nm} is empty or a placeholder - fill from the FSD/GSB tier or state explicitly that none apply")

    # 9b components named in the §3.2 patterns table must exist in §4.3 Required Components
    # (374's approved TSD names Azure Functions / Event Grid / Service Bus patterns copied from 304 but lists none of them)
    comp = {"Logic App": r"Logic Apps?", "Azure Functions": r"Function", "Event Grid": r"Event Grid", "Service Bus": r"Service Bus",
            "Data Factory": r"Data Factory", "Blob Storage": r"Blob|Storage Account", "GoAnywhere": r"GoAnywhere",
            "API Management": r"API Management|APIM"}
    s32 = section(lines, hs, "3.2") or ""
    pat_tbl = "\n".join(l for l in s32.split("\n") if l.startswith("|"))
    s43 = section(lines, hs, "4.3") or ""
    if pat_tbl and s43.strip():
        for name, rx in comp.items():
            if re.search(rx, pat_tbl, re.I) and not re.search(rx, s43, re.I):
                add("warn", "pattern-component-not-in-4.3", f"§3.2 patterns mention {name} but §4.3 Required Components does not list it (text copied from another interface?)")

    # 10 process step count (feeds lint_drawio --steps)
    for (n, t, body) in sections_matching(lines, hs, r"\d+\.\d+\.2\.1"):
        steps = re.findall(r"(?m)^\s*(\d+)\.\s+\S", body or "")
        top = [int(s) for s in steps]
        add("info", "step-count", f"§{n}: {len(top)} numbered process step lines (use as --steps N for lint_drawio.py on the process-flow page)")

    # --- checks that need this interface's inputs ---
    if inputs:
        itext = ""
        for p in sorted(Path(inputs).rglob("*.md")):
            if p.name.startswith(("intake-questionnaire", "Technical Specification")):
                continue
            itext += "\n" + read(p)
        il = itext.lower()
        # invented NFR figures
        for m in re.finditer(r"(\d+(?:\.\d+)?)\s*%", text):
            ctx = text[max(0, m.start() - 70):m.end() + 40].lower()
            if re.search(r"availab|uptime|sla|success rate|error rate", ctx) and m.group(1) not in itext:
                add("error", "nfr-not-in-inputs", f"availability/rate figure {m.group(0)} is not in this interface's FSD/Mapping/Manifest/transcript (context: ...{ctx.strip()[:60]}...)")
        for m in re.finditer(r"(\d[\d,]*)\s*(requests?/min(?:ute)?|requests per minute|concurrent|tps)", text, re.I):
            if m.group(1) not in itext:
                add("error", "nfr-not-in-inputs", f"NFR figure '{m.group(0)}' is not in this interface's inputs - mark *<To be confirmed>* instead of inventing it")
        # other interfaces' signature nouns
        if corpus:
            own = Path(tsd).resolve()
            docs = {}
            for p in Path(corpus).rglob("TSD-*.md"):
                if p.resolve() == own:
                    continue  # the TSD under test is compared AGAINST the others, never against itself
                docs[p.parent.name] = read(p)
            toks = {k: collections.Counter(w for w in re.findall(r"[A-Za-z]{6,}", v.lower()) if w not in STOP) for k, v in docs.items()}
            sig = {}
            for k, c in toks.items():
                others = [set(o) for kk, o in toks.items() if kk != k]
                sig[k] = {w for w, n in c.items() if n >= 8 and len(w) >= 7 and not any(w in o for o in others)}
            mine = set(w for w in re.findall(r"[A-Za-z]{6,}", text.lower()))
            hit = collections.defaultdict(list)
            for k, ws in sig.items():
                for w in ws:
                    if w in mine and w not in il and not any(i and f"eaii-{i}" in k.lower() for i in ids) and w not in STOP:
                        hit[k].append(w)
            for k, ws in hit.items():
                if len(ws) >= 3:
                    add("warn", "foreign-terms", f"terms characteristic of {k} appear here but not in this interface's inputs: {sorted(ws)[:6]} (copied text?)")
    return R


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("tsd")
    ap.add_argument("--inputs")
    ap.add_argument("--corpus")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    R = check(a.tsd, a.inputs, a.corpus)
    if a.json:
        print(json.dumps([dict(sev=s, code=c, msg=m) for s, c, m in R], indent=1))
    else:
        for sev, code, msg in R:
            print(f"{sev.upper():5} {code}: {msg}")
        e = sum(1 for r in R if r[0] == "error")
        w = sum(1 for r in R if r[0] == "warn")
        print(f"-- {e} error(s), {w} warning(s)")
    bad = any(r[0] == "error" for r in R) or (a.strict and any(r[0] == "warn" for r in R))
    sys.exit(1 if bad else 0)
