#!/usr/bin/env python3
"""Summarise the Logic App code a TSD is about to be reconciled with (read-only, git only - no MCP, no network).

Usage:
  python scan_logicapp.py <local-clone> <branch-or-ref> [--env dev]
e.g.
  python scan_logicapp.py C:\\Users\\me\\source\\repos\\Metcash.AIS.Data.Metproducts-main origin/feature/EAII-374-pe-item-and-vendor-validation

Prints, per workflow.json on that ref: kind (Stateful / Stateless), trigger, scopes, switch cases, every service-provider /
APIM / Service Bus action (so a DB call, SMC call and queue are visible), retry policies, HTTP status mapping, and the
Parameters / AppSettings / Connections files for one environment. The TSD reconciliation checklist
(references/11-post-generation-checklist.md, section D) is answered from this output.
Only reads from the clone you name; the clone must belong to the METCASHDevOps organisation.
"""
import argparse, json, re, subprocess, sys

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass


def git(repo, *a):
    return subprocess.run(["git", "-C", repo, *a], capture_output=True, text=True, encoding="utf-8").stdout


def walk(actions, depth=0, out=None):
    out = [] if out is None else out
    for name, a in (actions or {}).items():
        t = a.get("type")
        inp = a.get("inputs", {}) if isinstance(a.get("inputs"), dict) else {}
        info = {"name": name, "type": t, "depth": depth}
        if t == "ServiceProvider":
            sp = inp.get("serviceProviderConfiguration", {})
            info["sp"] = sp.get("serviceProviderId", "") + "/" + sp.get("operationId", "")
            info["conn"] = sp.get("connectionName")
        if t == "ApiManagement":
            info["apim"] = inp.get("apiManagement", {}).get("operationId")
        info["retry"] = a.get("retryPolicy") or inp.get("retryPolicy")
        out.append(info)
        for sub in ("actions",):
            if isinstance(a.get(sub), dict):
                walk(a[sub], depth + 1, out)
        if isinstance(a.get("else"), dict):
            walk(a["else"].get("actions", {}), depth + 1, out)
        if t == "Switch":
            info["cases"] = list(a.get("cases", {}).keys())
            for c in a.get("cases", {}).values():
                walk(c.get("actions", {}), depth + 1, out)
            walk(a.get("default", {}).get("actions", {}), depth + 1, out)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("repo")
    ap.add_argument("ref")
    ap.add_argument("--env", default="dev")
    a = ap.parse_args()

    print("remote:", git(a.repo, "remote", "get-url", "origin").strip())
    print("ref:", a.ref)
    print("recent commits:\n" + git(a.repo, "log", a.ref, "--format=  %h %ad %an  %s", "--date=short", "-6"))
    files = git(a.repo, "ls-tree", "-r", "--name-only", a.ref).split("\n")
    wfs = [f for f in files if f.endswith("workflow.json")]
    print("workflow.json files:", wfs)
    for wf in wfs:
        j = json.loads(git(a.repo, "show", f"{a.ref}:{wf}"))
        d = j["definition"]
        print(f"\n=== {wf}\nkind: {j.get('kind')}  triggers: {[(k, v.get('type')) for k, v in d['triggers'].items()]}")
        acts = walk(d["actions"])
        print("actions:", len(acts), "| scopes:", [x["name"] for x in acts if x["type"] == "Scope"])
        for x in acts:
            if x.get("cases"):
                print("switch", x["name"], "cases:", x["cases"])
            if x.get("sp") or x.get("apim"):
                print(f"  {x['name']}: {x.get('sp') or 'APIM ' + str(x.get('apim'))} conn={x.get('conn')} retry={x.get('retry')}")
        txt = json.dumps(j)
        codes = sorted(set(re.findall(r"'(\d{3})'", txt)))
        print("HTTP codes mapped:", codes)
        print("operation header:", sorted(set(re.findall(r"headers'\]\?\['([\w-]+)'\]", txt))))
        print("responses:", [x["name"] for x in acts if x["type"] == "Response"])
    base = wfs[0].rsplit("/", 2)[0] if wfs else ""
    for sub, pat in (("Connections", f"connections.{a.env}.json"), ("Parameters", f"parameters.{a.env}.json"), ("AppSettings", f"appsettings.{a.env}.json")):
        path = f"{base}/{sub}/{pat}"
        if path in files:
            print(f"\n=== {path}\n" + git(a.repo, "show", f"{a.ref}:{path}")[:2500])
    print("\npipelines:", [f for f in files if f.startswith("pipelines/") and f.endswith(".yml")])


main()
