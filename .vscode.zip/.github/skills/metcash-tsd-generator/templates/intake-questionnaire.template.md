# TSD Design Questionnaire — {EAII-IDs} — {Source} to {Target}

Generated: {date} | Status: **AWAITING YOUR APPROVAL — generation is paused**

Every item below already has a **proposed answer**, worked out from the FSD, Mapping/Manifest,
transcript, and corpus precedent — the same rigor a live conversation would apply. Review each
one:

- Agree with a proposal? Leave it as-is.
- Disagree? Edit the `Proposed:` line directly with your answer.

Then tell the agent the questionnaire is approved. **Generation will not continue until you do —**
proposed answers are recommendations, not silent defaults the agent will act on unattended.

**Two kinds of item, two colours:**

- **Proposals** (§1–§3) already carry an answer worked out from the inputs — edit only if you disagree.
- **🟥 NEEDS INPUT** items (§3A) are facts the FSD/Mapping/Manifest/transcript do not give and the agent
  must not guess — storage account, container/folder names, repo, public API path, queue/topic name,
  GoAnywhere details, DB2 host/schema, and so on. Type the answer on the `Answer:` line. **While any 🟥
  item still says `⟪ fill in ⟫`, generation is blocked** (`tools/intake/intake_gaps.py check`).
  🟧 CONFIRM items do not block; ⬜ RECOMMENDED items are optional.

---

## 1. Architecture Archetype

**Proposed:** {archetype letter} — {archetype name}

**Why:** {evidence from FSD — trigger, transformation, volume, latency} + closest corpus
precedent {TSD-EAII-nnn}. Rejected: {archetype} — {one-line reason}.

> Edit above if you want a different archetype, otherwise leave as-is.

---

## 1.5 Legacy TIBCO Source *(migration interfaces only — omit entirely for net-new)*

**Repo:** {repo name}

**Entry point(s):** {e.g. `ProcessProductRecords.bwp`, `getOpenidToken.bwp`}

**Found via:** {cited transcript turn/speaker/timestamp, or "GitHub MCP `search_repositories`
on {search term} → confirmed via `list_directory`/`get_file_contents`"}

> If no confident match was found, this becomes a **gap** in §4 below (kind A) — never guess a
> repo name. `ais-codegen-readiness`'s own TIBCO cross-check reads this section back later, so an
> unresolved entry here blocks that cross-check too, not just this document.

---

## 2. Already confirmed from the FSD walkthrough transcript

No action needed — these are settled decisions, shown for your awareness. Correct any that are
wrong by editing the "Decision" column directly.

| Topic | Decision | Cited from |
|---|---|---|
| {topic} | {decision} | Turn {n}, {speaker}, {mm:ss} |

---

## 3. Open design questions — each has a proposed answer, edit any you disagree with

Only questions the FSD and transcript leave genuinely open appear here — everything already
settled above is not repeated.

### Q1. {question text}

**Proposed:** {best-supported answer} — *{one-line rationale: FSD §, corpus precedent, or stated default}*

<!-- If this question concerns a non-trivial runtime mechanism (content-based router, partial-
     failure/retry strategy, concurrency/singleton constraint, etc.), don't stop at one line —
     write the concrete step-by-step design here at the depth §5.x.5 Design Considerations needs,
     so the user is approving a real design, not just a label. -->

### Q2. {question text}

**Proposed:** {best-supported answer} — *{one-line rationale}*

<!-- Repeat one ### block per open Step 2 question. Renumber sequentially. Every block MUST have
     a filled-in Proposed line with rationale — never leave one blank or unreasoned. -->

---

## 3A. Facts the design needs — 🟥 NEEDS INPUT / 🟧 CONFIRM

<!-- GENERATED, do not hand-write: after the archetype in §1 is proposed, run
       python .github/skills/metcash-tsd-generator/tools/intake/intake_gaps.py scan             tsd-inputs/<EAII-ID>/converted --archetype <A|B|C|D|hybrid-async-upload> [--flags +db2,+goanywhere]             --out tsd-inputs/<EAII-ID>/intake-facts.md
     and paste its output here. Only the facts that apply to THIS design appear (a blob container is asked
     for only when files are staged in Blob Storage; DB2 details only when there is a DB2 target; etc.).
     Re-run it whenever the archetype or a component in §1 changes. -->

{generated section 3A — one `### 🟥/🟧/⬜/✅` block per applicable fact, each with Question, Evidence found,
Starting point and an `Answer:` line}

> **Gate:** `python .github/skills/metcash-tsd-generator/tools/intake/intake_gaps.py check <this file>` must print
> `OK` before Step 3. Facts left unanswered are never invented: they would become `*<To be confirmed — [what] from [whom]>*`
> in the TSD only if the user explicitly chooses that instead of answering.

---

## 4. Open questions & gaps — will carry into the TSD's §12 Limitations / §13 Assumptions

Mandatory section — never omit it, even if it ends up with only one or two rows. Split explicitly
into two kinds; do not blend them into the Q&A list above.

- **(A) Transcript-unresolved** — a decision point the SMEs raised live but never actually
  answered on record (e.g. "we'll check the code and get back to you" with no follow-up visible,
  or an explicit "let's take it up during the technical discussion"). If some other document
  states a value for the same point, cross-reference it against the live uncertainty rather than
  silently treating the document as having settled it.
- **(B) Copilot-identified** — a gap or risk noticed while cross-reading the FSD, Mapping,
  Manifest, and transcript together that nobody raised live: a record type with zero production
  sample coverage, a stated constraint (e.g. "singleton"/"one at a time") that doesn't
  automatically hold in the target Azure runtime model, or two documents that look contradictory
  until read closely (resolve these yourself from the evidence and mark them resolved, showing
  your reasoning, rather than leaving them open).

| # | Kind | Item | Detail | Recommended action / resolution |
|---|---|---|---|---|
| G1 | (A) Transcript-unresolved | {topic} | {what was raised, what was never confirmed, citation} | {what needs to happen before build sign-off} |
| G2 | (B) Copilot-identified | {topic} | {the gap or the contradiction, and how it's resolved by evidence if resolved} | {recommended action, or "resolved — no action needed" with the reasoning} |

<!-- Add one row per gap found. Every row here must reappear in the generated TSD as an explicit
     *<To be confirmed>* entry in §12 Limitations and/or §13 Assumptions — never drop one silently
     once the questionnaire is approved. -->

---

## 5. Anything else the architect should know

Free text — known risks, naming preferences, sibling interfaces to reuse a workload token from,
non-standard environments, publishing preferences, etc.

> _______________

---

*Review the proposals above, edit anything you disagree with, then tell the agent "questionnaire
approved" (or similar) to resume TSD generation from Step 3. The agent will not proceed on its
own — this pause is mandatory.*
