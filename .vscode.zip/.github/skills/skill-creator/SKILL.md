---
name: skill-creator
description: |
  Guide for creating new skills for the Metcash AIS Skills Hub. USE FOR: creating a new SKILL.md,
  adding a new agent persona, adding a new prompt template, or extending this repository with
  domain-specific knowledge for Azure Integration development. DO NOT USE FOR: generating
  integration code, reviewing code, or architecture recommendation.
  Triggers: "create a skill", "add a new skill", "new skill template", "skill creator",
  "add skill", "extend skills", "write a SKILL.md".
---

# AIS Skill Creator

Guide for adding new skills, agents, and prompts to the Metcash AIS Skills Hub.

> **Before creating a skill:** Confirm there isn't an existing skill that covers the need.
> Avoid overlapping trigger phrases — each skill should have a distinct activation surface.

---

## Skill Structure

Every skill lives at `.github/skills/<skill-name>/SKILL.md`:

```
.github/skills/<skill-name>/
├── SKILL.md              ← Required. Frontmatter + instructions.
├── references/           ← Optional. Detailed pattern docs loaded on demand.
│   └── *.md
└── assets/               ← Optional. Templates, sample JSON, CSV boilerplate.
    └── *
```

**Keep `SKILL.md` under 500 lines.** Move detailed patterns to `references/`.

---

## SKILL.md Frontmatter

```yaml
---
name: <skill-name>
description: |
  One-paragraph description. Must include:
  - USE FOR: list of trigger scenarios
  - DO NOT USE FOR: explicit anti-triggers (prevent wrong activation)
  - Triggers: comma-separated phrases that should activate this skill
---
```

**Scoring criteria** (higher is better):
| Score | Criteria |
|---|---|
| Low | Description only |
| Medium | Description > 150 chars, has trigger keywords |
| High | Has USE FOR + DO NOT USE FOR + Triggers list |

---

## Naming Convention

| Asset | Pattern | Example |
|---|---|---|
| AIS integration skills | `ais-<domain>-<function>` | `ais-logicapp-codegen` |
| TIBCO conversion skills | `tibco-azure-<phase>` | `tibco-azure-converter` |
| Cross-cutting skills | `ais-<function>` | `ais-code-review` |

---

## Skill Body Structure (AIS Integration Skills)

Follow this section order:

1. **Title** — `# Skill Name`
2. **Required Inputs** — what the agent must have before proceeding
3. **Workflow** — numbered steps, each with a clear action
4. **Patterns / Code Examples** — concrete examples with AIS naming
5. **Coding Rules** — numbered list of constraints and conventions
6. **References** — table linking to `references/*.md` files

---

## Step-by-Step: Creating a New Skill

### Step 1 — Define Scope

Answer these questions before writing:

- What does this skill produce? (code / doc / test cases / review report)
- What triggers it? (list 4–6 specific phrases)
- What must NOT trigger it? (list exclusions for the DO NOT USE FOR section)
- Does a reference template already exist in `reference-templates/` or `outputs/`?

### Step 2 — Create the File

```
.github/skills/<skill-name>/SKILL.md
```

Start with frontmatter, then the body following the section order above.

### Step 3 — Add Reference Assets (if needed)

For patterns too long for SKILL.md, create `references/<topic>.md`.
For boilerplate templates, create `assets/<template-name>`.

Reference them at the bottom of SKILL.md:

```markdown
## References
- [Pattern Name](references/<topic>.md)
- [Template Name](assets/<template>.json)
```

### Step 4 — Register the Skill

Add the skill to `.github/copilot-instructions.md` under the appropriate section:

```markdown
<skill>
<name>your-skill-name</name>
<description>Trigger description for VS Code skill routing</description>
<file>.github/skills/your-skill-name/SKILL.md</file>
</skill>
```

### Step 5 — Update AGENTS.md

Add a row to the **AIS Integration Skills** table in `AGENTS.md`:

```markdown
| `your-skill-name` | "trigger phrase" | Brief description |
```

### Step 6 — Update README.md

Add a row to the Skill Catalog table in `README.md`.

---

## Creating a New Agent Persona — prefer a SKILL.md instead

The old `.github/agents/<agent-name>.agent.md` pattern is **archived**
(`archive/github-agents-superseded-by-skills/`, 2026-09-19) — nothing in
`.github/copilot-instructions.md` or the portal wires that folder into Copilot Chat's actual
skill-discovery path, and the archived files had drifted out of sync with the real pipeline
(stale `outputs/`-for-code guidance, stale .NET version). **Create a new `SKILL.md` under
`.github/skills/<skill-name>/` instead** (see "Creating a New Skill" above) and register it in
`.github/copilot-instructions.md`'s `<skill>` list — that is the only path Copilot Chat actually
follows when a user pastes a portal prompt.

---

## Creating a New Prompt Template

Prompt files live at `.github/prompts/<prompt-name>.prompt.md`.
They power VS Code slash commands (e.g., `/code-review`, `/document`).

```markdown
---
mode: agent
description: Brief description of what this prompt does
---

# Prompt Title

[Instructions for the prompt — written as if talking to the agent]
```

---

## Anti-Patterns

| Don't | Why |
|---|---|
| Put "when to use" guidance in the body | Body loads AFTER triggering — too late |
| Create skills with overlapping trigger phrases | Causes wrong skill activation |
| Hardcode environment paths in skills | Skills must work across machines and users |
| Skip the DO NOT USE FOR section | Without exclusions, skills activate in wrong contexts |
| Make SKILL.md over 500 lines | Split long sections into `references/` files |
| Duplicate existing skills | Extend the existing skill with a `references/` file instead |

---

## Checklist

Before committing a new skill:

- [ ] Frontmatter includes `name`, `description` with USE FOR / DO NOT USE FOR / Triggers
- [ ] Description > 150 characters
- [ ] SKILL.md under 500 lines
- [ ] No hardcoded machine paths
- [ ] Skill registered in `.github/copilot-instructions.md`
- [ ] Entry added to `AGENTS.md` skill catalog
- [ ] Entry added to `README.md` skill catalog
