---
name: ais-codegen-readiness
description: |
  Metcash AIS codegen readiness gate. USE FOR: the step between an approved TSD and any code
  generation skill — resolves target repo, resource name(s), field-level mapping cross-check
  against the raw Mapping Manifest, and (for interfaces with a legacy TIBCO implementation) a
  cross-check against the actual TIBCO source. Runs the SAME propose/evidence/gap/stop pattern
  as metcash-tsd-generator's own intake-questionnaire, scoped to codegen's specific needs.
  MANDATORY PREREQUISITE for ais-logicapp-codegen, ais-functionapp-codegen, and
  ais-datafactory-codegen whenever a TSD already exists — replaces ais-design-intake for that
  path (ais-design-intake is still used when NO TSD exists at all).
  DO NOT USE FOR: generating code directly, or when no TSD exists yet (use ais-design-intake
  or metcash-tsd-generator first).
  Triggers: "ready to generate code", "codegen readiness", "resolve repo and resource name",
  "before generating code from TSD", "TSD approved, what's next".
---

# AIS Codegen Readiness — the gate between an approved TSD and code generation

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — read it before Step 1 (a resumed session may already have partial
> answers), and update the Repo/Branch section + this phase's row once the questionnaire is
> approved and the clone/branch exist.

Closes the gap between "the TSD is approved" and "code generation can safely start" — a TSD can
be fully approved while still carrying open TBCs (e.g. "confirm resource name with DevOps") that
must not be silently carried into generated code. This skill surfaces and resolves them using
the same disciplined pattern already proven for TSD generation itself.

## When to Use This Skill

- A TSD already exists and is approved (`tsd/<EAII-ID>/*.md`) and the user wants to move to
  code generation
- Replaces `ais-design-intake` for this path — do not run both

## When NOT to Use This Skill

- No TSD exists yet — run `metcash-tsd-generator` first, or `ais-design-intake` for the
  FSD-only path (no TSD, never will be one for this interface)
- Generating the code itself — that's `ais-logicapp-codegen` / `ais-functionapp-codegen` /
  `ais-datafactory-codegen`, invoked only after this questionnaire is approved

---

## ⛔ Mandatory Pre-condition

| Check | Condition | Action |
|---|---|---|
| ADO MCP + GitHub MCP verified | Both confirmed reachable per [`azure-local-auth`'s pre-flight check](../azure-local-auth/SKILL.md#-mandatory-pre-flight-check--required-before-generating-a-tsd-generating-code-or-generating-unit-test-cases) | **Stop** and run that check first if either is unverified — do not resolve a repo/resource name or run the Step 4 TIBCO cross-check on unverified access |
| Approved TSD present | `tsd/<EAII-ID>/*.md` exists | Continue |
| TSD not yet approved/still in questionnaire | `tsd-inputs/<EAII-ID>/intake-questionnaire.md` exists but not yet approved | **Stop.** Ask the user to approve the TSD questionnaire first — this skill assumes a settled TSD, not a draft |
| No TSD at all | Neither exists | **Stop.** Direct to `metcash-tsd-generator` (if a TSD should exist) or `ais-design-intake` (if it genuinely won't) |

---

## Inputs Consulted (read directly — do not re-ask the user for these)

| Input | Source | Always needed? |
|---|---|---|
| The approved TSD | `tsd/<EAII-ID>/*.md` | Always |
| The raw Mapping Manifest | `tsd-inputs/<EAII-ID>/converted/MAP-EAII-<ID>/` | Always — the TSD prose *summarizes* this; codegen needs the full field-level detail |
| The TSD's own questionnaire | `tsd-inputs/<EAII-ID>/intake-questionnaire.md` | Always — specifically any item still marked TBC |
| `code-corpus/` (repo mapping + patterns) | `code-corpus/index.md` and `patterns/*.md` | Always — to propose a repo/resource-name answer from real evidence |
| Legacy TIBCO source, via GitHub MCP | The repo the TSD names, per `tibco-azure-nfr-recommendation`'s existing read pattern (README → root listing → relevant `.process`/`.bwp` files only) | **Only if** the TSD's own Background/Design Considerations names a legacy TIBCO implementation — detect by searching the TSD text for `TIBCO`, `.bwp`, or `BusinessWorks` |

## Workflow

### Step 1 — Read everything above

Read the approved TSD in full, the raw Mapping Manifest, and the TSD's own questionnaire.
Search the TSD text for a legacy TIBCO mention; if found, note which repo/files it points to.

### Step 2 — Resolve the target repo and resource name(s)

Search `code-corpus/index.md` for a sibling interface sharing this interface's workload token
(e.g. the TSD's own naming-convention token, or an explicit §9.3 recommendation). Propose the
existing repo if one is found. If none is found, propose a new repo name following
`Metcash.AIS.{Platform}.{Service}` and say so explicitly — do not silently invent an existing
repo that doesn't actually appear in the corpus.

Before cloning or creating a branch, use `vscode_askQuestions` inline to present the proposed
repo, branch, resource names and any TSD/code-corpus discrepancy. Include the source/evidence for
each proposal and let the user confirm, correct, or leave it unresolved. If the user cannot
confirm a blocking repo/resource choice, stop; do not clone, branch, or hand off to codegen.

Propose resource name(s) (Function/workflow/pipeline name) from `squad20-naming-conventions`
applied to the interface name, cross-checked against any sibling resource already in the target
repo (read the repo's actual folder structure, matching Step 1 of the relevant `ais-*-codegen`
skill).

**Get (or refresh) a real local clone of the target repo — code is never generated into a
scratch folder.** Once the repo is resolved (proposed or confirmed):

1. Check whether `C:\Users\jagae\source\repos\<TargetRepoName>` already exists locally.
   - Exists: `git -C "C:\Users\jagae\source\repos\<TargetRepoName>" fetch origin`. If the
     working tree isn't clean, **stop and ask** before touching it — never branch over
     uncommitted changes silently.
   - Doesn't exist: clone it there —
     `git clone https://METCASHDevOps@dev.azure.com/METCASHDevOps/Squad%2020/_git/<TargetRepoName> "C:\Users\jagae\source\repos\<TargetRepoName>"`
     (same command pattern already used for every `code-corpus/` reference clone this session —
     Git Credential Manager handles auth against the cached `dev.azure.com/METCASHDevOps`
     credential, no PAT needed).
   - If an existing sibling clone is on a different branch (e.g. a personal feature branch, like
     the real `Metcash.AIS.Data.Metproducts` clone found on `feature/eai254` this session), do
     **not** touch it — clone a second copy under `<TargetRepoName>-main` instead, exactly as
     done for `Metcash.AIS.Data.Metproducts-main` and `Metcash.AIS.B2C.Datafactory-main`.
2. Create the feature branch off `main`: `feature/EAII-<number>-<short-description>`, per
   `azure-devops-repository-pr`'s existing naming convention. If it already exists locally from a
   prior run of this interface, check it out instead of recreating it.
3. Record the resolved local path and branch name in the questionnaire (§1) — this is what
   `ais-*-codegen` skills write into.

### Step 3 — Field-level mapping cross-check

Compare the TSD's summarized field-mapping table against the raw Mapping Manifest row by row.
For any missing or conflicting field, show the candidate interpretation and the TSD/Manifest
evidence in an inline `vscode_askQuestions` round; allow confirm, correction, or blocked. Record
the answer/provenance in the readiness questionnaire. Never let a downstream codegen skill
silently pick one source over the other.

### Step 3.5 — Network connectivity pre-check (via Kudu, from any sibling host in the same ASE v3)

**Squad 20's Function Apps and Logic Apps all run inside a shared, privately-hosted App Service
Environment v3 (ASE v3, ILB) per environment** — every host in the same environment shares the
same VNet/subnet egress path. This means the Kudu connectivity check is **not limited to
extending an existing host** — even when Step 2 resolved a brand-new host (one that doesn't
exist yet), pick **any already-deployed sibling Function App or Logic App in the same
environment** (e.g. an existing host in the same resource group / domain) and run the check from
its Kudu (SCM) endpoint instead. The result is equally valid evidence of whether the target
endpoint is reachable from that ASE v3, because the new host will land on the same shared
network path once deployed.

Only skip this step entirely if **no sibling host exists anywhere in the target environment yet**
(e.g. the very first interface ever deployed into a brand-new ASE v3) — that is genuinely rare;
in that case, add a note to the questionnaire that connectivity must be verified post-deployment
instead (cross-reference `ais-deployment-runbook`'s existing firewall-opening checks). Do not
conflate "the target Function App doesn't exist yet" with "the check can't be performed" — they
are different conditions.

1. Extract the target endpoint(s) and port(s) from the TSD (default `443` for HTTPS if the TSD
   doesn't state a port explicitly).
2. Pick the proxy host: if extending an existing host, use it directly; if the target host is
   new, pick any existing Function App or Logic App already deployed in the same environment/
   resource group (check `code-corpus/index.md` or the relevant `t3-met-ais-{env}-ae1-rsg-*`
   resource group for a candidate) and note in the questionnaire which sibling host was used as
   the proxy and why it's a valid stand-in (same ASE v3 / same environment).
3. Determine the proxy host's OS:
   `az functionapp show --name <app> --resource-group <rg> --query kind -o tsv` (or
   `az webapp show` for a Logic App Standard host) — `"functionapp,linux"` vs `"functionapp"`.
4. Get Kudu (SCM) credentials:
   `az functionapp deployment list-publishing-credentials --name <app> --resource-group <rg> --query "{u:publishingUserName,p:publishingPassword}" -o json`
   (the `webapp` equivalent for a Logic App Standard host). **If this fails** — some orgs disable
   SCM Basic Auth publishing credentials by policy — say so explicitly and record the check as
   "not performed — SCM basic auth disabled" in the questionnaire; do not silently skip it.
5. Run the check via the Kudu command API, `POST https://<app>.scm.azurewebsites.net/api/command`
   with Basic auth from step 4:
   - **Windows-hosted:** body `{"command": "tcpping <endpoint-host>:<port>", "dir": "site\\wwwroot"}`
     — `tcpping.exe hostname[:port]` is a Kudu-bundled diagnostic tool (defaults to port 80 if
     unspecified; always specify the port explicitly here).
   - **Linux-hosted:** body `{"command": "nc -zv -w5 <endpoint-host> <port> || echo UNREACHABLE", "dir": "/home/site/wwwroot"}`.
5. Parse the response body for success (`tcpping`: a connect message with round-trip time; `nc`:
   `succeeded` on stderr/stdout) vs. failure/timeout. Record the result — **Pass** / **Fail** /
   **Not tested (new host)** / **Not performed (SCM auth disabled)** — in the questionnaire's
   Network Connectivity Pre-Check section.
6. **A Fail is a blocking gap (§7, kind A)** — codegen must not proceed until network/firewall
   access is confirmed by the network team or explicitly waived by the user. Do not treat a
   failed connectivity check as a warning to note and move past.

### Step 4 — TIBCO source cross-check (if applicable)

If a legacy TIBCO implementation was found in Step 1, use the GitHub MCP read pattern already
established in `tibco-azure-nfr-recommendation` to read the specific `.bwp`/`.process` files the
TSD's own gaps point at (e.g. an endpoint-count or field-mapping question left open in the TSD's
questionnaire). Compare against the FSD/TSD's stated behavior. If GitHub MCP isn't reachable,
say so explicitly — never silently skip this cross-check.

### Step 5 — Carry forward the TSD's own open TBCs

Copy every TBC from the TSD's questionnaire that's relevant to codegen (not architecture
already-settled items) into this questionnaire, with a proposed resolution where evidence now
allows one.

### Step 6 — Produce the Questionnaire and Stop

Fill [`templates/codegen-readiness-questionnaire.template.md`](templates/codegen-readiness-questionnaire.template.md)
and write to `outputs/<EAII-ID>/codegen-readiness-questionnaire.md`. **Stop.** Do not invoke any
codegen skill until the user explicitly approves it.

### Step 7 — Hand off

Once approved, invoke the codegen skill(s) indicated by the TSD's architecture archetype. Pass
the approved questionnaire's resolved repo (**local clone path and feature branch**, not just a
name), resource name(s), and field mappings as settled fact — codegen skills must not re-ask
for them, and must write generated files into that clone, not into `outputs/<EAII-ID>/`.

---

## Anti-Patterns — Never Do These

- Do NOT invent a repo or resource name when the corpus has no real precedent — propose a new
  repo explicitly and say so, or surface it as a gap.
- Do NOT skip the TIBCO cross-check just because GitHub MCP might be slow or unavailable —
  state the failure and carry it forward as an open gap instead.
- Do NOT run this skill AND `ais-design-intake` for the same interface — pick the one that
  matches whether a TSD exists.
- Do NOT let a codegen skill start before this questionnaire is explicitly approved.
- Do NOT generate code into `outputs/<EAII-ID>/` — that folder is documents only. Code goes into
  the real repo clone resolved in Step 2.
- Do NOT auto-commit or auto-push the branch created in Step 2 — leave it as local, uncommitted
  changes for the user to review; committing/pushing/PR-raising is a separate, explicit action.
- Do NOT treat a failed Kudu connectivity check (Step 3.5) as a warning — it's a blocking gap.
- Do NOT skip the Step 3.5 connectivity check just because the target host is brand new — use an
  existing sibling host in the same ASE v3/environment as the proxy instead; only skip when
  genuinely no sibling host exists anywhere in that environment yet.
- Do NOT branch over an existing clone with uncommitted changes without asking first.

## References

- [`code-corpus/index.md`](../../../code-corpus/index.md) — real repo mapping used in Step 2
- [`code-corpus/patterns/`](../../../code-corpus/patterns/) — real code patterns referenced when checking existing hosts
- [Codegen Readiness Questionnaire Template](templates/codegen-readiness-questionnaire.template.md)
- [metcash-tsd-generator's intake-questionnaire.template.md](../metcash-tsd-generator/templates/intake-questionnaire.template.md) — the pattern this skill extends
