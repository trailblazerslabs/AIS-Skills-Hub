# Codegen Readiness Questionnaire — {EAII-IDs} — {InterfaceName}

Generated: {date} | Status: **AWAITING YOUR APPROVAL — code generation is paused**

Every item below already has a **proposed answer**, worked out from the approved TSD, the raw
Mapping Manifest, the TSD's own questionnaire, `code-corpus/`, and (where the TSD names a legacy
TIBCO implementation) the actual TIBCO source. Review each one:

- Agree with a proposal? Leave it as-is.
- Disagree? Edit the `Proposed:` line directly with your answer.

Then tell the agent the questionnaire is approved. **Code generation will not start until you
do —** proposed answers are recommendations, not silent defaults the agent will act on
unattended, and a missing repo or resource name is never guessed.

---

## 1. Target Repository

**Proposed:** {repo name}

**Why:** {evidence — TSD §9.3 repo recommendation, or a sibling interface sharing the same
workload token per `code-corpus/index.md`'s real repo mapping, or "no existing repo covers this
workload — recommend a new repo `Metcash.AIS.{Platform}.{Service}`"}

**Local clone:** `C:\Users\jagae\source\repos\{TargetRepoName}` — {existing clone reused / fresh
clone created}

**Branch:** `feature/EAII-{number}-{short-description}` — {created off latest main / already
existed, checked out}

> If no confident repo evidence exists, this becomes a **gap** in §7, not a guess — never invent
> a repo name here. Code generation writes into this clone, never into `outputs/`.

---

## 2. Resource Name(s)

**Proposed:** {Function name} / {Logic App workflow name} / {ADF pipeline name} (whichever apply)

**Why:** {naming convention from `squad20-naming-conventions` applied to the interface name from
the TSD/FSD, and any existing sibling resource name pattern found in the target repo}

---

## 3. New or Existing Host?

**Proposed:** {extend the existing `<host>` Function App / Logic App workspace in the target
repo} or {new host required — no existing host covers this workload}

**Why:** {what was actually found when Step 1 of the relevant `ais-*-codegen` skill read the
target repo}

---

## 3.5 Network Connectivity Pre-Check

*Squad 20's Function Apps/Logic Apps all run inside a shared, privately-hosted App Service
Environment v3 (ASE v3, ILB) per environment — this check can be run from ANY existing sibling
host in the same environment, not only when §3 resolved an existing host. Only omit this section
entirely if no sibling host exists anywhere in the target environment yet.*

**Target endpoint(s):** {host:port, from the TSD — default 443 if the TSD doesn't state a port}

**Tested from:** {existing Function App / Logic App name} ({Windows / Linux}-hosted, via Kudu) —
{state whether this is the target host itself (extending an existing host) or a **sibling proxy
host** used because the target host is new, and why that sibling is a valid stand-in (same ASE
v3 / same environment)}

**Result:** **Pass** / **Fail** / **Not tested (no sibling host exists yet in this environment —
verify post-deployment per `ais-deployment-runbook`)** / **Not performed (SCM basic auth
disabled)**

**Evidence:** {raw `tcpping`/`nc` output}

> A **Fail** here is a blocking gap (see §7) — do not proceed to code generation until
> network/firewall access is confirmed or explicitly waived by the user.

---

## 4. Field-Level Mapping Cross-Check

Confirms the TSD's summarized mapping table matches the **raw** Mapping Manifest exactly — the
TSD prose is a summary; codegen needs the full field-level detail.

| Source Field | Target Field | Transformation | Matches TSD §5.x.6.3.7? |
|---|---|---|---|
| {field} | {field} | {rule} | Yes / **Discrepancy — see below** |

> Any row marked "Discrepancy" must be resolved here (state which source wins and why) before
> codegen proceeds — never let a generator silently pick one.

---

## 5. Legacy TIBCO Source Cross-Check

*Only include this section if the TSD's own Background/Design Considerations names a legacy
TIBCO implementation (search for "TIBCO"/".bwp"/"BusinessWorks"). Omit entirely otherwise.*

**TIBCO source consulted (via GitHub MCP):** {repo, file(s) — e.g.
`ProcessProductRecords.bwp`, `getOpenidToken.bwp`}

**Findings vs. the FSD/TSD's stated behavior:**

| Topic | FSD/TSD states | TIBCO source shows | Resolution |
|---|---|---|---|
| {topic, e.g. endpoint count} | {stated value} | {actual value found in source, or "GitHub MCP unreachable — not verified"} | {which is authoritative, or carried to §7 as a gap} |

> If GitHub MCP isn't reachable, say so explicitly here and carry the item to §7 as a gap —
> never silently skip the cross-check.

---

## 6. Carried-Forward TBCs from the TSD Questionnaire

Every item the TSD's own `intake-questionnaire.md` left as TBC/open that specifically blocks
code generation. Copy the item verbatim from the TSD questionnaire, then propose a resolution.

| From TSD Questionnaire | Original TBC | Proposed resolution |
|---|---|---|
| {e.g. Q2} | {e.g. "Exact existing resource name to confirm with DevOps"} | {resolution, or carried to §7 if still unresolved} |

---

## 7. Open gaps blocking codegen sign-off

Mandatory section — never omit it, even with only one or two rows. Split into the same two
kinds as the TSD questionnaire:

- **(A) Source-unresolved** — a TBC that's still genuinely open after checking every available
  source (TSD, raw Manifest, TIBCO source, code-corpus).
- **(B) Agent-identified** — a gap noticed while cross-reading these sources together that
  nobody flagged explicitly.

| # | Kind | Item | Detail | What's needed to close it |
|---|---|---|---|---|
| G1 | (A) | {item} | {detail} | {e.g. "Confirm with DevOps before Stage 2 starts"} |

---

## 8. Anything else the developer should know

Free text — naming preferences, known risks specific to build, non-standard environments, etc.

> _______________

---

*Review the proposals above, edit anything you disagree with, then tell the agent "questionnaire
approved" (or similar) to start code generation. The agent will not proceed on its own — this
pause is mandatory.*
