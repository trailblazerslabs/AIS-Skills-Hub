---
name: ais-deployment-runsheet
description: |
  Metcash AIS Deployment Runsheet guide. USE FOR: creating, understanding, or updating a
  Confluence deployment runsheet for any AIS interface across any environment (ST1, UT1, SIT,
  PRD). Covers page structure, all mandatory sections, login and access prerequisites, resource
  naming per environment, status macro conventions, and end-to-end checklist for a successful
  deployment. DO NOT USE FOR: generating Logic App or Function App code (use ais-logicapp-codegen
  or ais-functionapp-codegen), ADF pipeline generation (use ais-datafactory-codegen), or code review.
  Triggers: "deployment runsheet", "how to deploy", "runsheet", "deployment checklist",
   "how to run deployment", "deployment guide", "what do I need to deploy", "deployment page",
   "create runsheet", "PRD readiness runbook", "production readiness review".
---

# AIS Deployment Runsheet

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — confirm code review and testing phases are actually Done before
> planning a deployment; flag it if this would run ahead of an incomplete phase. Update Phase
> 10's row on completion.

This skill describes the structure, prerequisites, and step-by-step content of an AIS
interface deployment runsheet (Confluence page). It is environment-agnostic — the same
structure applies to ST1, UT1 (UAT), SIT, and PRD deployments.

---

## Required Inputs

Before creating or running a deployment runsheet, confirm you have:

| Input | Where to Find |
|---|---|
| EAII ID | ADO work item (format: `EAII-{number}`) |
| Target environment | ST1 / UT1 / SIT / PRD |
| Interface resource names | Squad 20 naming conventions skill |
| Change Request number | ServiceNow / ADO (can be TBD pre-approval) |
| Deployment start/end dates | Sprint/release calendar |
| Author, Implementers, Reviewers | Team roster |
| Approved TSD and revision | Controlling design for scope, architecture, environment resources, security, support and promotion requirements |
| Current application code and promotion evidence | TSD-mapped repository, refreshed `origin/main` SHA, pipeline YAML, target branch/artifact/build ID and pipeline run evidence |
| Deployment mode | Confirm first deployment to this environment or update/redeployment of an existing interface; for redeployment, identify the deployed artifact/revision and current rollback target |
| Shared personnel roster | Approved Metcash/DevOps production roster identified by the user; preserve its exact person names and role labels. `{{TMSDeveloperFullName}}` is the only variable roster entry unless the user explicitly changes this rule. |

Use the approved TSD for intended behavior and the current repository for implemented deployment mechanics. `origin/main` is the comparison baseline, not automatically the artifact being promoted. If the TSD and code disagree, record the difference, impact, owner and decision in the runsheet; do not silently choose one.

Before filling action tables, follow the mandatory inline intake gate below. When the user designates a shared Metcash/DevOps production roster, carry its exact names and role labels forward without substituting other people; replace only `{{TMSDeveloperFullName}}` with the assigned developer's exact full name. Do not copy environment-specific resources, dates, change records, pipeline actions or historical statuses from that example. Every action row's `Escalations/Instructions` cell must be populated: use a specific instruction/evidence owner, or `N/A — <reason>` when genuinely not applicable; use `TBD — <owner/decision required>` when unknown. Never leave it blank.

If the approved shared roster source has not been identified, ask the user to identify it; do not
create or substitute person/role entries. Once the fixed roster is evidenced, ask only for the
assigned developer's exact full name unless the user explicitly changes the roster rule.

### Mandatory Inline Intake Gate — Before Runsheet Generation

1. Read `outputs/<EAII-ID>/status.md` first. Inspect the approved TSD, the current target repository and pipeline YAML, the latest same-interface/environment runsheet, the approved shared roster designated by the user, and any existing deployment/change evidence. Record the source revision, commit SHA, page version, or build ID where available. Do not treat `origin/main` as the artifact being promoted.
2. Identify only material facts that remain missing, ambiguous, or conflicting after that review. These normally include target environment and first-deployment/redeployment mode; change request/window; exact promotion branch, immutable artifact/build ID and successful run; each independently deployed application/APIOps/IaC component and pipeline; current environment/rollback target; code review/build/test readiness; access and infrastructure evidence; and the assigned developer's exact full name. Do not re-ask facts already established by approved evidence. Do not request roster names already fixed by the user-designated shared roster.
3. Use `vscode_askQuestions` inline for those gaps. State the proposed answer, evidence/source, confidence or conflict, and impact; let the user confirm, correct, or choose unknown/keep blocked. Batch independent questions and ask dependent questions in sequence. Never present an unsupported guess as a proposed fact. An unanswered question is not approval.
4. Record each proposal, evidence, user answer/correction, provenance, and remaining blocker in `outputs/<EAII-ID>/runsheet-intake-questionnaire.md`, using [`templates/runsheet-intake-questionnaire.template.md`](templates/runsheet-intake-questionnaire.template.md). If the question tool is unavailable, ask in chat and stop.
5. Stop if any required fact remains unknown or conflicting. Once all required answers are recorded, stop for explicit user approval of the intake questionnaire before generating the runsheet or creating/updating a Confluence page. Approval authorizes only the named runsheet draft/scope; it does not authorize ADO/Confluence writes, pipeline execution, or deployment. A directly authorized local quality-evaluation exception may create only a clearly labelled local draft and does not waive any operational approval gate.

### Local Quality-Evaluation Exception

Only when the user explicitly requests a local quality evaluation, a draft TSD may be used as an evaluation input. Label the output `LOCAL QUALITY-EVALUATION DRAFT — NOT DEPLOYMENT APPROVAL`, mark unverified operational inputs `TBD/BLOCKED`, and save it as a local document. This exception does not satisfy TSD approval, codegen readiness, environment-specific runsheet review, or PRD readiness; it never authorizes Confluence/ADO writes, pipeline execution, or deployment.

## Mandatory Review Gates — before deployment

Create and review a separate environment-specific runsheet for SIT, UAT/UT1, and PRD. Before
each deployment, fill
[`review-gates/templates/deployment-runsheet-review.template.md`](../../../review-gates/templates/deployment-runsheet-review.template.md)
and save it as `outputs/<EAII-ID>/deployment-runsheet-review-<ENV>.md`. Review the actual
Confluence runsheet revision and evidence; a drafted page or un-fetched example is not a pass.

The mandatory readiness checklist must score 100% of applicable items, with each N/A justified,
all named reviewers signed, and no unresolved Critical/High finding. Below 100%, missing build or
test evidence, or any mandatory blocker means **BLOCKED**. Stop for explicit environment-specific
approval before triggering or authorizing that environment's deployment. An SIT approval does
not approve UAT or PRD.

### Additional PRD Runbook Gate

Before deploying to PRD **or** marking the interface “Ready for PRD”, complete
[`templates/prd-deployment-readiness-runbook.template.md`](templates/prd-deployment-readiness-runbook.template.md)
as `outputs/<EAII-ID>/prd-deployment-readiness-runbook.md`. The PRD runbook must reference the
approved TSD and review, code/build/check report, unit-test status, SIT and UAT/UT1 execution
results, PRD artifact SHA, change request, operational monitoring, cut-over and rollback
procedure. It must score 100% of applicable mandatory checks with no unresolved Critical/High
finding and receive named reviewer sign-off. Otherwise record **NO-GO**.

“Ready for PRD” is a readiness disposition, not permission to deploy. PRD execution requires a
separate explicit authorization for the named artifact, change request, and deployment window.

---

## Access & Login Prerequisites

Every team member participating in a deployment must have the following before the
start date:

### Azure Access
- **Metcash Azure Dev Box** — primary workstation for all Azure operations.
  Log in at: `https://devbox.microsoft.com` using your Metcash SSO credentials.
- **Azure Portal** — `https://portal.azure.com` — for validating Key Vault secrets,
  RBAC assignments, Storage Account tables, ADF pipeline runs, and Function App configs.
- **Azure CLI / PowerShell Az module** — for scripted RBAC and IAC operations.

### ADO Access (Azure DevOps)
- Organisation: `https://dev.azure.com/METCASHDevOps`
- Access required to: run IAC release pipelines, ALM (deployment) pipelines, DB pipelines.
- Verify you can see and trigger pipelines in the Squad 20 project before the deployment day.

### Confluence Access
- Organisation: `https://metcash.atlassian.net`
- Edit rights on the MAP space — required to update runsheet statuses live during deployment.
- Page location: `MAP > [Domain] > Extended Product Info` (or relevant interface parent page).

### Service Bus / Storage
- Access to the `t1-met-npr-ae-sb-001` (non-prod) or `t1-met-prd-ae-sb-001` (prod)
  Service Bus namespace via Azure Portal to validate queue creation and MSI access.
- Access to the relevant Storage Account for table/blob operations.

### SQL / Database
- SQL access to `b2b-integration-{env}-sqldb` via the Azure Dev Box or SSMS.
- AD group membership for `b2b_db_datareader_{env}` and related roles must be confirmed
  before deployment starts.

### SMC (Observability Platform)
- SMC UAT or SMC PROD portal access to register interfaces and validate logs post-deployment.
- Subscription key (`SMC-Ocp-Apim-Subscription-Key`) must be available as a Key Vault secret.

---

## Environment → Resource Name Mapping

All resource names follow the Squad 20 naming convention. Substitute `{env}` as shown:

| Component | ST1 | UT1 (UAT) | SIT | PRD |
|---|---|---|---|---|
| ADF | `t3-met-ais-st1-ae-adf-b2b-01` | `t3-met-ais-ut1-ae-adf-b2b-01` | `t3-met-ais-sit-ae-adf-b2b-01` | `t3-met-ais-prd-ae-adf-b2b-01` |
| B2B Storage Account | `t3b2b{env}aesta01` | `t3b2but1aesta01` | `t3b2bsitaesta01` | `t3b2bprdaesta01` |
| Product Info Storage Account | `t3productinfo{env}aesta01` | `t3productinfout1aesta01` | `t3productinfositaesta01` | `t3productinfoprdaesta01` |
| B2B Key Vault | `t3b2b{env}ae1kv01` | `t3b2but1ae1kv01` | `t3b2bsitae1kv01` | `t3b2bprdae1kv01` |
| Enabling Key Vault | `t3enabling{env}ae1kv01` | `t3enablingut1ae1kv01` | `t3enablingsitae1kv01` | `t3enablingprdae1kv01` |
| Blob Mgmt Function App | `t3-met-enabling-blobmgmt-{env}-ae-func` | `t3-met-enabling-blobmgmt-ut1-ae-func` | `t3-met-enabling-blobmgmt-sit-ae-func` | `t3-met-enabling-blobmgmt-prd-ae-func` |
| Cloudinary Function App | `t3-met-cloudinary-{env}-ae-func` | `t3-met-cloudinary-ut1-ae-func` | `t3-met-cloudinary-sit-ae-func` | `t3-met-cloudinary-prd-ae-func` |
| SQL Database | `b2b-integration-{env}-sqldb` | `b2b-integration-ut1-sqldb` | `b2b-integration-sit-sqldb` | `b2b-integration-prd-sqldb` |
| DB Roles | `b2b_db_*_{env}` | `b2b_db_*_ut1` | `b2b_db_*_sit` | `b2b_db_*_prd` |
| Service Bus (send) | `b2b.{interface}.sv.{env}.sbq` | `*.sv.ut1.sbq` | `*.sv.sit.sbq` | `*.sv.prd.sbq` |
| Service Bus (monitor) | `b2b.{interface}.sm.{env}.sbq` | `*.sm.ut1.sbq` | `*.sm.sit.sbq` | `*.sm.prd.sbq` |
| Service Bus Namespace (non-prod) | `t1-met-npr-ae-sb-001` | — | — | — |
| Service Bus Namespace (prod) | — | — | — | `t1-met-prd-ae-sb-001` |

---

@@
## Derive the Runsheet from the TSD and Current Code

Use the approved TSD as the design authority and the refreshed interface repository as implementation evidence. For combined TSDs, repeat the mapping per EAII ID and identify shared components separately.

| Runsheet content | TSD source | Current-code evidence |
|---|---|---|
| Interface identity, scope, source/target, exclusions | TSD §§1–2 and each `§5.x` interface subsection | Repository/workspace identity and interface-specific workflow, function, or pipeline paths |
| Components, executable sequence, dependencies | TSD `§5.x.2`, `§5.x.6.1–§5.x.6.2` | Current workflow/function entry points and deployment YAML stages; derive actual build/deploy order here |
| SMC, monitoring, error handling and test scenarios | TSD `§5.x.6.3`, `§5.x.7–§5.x.10` | Code logging/error paths, test projects and pipeline steps; test scenarios are not test execution evidence |
| Network, identity, secrets, RBAC and infrastructure | TSD `§6.2–§6.5` | Current resource/configuration paths and IaC/pipeline references; include setting names only, never secret values |
| Communications and data handling/retention | TSD `§7` and applicable `§8` subsections | Code storage paths, lifecycle/deletion behavior, support/monitoring configuration |
| Promotion and environment migration | TSD `§9` | Pipeline YAML, branch/stage conditions, parameters, variable-group references, build artifact packaging and actual run evidence |

The TSDs may say only “standard CI/CD” or retain an open item after a repository/pipeline exists. Record that as a TSD-to-code discrepancy and obtain an owner decision; do not copy the generic statement as the implementation sequence. Refresh `origin/main` and record its SHA/date, but separately record the approved promotion branch, immutable artifact/build ID and actual pipeline run. A main commit or a PRD-looking configuration file alone does not prove deployment.

For each deployment, enumerate every independently promoted component: application, APIOps/API, and infrastructure/IaC where applicable. Map each to its own repository, pipeline definition/YAML, environment stage, artifact/build ID, run and approval evidence. An application build does not prove APIM or infrastructure deployment. If a required repository or run is unavailable, mark that component `TBD/BLOCKED`; do not infer it from another pipeline.

## Runsheet Page Structure

A deployment runsheet Confluence page must contain the following sections in order:

```
1. Overview (info panel)
2. Release Note
3. Review and Approval Matrix
4. Pre-Checks
   4a. 🛠️ Infra Setup  (IS-x table)
   4b. Actions         (numbered action table)
   4c. Communications
5. Implementation
   5a. Actions         (numbered action table)
   5b. Communications
6. Post-Implementation
   6a. Actions         (numbered action table)
   6b. Communications
7. Rollback
   7a. Actions
   7b. Communications
8. Contact
```

---

## Section Details

### 1. Overview Panel

A structured info table at the top of the page with these fields:

| Field | Value |
|---|---|
| Title | `EAII - {number} - {Interface Name} - {ENV} Deployment Runsheet` |
| Change Request | TBD (update before deployment) |
| Change Type | Standard (Blue badge) |
| Environment | `{ENV}` (coloured badge: Purple=ST1/UT1, Yellow=SIT, Red=PRD) |
| Summary | `Deploy EAII-{number} {Interface Name} to {ENV} environment.` |
| Start Date / End Date | Per deployment schedule |
| Version | `1.0` |
| Author | Page creator |
| Implementers | Team members executing the deployment |
| Reviewers | Tech Lead / Architect |
| Change Approvers | Populated before PRD only |
| Informed Stakeholders | Business owner / product owner |

---

### 2. Release Note

Free-text description of what is being deployed:
- Interface IDs and names
- Brief description of integration (source → destination)
- Key components: ADF pipelines, Function Apps, SQL objects, Storage tables

---

### 3. Review and Approval Matrix

Table with columns: **Name | Role | Review Date | Approval Date | Notes**

Mandatory reviewers: Tech Lead, Solution Architect, and a second developer.

---

### 4a. Pre-Checks — Infra Setup (IS-x Table)

A 6-column table: **IS-# | Component | Action | Dependency | Team | Status**

Standard IS items for AIS B2B interfaces:

| # | Item | What to Check |
|---|---|---|
| IS-1 | SHIR VMSS upgrade | Upgrade VMSS nodes for shared SHIR `t3aisadfshir` prior to deployment |
| IS-2 | ADF — validate/create | Validate ADF resource exists; all pipelines + linked services ready to deploy |
| IS-3 | Service Bus Queues | Create send and monitor queues on the correct namespace |
| IS-4 | Storage Account Tables | Create `cfgAdfPipelineRetryPolicy` and `logAdfPipelineRetry` tables |
| IS-5 | SQL Database | Validate DB exists and is accessible from the Dev Box |
| IS-6 | APIM | Validate API is registered and policy is deployed |
| IS-7 | Key Vault Secrets (B2B KV) | Confirm all B2B KV secrets are present with correct values |
| IS-8 | Key Vault Secrets (Enabling KV) | Confirm all Enabling KV secrets are present with correct values |

> IS items are marked with Green COMPLETED or Yellow TODO status macros (see [Status Macros](#status-macros)).

---

### 4b. Pre-Checks — Actions Table

7-column table: **Sr. No. | Action | Dependency | Team | Start Date/Time | End Date/Time | Status | Escalations/Instructions**

Standard pre-check actions (16 rows for AIS B2B interfaces):

| # | Action |
|---|---|
| 1 | Validate Metcash Azure Dev Box Access |
| 2 | Create/validate release pipeline and folder structure for IAC pipeline |
| 3 | Onboard Interface on SMC `{ENV}` — register interfaces on SMC |
| 4 | Run IAC pipeline for resource creation (Release Pipeline) |
| 5 | IaC Resource Validation |
| 6 | Key Vault secret creation in B2B KV with all required values |
| 7 | Validate Key Vault secret creation |
| 8 | Add ADF Managed Identity to SQL AD groups (`b2b_db_datareader`, `b2b_db_datawriter`, `b2b_db_executor`) |
| 9 | Storage account delegator access → Blob management Function App |
| 10 | Storage account table data + Blob data contributor access → ADF |
| 11 | Key Vault MSI access → ADF |
| 12 | Service Bus queue MSI access → Function App |
| 13 | Firewall Opening — ADF SHIR → SQL DB |
| 14 | Firewall Opening — ADF SHIR → SkuVantage REST API |
| 15 | RBAC — ADF Managed Identity → Storage Account (container-level) |
| 16 | RBAC — Function App → SQL DB (AD group membership) |

---

### 5. Implementation — Actions Table

Same 7-column structure. Standard implementation steps for AIS B2B interfaces:

| # | Action | Dependency |
|---|---|---|
| 1 | Create & execute deployment ALM pipelines | Infra setup done |
| 2 | Configure Data Factory app setup | — |
| 3 | Configure Function App setup | — |
| 4 | Configure SQL user-defined value tables and stored procedures | — |
| 5 | Insert `cfgAdfPipelineRetryPolicy` values to Storage Account for retry | — |
| 6 | Create `logAdfPipelineRetry` table in Storage Account | — |
| 7 | Deploy ADF workspace via ALM pipeline (all pipelines + linked services + datasets) | IS-2, rows 5–6 |
| 8 | Deploy database objects via DB pipeline (tables + stored procedures) | Row 7 |

---

### 6. Post-Implementation — Actions Table

Same 7-column structure. Standard post-deployment validation steps:

| # | Action | Notes |
|---|---|---|
| 1 | Validation of ADF, Function App & related configs | Verify ADF triggers, FA config keys, linked services |
| 2 | Validate end-to-end integration (EAII-{number}) | Run smoke test using E2E integration test |
| 3 | Interface Ready for `{ENV}` Testing | Sign-off gate |
| 4 | Product table data migration to new `{ENV}` table structure | Impl Row 8 dependency |
| 5 | Add secrets to B2B KV | API credentials (e.g. rest-pwd, rest-username) |
| 6 | Add secrets to Enabling KV | SMC subscription key, blobmgmt AD client secret |
| 7 | Create task for SMC Onboarding (`{ENV}`) | Log SMC onboarding work item in ADO |

> **Note:** The "Share SAS credentials" step is **not** included in standard runsheets.
> SAS-based access has been replaced by Managed Identity (MSI) across all environments.

---

### 7. Rollback — Actions Table

Columns: **Sr. No. | Action | Team | Start Date/Time | End Date/Time | Status | Escalations/Instructions**

For fresh deployments (first-time to environment):
> "This is a fresh deployment. Rollback is not applicable for this deployment."

For re-deployments: document the specific pipeline re-run steps and data rollback procedure.

---

### 8. Contact

Table listing team members with: **Name | Role | Email | Phone/Teams handle**

Include: Deployment Lead, Tech Lead, On-call DBA, Infrastructure contact.

---

## Status Macros

All statuses use Confluence structured macros. Use exactly these patterns:

| Status | Colour | When to Use |
|---|---|---|
| `TODO` | Yellow | Not yet started — default for new runsheets |
| `INPROGRESS` | Blue | Currently being executed |
| `COMPLETED` | Green | Step finished and verified |
| `BLOCKED` | Red | Cannot proceed — escalation required |

Storage format example (colour param **must** come before title param):
```xml
<ac:structured-macro ac:name="status" ac:schema-version="1">
  <ac:parameter ac:name="colour">Green</ac:parameter>
  <ac:parameter ac:name="title">COMPLETED</ac:parameter>
</ac:structured-macro>
```

---

## Runsheet Creation Workflow

Follow these steps to create a new deployment runsheet for any interface:

**Step 1 — Confirm inputs**
- Complete the Mandatory Inline Intake Gate above before generating any runsheet artifact or creating a Confluence page. Do not populate names from a different interface's production runsheet.

**Step 2 — Clone from previous environment runsheet**
- Prefer the latest runsheet for the same interface. If none exists, preserve the fixed production runsheet section order and table layouts defined below and exemplified by the approved runsheets in `Doc/Temp/Runsheets/`.
- Do not add, remove, rename, or reorder top-level sections or change the established action-table columns. Place TSD/code provenance, discrepancies, and component-specific evidence inside the existing Overview, Pre-Checks, Implementation, Post-Implementation, Rollback, and Contact sections.
- Use the approved production example's fixed section/table format. Copy the shared personnel names/roles only when the user designates that roster for reuse; the developer placeholder is the only personnel variable. Do not copy environment-specific resources, endpoints, change records, dates, pipeline actions, statuses or business behavior.
- Map each interface to its approved TSD and code repository. Derive intended scope/resources from the TSD and actual build/deploy stages from the refreshed code repository's pipeline YAML. Record both source revisions and any discrepancies.
- Replace all environment-specific resource names using the mapping table above.
- Update all `datetime=""` values to the new deployment window dates.
- Update page title to reflect the new environment.

The selected target artifact must be tied to its promotion branch, immutable artifact/build ID, and pipeline run. A current `main` commit alone does not prove which artifact was deployed.

**Step 3 — Set all statuses to TODO**
- New runsheets start with all statuses as Yellow `TODO`.
- Only mark COMPLETED after each step is verified on deployment day.

**Step 4 — Fill Overview panel**
- Set Change Request (once raised in ServiceNow).
- Set correct environment badge colour.
- Set start/end dates per deployment schedule.
- Add author, implementers, and reviewers.

**Step 5 — Review and approval**
- Share page with Tech Lead and Architect for review before deployment day.
- Reviewers must populate the Review and Approval Matrix.

**Step 6 — Deploy and track**
- On deployment day: update each row status live as work progresses.
- Use `INPROGRESS` while a step is running; `COMPLETED` when verified.
- Log blockers in the Escalations/Instructions column.

**Step 7 — Post-deployment sign-off**
- Row 3 in Post-Implementation ("Interface Ready for `{ENV}` Testing") is the sign-off gate.
- Once all rows are COMPLETED, notify stakeholders via the Communications section.

---

## Runsheet per Environment — Date Conventions

| Environment | Typical Deployment Window |
|---|---|
| ST1 | 2 weeks — first sprint cycle |
| UT1 (UAT) | 2 weeks — second sprint cycle |
| SIT | 5–7 business days |
| PRD | Mon–Wed of release week (3 days max) |

Set start and end dates on the Overview panel and on every action row's Start/End Date cells.

---

## End-to-End Deployment Readiness Checklist

Before executing any deployment, verify all of the following:

- [ ] Azure Dev Box access confirmed for all implementers
- [ ] ADO pipeline access confirmed (IAC, ALM, DB pipelines visible and triggerable)
- [ ] Confluence page created with correct title and all sections populated
- [ ] All statuses set to TODO
- [ ] Change Request raised and CR number added to Overview panel
- [ ] Key Vault secrets staged (values confirmed with Secret Manager)
- [ ] Service Bus queues created (or confirmed existing on namespace)
- [ ] SQL DB accessible from Dev Box (AD group membership confirmed)
- [ ] ADF resource exists and pipelines are ready to deploy
- [ ] Storage Account tables exist (`cfgAdfPipelineRetryPolicy`, `logAdfPipelineRetry`)
- [ ] RBAC assignments completed (ADF MI → Storage, Function App → SQL)
- [ ] Firewall rules opened (SHIR → SQL DB, SHIR → external REST API)
- [ ] SMC interface registration task raised
- [ ] Reviewers have signed off on the runsheet

---

## Model Evaluation Corpus

For a prompt/model bake-off, use `review-gates/corpus/runsheets/README.md`, the fixed prompt in `review-gates/corpus/runsheets/model-eval/PROMPT.md`, and `review-gates/templates/runsheet-model-eval.template.md`. Keep the approved Confluence exports as hidden local references; do not include them in candidate prompts. The current corpus has PRD outputs but no paired approved input bundles, so it supports structure/style evaluation only until those inputs are prepared. Benchmark results do not replace the per-environment review gate or authorize Confluence publication, pipeline execution, or deployment.

## References

| Document | Location |
|---|---|
| Squad 20 Naming Conventions | `skills/squad20-naming-conventions.md` |
| Squad 20 Engineering Overview | `skills/squad20-engineering-overview.md` |
| Logic App Skill | `skills/logic-app-skill.md` |
| Azure Function Skill | `skills/azure-function-skill.md` |
| Azure Service Bus Skill | `skills/azure-service-bus-skill.md` |
| ADF Skill | `skills/azure-data-factory-skill.md` |
| Sample UT1 Runsheet | https://metcash.atlassian.net/wiki/spaces/MAP/pages/3027140609 |
| Sample SIT Runsheet | https://metcash.atlassian.net/wiki/spaces/MAP/pages/3013935105 |
| Sample PRD Runsheet | https://metcash.atlassian.net/wiki/spaces/MAP/pages/3445817349 |

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `com.atlassian/atlassian-mcp-server-metcash` | Search Confluence pages | Locate existing runsheet for same interface to clone from |
| `com.atlassian/atlassian-mcp-server-metcash` | Create Confluence page | Create new runsheet page in MAP space |
| `com.atlassian/atlassian-mcp-server-metcash` | Update Confluence page | Update status macros live during deployment |
| `mcp_azure_devops2_pipelines_get_build_status` | ADO MCP | Verify IAC / ALM / DB pipelines are ready before deployment |
| `mcp_azure_devops2_pipelines_run_pipeline` | ADO MCP | Trigger pipeline runs from within the runsheet workflow |
| `mcp_azure_devops2_wit_get_work_item` | ADO MCP | Confirm EAII work item exists and read interface details |
| `mcp_azure_devops2_wit_add_work_item_comment` | ADO MCP | Log deployment status updates on the work item |

### Atlassian MCP — Creating the Confluence Runsheet

When creating a new deployment runsheet:

1. **Search for existing runsheet** to clone from:
   - Search Confluence for `{EAII-ID}` in the MAP space.
   - If an earlier-environment runsheet exists (e.g., UT1 when creating SIT), clone its structure.

2. **Create the new Confluence page** in the correct location:
   - Space: `MAP`
   - Parent page: Domain-specific parent (e.g., `B2B > Extended Product Info`)
   - Title: `{EAII-ID} — {InterfaceName} — {ENV} Deployment Runsheet`

3. **Set all Status macros to TODO** on creation.

4. **On deployment day**, update status macros via Atlassian MCP as each step completes.

### ADO MCP — Pipeline Readiness Checks

Before step 4 (Pre-Checks → Actions), verify pipeline status:
```
mcp_azure_devops2_pipelines_get_build_definitions → list IAC + ALM + DB pipelines
mcp_azure_devops2_pipelines_get_build_status → confirm last run was successful
```
