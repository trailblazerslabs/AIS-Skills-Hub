# PRD Deployment Readiness Runbook — {EAII-IDs} — {InterfaceName}

Runbook revision: {revision}  
Review date: {date}  
Runbook owner: {name}  
Reviewer(s): {names}  
Status: **DRAFT / BLOCKED / READY FOR PRD REVIEW / APPROVED FOR PRD EXECUTION**

> Required before either deploying to PRD or declaring the interface Ready for PRD. This runbook
> review is a hard gate, not deployment authorization. Execution requires separate explicit
> approval for the named change, window, artifact, and environment.

## Critical Findings

| # | Severity | Runbook section / evidence | Risk / impact | Required correction / owner | Blocks PRD? |
|---|---|---|---|---|---|
| 1 | Critical / High / Medium / Low | {location} | {impact} | {action / owner} | Yes / No |

## PRD Readiness Checklist

All applicable mandatory rows must be supported by evidence. N/A requires an explicit rationale
and reviewer acceptance. Unknown/unverified is incomplete and scores zero.

| Check | Points | Complete? | Evidence / comments |
|---|---:|---|---|
| Approved TSD and TSD review; production contracts/gaps dispositioned | 10 | Yes / No / N/A | {links / signed disposition} |
| Code review approved; production comparison and checker current; no blocking findings | 10 | Yes / No / N/A | {reports / baseline SHA} |
| Build and unit tests pass; test cases trace to TSD; execution results recorded for SIT/UAT | 15 | Yes / No / N/A | {build, test plan, results} |
| SIT and UAT/UT1 runsheets reviewed and deployment/validation evidence complete | 10 | Yes / No / N/A | {runsheet links / sign-offs} |
| PRD artifact provenance, version, branch and approved pipeline source verified | 10 | Yes / No / N/A | {commit SHA / pipeline / package} |
| PRD infrastructure, networking, identity, RBAC, secrets and endpoints verified | 15 | Yes / No / N/A | {resource/change evidence; no secret values} |
| Monitoring, SMC registration, alerts, dashboards, support contacts and escalation tested | 10 | Yes / No / N/A | {evidence / owners} |
| Cut-over, ingress/egress control, data reconciliation, DLQ/replay and duplicate-risk plan | 10 | Yes / No / N/A | {procedure / responsible owner} |
| Rollback trigger, prior artifact, rollback steps, decision authority and recovery targets | 10 | Yes / No / N/A | {rollback evidence / rehearsal result} |
| **Total** | **100** | | |

**PRD readiness percentage:** `{points awarded}/{applicable points} = {percent}%`  
**Required score:** 100% of applicable mandatory rows. This percentage does not itself authorize deployment.

## Go / No-Go

- [ ] **NO-GO** — any mandatory evidence missing, any Critical/High finding open, tests/build failed, or approval absent
- [ ] **READY FOR PRD REVIEW** — all readiness evidence complete; awaiting authorized change approval
- [ ] **APPROVED FOR PRD EXECUTION** — named approvers explicitly authorize the specific PRD deployment

**Deployment authorization is separate:** Change Request {CR}; artifact/commit {SHA}; approved window {start/end}; approvers {names}; explicit approval evidence {link}.

## Execution, Validation, and Recovery

| Step | Action | Owner | Evidence / expected result | Status |
|---|---|---|---|---|
| Pre-deploy | Confirm artifact, environment, change window and stop/go decision | {owner} | {evidence} | Not Started |
| Deploy | Execute only the approved pipeline/artifact | {owner} | {pipeline run} | Not Started |
| Smoke test | Run approved non-destructive PRD validation only after authorization | {owner} | {expected result} | Not Started |
| Monitor | Verify SMC, alerts, queues/backlog, errors and target outcomes | {owner} | {dashboard/query} | Not Started |
| Rollback decision | Invoke rollback criteria and notify decision authority | {owner} | {criteria/result} | Not Started |
| Closeout | Record outcome, incident/CR links, outstanding actions and operational handover | {owner} | {links} | Not Started |

## Reviewer Comments and Sign-off

| Reviewer | Role | Decision | Date | Comments / conditions |
|---|---|---|---|---|
| {name} | {role} | Approve / Reject / Conditional | {date} | {critical findings or conditions} |
