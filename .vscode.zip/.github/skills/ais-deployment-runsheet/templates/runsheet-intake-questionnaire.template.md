# Deployment Runsheet Intake Questionnaire — {EAII-IDs}

**Interface(s):** {IDs and names}  
**Requested environment:** {DV1 / ST1 / UT1 / SIT / PRD / local evaluation}  
**Deployment mode:** {first deployment / change or redeployment}  
**Status:** {DRAFT / BLOCKED / READY FOR USER APPROVAL / APPROVED}  
**Prepared by/date:** {name/date}

> This is an intake record, not the deployment runsheet and not deployment authorization. Do not create or publish the runsheet until this questionnaire is complete and explicitly approved, except for a directly authorized local quality-evaluation draft. That exception never authorizes Confluence/ADO writes, pipeline execution, or deployment.

## Evidence Baseline

| Evidence source | Revision / SHA / version | What it establishes |
|---|---|---|
| Approved TSD | {title, version, approval state} | {scope, environment/resource patterns, security, monitoring, promotion path} |
| Application code | {repository, branch, `origin/main` SHA} | {implemented workflows/services, settings, dependencies} |
| Production runsheet / shared roster | {source page/file and revision} | {fixed section/table layout and approved shared person/role roster} |
| Promotion candidate | {branch, artifact/build ID} | {exact code intended for this run; never substitute `main` SHA} |
| Pipelines | {application / APIOps / IaC definitions and runs} | {independent stage conditions, approvals and artifact evidence} |

## Proposed Answers and Inline Questions

For each unresolved or conflicting fact, present the proposed value and evidence in an inline question. The user may confirm, correct, or leave it unknown/blocked. Do not ask again for facts established by the TSD, current code, or approved shared roster.

| ID | Required fact | Proposed answer | Evidence / source | User answer or correction | Status / owner |
|---|---|---|---|---|---|
| Q-01 | Target environment and deployment mode | {proposal or TBD} | {TSD/previous same-interface runsheet/owner} | {answer} | {OPEN / CONFIRMED / BLOCKED} |
| Q-02 | Current CR, deployment window and change type | {proposal or TBD} | {approved change record/calendar} | {answer} | {OPEN / CONFIRMED / BLOCKED} |
| Q-03 | Exact promotion branch, artifact/build ID and pipeline run | {proposal or TBD} | {repo/pipeline result} | {answer} | {OPEN / CONFIRMED / BLOCKED} |
| Q-04 | Independent application, APIOps/API and IaC pipelines | {one proposed row per component} | {checked-in YAML/ADO run} | {answer} | {OPEN / CONFIRMED / BLOCKED} |
| Q-05 | Exact shared person/role roster | {copy approved names/roles verbatim; developer placeholder only} | {user-designated production runsheet/roster} | {developer full name / corrections} | {OPEN / CONFIRMED / BLOCKED} |
| Q-06 | First deployment or redeployment; rollback target | {proposal or TBD} | {current environment inventory/artifact history} | {answer} | {OPEN / CONFIRMED / BLOCKED} |
| Q-07 | Pre-check evidence: access, resources, identity, network, secrets, monitoring | {one proposed check per applicable dependency} | {TSD/code/platform evidence} | {answer} | {OPEN / CONFIRMED / BLOCKED} |
| Q-08 | Test/build/review readiness and post-deployment validation | {proposal or TBD} | {code review/build/test evidence} | {answer} | {OPEN / CONFIRMED / BLOCKED} |
| Q-09 | Communications, support and escalation contacts | {proposal or TBD} | {approved roster/operations plan} | {answer} | {OPEN / CONFIRMED / BLOCKED} |

## TSD-to-Code Differences and Open Gaps

| ID | Design statement / TSD section | Code or pipeline evidence | Impact | Proposed question / owner | Resolution / status |
|---|---|---|---|---|---|
| G-01 | {statement} | {repo/path/SHA or missing evidence} | {impact} | {inline question / owner} | {OPEN / RESOLVED / ACCEPTED} |

## Gate Decision

- [ ] BLOCKED — any required fact is unknown, conflicting, or lacks evidence.
- [ ] READY FOR USER APPROVAL — all proposed values have sources; remaining N/A items are justified.
- [ ] APPROVED FOR RUNSHEET DRAFT — user explicitly approved this questionnaire and the named scope/environment.
- [ ] LOCAL EVALUATION ONLY — direct user instruction permits a local draft with TBD/BLOCKED items; no publishing, shared-system write, pipeline execution, or deployment.

**User approval / correction and date:** {verbatim response or link to recorded response}  
**Next action:** {stop / generate local draft / create approved environment runsheet}