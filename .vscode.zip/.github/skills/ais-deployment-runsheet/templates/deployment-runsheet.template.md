# EAII-{number} — {Interface Name} — {ENV} Deployment Runsheet

> Draft for review. This page is not deployment authorization. Keep new actions at `TODO`; update a status only when the action is observed and verified.

## 1. Overview

| Field | Value | Evidence / owner |
|---|---|---|
| Interface ID(s) | EAII-{number}[, EAII-{number}] | {approved work item(s)} |
| Interface name | {approved name} | {approved design} |
| Environment | {ST1 / UT1 / SIT / PRD} | {environment approval} |
| Change Request | {CHG number or TBD} | {change record} |
| Change type | {standard / normal / emergency} | {change record} |
| Deployment window | {start date/time and end date/time, timezone} | {approved schedule} |
| Artifact version / commit | {tag, SHA, or release identifier} | {repository / pipeline evidence} |
| Author | {name} | {contact} |
| Implementers | {names} | {team} |
| Reviewers / approvers | {names and roles} | {review evidence} |
| Informed stakeholders | {names / groups} | {communications plan} |

## Source and Release Baseline

Use the approved TSD for intended design and the refreshed application repository for implemented behavior. Record both the current `main` reference and the exact artifact being promoted; they are not interchangeable. Do not put secret values in this page.

| Interface ID | Approved TSD / revision | TSD sections used | Application repository | `origin/main` SHA / date | Deployment pipeline YAML | Deployable component / source path | Promotion artifact / build ID |
|---|---|---|---|---|---|---|---|
| {EAII-ID} | {TSD title, version, approval evidence} | {scope, components, security, infrastructure, tests, deployment} | {repo name and link} | {SHA/date} | {pipeline file and definition link} | {workflow / Function App / ADF path} | {artifact SHA, tag, build/run link} |

For a combined-interface runsheet, add one row per EAII ID and identify the shared and interface-specific components. Record the source used for each deployment action. The current `origin/main` SHA is a comparison baseline only; deployment readiness requires the actual promotion branch, immutable artifact/build ID, and pipeline run evidence.

### Independently Deployed Components

List every independently promoted application, APIOps/API, and infrastructure component. Do not assume the application pipeline deploys APIM policies or IaC, or that one pipeline run proves every component was promoted.

| Component / interface | Repository and source revision | Pipeline definition / YAML | Target stage / parameters | Artifact / build ID | Run / approval evidence | Owner |
|---|---|---|---|---|---|---|
| Application / {EAII-ID} | {repo, branch, SHA} | {definition link and YAML path} | {environment condition and selection} | {immutable artifact/hash} | {actual run and approval} | {owner} |
| APIOps/API (if applicable) | {repo, branch, SHA} | {publisher pipeline and YAML path} | {environment condition and selection} | {artifact/hash} | {actual run and approval} | {owner} |
| Infrastructure/IaC (if applicable) | {repo, branch, SHA} | {IAC pipeline and YAML path} | {environment condition and selection} | {plan/artifact/hash} | {actual run and approval} | {owner} |

### TSD-to-Code Differences and Decisions

Record every material conflict, stale TSD open item, or implementation difference. Do not silently prefer the code or the TSD; obtain an owner decision and update the controlling artifact where required.

| ID | TSD section and stated design | Current code evidence (repo/path/SHA) | Difference / deployment risk | Owner / required decision | Status |
|---|---|---|---|---|---|
| D-01 | {statement} | {implementation evidence} | {impact} | {owner and correction / approval} | {OPEN / RESOLVED} |

## 2. Release Note

{Describe the approved change, interface flow, scope, and components being deployed. Cite the TSD and implementation artifact. List exclusions and known constraints.}

## 3. Review and Approval Matrix

| Name | Role | Review date | Decision / approval date | Evidence / notes |
|---|---|---|---|---|
| {name} | Tech Lead | {date} | {TODO / decision} | {link} |
| {name} | Solution Architect | {date} | {TODO / decision} | {link} |
| {name} | Second developer / implementer | {date} | {TODO / decision} | {link} |
| {name} | Change approver (PRD where required) | {date} | {TODO / decision} | {link} |

## 4. Pre-Checks

### 4a. Infrastructure Setup

Include only infrastructure checks applicable to this interface and environment. Derive resources and identity/network requirements from the approved design; do not copy example values.

| IS-# | Component | Required action / evidence | Dependency | Owner / team | Status |
|---|---|---|---|---|---|
| IS-1 | {resource / identity / network} | {verified condition and evidence link} | {dependency or None} | {owner} | TODO |
| IS-2 | {resource / identity / network} | {verified condition and evidence link} | {dependency or None} | {owner} | TODO |

### 4b. Pre-Check Actions

| No. | Action | Dependency | Owner / team | Planned start | Planned end | Status | Evidence / escalation |
|---:|---|---|---|---|---|---|---|
| 1 | Confirm access and deployment prerequisites | {dependency} | {owner} | {date/time} | {date/time} | TODO | {evidence or TBD owner} |
| 2 | Verify change record, artifact, and required approvals | {dependency} | {owner} | {date/time} | {date/time} | TODO | {evidence or TBD owner} |
| 3 | Verify applicable pipeline, infrastructure, identity, secret-store, and network prerequisites | {dependency} | {owner} | {date/time} | {date/time} | TODO | {evidence or TBD owner} |
| 4 | Confirm code-review/build/check and unit-test status for this promotion | {review/test reports} | {owner} | {date/time} | {date/time} | TODO | {links; do not claim pass without results} |

### Pre-Check Communications

| Audience | Message / channel | Owner | Planned time | Status |
|---|---|---|---|---|
| {stakeholder} | {message} | {owner} | {date/time} | TODO |

## 5. Implementation

List executable steps in dependency order. For multi-interface deployments, identify the interface for each action. Add pipeline, repository, resource, and verification references from the approved input evidence.

| No. | Interface | Action | Dependency | Owner / team | Planned start | Planned end | Status | Evidence / escalation |
|---:|---|---|---|---|---|---|---|---|
| 1 | {EAII-ID} | {specific deployment action} | {pre-check or prior step} | {owner} | {date/time} | {date/time} | TODO | {pipeline / artifact / expected result} |
| 2 | {EAII-ID} | {specific deployment action} | {prior step} | {owner} | {date/time} | {date/time} | TODO | {pipeline / artifact / expected result} |

### Optional Deployment Steps and RBAC Verification

Include only where applicable; verify every role, scope, principal, and target against approved evidence.

| No. | Interface | Resource / identity | Required role / action | Scope | Verification evidence | Status |
|---:|---|---|---|---|---|---|
| 1 | {EAII-ID} | {resource and managed identity} | {role / action} | {scope} | {evidence link} | TODO |

### Implementation Communications

| Audience | Message / channel | Owner | Planned time | Status |
|---|---|---|---|---|
| {stakeholder} | {message} | {owner} | {date/time} | TODO |

## 6. Post-Implementation

| No. | Action / expected result | Dependency | Owner / team | Planned start | Planned end | Status | Evidence / escalation |
|---:|---|---|---|---|---|---|---|
| 1 | Verify deployed configuration and resource health | {implementation step} | {owner} | {date/time} | {date/time} | TODO | {evidence link} |
| 2 | Run approved end-to-end or smoke validation | {test case / approval} | {owner} | {date/time} | {date/time} | TODO | {observed result} |
| 3 | Confirm monitoring, support handoff, and interface readiness for {ENV} testing | {validation complete} | {owner} | {date/time} | {date/time} | TODO | {sign-off evidence} |

### Post-Implementation Communications

| Audience | Message / channel | Owner | Planned time | Status |
|---|---|---|---|---|
| {stakeholder} | {outcome and next step} | {owner} | {date/time} | TODO |

## 7. Rollback / Recovery

Rollback decision trigger: {observable condition and decision owner}  
Recovery point / data reconciliation: {approved procedure and owner}

For a first-time deployment, state that rollback is not applicable only when the approved design and deployment evidence support it. For a re-deployment, document the exact pipeline/artifact reversal, ingress or trigger controls, data recovery, and verification steps.

| No. | Action | Dependency | Owner / team | Planned start | Planned end | Status | Evidence / escalation |
|---:|---|---|---|---|---|---|---|
| 1 | {specific rollback/recovery action} | {trigger / prior step} | {owner} | {date/time} | {date/time} | TODO | {procedure / evidence} |

### Rollback Communications

| Audience | Message / channel | Owner | Planned time | Status |
|---|---|---|---|---|
| {stakeholder} | {message and escalation path} | {owner} | {date/time} | TODO |

## 8. Contacts and Escalation

| Name | Role | Email / Teams | Escalation responsibility |
|---|---|---|---|
| {name} | Deployment Lead | {contact} | {responsibility} |
| {name} | Tech Lead | {contact} | {responsibility} |
| {name} | On-call / support | {contact} | {responsibility} |
| {name} | Infrastructure / DBA (if applicable) | {contact} | {responsibility} |

## Readiness Review Record

Complete a separate [deployment-runsheet review](../../../review-gates/templates/deployment-runsheet-review.template.md) for this environment and runsheet revision. A passing review is not pipeline execution approval or deployment authorization.

Review artifact: {path/link}  
Runsheet revision: {Confluence page version / artifact revision}  
Decision: {IN REVIEW / BLOCKED / APPROVED FOR THIS ENVIRONMENT ONLY}  
Reviewer and date: {name/date}  
Open Critical/High findings: {IDs or None}