---
name: ais-runsheet-review
description: |
  Metcash AIS deployment-runsheet reviewer. USE FOR: critically reviewing an existing
  deployment runsheet against its approved TSD, current code/pipeline baseline, and the
  environment-specific review checklist; retrospective audits of approved runsheet examples;
  scoring and reporting blocking findings. DO NOT USE FOR: generating or publishing a new
  runsheet (use ais-deployment-runsheet), triggering pipelines, or authorizing deployment.
  Triggers: "review this runsheet", "review existing deployment runsheet", "runsheet quality
  review", "audit deployment checklist", "check runsheet against TSD and code".
---

# AIS Runsheet Review

Review the exact runsheet revision against its design and implementation evidence. Findings are primary; a percentage never overrides a deployment blocker.

## Required Inputs

| Input | Evidence |
|---|---|
| Interface ID(s), target environment, and review mode (active gate or retrospective corpus audit) | Interface status and runsheet title/revision |
| Approved TSD title, revision, and approval evidence | TSD source or approved local copy |
| Current code repository, refreshed `origin/main` SHA, and target promotion branch/artifact | Local Git metadata and pipeline evidence |
| Each independently deployed component's pipeline definition and actual run/build results | Application, APIOps/API and IaC pipeline YAML plus each linked artifact/run/approval |
| Runsheet page revision and applicable change record, approvers, dates, and owners | Current Confluence page or its explicit local export; distinguish a static export from the live page |
| Applicable per-environment review checklist | `review-gates/templates/deployment-runsheet-review.template.md` |

Missing evidence is a finding, not an invitation to infer. Never report a build, test, approval, deployment, or production state as passed unless observed evidence supports it.

## Workflow

1. For an active interface gate, read `outputs/<EAII-ID>/status.md` first. Confirm prior review/build/test phases and the exact environment; update that status record last. Do not apply active deployment disposition to an archive-only corpus audit.
2. Capture the runbook page/revision, environment, interface IDs, TSD revision, code repository and `origin/main` SHA, target artifact/build ID, and a separate pipeline/run for every independently deployed application, APIOps/API, or IaC component. Keep the main comparison baseline distinct from the artifact being promoted.
3. Build a traceability map from TSD scope/components, security/RBAC, infrastructure, monitoring/testing, and environment-migration sections to code paths, pipeline stages, runbook actions, owners, and evidence.
4. Check multi-interface coverage, environment/resource names, dependencies, approvals/change record, deployment sequence, code-review/build/check evidence, unit-test status, post-deployment validation, support/communications, and rollback/recovery. Treat TSD/code disagreements as explicit findings requiring an owner decision.
5. Fill the 100-point checklist in `review-gates/templates/deployment-runsheet-review.template.md`. Unverified items score zero; N/A needs a reason and evidence. Report Critical/High findings before the score.
6. Decide `PASS` only for an active gate with 100% of applicable mandatory points, complete evidence, required named sign-offs, and no unresolved Critical/High findings. Otherwise mark `BLOCKED`. Approval applies only to that environment and runsheet revision; it is not pipeline execution or deployment authorization.
7. For a retrospective audit of user-designated approved examples, preserve historical statuses and dates; do not reset completed actions to TODO. Score the evidence present in the export, clearly mark the result **RETROSPECTIVE — NOT DEPLOYMENT APPROVAL**, and do not infer current Confluence approval or live deployment state from a static export.
8. Record each finding with stable ID, severity, exact section/row, source evidence, impact, required correction/owner, and blocking status. Record unresolved input conflicts and any evidence that was unavailable.

## Hard Blockers

- Wrong or ambiguous interface/environment/resource mapping, or an unresolved TSD-to-code conflict that changes deployment behavior.
- Missing or untraceable promotion artifact/build or independent component pipeline, required change record, required reviewer sign-off, or mandatory pre-check evidence.
- Failed or unreported required build/check/unit-test results for the promotion.
- Incomplete or unsafe rollback/recovery, unsupported claim of completion/approval, or a readiness statement that implies deployment authorization.
- Any secret value, credential, token, private key, or SAS token included in the runsheet.

Any Critical/High finding or mandatory checklist failure blocks an active gate regardless of score.

## Output Location

- Active deployment review: `outputs/<EAII-ID>/deployment-runsheet-review-<ENV>.md` and update the interface status record last.
- Retrospective corpus review: `review-gates/corpus/runsheets/reviews/`; label it retrospective and do not mark an interface deployment gate complete.

Do not update Confluence, ADO, run a pipeline, or deploy as part of review.

## References

| Purpose | File |
|---|---|
| Runsheet generation and fixed production page structure | `.github/skills/ais-deployment-runsheet/SKILL.md`; approved format examples in `Doc/Temp/Runsheets/` |
| Per-environment readiness checklist | `review-gates/templates/deployment-runsheet-review.template.md` |
| Approved-example provenance and structure corpus | `review-gates/corpus/runsheets/README.md` |
| Model candidate scoring (separate from deployment approval) | `review-gates/templates/runsheet-model-eval.template.md` |