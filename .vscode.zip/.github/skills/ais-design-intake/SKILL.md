---
name: ais-design-intake
description: |
  Metcash AIS design intake skill — the NO-TSD path only, never the default for a new interface.
  USE FOR: reading and parsing an FSD (Functional Specification Document) and inferring technical
  decisions ONLY when the user has explicitly confirmed no TSD exists and none will be generated
  for this interface, before generating any Logic App, Function App, or ADF code. The default for
  every new interface is FSD → metcash-tsd-generator → ais-codegen-readiness — do not reach for
  this skill just because an FSD is available or generation would be faster; having an FSD ready
  is exactly what metcash-tsd-generator needs, not a reason to skip it. Validates that mandatory
  FSD is present, produces a Design Intake Questionnaire via inference, and stops for explicit
  approval before any codegen skill runs. MANDATORY PREREQUISITE for ais-logicapp-codegen,
  ais-functionapp-codegen, and ais-datafactory-codegen ONLY on this explicit no-TSD exception path
  — when a TSD already exists or could be generated (the default path), use metcash-tsd-generator
  then ais-codegen-readiness instead; do not run both.
  DO NOT USE FOR: generating code directly, choosing this path on your own initiative without an
  explicit user confirmation that no TSD applies, or for any interface that already has an
  approved TSD (use ais-codegen-readiness — running this skill anyway just re-derives what the TSD
  already settled).
  Triggers: "no TSD and none will be generated", "skip TSD generation" (only after explicit user
  confirmation), "design intake".
---

# AIS Design Intake — FSD Reader (no-TSD EXCEPTION path)

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — this file should also record *why* the no-TSD exception applies (the
> user's explicit confirmation), so a resuming session doesn't have to ask "why did we skip the
> TSD?" again.

**⛔ This is an exception path, not a default choice.** The default for every new interface is
`metcash-tsd-generator` → `ais-codegen-readiness` (FSD → approved TSD → codegen). Only use this
skill once the user has **explicitly confirmed** no TSD will ever be produced for this interface
— never select it on your own initiative just because an FSD is on hand or it would be faster.
If it's unclear which path applies, ask the user rather than defaulting to this shortcut.

**If a TSD already exists for this interface, use `ais-codegen-readiness` instead of this
skill** — this skill's inference logic exists specifically to derive technical decisions when
there is no TSD to read them from; running it against an interface that already has an approved
TSD just re-derives decisions that are already settled and written down, and skips the
TSD-aware checks (repo/resource-name resolution, TIBCO cross-check) that `ais-codegen-readiness`
does instead.

Read, validate, and extract all information from the FSD before any code is generated, inferring
the technical decisions a TSD would normally contain. The output of this skill is a **Design
Intake Questionnaire** — a stop-for-approval gate, not a silent summary — that is passed to
`ais-logicapp-codegen`, `ais-functionapp-codegen`, or `ais-datafactory-codegen` only once approved.

## Document Rules

| Document | Requirement | Purpose |
|---|---|---|
| **FSD** (Functional Specification Document) | **Mandatory** — stop if not provided | Business rules, trigger events, acceptance criteria, scope |
| **TSD** (Technical Specification Document) | If one exists, **stop — use `ais-codegen-readiness` instead**, not this skill | Architecture pattern, field mappings, API contracts, NFRs |

> If FSD is not provided, **stop immediately** and ask the user to provide it.
> Do not attempt code generation without a confirmed FSD.
> **If a TSD exists (check `tsd/<EAII-ID>/` before proceeding), stop and redirect to
> `ais-codegen-readiness`** — do not run this skill's inference logic against an interface that
> already has a TSD; that skill reads the TSD directly plus does the repo/resource-name and
> TIBCO cross-checks this skill doesn't do. Only continue with this skill when there is
> genuinely no TSD and none will be produced for this interface.

---

## Step 1 — Collect the Interface ID and Fetch Documents

### 1a — Confirm the Interface ID

Ask if not already provided:
> **"What is the Interface ID (EAII-{number})?"**

Do not proceed until the Interface ID matches `EAII-{number}`.

### 1b — Fetch FSD from Confluence via Atlassian MCP (preferred)

Use the **Atlassian MCP** (`com.atlassian/atlassian-mcp-server-metcash`) to search Confluence
before asking the user to paste content manually:

1. Search Confluence for a page whose title contains the EAII ID (e.g., `EAII-107`).
2. If a match is found, read the full page content.
3. If multiple matches exist, ask the user to confirm the correct FSD page.
4. If no Confluence page is found, ask:
   > **"No FSD found in Confluence for {EAII-ID}. Please paste the FSD content or provide a file path."**

### 1c — Fetch TSD from Confluence via Atlassian MCP (optional)

After finding the FSD, search Confluence for a linked TSD page:
1. Search for `{EAII-ID} TSD` or `{InterfaceName} Technical Specification`.
2. If found, read its content and extract technical details.
3. If not found, proceed without it and log as assumption `A-TSD-ABSENT`.

### 1d — Confirm Generation Target

Ask:
> **"Which target should be generated: Logic App workflow, Function App, ADF pipeline, or a combination?"**

Do not proceed past this step until at minimum the FSD and Interface ID are confirmed.

---

## Step 2 — Read and Validate the FSD

Read the FSD and verify it contains, at minimum, the following sections:

| # | Required FSD Section | Field to Extract |
|---|---|---|
| 1 | Interface ID | `interfaceId` — must match `EAII-{number}` |
| 2 | Business Purpose (§1) | `businessPurpose` — one-line summary |
| 3 | Trigger Event (§4) | `triggerType`, `triggerSource`, `triggerFrequency`, `expectedVolume` |
| 4 | Source System (§5) | `sourceSystem`, `sourceFormat`, `sourceProtocol` |
| 5 | Target System (§6) | `targetSystem`, `targetFormat`, `targetProtocol` |
| 6 | Business Rules (§7) | `businessRules[]` — list of BR-NNN rules |
| 7 | Error Scenarios (§9) | `errorScenarios[]` — list of E-NNN scenarios |
| 8 | Acceptance Criteria (§10) | `acceptanceCriteria[]` — list of AC-NNN criteria |

If any of sections 1–5 are missing from the FSD, **stop and ask the user to complete the FSD**
before continuing. Sections 6–8 being absent is a warning only — log in assumptions.

### FSD Validation Checklist

- [ ] Interface ID present and matches `EAII-{number}`
- [ ] Business purpose is described (not just a placeholder)
- [ ] Trigger type and source system are identified
- [ ] Target system is identified
- [ ] At least one business rule is documented
- [ ] FSD status is "Review" or "Approved" (warn if still "Draft")

> If FSD status is "Draft", warn: _"FSD is still in Draft status. Proceeding with code
> generation against a Draft FSD creates re-work risk. Confirm with the user before continuing."_

---

## Step 3 — Read and Validate the TSD (if provided)

If a TSD is provided, read it and extract:

| # | TSD Section | Field to Extract |
|---|---|---|
| 1 | Architecture Pattern (§1) | `approvedPattern` — Logic App only / LA + Function / ADF |
| 2 | Workflow Design (§3) | `workflowName`, `triggerType`, `actionChain[]`, `appSettingsKeys[]` |
| 3 | Function App Design (§4) | `functionName`, `transformations[]`, `fileStructure` (if applicable) |
| 4 | ADF Pipeline Design (§5) | `pipelineName`, `linkedServices[]`, `datasets[]` (if applicable) |
| 5 | Field Mapping (§6) | `fieldMappings[]` — source → target with transformation rules |
| 6 | API Contracts (§7) | `sourceSchema`, `targetSchema`, `targetEndpoint` |
| 7 | Non-Functional Requirements (§8) | `payloadSize`, `dailyVolume`, `peakThroughput`, `latencySla` |
| 8 | Error Handling (§9) | `retryPolicy`, `deadLetterConfig`, `alertNames[]` |
| 9 | Observability (§10) | `smcLogPoints[]`, `smcQueueNames{}` |
| 10 | Security (§11) | `authMethod`, `secretsStrategy`, `piiFields[]` |

### TSD Absent — Inference Mode

If no TSD is provided, derive technical details from the FSD and log each assumption:

| FSD Data Available | Derived Technical Decision | Assumption Logged |
|---|---|---|
| Trigger type = "HTTP Request" | Logic App with HTTP trigger | A-TSD-001 |
| Trigger type = "Scheduled" | Logic App with Recurrence trigger (or ADF) | A-TSD-002 |
| Trigger type = "Message" | Logic App with Service Bus trigger | A-TSD-003 |
| Trigger type = "File / Bulk data" | ADF pipeline recommended | A-TSD-004 |
| Business rules require sorting/grouping | Function App co-located in Logic App | A-TSD-005 |
| Source format = XML; target = JSON | Transformation layer required | A-TSD-006 |
| No field mapping table in FSD | Ask user for mappings before codegen | A-TSD-007 |

---

## Step 4 — Produce the Design Intake Questionnaire ⏸️ MANDATORY PAUSE

**This is a stop-for-approval gate, the same pattern `metcash-tsd-generator`'s intake
questionnaire and `ais-codegen-readiness`'s readiness questionnaire both use — do not skip it or
treat it as an inline summary the agent can act on unattended.** Every technical decision in this
skill is *inferred*, not read from an approved TSD, which makes this pause more important here
than in the has-TSD path, not less.

Before finalizing the questionnaire, use `vscode_askQuestions` inline for each unresolved or
conflicting decision. State the proposed answer and its FSD/corpus evidence in the question, and
allow the user to confirm, correct, or leave it blocked. Ask dependent questions in sequence and
do not ask for facts already established by the FSD. Record each response and its provenance.

Then fill [`templates/design-intake-questionnaire.template.md`](templates/design-intake-questionnaire.template.md)
and write it to `outputs/<InterfaceID>/design-intake-questionnaire.md`. Every proposed answer —
the architecture choice above all — needs a `Proposed:` line with real evidence (FSD citation,
corpus precedent), never a bare label with no rationale. Populate it with:

- §1 Architecture: the archetype recommendation and evidence, including the closest matching
  precedent from `code-corpus/index.md`'s Interface → Repo Mapping if one exists — cite the EAII
  number, don't just assert a pattern name
- §2 Trigger/Source/Target: read directly from the FSD, for awareness (not a question)
- §3 Open Design Question(s): one numbered block per infra/architecture decision the FSD leaves
  genuinely unspecified (a caching strategy, a retry policy, anything with no stated FSD answer)
- §4 NFRs/error handling/observability: read directly from the FSD, for awareness
- §5 Gaps & Open Questions: **mandatory, never empty even if only one or two rows** — split into
  (A) FSD/transcript-unresolved and (B) Copilot-identified, exactly like the other questionnaires
  in this repo

**Then stop. Do not proceed to Step 5 under any circumstances until the user has explicitly
approved the questionnaire.** Tell the user the file is ready and where, and that intake is
paused until they respond — going quiet is not approval.

When the user confirms, re-read the file in full and treat every line (proposed or edited) as
settled fact for Step 5 onward.

---

## Step 4.5 — Resolve the Target Repo and Branch ⛔ MANDATORY, DO NOT SKIP

**No skill owns this step in the no-TSD path unless you do it here.** `ais-codegen-readiness`
resolves the repo/branch for the has-TSD path, but it explicitly refuses to run without a TSD —
and every `ais-*-codegen` skill's own instructions assume "the real repo clone resolved by
`ais-codegen-readiness`" regardless of which path was taken. If this step is skipped, a codegen
skill either invents a repo (an anti-pattern everywhere in this repo) or silently has nowhere
real to write.

1. **Search for an existing repo first** — the same evidence-based check
   `ais-codegen-readiness` Step 2 does: search `code-corpus/index.md`'s Interface → Repo Mapping
   for a sibling interface sharing this interface's workload, and if ADO MCP or the REST fallback
   (`az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798`, then
   `almsearch.dev.azure.com/.../codesearchresults`) is reachable, search Squad 20 for the
   interface ID and any named external system/keyword. **Do not skip this even when a new repo
   feels obvious** — confirms nothing partial already exists.
2. **If nothing exists, propose a new repo name** (`Metcash.AIS.{Platform}.{Service}`) with your
   reasoning, and **ask the user to confirm the domain token and whether to create the ADO remote
   now or locally-only for now** — a new repo (and its domain/platform classification) is a
   real, hard-to-reverse decision, not something to pick silently.
3. Clone (existing repo) or scaffold (new repo, no reference workspace to append into yet — build
   the minimal structural skeleton for the approved architecture: `host.json`, `.gitignore`/
   `.funcignore`, per-env `AppSettings`/`Connections`/`Parameters` folders, and a base
   `connections.json`/`parameters.json` containing only the universal SMC + Key Vault shape every
   AIS interface uses — see `code-corpus/patterns/02-logic-app-pattern.md` for the real shape).
   **Never fabricate a subscription ID, resource group, or Key Vault name that hasn't actually
   been provisioned** — mark those `<TBC — confirm with DevOps>` rather than invent a plausible
   value.
4. Create the feature branch `feature/EAII-<number>-<short-description>` off `main`.
5. Record the resolved **local clone path and branch** back into the approved questionnaire (or
   tell the user to add it) so the codegen skill in Step 5 doesn't have to re-ask.

---

## Step 5 — Route to the Correct Codegen Skill

Based on the **approved** questionnaire's §1 Architecture, invoke the appropriate skill:

| Approved Pattern | Skill to Invoke Next |
|---|---|
| Logic App Standard only | `ais-logicapp-codegen` |
| Logic App Standard + Function App | `ais-logicapp-codegen` then `ais-functionapp-codegen` |
| ADF only | `ais-datafactory-codegen` |
| ADF + Logic App | `ais-datafactory-codegen` then `ais-logicapp-codegen` |

Pass the full **approved questionnaire** as the starting context to the codegen skill. The
codegen skill must not re-ask questions already answered in it.

---

## Step 6 — Write Outputs

Write to `outputs/<InterfaceID>/`:

```
outputs/<InterfaceID>/
├── design-intake-questionnaire.md   ← Produced in Step 4, approved before Step 5 runs
└── assumptions.md                   ← All assumptions logged during intake (mirrors §3/§5 of the questionnaire)
```

`fsd.md`/`tsd.md` copies are not needed — the converted FSD (and transcript, if one exists)
already live under `tsd-inputs/<InterfaceID>/converted/`; reference that path rather than
duplicating the document into `outputs/`.

---

## Reference Templates

| Template | Path | Use |
|---|---|---|
| FSD template | `reference-templates/documentation/fsd.template.md` | Use when user needs to create an FSD from scratch |
| TSD template | `reference-templates/documentation/tsd.template.md` | Use when user needs to create a TSD from scratch |
| Spec template | `reference-templates/documentation/spec.template.md` | Combined technical spec (alternative to TSD) |
| Assumptions log | `reference-templates/documentation/assumptions.template.md` | Assumption log format |

> If the user does not yet have an FSD, offer to generate one using `fsd.template.md` as a
> starting point. Populate every `<PLACEHOLDER>` you can infer from the conversation, then ask
> the user to review and approve it before code generation begins.

---

## Anti-Patterns — Never Do These

- Do NOT start code generation if no FSD has been provided or confirmed.
- Do NOT assume the architecture pattern without reading §1 of the TSD or asking.
- Do NOT skip the Design Intake Questionnaire step — it is required input for codegen skills.
- Do NOT invent field mappings. If the FSD has no mapping table and the TSD is absent, ask.
- Do NOT proceed past a "Draft" FSD without an explicit user confirmation.

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `com.atlassian/atlassian-mcp-server-metcash` | Search Confluence pages | Find FSD by EAII ID |
| `com.atlassian/atlassian-mcp-server-metcash` | Get Confluence page content | Read full FSD / TSD text |
| `memory` | Store entity | Persist Design Intake Questionnaire for downstream codegen skills |

> Always attempt Atlassian MCP first. Only fall back to asking the user to paste content if
> the FSD page is not found in Confluence.
