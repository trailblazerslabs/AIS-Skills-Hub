# Design Intake Questionnaire — {EAII-ID} — {InterfaceName}

Generated: {date} | Source: `ais-design-intake` (no-TSD path) | Status: **AWAITING YOUR APPROVAL — code generation is paused**

**No TSD exists for this interface** — every technical decision below is *inferred* from the FSD
(and walkthrough transcript, where one exists), not read from an approved technical design. Some
sections need less scrutiny than others (things read straight off the FSD's own tables), but the
**Architecture** choice and any **Open Design Question** are real judgment calls made without a
TSD's authority behind them — review those especially closely.

- Agree with a proposal? Leave it as-is.
- Disagree? Edit the `Proposed:` line directly with your answer.

Then tell the agent the questionnaire is approved. **Code generation will not start until you
do** — proposed answers are recommendations, not silent defaults the agent will act on unattended.

---

## 1. Architecture

**Proposed:** {archetype — e.g. "APIM + Logic App Standard only", "Function App event-driven", "ADF pipeline"}

**Why:** {evidence from the FSD — trigger type, payload shape, volume — plus the closest real
precedent found in `code-corpus/index.md`'s Interface → Repo Mapping, cited by EAII number.
Rejected: {archetype} — {one-line reason}.}

> If no confident precedent exists in `code-corpus/`, say so explicitly here rather than picking
> an archetype with no evidence behind it.

**Resolved Target** *(filled in after approval, during Step 4.5 — repo/branch resolution)*:

- Repo: {repo name} — {new repo scaffolded / existing repo extended}
- Local clone: `{path}`
- Branch: `feature/EAII-{number}-{short-description}`

---

## 2. Trigger, Source & Target

No action needed unless something below is wrong — these are read directly from the FSD, shown
for your awareness, not inferred.

| Item | Value | FSD Source |
|---|---|---|
| Trigger type | {type} | {FSD §} |
| Source system(s) | {system(s)} | {FSD §} |
| Target system(s) | {system(s)} | {FSD §} |
| Endpoint(s) / path constraints | {value} | {FSD §} |

---

## 3. Open Design Question(s) — each has a proposed answer, edit any you disagree with

Only decisions the FSD leaves genuinely unspecified appear here (an architecture/infra choice, a
caching strategy, a retry policy) — settled facts belong in §2, not here.

### Q1. {question text}

**Proposed:** {best-supported answer} — *{one-line rationale: FSD evidence, corpus precedent, or
"no infra beyond what's already justified by volume/complexity"}*

<!-- Repeat one ### block per open question. Never leave one without a reasoned Proposed line. -->

---

## 4. Non-Functional Requirements, Error Handling & Observability

Read directly from the FSD — shown for awareness, not inferred. Correct anything wrong.

- NFRs: {payload size / volume / latency / availability, from FSD §}
- Error handling: {summary table or reference to FSD §}
- Observability: {logging/monitoring requirements, from FSD §}

---

## 5. Gaps & Open Questions — will carry into codegen and later into the TSD-equivalent record

Mandatory section — never omit it, even if only one or two rows. Split explicitly into two kinds:

- **(A) Transcript/FSD-unresolved** — a decision point the FSD or walkthrough raises but never
  actually closes (an "Open/Noted" row in the FSD's own context-considerations table, a live
  "we'll confirm that later" with no follow-up). If the FSD text and the transcript disagree or
  one is more specific than the other, say which one you treated as authoritative and why.
- **(B) Copilot-identified** — a gap noticed while cross-reading the FSD and transcript together
  that nobody raised explicitly: a schema table that doesn't match the process description's
  stated required fields, a hard constraint (like a fixed API path prefix) that might conflict
  with a standard naming/pattern convention, an infra decision with no stated owner.

| # | Kind | Item | Detail | Recommended action |
|---|---|---|---|---|
| G1 | (A) | {item} | {what's open, citation} | {what needs to happen before codegen locks it in} |

> Every row here must reappear as a real flagged item wherever this interface's design ends up
> recorded long-term (its TSD, if one gets written later; otherwise this questionnaire is the
> only record of these gaps) — never resolved silently by the codegen skill downstream.

---

## 6. Anything else the developer should know

Free text — known risks, naming preferences, sibling interfaces to reuse a workload token from,
non-standard environments.

> _______________

---

*Review the proposals above, edit anything you disagree with, then tell the agent "questionnaire
approved" (or similar) to route to the codegen skill indicated by §1. The agent will not proceed
on its own — this pause is mandatory.*
