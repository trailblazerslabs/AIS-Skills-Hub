---
name: ais-test-results-to-ado
description: |
  Metcash AIS test results recorder. USE FOR: taking the executed outcomes from
  ais-test-execution (test-execution-log.md) and recording them as Test Results against the
  ADO Test Plan/Suite/Cases that ais-unit-test-cases already created, completing the Test Run,
  and posting a pass/fail summary comment on the EAII work item.
  DO NOT USE FOR: generating test cases (use ais-unit-test-cases), running the tests
  (use ais-test-execution), or creating the initial Test Plan/Suite (already done by
  ais-unit-test-cases — never create a second, duplicate plan here).
  Triggers: "record test results", "upload results to ado", "update ado test run", "mark test
  cases pass/fail", "close the test run", "publish test outcomes", "test run complete".
---

# AIS Test Results to ADO — Record Execution Outcomes

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — confirm Phase 6 (Test Execution) is Done before starting, update
> Phase 7's row on completion.

Records real, already-executed outcomes (from `ais-test-execution`) against the existing ADO
Test Plan for this interface, closes the Test Run, and updates the EAII work item. This is the
last step of the TSD → code → tests pipeline.

---

## Required Inputs

| Input | Source |
|---|---|
| EAII ID | User or ADO work item |
| ADO Test Plan/Suite/Case IDs | `outputs/<InterfaceID>/ado-test-case-creation-result.json`, written by `ais-unit-test-cases` — read this, don't re-derive or guess suite IDs |
| Per-test-case outcome + evidence | `outputs/<InterfaceID>/test-execution-log.md` from `ais-test-execution` |

Stop and ask if `test-execution-log.md` doesn't exist yet — run `ais-test-execution` first.
Never invent an outcome; only record what was actually captured during execution.

---

## Workflow

1. Find the existing Test Plan/Suite for this interface from
   `outputs/<InterfaceID>/ado-test-case-creation-result.json` — never create a new plan here,
   and never re-search by name if that file already has the IDs.
2. Get the test points (test case ↔ suite associations) for the plan's suites so results can
   be attached to the correct point, not just the bare test case.
3. Create a Test Run against those points (see **Step-by-step** below).
4. Add one Test Result per test case: `outcome` (`Passed`/`Failed`/`Blocked`), a `comment`
   containing the run/correlation ID and actual outcome text from `test-execution-log.md`.
5. Complete the Test Run (`state: "Completed"`).
6. Post a summary comment to the EAII work item (via `azure-devops-work-items`):
   `"Executed N test cases via ais-test-execution: X Passed, Y Failed. Test Run #<id>: <url>."`
7. If any case Failed, do not close out the interface as done — flag it back to the user and,
   if it's a code defect, hand off to `ais-debug-azure`.

---

## Step-by-Step (check ADO MCP once, then use the proven REST fallback)

**Auth:** same rule as `ais-unit-test-cases` Step 0 — `azure-devops-mcp-metcash` only works if
`az account show` shows a `*.metcash.com`/`metcash.onmicrosoft.com` session; "✔ Connected" in
`claude mcp list` does not prove that. If it's the wrong tenant, `az login --tenant
metcash.onmicrosoft.com` fixes it. If the tenant is already right and the MCP tools still don't
appear in `ToolSearch`, don't keep retrying — go straight to the REST calls below using an AAD
bearer token (no PAT needed):

```powershell
$token = az account get-access-token --resource "499b84ac-1321-427f-aa17-267ca6975798" --query accessToken -o tsv
$headers = @{ Authorization = "Bearer $token" }
# use $headers below, then $token = $null when done — never write it to a file
```

A PAT (`Authorization: Basic <base64(:pat)>`, per `azure-local-auth`) also works if supplied —
verify it against a real read call first, since an unrelated/expired PAT will 401 silently.

### Step 1 — Locate the Test Plan, Suite, and Test Points

The plan/suite this interface's cases live in is whatever `ais-unit-test-cases` recorded in
`outputs/<InterfaceID>/ado-test-case-creation-result.json` (suite id, plan id 224095, and the
CSV-TestCaseID → work-item-id mapping) — read that file first rather than re-deriving IDs.
Get the test points (test case ↔ suite associations) needed to attach results:

```powershell
Invoke-RestMethod -Method Get -Headers $headers `
  -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/testplan/Plans/224095/Suites/<suiteId>/TestPoint?api-version=7.1"
```

### Step 2 — Create a Test Run

```powershell
$body = @{ name = "EAII-<number> — <InterfaceName> Test Run <date>"; plan = @{ id = "224095" }; pointIds = @(<pointId-1>, <pointId-2>) } | ConvertTo-Json
$run = Invoke-RestMethod -Method Post -Headers $headers -ContentType "application/json" `
  -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/test/runs?api-version=7.1-preview.3" -Body $body
```

### Step 3 — Add Test Results

```powershell
$results = @(
  @{ testCaseTitle = "Single item processed successfully"; testCase = @{ id = "<testCaseWorkItemId>" };
     testPoint = @{ id = "<pointId>" }; outcome = "Passed";
     comment = "corr-abc123 — 200, record created, SMC log Succeeded" }
) | ConvertTo-Json -Depth 5

Invoke-RestMethod -Method Post -Headers $headers -ContentType "application/json" -Body $results `
  -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/test/Runs/$($run.id)/results?api-version=7.1"
```

### Step 4 — Complete the Run

```powershell
Invoke-RestMethod -Method Patch -Headers $headers -ContentType "application/json" `
  -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/test/runs/$($run.id)?api-version=7.1" `
  -Body (@{ state = "Completed" } | ConvertTo-Json)
```

### Step 5 — Update the EAII Work Item

Comment on the interface's own "Unit Testing" (or relevant stage) Task work item — find it via
WIQL (`System.Title CONTAINS 'EAII-{number}'`), not a made-up single "EAII work item":

```powershell
$comment = @{ text = "Executed N test cases: X Passed, Y Failed. Test Run #$($run.id): https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/test/runs/$($run.id)" } | ConvertTo-Json
Invoke-RestMethod -Method Post -Headers $headers -ContentType "application/json" -Body $comment `
  -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/wit/workitems/<workItemId>/comments?api-version=7.1-preview.4"
```

---

## Output

`outputs/<InterfaceID>/test-results-summary.md`:

```markdown
# Test Results Summary: EAII-<number> — <InterfaceName>

**Test Run:** #<runId> — <ADO Test Run URL>
**Executed:** <date> in <environment>

| Category | Total | Passed | Failed |
|---|---|---|---|
| Happy Path | 4 | 4 | 0 |
| Error Path | 3 | 3 | 0 |
| Boundary | 2 | 2 | 0 |
| Business Logic | 3 | 2 | 1 |

## Failures
| TestCaseID | Reason | Follow-up |
|---|---|---|
| TC-008 | Null field produced NullReferenceException instead of default value | Handed to ais-debug-azure |
```

---

## Rules

- Never create a second Test Plan for the same interface — reuse the one `ais-unit-test-cases`
  already created; if it can't be found, stop and ask rather than duplicating it.
- Every recorded outcome must trace back to a row in `test-execution-log.md` — no result
  without captured evidence.
- A Test Run that includes any `Failed` result is still marked `Completed` in ADO (that's the
  accurate state) — do not skip closing it, and do not soften a Failed outcome to Passed.
- Always link the Test Run back to the EAII work item via a comment, so status is visible
  without opening ADO directly.

---

## Auth & Tooling Notes

Same rule as `ais-unit-test-cases`: `azure-devops-mcp-metcash` needs `az login` on the
`metcash.onmicrosoft.com` tenant to expose any tools at all — "✔ Connected" alone doesn't mean
its tools are usable. If `az account show` is already correct and the tools still don't appear,
use the REST calls above (AAD bearer token via `az account get-access-token --resource
499b84ac-1321-427f-aa17-267ca6975798`) rather than waiting on a restart.

## MCP Servers / Tools Used in This Skill

| Tool | Purpose |
|---|---|
| `azure-devops-mcp-metcash` MCP tools (`testplan_*`, `wit_*`) | Preferred if actually exposed — check once, don't wait on it |
| ADO REST API via `az login` AAD bearer token | Proven fallback — same pattern as `ais-unit-test-cases` |
| `memory` | Retrieve entity — load Test Plan/Suite IDs and interface context from the `ais-unit-test-cases` step |

## References

- [ais-unit-test-cases](../ais-unit-test-cases/SKILL.md) — creates the Test Plan/Suite/Cases this skill attaches results to
- [ais-test-execution](../ais-test-execution/SKILL.md) — produces the execution log this skill consumes
- [azure-devops-work-items](../azure-devops-work-items/SKILL.md) — work item comment conventions
- [ais-debug-azure](../ais-debug-azure/SKILL.md) — next step for any Failed outcome caused by a code defect
