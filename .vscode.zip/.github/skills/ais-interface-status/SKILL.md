---
name: ais-interface-status
description: |
  Metcash AIS interface status tracker — the standing "where did we leave off" record for a
  single interface, checked at the START of every SDLC skill and updated at the END of every
  one. USE FOR: resuming an interface across sessions without re-deriving its history from git
  log, chat scrollback, or scattered outputs/ files; answering "what's the status of EAII-<n>";
  recording which phase is done, what's still open, and what real evidence (Confluence
  attachments, ADO search results) was already fetched so it isn't re-fetched. This is a
  cross-cutting Ways of Working practice, not a one-off deliverable — every other AIS SDLC skill
  (metcash-tsd-generator, ais-design-intake, ais-codegen-readiness, the ais-*-codegen skills,
  ais-unit-test-cases, ais-test-execution, ais-test-results-to-ado, ais-documentation,
  ais-code-review, ais-deployment-runsheet, ais-smc-failure-retrieval) reads this file first and
  writes to it last.
  DO NOT USE FOR: replacing the TSD, the questionnaires, or any other skill's own real
  deliverable — this file is a pointer/index to those, never a substitute for them.
  Triggers: "what's the status of EAII", "where did we leave off", "resume this interface",
  "pick this interface back up", "interface status", "what's been done for EAII".
---

# AIS Interface Status — Cross-Session Resume Point

**The problem this solves, confirmed real in this project:** two separate times in one session,
the user had to ask "why did it get missed?" and "did we generate a TSD for this? why did we
skip it?" — not because anything was actually done wrong, but because the *reasoning* for a
routing decision (no-TSD path explicitly instructed, TSD generated later as-built) only existed
in chat scrollback, not in any durable file. The next session — or the next developer — has no
way to reconstruct that without re-reading the whole conversation.

## The file: `outputs/<InterfaceID>/status.md`

One file per interface, at [`templates/status.template.md`](templates/status.template.md)'s
structure. Like every other file in `outputs/<InterfaceID>/`, this is **documents-only, local
scratch** — it is not code, not committed to the shared prompts repo differently than any other
`outputs/` file (see the repo's global `outputs/*` gitignore rule), and it never substitutes for
the TSD, a questionnaire, or the actual generated code as the record of truth for *what was
decided*. It exists purely to answer *where things currently stand* at a glance.

## ⛔ Mandatory: check first, update last — for every SDLC skill, not just this one

This is a **Ways of Working** rule that applies across the entire SDLC cycle, not a single
skill's own step:

1. **Before starting any phase for an interface that might already have history**, check whether
   `outputs/<InterfaceID>/status.md` exists. If it does, read the **Quick Resume** and **Open
   Gaps** sections before doing anything else — before re-reading the FSD, before re-deriving an
   architecture decision, before asking the user a question the file already answers. Treat a
   stale-looking status file as a signal to verify against the real artifacts (git log, the TSD,
   the actual repo), not as ground truth to blindly trust — but it's the fastest way to know
   *what to go verify*, rather than starting from zero.
2. **After completing any phase**, update the file:
   - Set that phase's row in the **SDLC Phase Checklist** to `Done` (or `Blocked — {reason}`),
     with today's date and a link to the real artifact (questionnaire path, TSD path, repo/branch,
     ADO suite URL — whatever this phase actually produced).
   - Append any new gap found to **Open Gaps** — never let a gap exist only in a questionnaire or
     a TSD's own §12/§13 without also being indexed here, since this is the file a resuming
     session reads *first*, before it would otherwise discover the TSD even has an open-gaps
     section.
   - Rewrite **Quick Resume** to reflect the new state in 2-3 sentences — this is the single most
     important edit; a stale Quick Resume is worse than none, since it actively misleads the next
     session.
   - If real external evidence was fetched this session (a Confluence attachment, an ADO code
     search result, a downloaded schema), log it under **Real Evidence Fetched This Session** so
     a future session doesn't repeat the same fetch (or worse, re-ask the user for permission to
     fetch something already sitting in the repo).
3. **If no `status.md` exists yet for an interface already in progress** (e.g. this rule was
   just added and older interfaces predate it), create one now from the template, backfilling
   its phase checklist from whatever real evidence exists (git log on the target repo, existing
   `outputs/<InterfaceID>/*` files, the TSD if one exists) — do not skip backfilling just because
   the interface didn't start under this rule.

## What this looks like in practice, per phase

| Skill | What it reads from `status.md` at Step 0 | What it writes at completion |
|---|---|---|
| `metcash-tsd-generator` / `ais-design-intake` | Whether a design-intake or TSD phase already ran (avoid re-running Step 0.1-0.5 from scratch if a questionnaire already exists) | Phase 1 row → Done, link to the questionnaire/TSD, architecture decision under Key Decisions |
| `ais-codegen-readiness` / `ais-design-intake` Step 4.5 | Whether a repo/branch was already resolved | Phase 2 row → Done, Repo/Branch section filled in |
| `ais-*-codegen` | Which operations/workflows are already generated (don't regenerate what's done) | Phase 3 row → Done or In Progress with a note on what's left |
| `ais-unit-test-cases` | Whether a CSV/questionnaire/ADO suite already exists (avoid creating a duplicate suite) | Phases 4-5 rows → Done, ADO suite link |
| `ais-test-execution` / `ais-test-results-to-ado` | Whether tests have already been run | Phases 6-7 rows |
| `ais-code-review` / `ais-deployment-runsheet` | Whether earlier phases are actually Done before reviewing/deploying — **stop and flag if this skill would run ahead of an incomplete phase** | Phases 9-10 rows |
| `ais-smc-failure-retrieval` | Whether an SMC export already exists and whether it is complete | Record the local export path, count, completeness, and permission/filter gaps; never copy record data into `status.md` |

## Anti-Patterns — Never Do These

- Do NOT let `status.md` become the *only* record of a decision — it links to the real artifact
  (questionnaire, TSD, ADO suite); it never contains the decision's own full rationale in place
  of that artifact.
- Do NOT skip updating it because "the chat already explains it" — the whole point is surviving
  past the current chat session.
- Do NOT treat a missing `status.md` as blocking — create it (backfilled) rather than stopping
  the actual requested work to ask the user for permission first.
- Do NOT let it go stale mid-session — update it at each phase boundary, not just once at the end
  of a long session, so an interruption mid-work still leaves an accurate resume point.
