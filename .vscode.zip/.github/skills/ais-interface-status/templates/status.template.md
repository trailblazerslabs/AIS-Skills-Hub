# Interface Status — {EAII-ID} — {InterfaceName}

**Last updated:** {date} by `{skill-name}`

## Quick Resume

*(2-3 sentences max — where this interface currently stands, and the single next action. This
is the first thing to read when picking this interface back up — write it for someone with zero
memory of this interface, not a note to yourself.)*

> {one-paragraph summary}

## SDLC Phase Checklist

Every phase that applies to this interface's architecture gets a row — mark phases that don't
apply `N/A`, never leave a row blank/ambiguous.

| # | Phase | Skill | Status | Date | Artifact / Link |
|---|---|---|---|---|---|
| 1 | Design Intake / TSD | `metcash-tsd-generator` (default) or `ais-design-intake` (no-TSD exception, only if explicitly confirmed) | Not Started | | |
| 2 | Codegen Readiness (repo + branch resolved) | `ais-codegen-readiness` (has-TSD) or `ais-design-intake` Step 4.5 (no-TSD) | Not Started | | |
| 3 | Code Generation | `ais-logicapp-codegen` / `ais-functionapp-codegen` / `ais-datafactory-codegen` | Not Started | | |
| 4 | Unit Test Cases (CSV) | `ais-unit-test-cases` | Not Started | | |
| 5 | ADO Test Suite | `ais-unit-test-cases` (ADO Test Plan Integration) | Not Started | | |
| 6 | Test Execution | `ais-test-execution` | Not Started | | |
| 7 | Test Results → ADO | `ais-test-results-to-ado` | Not Started | | |
| 8 | Documentation | `ais-documentation` | Not Started | | |
| 9 | Code Review | `ais-code-review` | Not Started | | |
| 10 | Deployment Runsheet | `ais-deployment-runsheet` | Not Started | | |
| 11 | SMC DEV Failure Retrieval | `ais-smc-failure-retrieval` | Not Started | | |

**Status values:** `Not Started` · `In Progress` · `Done` · `Blocked — {reason}` · `N/A — {why this phase doesn't apply}`

## Review Gates

Track each reviewer decision separately from artifact generation. Percentages require linked
evidence; a Critical/High finding or unmet hard gate blocks PASS regardless of score.

| Gate | Required artifact | Score | Status | Reviewer / date | Decision / blocking findings |
|---|---|---:|---|---|---|
| TSD review | `outputs/<EAII-ID>/tsd-review-checklist.md` | — | Not Started | | |
| Code review (including build + unit-test status) | `outputs/<EAII-ID>/code-review-report.md` | — | Not Started | | |
| SIT runsheet review | `outputs/<EAII-ID>/deployment-runsheet-review-SIT.md` | — | Not Started | | |
| UAT/UT1 runsheet review | `outputs/<EAII-ID>/deployment-runsheet-review-UT1.md` | — | Not Started | | |
| PRD runsheet review | `outputs/<EAII-ID>/deployment-runsheet-review-PRD.md` | — | Not Started | | |
| PRD readiness runbook | `outputs/<EAII-ID>/prd-deployment-readiness-runbook.md` | — | Not Started | | |

## Open Gaps (carried across every phase — never dropped silently)

| # | Gap | Raised in | Status | Next step to resolve |
|---|---|---|---|---|

## Key Decisions & Architecture

*(short bullets — archetype chosen and why, workload token, anything a resuming session needs to
know before re-deriving it from scratch)*

-

## Repo / Branch

- **Repo:** {name} — {new / existing}
- **Branch:** {branch name}
- **Local clone path:** {path}
- **Remote status:** {not yet pushed / pushed, PR #N open / merged}

## Real Evidence Fetched This Session

*(anything pulled from an external source — Confluence attachments, ADO code search results,
etc. — that a resuming session shouldn't have to re-fetch. Include the source and where the
result now lives.)*

-
