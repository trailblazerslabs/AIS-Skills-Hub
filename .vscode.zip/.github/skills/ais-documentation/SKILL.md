---
name: ais-documentation
description: |
  Metcash AIS interface documentation generator. USE FOR: generating technical specification
  documents, data flow descriptions, interface overviews, assumption logs, change summaries,
  and field mapping tables for Azure Integration interfaces (Logic Apps, Function Apps, ADF
  pipelines, Service Bus). DO NOT USE FOR: code generation, architecture recommendation,
  deployment planning, or TIBCO source analysis.
  Triggers: "generate documentation", "create spec", "interface documentation",
  "technical specification", "document this interface", "write assumption log",
  "data flow diagram", "field mapping", "change summary".
---

# AIS Documentation

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — update Phase 8's row on completion.

Generate structured technical documentation for Metcash AIS integration interfaces.

## Required Inputs

- Interface ID (must match `EAII-{number}`)
- Interface name and brief description
- Source system and target system
- Data flow summary (what moves where)
- Any known field mappings or transformation rules

Before generating a document, compare the required inputs with the TSD/FSD, mappings, code and
existing approved records. For each missing, ambiguous or conflicting fact, use
`vscode_askQuestions` inline with the proposed value, evidence/source and impact; let the user
confirm, correct or leave it blocked. Batch independent questions and ask dependent questions in
sequence. Do not write the document until required facts are answered. Record user-supplied or
provisional facts in `assumptions.md` with provenance; never silently fill a gap from another
interface's example.

## Document Types

### 1. Technical Specification (`spec.md`)

Full interface specification including:

```markdown
# Technical Specification: <InterfaceName> (<InterfaceID>)

## Overview
| Field | Value |
|---|---|
| Interface ID | EAII-NNN |
| Interface Name | ... |
| Source System | ... |
| Target System | ... |
| Pattern | Logic App Standard / Logic App + Function App / ADF |
| Trigger Type | HTTP / Service Bus / Timer / Blob |
| Environment | dev / sit / uat / prd |

## Data Flow
[Describe message path: source → trigger → transform → target]

## Field Mapping
| Source Field | Target Field | Transformation | Notes |
|---|---|---|---|

## Non-Functional Requirements
| Dimension | Requirement |
|---|---|
| Payload size | ... |
| Volume | ... |
| Latency SLA | ... |
| Reliability | ... |

## Error Handling
[Describe retry, dead-letter, and alerting strategy]

## Observability
[SMC logging points, alert definitions]

## Assumptions
[Numbered list of assumptions made during design]
```

### 2. Assumption Log (`assumptions.md`)

```markdown
# Assumptions: <InterfaceID>

Generated: <date>
Author: GitHub Copilot

| # | Assumption | Impact if Wrong | Status |
|---|---|---|---|
| 1 | ... | ... | Open / Confirmed |
```

### 3. Change Summary (`change-summary.md`)

```markdown
# Change Summary: <InterfaceID>

## What Changed
[High-level description]

## Files Added / Modified
| File | Change Type | Description |
|---|---|---|

## Testing Notes
[What was tested and how to verify]
```

### 4. Data Flow Diagram (Mermaid)

Generate a Mermaid flowchart showing source → processing → target:

```mermaid
flowchart LR
    Source([Source System]) --> Trigger[Logic App Trigger]
    Trigger --> Transform[Function App Transform]
    Transform --> Target([Target System])
    Trigger -.->|Error| DLQ[Dead Letter Queue]
    Transform -.->|Error| SMC[SMC Alert]
```

## Output Location

Write all documents to `outputs/<InterfaceID>/`:

```
outputs/EAII-NNN/
├── spec.md
├── assumptions.md
├── change-summary.md
└── data-flow.md
```

## Style Rules

- Use Markdown tables for field mappings and NFR grids.
- Keep sentences short and factual — avoid marketing language.
- Every assumption must be numbered and have an impact statement.
- Use the interface ID in all document headings.

## Reference Assets

- [Field Mapping Template](assets/field-mapping-template.md)
- [Spec Template](assets/spec-template.md)
