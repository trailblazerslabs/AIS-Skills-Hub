---
name: ais-test-execution
description: |
  Metcash AIS test execution skill. USE FOR: actually running the unit test cases that
  ais-unit-test-cases generated against a deployed Logic App, Function App, ADF pipeline, or
  Service Bus-triggered interface in a non-production environment (dev/sit/uat/ut1), using
  Azure CLI / direct HTTP calls to fire each trigger and capture the real outcome. For DEV runs,
  requires an SMC error snapshot after the ADO suite is complete and before the first test trigger.
  DO NOT USE FOR: generating unit-test-cases.csv (use ais-unit-test-cases), recording outcomes
  in Azure DevOps (use ais-test-results-to-ado), or debugging a production failure (use
  ais-debug-azure). NEVER run this skill against a PRD resource.
  Triggers: "run the unit tests", "execute test cases", "test this interface", "trigger a test
  run", "fire the workflow", "send a test message", "run pipeline test", "execute test plan",
  "retrieve SMC error baseline before test execution".
---

# AIS Test Execution — Run Unit Test Cases Against a Live Interface

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — confirm Phase 5 (ADO Test Suite) is Done before starting, update
> Phase 6's row on completion.

Executes each row of `outputs/<InterfaceID>/unit-test-cases.csv` against the real, deployed
resource in a non-prod environment and records the actual outcome. This is the step between
"tests exist" and "tests passed" — do not skip it and do not fabricate results.

---

## Required Inputs

| Input | Source |
|---|---|
| EAII ID | User or ADO work item |
| Environment | `dev` / `sit` / `uat` (AIS token: `dv1`/`st1`/`ut1`) — **never `prd`** |
| `unit-test-cases.csv` | `outputs/<InterfaceID>/unit-test-cases.csv` (from `ais-unit-test-cases`) |
| Architecture archetype + trigger type | Design Intake Questionnaire or TSD (APIM-only, APIM+Logic App, Function App event-driven, file/MFT batch) |
| Resource names (Logic App, Function App, ADF, Service Bus namespace) | Squad 20 naming conventions / generated code |

Stop and ask if the trigger type or resource names are not known — never guess a resource name.

---

## Pre-flight: Authentication

Complete `azure-local-auth` first. Confirm the active subscription matches the target
environment before sending anything:

```powershell
az account show --query "{name:name, id:id}" -o table
```

## Mandatory SMC Error Snapshot (DEV)

After confirming Phase 5 (ADO Test Suite) is `Done`, but **before firing the first test case**, invoke
`ais-smc-failure-retrieval` for this interface. This is a required execution preflight, not an
optional diagnostic. Do not trigger unit tests until the retrieval completes with `complete: true`.
If the retrieval is partial, blocked by access, or requires confirmation for a large export, stop
before sending test payloads and resolve that condition with the user. Record the local export path
and count in the execution log; treat this snapshot as the pre-test baseline, not as a test outcome.
The helper is DEV-only; SIT/UAT execution does not call it.

---

## Workflow

1. Read `unit-test-cases.csv`. For each row, identify: `TestCaseID`, `InputDescription`,
   `ExpectedOutput`, `ValidationPoints`.
2. Determine the trigger mechanism from the interface's archetype (see table below).
3. Build the input payload described in `InputDescription` (as a JSON file if the payload is
   non-trivial — never inline large payloads in a CLI arg).
4. Fire the trigger (commands below). Capture: HTTP status / run ID, `startTime`/`endTime`,
   and the raw response or run output.
5. Poll until the run reaches a terminal state (`Succeeded`/`Failed`/`Completed`).
6. Compare the actual outcome against `ExpectedOutput` and each line in `ValidationPoints`.
7. Record one result row per test case (see **Output** below) — Pass only if every validation
   point is verifiably true, not just "no error was thrown".
8. Repeat for every row and finish the execution log.
9. Hand off the execution log and SMC baseline path to `ais-test-results-to-ado`. The baseline does
  not change test verdicts by itself.

---

## Trigger Mechanisms by Archetype

| Archetype | Trigger | How to Fire |
|---|---|---|
| APIM-only / APIM + Logic App (HTTP) | HTTP request via APIM | `curl` the APIM gateway URL with the `Ocp-Apim-Subscription-Key` header |
| Logic App Standard, direct HTTP trigger (no APIM) | Workflow HTTP trigger | Get the callback URL, then `curl` it |
| Function App event-driven (Service Bus) | Service Bus message | `az servicebus queue message send` / `topic message send` |
| Function App event-driven (HTTP) | Function HTTP trigger | `curl` with the function key |
| File/MFT batch (ADF) | Pipeline run | `az datafactory pipeline create-run` |

### APIM-fronted HTTP interface

```powershell
curl -X POST "https://<apim-name>.azure-api.net/<api-path>" `
  -H "Ocp-Apim-Subscription-Key: <subscription-key-from-keyvault>" `
  -H "Content-Type: application/json" `
  -d "@testcase-<TC-NNN>-input.json" `
  -w "`nHTTP %{http_code}`n"
```

### Logic App Standard — direct HTTP request trigger (no APIM)

```powershell
# Get the callback URL for the request trigger
az rest --method post `
  --url "https://management.azure.com/subscriptions/<sub-id>/resourceGroups/<rg>/providers/Microsoft.Web/sites/<logicapp-name>/hostruntime/runtime/webhooks/workflow/api/management/workflows/<workflow-name>/triggers/<trigger-name>/listCallbackUrl?api-version=2018-11-01"

# Fire it
curl -X POST "<callback-url-from-above>" -H "Content-Type: application/json" -d "@testcase-<TC-NNN>-input.json"
```

### Service Bus — send a test message

```powershell
az servicebus queue message send `
  --resource-group <rg> --namespace-name <sb-namespace> --queue-name <queue-name> `
  --body "$(Get-Content testcase-<TC-NNN>-input.json -Raw)"

# Topic variant
az servicebus topic message send `
  --resource-group <rg> --namespace-name <sb-namespace> --topic-name <topic-name> `
  --body "$(Get-Content testcase-<TC-NNN>-input.json -Raw)"
```

Then poll the Logic App / Function App run history (see `ais-debug-azure` for run-history
commands) to find the run the message triggered.

### Function App — direct HTTP trigger

```powershell
$key = az functionapp function keys list `
  --name <function-app-name> --resource-group <rg> --function-name <function-name> `
  --query "default" -o tsv

curl -X POST "https://<function-app-name>.azurewebsites.net/api/<function-name>?code=$key" `
  -H "Content-Type: application/json" -d "@testcase-<TC-NNN>-input.json"
```

### ADF Pipeline

```powershell
$runId = az datafactory pipeline create-run `
  --factory-name <adf-name> --resource-group <rg> --name <pipeline-name> `
  --parameters "@testcase-<TC-NNN>-parameters.json" --query "runId" -o tsv

az datafactory pipeline-run show `
  --factory-name <adf-name> --resource-group <rg> --run-id $runId
```

---

## Verifying the Outcome

- **HTTP interfaces:** check the returned status code and body against `ExpectedOutput`.
- **Async/queue-triggered interfaces:** check the Logic App/Function run history for a
  `Succeeded` run correlated by timestamp (or a correlation ID in the payload), per
  `ais-debug-azure`.
- **Data outcome validation (UT1 only):** query the target table via the Azure SQL MCP
  (`azure-sql-b2b-ut1`) to confirm the record actually landed with the expected values —
  a `200 OK` alone does not prove the data arrived correctly.
- **SMC log confirmation:** search SMC by `EAII-{number}` and correlation ID for a
  `Succeeded` entry matching this run.

---

## Output

Write one row per test case to `outputs/<InterfaceID>/test-execution-log.md`:

```markdown
| TestCaseID | ExecutedAt | Trigger Method | Run/Correlation ID | Actual Outcome | Outcome |
|---|---|---|---|---|---|
| TC-001 | 2026-09-18T10:15:00Z | APIM HTTP | corr-abc123 | 200, record created, SMC log Succeeded | Pass |
| TC-004 | 2026-09-18T10:16:12Z | Service Bus | run-def456 | Message dead-lettered as expected | Pass |
```

Also update the `Status` column of `unit-test-cases.csv` from `Draft` to `Executed - Pass` /
`Executed - Fail` for each row.

---

## Rules

- **Never execute against PRD.** Confirm the environment before every run; default to the
  lowest available non-prod environment (`dev`/`sit`) unless the user specifies otherwise.
- Never mark a test `Pass` without a captured, verifiable result — no result, no verdict.
- Use realistic but non-sensitive test payloads; never send real customer/PII data as a test
  payload, even in non-prod.
- Capture the run/correlation ID for every execution — it is required evidence for
  `ais-test-results-to-ado` and for any later debugging.
- If a test case's trigger type isn't covered above (e.g., a file drop for MFT batch), ask
  before inventing a triggering mechanism.

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `azure-sql-b2b-ut1` | Query | Validate data outcome landed correctly in UT1 |
| `microsoft/azure-devops-mcp-metcash` | `wit_get_work_item` | Confirm interface/resource names from the EAII work item |
| `memory` | Retrieve/store entity | Load interface context; persist execution log across a multi-step session |

## References

- [ais-unit-test-cases](../ais-unit-test-cases/SKILL.md) — produces the CSV this skill executes
- [ais-test-results-to-ado](../ais-test-results-to-ado/SKILL.md) — next step, records outcomes in ADO
- [ais-debug-azure](../ais-debug-azure/SKILL.md) — run-history and log-inspection commands reused here
- [azure-local-auth](../azure-local-auth/SKILL.md) — required auth setup before running this skill
