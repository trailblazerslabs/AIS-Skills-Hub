#!/usr/bin/env python3
"""Lint a generated Logic App Standard workspace against the Squad 20 PRODUCTION pattern.

The rules were calibrated on code that is live in production (the `main` branch of the Squad 20 repos, where the
PRD stage of the pipeline runs only from `refs/heads/main`): Metcash.AIS.B2B.RealTimePricing (EAII-514) and
Metcash.AIS.B2B.IBADirects (EAII-304). Both must pass with 0 errors; see code-corpus/production-snapshot.md.

Usage:
    python check_logicapp.py <LogicApp workspace dir> [--repo-root <repo clone>] [--strict]

<LogicApp workspace dir> is the folder that holds one sub-folder per workflow (each with workflow.json) plus
AppSettings/, Connections/, Parameters/, connections.json, parameters.json and host.json.
Exit code 1 when there is at least one error (or any warning with --strict).
"""
import argparse
import json
import re
import sys
from pathlib import Path

ENVS = ["dev", "sit", "uat", "prd"]
SMC_VARS = ["SMCGuid", "SMCErrors", "SMCStagesStatus", "SMCStages", "SMCCorrelationProperties"]
SMC_SEND_FIELDS = ["SMCGuid", "SMCStages", "SMCStagesStatus", "SMCCorrelationProperties"]
SMC_APPSETTINGS = ["APIM_BaseUrl_SMC", "ServiceBus_FullyQualifiedNamespace_SMC", "SMC_QueueName",
                   "SMC_API_Subscription_Key", "WORKFLOWS_ENVIRONMENT"]
FAIL_STATES = {"FAILED", "TIMEDOUT"}


class Report:
    def __init__(self):
        self.items = []

    def add(self, level, rule, where, msg):
        self.items.append((level, rule, where, msg))


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8-sig"))


def walk(actions, path=""):
    """Yield (path, name, action) for every action, depth first."""
    for name, a in (actions or {}).items():
        yield path, name, a
        for key in ("actions",):
            if key in a:
                yield from walk(a[key], f"{path}{name}/")
        if "else" in a:
            yield from walk(a["else"].get("actions", {}), f"{path}{name}/else/")
        for cname, c in (a.get("cases") or {}).items():
            yield from walk(c.get("actions", {}), f"{path}{name}/{cname}/")
        if "default" in a:
            yield from walk(a["default"].get("actions", {}), f"{path}{name}/default/")


def check_workflow(wf_path, rep):
    where = str(wf_path.parent.name)
    try:
        d = load(wf_path)
    except Exception as e:  # noqa: BLE001
        rep.add("error", "LA-01", where, f"workflow.json is not valid JSON: {e}")
        return {}
    dfn = d.get("definition")
    if not dfn:
        rep.add("error", "LA-01", where, "no `definition` object")
        return {}
    if str(d.get("kind", "")).lower() not in ("stateful", "stateless"):
        rep.add("error", "LA-02", where, "`kind` must be Stateful or Stateless (production writes it as Stateful or stateful)")
    if str(d.get("kind", "")).lower() == "stateless":
        rep.add("warning", "LA-02", where, "Stateless: every production workflow is Stateful (run history is what support uses with SMC); if the TSD asks for Stateless, record it as an assumption to confirm")
    trig = dfn.get("triggers") or {}
    if len(trig) != 1:
        rep.add("error", "LA-01", where, f"exactly one trigger expected, found {len(trig)}")
    actions = dfn.get("actions") or {}
    top = actions
    used = {"serviceBus": False, "serviceBusSMC": False, "apim": False, "text": json.dumps(d)}

    # --- every action carries runAfter
    # production omits runAfter on the first action of a scope or branch; at top level only the variable
    # initialisers may omit it (they run in parallel at the start).
    for path, name, a in walk(actions):
        if "runAfter" not in a and not path and a.get("type") != "InitializeVariable":
            rep.add("error", "LA-08", where, f"top-level action `{name}` has no runAfter; only InitializeVariable actions may start the workflow")

    # --- SMC variables
    var_names = set()
    for _, name, a in walk(actions):
        if a.get("type") == "InitializeVariable":
            for v in a.get("inputs", {}).get("variables", []):
                var_names.add(v.get("name"))
    for v in SMC_VARS:
        if v not in var_names:
            rep.add("error", "LA-03", where, f"missing workflow variable `{v}` (SMC variable-accumulator pattern)")
    if "SMCMessageHeaders" not in var_names:
        rep.add("warning", "LA-03", where, "no `SMCMessageHeaders` variable (all file/queue workflows in production have it)")

    # --- SMCGuid expression
    for _, name, a in walk(actions):
        if a.get("type") == "InitializeVariable":
            for v in a["inputs"].get("variables", []):
                if v.get("name") == "SMCGuid":
                    val = str(v.get("value", ""))
                    if "guid()" not in val:
                        rep.add("error", "LA-03", where, "`SMCGuid` must fall back to guid()")
                if v.get("name") == "SMCStages":
                    stages = v.get("value") or []
                    ids = [str(s.get("StageID")) for s in stages if isinstance(s, dict)]
                    if not ids or ids[-1] != "100":
                        rep.add("error", "LA-16", where, "`SMCStages` must end with StageID \"100\" (Observation Complete)")
                    for s in stages:
                        if isinstance(s, dict) and not all(k in s for k in ("StageID", "StageName", "Description")):
                            rep.add("error", "LA-16", where, f"SMCStages entry {s.get('StageID')} needs StageID, StageName and Description")

    # --- Try / Catch / Finally
    scopes = {n: a for n, a in top.items() if a.get("type") == "Scope"}
    for n in ("Try", "Catch", "Finally"):
        if n not in scopes:
            rep.add("error", "LA-04", where, f"top-level Scope `{n}` is missing")
    if all(n in scopes for n in ("Try", "Catch", "Finally")):
        ra = scopes["Catch"].get("runAfter", {})
        if "Try" not in ra or not FAIL_STATES <= set(ra["Try"]):
            rep.add("error", "LA-05", where, "`Catch` must run after `Try` on FAILED and TIMEDOUT")
        ra = scopes["Finally"].get("runAfter", {})
        # two shapes are live in production: Finally after Try AND Catch (IBADirects) or chained after Catch (RealTimePricing)
        all_states = FAIL_STATES | {"SUCCEEDED"}
        ok = "Catch" in ra and all_states <= set(ra["Catch"]) and ("Try" in ra or len(ra) == 1)
        if "Try" in ra and not all_states <= set(ra["Try"]):
            ok = False
        if not ok:
            rep.add("error", "LA-05", where, "`Finally` must run after `Catch` (and `Try`) on SUCCEEDED, FAILED, TIMEDOUT and SKIPPED, so it always runs")
        # the first action chain of Try is gated on the variable initialisers
        if not scopes["Try"].get("runAfter"):
            rep.add("error", "LA-05", where, "`Try` must declare runAfter on the variable initialisers")

    # --- start observation (inside Try) and final SMC send (inside Finally)
    start = None
    if "Try" in scopes:
        for _, name, a in walk(scopes["Try"].get("actions", {})):
            if a.get("type") == "ApiManagement":
                inp = a.get("inputs", {})
                if inp.get("apiManagement", {}).get("connection") == "apiManagementOperationSMC" and \
                        "startobservation" in json.dumps(inp).lower():
                    start = a
        if start is None:
            rep.add("error", "LA-06", where, "Try has no StartObservation call through the `apiManagementOperationSMC` connection")
        else:
            body = start["inputs"].get("body", {})
            for k in ("InterfaceID", "Environment", "ObservationID", "ResourceName", "ResourceType"):
                if k not in body:
                    rep.add("error", "LA-06", where, f"StartObservation body is missing `{k}`")
            if "EnableObservation" not in (start["inputs"].get("queries") or {}):
                rep.add("error", "LA-06", where, "StartObservation must pass `EnableObservation` = parameters('paramSMCEnableObservation')")
    if "Finally" in scopes:
        send = None
        for _, name, a in walk(scopes["Finally"].get("actions", {})):
            if a.get("type") == "ServiceProvider":
                cfg = a.get("inputs", {}).get("serviceProviderConfiguration", {})
                if cfg.get("connectionName") == "serviceBusSMC" and cfg.get("operationId") == "sendMessage":
                    send = a
        if send is None:
            rep.add("error", "LA-07", where, "Finally has no sendMessage through the `serviceBusSMC` connection (the SMC end observation)")
        else:
            text = json.dumps(send)
            if "paramSMCQueue" not in text:
                rep.add("error", "LA-07", where, "the SMC message must target `parameters('paramSMCQueue')`")
            for f in SMC_SEND_FIELDS:
                if f not in text:
                    rep.add("error", "LA-07", where, f"the SMC message is missing `{f}`")
        has_terminate = any(a.get("type") == "Terminate" for _, _, a in walk(scopes["Finally"].get("actions", {})))
        is_http = any(t.get("type") == "Request" for t in trig.values())
        has_response = any(a.get("type") == "Response" for _, _, a in walk(actions))
        if is_http and not has_response:
            rep.add("error", "LA-19", where, "HTTP-triggered workflow has no Response action")
        if not is_http and not has_terminate:
            rep.add("warning", "LA-07", where, "Finally has no Terminate action (queue/file workflows in production end with Terminate on error)")

    # --- retryPolicy on built-in connector calls
    for path, name, a in walk(actions):
        if a.get("type") == "ServiceProvider":
            cfg = a.get("inputs", {}).get("serviceProviderConfiguration", {})
            if cfg.get("connectionName") in ("serviceBusSMC",):
                continue
            if "retryPolicy" not in a.get("inputs", {}) and "retryPolicy" not in a:
                rep.add("warning", "LA-09", where, f"ServiceProvider action `{path}{name}` has no retryPolicy")

    # --- constructs production does not use / that race
    for path, name, a in walk(actions):
        if a.get("type") == "JavaScriptCode":
            rep.add("warning", "LA-20", where, f"`{path}{name}` is inline JavaScript; production maps with Compose / Select expressions or an InvokeFunction (.NET) call")
    for path, name, a in walk(actions):
        if a.get("type") == "Foreach":
            conc = (a.get("runtimeConfiguration") or {}).get("concurrency", {}).get("repetitions", 20)
            if conc != 1:
                for p2, n2, a2 in walk(a.get("actions", {})):
                    if a2.get("type") in ("SetVariable", "IncrementVariable"):
                        rep.add("warning", "LA-21", where, f"`{n2}` sets a variable inside parallel Foreach `{name}` (concurrency {conc}); iterations race. Append to an array or use Select, or set concurrency to 1 from an app setting")
                        break

    # --- HTTP flow contract
    if any(t.get("type") == "Request" for t in trig.values()):
        resp = [a for _, _, a in walk(actions) if a.get("type") == "Response"]
        if resp:
            rtxt = json.dumps(resp)
            if "X-Workflow-Executed" not in rtxt:
                rep.add("error", "LA-19", where, "Response must set the header `X-Workflow-Executed: Completed` (APIM's retry policy keys on it)")
            if "StatusCode" not in rtxt:
                rep.add("error", "LA-19", where, "Response statusCode must come from the `StatusCode` variable so Catch and failure branches can return 4xx/5xx")
        if "StatusCode" not in var_names:
            rep.add("error", "LA-19", where, "HTTP workflow needs a `StatusCode` variable")
        if "HasErrors" in var_names:
            rep.add("warning", "LA-19", where, "HTTP workflows in production carry StatusCode / Message / Response instead of HasErrors")

    # --- hard-coded values
    text = used["text"]
    for m in re.finditer(r'"(https?://[^"@]+)"', text):
        u = m.group(1)
        # XML / SOAP namespace identifiers inside payload templates are not endpoints
        if any(h in u for h in ("schema.management", "json-schema", "logic.azure.com", "xmlsoap", "oasis-open", "w3.org", "schemas.", "/schema",
                                "xmlns", "tibco.com", "ibm.com/mdm", "namespaces")) or u.endswith("\\") or re.search(r"/(port|ws)$", u):
            continue
        rep.add("error", "LA-10", where, f"hard-coded URL `{m.group(1)[:80]}`; use appsetting() or a parameter")
    if re.search(r'"(?:password|pwd|client_?secret|sharedaccesskey|accountkey)"\s*:\s*"[^@"][^"]*"', text, re.I):
        rep.add("error", "LA-10", where, "secret-looking literal in workflow.json; use Key Vault via appsetting()")
    for m in re.finditer(r"appsetting\('([^']+)'\)", text):
        used.setdefault("appsettings", set()).add(m.group(1))
    for m in re.finditer(r"parameters\('([^']+)'\)", text):
        used.setdefault("parameters", set()).add(m.group(1))
    for m in re.finditer(r'"connectionName":\s*"([^"]+)"', text):
        used.setdefault("connections", set()).add(m.group(1))
    return used


def check_config(root, used_all, rep):
    for env in ENVS:
        for sub, stem in (("AppSettings", "appsettings"), ("Connections", "connections"), ("Parameters", "parameters")):
            if not (root / sub / f"{stem}.{env}.json").exists():
                rep.add("error", "LA-12", sub, f"missing {sub}/{stem}.{env}.json")
    if not (root / "host.json").exists():
        rep.add("error", "LA-15", "host.json", "missing host.json")
    else:
        h = load(root / "host.json")
        if "Workflows" not in json.dumps(h.get("extensionBundle", {})):
            rep.add("error", "LA-15", "host.json", "extensionBundle must be Microsoft.Azure.Functions.ExtensionBundle.Workflows")

    conns = {}
    cj = root / "connections.json"
    if cj.exists():
        conns = load(cj)
    for env in ENVS:
        p = root / "Connections" / f"connections.{env}.json"
        if p.exists():
            c = load(p)
            for name, v in (c.get("serviceProviderConnections") or {}).items():
                sp = v.get("serviceProvider", {}).get("id", "")
                if sp in ("/serviceProviders/azureBlob", "/serviceProviders/serviceBus", "/serviceProviders/keyVault",
                          "/serviceProviders/AzureBlob") and v.get("parameterSetName") != "ManagedServiceIdentity":
                    rep.add("error", "LA-11", p.name, f"connection `{name}` ({sp}) must use parameterSetName ManagedServiceIdentity")
                elif v.get("parameterSetName") != "ManagedServiceIdentity":
                    # connectors with no managed identity (for example DB2) are allowed only with appsetting() references
                    for pk, pv in (v.get("parameterValues") or {}).items():
                        if isinstance(pv, str) and not pv.startswith("@appsetting("):
                            rep.add("error", "LA-11", p.name, f"connection `{name}`: `{pk}` must be an @appsetting() reference, not a literal")
            if "connectionString" in json.dumps(c) or "managedApiConnections" in c:
                rep.add("error", "LA-11", p.name, "connection strings / managed API connections are not used in production; use serviceProviderConnections with Managed Identity")
            apim = (c.get("apiManagementConnections") or {}).get("apiManagementOperationSMC")
            if not apim:
                rep.add("error", "LA-11", p.name, "missing apiManagementConnections.apiManagementOperationSMC")
            elif "appsetting('SMC_API_Subscription_Key')" not in apim.get("subscriptionKey", ""):
                rep.add("error", "LA-11", p.name, "SMC APIM subscriptionKey must be @appsetting('SMC_API_Subscription_Key')")
            if "serviceBusSMC" not in (c.get("serviceProviderConnections") or {}):
                rep.add("error", "LA-11", p.name, "missing serviceProviderConnections.serviceBusSMC")
    # every @appsetting() used by a connections file must be defined
    app_defined = set()
    for env in ENVS:
        ap = root / "AppSettings" / f"appsettings.{env}.json"
        if ap.exists():
            app_defined |= set(load(ap))
    for env in ENVS:
        cp = root / "Connections" / f"connections.{env}.json"
        if cp.exists():
            for k in sorted(set(re.findall(r"appsetting\('([^']+)'\)", cp.read_text(encoding="utf-8-sig")))):
                if app_defined and k.lower() not in {x.lower() for x in app_defined} and not k.startswith("WEBSITE_"):
                    rep.add("error", "LA-22", cp.name, f"connection uses appsetting `{k}` that no appsettings.<env>.json defines")
    declared = set((conns.get("serviceProviderConnections") or {}).keys())
    for c in used_all.get("connections", set()):
        if declared and c not in declared and c != "apiManagementOperationSMC":
            rep.add("error", "LA-11", "connections.json", f"workflow uses connection `{c}` that connections.json does not declare")

    app_keys = set()
    for env in ENVS:
        p = root / "AppSettings" / f"appsettings.{env}.json"
        if not p.exists():
            continue
        a = load(p)
        app_keys |= set(a)
        for k in SMC_APPSETTINGS:
            if k not in a:
                rep.add("error", "LA-14", p.name, f"missing app setting `{k}`")
        key = str(a.get("SMC_API_Subscription_Key", ""))
        if key and "@Microsoft.KeyVault(" not in key:
            rep.add("error", "LA-14", p.name, "SMC_API_Subscription_Key must be a Key Vault reference")
        for k, v in a.items():
            if re.search(r"(password|secret|accesskey|connectionstring|token)", k, re.I) and "@Microsoft.KeyVault(" not in str(v):
                rep.add("error", "LA-14", p.name, f"`{k}` looks like a secret but is not a Key Vault reference")
        for k, v in a.items():
            if re.search(r"(REPLACE|TBC|TODO|CHANGEME|<[^>]+>)", str(v)):
                rep.add("error" if env == "prd" else "warning", "LA-22", p.name, f"setting `{k}` still holds a placeholder ({str(v)[:50]}); unresolved values must be raised as open items, never shipped")
        if env == "prd":
            for k, v in a.items():
                if re.search(r"(-dv1-|-st1-|-ut1-|\.dev\.|\.dv1\.|\.sit\.|\.uat\.)", str(v)):
                    rep.add("error", "LA-14", p.name, f"prd setting `{k}` points at a non-prod resource: {str(v)[:70]}")
    for k in used_all.get("appsettings", set()):
        if app_keys and k.lower() not in {x.lower() for x in app_keys} and not k.startswith("WEBSITE_") and k != "WORKFLOWS_SUBSCRIPTION_ID":
            rep.add("error", "LA-14", "AppSettings", f"workflow uses appsetting `{k}` that no appsettings.<env>.json defines")

    pkeys = set()
    for env in ENVS:
        p = root / "Parameters" / f"parameters.{env}.json"
        if not p.exists():
            continue
        pr = load(p)
        pkeys |= set(pr)
        for k in pr:
            if not k.startswith("param"):
                rep.add("error", "LA-13", p.name, f"parameter `{k}` must be named param<Name> (camelCase after the prefix)")
        for k in ("paramSMCEnableObservation", "paramSMCQueue"):
            if k not in pr:
                rep.add("error", "LA-13", p.name, f"missing `{k}`")
        if not any(re.fullmatch(r"paramEAII\d+InterfaceId", k) for k in pr):
            rep.add("warning", "LA-13", p.name, "no param<EAIIn>InterfaceId parameter (the StartObservation InterfaceID)")
    for k in used_all.get("parameters", set()):
        if pkeys and k not in pkeys:
            rep.add("error", "LA-13", "Parameters", f"workflow uses parameter `{k}` that no parameters.<env>.json defines")


def check_repo(repo_root, rep):
    pip = list(Path(repo_root).glob("pipelines/gen3*ladep.yml"))
    if not pip:
        rep.add("warning", "LA-18", "pipelines", "no pipelines/gen3<name>ladep.yml (Logic App deployment pipeline)")
    ws = [d.name for d in Path(repo_root).glob("*.Workspace")] + [d.parent.name for d in Path(repo_root).glob("*/*/LogicApp/host.json")]
    for p in pip:
        t = p.read_text(encoding="utf-8", errors="replace")
        m = re.search(r"workspaceFolder:\s*'([^']+)'", t)
        if m and ws and m.group(1) not in ws:
            rep.add("error", "LA-18", p.name, f"workspaceFolder '{m.group(1)}' is not a workspace folder of this repo ({', '.join(ws)})")
        if "Get-ChildItem \"$(workspaceFolder)/Function\"" in t and not any((Path(repo_root) / w / "Function").is_dir() for w in ws):
            rep.add("error", "LA-18", p.name, "pipeline builds a Function/ project but the workspace has none; remove the dotnet build steps when there is no custom code")
        if "refs/heads/main" not in t:
            rep.add("error", "LA-18", p.name, "the PRD stage must be gated on refs/heads/main (production deploys only from main)")
        if "deployPRD" not in t:
            rep.add("warning", "LA-18", p.name, "no deployPRD parameter guarding the PRD stage")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("workspace")
    ap.add_argument("--repo-root")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    root = Path(a.workspace)
    rep = Report()
    wfs = sorted(root.glob("*/workflow.json"))
    if not wfs:
        rep.add("error", "LA-01", str(root), "no <WorkflowName>/workflow.json found")
    used_all = {}
    for w in wfs:
        u = check_workflow(w, rep)
        for k in ("appsettings", "parameters", "connections"):
            used_all.setdefault(k, set()).update(u.get(k, set()))
    check_config(root, used_all, rep)
    if a.repo_root:
        check_repo(a.repo_root, rep)
    errs = [i for i in rep.items if i[0] == "error"]
    warns = [i for i in rep.items if i[0] == "warning"]
    for lvl, rule, where, msg in rep.items:
        print(f"{lvl.upper():7} {rule} [{where}] {msg}")
    print(f"-- {len(wfs)} workflow(s); {len(errs)} error(s), {len(warns)} warning(s)")
    sys.exit(1 if errs or (a.strict and warns) else 0)


if __name__ == "__main__":
    main()
