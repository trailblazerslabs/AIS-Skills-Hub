#!/usr/bin/env python3
"""Compare a generated Logic App workspace with the production workspace of the same interface.

Used to evaluate the codegen skill: generate from the approved TSD without looking at production, then run this to see
what the generated code is missing, what it invented, and where names, parameters, settings and structure differ.

Usage:
    python compare_logicapp.py <generated LogicApp dir> <production LogicApp dir> [--json out.json]

Both folders are the `<Repo>.Workspace/LogicApp` directory. Reports sets (only in production / only in generated) and
ratios; it is a diagnostic, not a gate (use check_logicapp.py as the gate).
"""
import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8-sig"))


def walk(actions, path=""):
    for name, a in (actions or {}).items():
        yield path, name, a
        if "actions" in a:
            yield from walk(a["actions"], f"{path}{name}/")
        if "else" in a:
            yield from walk(a["else"].get("actions", {}), f"{path}{name}/else/")
        for cn, c in (a.get("cases") or {}).items():
            yield from walk(c.get("actions", {}), f"{path}{name}/{cn}/")
        if "default" in a:
            yield from walk(a["default"].get("actions", {}), f"{path}{name}/default/")


def inp(a):
    i = a.get("inputs", {})
    return i if isinstance(i, dict) else {}


def norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def facts(root):
    root = Path(root)
    f = {"workflows": {}, "appsettings": {}, "params": {}, "connections": {}}
    for w in sorted(root.glob("*/workflow.json")):
        d = load(w)
        dfn = d["definition"]
        acts = list(walk(dfn.get("actions")))
        types = Counter(a.get("type") for _, _, a in acts)
        names = [n for _, n, _ in acts]
        vars_ = set()
        stages = []
        ops = set()
        for _, n, a in acts:
            if a.get("type") == "InitializeVariable":
                for v in inp(a).get("variables", []):
                    vars_.add(v["name"])
                    if v["name"] == "SMCStages":
                        stages = [(s.get("StageID"), s.get("StageName")) for s in v.get("value", []) if isinstance(s, dict)]
            cfg = inp(a).get("serviceProviderConfiguration", {})
            if cfg:
                ops.add(f"{cfg.get('connectionName')}:{cfg.get('operationId')}")
            if a.get("type") in ("Http", "ApiManagement", "InvokeFunction", "Function", "Response", "JavaScriptCode", "Terminate", "Workflow"):
                ops.add(a["type"])
        for k, t in (dfn.get("triggers") or {}).items():
            cfg = inp(t).get("serviceProviderConfiguration", {})
            ops.add("trigger:" + (f"{cfg.get('connectionName')}:{cfg.get('operationId')}" if cfg else f"{t.get('type')}/{t.get('kind')}"))
        retry = sum(1 for _, _, a in acts if "retryPolicy" in json.dumps(inp(a)))
        sp = sum(1 for _, _, a in acts if a.get("type") == "ServiceProvider")
        fail_branches = sum(1 for _, n, a in acts if re.search(r"Append_to_SMCErrors", n))
        f["workflows"][w.parent.name] = {"kind": d.get("kind"), "actions": len(acts), "types": dict(types), "names": names,
                                         "vars": sorted(vars_), "stages": stages, "ops": sorted(ops),
                                         "retry": retry, "serviceprovider_actions": sp, "failure_branches": fail_branches,
                                         "scopes": [n for n, a in (dfn.get("actions") or {}).items() if a.get("type") == "Scope"]}
    for env in ("dev", "sit", "uat", "prd"):
        for sub, key, stem in (("AppSettings", "appsettings", "appsettings"), ("Parameters", "params", "parameters")):
            p = root / sub / f"{stem}.{env}.json"
            if p.exists():
                f[key][env] = load(p)
        p = root / "Connections" / f"connections.{env}.json"
        if p.exists():
            c = load(p)
            f["connections"][env] = sorted(list((c.get("serviceProviderConnections") or {}).keys()) + list((c.get("apiManagementConnections") or {}).keys()))
    return f


def setdiff(label, prod, gen, out):
    prod, gen = set(prod), set(gen)
    only_p, only_g, both = sorted(prod - gen), sorted(gen - prod), sorted(prod & gen)
    ratio = len(both) / len(prod) if prod else 1.0
    out.append((label, len(prod), len(gen), len(both), ratio, only_p, only_g))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("generated")
    ap.add_argument("production")
    ap.add_argument("--json")
    a = ap.parse_args()
    g, p = facts(a.generated), facts(a.production)
    rows = []
    gw, pw = g["workflows"], p["workflows"]
    setdiff("workflow folders", pw, gw, rows)
    # pair workflows by name similarity (or the only one)
    pairs = []
    for pn in pw:
        gn = next((x for x in gw if norm(x) == norm(pn)), None) or (list(gw)[0] if len(gw) == 1 and len(pw) == 1 else None)
        if gn:
            pairs.append((pn, gn))
    for pn, gn in pairs:
        P, G = pw[pn], gw[gn]
        setdiff(f"[{pn}] SMC variables", P["vars"], G["vars"], rows)
        setdiff(f"[{pn}] SMC stage names", [norm(n) for _, n in P["stages"]], [norm(n) for _, n in G["stages"]], rows)
        setdiff(f"[{pn}] connector operations", P["ops"], G["ops"], rows)
        setdiff(f"[{pn}] action names", [norm(n) for n in P["names"]], [norm(n) for n in G["names"]], rows)
    for env in ("prd",):
        setdiff(f"app settings ({env}) keys", p["appsettings"].get(env, {}), g["appsettings"].get(env, {}), rows)
        setdiff(f"parameters ({env}) names", p["params"].get(env, {}), g["params"].get(env, {}), rows)
        setdiff(f"connections ({env})", p["connections"].get(env, []), g["connections"].get(env, []), rows)
    # parameter VALUES that differ on shared keys
    diffs = []
    for env in ("prd",):
        for k, v in p["params"].get(env, {}).items():
            gv = g["params"].get(env, {}).get(k)
            if gv is not None and gv.get("value") != v.get("value"):
                diffs.append((env, k, v.get("value"), gv.get("value")))
        for k, v in p["appsettings"].get(env, {}).items():
            gv = g["appsettings"].get(env, {}).get(k)
            if gv is not None and gv != v:
                diffs.append((env, k, v, gv))

    print("== STRUCTURE")
    for pn, gn in pairs:
        P, G = pw[pn], gw[gn]
        print(f"workflow {pn} <-> {gn}: kind {P['kind']}/{G['kind']}; actions prod {P['actions']} / generated {G['actions']}; scopes {P['scopes']} / {G['scopes']}")
        print(f"   retryPolicy on {P['retry']}/{P['serviceprovider_actions']} prod service-provider actions, generated {G['retry']}/{G['serviceprovider_actions']}; "
              f"failure branches prod {P['failure_branches']} generated {G['failure_branches']}")
        print(f"   action types prod {P['types']}")
        print(f"   action types gen  {G['types']}")
    print("\n== OVERLAP (share of PRODUCTION items the generated code also has)")
    for label, np_, ng, nb, ratio, only_p, only_g in rows:
        print(f"{label}: prod {np_}, generated {ng}, shared {nb}  ({ratio:.0%})")
    print("\n== MISSING IN GENERATED (in production only)")
    for label, np_, ng, nb, ratio, only_p, only_g in rows:
        if only_p and "action names" not in label:
            print(f"- {label}: {', '.join(only_p)[:600]}")
    print("\n== EXTRA IN GENERATED (not in production)")
    for label, np_, ng, nb, ratio, only_p, only_g in rows:
        if only_g and "action names" not in label:
            print(f"- {label}: {', '.join(only_g)[:600]}")
    print("\n== SAME KEY, DIFFERENT VALUE (prd)")
    for env, k, pv, gv in diffs:
        print(f"- {k}: prod {str(pv)[:90]!r} | generated {str(gv)[:90]!r}")
    if a.json:
        Path(a.json).write_text(json.dumps({"rows": [r[:5] for r in rows], "diffs": diffs}, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
