---
name: ais-logicapp-codegen
description: |
  Metcash AIS Logic App Standard workflow code generator. USE FOR: generating Logic App Standard
  workflow JSON files (workflow.json), connection references (connections.json), parameters
  (parameters.json), and environment app settings for AIS integration interfaces. Requires an
  approved codegen-readiness questionnaire. Derives patterns from production `main`, then on
  every generation runs the production-calibrated checker and compares generated code with the
  closest production Logic App; records and fixes real differences before handoff. DO NOT USE
  FOR: architecture
  recommendation (use solution-architect or tibco-azure-nfr-recommendation first), Function App
  transformation code (use ais-functionapp-codegen), or ADF pipelines (use ais-datafactory-codegen).
  Triggers: "generate logic app", "create workflow", "logic app code", "workflow json",
  "create logic app workflow", "generate workflow", "HTTP trigger workflow", "Service Bus workflow",
  "compare generated Logic App with production", "Logic App code quality evaluation".
---

# AIS Logic App Workflow Code Generator

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — check which workflows are already generated before starting (don't
> regenerate what's done), and update Phase 3's row with what's generated vs still outstanding.

Generate Logic App Standard workspace assets as an **additive overlay** on the reference workspace.
Never modify existing files — only add new ones or append new keys to shared config files.

---

## ⛔ Mandatory Pre-condition — Codegen Readiness

**Do not generate any code until the relevant pre-condition below is met** — which one depends
on whether this interface has a TSD:

| Interface has... | Required artifact | Check | Action if missing |
|---|---|---|---|
| A TSD (`tsd/<InterfaceID>/*.md`; approved corpus TSDs are at `reference-corpus/converted/tsd/TSD-<InterfaceID>/TSD-<InterfaceID>.md`) | **Approved** `outputs/<InterfaceID>/codegen-readiness-questionnaire.md` | Found and marked approved | **Stop.** Ask the user to run `ais-codegen-readiness` and approve it first — repo and resource name must be resolved before any code is written, never guessed. |
| No TSD | **Approved** `outputs/<InterfaceID>/design-intake-questionnaire.md` | Found and marked approved | **Stop.** Ask the user to run `ais-design-intake` and approve it first — never proceed on an unapproved questionnaire. |

> Whichever artifact applies replaces the "Required Inputs" questions below — do not re-ask for
> information already captured in it. In particular, the target repo and workflow name are
> **mandatory** and must come from the approved questionnaire/summary, never invented.

### Inline Gap Resolution Before Generation

Review the approved questionnaire, TSD/design evidence, target repo and production reference
before asking anything. For each codegen-critical fact still missing, ambiguous or conflicting,
use `vscode_askQuestions` inline with a proposed answer, evidence/source and impact; allow confirm,
correct, or unknown/keep blocked. Do not ask again for established facts. Record answers and
provenance in the existing readiness/design-intake questionnaire and `assumptions.md`. If an
answer materially changes an approved questionnaire, stop and obtain explicit approval of the
revised questionnaire before writing code. If a critical answer remains unknown, stop generation.

---

## Required Inputs

> Sourced from the Design Intake Questionnaire. If any item is missing from the summary, ask only for that specific gap.

- Interface ID matching `EAII-{number}`
- Architecture recommendation (approved pattern)
- Reference workspace: the production `main` repo chosen in Step 1 (IBADirects for queue/file flows, RealTimePricing for synchronous HTTP)
- Trigger type: HTTP / Service Bus / Timer / Blob
- Source and target systems

Resolve any missing input using the inline gap process above; do not fill it by inference without
the user's confirmation.

## Workflow

### Step 1 — Read the production reference (not a template)

The reference is **code that is live in production** — the `main` branch of the Squad 20 repos (the PRD stage of every
pipeline runs only from `refs/heads/main`; `release/*` and `feature/*` deploy to non-prod). Production inventory, SHAs and the
list of branches that are *not* yet live: [`code-corpus/production-snapshot.md`](../../../code-corpus/production-snapshot.md).
Re-check it before generating (`git -C <clone> fetch` then `git log origin/main -5`); if `main` moved, read the new commits.

| Archetype | Read this production workspace (`origin/main`) |
|---|---|
| Queue / blob / file batch (B, D) | `Metcah.AIS.B2B.IBADirects` → `Metcash.AIS.B2B.IBADirects.Workspace/LogicApp/LiquorSuppliersToEIM/workflow.json` (EAII-304, 23 Sep 2026, CHG0065195) |
| Synchronous HTTP API, SOAP / REST backend (A/B) | `Metcash.AIS.DATA.MetconnectSuppOnboarding` → `Metcash.AIS.DATA.MetconnectSuppOnboarding.Workspace/LogicApp/GetNewSupplierNumber/workflow.json` (EAII-297, 23 Sep 2026, CHG0065195) |
| Synchronous HTTP API (A/B) | `Metcash.AIS.B2B.RealTimePricing` → `Metcash.AIS.B2B.RealTimePricing.Workspace/LogicApp/GetPricingData/workflow.json` (EAII-514, 11 Sep 2026, CHG0064987) |

Read the whole `LogicApp/` folder of the closest one: `AppSettings/`, `Connections/`, `Parameters/`, `connections.json`, `host.json`, the
`pipelines/gen3<name>ladep.yml`. Derive names, shapes and the SMC wiring from it. `reference-templates/logic-apps/workflow.template.json`
is a skeleton only and is **older than production**: do not copy it.

### Precedence when the TSD, this skill and production disagree

Found by generating EAII-514 and EAII-304 from their TSDs with the production code held out: the TSD and production differ in small, repeatable ways.

| Question | Rule |
|---|---|
| Business behaviour, field mappings, resource names, queue and container names, exception codes | **The approved TSD wins.** |
| SMC wiring, scopes, connection types, file layout, naming of `param*` / settings | **This skill (the production standard) wins**, even if the TSD says otherwise. |
| `Stateful` vs `Stateless` | Generate **Stateful** (every production workflow is Stateful: run history is what support uses next to SMC). If the TSD says Stateless, keep Stateful and record it as an assumption for the architect to confirm. |
| The TSD names two workflows (for example one in the component list and another in the APIM backend) | The name in the **APIM backend / SAS named value** wins: the signature is bound to the workflow name. |
| Service Bus namespace | Hub input: `t1-met-{npr\|prd}-ae-sb-001`. SMC: `t2-met-{npr\|prd}-ae-sb-001`. Use `npr` for dev, sit and uat. If the TSD gives the other prefix for the input queue, follow the TSD and log the conflict (production IBADirects reads its input from `t1`). |
| SMC queue per environment | `smc.endobservation.{dev\|uat\|uat\|prd}.sbq` for dev, sit, uat, prd (sit and uat share `uat`). |
| A value the TSD does not give (hosts, database names, SAS signatures) | Never invent it and never leave `REPLACE-...` in a file you ship. Put it in `assumptions.md` as an open item with the owner; the checker flags placeholders (error in `prd`). |

Record every divergence from the TSD in `outputs/<InterfaceID>/assumptions.md`.

### Step 2 — Generate the workspace (the real production shape)

**Write into the real repo clone resolved by `ais-codegen-readiness`** (never into `outputs/<InterfaceID>/`). Leave local,
uncommitted edits on the feature branch; committing and pushing is a separate step.

```
<Repo>.Workspace/LogicApp/
├── <WorkflowName>/workflow.json        ← folder name = workflow name (PascalCase, e.g. LiquorSuppliersToEIM)
├── AppSettings/appsettings.{dev,sit,uat,prd}.json      ← every environment value (ppd only if the repo already has it)
├── Connections/connections.{dev,sit,uat,prd}.json      ← same connections, per environment
├── Parameters/parameters.{dev,sit,uat,prd}.json        ← workflow parameters (param*), per environment
├── connections.json  parameters.json  host.json        ← base files (copy host.json from production unchanged)
├── lib/custom/<FunctionName>/   and   ../Function/     ← only when the workflow calls InvokeFunction (custom .NET code)
└── workflow-designtime/host.json  .funcignore  .gitignore
pipelines/gen3<name>ladep.yml + pipelines/templates/{logicapp-prepare-package,update-app-settings}.yml   ← copy the production ones
```

**workflow.json — what every production workflow has** (`tools/check_logicapp.py` enforces it; the production repos pass with 0 errors):

1. `"kind": "Stateful"` (production also writes it lower case), exactly one trigger, then **variable initialisers as the only top-level actions without `runAfter`**:
   the SMC set `SMCGuid`, `SMCErrors`, `SMCStagesStatus`, `SMCStages`, `SMCCorrelationProperties`, `SMCMessageHeaders`, plus the flow-specific set:
   * **queue / file flows:** `triggerBody` (the trigger body as a string), `TransactionId`, the business keys, `HasErrors` (bool), `ErrorMessage`, `FileMovedToError`;
   * **HTTP flows:** `TransactionID` (`@{if(equals(triggerBody()?['TransactionID'], null), guid(), triggerBody()?['TransactionID'])}`), `StatusCode` (string), `Message` (string),
     `Response` (object), the business inputs. **No `HasErrors`.**
   `SMCGuid` is the observation id (`@{guid()}`, or `coalesce(triggerOutputs()?['headers']?['ParentObservationID'], guid())` when a caller passes one);
   `TransactionId` is the business correlation id sent as `ParentObservationID` to SMC. They are different values.
   `SMCStages` is the declared table of stages (`StageID`, `StageName`, `Description`) and **ends with `"100"` / "Observation Complete"**.
2. Three top-level scopes: **`Try`** (runAfter = all initialisers, `SUCCEEDED`), **`Catch`** (runAfter `Try` on `FAILED` and `TIMEDOUT`),
   **`Finally`** (runAfter `Catch`, plus `Try` for queue/file flows, on all four states so it always runs).
3. **Inside `Try`, first:** `Append_SMC_Stage_Status_1.0_Start`, then the SMC start call through the APIM connection:
   ```json
   "type": "ApiManagement",
   "inputs": { "apiManagement": { "operationId": "post-startobservation", "connection": "apiManagementOperationSMC" },
     "method": "post", "pathTemplate": { "template": "/startObservation" },
     "body": { "InterfaceID": "@parameters('paramEAII<n>InterfaceId')", "Environment": "@appsetting('WORKFLOWS_ENVIRONMENT')",
       "StageName": "Start Observation", "StageStatus": "Success", "MessageBody": "@string(coalesce(triggerBody(), ''))",
       "ParentObservationID": "@variables('TransactionId')", "ObservationID": "@variables('SMCGuid')",
       "ResourceName": "@{appsetting('WEBSITE_SITE_NAME')}.@{workflow()['name']}", "ResourceTriggerName": "@{trigger()['Name']}",
       "ResourceType": "StandardLogicApp", "ResourceRunID": "@{workflow()['run']['name']}", "IsObservationComplete": "False" },
     "queries": { "EnableObservation": "@parameters('paramSMCEnableObservation')" } }
   ```
4. **Queue / file flows: every business action that can fail has its own failure branch** (this is the production signature of IBADirects): the action, then on `FAILED`
   `Set_HasErrors_true_on_<Action>_failure` → `Set_ErrorMessage_from_<Action>_failure` → `Append_to_SMCErrors_<Action>_failure` →
   `Append_SMC_Stage_Status_<Stage>_Failed`; success appends `Append_SMC_Stage_Status_<Stage>_Completed`. Stage names match `SMCStages`.
   File flows also copy the source blob to the error folder and delete it on failure; on success copy to archive, then delete the source.
   **HTTP flows do not use this** (see "Synchronous HTTP flows" below): a failing call propagates to `Catch`, and a business failure is handled in an `If` on the response.
5. **Retry on every built-in connector call**: `"retryPolicy": { "type": "fixed", "count": 3, "interval": "PT5S" }` inside `inputs`.
6. **`Catch`:** `Set_HasErrors_true_on_unhandled_error` (`HasErrors` = true) → `Fetch_Uncaught_Error` (`Query`, `from: @result('Try')`,
   `where: @equals(item()['status'],'Failed')`) → `Select_Errors` → `Append_to_SMCErrors` → `Append_SMC_Stage_Status_1.0_Failed`.
7. **`Finally`:** `Append_SMC_Stage_Status_100_Complete`, then the correlation property (`{ "CorrelationId": "@variables('TransactionId')" }`) and one
   message header per key as `{ "PropertyName": "TransactionId", "PropertyValue": "@variables('TransactionId')" }` (business keys, file name, workflow run id), then the SMC end observation:
   ```json
   "type": "ServiceProvider",
   "inputs": { "parameters": { "entityName": "@parameters('paramSMCQueue')", "message": { "contentType": "application/json", "contentData": {
       "MessageBody": "@string(coalesce(triggerBody(), ''))", "SMCCorrelationProperties": "@variables('SMCCorrelationProperties')",
       "SMCEnableObservation": "@parameters('paramSMCEnableObservation')", "SMCError": "@array(variables('SMCErrors'))",
       "SMCGuid": "@variables('SMCGuid')", "SMCMessageHeaders": "@variables('SMCMessageHeaders')", "SMCStages": "@variables('SMCStages')",
       "SMCStagesStatus": "@variables('SMCStagesStatus')", "StageName": "@{workflow()['name']} Observation Complete" } } },
     "serviceProviderConfiguration": { "connectionName": "serviceBusSMC", "operationId": "sendMessage", "serviceProviderId": "/serviceProviders/serviceBus" } }
   ```
   then queue/file workflows end with `Terminate` (`runStatus` Failed, `runError` code 500 "Processing failed. Error details were sent to SMC.") when `HasErrors` is true **and the source file was not already moved to the error folder** (`FileMovedToError` = false), so the run shows as Failed in run history and alerts without a second failure signal for a file that was already routed to error; **HTTP workflows end with `Response`** and add the header
   `X-Workflow-Executed: Completed` (APIM's retry policy keys on it, see `code-corpus/patterns/03-apim-apiops-pattern.md`).
8. **No literals**: hosts, queue names, container names and folders come from `appsetting()` / `parameters()`; secrets are Key Vault references.

#### Synchronous HTTP flows (behind APIM): the production skeleton

Two live examples agree: `RealTimePricing/GetPricingData` (EAII-514) and `Metcash.AIS.DATA.MetconnectSuppOnboarding` `GetNewSupplierNumber` / `ReleaseReservedSupplierNumber` (EAII-297, 23 Sep).

* **Trigger:** `When_a_HTTP_request_is_received`, `Request` / `Http`, `inputs.method: POST`.
* **Variables:** the SMC set, `TransactionID`, `StatusCode`, `Message`, `Response` (object). Secrets needed at runtime (for example a basic-auth password) are read in `Try` with a
  `keyVault` `getSecret` ServiceProvider action (`paramMDMSecretName`-style parameter), never from a literal.
* **`Try`:** StartObservation (the action after it runs on all four states of it, so an SMC outage never blocks the API) → call the backend (`Http` action or `ServiceProvider`) →
  **`If` on the backend result**: success branch maps the answer, sets `Response` and stage `Complete`; failure branch appends the SMC error, sets `StatusCode` from the backend
  (and the real code into `ActualStatusCode`), sets `Message` and `Response` to the fault body. No per-action `HasErrors` chain.
* **`Catch`** (after `Try` on FAILED, TIMEDOUT): `Fetch_Uncaught_Error` → `Select_Errors`; `Set_StatusCode` = `500`; `Set_Error_Message`; `Set_Catch_Response`; append to `SMCErrors`; append the stage failed.
* **`Finally`** (after `Catch` on all four states): correlation + header appends → `Log_Process_Complete` (stage `100`) → `Send_SMC_Message` (the `serviceBusSMC` send, only when
  observation is enabled) → **`Return_API_Response`** with `runAfter` on all four states of the send, so a failing SMC send can never swallow the reply.
* **`Response`:** `statusCode` = `@coalesce(if(empty(variables('StatusCode')), null, int(variables('StatusCode'))), 200)`, header `X-Workflow-Executed: Completed`, body `@variables('Response')`.
  APIM retries once when that header is missing, so it must be set on every path.
* **Fault body:** the structure the TSD defines for errors (exception code, message, `TransactionID`); put the interface exception codes (`EAII<n>-001`...) in the response `Message` and in `SMCErrors`.
* App settings and connections: **only what the flow uses** (no input queue, no blob endpoint for a pure API-to-database flow).

#### Loops (`Foreach`)

* Set the concurrency the TSD asks for under `runtimeConfiguration.concurrency.repetitions` (a static number; production RealTimePricing runs its loop sequentially, with `RealTimePricing_ForeachConcurrency` = 1 as the documented setting). Do not invent a default of 10 or 20.
* **Never `SetVariable` / `IncrementVariable` inside a `Foreach` whose concurrency is above 1** (iterations race). Collect with `Select`, or `AppendToArrayVariable` and promote the array after the loop; keep order by index.
* A "first call sequential, the rest in parallel" rule from the TSD is a call before the loop, then the loop over the remaining items.

#### Transformations

Use Workflow Definition Language expressions (`Compose`, `Select`, `Query`, `if`, `coalesce`, `formatDateTime`, `substring`) for field mapping, padding and trimming (`tib:pad-front` is
`concat(repeat(' ', n), x)` then `substring`). Use an `InvokeFunction` call to the .NET project for transformations that are large or need real code. **Do not use inline `JavaScriptCode`**: no production
workflow does, and the checker warns (`LA-20`).

#### Database and other connectors without Managed Identity (DB2 / AS400, from RealTimePricing)

```json
"DB2": { "displayName": "la_to_db2_connection",
  "parameterValues": { "serverName": "@appsetting('DB2_serverName')", "portNumber": "@appsetting('DB2_portNumber')", "database": "@appsetting('DB2_database')",
    "defaultSchema": "@appsetting('DB2_defaultSchema')", "packageCollection": "@appsetting('DB2_packageCollection')",
    "userName": "@appsetting('DB2_userName')", "password": "@appsetting('DB2_<user>_password')" },
  "serviceProvider": { "id": "/serviceProviders/DB2" } }
```
The password setting is `@Microsoft.KeyVault(SecretUri=https://t3b2b<env>ae1kv01.vault.azure.net/secrets/DB2Password)`; `keyVault_VaultUri` is still set. The stored procedure call:
```json
"type": "ServiceProvider", "inputs": { "parameters": { "procedureName": "@parameters('paramDB2StoredProcedure')", "procedureParameters": { "...": "@outputs('Compose_...')" } },
  "serviceProviderConfiguration": { "connectionName": "DB2", "operationId": "storedProcedure", "serviceProviderId": "/serviceProviders/DB2" },
  "retryPolicy": { "type": "fixed", "count": 3, "interval": "PT5S" } }
```
The procedure name is a parameter per environment (`IDSLIBPRD.<proc>` in prd). Query timeout and pool size are database settings, not workflow JSON: record them in `assumptions.md`.

#### Custom .NET code called from the workflow (IBADirects `TransformToPSV`)

* Source in `<Repo>.Workspace/Function/` (csproj + classes); the workflow calls it with an `InvokeFunction` action (`functionName`, `parameters`).
* The pipeline builds and publishes it (`dotnet build` / `dotnet publish -o <Workspace>/bin`) before zipping; `lib/custom/<FunctionName>/` is generated by the build and is git-ignored.
* **No custom code: remove the dotnet steps from the pipeline** (the checker fails a pipeline that builds a missing `Function/`).
* Pipeline edits for a new interface: `workspaceFolder`, the variable groups (`t3-ais_<domain>_<name>_{dv1|st1|ut1|prd}`), `logicAppName` per environment, the settings file path.

#### What goes to SMC

`MessageBody` is `string(coalesce(triggerBody(), ''))` by default. When the TSD restricts payload logging (for example "do not log full pricing payloads in production"), gate it with a variable
(RealTimePricing uses `IsSMCLoggingRequired` and `IsResponseBodyRequiredInSMC`) and send an empty or summarised body; never log secrets or full personal data.


### Step 3 — connections (per environment, built-in connectors, Managed Identity)

Declare **only the connections the workflow uses**; the SMC pair (`apiManagementOperationSMC`, `serviceBusSMC`) is always present. `serviceBus`, `azureBlob`, `keyVault` are added when used.

Production uses **built-in service-provider connections** with Managed Identity, defined per environment in `Connections/connections.<env>.json`
(and the base `connections.json`). The old `managedApis` / `connectionId` shape is **not** used.

```json
{ "apiManagementConnections": { "apiManagementOperationSMC": {
      "apiId": "/subscriptions/@{appsetting('WORKFLOWS_SUBSCRIPTION_ID_SMC')}/resourceGroups/@{appsetting('APIM_ResourceGroup_SMC')}/providers/Microsoft.ApiManagement/service/@{appsetting('APIM_ServiceName_SMC')}/apis/smc-v1",
      "baseUrl": "@{appsetting('APIM_BaseUrl_SMC')}monitoring/smc/v1", "displayName": "smc-api-connection",
      "subscriptionKey": "@appsetting('SMC_API_Subscription_Key')" } },
  "serviceProviderConnections": {
    "serviceBus":    { "displayName": "servicebus-mi-<name>-conn", "parameterSetName": "ManagedServiceIdentity",
                       "parameterValues": { "authProvider": { "Type": "ManagedServiceIdentity" }, "fullyQualifiedNamespace": "@appsetting('ServiceBus_FullyQualifiedNamespace')" },
                       "serviceProvider": { "id": "/serviceProviders/serviceBus" } },
    "serviceBusSMC": { "...": "same, fullyQualifiedNamespace = @appsetting('ServiceBus_FullyQualifiedNamespace_SMC')" },
    "azureBlob":     { "...": "ManagedServiceIdentity, blobStorageEndpoint = @appsetting('AzureBlob_Endpoint'), serviceProvider id /serviceProviders/azureBlob" },
    "keyVault":      { "...": "ManagedServiceIdentity, VaultUri = @appsetting('keyVault_VaultUri')" } } }
```

Connectors with no managed identity (DB2 in RealTimePricing) still take **every** value from `@appsetting()`, with the password a Key Vault reference.
Never put a connection string or key in a connections file.

### Step 4 — parameters and app settings (per environment)

* `Parameters/parameters.<env>.json` — names are `param<Name>` (camelCase after `param`), each `{ "type": "String", "value": ... }`. **Always:**
  `paramSMCEnableObservation` ("Yes"), `paramSMCQueue` (`@appsetting('SMC_QueueName')`), `paramEAII<n>InterfaceId` ("EAII-<n>"). **When used:** folder parameters
  (`paramExtractFolderPath`, `paramOutputFolderPath`, `paramArchiveFolderPath`, `paramErrorFolderPath`) as `<Interface>/<stage>`, `paramDB2StoredProcedure`, secret names, business constants.
* `AppSettings/appsettings.<env>.json` — **always (SMC):** `APIM_BaseUrl_SMC`, `APIM_ResourceGroup_SMC`, `APIM_ServiceName_SMC`,
  `ServiceBus_FullyQualifiedNamespace_SMC` (`t2-met-{npr|prd}-ae-sb-001.servicebus.windows.net`), `SMC_QueueName` (`smc.endobservation.{dev|uat|uat|prd}.sbq`),
  `SMC_API_Subscription_Key` as `@Microsoft.KeyVault(SecretUri=https://t3enabling<env>ae1kv01.vault.azure.net/secrets/SMC-API-Subscription-Key)`,
  `WORKFLOWS_SUBSCRIPTION_ID_SMC`, `WORKFLOWS_ENVIRONMENT`. **Only when the workflow uses it:** `ServiceBus_FullyQualifiedNamespace` (`t1-met-{npr|prd}-ae-sb-001...`) and
  `ServiceBus_InputQueue` for a queue trigger; `AzureBlob_Endpoint` and `BlobStorage_Container` for blob steps; `keyVault_VaultUri` for a `keyVault` connection;
  `DB2_*` for DB2; a `<Interface>_ForeachConcurrency` setting only if you document it for operations. The `prd` file must never point at a `dv1`/`st1`/`ut1` resource and must never hold a placeholder; every
  `@appsetting()` used in a workflow or a connections file must be defined (names are case-insensitive).

### Step 4b — run the production-calibrated check (mandatory on every generation)

```powershell
python .github\skills\ais-logicapp-codegen\tools\check_logicapp.py <clone>\<Repo>.Workspace\LogicApp --repo-root <clone>
```
Require **0 errors** before handoff. Fix warnings or justify them in `assumptions.md`. The same command on `origin/main` of IBADirects, RealTimePricing and MetconnectSuppOnboarding (EAII-297) prints 0 errors (that is how the rules were calibrated).

### Step 4c — production quality comparison (mandatory after every generation)

Every code-generation run must compare the generated Logic App against the closest available
production Logic App on `origin/main`; this is not an optional evaluation-only step.

1. Record the production repository, `origin/main` commit SHA and latest production change
  reference from `code-corpus/production-snapshot.md`. Compare against `origin/main`, never a
  feature/release branch or a stale working tree.
2. Use the closest matching archetype from Step 1. For multiple generated workflows, make a
  temporary one-workflow view for each workflow so `compare_logicapp.py` pairs it with exactly
  one production workflow. Do not change the generated target repo or production clone to create
  those views.
3. Run:

  ```powershell
  python .github\skills\ais-logicapp-codegen\tools\compare_logicapp.py `
     <one-workflow generated LogicApp view> <production origin/main LogicApp view> `
     --json outputs\<InterfaceID>\code-quality-comparison.json
  ```

4. Write `outputs/<InterfaceID>/code-quality-comparison.md` with the baseline repo/SHA,
  checker results, structure/action/connector/parameter/setting comparisons, and each finding
  classified as (a) required production convention, (b) intentional TSD/business difference,
  (c) unrelated production-specific behavior, or (d) generated defect. Raw name overlap is a
  diagnostic, **not** a quality score; never copy production business behavior over the approved
  TSD merely to increase similarity.
5. Fix every generated defect in the target feature branch. After each fix, rerun both
  `check_logicapp.py` and `compare_logicapp.py`, refresh the report, and stop only when the
  checker has 0 errors and every remaining comparison difference is explicitly explained.

This gate is local source-quality verification only. It does not authorize or imply deployment,
runtime tests, ADO writes, commit, or push. Those require their own explicit authorization and
the relevant SDLC gates; no code-quality comparison can substitute for them.

### Step 5 — Log Assumptions

Write `outputs/<InterfaceID>/assumptions.md` with every assumption made.

## Trigger Patterns (as they are in production)

### Service Bus queue trigger (blob-event or pointer messages) — IBADirects
```json
"triggers": { "When_a_message_is_received_in_a_queue": {
  "type": "ServiceProvider",
  "inputs": { "parameters": { "queueName": "@appsetting('ServiceBus_InputQueue')", "isSessionsEnabled": false },
    "serviceProviderConfiguration": { "connectionName": "serviceBus", "operationId": "receiveQueueMessages",
      "serviceProviderId": "/serviceProviders/serviceBus" } },
  "splitOn": "@triggerOutputs()?['body']" } }
```
(not `"type": "ServiceBusTrigger"`: production uses the built-in service-provider trigger.)

### HTTP trigger (synchronous API behind APIM) — RealTimePricing
```json
"triggers": { "When_a_HTTP_request_is_received": { "type": "Request", "kind": "Http", "inputs": { "method": "POST" } } }
```
Return a `Response` on success and failure with the header `X-Workflow-Executed: Completed`.

### Timer / Recurrence
Use only when the FSD says scheduled; keep the same Try / Catch / Finally and SMC wiring.

## Error handling rules (production)

- Top-level `Try` / `Catch` / `Finally` scopes exactly as in Step 2; `Finally` always sends the SMC end observation.
- Per-action failure branches (set error, append to `SMCErrors`, append the stage as failed); built-in connector actions carry `retryPolicy`.
- File flows: failed source blob goes to the error folder, then is deleted; successful source blob goes to archive, then is deleted.
- HTTP flows return the real status code from a `StatusCode` variable and always set `X-Workflow-Executed`.

## References

- [`code-corpus/production-snapshot.md`](../../../code-corpus/production-snapshot.md) — what is live in production, which repo to read, SHAs, CHG numbers
- [`code-corpus/patterns/02-logic-app-pattern.md`](../../../code-corpus/patterns/02-logic-app-pattern.md) — the full pattern with evidence
- `tools/check_logicapp.py` — production-calibrated lint for a generated workspace
