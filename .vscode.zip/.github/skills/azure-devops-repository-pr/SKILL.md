---
name: azure-devops-repository-pr
description: |
  Squad 20 Azure DevOps repository and pull request conventions. USE FOR: repository naming,
  branch naming (main, release, feature/EAII-ID), PR title format (EAII-{number}: description),
  the PR description checklist, creating branches via ADO MCP, creating pull requests via ADO
  MCP, and the expected file changes per PR type (Logic App + Function, APIOps). This is a
  "way of working" skill — day-to-day source-control operations, not code generation.
  DO NOT USE FOR: generating Logic App, Function App, or ADF code (use the ais-*-codegen
  skills), work item / board conventions (use azure-devops-work-items).
  Triggers: "pull request", "create PR", "create a PR", "branch naming", "create branch",
  "repository convention", "merge to main", "PR title", "PR checklist", "raise a PR".
---

# Azure DevOps Repository and Pull Request Skill — Squad 20

> Status: Observed — derived from repository naming, branch patterns, and pipeline conventions across Squad 20 repositories.

---

## Repository Overview

**Organisation:** `METCASHDevOps` | **Project:** `Squad 20`
**Total repos:** ~48 (as of scan date)

### Repository Categories

| Category | Repos | Description |
|---|---|---|
| Logic App + Function App | `Metcash.AIS.RMN`, `Metcash.AIS.Data.Metproducts`, `Metcash.AIS.B2C.Wynshop` | Workflow + transformation code |
| Standalone Function App | `Metcash.AIS.B2B.Cloudinary`, `Metcash.AIS.Enabling.AzureBlobManagement`, `Metcash.AIS.Enabling.Notifications` | Dedicated function services |
| Azure Data Factory | `Metcash.AIS.B2B.Datafactory`, `Metcash.AIS.B2C.Datafactory`, `Metcash.AIS.RMN.01.Datafactory` | ADF JSON artifacts |
| APIOps | `Metcash.AIS.APIOps` | APIM artifact management |
| Shared DevOps | `Metcash.AIS.DevOps`, `Metcash.AIS.ADF.DevOps` | Shared pipeline templates |
| Testing | `AIS-JMETER-SCANAPI.git`, `Katalon-POC`, `PostmantoJmeter`, `EAII-370-API-Test.git` | Testing tooling |
| ALMNZ | `Metcash.AIS.ALMNZ.*` | New Zealand supply chain repos |
| RetailTech | `Metcash.RetailTech.*` | Loyalty, ScanV2.5, DigitalReceipts |
| Shared/Copilot | `Metcash.AIS.Shared.Copilot`, `Metcash.AIS.Shared.Copilot.Prompts` | AI tooling |

---

## Repository Naming Convention

```
Metcash.AIS.{Platform}.{Service}
```

or for sub-numbered repos:
```
Metcash.AIS.{Platform}.{NN}.{Type}
```

Examples:
- `Metcash.AIS.B2B.01.Datafactory` (first B2B ADF repo)
- `Metcash.AIS.RMN.01.Datafactory`, `Metcash.AIS.RMN.02.Datafactory`

---

## Default Branch

All repos use `main` as the default/collaboration branch.

---

## Branch Conventions

| Branch Pattern | Purpose | Example |
|---|---|---|
| `main` | Production-ready default | `main` |
| `release_{yyyyMMdd}` | Release snapshot (used in Metproducts) | `release_200617` |
| `feature/{kebab-description}` | Feature work | `feature/pim-to-pe-ai-code` |
| `feature/{EAII-ID}-{description}` | **[Recommended]** EAII-linked feature branch | `feature/EAII-432-consent-subscriber` |
| `bugfix/{description}` | **[Inferred]** Bug fix branches | — |
| `hotfix/{description}` | **[Inferred]** Production hotfixes | — |

---

## Pull Request Guidelines

### PR Title Format

**[Recommended]** Use EAII ID prefix for traceability:
```
EAII-{number}: {Short description of change}
```

Example: `EAII-432: Add consent subscriber to Braze (TT)`

### PR Description Checklist

Include in all PRs:
- [ ] EAII ID linked in title
- [ ] What changed (brief)
- [ ] Which environments this targets
- [ ] Test evidence (unit test pass, SIT validation)
- [ ] Link to ADO work item

### Reviewers

**[Inferred]** Squad 20 team members. At least one reviewer required for merge.

### Branch Policies (Inferred)

- PR required to merge into `main`
- At least one required reviewer
- Build validation (CI pipeline must pass before merge)
- SonarQube quality gate must pass (CI with SonarQube template)

---

## Pipeline Trigger Conventions

### CI (Merge) Trigger

```yaml
trigger:
  branches:
    include:
      - main
```

### PR Validation Trigger

```yaml
pr:
  branches:
    include:
      - main
```

---

## How to Create a Branch via ADO MCP

Get the latest `main` commit ID first using `mcp_azure_devops2_repo_get_branch_by_name`, then:

```json
{
  "repositoryId": "Metcash.AIS.{Platform}.{Service}",
  "project": "Squad 20",
  "name": "refs/heads/feature/EAII-{number}-{description}",
  "oldObjectId": "{commitId-of-main-HEAD}"
}
```

Tool: `mcp_azure_devops2_repo_create_branch`

---

## How to Create a PR via ADO MCP

```json
{
  "repositoryId": "Metcash.AIS.{Platform}.{Service}",
  "project": "Squad 20",
  "title": "EAII-{number}: {Description}",
  "description": "## Changes\n...\n\n## EAII Work Item\nEAII-{number}",
  "sourceBranch": "refs/heads/feature/{branch-name}",
  "targetBranch": "refs/heads/main"
}
```

Tool: `mcp_azure_devops2_repo_create_pull_request`

---

## File Structure Expectations for PR Review

When reviewing a PR for Logic App + Function changes, expect:

```
changed:
  LogicApp/{WorkflowName}/workflow.json           ← workflow changes
  LogicApp/AppSettings/appsettings.{env}.json     ← new app settings
  LogicApp/Connections/connections.{env}.json     ← new connections
  LogicApp/Parameters/parameters.{env}.json       ← new parameters
  Function/{FunctionName}.cs                      ← function changes
  pipelines/{interface}.yml                       ← pipeline changes
```

When reviewing a PR for APIOps changes, expect:
```
changed:
  gen-3/artifacts/apis/{api-name}/apiInformation.json
  gen-3/artifacts/apis/{api-name}/specification.yaml
  gen-3/artifacts/apis/{api-name}/policy.xml
  gen-3/artifacts/backends/{backend}/backendInformation.json
  gen-3/artifacts/named values/{name}/namedValueInformation.json
```

---

## Observed Evidence

| Repository | File Path | Pattern Observed |
|---|---|---|
| `Metcash.AIS.Data.Metproducts` | Branch `release_200617` | Release branch naming pattern |
| `Metcash.AIS.Data.Metproducts` | Branch `feature/pim-to-pe-ai-code` | Feature branch naming |
| `Metcash.AIS.RMN` | Workflow folder `EAII-432-consentsubscriber-braze-tt` | EAII ID in work item naming |
| `Metcash.AIS.DevOps` | `/pipelines/templates/logicapp-pr-template.yml` | PR validation pipeline template |
| `Metcash.AIS.DevOps` | `/pipelines/templates/logicapp-pr-sonarqube-template.yml` | SonarQube PR gate |

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `microsoft/azure-devops-mcp-metcash` | `repo_get_branch_by_name` | Get latest `main` HEAD commit ID |
| `microsoft/azure-devops-mcp-metcash` | `repo_create_branch` | Create the feature branch |
| `microsoft/azure-devops-mcp-metcash` | `repo_create_pull_request` | Open the PR |
| `microsoft/azure-devops-mcp-metcash` | `repo_get_pull_request_changes` | Read PR diff for review |
| `memory` | Retrieve entity | Load EAII ID and repository name from session |
