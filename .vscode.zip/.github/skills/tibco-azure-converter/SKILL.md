---
name: tibco-azure-converter
description: >
  Use this skill for TIBCO-to-Azure Logic App workspace code generation after the NFR and
  architecture-fit analysis is complete. Trigger it when the user wants to generate a Logic App
  Standard workspace (workflows, connections, parameters, and any required local transformation
  code) for one or more destinations, derived from a reference workspace, and produce conversion
  outputs, assumptions, and unit-test CSV files. Do not use this skill for initial architecture
  recommendation or deployment planning.
---

# TIBCO to Azure Logic App Workspace Code Generation

Generate Logic App Standard workspace assets for the approved interface and destinations as an
**additive overlay** onto the reference workspace. **The reference workspace IS the production
source repo (Core rule below) — the overlay is written directly into a real local clone of that
repo, on a feature branch, never into `outputs/<InterfaceID>/`.** Only documents (`OVERLAY.md`,
`assumptions.md`, `change-summary.md`, `conversion-notes.md`, `unit-test-cases.csv`) go in
`outputs/<InterfaceID>/` — matching the same docs-vs-code split used everywhere else in this
pipeline (see `ais-codegen-readiness`, `ais-logicapp-codegen`).

## Resolve the real repo clone after the inline intake gate

1. Resolve the proposed reference workspace repo name from the NFR recommendation or verified
   workspace evidence; surface any uncertainty through the inline intake gate below.
2. Check whether `C:\Users\<you>\source\repos\<RepoName>` already exists locally — if the working
   tree isn't clean, **stop and ask** before touching it; never branch over uncommitted changes.
   Clone only after the inline questions are answered and the user confirms the resolved scope.
3. Create the feature branch `feature/EAII-<number>-<short-description>` off latest `main` only
   after that confirmation (per `azure-devops-repository-pr`'s naming convention). Never
   auto-commit or auto-push — leave the overlay as local, uncommitted changes for review.
4. Write every new workflow/function/helper/resource/pipeline file from the "Overlay layout"
   below directly into that clone, at the real paths the reference workspace already uses.

## Core rule - preserve existing, add on top

The reference workspace is the production source repo. Never modify existing logic, namespaces,
project files, models, helpers, or workflows. Only add new files, and for shared per-environment
config (parameters, app settings, connections) append the new keys directly into the existing
files without rewriting or duplicating them.

New code reuses existing root namespaces, the existing csproj, and existing shared types (for
example the existing `TransfromationOutput` envelope). Do not duplicate them.

## Required inputs

- NFR recommendation summary (approved target architecture)
- TIBCO source (Git URL or local checkout)
- Reference workspace path
- Interface ID matching `^EAII-[0-9]+$`
- Requested target destination(s)

If any input is missing, stop and ask.

## Inline Intake Gate — Before Clone, Branch, or Generation

Read the approved NFR recommendation, the selected TIBCO source, and the current reference
workspace before asking questions. For each required fact still missing, ambiguous or conflicting,
use `vscode_askQuestions` inline. State the proposed answer, evidence/source, confidence or
conflict, and impact; allow the user to confirm, correct, or choose unknown/keep blocked. Ask only
about unresolved facts, including the exact interface ID, source entry point, target destination(s),
reference repo/path, transformation and endpoint behavior, branch name, or target resource names.
Do not clone, create a branch, or write code while a blocking choice is unresolved.

Record each proposal, evidence, user response/correction and provenance in
`outputs/<InterfaceID>/assumptions.md` before generation. If the question tool is unavailable, ask
in chat and stop. Once all required facts are confirmed, present the resolved scope (repo, branch,
destinations and architecture) and obtain explicit confirmation before cloning/branching or writing
the overlay. That confirmation does not authorize commits, pushes, shared-system writes, or
deployment. Do not repeat questions already answered by the approved NFR recommendation or
verified source/repo evidence.

## Workflow

1. **Read the reference workspace first.** Derive all naming, folder layout, namespaces, project
   layout, connection names, parameter object names, and observability patterns from it. If a
   convention is not visible, stop and ask.
2. **Read the TIBCO source for the selected target only.** Extract source/target schemas, field
   mappings, conditionals, loops, defaults, and endpoint behavior. Ignore unrelated targets.
3. **Apply the approved architecture from the NFR step.** Do not introduce a local code layer just
   because TIBCO had one.
4. **Prefer direct target JSON for JSON destinations.** Preserve an XML intermediate only when the
   downstream contract, reference workspace, or user explicitly requires it. Document any retained
   intermediate in `assumptions.md`.
5. **Generate the overlay directly in the real repo clone + branch resolved above** (see layout
   below) — never in `outputs/<InterfaceID>/`.

## Overlay layout

Add new workflow, function, helper, resource, test, and pipeline files only, into the real repo
clone. Append new keys directly into the existing parameter, app settings, and connection files
for each environment; do not duplicate or rewrite those files.

Also generate, in `outputs/<InterfaceID>/` (documents only): `OVERLAY.md` (where each new file
went in the clone and which keys were appended where), `assumptions.md`, `change-summary.md`,
`conversion-notes.md`, and `unit-test-cases.csv`.
`change-summary.md` must list both new files and an explicit "Files NOT included (preserved from
reference)" section.

## Quality checklist

- approved architecture from the NFR step is reflected in the generated files
- existing files are not duplicated or rewritten; new keys are appended into existing config files
- new code reuses existing namespaces, csproj, and shared types
- `OVERLAY.md` and `change-summary.md` make the merge steps obvious
- JSON-first targets avoid unnecessary XML intermediates
- generated code and JSON are buildable or syntactically valid

## Guardrails

- For architecture recommendation, use `tibco-azure-nfr-recommendation`.
- For deployment planning, use `tibco-azure-deployment-guidance`.

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `github` | `get_file_contents`, `list_directory` | Read TIBCO source — extract schemas, mappings, business rules |
| `mcp_azure_devops2_repo_get_file_content` | ADO MCP | Read reference Logic App workspace patterns (workflow.json, connections.json) |
| `mcp_azure_devops2_repo_list_directory` | ADO MCP | Browse reference workspace folder structure |
| `memory` | Retrieve entity | Load NFR recommendation and Design Intake Questionnaire from session context |
| `memory` | Store entity | Persist conversion output summary for downstream deployment skill |
| `microsoft-docs` | Microsoft Docs MCP | Verify Logic App action schemas and ADF pipeline properties |

### Step-by-Step MCP Usage

**Step 1 — Load NFR recommendation from memory**
Retrieve the NFR recommendation stored by `tibco-azure-nfr-recommendation`. Do not re-read
the TIBCO source from scratch — use the already-extracted transformation summary.

**Step 2 — Read reference workspace via ADO MCP**
```
mcp_azure_devops2_repo_list_directory → reference workspace root
mcp_azure_devops2_repo_get_file_content → LogicApp/connections.json, parameters.json, workflow.json
mcp_azure_devops2_repo_get_file_content → Function/ project structure
```

**Step 3 — Read TIBCO source for the selected interface only via GitHub MCP**
```
github: list_directory → TIBCO repo root
github: get_file_contents → {interface}/*.process files
github: get_file_contents → {interface}/*.substvar files
github: get_file_contents → schemas/*.xsd or schemas/*.json
```

**Step 4 — Generate overlay and store summary in memory**
After generating all output files, store a conversion summary in memory so
`tibco-azure-deployment-guidance` can consume it without re-reading files.
