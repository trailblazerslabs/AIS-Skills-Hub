---
name: mcp-usage-guide
description: |
  Metcash AIS MCP (Model Context Protocol) usage guide. USE FOR: understanding which MCP server
  to activate for each engineering activity — reading FSD/TSD from Confluence, reading TIBCO
  source from GitHub, managing ADO work items / repos / test plans / pipelines, querying Azure
  SQL, looking up Azure documentation, and persisting session context. Reference this skill
  whenever a task requires reading from or writing to an external system.
  DO NOT USE FOR: generating Logic App or Function App code directly.
  Triggers: "which MCP", "use MCP", "read FSD from confluence", "read TSD", "read TIBCO from
  GitHub", "create ADO work item", "create test plan", "create PR via MCP", "query database",
  "lookup Azure docs", "mcp server", "connect to ADO", "connect to confluence", "MCP routing".
---

# MCP Usage Guide — Metcash AIS

This skill is the authoritative reference for **when and where to use each MCP server**
across the Squad 20 engineering lifecycle. Load this skill whenever you are unsure which
external system to reach or how to authenticate.

---

## ⛔ Metcash only — never Pet Supermarket (rule 2026-10-04)

All ADO, Confluence and Azure work here targets `METCASHDevOps` / `metcash.atlassian.net` / the Metcash tenant only. The VS Code
tool names for the Azure DevOps MCP servers (`mcp_azure_devops__…`, `…2_…`, `…3_…`) do **not** say which organisation they hit,
and a user-level `azure-devops-mcp-petsupermarket` server used to be registered next to the Metcash one (removed 2026-10-04;
backup `mcp.json.bak-*`). Therefore: before the first ADO MCP call in a session confirm the server is the one defined in this
repo's `.vscode/mcp.json` with `METCASHDevOps`; if you cannot tell, do not call it — use the local clone and `git` against the
`https://METCASHDevOps@dev.azure.com/METCASHDevOps/Squad%2020/_git/<repo>` remote instead. Ignore any global instruction that
routes `psi*` / Pet Supermarket work to another organisation when the task is a Metcash interface.

## Configured MCP Servers (`.vscode/mcp.json`)

Six MCP servers are active in this workspace:

| Key | Type | System | Purpose |
|---|---|---|---|
| `microsoft/azure-devops-mcp-metcash` | stdio | Azure DevOps | Work items, repos, PRs, test plans, pipelines, wikis |
| `com.atlassian/atlassian-mcp-server-metcash` | HTTP | Atlassian | Confluence (FSD, TSD, runbooks) |
| `github` | stdio | GitHub.com | TIBCO legacy source repos, reference workspaces |
| `azure-sql-b2b-ut1` | stdio | Azure SQL | `b2b-integration-ut1-sqldb` queries (UT1 env only) |
| `microsoft-docs` | HTTP | Microsoft Learn | Azure Logic App, ADF, Function App API schemas |
| `memory` | stdio | Local | Session context persistence across multi-step tasks |

---

## MCP Server 1 — Azure DevOps (`microsoft/azure-devops-mcp-metcash`)

**Organisation:** `METCASHDevOps` | **Default Project:** `Squad 20`

### When to Use

| Task | Tool to Call |
|---|---|
| Read a work item by ID | `mcp_azure_devops2_wit_get_work_item` |
| Search work items by EAII ID or text | `mcp_azure_devops2_search_workitem` |
| Create work item (Epic, Feature, Story, Task, Bug) | `mcp_azure_devops2_wit_create_work_item` |
| Update a work item field or status | `mcp_azure_devops2_wit_update_work_item` |
| Add comment to a work item | `mcp_azure_devops2_wit_add_work_item_comment` |
| Link work items (parent/child) | `mcp_azure_devops2_wit_add_child_work_items` |
| List repositories in Squad 20 | `mcp_azure_devops2_repo_list_repos_by_project` |
| Read a file from a repository | `mcp_azure_devops2_repo_get_file_content` |
| List directory contents in a repo | `mcp_azure_devops2_repo_list_directory` |
| Create a feature branch | `mcp_azure_devops2_repo_create_branch` |
| Create a pull request | `mcp_azure_devops2_repo_create_pull_request` |
| Get PR changes/diff | `mcp_azure_devops2_repo_get_pull_request_changes` |
| Get pipeline build status | `mcp_azure_devops2_pipelines_get_build_status` |
| Run / trigger a pipeline | `mcp_azure_devops2_pipelines_run_pipeline` |
| Create a test plan | `mcp_azure_devops2_testplan_create_test_plan` |
| Create a test suite | `mcp_azure_devops2_testplan_create_test_suite` |
| Create test cases | `mcp_azure_devops2_testplan_create_test_case` |
| Add test cases to a suite | `mcp_azure_devops2_testplan_add_test_cases_to_suite` |
| Search or read wiki pages | `mcp_azure_devops2_wiki_get_page`, `mcp_azure_devops2_search_wiki` |
| Create or update a wiki page | `mcp_azure_devops2_wiki_create_or_update_page` |

### Skills That Load This MCP

- `ais-unit-test-cases` — create ADO Test Plan, Test Suite, and Test Cases
- `ais-test-results-to-ado` — record execution outcomes against the existing Test Plan, close the Test Run
- `ais-deployment-runbook` — validate pipeline status before and after deployment
- `azure-devops-work-items` — EAII ID lookup and work item management
- `azure-devops-repository-pr` — branch creation, PR creation
- `ais-code-review` — read source files from ADO repos for review

### Usage Pattern

Always confirm the EAII ID before calling ADO MCP tools. Use `Squad 20` as the default
project. When creating work items, use `wit_create_work_item` and immediately link to
the parent with `wit_add_child_work_items`.

---

## MCP Server 2 — Atlassian (`com.atlassian/atlassian-mcp-server-metcash`)

**Instance:** `metcash.atlassian.net` | **Products:** Confluence (this project tracks work items in Azure DevOps, not Jira)

### When to Use

| Task | Action |
|---|---|
| Search Confluence for FSD by EAII ID | Search Confluence pages with title containing EAII ID |
| Read FSD page content | Fetch full page content from Confluence |
| Search for TSD linked to FSD | Search Confluence for TSD or Technical Specification page |
| Create a new Confluence documentation page | Create page in correct space (e.g., MAP space) |
| Update deployment runsheet page | Update page with live status macros |
| Search for architecture decision records | Search by label or title |

### Skills That Load This MCP

- `ais-design-intake` — fetch FSD and TSD from Confluence **before** code generation
- `ais-deployment-runbook` — create and update Confluence runsheet pages
- `ais-documentation` — publish generated technical specs to Confluence

### Usage Pattern

1. When EAII ID is known, search Confluence: `Search for "EAII-{number}" in page titles`.
2. Read the full FSD/TSD page content before starting intake.
3. When creating documentation, target the `MAP` Confluence space unless specified otherwise.

---

## MCP Server 3 — GitHub (`github`)

**Auth:** `GITHUB_TOKEN` env variable | **Scope:** TIBCO legacy repos + reference workspaces

### When to Use

| Task | Action |
|---|---|
| List repositories containing TIBCO source | `search_repositories` with TIBCO org/name terms |
| Read TIBCO BusinessWorks process files | `get_file_contents` on `.process`, `.bwp`, `.substvar` files |
| Browse TIBCO repo directory structure | `list_directory` or `get_file_contents` on root |
| Read reference Logic App workspace from GitHub | `get_file_contents` on workflow.json, connections.json |
| Understand TIBCO mapping and transformation logic | Read all `.substvar` and `.process` files in scope |

### Skills That Load This MCP

- `tibco-azure-nfr-recommendation` — read TIBCO source to assess transformation complexity
- `tibco-azure-converter` — extract field mappings, schemas, and business rules from TIBCO source
- `ais-codegen-readiness` — cross-check an interface's TSD/FSD against its actual legacy TIBCO
  source, when one exists, reusing this same read pattern (README → root listing → relevant
  `.process`/`.bwp` files only)

### Usage Pattern

1. Read `README.md` at repo root first to understand the TIBCO application scope.
2. List root directory to identify entry points (`.application`, `.bwp` folders).
3. Read `.process` files in the relevant interface folder only — not the entire repo.
4. Read `.substvar` files to extract environment-specific values.
5. Read `schemas/` or `xsd/` folders to understand source/target schemas.

---

## MCP Server 4 — Azure SQL (`azure-sql-b2b-ut1`)

**Server:** `t3-met-b2b-ut1-ae-sql.database.windows.net`
**Database:** `b2b-integration-ut1-sqldb` | **Environment:** UT1 only

### When to Use

| Task | When |
|---|---|
| Query reference or lookup data | During debugging of Logic App or ADF failures in UT1 |
| Validate data outcomes after a test run | Post-deployment verification in UT1 |
| Check stored procedure parameters or table schema | During development or ADF pipeline design |
| Investigate data transformation issues | When ADF copy activity produces unexpected output |

### Skills That Load This MCP

- `ais-debug-azure` — data validation during debugging sessions
- `ais-code-review` — validate ADF SQL sink configurations against actual schema

### Authentication Prerequisite

```powershell
# Must run BEFORE using this MCP server
az login --username m-sathyja@metcash.onmicrosoft.com --tenant metcash.onmicrosoft.com
```

See `azure-local-auth` skill for full authentication setup.

---

## MCP Server 5 — Microsoft Docs (`microsoft-docs`)

**URL:** `https://docs.microsoft.com/api/mcp`

### When to Use

| Task | When |
|---|---|
| Look up Logic App action schema | When generating `workflow.json` and unsure of action shape |
| Verify ADF linked service properties | When generating linked service JSON |
| Check Function App binding attributes | When generating Function App trigger/output bindings |
| Verify Service Bus connector properties | When configuring Logic App Service Bus actions |
| Look up Azure resource REST API contracts | When writing ARM templates or Bicep |

### Skills That Load This MCP

- `ais-logicapp-codegen` — verify Logic App action and connector schemas
- `ais-datafactory-codegen` — verify ADF pipeline, dataset, and linked service schemas
- `ais-functionapp-codegen` — verify Function App binding attributes

---

## MCP Server 6 — Memory (`memory`)

### When to Use

| Task | When |
|---|---|
| Persist Design Intake Questionnaire | After `ais-design-intake` — store for downstream codegen skills |
| Persist NFR recommendation | After `tibco-azure-nfr-recommendation` — pass to `tibco-azure-converter` |
| Track multi-step session progress | During long sessions spanning multiple skills |
| Store field mapping tables | When mappings are large and referenced across multiple skills |
| Store EAII ID and interface metadata | At session start — retrieve in every subsequent skill |

### Skills That Load This MCP

Used by **all skills** when operating in a multi-step session. Always store and retrieve
shared context via memory rather than re-asking the user for known values.

---

## End-to-End MCP Activity Map

Use this to determine which MCP servers to activate for a given engineering phase:

| Engineering Phase | Skills Involved | MCP Servers |
|---|---|---|
| **1. Intake** — read FSD (no TSD exists) | `ais-design-intake` | Atlassian MCP |
| **1.5. Codegen Readiness** — resolve repo/resource name once a TSD exists | `ais-codegen-readiness` | GitHub MCP (TIBCO cross-check, if applicable), memory MCP |
| **2. Architecture** — assess TIBCO / NFR | `tibco-azure-nfr-recommendation` | GitHub MCP, memory MCP |
| **3. Development** — generate code | `ais-logicapp-codegen`, `ais-functionapp-codegen`, `ais-datafactory-codegen` | ADO MCP (reference workspace), memory MCP, Microsoft Docs MCP |
| **4. Testing** — generate + register tests | `ais-unit-test-cases` | ADO MCP |
| **5. Test Execution** — run tests against a deployed non-prod resource | `ais-test-execution` | Azure SQL MCP, ADO MCP |
| **6. Test Results** — record outcomes in ADO | `ais-test-results-to-ado` | ADO MCP |
| **7. Code Review** | `ais-code-review` | ADO MCP |
| **8. Documentation** — publish specs | `ais-documentation` | Atlassian MCP, memory MCP |
| **9. Deployment** — runbook + pipelines | `ais-deployment-runbook` | Atlassian MCP, ADO MCP |
| **10. Debugging** — investigate failures | `ais-debug-azure` | ADO MCP, Azure SQL MCP |
| **11. Work Items** — manage backlog | `azure-devops-work-items` | ADO MCP |
| **12. PR / Branch** — source control | `azure-devops-repository-pr` | ADO MCP |
| **13. TIBCO Conversion** — generate code | `tibco-azure-converter` | GitHub MCP, ADO MCP, memory MCP |

---

## Pre-Session Authentication Checklist

Before starting any MCP-connected session, verify:

- [ ] **ADO MCP** — VS Code Azure Account signed in (`Ctrl+Shift+P` → `Azure: Sign In`) or ADO PAT token configured
- [ ] **Atlassian MCP** — authenticated via `metcash.atlassian.net` (HTTP MCP handles token via browser)
- [ ] **GitHub MCP** — `GITHUB_TOKEN` environment variable set in shell or `.env` file
- [ ] **Azure SQL MCP** — `az login` completed with `m-sathyja@metcash.onmicrosoft.com`
- [ ] **Microsoft Docs MCP** — HTTP MCP, no authentication required
- [ ] **Memory MCP** — stdio MCP, no authentication required

See `azure-local-auth` skill for detailed authentication steps.

---

## MCP Restart After Sign-In

After completing Azure or Atlassian sign-in, restart affected MCP servers:

```
Ctrl+Shift+P → MCP: List Servers → Select server → Restart
```
