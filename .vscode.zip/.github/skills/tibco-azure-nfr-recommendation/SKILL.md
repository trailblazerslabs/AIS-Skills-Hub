---
name: tibco-azure-nfr-recommendation
description: >
  Use this skill first for TIBCO-to-Azure work when the user needs architecture-fit,
  non-functional-requirement analysis, or a recommendation on whether the interface should be
  implemented with Logic App Standard only, Logic App Standard plus local transformation code, or
  another Azure pattern. Trigger it before code generation whenever the user mentions performance,
  payload size, throughput, best fit, architecture choice, or asks what the right target shape is.
---

# TIBCO Azure NFR And Fit Analysis

This is the first skill in the workflow. It must run before any conversion skill writes code.

## Purpose

- collect non-functional requirements early
- assess the interface shape before committing to an Azure implementation pattern
- produce an explicit architecture recommendation that later code generation must follow

## Mandatory first questions

Ask for these before reading the full TIBCO mapping in depth:

| Input | Mandatory | Notes |
|---|---|---|
| Interface ID(s) | Yes | Must match `EAII-{number}` |
| TIBCO source location | Yes | Git URL or local checkout |
| Reference Azure workspace or template | Yes | Needed to assess fit against existing implementation patterns |
| Payload size | Yes | Typical and peak message or file size |
| Volume and concurrency | Yes | Requests per minute, batch frequency, or concurrent runs |
| Latency expectations | Yes | Real-time, near-real-time, batch, or scheduled |
| Reliability expectations | Yes | Retry, idempotency, failure handling, recovery expectations |
| Observability and support constraints | Yes | Logging, alerting, auditability, support ownership |
| Special constraints | Optional | Security, network, cost, schema volatility, transformation complexity |

Before asking, read the interface status and enough of the TIBCO entry point/reference workspace
to establish any available context; do not deep-read unrelated mappings. Use `vscode_askQuestions`
for each missing or conflicting NFR. State an evidence-backed proposed value when one exists,
otherwise say that no evidence supports a proposal; explain the impact and allow confirm, correct,
or unknown/keep blocked. Do not re-ask facts already evidenced. Record the confirmed answers and
their sources in the recommendation. If required NFR data remains unknown, stop; do not proceed
with a recommendation using guessed values.

## Analysis order

### Step 1 - Read enough technical context to assess fit

Read only what is needed to determine the likely implementation pattern:

- reference workflow and transformation structure
- TIBCO entry points, mapping complexity, and target contract style
- whether the target is JSON-first, XML-first, or mixed

Do not start generating code in this skill.

### Step 2 - Evaluate implementation options

Compare at least these options when relevant:

- Logic App Standard only
- Logic App Standard plus local transformation code
- another Azure-hosted pattern if the NFRs clearly exceed the reference shape

Consider:

- transformation complexity
- payload size and memory pressure
- throughput and concurrency
- maintainability and operational ownership
- fit with the existing Azure reference workspace
- how much custom code is actually necessary

### Step 3 - Produce the recommendation

Return a concise decision package the next skill can consume directly:

- recommended Azure implementation pattern (the approved architecture)
- reasons tied to the stated NFRs
- any constraints on payload handling, retries, logging, or code placement
- what follow-up skill should run next
- any blockers or missing data that prevent safe code generation

If the recommendation is not approved or remains ambiguous, do not move to code generation.

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `github` | `get_file_contents`, `list_directory` | Read TIBCO source repo — entry points, mappings, schemas |
| `github` | `search_repositories` | Locate TIBCO repo by name or org |
| `mcp_azure_devops2_repo_get_file_content` | ADO MCP | Read reference Logic App workspace from METCASHDevOps |
| `memory` | Store entity | Persist NFR recommendation for `tibco-azure-converter` |

### GitHub MCP — Reading TIBCO Source

When the TIBCO source is a GitHub URL:
1. Use `search_repositories` to confirm the repo exists and get its full name.
2. Use `list_directory` on the repo root to identify application folders.
3. Read `README.md` first to understand the TIBCO application scope.
4. Read `.process` files in the relevant interface folder to assess transformation complexity.
5. Read `.substvar` files to understand environment-specific configuration.
6. Read `schemas/` or `xsd/` folders to understand source/target data contracts.

> Read **only the interface(s) in scope**. Do not read the entire TIBCO repository.

### ADO MCP — Reading Reference Workspace

When the reference Azure workspace is in METCASHDevOps:
1. Use `mcp_azure_devops2_repo_list_repos_by_project` to locate the reference repo.
2. Use `mcp_azure_devops2_repo_list_directory` to browse the workspace structure.
3. Use `mcp_azure_devops2_repo_get_file_content` to read `workflow.json` and `connections.json` patterns.