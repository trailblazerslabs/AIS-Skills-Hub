# Unit Test Generation Intake — {EAII-IDs} — {InterfaceName}

Generated: {date} | Status: **AWAITING YOUR APPROVAL — CSV generation is paused**

This questionnaire proposes the test coverage to be expanded into `unit-test-cases.csv`. It is
based on the TSD's §5.x.10.2 scenarios, the generated code, and the approved Codegen Readiness
Questionnaire. **No test-case CSV rows or final `TC-NNN` IDs have been generated yet.**

Approving this questionnaire authorizes generating the local CSV only. It does not authorize
creating or updating ADO Test Plans/Suites/Cases, deploying code, or executing tests.

## 1. TSD Scenario Inventory

| TSD Scenario ID / Name | Proposed coverage treatment | Evidence |
|---|---|---|
| {scenario} | {carry forward / expand / blocked pending contract} | {TSD section} |

## 2. Code-Derived Coverage Themes

| Code path / behavior | Proposed assertion theme | Evidence |
|---|---|---|
| {class, action, retry/error behavior} | {what a case should verify, no final TC ID} | {file/method or workflow action} |

## 3. Proposed Category Coverage

| Category | Proposed case count | Rationale |
|---|---:|---|
| Happy Path | {n} | {TSD/code evidence} |
| Error Path | {n} | {TSD/code evidence} |
| Boundary | {n} | {TSD/code evidence} |
| Business Logic | {n} | {TSD/code evidence} |
| **Total** | **{n}** | |

## 4. Test Data and Expected-Result Gaps

| # | Gap | Effect on expected result | Needed evidence / owner |
|---|---|---|---|
| G1 | {gap or None} | {can a precise assertion be written?} | {source / owner} |

Do not invent payload fixtures, external endpoints, or expected business outcomes to fill gaps.
Carry blocked cases as explicit gaps; do not present them as executable tests.

## 5. Proposed Output

- CSV path: `outputs/{EAII-ID}/unit-test-cases.csv`
- Proposed case count: {n}
- Interface IDs covered: {EAII-IDs}
- No ADO writes, deployment, or test execution are part of this approval.

## 6. Approval

Review the scenario inventory, scope, counts, and blockers. Edit this questionnaire if needed,
then explicitly approve it before CSV generation begins.