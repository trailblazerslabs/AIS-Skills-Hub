# Unit Test Readiness Questionnaire — {EAII-IDs} — {InterfaceName}

Generated: {date} | Status: **AWAITING YOUR APPROVAL — ADO Test Case creation is paused**

The `unit-test-cases.csv` below is a proposal, enriched from the TSD's own §5.x.10.2 scenarios,
the actual generated code, and (if applicable) the TIBCO cross-check. Review it:

- Agree with the coverage? Leave it as-is.
- Disagree, or see a missing case? Edit `outputs/{EAII-ID}/unit-test-cases.csv` directly, or
  tell the agent what to add/change.

Then tell the agent the questionnaire is approved. **Real ADO Test Cases will not be created in
the shared "AIS Migration" plan until you do** — this is a shared, squad-wide plan, not a
scratch/local artifact, so nothing is written there without your review.

---

## 1. TSD baseline scenarios carried forward

**Count:** {N} of {N} TSD §5.x.10.2 scenarios carried forward as-is (none dropped, none reworded
away from what the TSD approved).

| TSD Scenario | Carried as |
|---|---|
| {T1} | {TC-001} |
| ... | ... |

---

## 2. Enrichments from the actual generated code

What changed or got more specific once the real code (Stage 2 output) was available — real
class/method names, actual retry constants, actual error codes, validation logic the TSD didn't
spell out at this level.

| TSD Scenario | What the code revealed | How the test case changed |
|---|---|---|
| {e.g. T7} | {e.g. "MaxRetries=3, RetryDelay=5s, confirmed in PEProductDataToStiboService.cs"} | {e.g. "Assertion now checks exactly 3 HTTP attempts with 5s between them"} |

---

## 3. Enrichments from the TIBCO cross-check

*Only include this section if `ais-codegen-readiness` §5 ran a TIBCO cross-check. Omit otherwise.*

| Codegen Readiness Finding | New/changed test case |
|---|---|
| {finding} | {TC-NNN} |

---

## 4. New cases added for gaps the TSD didn't cover

| Category | New Case | Why it's needed |
|---|---|---|
| {category} | {TC-NNN — scenario name} | {gap the TSD's own scenarios didn't address} |

> If the TSD's own coverage was already thorough (e.g. 16 scenarios), this section may be empty
> or short — don't manufacture cases just to fill it.

---

## 5. Category coverage summary

| Category | Count |
|---|---|
| Happy Path | {n} |
| Error Path | {n} |
| Boundary | {n} |
| Business Logic | {n} |
| **Total** | **{n}** |

---

## 6. ADO destination

**Plan:** "AIS Migration" (id `224095`) — **existing shared plan, not created by this run**

**Parent suite:** "Unit Testing" (id `416102`) — **existing shared suite, not created by this run**

**New suite to create:** `UT_EAII-{number} - {InterfaceName}` — **{n} test cases**, flat (no
sub-suites), one per CSV row regardless of category.

> If a suite with this exact name already exists (e.g. a prior partial run), say so here rather
> than silently creating a duplicate — the agent should stop and ask which to use.

---

## 7. Open gaps

| # | Item | Detail |
|---|---|---|
| G1 | {e.g. "TMP record type has no production sample — TC-0NN uses a synthetic payload per TSD §13"} | {carried from TSD/codegen-readiness, or newly noticed here} |

---

## 8. Anything else the developer/tester should know

> _______________

---

*Review the CSV and the summary above, make any edits you want, then tell the agent "questionnaire
approved" (or similar) to create the real ADO Test Cases. The agent will not proceed on its own —
this pause is mandatory, the same as the TSD intake questionnaire and the Codegen Readiness
Questionnaire before it.*
