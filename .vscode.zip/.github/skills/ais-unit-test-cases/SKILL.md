---
name: ais-unit-test-cases
description: |
  Metcash AIS unit test case generator. USE FOR: expanding a TSD's own §5.x.10.2 test scenarios
  (and, if none exist, deriving new ones) into an engineering-grade CSV after explicit approval
  of a pre-generation coverage intake questionnaire. A separate post-generation questionnaire
  governs ADO Test Plan/Suite/Case creation. Enrichment uses generated code and any TIBCO
  cross-check; scenarios are not redundantly re-derived. Covers happy path, error path, boundary,
  and business logic for Logic App, Function App, and ADF interfaces.
  RUNS AFTER Stage 2 codegen, not before.
  DO NOT USE FOR: generating code, running tests, or CI/CD pipeline configuration.
  Triggers: "generate test cases", "unit test", "test scenarios", "test matrix",
  "create test cases", "test coverage", "unit-test-cases.csv".
---

# AIS Unit Test Case Generator

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — confirm Phase 3 (code) is actually Done before starting, check
> whether a CSV/questionnaire/ADO suite already exists (avoid a duplicate suite), and update
> Phases 4-5's rows plus the ADO suite link on completion.

Generate a `unit-test-cases.csv` for an AIS integration interface — **after** code generation,
not instead of or before it. Every interface must have a test case CSV alongside its generated
code. **Do not write any test-case rows before the pre-generation intake questionnaire above is
explicitly approved.**

## This is an expansion of the TSD's own test scenarios, not a re-derivation from scratch

The TSD's own §5.x.10.2 "Unit Testing" section already lists real, often quite thorough test
scenarios (e.g. EAII-529's TSD has 16 — T1 through T16 — covering happy path, partial-file
variants, retry success/exhaustion, auth failure, format/empty-file errors, and more). **Do not
ignore this section and re-derive generic categories from nothing** — that risks diverging from,
or duplicating, what was already approved. Instead:

1. **Every TSD scenario is a mandatory baseline row** — carry each one into the CSV, never
   dropped, never silently reworded away from what the TSD approved.
2. **Enrich each one using what's now available that wasn't at TSD-approval time:**
   - **The actual generated code** (Stage 2's output, in the real repo clone resolved by
     `ais-codegen-readiness`) — real class/method names, the actual retry constants and
     non-retryable status codes used, the actual error codes/messages the code produces, any
     validation logic the TSD didn't spell out at this level of detail.
   - **The TIBCO cross-check findings**, if `ais-codegen-readiness` Step 4 ran one (§5 of the
     approved `codegen-readiness-questionnaire.md`) — legacy behavior it uncovered (e.g. an
     exact endpoint count/grouping, a legacy validation quirk) often reveals edge cases the FSD/
     TSD prose didn't capture at the code level.
3. **Add genuinely new cases only for gaps the TSD didn't cover** — a thin TSD test-scenarios
   section needs more added here; a thorough one (like EAII-529's) may need little.
4. **Do not write anything back into the TSD.** The TSD stays exactly as approved — this CSV
   and the ADO Test Cases it creates are the enhanced artifact, not a TSD revision.

If the TSD has no §5.x.10.2 scenarios at all (rare — only the no-TSD `ais-design-intake` path,
or an older TSD predating this corpus correction), derive cases from scratch using the
categories below.

## Required Inputs

- Interface ID matching `EAII-{number}`
- The TSD's own §5.x.10.2 test scenarios (`tsd/<EAII-ID>/*.md`) — the mandatory baseline
- The actual generated code, in the real repo clone + branch resolved by
  `ais-codegen-readiness` (from its approved `codegen-readiness-questionnaire.md`)
- The TIBCO cross-check section of that same questionnaire, if present
- Trigger type and input schema (or sample payload); target system and expected output shape

Stop and ask if the generated code isn't available yet — this skill runs after Stage 2, not
before it.

## CSV Template

The output CSV matches this column structure (from `reference-templates/tests/unit-test-cases.template.csv`):

```
TestCaseID, InterfaceID, InterfaceName, Category, ScenarioName, InputDescription,
ExpectedOutput, ValidationPoints, Priority, Status, Notes
```

## Test Categories

Cover all four categories for every interface:

| Category | Description | Minimum Cases |
|---|---|---|
| Happy Path | Valid input, expected output, successful end-to-end | 3–5 |
| Error Path | Invalid input, system errors, dead-letter scenarios | 3–5 |
| Boundary | Edge values: empty arrays, max payload, single record | 2–3 |
| Business Logic | Sorting order, duplicate handling, null field treatment | 2–4 |

## Example Output (CSV rows)

```csv
TC-001,EAII-NNN,<InterfaceName>,Happy Path,Single item processed successfully,"Single valid item payload","Item appears in target system with correct field values","1. Response 200 2. Target record created 3. SMC log entry written",High,Draft,
TC-002,EAII-NNN,<InterfaceName>,Happy Path,Multiple items processed and sorted,"100 items in random order","Items arrive at target sorted by [SortKey1] asc then [SortKey2] asc","1. Sort order verified 2. No items lost 3. Count matches",High,Draft,
TC-003,EAII-NNN,<InterfaceName>,Error Path,Empty payload rejected,"Empty JSON body {}","HTTP 400 returned with error message","1. 400 status code 2. Error message contains interface ID 3. SMC error log written",High,Draft,
TC-004,EAII-NNN,<InterfaceName>,Error Path,Target system unavailable,"Valid payload, target system down","Message dead-lettered, SMC alert fired","1. Dead letter queue has message 2. SMC alert triggered 3. Original message not lost",High,Draft,
TC-005,EAII-NNN,<InterfaceName>,Boundary,Single record processed,"Payload with exactly 1 item","1 item in target, no sorting errors","1. Count = 1 2. No array index errors",Medium,Draft,
TC-006,EAII-NNN,<InterfaceName>,Boundary,Maximum payload size,"Payload at maximum expected size (Xmb)","All items processed without timeout","1. No 413 error 2. Completion within SLA",Medium,Draft,
TC-007,EAII-NNN,<InterfaceName>,Business Logic,Duplicate items handled correctly,"Payload contains duplicate items","Duplicates handled per business rule (deduplicated / kept / flagged)","1. Output count correct 2. No data loss",Medium,Draft,
TC-008,EAII-NNN,<InterfaceName>,Business Logic,Null optional field treated as blank,"Item with null optional field","Output contains empty string or default value for null field","1. No null reference exception 2. Default value applied",Medium,Draft,
```

## Mandatory Approval Gate — before generating the CSV

The TSD scenarios and generated code are sufficient to propose a coverage plan, but the CSV
itself must not be generated before the user reviews that plan.

1. Read the TSD scenarios, generated code, and applicable codegen/TIBCO findings as described in
  the workflow below.
2. For each unresolved sample, expected result, boundary, environment or code-vs-TSD conflict,
   use `vscode_askQuestions` inline. State the proposed answer and its TSD/code evidence; allow
   the user to confirm, correct, or leave it blocked. Record answers/provenance and remaining
   gaps in the questionnaire. Do not re-ask a TSD scenario whose expected result is already
   explicit.
3. Fill [`templates/unit-test-generation-intake-questionnaire.template.md`](templates/unit-test-generation-intake-questionnaire.template.md)
  and write it to `outputs/<InterfaceID>/unit-test-generation-intake-questionnaire.md`.
  Include the TSD scenario inventory, code-derived coverage themes, proposed category counts,
  available test data, and unresolved expected-result blockers. Do not assign final `TC-NNN`
  IDs or write CSV rows at this stage.
4. **Stop.** Do not create or modify `unit-test-cases.csv` until the user explicitly approves
  this intake questionnaire. Approval permits only local CSV generation; it does not authorize
  ADO writes, deployment, or test execution.

## Workflow

1. Read the TSD's §5.x.10.2 test scenarios in full — this is the baseline, not optional context
2. Read the actual generated code in the real repo clone (Stage 2's output) — real method/class
  names, retry constants, non-retryable status codes, actual error codes/messages
3. Read the TIBCO cross-check section of the approved Codegen Readiness Questionnaire, if present
4. Produce the pre-generation intake questionnaire and stop at the mandatory gate above
5. After approval, map every TSD scenario to one CSV row, enriched with the concrete detail
  from steps 2–3
6. Identify any transformation rules or business logic points the TSD scenarios don't already
  cover, and add cases for them
7. Fill remaining category gaps if the TSD's own coverage is thin: error path, boundary,
  business logic (sort order, duplicate handling, null handling)
8. Assign test case IDs as `TC-NNN` starting from `TC-001`
9. Set all Status = `Draft`
10. Write to `outputs/<InterfaceID>/unit-test-cases.csv`
11. Fill [`templates/unit-test-readiness-questionnaire.template.md`](templates/unit-test-readiness-questionnaire.template.md)
   and write to `outputs/<InterfaceID>/unit-test-readiness-questionnaire.md`. **Stop.** Do not
   proceed to "ADO Test Plan Integration" below until the user explicitly approves this
   separate post-generation questionnaire.

## ⛔ Mandatory Approval Gate — before any ADO Test Case is created

**This mirrors the same stop-for-approval pattern as `metcash-tsd-generator`'s intake
questionnaire and `ais-codegen-readiness`'s own questionnaire — do not skip it.** The shared
"AIS Migration" Test Plan is squad-wide, not a scratch artifact: creating a real ADO Test Suite
and Test Cases in it is a visible, shared-state action, not a draft the user can quietly discard.

- Do NOT run any step under "ADO Test Plan Integration" until the user has reviewed
  `outputs/<InterfaceID>/unit-test-readiness-questionnaire.md` and told the agent it's approved.
- If the user edits `unit-test-cases.csv` directly during review, re-read it before creating
  ADO Test Cases — the CSV is the source of truth for what gets created, not the questionnaire's
  own summary tables.
- If a suite named `UT_EAII-{number} - {InterfaceName}` already exists under the shared "Unit
  Testing" parent suite (e.g. a prior partial run), stop and ask which to use rather than
  silently creating a duplicate.

## Output Location

Documents only — matches every other skill's `outputs/<InterfaceID>/` convention (see
[`README.md`](../../../README.md)/[`AGENTS.md`](../../../AGENTS.md) folder structure); this
skill never writes code, only the CSV, questionnaire, and the ADO creation-result mapping:

```
outputs/<InterfaceID>/unit-test-cases.csv
outputs/<InterfaceID>/unit-test-generation-intake-questionnaire.md
outputs/<InterfaceID>/unit-test-readiness-questionnaire.md
outputs/<InterfaceID>/ado-test-case-creation-result.json   ← written after ADO Test Plan Integration
                                                               below completes (suite id, plan/suite
                                                               hierarchy, and every CSV TestCaseID →
                                                               ADO work item id — read by
                                                               ais-test-results-to-ado afterwards)
```

## Rules

- Every TSD scenario (§5.x.10.2) must appear as at least one CSV row — count is whatever the
  TSD actually specifies (16 for EAII-529), not a fixed number. 8 across four categories is a
  **floor** for interfaces with no TSD scenarios to start from, not a target to cap at.
- Test case IDs must be sequential: `TC-001`, `TC-002`, etc.
- `ValidationPoints` must list specific, checkable assertions — not vague statements.
- Priority: High for happy path and error path; Medium for boundary and business logic edge cases.
- Reference the template at `reference-templates/tests/unit-test-cases.template.csv` for exact column order.

---

## ADO Test Plan Integration

**Precondition: `outputs/<InterfaceID>/unit-test-readiness-questionnaire.md` exists and the user
has approved it.** If not, stop here and go back to the Mandatory Approval Gate above — do not
create anything below on an unapproved or missing questionnaire.

**Confirmed against the real ADO Test Plan** (`AIS Migration`, plan id `224095`,
`https://dev.azure.com/METCASHDevOps/Squad%2020/_testPlans/execute?planId=224095`) —
the real structure is **one shared plan for the whole squad, with a `Phase 2` layer in
between the plan and the shared "Unit Testing" suite** (confirmed 2026-09-19 by walking the
full suite tree via REST — earlier versions of this skill omitted the `Phase 2` layer):

```
Test Plan: "AIS Migration" (id 224095)                    ← DO NOT create a new plan per interface
└── Suite: "Phase 2" (id 416101)                           ← current squad phase; "Phase 1" (416100)
    │                                                          is the earlier/legacy phase — do not
    │                                                          create under it unless told to
    └── Suite: "Unit Testing" (id 416102)                  ← the one shared parent suite for ALL
        │                                                      interfaces' unit tests
        └── Suite: "UT_EAII-{number} - {InterfaceName}"    ← ONE suite per interface, flat (no
            ├── Test Case: "{ScenarioName}"                   sub-suites)
            ├── Test Case: "{ScenarioName}"
            └── ... every scenario from the CSV, regardless of category
```

If a user mentions "Phase 2" (or "Phase 1") when asking for a suite to be created, they mean
this literal `Phase 2`/`Phase 1` suite layer — confirm current phase with the user if unstated,
but default to `Phase 2` (416101) since that's where every interface built after mid-2026 lives
(EAII-282/283/284/301/302/304/333/385/514/516/517/297, etc. — see
[`code-corpus/unit-tests/index.md`](../../../code-corpus/unit-tests/index.md)). Never assume
`416101`/`416102` are correct for a *different* ADO project without re-walking the suite tree
(Step 0 below) — those IDs are specific to `METCASHDevOps/Squad 20`.

Real example: `UT_EAII-304 - Liquor Suppliers to EIM` (suite id `416879`) holds **41** flat test
cases spanning auth/header validation, payload/file-format validation, business logic, error
handling, and cross-cutting checks (Finally-block behavior, non-blocking dependency failure,
termination gates) — treat the CSV's "at least 8 across 4 categories" as a floor, not a target;
category is expressed in the test case *title* and the CSV's `Category` column, not a separate
ADO suite per category.

### Step 0 — ⛔ Mandatory: verify ADO MCP access (and GitHub MCP, per the shared pre-flight gate)

This step is the same mandatory pre-flight gate documented once in
[`azure-local-auth`](../azure-local-auth/SKILL.md#-mandatory-pre-flight-check--required-before-generating-a-tsd-generating-code-or-generating-unit-test-cases) —
do not create a suite or test case with ADO access unverified. This skill doesn't itself read
GitHub, but confirm GitHub MCP is also reachable before proceeding if it hasn't already been
verified earlier in this session (e.g. by `metcash-tsd-generator` or `ais-codegen-readiness` for
the same interface) — it's a standing project-wide gate, not a per-skill one.

**Do not spend more than one check on the MCP tool.** `azure-devops-mcp-metcash` authenticates
via the local Azure CLI credential (`az login`), not a token of its own. Two failure modes look
identical from the outside — `claude mcp list` reports "✔ Connected" either way — but only one
is fixable by restarting:

1. Run `az account show`. If the signed-in user/tenant is **not** `*.metcash.com` /
   `metcash.onmicrosoft.com` (e.g. it shows an unrelated tenant or subscription), that's the
   actual problem: the MCP server can't get a Metcash ADO-scoped token, so it silently exposes
   zero tools even while the stdio handshake still succeeds. Fix it yourself — **do not wait for
   a session restart to fix this, restarting does nothing for it**:
   ```powershell
   az login --tenant metcash.onmicrosoft.com
   ```
   Then re-check the MCP tools once (`ToolSearch` for `testplan_create_test_suite` or similar).
2. If `az account show` already shows the Metcash tenant and the MCP tools *still* don't appear,
   that's a genuine tool-indexing issue with no known fix from inside the session — proceed
   directly to the REST fallback below rather than retrying `ToolSearch` repeatedly or asking
   the user to restart again.

**The REST fallback is proven and safe to use as the primary path whenever the MCP tools aren't
available** — it was used to create the real EAII-529 suite/cases on 2026-09-19 end-to-end. It
needs no PAT: the same `az login` session above is enough, using the AAD token scoped to Azure
DevOps's resource ID:

```powershell
$token = az account get-access-token --resource "499b84ac-1321-427f-aa17-267ca6975798" --query accessToken -o tsv
$headers = @{ Authorization = "Bearer $token" }
# ... use $headers on every call below, then always: $token = $null   (never write the token to a file)
```

A PAT (`Authorization: Basic <base64(:pat)>`, per `azure-local-auth`) also works if one is
supplied, but don't assume an `AZDO_PAT`-style env var is valid for `METCASHDevOps` without
testing it first — one found in this environment 401'd (it was scoped to something else). The
AAD bearer token above is the reliable option because it reuses the same `az login` session that
`git clone`/`az repos` already depend on.

### Step 1 — Confirm the suite tree, then find or create the interface's suite

Never hardcode `416101`/`416102` from memory across sessions without a quick re-check — walk the
tree once per run (cheap, catches any re-org):

```powershell
$uri = "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/testplan/Plans/224095/suites?api-version=7.1"
$all = @()
while ($uri) {
  $resp = Invoke-WebRequest -Method Get -Uri $uri -Headers $headers -UseBasicParsing   # -UseBasicParsing avoids a
  $json = $resp.Content | ConvertFrom-Json                                             # "NonInteractive mode" error
  $all += $json.value                                                                  # on Windows PowerShell 5.1
  $ct = $resp.Headers["x-ms-continuationtoken"]
  $uri = if ($ct) { "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/testplan/Plans/224095/suites?api-version=7.1&continuationToken=$ct" } else { $null }
}
$all | Where-Object { $_.name -like "*Phase*" -or $_.name -like "*Unit Testing*" -or $_.name -like "*EAII-<number>*" } |
  Select-Object id, name, @{n='parent';e={$_.parentSuite.name}}
```

If `UT_EAII-{number} - {InterfaceName}` already exists, **stop and ask** which to use rather than
creating a duplicate. Otherwise create it under the "Unit Testing" suite id confirmed above:

```powershell
$suiteBody = @{ suiteType = "staticTestSuite"; name = "UT_EAII-{number} - {InterfaceName}"; parentSuite = @{ id = 416102 } } | ConvertTo-Json
$suite = Invoke-RestMethod -Method Post -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/testplan/Plans/224095/suites?api-version=7.1" -Headers $headers -ContentType "application/json" -Body $suiteBody
$suiteId = $suite.id
```

Never create a new Test Plan for this — reuse the existing shared plan every time.

### Step 2 — Create Test Cases from the CSV (flat, one per row, no sub-suites)

**Always read the CSV with explicit UTF-8 encoding** (`Import-Csv -Encoding UTF8`). Without it,
non-ASCII characters already present in this project's CSVs (em dashes, `§` section marks) get
silently corrupted into invalid bytes, which then breaks the JSON body with a generic
`VssPropertyValidationException: You must pass a valid patch document` error — this exact
failure hit 2 of 19 rows on the first EAII-529 run and was fixed by adding `-Encoding UTF8`.

Build the `Microsoft.VSTS.TCM.Steps` field as an ordered (Action, Expected Result) list, not one
combined description — one step for the row's overall setup/outcome, then one step per numbered
item in `ValidationPoints` (each already reads as a checkable assertion):

```powershell
function Esc($s) { if ($null -eq $s) { return "" }; $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;' }

$csv = Import-Csv -Encoding UTF8 "outputs/<InterfaceID>/unit-test-cases.csv"
foreach ($row in $csv) {
  $priority = if ($row.Priority -eq "High") { 1 } else { 2 }
  $items = [regex]::Matches($row.ValidationPoints, '\d+\.\s*(.*?)(?=(\s\d+\.\s)|$)') | ForEach-Object { $_.Groups[1].Value.Trim() }

  $stepId = 2
  $stepsInner = "  <step id=`"$stepId`" type=`"ValidateStep`"><parameterizedString isformatted=`"true`">$(Esc $row.InputDescription)</parameterizedString><parameterizedString isformatted=`"true`">$(Esc $row.ExpectedOutput)</parameterizedString></step>`n"
  $stepId++
  foreach ($it in $items) {
    if ([string]::IsNullOrWhiteSpace($it)) { continue }
    $stepsInner += "  <step id=`"$stepId`" type=`"ValidateStep`"><parameterizedString isformatted=`"true`">Verify</parameterizedString><parameterizedString isformatted=`"true`">$(Esc $it)</parameterizedString></step>`n"
    $stepId++
  }
  $stepsXml = "<steps id=`"0`" last=`"$($stepId-1)`">`n$stepsInner</steps>"

  $patchBody = @(
    @{ op = "add"; path = "/fields/System.Title"; value = $row.ScenarioName },        # NOT prefixed with TC-NNN —
    @{ op = "add"; path = "/fields/Microsoft.VSTS.Common.Priority"; value = $priority }, # match real naming exactly
    @{ op = "add"; path = "/fields/Microsoft.VSTS.TCM.Steps"; value = $stepsXml }
  ) | ConvertTo-Json -Depth 5

  $wi = Invoke-RestMethod -Method Post -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/wit/workitems/`$Test%20Case?api-version=7.1" `
    -Headers $headers -ContentType "application/json-patch+json" -Body $patchBody
  # then Step 3 below with $wi.id
}
```

### Step 3 — Add each Test Case to the Suite

```powershell
$addBody = "[" + (@{ workItem = @{ id = "$($wi.id)" } } | ConvertTo-Json -Depth 5) + "]"
Invoke-RestMethod -Method Post -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/testplan/Plans/224095/Suites/$suiteId/TestCase?api-version=7.1" `
  -Headers $headers -ContentType "application/json" -Body $addBody
```

### Step 4 — Comment on the EAII work item

Find the interface's own "Unit Testing" task (search `System.Title CONTAINS 'EAII-{number}'` via
WIQL — these interfaces have one Task work item per SDLC stage, e.g. `... - Unit Testing`, not
just one parent item) and post a summary comment linking the new suite:

```powershell
$comment = @{ text = "Created ADO Test Suite `"UT_EAII-{number} - {InterfaceName}`" (suite id $suiteId) under Test Plan `"AIS Migration`" (224095) -> Phase 2 -> Unit Testing (416102), with N Test Cases. Suite: https://dev.azure.com/METCASHDevOps/Squad%2020/_testPlans/execute?planId=224095&suiteId=$suiteId" } | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri "https://dev.azure.com/METCASHDevOps/Squad%2020/_apis/wit/workitems/<workItemId>/comments?api-version=7.1-preview.4" -Headers $headers -ContentType "application/json" -Body $comment
```

**After creating everything**, write the created suite id, plan hierarchy, and every
`CSV TestCaseID → ADO work item id` mapping to `outputs/<InterfaceID>/ado-test-case-creation-result.json`
so the mapping survives beyond the session (needed later by `ais-test-results-to-ado`).

See [`code-corpus/unit-tests/index.md`](../../../code-corpus/unit-tests/index.md) in the repo
root for the full real evidence behind this section, including the real `Steps` XML format.

---

## Auth & Tooling Notes

| Fact | Detail |
|---|---|
| MCP auth dependency | `azure-devops-mcp-metcash` uses the local `az login` credential — "✔ Connected" in `claude mcp list` only proves the stdio transport works, not that it can reach `METCASHDevOps` |
| Right tenant check | `az account show` must show a `*.metcash.com` user; if not, `az login --tenant metcash.onmicrosoft.com` |
| REST fallback auth | `az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798` (no PAT needed if `az login` is correct) |
| PAT alternative | Works too (Basic auth, see `azure-local-auth`) — but verify it 401s or not before trusting an existing env var's PAT blindly |
| CSV encoding | Always `Import-Csv -Encoding UTF8` — silent corruption of `—`/`§`/etc. otherwise breaks the ADO API call with an opaque error |
| PowerShell paging | `Invoke-WebRequest` needs `-UseBasicParsing` in this environment (Windows PowerShell 5.1 NonInteractive mode) or it throws immediately |
| Never persist tokens | Don't write `az account get-access-token` output to a file — pass it straight into `$headers` and null the variable after use |

## MCP Servers / Tools Used in This Skill

| Tool | Purpose |
|---|---|
| `azure-devops-mcp-metcash` MCP tools (`testplan_*`, `wit_*`) | Preferred if actually exposed — check once per run, don't wait on it |
| ADO REST API via `az login` AAD bearer token (Step 0–4 above) | Proven fallback; use immediately if MCP tools aren't available, not as a last resort after repeated retries |
| `memory` | Retrieve entity — load interface context (EAII ID, interface name) from session |
