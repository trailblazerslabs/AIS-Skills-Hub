---
name: ais-daily-start
description: |
  Metcash AIS daily start check. USE FOR: the first thing to run at the start of a work session —
  confirms Azure/MCP auth is actually usable (not just "Connected"), and shows git status for
  this skills-hub repo plus every Metcash interface repo already cloned locally. Does NOT clone
  anything new (see code-corpus/initial-setup-checklist.md for one-time setup) and does NOT call
  any MCP server or ADO API — everything is local git + a single az CLI call, by design, to keep
  this fast and free of token/network cost.
  DO NOT USE FOR: cloning a repo for the first time (use code-corpus/initial-setup-checklist.md),
  resolving which repo a specific interface needs (use ais-codegen-readiness).
  Triggers: "daily start", "start of day", "morning check", "what should I continue with",
  "check my repos", "git status all repos", "am I logged in", "daily status".
---

# AIS Daily Start — Auth + Repo Status Check

Run once at the start of a session. Two things only, both fast and local:

1. **Azure auth health** — confirms `az account show` is on the `metcash.onmicrosoft.com`
   tenant. This matters more than it looks: an Azure DevOps/Azure MCP server authenticates via
   whatever tenant `az login` currently holds, and will report "✔ Connected" in `claude mcp
   list`/VS Code's MCP panel **even when it's on the wrong tenant and exposes zero usable
   tools** — see `azure-local-auth` for the full story. Catching this here, before relying on an
   MCP server later in the session, saves a lot of confused debugging.
2. **Git status for every repo already cloned** — this skills-hub repo, plus every
   `Metcash*`/`Metcah.AIS*` repo found under `source/repos/`. Local-only by default (no
   network), so it's instant.

## Why this doesn't use MCP or ADO at all

Two things were deliberately left out after actually testing this with real repos on a real
machine:

- **No MCP calls.** Reading local git state via MCP would mean a round trip per repo, adds
  nothing local `git status`/`git log` can't already tell you, and depends on the exact MCP
  reliability issue this check exists partly to catch.
- **No ADO work-item fetch.** An earlier version of this skill fetched "work items assigned to
  me" from ADO once per day. Dropped — it added real complexity (a cache file, a REST call, a
  once-per-calendar-day rule to reason about) for a feature that turned out not to be worth it
  day-to-day. If you want your assigned work items, ask for that separately
  (`azure-devops-work-items` / a direct ADO query) rather than baking it into every daily check.

## Workflow

1. Run the script directly — this is a normal PowerShell script, not something that needs an
   agent to reimplement step by step:
   ```powershell
   pwsh .github/skills/ais-daily-start/scripts/daily-start.ps1
   ```
   Add `-Fetch` if you actually want live ahead/behind numbers against `origin` (slower — does a
   real `git fetch` per repo, so only use it when you need it, not for a quick check).
2. **Interpret the output, don't just repeat it.** Turn the digest into 2–3 concrete
   observations, e.g.:
   - "Auth is fine, no action needed."
   - "`Metcash.AIS.Data.Metproducts-main` has no upstream on `feature/EAII-529-pe-to-stibo` —
     you haven't pushed this branch yet."
   - "This skills-hub repo has 83 uncommitted files — did you mean to commit before switching
     tasks?"
3. If the auth check fails or shows the wrong tenant, tell the user to run
   `az login --tenant metcash.onmicrosoft.com` and restart MCP servers afterward — don't attempt
   to fix Azure auth on their behalf.
4. If no repos are found under `source/repos/` at all, point to
   [`code-corpus/initial-setup-checklist.md`](../../../code-corpus/initial-setup-checklist.md)
   for the one-time clone step — this skill never clones anything itself.

## Output

Nothing is written to disk — this is a read-only status check, printed straight to the chat
response.

## References

- [azure-local-auth](../azure-local-auth/SKILL.md) — the auth setup and the "Connected but
  broken" MCP gotcha this skill's Step 1 exists to catch early
- [`code-corpus/initial-setup-checklist.md`](../../../code-corpus/initial-setup-checklist.md) —
  the one-time "clone these repos" step this skill deliberately does not do
- [`code-corpus/index.md`](../../../code-corpus/index.md) — the real repo mapping, if you need to
  find which repo a specific interface lives in
