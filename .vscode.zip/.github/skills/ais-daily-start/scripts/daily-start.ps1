<#
.SYNOPSIS
  Metcash AIS daily start check: Azure/MCP auth health + git status for this repo and every
  Metcash interface repo you already have cloned locally.

.DESCRIPTION
  Everything here runs locally (git) or is a single `az account show` call -- it never calls an
  MCP server and never re-clones anything (that's the one-time job of
  code-corpus/initial-setup-checklist.md).

  Two deliberate safety choices, both found by actually running this against a real dev machine:
  1. **Only scans repos matching `Metcash*` / `Metcah.AIS*`** (the real, confirmed misspelling of
     one actual ADO repo -- see code-corpus/index.md) under -ReposRoot. A a broad, unscoped scan
     of an entire source/repos folder picks up every unrelated personal/other-client repo on the
     machine -- a real cross-client information leak, not hypothetical.
  2. **No `git fetch` by default.** Fetching ~20 repos sequentially is slow and, if any one of
     them prompts for credentials, can hang indefinitely -- unacceptable for a live walkthrough.
     Local branch/uncommitted status is instant and doesn't need network access; pass -Fetch to
     opt into fresh ahead/behind numbers when you actually want them.

.PARAMETER ReposRoot
  The folder that contains your repo clones. Defaults to C:\Users\<you>\source\repos.

.PARAMETER Fetch
  Also run `git fetch origin` for each repo before reporting ahead/behind. Slower; only pass
  this when you actually need fresh numbers, not for a quick daily check.

.EXAMPLE
  .\daily-start.ps1
.EXAMPLE
  .\daily-start.ps1 -Fetch
#>
param(
    [string]$ReposRoot = (Join-Path $env:USERPROFILE "source\repos"),
    [switch]$Fetch
)

$ErrorActionPreference = "Continue"
$thisRepoRootRaw = (& git rev-parse --show-toplevel 2>$null)
$thisRepoRoot = if ($thisRepoRootRaw) { (Resolve-Path $thisRepoRootRaw).Path } else { $null }
$today = Get-Date -Format "yyyy-MM-dd"

Write-Output "=================================================================="
Write-Output " METCASH AIS DAILY START -- $today"
Write-Output "=================================================================="

# ---------------------------------------------------------------------------
# 1. Azure auth -- confirms the tenant BEFORE trusting any MCP server's
#    "Connected" status (see azure-local-auth skill: wrong tenant = MCP shows
#    "Connected" but exposes zero usable Azure DevOps/Azure tools).
# ---------------------------------------------------------------------------
Write-Output ""
Write-Output "--- 1. Azure Auth ---"
$accountJson = az account show 2>$null
if ($accountJson) {
    $account = $accountJson | ConvertFrom-Json
    $tenantOk = $account.user.name -like "*@metcash.com"
    Write-Output "Signed in as: $($account.user.name)"
    Write-Output "Subscription: $($account.name)"
    if ($tenantOk) {
        Write-Output "Tenant check: OK"
    } else {
        Write-Output "Tenant check: *** WRONG TENANT *** -- MCP servers will show 'Connected'"
        Write-Output "  but expose no usable tools. Fix: az login --tenant metcash.onmicrosoft.com"
        Write-Output "  then restart MCP servers (Ctrl+Shift+P -> MCP: List Servers -> Restart)."
    }
} else {
    Write-Output "*** NOT LOGGED IN *** -- run: az login --tenant metcash.onmicrosoft.com"
}

# ---------------------------------------------------------------------------
# Helper: print a one-line git digest for a repo path (local-only unless -Fetch)
# ---------------------------------------------------------------------------
function Show-RepoDigest {
    param([string]$Path, [string]$Label)
    Push-Location $Path
    if ($Fetch) { git fetch origin --quiet 2>$null }
    $branch = git rev-parse --abbrev-ref HEAD 2>$null
    $status = git status --porcelain 2>$null
    $statusCount = ($status | Measure-Object).Count
    $upstream = git rev-parse --abbrev-ref "$branch@{upstream}" 2>$null
    $aheadBehind = "no upstream"
    if ($upstream) {
        $ahead = git rev-list --count "$upstream..$branch" 2>$null
        $behind = git rev-list --count "$branch..$upstream" 2>$null
        $aheadBehind = "ahead=$ahead behind=$behind (vs $upstream)"
    }
    Write-Output "$Label [$branch] uncommitted=$statusCount $aheadBehind"
    if ($statusCount -gt 0) {
        $status | Select-Object -First 5 | ForEach-Object { "    $_" }
    }
    Pop-Location
}

# ---------------------------------------------------------------------------
# 2. This repo (the skills hub)
# ---------------------------------------------------------------------------
Write-Output ""
Write-Output "--- 2. This Repo ---"
if ($thisRepoRoot) {
    Show-RepoDigest -Path $thisRepoRoot -Label "Metcash.AIS.Shared.Copilot.Prompts"
} else {
    Write-Output "(not inside a git repo)"
}

# ---------------------------------------------------------------------------
# 3. Metcash interface repos already cloned under -ReposRoot
#    Scoped to Metcash*/Metcah.AIS* by name -- never scans unrelated repos.
# ---------------------------------------------------------------------------
Write-Output ""
Write-Output "--- 3. Metcash Interface Repos Cloned Under $ReposRoot ---"
if (-not $Fetch) { Write-Output "(local-only, no fetch -- pass -Fetch for live ahead/behind numbers)" }
if (Test-Path $ReposRoot) {
    $found = 0
    Get-ChildItem -Path $ReposRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "Metcash*" -or $_.Name -like "Metcah.AIS*" } |
        ForEach-Object {
            $gitDir = Join-Path $_.FullName ".git"
            $fullPath = (Resolve-Path $_.FullName).Path
            if ((Test-Path $gitDir) -and ($fullPath -ne $thisRepoRoot)) {
                $found++
                Show-RepoDigest -Path $_.FullName -Label $_.Name
            }
        }
    if ($found -eq 0) {
        Write-Output "No Metcash repo clones found here yet. See"
        Write-Output "code-corpus/initial-setup-checklist.md for the clone commands."
    }
} else {
    Write-Output "$ReposRoot does not exist yet -- see code-corpus/initial-setup-checklist.md"
}

Write-Output ""
Write-Output "=================================================================="
Write-Output " Done."
Write-Output "=================================================================="
