---
name: ais-code-review
description: |
  Metcash AIS code reviewer. USE FOR: reviewing Logic App Standard workflow JSON, C# .NET 10
  Function App transformation code, and Azure Data Factory pipelines against Metcash AIS
  coding standards, naming conventions, OWASP Top 10 security practices, observability
  requirements (SMC logging), and performance patterns. Produces a structured review report.
  DO NOT USE FOR: generating new code, architecture recommendation, or deployment planning.
  Triggers: "code review", "review my workflow", "review my function", "validate my code",
  "check my logic app", "audit this pipeline", "security review", "review generated code",
  "code review score", "build and unit-test review status".
---

# AIS Code Review

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — confirm the phases you're reviewing are actually marked Done first;
> flag it if this review would run ahead of an incomplete phase. Update Phase 9's row on
> completion.

Review AIS integration code and produce a structured findings report.
Apply all dimensions below. Do not skip any category even if no findings exist.

## Run the calibrated checkers first (they encode what is live in production)

The checkers were calibrated on the code deployed from `main` ([`code-corpus/production-snapshot.md`](../../../code-corpus/production-snapshot.md)); run the one that fits and turn every error into a High finding, every warning into a Medium or Low:

```powershell
python .github\skills\ais-logicapp-codegen\tools\check_logicapp.py  <clone>\<Repo>.Workspace\LogicApp --repo-root <clone>
python .github\skills\ais-functionapp-codegen\tools\check_functionapp.py <clone>
python .github\skills\ais-code-review\tools\check_apiops.py <APIOps clone> <api-folder> [<api-folder>...]
```

Then review the dimensions below by reading the code; the tools do not replace that.

## Required Review Evidence

Before issuing a verdict, record the exact repo, branch, commit SHA, TSD review disposition, and
the production comparison baseline/report where applicable. Include a build review checklist
and the unit-test status for this interface; do not infer either from source inspection.

| Evidence | Record |
|---|---|
| Build/package | Exact command or pipeline, configuration/TFM, pass/fail/not run, warnings/errors, log/run link |
| Unit-test design | `unit-test-cases.csv` present/absent, TSD scenario coverage, intake/readiness approval status |
| Code-level unit tests | Exact command, passed/failed/skipped, TRX/log/run link |
| ADO test cases | Suite/case IDs and creation status, or not created with reason |
| Non-prod execution | Environment and result status, or not run; never infer deployment/runtime coverage from unit tests |

If a required build or applicable unit test has not run, report `NOT RUN` and do not issue PASS.
If the code is intentionally under a local-only evaluation override, say so and do not claim the
normal readiness gate or deployment requirements were met.

## Review Dimensions

### 1. Interface ID and Structure
- [ ] Interface ID matches `EAII-{number}` in all file headers and log messages
- [ ] Outputs are in `outputs/<InterfaceID>/` folder
- [ ] Folder structure matches reference workspace layout
- [ ] No existing reference files were modified

### 2. Naming Conventions
- [ ] Workflow folder name matches interface name
- [ ] Workflow JSON actions use PascalCase with descriptive verbs (`Get_`, `Parse_`, `Send_`, `Log_`)
- [ ] C# namespaces follow `Metcash.AIS.<Domain>.<Interface>` pattern
- [ ] C# class names follow `<InterfaceName>Function`, `<InterfaceName>Transformer` pattern
- [ ] ADF asset names prefix: pipeline `PL_`, dataset `DS_`, linked service `LS_`, trigger `TR_`
- [ ] Connection reference names match existing `connections.json` patterns

### 3. Logic App Workflow Quality
- [ ] Top-level `Try` / `Catch` / `Finally` scopes; `Catch` after `Try` on FAILED and TIMEDOUT; `Finally` always runs and sends the SMC end message through `serviceBusSMC`
- [ ] SMC variables present (`SMCGuid`, `SMCErrors`, `SMCStagesStatus`, `SMCStages` ending in `100`, `SMCCorrelationProperties`, `SMCMessageHeaders`); `StartObservation` through `apiManagementOperationSMC`
- [ ] Every action that can fail has its own failure branch (set error, append to `SMCErrors`, append the failed stage)
- [ ] Retry is explicit on every retry-capable action (`retryPolicy` present, `none` where no retry is intended; an unset policy is a default of 4 retries): none inside synchronous actions; max 2 and interval at least `PT5S` for async calls internal to Azure; no retry on variable init, config fetch or blob write; none on Stibo/PE procedure calls; values match TSD §4.5.1 (use case/connector may justify a different value only if the TSD records it)
- [ ] Worst-case cumulative retry time of the workflow is below the Service Bus PeekLock duration (or the lock is raised in the TSD)
- [ ] Workflow `kind` and trigger settlement match the TSD: stateless with PeekLock, explicit complete and queue retry, or stateful only where SMC resubmission is the recovery path
- [ ] Concurrency matches the TSD: trigger `runtimeConfiguration.concurrency.runs` (max 100) and `maximumWaitingRuns` at the minimum (10); one file/message at a time and the 2-3 s pause where the target locks items; only operations present in the input are invoked
- [ ] Single variable-initialisation / Compose action instead of chains of single-purpose actions; transformation via XSLT where the TSD says so
- [ ] File flows: failed source blob to the error folder then deleted, successful to archive then deleted; `Terminate` only when `HasErrors` and the file was not already moved to error
- [ ] No hardcoded values: environment values via `appsetting()` / `parameters()` (`param*` names), per-environment `AppSettings/`, `Connections/`, `Parameters/` files
- [ ] No inline credentials: built-in service-provider connections with Managed Identity (DB2-style connectors take `@appsetting()` references), secrets are Key Vault references
- [ ] The `prd` app settings never reference a `dv1`/`st1`/`ut1` resource
- [ ] HTTP triggers return `Response` action on both success and failure paths
- [ ] Pagination implemented for actions that may return large result sets
- [ ] `operationOptions: "DisableAsyncPattern"` set where synchronous response is needed

### 4. Function App Code Quality (C# .NET 10)
- [ ] Uses the existing `ProcessingResult` / `IServiceBusFunctionExecutor` — no duplicate envelope or executor, no per-function try/catch around settlement
- [ ] `.NET 10` isolated worker, `Program.cs` composition as in Metproducts / MDMSupplierInfo (not the older Cloudinary style)
- [ ] No synchronous blocking: no `.Result`, `.Wait()`, or `.GetAwaiter().GetResult()`
- [ ] LINQ does not buffer unbounded collections (e.g., `.ToList()` on millions of records)
- [ ] Exception handler logs to SMC with interface ID before rethrowing or returning error
- [ ] Settlement: PeekLock with explicit complete / dead-letter (a Function App cannot be resubmitted from SMC); `maxConcurrentCalls` (host.json / trigger) matches the TSD (1 where the target locks items, DLQ replays included)
- [ ] Every outbound call has an explicit timeout (HttpClient timeout plus the `CancellationToken` passed down); retries match TSD §4.5.1 (none for synchronous, max 2 for async internal, none on Stibo/PE procedure calls); worst-case retry time is below the lock duration
- [ ] Downstream calls to the same item are sequential with the pause the TSD states; only the operations present in the input are called
- [ ] Performance-test evidence (peak or compressed load, ADO card) is attached or its absence is flagged before the CR
- [ ] No new `.csproj` created — reuses existing project file
- [ ] DI registration appended to existing `Program.cs`
- [ ] Unit test class exists in `tests/` folder

### 4b. APIM / APIOps (gen-3)
- [ ] API folder `<domain>-<name>-v<n>` with `apiInformation.json`, `policy.xml`, `specification.yaml`, one `operations/<op>/policy.xml` per operation; version set exists
- [ ] API policy sets `interfaceId` from a `{{...-Interface-Id}}` named value and includes `set-common-inbound-variables_v1`, a payload validation fragment and `validate-jwt_v1`
- [ ] `<on-error>` includes `on-error_v2` (v1 only on legacy APIs); operations set a backend (`set-backend-service backend-id`) that exists in `backends/`
- [ ] Logic App backends use the `<retry>` keyed on the `X-Workflow-Executed` response header
- [ ] Per-environment values (interface ids, backend URLs, secrets) are in `gen-3/tools/parameters/parameters.<env>.yaml`; no hard-coded hosts, keys or tokens in policies

### 5. ADF Pipeline Quality
- [ ] Linked services use Managed Identity — no connection strings with storage keys
- [ ] Datasets are parameterized (no hardcoded container/table/file names)
- [ ] Pipeline has WebActivity log at start and end (SMC endpoint)
- [ ] Failure dependency path defined for error notification
- [ ] Pipeline parameters include `SmcLogEndpoint`

### 6. Security (OWASP Top 10)
- [ ] No hardcoded credentials anywhere (A02 — Cryptographic Failures)
- [ ] HTTP trigger inputs validated before processing (A03 — Injection)
- [ ] All service-to-service calls use Managed Identity (A07 — Authentication Failures)
- [ ] Sensitive data not written to log output (A09 — Security Logging Failures)
- [ ] No dynamic expression injection risk in Logic App expressions

### 7. Observability (SMC)
- [ ] SMC log action present on entry, exit, and error paths in every workflow
- [ ] Error log includes interface ID, correlation ID, and exception message
- [ ] ADF pipeline has WebActivity calling SMC on start, success, and failure

### 8. Unit Test Cases
- [ ] `unit-test-cases.csv` exists in `outputs/<InterfaceID>/`
- [ ] At least 8 test cases across all four categories (happy, error, boundary, business logic)
- [ ] Validation points are specific and checkable

## Output Format

```markdown
# Code Review Report: <InterfaceID>

**Review Date:** <date>
**Reviewer:** GitHub Copilot (ais-code-review skill)
**Repo / Branch / Commit:** <repo> / <branch> / <SHA>
**TSD Review:** <score>/100 — <disposition and report path>
**Production Baseline:** <repo + origin/main SHA + comparison report, or N/A with reason>
**Build Status:** <PASS / FAIL / NOT RUN / N/A with evidence>
**Unit-Test Status:** <CSV coverage; code tests; ADO cases; non-prod execution>
**Verdict:** PASS / PASS WITH FINDINGS / FAIL

---

## Findings

| # | Severity | Dimension | File / Location | Finding | Recommendation |
|---|---|---|---|---|---|
| 1 | Critical / High / Medium / Low | Security | connections.json | Storage key hardcoded in linked service | Replace with Managed Identity |

Severity levels: **High** (blocks approval), **Medium** (must fix before release), **Low** (recommended improvement)
Severity levels: **Critical** (immediate stop), **High** (blocks approval), **Medium** (must fix before release), **Low** (recommended improvement)

## Quality Score

Use `reference-templates/code-review/review-report.template.md`. Record the weighted score by
dimension and cite evidence for every awarded point. Score = awarded applicable points / maximum
applicable points × 100. N/A needs a reason; missing evidence earns zero. Target >= 90%.
Any Critical/High finding, failed checker/build, or applicable required unit tests not passing
blocks PASS regardless of score. Keep the score separate from the verdict.

---

## Category Summary

| Dimension | Status | Finding Count |
|---|---|---|
| Naming Conventions | Pass | 0 |
| Logic App Quality | Pass with findings | 1 |
| Function App Quality | N/A | — |
| ADF Quality | N/A | — |
| Security | Fail | 1 |
| Observability | Pass | 0 |
| Unit Tests | Pass | 0 |

---

## Approved Patterns

[List what was done correctly]
```

## Severity Definitions

| Severity | Definition |
|---|---|
| **Critical** | Active credential exposure, likely severe data loss, or unsafe production mutation; stop and escalate immediately. |
| **High** | Security risk, data loss potential, or blocks correct operation. Must fix before merging. |
| **Medium** | Quality or standards violation that must be resolved before release. |
| **Low** | Improvement recommendation; does not block release. |
