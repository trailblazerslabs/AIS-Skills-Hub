#!/usr/bin/env python3
"""Lint APIOps gen-3 API artefacts against the Squad 20 PRODUCTION pattern.

Calibrated on the `main` branch of Metcash.AIS.APIOps (production publisher runs from main), using the APIs
merged for CHG0065195 on 2026-09-23 (data-mdmsupplier-v1, b2b-iba-directs-upload-v1) and the recent b2b-/data-/
enabling- APIs. See code-corpus/production-snapshot.md and code-corpus/patterns/03-apim-apiops-pattern.md.

Usage:
    python check_apiops.py <APIOps clone or extracted dir> <api-folder> [<api-folder> ...]
    python check_apiops.py <dir> --recent-b2b      # every b2b-/data-/enabling- API (calibration)

Exit code 1 on any error (or warning with --strict).
"""
import argparse
import json
import re
import sys
from pathlib import Path

ENVS = ["dev", "sit", "uat", "prd"]
DOMAINS = ("b2b", "b2c", "data", "enabling", "corporate", "corp", "fin", "finance", "rpa", "iba", "smc", "customer")
REQUIRED_FRAGMENTS = ["set-common-inbound-variables_v1"]
ERROR_FRAGMENTS = ("on-error_v2", "on-error_v1", "on-error-handler", "on-error-marketplace")


def jload(p):
    return json.loads(Path(p).read_text(encoding="utf-8-sig"))


def read(p):
    return Path(p).read_text(encoding="utf-8-sig", errors="replace")


def norm(s):
    """APIM matches {{name}} against the display name; compare ignoring case and separators."""
    return re.sub(r"[^a-z0-9]", "", s.lower())


def check_api(art, name, rep, env_params):
    base = art / "apis" / name
    w = name

    def add(level, rule, msg):
        rep.append((level, rule, w, msg))

    if not base.is_dir():
        add("error", "AP-01", "API folder not found")
        return
    for f in ("apiInformation.json", "policy.xml"):
        if not (base / f).exists():
            add("error", "AP-01", f"missing {f}")
    if not (base / "specification.yaml").exists():
        add("warning", "AP-01", "missing specification.yaml (every recent API has an OpenAPI spec)")
    ops = sorted(p.parent.name for p in (base / "operations").glob("*/policy.xml")) if (base / "operations").exists() else []
    if not ops:
        add("warning", "AP-01", "no operations/<op>/policy.xml (every operation needs its own policy)")
    if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)+-v\d+(-\d+)?|[a-z0-9]+(-[a-z0-9]+)+", name) or name.split("-")[0] not in DOMAINS:
        add("warning", "AP-02", f"API folder `{name}` should be <domain>-<name>-v<n> in lower-case kebab (domain one of {', '.join(DOMAINS[:6])}...)")

    info = {}
    if (base / "apiInformation.json").exists():
        info = jload(base / "apiInformation.json").get("properties", {})
        for k in ("path", "displayName", "apiVersion", "apiVersionSetId", "protocols"):
            if not info.get(k):
                add("error", "AP-02", f"apiInformation.json: `{k}` is empty")
        if info.get("protocols") and info["protocols"] != ["https"]:
            add("error", "AP-02", "apiInformation.json: protocols must be [\"https\"]")
        if info.get("apiVersionSetId"):
            vs = info["apiVersionSetId"].rstrip("/").split("/")[-1]
            if not (art / "version sets" / vs / "versionSetInformation.json").exists():
                add("error", "AP-09", f"version set `{vs}` is not in artifacts/version sets")
        if info.get("subscriptionRequired") is None:
            add("warning", "AP-02", "apiInformation.json: set subscriptionRequired explicitly")

    pol = read(base / "policy.xml") if (base / "policy.xml").exists() else ""
    oppol = {o: read(base / "operations" / o / "policy.xml") for o in ops}
    allp = pol + "\n".join(oppol.values())

    frags = set(re.findall(r'fragment-id="([^"]+)"', allp))
    for fr in REQUIRED_FRAGMENTS:
        if fr not in frags:
            add("error", "AP-03", f"policy must include fragment `{fr}` (sets requestId, SMC and request variables)")
    for fr in frags:
        if not (art / "policy fragments" / fr / "policy.xml").exists():
            add("error", "AP-03", f"fragment `{fr}` does not exist in artifacts/policy fragments")
    if "validate-jwt_v1" not in frags and "validate-jwt" not in allp:
        add("warning", "AP-03", "no validate-jwt_v1 (inbound OAuth 2.0 token validation); required for externally exposed APIs")
    if not any(f in frags for f in ERROR_FRAGMENTS):
        add("warning", "AP-03", "no on-error fragment in <on-error>; use on-error_v2 (the 23 Sep production APIs use v2)")
    elif "on-error_v2" not in frags and not frags & {"on-error-handler", "on-error-marketplace"}:
        add("warning", "AP-03", "uses on-error_v1; new APIs use on-error_v2")
    if not frags & {"validate-json-payload_v1", "validate-xml-payload_v1"} and "validate-content" not in allp:
        add("warning", "AP-03", "no payload validation fragment (validate-json-payload_v1 / validate-xml-payload_v1)")

    # interface id from a named value
    m = re.search(r'name="interfaceId"\s+value="\{\{([^}]+)\}\}"', pol)
    named_dir = art / "named values"
    nv_by_display = {}
    for f in named_dir.glob("*/namedValueInformation.json"):
        try:
            nv_by_display[norm(jload(f)["properties"]["displayName"])] = f.parent.name
            nv_by_display[norm(f.parent.name)] = f.parent.name
        except Exception:  # noqa: BLE001
            pass
    for env, names in env_params.items():  # values that exist only in parameters.<env>.yaml (secrets, URIs)
        for n in names:
            nv_by_display.setdefault(norm(n), n)
    if not m:
        add("warning", "AP-04", "API policy does not set `interfaceId` from a `{{...-Interface-Id}}` named value (SMC InterfaceID)")
    else:
        if not norm(m.group(1)).endswith("interfaceid"):
            add("warning", "AP-04", f"interface id named value `{m.group(1)}` should end with -Interface-Id")
    for ref in sorted(set(re.findall(r"\{\{([^}]+)\}\}", allp))):
        if norm(ref) not in nv_by_display:
            add("error", "AP-04", f"named value `{{{{{ref}}}}}` is referenced but not defined in artifacts/named values")

    # operations: backend + retry
    for o, t in oppol.items():
        be = re.search(r'set-backend-service[^>]*backend-id="([^"]+)"', t)
        if not be and not re.search(r"set-backend-service", t + pol) and not re.search(r"<send-request|<return-response|<mock-response", t + pol):
            add("error", "AP-05", f"operation `{o}` has no set-backend-service (backend-id) and does not call out another way")
        elif not be and not re.search(r"set-backend-service", t + pol):
            add("warning", "AP-05", f"operation `{o}` has no set-backend-service; it calls out with send-request (acceptable for lookups, not for a Logic App/Function backend)")
        if be and not (art / "backends" / be.group(1) / "backendInformation.json").exists():
            add("error", "AP-05", f"operation `{o}`: backend `{be.group(1)}` is not in artifacts/backends")
        if be and "logic" in be.group(1) and "<retry" not in t:
            add("warning", "AP-05", f"operation `{o}` calls a Logic App backend without the <retry> block (X-Workflow-Executed pattern)")

    # no secrets / hard-coded hosts
    for where, t in [("policy.xml", pol)] + [(f"operations/{o}", t) for o, t in oppol.items()]:
        if re.search(r"(subscription-key|Ocp-Apim-Subscription-Key)[^<]{0,40}[A-Fa-f0-9]{24,}", t):
            add("error", "AP-06", f"{where}: hard-coded subscription key")
        if re.search(r'value="Bearer [A-Za-z0-9._-]{20,}', t):
            add("error", "AP-06", f"{where}: hard-coded bearer token")
        for u in re.findall(r'(?:value|base-url|url)="(https?://[^"{@]+)"', t):
            if any(h in u for h in ("azure-api.net", "w3.org", "schemas.", "login.microsoftonline.com", "sts.windows.net")):
                continue
            add("error", "AP-06", f"{where}: hard-coded URL `{u[:70]}`; use a backend or named value")

    # per-environment parameters
    for env, names in env_params.items():
        for ref in sorted(set(re.findall(r'name="interfaceId"\s+value="\{\{([^}]+)\}\}"', pol))):
            slugd = nv_by_display.get(norm(ref))
            if slugd and slugd not in names:
                add("warning", "AP-08", f"interface-id named value `{slugd}` is not listed in parameters.{env}.yaml")


def env_named_values(root):
    out = {}
    for env in ENVS:
        p = root / "tools" / "parameters" / f"parameters.{env}.yaml"
        if p.exists():
            out[env] = set(re.findall(r"^- name: ([a-z0-9-]+)$", p.read_text(encoding="utf-8", errors="replace"), re.M))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("apis", nargs="*")
    ap.add_argument("--recent-b2b", action="store_true")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    root = Path(a.root)
    if (root / "gen-3").exists():
        root = root / "gen-3"
    art = root / "artifacts"
    apis = list(a.apis)
    if a.recent_b2b:
        apis = sorted(p.name for p in (art / "apis").iterdir() if p.is_dir() and p.name.split("-")[0] in ("b2b", "data", "enabling"))
    if not apis:
        sys.exit("give at least one API folder or --recent-b2b")
    rep = []
    params = env_named_values(root)
    for n in apis:
        check_api(art, n, rep, params)
    for lvl, rule, w, msg in rep:
        print(f"{lvl.upper():7} {rule} [{w}] {msg}")
    errs = sum(1 for r in rep if r[0] == "error")
    warns = sum(1 for r in rep if r[0] == "warning")
    print(f"-- {len(apis)} API(s); {errs} error(s), {warns} warning(s)")
    sys.exit(1 if errs or (a.strict and warns) else 0)


if __name__ == "__main__":
    main()
