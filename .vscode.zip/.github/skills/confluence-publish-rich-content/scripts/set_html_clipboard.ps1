<#
.SYNOPSIS
    Loads a fragment of HTML onto the Windows clipboard in correct CF_HTML format,
    UTF-8 safe, for pasting into a browser-based rich-text editor (e.g. Confluence).

.DESCRIPTION
    Two bugs this script exists to avoid:

    1. CF_HTML requires a specific ASCII header (Version/StartHTML/EndHTML/
       StartFragment/EndFragment as fixed-width, zero-padded BYTE offsets) wrapping
       the fragment in <html><body><!--StartFragment-->...<!--EndFragment--></body></html>.
       .NET's [Windows.Forms.Clipboard]::SetText($html, [TextDataFormat]::Html) produces a
       malformed version of this that Chrome's navigator.clipboard.read() reads back as
       EMPTY. You must build the header manually with correct byte-length offsets.

    2. Setting the clipboard via Clipboard.SetData("HTML Format", <string>) round-trips
       the string through the system ANSI codepage internally, silently mangling any
       character outside it (em dashes, curly quotes, accented names) into the Unicode
       replacement character (U+FFFD, shows as a black diamond "?") on the way out.
       This is invisible until you inspect the pasted page text — the source HTML file
       is untouched, only the clipboard write corrupts it. The fix is to write the raw
       UTF-8 BYTES onto the clipboard via a MemoryStream + DataObject, never a .NET string,
       for this custom format.

.PARAMETER FilePath
    Path to a UTF-8 HTML file containing the fragment to paste (e.g. produced by
    `pandoc source.md -t html --embed-resources --standalone -o out.html`). The whole
    file content becomes the pasted fragment — pass the <body> content you want, not a
    full HTML document with things you don't want pasted (title bars, etc.); pandoc's
    --standalone output is fine since Confluence's paste handler only reads the body.

.EXAMPLE
    .\set_html_clipboard.ps1 -FilePath C:\scratch\tsd.html
    # Then in the target page (focused, contenteditable), dispatch a synthetic paste
    # event reading this clipboard content via javascript_tool — see SKILL.md.
#>
param(
    [Parameter(Mandatory=$true)][string]$FilePath
)
Add-Type -AssemblyName System.Windows.Forms

$fragment = [System.IO.File]::ReadAllText($FilePath, [System.Text.Encoding]::UTF8)

$header = "Version:0.9`r`nStartHTML:0000000000`r`nEndHTML:0000000000`r`nStartFragment:0000000000`r`nEndFragment:0000000000`r`n"
$htmlOpen = "<html><body>`r`n<!--StartFragment-->"
$htmlClose = "<!--EndFragment-->`r`n</body></html>"

$enc = [System.Text.Encoding]::UTF8

function ByteLen($s) { return $enc.GetByteCount($s) }

$headerLen = ByteLen($header)
$startHtml = $headerLen
$startFragment = $startHtml + (ByteLen($htmlOpen))
$endFragment = $startFragment + (ByteLen($fragment))
$endHtml = $endFragment + (ByteLen($htmlClose))

$header2 = "Version:0.9`r`nStartHTML:{0:D10}`r`nEndHTML:{1:D10}`r`nStartFragment:{2:D10}`r`nEndFragment:{3:D10}`r`n" -f $startHtml, $endHtml, $startFragment, $endFragment

if ((ByteLen($header2)) -ne $headerLen) {
    Write-Error "Header length mismatch: $((ByteLen($header2))) vs $headerLen"
    exit 1
}

$cfHtml = $header2 + $htmlOpen + $fragment + $htmlClose

# Write raw UTF-8 bytes via MemoryStream — do NOT use Clipboard.SetData(format, [string]),
# it round-trips through the system ANSI codepage and corrupts non-ASCII characters
# (em dashes, curly quotes, etc.) into U+FFFD with no error or warning.
$bytes = $enc.GetBytes($cfHtml)
$ms = New-Object System.IO.MemoryStream
$ms.Write($bytes, 0, $bytes.Length)
$ms.Position = 0

$dataObj = New-Object System.Windows.Forms.DataObject
$dataObj.SetData("HTML Format", $false, $ms)
[System.Windows.Forms.Clipboard]::SetDataObject($dataObj, $true)

Write-Host "Set CF_HTML clipboard (UTF-8 bytes), total length: $($cfHtml.Length), fragment length: $($fragment.Length), byte length: $($bytes.Length)"
