---
name: confluence-publish-rich-content
description: 'Publish or update rich content (headings, tables, code blocks, and embedded
  diagram images) on a Confluence Cloud page via browser automation, when no working
  Confluence MCP/API write path is available. Use when asked to "publish this to
  Confluence", "update the Confluence page with the latest TSD/ADR/doc", or "paste this
  into Confluence" for a markdown document that has more than plain text — i.e. it has
  tables, code blocks, or images. Covers both updating an existing page and creating a
  new page from an existing page as a template ("Make a copy"). Do not use for
  plain-text-only updates (a single paragraph edit) — just edit directly in the browser.'
---

# Publish Rich Content to Confluence (Browser Automation)

Confluence's editor is a ProseMirror-based rich-text surface. The reliable way to get a
locally-generated markdown document (a TSD, an ADR, any structured doc) into it — with
correct tables, headings, code blocks, and diagrams — is a **clipboard-based rich paste**
via browser automation (`claude-in-chrome` tools), not typing/API calls. This skill exists
because two non-obvious bugs will silently corrupt the result if you don't know about them
(see Known Issues below) — read that section before starting.

## When to use this

- Updating an existing Confluence page's body with new/regenerated markdown content
  (e.g. `metcash-tsd-generator`'s Step 2 Q11 "publish to Confluence" answer was yes)
- Creating a new Confluence page that should look like an existing one (ADR pattern,
  TSD pattern) — via "Make a copy" of a template page
- Any case where the content has tables, code blocks, or images — plain single-paragraph
  edits don't need this, just edit directly

## Prerequisites

- `pandoc` (`pandoc --version`) — converts the markdown to self-contained HTML
- Windows PowerShell — runs the clipboard script
- `claude-in-chrome` MCP tools loaded — `browser_batch`, `computer`, `javascript_tool`,
  `read_page`, `file_upload` (load all via one `ToolSearch` call up front, see the
  `claude-in-chrome` tool-loading guidance already in your system prompt)
- The target Confluence page's URL (existing page to update, or a similar page to copy
  as a template for a new one)

## Known Issues (read this before starting — both are silent, no error is raised)

1. **Non-ASCII characters get corrupted through the naive clipboard write.**
   `[Windows.Forms.Clipboard]::SetData("HTML Format", <string>)` round-trips the string
   through the system ANSI codepage internally. Em dashes, curly quotes, and any other
   non-ASCII character silently become the Unicode replacement character (`U+FFFD`,
   renders as a black diamond `�`) in the pasted result — the source file is untouched,
   only the clipboard write corrupts it. **Always use
   [`scripts/set_html_clipboard.ps1`](scripts/set_html_clipboard.ps1)**, which writes raw
   UTF-8 bytes via a `MemoryStream`/`DataObject` instead of a `.NET` string — never
   reimplement this with a plain `SetData(string)` call. After pasting, verify: read the
   clipboard back via `navigator.clipboard.read()` in page JS and count `�` (must be
   0) and a known non-ASCII character your source actually contains (e.g. `—` em
   dash count should match the source file's count) — do this *before* you spend time
   pasting, not after.

2. **Confluence's paste sanitizer strips embedded base64 images entirely — silently.**
   An `<img src="data:image/png;base64,...">` in the pasted HTML fragment (which is what
   `pandoc --embed-resources` produces) does not survive the paste. It isn't converted to
   a broken-image placeholder either — the `<img>` tag is simply removed, leaving only
   any surrounding caption text. This is easy to miss because the paste itself reports
   success and the surrounding text/tables all land correctly. **Every image must be
   inserted separately, after the text paste, using the editor's native upload** — see
   Step 4 below. Do not spend time trying to work around this via different embed
   formats (external URLs won't work either unless already hosted somewhere Confluence
   can fetch, and file:// paths never work in a browser context) — the native upload
   dialog is the only reliable path.

## Step 1: Convert the source markdown to self-contained HTML

```powershell
pandoc "<source>.md" `
  --from=markdown `
  --to=html `
  --embed-resources --standalone `
  -o "<scratch>\content.html"
```

Run from the document's own folder (or pass `--resource-path=.`) so relative image paths
(`images/01.png`) resolve and get embedded as base64. Verify: `grep -c "data:image"
content.html` should match the number of images in the source — these embeds won't
survive the paste (see Known Issue 2), but confirming they're in the HTML at least
proves pandoc resolved every image path correctly, which you'll need again in Step 4.

## Step 2: Load the HTML onto the clipboard (UTF-8 safe)

```powershell
& ".github\skills\confluence-publish-rich-content\scripts\set_html_clipboard.ps1" -FilePath "<scratch>\content.html"
```

Confirm the script's own output line looks sane (`total length`, `fragment length`,
`byte length` all non-zero and proportionate to the source file size). Then verify via
the browser before touching the page (see Known Issue 1's verification step) — this
catches corruption for free, before it costs you a re-paste:

```js
// javascript_tool, on the target tab
const items = await navigator.clipboard.read();
for (const item of items) {
  if (item.types.includes('text/html')) {
    const html = await (await item.getType('text/html')).text();
    const replacementCount = (html.match(/�/g) || []).length; // must be 0
    // compare emdashCount / other known non-ASCII counts against the source file
  }
}
```

## Step 3: Navigate, select the body, and paste

1. Navigate to the target page. For an **existing page**, click `Edit`. For a **new
   page** based on a template, open the closest existing page and use its `...` menu →
   `Make a copy` — more reliable under automation than `Create` / `+Create > Page`,
   which intermittently fail to open (confirmed across repeated attempts in practice).
2. **Select the entire existing body** (skip if the page/section is empty): click
   into the first line of body content (not the title, not a stray badge/tooltip near
   the byline — clicking those can select the whole page including sidebar chrome
   instead of just the editor), then:
   ```
   Home → ctrl+shift+End → Delete
   ```
   For a long page, `ctrl+shift+End` may not visually confirm the selection reached the
   true end in one screenshot (long pages can need the viewport to actually scroll
   through content for it to register) — scroll through and re-verify the highlighted
   selection spans from just under the title to the true last block before deleting.
   **After deleting, check for a leftover empty single-cell table** — if the selection's
   anchor point happened to be inside a table cell, the delete can leave one empty table
   behind instead of a clean empty paragraph. Its own `...` menu → `Delete` removes it;
   confirm the body is a blank `Press space to Ask Rovo or / to insert elements` state
   before pasting.
3. **Dispatch a synthetic paste** via page-context JS — never type the HTML fragment
   into your own context first, it's both wasteful (large token cost for a big document)
   and unnecessary:
   ```js
   // javascript_tool, on the target tab, with the editor's contenteditable focused
   const items = await navigator.clipboard.read();
   for (const item of items) {
     if (item.types.includes('text/html')) {
       const html = await (await item.getType('text/html')).text();
       const dt = new DataTransfer();
       dt.setData('text/html', html);
       const evt = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
       const target = document.querySelector('[contenteditable="true"]');
       target.focus();
       target.dispatchEvent(evt);
     }
   }
   ```
4. Scroll through the pasted result and sanity-check: heading structure, table
   rendering, no `�` anywhere. If corruption shows up despite Step 2's clean clipboard
   check, the selection/delete/re-paste cycle itself is fine to repeat — just redo Step
   3 from the `Home → ctrl+shift+End → Delete` point, no need to regenerate the HTML.

## Step 4: Insert images individually (mandatory — see Known Issue 2)

Every image in the source is now missing from the pasted page — only its caption text
(if any) survived. For each image, in document order:

1. Locate the image's caption/anchor text in the pasted page (scroll to it — for a long
   document, `get_page_text` on the whole page once is cheaper than repeated scrolling
   guesses, since it lets you read the full section order and plan your scroll targets
   before touching the mouse).
2. Click **on that caption text directly** to place the cursor there, then `End`. If the
   caption renders as a stray hyperlink (Confluence sometimes linkifies the orphaned
   image-alt text) and clicking it doesn't move a text caret (check the toolbar — if it
   still shows the *previous* selection's style/heading level, the click didn't register
   in the editor), click a **nearby plain paragraph** instead, then `End` → `Down` →
   `End` to arrive at the caption line's end without ever clicking the link itself.
3. Open the insert menu: toolbar `+` (rightmost icon in the second toolbar row) → type
   `image` → select **"Image, video, or file"**. This opens a small `File | Link`
   picker dialog with an `Upload` button.
4. **The visible `Upload` button is not the file input** — get the real one:
   ```
   read_page (filter: interactive) → find the newest `tabpanel` in the toolbar/dialog
     region, containing a `button type="button"` labelled Upload
   read_page (ref_id: <that tabpanel's ref>, filter: all) → its sibling `button
     type="file"` is the real input
   ```
5. `file_upload` with the local image path (from the same `images/` folder the source
   markdown references) and that file-input ref.
6. Wait ~2s, screenshot, confirm the image rendered in place (not a broken-image icon).

Repeat for every image, working top-to-bottom through the document so each new `+`
click's resulting dialog is easy to associate with the right caption. **`read_page`'s
`ref_id` is per-call and DOM position can shift between images (sidebar
expand/collapse, dialogs opening/closing change other elements' refs)** — always
re-resolve the file input's ref fresh for each image via a new `read_page` call right
after opening that image's dialog; don't reuse a ref from an earlier image's dialog.

## Step 5: Publish

Click `Update` (existing page) or the equivalent publish action. Confirm the page header
shows `Updated just now` / the new page is live, then spot-check the published (non-edit)
view — not just the editor — for the same things Step 3.4 checked, since some sanitizer
behavior can differ between edit-mode preview and the final rendered page.

## Troubleshooting

- **Browser extension disconnects mid-action** (`Browser extension is not connected`):
  re-run `tabs_context_mcp` to check reconnection, then re-screenshot before assuming the
  action failed — a click that triggers a page navigation/publish can disconnect the
  extension for a moment while the action itself already succeeded. Check the resulting
  page state before retrying the same action (a retried "Update" click on an
  already-updated page is harmless, but don't assume failure without checking first).
- **A `Delete` keypress on a large cross-block selection appears to do nothing**: this
  has been observed when focus silently shifted away from the editor (e.g. after a
  scrollbar drag interaction). Click back into a real text line in the editor, redo the
  `Home → ctrl+shift+End`, and retry `Delete` — don't repeat the same keypress blindly;
  re-establish focus first.
- **`find` (natural-language element search) tool returns a rate-limit error**: fall back
  to `read_page` with `filter: interactive` (and `ref_id` to scope down output on a large
  page) — it doesn't use the same quota and is the primary technique this skill relies on
  for locating file inputs anyway.

## Reference

| File | Contents |
|---|---|
| [scripts/set_html_clipboard.ps1](scripts/set_html_clipboard.ps1) | UTF-8-safe CF_HTML clipboard writer — see Known Issue 1 |
