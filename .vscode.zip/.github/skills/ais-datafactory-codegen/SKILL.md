---
name: ais-datafactory-codegen
description: |
  Metcash AIS Azure Data Factory (ADF) pipeline code generator. USE FOR: generating ADF pipeline
  JSON, dataset definitions, linked service configurations, and trigger definitions for bulk data
  movement, batch processing, and scheduled data integration scenarios. Follows Metcash AIS
  naming conventions and uses Managed Identity for all linked service authentication.
  DO NOT USE FOR: Logic App workflow generation (use ais-logicapp-codegen), real-time event-driven
  integration, or architecture recommendation.
  Triggers: "generate ADF", "data factory pipeline", "ADF pipeline", "data integration pipeline",
  "bulk data movement", "ADF dataset", "linked service", "ADF trigger", "scheduled pipeline".
---

# AIS Azure Data Factory Pipeline Generator

> **⛔ Ways of Working: check `outputs/<InterfaceID>/status.md` first, update it last.** See
> `ais-interface-status` — check what's already generated before starting, update Phase 3's row
> on completion.

Generate ADF pipeline assets for Metcash AIS batch and bulk data integration scenarios.

---

## ⛔ Mandatory Pre-condition — Codegen Readiness

**Do not generate any code until the relevant pre-condition below is met** — which one depends
on whether this interface has a TSD:

| Interface has... | Required artifact | Check | Action if missing |
|---|---|---|---|
| A TSD (`tsd/<InterfaceID>/*.md` exists) | **Approved** `outputs/<InterfaceID>/codegen-readiness-questionnaire.md` | Found and marked approved | **Stop.** Ask the user to run `ais-codegen-readiness` and approve it first — repo and pipeline name must be resolved before any code is written, never guessed. |
| No TSD | **Approved** `outputs/<InterfaceID>/design-intake-questionnaire.md` | Found and marked approved | **Stop.** Ask the user to run `ais-design-intake` and approve it first — never proceed on an unapproved questionnaire. |

> Whichever artifact applies provides the source/target types, NFRs, field mappings, repo, and
> schedule details needed below — do not re-ask for information already captured in it.

### Inline Gap Resolution Before Generation

Review the approved questionnaire, TSD/design evidence, current ADF repo and production pattern
before asking anything. For each codegen-critical fact still missing, ambiguous or conflicting
(for example source/target contract, mapping, schedule, retry behavior or pipeline/resource name),
use `vscode_askQuestions` inline with a proposed answer, evidence/source and impact; allow confirm,
correct, or unknown/keep blocked. Do not ask again for established facts. Record answers and
provenance in the existing readiness/design-intake questionnaire and `assumptions.md`. If an
answer materially changes an approved questionnaire, stop and obtain explicit approval of the
revised questionnaire before writing code. If a critical answer remains unknown, stop generation.

---

## Required Inputs

> Sourced from the Design Intake Questionnaire. If any item is missing from the summary, ask only for that specific gap.

- Interface ID matching `EAII-{number}`
- Source type: Azure Blob Storage / Azure SQL / REST API / Storage Account
- Target type: Azure Blob Storage / Azure SQL / Service Bus / Storage Account
- Transformation requirements (copy-only, mapping, stored procedure, etc.)
- Schedule or trigger type: Tumbling Window / Schedule / Storage Event / Manual

Resolve any missing input using the inline gap process above; do not fill it by inference without
the user's confirmation.

## Output Structure

**Write into the real ADF repo clone resolved by `ais-codegen-readiness`** (local path and
feature branch from the approved questionnaire's §1) — never into `outputs/<InterfaceID>/`.
Leave the change as local, uncommitted edits on that branch; committing/pushing is a separate
step.

**Folder structure, relative to the clone root** — confirmed real (singular, lowercase folder
names, per `Metcash.AIS.B2B.01.Datafactory` and `Metcash.AIS.B2C.Datafactory`, not the plural
`pipelines/`/`datasets/` this section previously said):

```
pipeline/
└── pl_<InterfaceName>.json
dataset/
├── ds_<InterfaceName>_source.json
└── ds_<InterfaceName>_target.json
linkedService/
├── ls_<SourceSystem>.json       ← only if new; reuse existing if present
└── ls_<TargetSystem>.json
trigger/
└── tr_<InterfaceName>.json      ← only if new trigger needed
```

## Pipeline Pattern

**Confirmed against real production pipelines** (`Metcash.AIS.B2B.01.Datafactory`,
`Metcash.AIS.B2C.Datafactory` — see
[`code-corpus/patterns/04-adf-pattern.md`](../../../code-corpus/patterns/04-adf-pattern.md) for
the full evidence). The real SMC pattern is a **variable-accumulator model**, not a two-activity
Log_Start/Log_End pair — matches the same shape used in the real Logic App pattern
(`ais-logicapp-codegen`'s SMC section), just hosted in ADF variables instead of workflow
variables.

### Required pipeline variables (set up before any business logic)

| Variable | Type | Purpose |
|---|---|---|
| `var_smc_guid` | string | Fresh correlation GUID for this run |
| `var_smc_observation_id` | string | Set from the Start-Observation response; falls back to `var_smc_guid` |
| `var_smc_stages` | array | **Static**, set once via `SetVariable` — every stage this pipeline reports, always ending `{"StageID":"100.00","StageName":"Observation Completed"}` |
| `var_smc_stages_status` | array | **Accumulator** — `AppendVariable` one JSON object per activity (success or failure) |
| `var_smc_errors` | array | **Accumulator** — `AppendVariable` from `@activity('<name>').error.message` on each failure |

### Start Observation (near the top of the pipeline)

```json
{
  "name": "act_web_start_observation",
  "type": "WebActivity",
  "typeProperties": {
    "method": "POST",
    "url": { "value": "@pipeline().globalParameters.gp_smc_start_observation_url", "type": "Expression" },
    "connectVia": { "referenceName": "t3aisadfshir", "type": "IntegrationRuntimeReference" },
    "body": {
      "value": "{\n  \"InterfaceID\": \"@{variables('var_interface_id')}\",\n  \"Environment\": \"@{pipeline().globalParameters.gp_environment}\",\n  \"StageName\": \"Start Observation\",\n  \"StageStatus\": \"Success\",\n  \"ObservationID\": \"@{variables('var_smc_guid')}\",\n  \"ParentObservationID\": \"@{pipeline().parameters.p_parent_observation_id}\",\n  \"ResourceName\": \"@{variables('var_pipeline_run_id')}.@{variables('var_data_factory_name')}.@{variables('var_pipeline_name')}\",\n  \"ResourceTriggerName\": \"@{variables('var_trigger_name')}\",\n  \"ResourceType\": \"@{variables('var_data_factory_name')}\",\n  \"ResourceRunID\": \"@{variables('var_pipeline_run_id')}\"\n}",
      "type": "Expression"
    },
    "authentication": { "type": "MSI", "resource": "https://management.azure.com/" }
  }
}
```

`ParentObservationID` propagates a parent pipeline's observation ID into a child — always pass
`pipeline().parameters.p_parent_observation_id` through on any `ExecutePipeline` call.

### Per-stage status append (repeat for every meaningful activity, success and failure branches)

```json
{
  "name": "act_appendvar_smc_stage_status_1_1",
  "type": "AppendVariable",
  "typeProperties": {
    "variableName": "var_smc_stages_status",
    "value": { "value": "@json(concat('{','\"StageName\":\"<Name>\",','\"Description\":\"<what happened>\",','\"Status\":\"Success\",','\"StageID\":\"1.1\"','}'))", "type": "Expression" }
  },
  "continueOnError": true
}
```

On a failure branch, also append to `var_smc_errors` from `@activity('<name>').error.message`
before the corresponding End-Observation call.

### End Observation (one branch per outcome)

```json
{
  "name": "act_web_end_observation",
  "type": "WebActivity",
  "typeProperties": {
    "method": "POST",
    "headers": { "Ocp-Apim-Subscription-Key": { "value": "@variables('var_ocp_apim_subscription_key')", "type": "Expression" } },
    "url": { "value": "@pipeline().globalParameters.gp_smc_observation_point_url", "type": "Expression" },
    "connectVia": { "referenceName": "t3aisadfshir", "type": "IntegrationRuntimeReference" },
    "body": { "value": "@json(concat('{','\"ObservationID\":\"', variables('var_smc_observation_id'), '\",','\"StageName\":\"', variables('var_pipeline_name'), ' Observation Complete\",','\"StageStatus\":\"Success\",','\"IsObservationComplete\": true,','\"SMCStages\":', string(variables('var_smc_stages')), ',','\"LogMessage\":\"', replace(concat('{ \"SMC\": ', string(variables('var_smc_stages_status')), ' }'), '\"', '\\\"'), '\"','}'))", "type": "Expression" },
    "authentication": { "type": "MSI", "resource": "https://management.azure.com/" }
  },
  "continueOnError": true
}
```

`continueOnError: true` on every SMC logging activity — a logging failure must never fail the
actual pipeline.

### Key Vault secrets — direct REST call, not a Key Vault linked service

```json
{
  "type": "WebActivity",
  "typeProperties": {
    "method": "GET",
    "url": { "value": "@concat(pipeline().globalParameters.gp_key_vault_base_url, 'secrets/', pipeline().parameters.p_secret_name, '?api-version=7.4')", "type": "Expression" },
    "connectVia": { "referenceName": "t3aisadfshir", "type": "IntegrationRuntimeReference" },
    "authentication": { "type": "MSI", "resource": "https://vault.azure.net" }
  }
}
```

Parameterize the **secret name**, never the value. Note the different `resource` for Key
Vault (`https://vault.azure.net`) vs. SMC/observation calls (`https://management.azure.com/`).

### Retry-log to Table Storage (for pipelines that support automated retry)

On a failure, and **only when `@not(pipeline().parameters.p_is_retry)`** (don't re-log a retry's
own failure), write a full parameter snapshot to a retry-log table via a raw REST `WebActivity`
(not a Copy/dataset) — `PartitionKey`/pipeline name, `RowKey`/new `guid()`, every pipeline
parameter, `Status: "Failed"`. Auth: `{"type": "MSI", "resource": "https://storage.azure.com/"}`.
See the pattern doc for the full body shape.

### Copy activity (unchanged from the general pattern)

```json
{
  "name": "act_copy_<source>_<sink>",
  "type": "Copy",
  "typeProperties": {
    "source": { "type": "<SourceDatasetType>" },
    "sink": { "type": "<SinkDatasetType>" },
    "enableStaging": false
  },
  "inputs": [{ "referenceName": "ds_<InterfaceName>_Source", "type": "DatasetReference" }],
  "outputs": [{ "referenceName": "ds_<InterfaceName>_Target", "type": "DatasetReference" }]
}
```

### Explicit failure signaling for a chained pipeline

Don't trust an `ExecutePipeline` activity's own ADF status implicitly — check it and raise an
explicit, clearly-coded failure:

```json
{
  "type": "IfCondition",
  "typeProperties": {
    "expression": { "value": "@not(equals(activity('<ExecutePipelineActivityName>').Status, 'Succeeded'))", "type": "Expression" },
    "ifTrueActivities": [{
      "name": "act_fail_<name>", "type": "Fail",
      "typeProperties": {
        "message": { "value": "@concat('<Stage> pipeline failed: ', activity('<ExecutePipelineActivityName>').error.message)", "type": "Expression" },
        "errorCode": "<STAGE>_FAILED"
      }
    }]
  }
}
```

## Linked Service Patterns

### Azure Blob Storage (Managed Identity)
```json
{
  "name": "ls_AzureBlobStorage",
  "properties": {
    "type": "AzureBlobStorage",
    "typeProperties": {
      "serviceEndpoint": "https://<storageaccount>.blob.core.windows.net/",
      "accountKind": "StorageV2",
      "credential": { "referenceName": "<ManagedIdentityCredential>", "type": "CredentialReference" }
    }
  }
}
```

### Azure SQL (Managed Identity)
```json
{
  "name": "ls_AzureSQL_<Database>",
  "properties": {
    "type": "AzureSqlDatabase",
    "typeProperties": {
      "connectionString": "Integrated Security=False;Encrypt=True;Connection Timeout=30;Data Source=<server>.database.windows.net;Initial Catalog=<database>",
      "credential": { "referenceName": "<ManagedIdentityCredential>", "type": "CredentialReference" }
    }
  }
}
```

## Dataset Pattern (Parameterized)

```json
{
  "name": "ds_<InterfaceName>_Source",
  "properties": {
    "linkedServiceName": { "referenceName": "ls_<SourceSystem>", "type": "LinkedServiceReference" },
    "parameters": {
      "containerName": { "type": "string" },
      "fileName": { "type": "string" }
    },
    "type": "DelimitedText",
    "typeProperties": {
      "location": {
        "type": "AzureBlobStorageLocation",
        "container": { "value": "@dataset().containerName", "type": "Expression" },
        "fileName": { "value": "@dataset().fileName", "type": "Expression" }
      },
      "columnDelimiter": ",",
      "firstRowAsHeader": true
    }
  }
}
```

## Coding Rules

- Never use connection strings with keys — always use Managed Identity credentials
  (`authenticationType: "SystemAssignedManagedIdentity"`, `encrypt: "mandatory"`).
- Datasets must be parameterized (container name, file name, table name) — no hardcoded paths.
- Every pipeline must implement the full SMC variable-accumulator pattern (Start Observation →
  per-stage `AppendVariable` → End Observation), not just a start/end log pair — see the
  Pipeline Pattern section above.
- Secrets are fetched via a `WebActivity` GET to Key Vault's REST API
  (`{base}secrets/{name}?api-version=7.4`, MSI resource `https://vault.azure.net`) — never a Key
  Vault linked service/dataset, and never a hardcoded secret value.
- Error handling path must exist: an `IfCondition`/`dependencyConditions: ["Failed"]` branch that
  appends to `var_smc_errors`, logs the failure via End Observation, and — for pipelines that
  support automated retry — writes a parameter snapshot to the retry-log table (guarded by
  `@not(pipeline().parameters.p_is_retry)` so a retry doesn't re-log itself).
- **Naming prefixes are lowercase**, confirmed against real production pipelines: pipelines
  `pl_`, datasets `ds_`, linked services `ls_`, triggers `tr_`, dataflows `df_` — not the
  uppercase `PL_`/`DS_`/`LS_`/`TR_` this section previously said. Activities: `act_<verb>_<what>`
  (e.g. `act_copy_rest_adls`, `act_web_kv_get_secret_username`, `act_setvar_date_folder`).
- Reuse existing linked services when they already cover the target system.
- When chaining pipelines with `ExecutePipeline`, always pass `p_parent_observation_id` through
  for SMC correlation, and check the child's `Status` explicitly with an `IfCondition` + `Fail`
  activity rather than trusting ADF's own success/failure implicitly.

## References

- [`code-corpus/patterns/04-adf-pattern.md`](../../../code-corpus/patterns/04-adf-pattern.md) — full real-code evidence for every pattern above
- [ADF Pipeline Patterns Reference](references/pipeline-patterns.md)
