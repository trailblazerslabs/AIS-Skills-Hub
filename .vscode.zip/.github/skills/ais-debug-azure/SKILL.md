---
name: ais-debug-azure
description: |
  Metcash AIS Azure resource debugger. USE FOR: investigating failures in Logic App workflows,
  Function Apps, Azure Data Factory pipelines, Service Bus queues, and APIM APIs — using Azure
  CLI plus cross-resource Application Insights KQL queries as the primary diagnostic tool. Covers
  log analysis, run history inspection, configuration validation, dead-letter investigation,
  APIM policy/backend tracing, and root cause identification. Produces a structured diagnosis
  report with recommended fixes.
  DO NOT USE FOR: generating new code (use ais-logicapp-codegen), deployment planning
  (use ais-deployment-runbook), or architecture design.
  Triggers: "debug", "investigate failure", "logic app failed", "function app error",
  "ADF pipeline failed", "service bus dead letter", "apim failing", "apim 401/403/5xx",
  "why is it failing", "run history", "diagnose", "troubleshoot", "check logs",
  "application insights", "app insights query", "kql", "production issue".
---

# AIS Debug Azure — Failure Investigation Guide

Systematically diagnose failures in AIS Azure integration resources. Always follow the
investigation order below — do not jump to fixes before understanding the root cause.

---

## Step 0 — ⛔ Mandatory before investigating: tenant login + the right questions

**0.1 Confirm the right tenant is active.** This skill runs entirely on Azure CLI + Application
Insights queries — both authenticate off the local `az login` session. Run `az account show` and
confirm the signed-in user is on `metcash.onmicrosoft.com` before running any command below; if
not, `az login --tenant metcash.onmicrosoft.com` first. See
[`azure-local-auth`](../azure-local-auth/SKILL.md) for the full pattern — the same "Connected but
zero tools" tenant-mismatch trap applies to any MCP server this skill also reaches for (ADO,
Azure SQL).

**0.2 Never guess the Required Inputs below — ask if any are missing.** Debugging on an assumed
resource name, environment, or symptom wastes a cycle and risks pointing the investigation at the
wrong resource entirely (or, worse, PRD when the user meant UAT). If the user's request doesn't
already state all five, stop and ask before running a single CLI command:

| Input | Source | Why it's asked, not guessed |
|---|---|---|
| EAII ID or interface name | User or ADO work item | Resource names are derived from it — a wrong ID debugs the wrong interface |
| Which resource type is failing | Logic App / Function App / ADF pipeline / Service Bus / **APIM** | Each has its own investigation path below — never assume from the symptom alone (e.g. a 401 could be APIM, the backend, or Key Vault) |
| Azure resource name | From Squad 20 naming conventions, or the ADO work item | Confirm rather than derive silently if the interface has more than one candidate resource |
| Environment | dev / sit / uat / prd | **Never default to prod.** If unstated, ask — do not infer from context |
| Failure symptom + evidence | Error message, run ID, correlation ID, timestamp, or screenshot | Determines whether App Insights, run history, or DLQ inspection is the fastest path in |
| Subscription | Metcash Azure subscription | Confirm with `az account show` matches what the user expects before querying |

Only proceed to the Investigation Order once these are answered.

---

## Investigation Order

```
1. Confirm the failing resource and environment (Step 0)
2. Collect run history and error messages
3. Inspect configuration (app settings, connections, parameters, APIM policies)
4. Check dependencies (Service Bus, Storage, Key Vault, SQL, APIM, backend services)
5. Cross-check Application Insights (KQL) for the same time window / correlation ID
6. Validate data (payload content, schema, encoding)
7. Identify root cause
8. Recommend and apply fix
9. Verify fix with a re-run
```

---

## Logic App Workflow Debugging

### Step 1 — Read Run History

Navigate to the Logic App in Azure Portal → **Overview → Runs history**.

Alternatively use Azure CLI:
```powershell
az logic workflow run list `
  --resource-group <rg-name> `
  --workflow-name <logic-app-name> `
  --query "[?status=='Failed']" `
  --output table
```

### Step 2 — Read Failed Run Details

```powershell
az logic workflow run show `
  --resource-group <rg-name> `
  --workflow-name <logic-app-name> `
  --name <run-id>
```

Look for:
- `error.code` — HTTP status or Logic App error code
- `error.message` — human-readable error description
- `startTime` / `endTime` — duration
- Which action failed (`status = "Failed"` in actions output)

### Step 3 — Check Action-Level Failure

```powershell
az logic workflow run action list `
  --resource-group <rg-name> `
  --workflow-name <logic-app-name> `
  --run-name <run-id>
```

Common failure points:
| Action Type | Common Failure | Fix |
|---|---|---|
| HTTP connector | 401/403 | Check Managed Identity RBAC assignment |
| Service Bus connector | 404 / Unauthorised | Check topic/queue name in app settings; verify MSI access |
| Function App call | 500 | Check Function App logs (see below) |
| Key Vault reference | 403 | Check MSI Key Vault access policy |
| Parse JSON | Schema mismatch | Validate incoming payload against expected schema |
| Condition / Switch | Always takes wrong branch | Log payload before condition; verify expression |

### Step 4 — Check App Settings

Verify all required app settings are present with correct values:
```powershell
az logicapp config appsettings list `
  --name <logic-app-name> `
  --resource-group <rg-name>
```

Cross-reference against `parameters.json` keys for the workflow.

---

## Function App Debugging

### Step 1 — Check Application Insights Logs

Use the [Application Insights Debugging](#application-insights-debugging-cross-resource-primary-tool)
section below — Function Apps are almost always instrumented, so this is usually the fastest way
in, especially for a `500 Internal Server Error` where run history alone shows nothing useful.

### Step 2 — Check Function App Live Logs

In Azure Portal → Function App → **Log stream** (near-real-time output).

Or via CLI:
```powershell
az webapp log tail `
  --name <function-app-name> `
  --resource-group <rg-name>
```

### Step 3 — Check Function App Configuration

```powershell
az functionapp config appsettings list `
  --name <function-app-name> `
  --resource-group <rg-name>
```

Look for missing or incorrect values in:
- Service Bus connection strings (should use `__fullyQualifiedNamespace`, not key)
- SMC subscription key (`SMC-Ocp-Apim-Subscription-Key`)
- Any `_Endpoint`, `_QueueName`, `_ContainerName` settings

---

## ADF Pipeline Debugging

### Step 1 — Check Pipeline Run History

```powershell
az datafactory pipeline-run query-by-factory `
  --factory-name <adf-name> `
  --resource-group <rg-name> `
  --last-updated-after "2024-01-01T00:00:00Z" `
  --last-updated-before "2024-12-31T23:59:59Z"
```

In Azure Portal → ADF → **Monitor → Pipeline runs** (visual with activity-level details).

### Step 2 — Read Activity Failure Details

Each activity in the failed run shows:
- `Input` — what was sent to the activity
- `Output` — what came back
- `Error` — error code and message

Common activity failures:
| Activity | Common Failure | Fix |
|---|---|---|
| Copy Activity | Access denied on source/sink | Check Managed Identity RBAC on Storage / SQL |
| Web Activity (SMC log) | 401 / Connection refused | Check SMC endpoint URL and subscription key |
| Lookup / GetMetadata | File not found | Check blob container name and file path in parameters |
| Stored Procedure | SQL execution error | Check SP name, parameters, and DB connectivity |
| ForEach / Until | Timeout | Reduce batch size or increase timeout setting |

### Step 3 — Validate Linked Services

```powershell
az datafactory linked-service show `
  --factory-name <adf-name> `
  --resource-group <rg-name> `
  --name <linked-service-name>
```

Confirm:
- `typeProperties.servicePrincipalId` or MSI config is present (never a connection string with key)
- URL / server / database name is correct for the environment

### Step 4 — Query Azure SQL (UT1 only)

Use **Azure SQL MCP** (`azure-sql-b2b-ut1`) to validate data outcomes:

```sql
-- Check if records were written to the target table
SELECT TOP 100 * FROM [dbo].[<TargetTable>] ORDER BY CreatedDate DESC

-- Check for errors logged by stored procedures
SELECT * FROM [dbo].[ErrorLog] WHERE InterfaceId = '<EAII-ID>' ORDER BY LogDate DESC
```

---

## APIM Debugging

### Step 1 — Confirm the API and Operation

```powershell
az apim api show `
  --resource-group <rg-name> `
  --service-name <apim-instance-name> `
  --api-id <api-id>

az apim api operation list `
  --resource-group <rg-name> `
  --service-name <apim-instance-name> `
  --api-id <api-id> `
  --output table
```

### Step 2 — Check the Backend Configuration

A 5xx from APIM is very often the backend, not APIM itself — confirm what APIM is actually
pointing at before assuming a policy bug:

```powershell
az apim api show `
  --resource-group <rg-name> `
  --service-name <apim-instance-name> `
  --api-id <api-id> `
  --query "serviceUrl"

az apim nv list `
  --resource-group <rg-name> `
  --service-name <apim-instance-name> `
  --query "[?contains(displayName, '<backend-related-name>')]"
```

### Step 3 — Read the Policy XML (inbound/backend/outbound/on-error)

```powershell
az rest --method get `
  --url "https://management.azure.com/subscriptions/<sub-id>/resourceGroups/<rg-name>/providers/Microsoft.ApiManagement/service/<apim-instance-name>/apis/<api-id>/policies/policy?api-version=2022-08-01"
```

Look for: a `set-backend-service` override pointing at the wrong environment, a
`validate-jwt`/`check-header` policy rejecting the caller (401/403), or an `on-error` block that
masks the real backend error behind a generic message — always read `on-error` before trusting
the error APIM actually returned to the caller.

### Step 4 — Cross-Check with Application Insights (Primary Diagnostic Path)

APIM's own CLI surface shows configuration, not request-level detail — for **what actually
happened to a specific call**, go straight to the
[Application Insights Debugging](#application-insights-debugging-cross-resource-primary-tool)
section below and query the `requests`/`dependencies` tables scoped to the APIM's linked App
Insights resource (confirm the link first: **APIM instance → Overview → Application Insights**,
or `az apim api diagnostic list`).

### Common APIM Failure Points

| Symptom | Common Cause | Fix |
|---|---|---|
| `401 Unauthorized` | Missing/expired subscription key, or a `validate-jwt` policy rejecting the token | Check Key Vault secret / token issuer & audience in the policy |
| `403 Forbidden` | IP restriction or product/subscription not authorized for this API | Check APIM product's IP filter and subscription scope |
| `404 Not Found` | Operation URL template doesn't match the caller's path, or API not published to the product | Compare the operation's URL template against the actual request path |
| `5xx from APIM, backend never called` | `on-error` policy short-circuiting, or a `set-backend-service` pointing at a dead/wrong URL | Read the policy XML (Step 3); confirm `serviceUrl` for the environment |
| `5xx, backend was called` | Backend (Logic App / Function App / external system) itself failed | Follow the correlation ID into that resource's own debugging section above |
| Timeout | Backend too slow, or APIM's own timeout policy too aggressive | Check backend response time in App Insights `dependencies`; adjust `forward-request timeout` if genuinely needed |

---

## Service Bus Dead-Letter Debugging

### Step 1 — Check Dead-Letter Queue

```powershell
# List messages in dead-letter sub-queue
az servicebus queue message peek `
  --namespace-name <sb-namespace> `
  --resource-group <rg-name> `
  --queue-name <queue-name>/$deadletterqueue `
  --count 10
```

### Step 2 — Inspect Dead-Letter Reason

Dead-letter reasons:
| Reason | Root Cause | Fix |
|---|---|---|
| `MaxDeliveryCountExceeded` | Logic App kept failing and retrying | Fix the Logic App error; re-process messages |
| `TTLExpiredException` | Message expired before processing | Increase message TTL or fix processing lag |
| `MessageLockLostException` | Lock timeout — processing too slow | Increase lock duration or reduce payload size |
| `SessionLockLost` | Session expired | Check session-enabled queue configuration |

### Step 3 — Reprocess Dead-Letter Messages

After fixing the root cause, move messages from DLQ back to the main queue:
```powershell
# No native CLI command — use Azure Portal Service Bus Explorer
# or write a Function App to move DLQ messages
```

---

## SMC Log Investigation

SMC (System Management Console) logs are the primary observability tool for AIS interfaces.

### Check SMC for Interface Errors

1. Log into SMC Portal (UAT or PRD depending on environment).
2. Search by interface ID (`EAII-{number}`) or by correlation ID from the Logic App run.
3. Look for `Log_Interface_Error` entries with error details.

SMC log fields to check:
- `interfaceId` — should match `EAII-{number}`
- `correlationId` — links Logic App run to SMC entry
- `status` — `Started` / `Succeeded` / `Failed`
- `errorMessage` — root cause message

---

## Application Insights Debugging (Cross-Resource, Primary Tool)

Application Insights is the fastest way into **any** of the four resource types above — Logic
App Standard, Function App, APIM, and ADF (via its linked diagnostics) can all be instrumented
against the same or separate App Insights resource(s). Use this section instead of poking at each
resource's own portal blade one at a time whenever a correlation ID, run ID, or rough timestamp
is available.

### Step 1 — Confirm the linked App Insights resource

```powershell
az monitor app-insights component show `
  --app <app-insights-name> `
  --resource-group <rg-name>
```

If you don't already know which App Insights resource a given Function App / Logic App / APIM
instance is linked to, check its `APPINSIGHTS_INSTRUMENTATIONKEY` / `APPLICATIONINSIGHTS_CONNECTION_STRING`
app setting, or (for APIM) its diagnostic settings — do not guess a name.

### Step 2 — Run a scoped KQL query, not an unbounded one

Always scope by time window and, where known, by correlation ID or operation name — an unbounded
query across a busy resource returns noise, not a root cause.

```powershell
az monitor app-insights query `
  --app <app-insights-name> `
  --resource-group <rg-name> `
  --analytics-query "<KQL — see table below>"
```

| Question | KQL |
|---|---|
| What exceptions happened in the window? | `exceptions \| where timestamp > ago(1h) \| order by timestamp desc \| take 50` |
| What did a specific request/correlation ID do end-to-end? | `union requests, dependencies, exceptions, traces \| where operation_Id == "<correlation-id>" \| order by timestamp asc` |
| Which requests failed, and with what status? | `requests \| where timestamp > ago(1h) and success == false \| project timestamp, name, resultCode, duration, operation_Id \| order by timestamp desc` |
| Did a downstream call (backend, SQL, Service Bus) fail or time out? | `dependencies \| where timestamp > ago(1h) and success == false \| project timestamp, name, target, resultCode, duration, operation_Id` |
| What custom trace/log lines did the code emit for this run? | `traces \| where operation_Id == "<correlation-id>" \| order by timestamp asc \| project timestamp, message, severityLevel` |
| Is this an APIM call — what did APIM log for it? | `requests \| where cloud_RoleName == "<apim-instance-name>" and timestamp > ago(1h) \| order by timestamp desc` |
| Slow but not failing — where's the time going? | `dependencies \| where operation_Id == "<correlation-id>" \| project name, target, duration \| order by duration desc` |

### Step 3 — Follow the correlation ID across resources

`operation_Id` (App Insights) and the Logic App run's own correlation ID / SMC `correlationId`
are usually the same value end-to-end if distributed tracing is wired correctly — use it to walk
from "APIM received the call" → "Logic App/Function ran" → "backend dependency call" → "SMC log
entry" without re-guessing timestamps at each hop. If the ID doesn't carry through cleanly, note
that as a finding itself (missing correlation propagation is a real, fixable gap, not just an
inconvenience for this investigation).

### Step 4 — Say so if App Insights has nothing

A resource with `APPLICATIONINSIGHTS_CONNECTION_STRING` unset, or sampling configured aggressively
enough that the specific request was dropped, will return empty results — treat an empty result
as a genuine finding ("not instrumented" / "sampled out"), not as proof nothing happened. Fall
back to the resource's own run history / log stream in that case.

---

## Diagnosis Report Template

After investigation, produce a structured report:

```markdown
# Diagnosis Report: <InterfaceID> — <ResourceName>

**Date:** <date>
**Environment:** <env>
**Investigator:** GitHub Copilot (ais-debug-azure skill)

## Symptom
[What was observed — error message, run ID, timestamp]

## Root Cause
[Single clear statement of the root cause]

## Evidence
| # | Evidence | Source |
|---|---|---|
| 1 | [Run ID xxx failed with 403 on Service Bus action] | Logic App run history |
| 2 | [MSI was not assigned ServiceBusDataReceiver role] | Azure Portal RBAC |

## Recommended Fix
[Specific action to resolve the issue]

## Verification Steps
1. Apply fix
2. Trigger a new run with the same payload
3. Confirm run completes with status = Succeeded
4. Confirm SMC log entry shows Succeeded for this run
```

---

## MCP Servers Used in This Skill

| MCP Server | Tool Action | Purpose |
|---|---|---|
| `mcp_azure_devops2_wit_get_work_item` | ADO MCP | Read EAII work item for interface details |
| `mcp_azure_devops2_repo_get_file_content` | ADO MCP | Read workflow.json / app settings to compare with live config |
| `azure-sql-b2b-ut1` | Azure SQL MCP | Query target tables and error logs in UT1 database |
| `memory` | Retrieve entity | Load interface context (EAII ID, resource names) from session |
| `microsoft-docs` | Microsoft Docs MCP | Look up Logic App action error codes or ADF activity error details |

### Azure CLI + Application Insights (Primary Debug Tools)

The Azure CLI (`az`) and Application Insights KQL queries are the primary tools for collecting
diagnostics from Logic Apps, Function Apps, ADF, and APIM. Use them via the terminal before
escalating to Azure Portal. **Authentication is Step 0.1 above** — do not re-derive it here;
see [`azure-local-auth`](../azure-local-auth/SKILL.md) for the full setup if `az account show`
doesn't already show the correct tenant.

---

## Common Error Codes Quick Reference

| Error | Component | Meaning | Fix |
|---|---|---|---|
| `403 Forbidden` | Any | MSI lacks required RBAC role | Add role assignment to the Managed Identity |
| `404 Not Found` | Service Bus / Blob | Resource name mismatch | Check topic/queue/container name in app settings |
| `401 Unauthorized` | APIM / SMC | Missing subscription key or token | Check Key Vault secret value |
| `500 Internal Server Error` | Function App | Unhandled exception in C# code | Check Application Insights exceptions |
| `408 Request Timeout` | Logic App HTTP | Downstream system too slow | Increase timeout or enable async pattern |
| `MaxDeliveryCountExceeded` | Service Bus | Message failed processing repeatedly | Fix root cause; move DLQ messages after fix |
| `InvalidTemplate` | Logic App | Workflow JSON syntax error | Validate workflow.json against Logic App schema |
| `ActivityFailed` | ADF | Activity-level execution failure | Read activity input/output/error in Monitor |
| APIM returns 5xx, backend never actually called | APIM | `on-error` policy or a misconfigured `set-backend-service` | Read the full policy XML (APIM Debugging Step 3) |
| App Insights query returns nothing | Any instrumented resource | Not instrumented, or sampled out | Check `APPLICATIONINSIGHTS_CONNECTION_STRING` app setting and sampling %; fall back to run history/log stream |
