---
description: Daily start check - MCP server status, git status digest, and what to continue with
---

Run today's start-of-day check for this repo:

1. Run `bash .claude/hooks/daily-status.sh` directly (via the Bash tool) and present its digest: current branch, uncommitted changes, commits ahead/behind `main`, and anything committed in the last 24h.
2. Check MCP server connectivity for this project (same servers `/mcp` would show — `azure-devops-mcp-metcash` and the user-scoped `github` server). Flag any that failed to connect or timed out, and note that a failed one can be retried with `/mcp`.
3. Based on the digest, suggest 2-3 concrete next steps to continue from where work left off. Interpret the uncommitted changes and recent commits — don't just repeat the raw git output.

Keep the whole response short and scannable.
