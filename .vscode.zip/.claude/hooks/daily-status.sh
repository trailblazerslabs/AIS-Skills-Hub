#!/usr/bin/env bash
# SessionStart hook: local git status digest ("what's in progress, continue from here")
BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
STATUS=$(git status --porcelain=v1 2>/dev/null)
AHEAD_COUNT=$(git rev-list --count main..HEAD 2>/dev/null)
BEHIND_COUNT=$(git rev-list --count HEAD..main 2>/dev/null)
AHEAD=$(git log main..HEAD --oneline -10 2>/dev/null)
BEHIND=$(git log HEAD..main --oneline -10 2>/dev/null)
RECENT=$(git log --since="24 hours ago" --oneline 2>/dev/null)

H_BRANCH="$BRANCH" H_STATUS="$STATUS" H_AHEAD="$AHEAD" H_BEHIND="$BEHIND" H_RECENT="$RECENT" H_AHEAD_COUNT="$AHEAD_COUNT" H_BEHIND_COUNT="$BEHIND_COUNT" node -e '
const branch = process.env.H_BRANCH || "(unknown)";
const status = (process.env.H_STATUS || "").trim();
const ahead = (process.env.H_AHEAD || "").trim();
const behind = (process.env.H_BEHIND || "").trim();
const recent = (process.env.H_RECENT || "").trim();
const aheadCount = parseInt(process.env.H_AHEAD_COUNT || "0", 10);
const behindCount = parseInt(process.env.H_BEHIND_COUNT || "0", 10);

const lines = [
  `Daily status - Metcash.AIS.Shared.Copilot.Prompts (branch: ${branch})`,
  "",
  "Uncommitted changes:",
  status ? status : "  (clean)",
  "",
  `Commits ahead of main (${aheadCount} total, showing latest 10):`,
  ahead ? ahead : "  (none)",
  "",
  `Commits behind main (${behindCount} total, showing latest 10):`,
  behind ? behind : "  (none)",
  "",
  "Commits in last 24h:",
  recent ? recent : "  (none)"
].join("\n");

console.log(JSON.stringify({
  hookSpecificOutput: { hookEventName: "SessionStart", additionalContext: lines }
}));
' 2>/dev/null || echo '{}'
