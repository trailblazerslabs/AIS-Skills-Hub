<!-- Source: Technical+Specification+-+EAII-374+-+STIBO+to+PE (1).doc -->
<!-- Title: Technical Specification - EAII-374 - STIBO to PE (1) -->

# Technical Specification - EAII-374 - STIBO to PE

**Table of Contents**

- 1 Document Overview
  - 1.1 Background
  - 1.2 Document Purpose
  - 1.3 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope

- 3 Compliance
  - 3.1 Architecture Principles
  - 3.2 Standards, Guidelines and Patterns

- 4 Requirements Overview
  - 4.1 Business Process Requirement and Integration
    - 4.1.1 Process Diagram from FSD
    - 4.1.2 Functional Specification Document

  - 4.2 Technical standard and requirements
  - 4.3 Required Components
  - 4.4 Environmental Requirement

- 5 Integration Overview and Implementation
  - 5.1 EAII-374 - SOH/SOO/TTG Product Information
    - 5.1.1 As-is Process(es)
      - 5.1.1.1 Description of Process(es)
      - 5.1.1.2 Process Flow Diagram

    - 5.1.2 Proposed Process(es)
      - 5.1.2.1 Description of Process(es)
      - 5.1.2.2 Process Flow Diagram
      - 5.1.2.3 Sequence Diagram
      - 5.1.2.4 PlantUML

    - 5.1.3 Coordination
      - 5.1.3.1 Transaction Boundaries
      - 5.1.3.2 State Management

    - 5.1.4 GoAnywhere Requirements
    - 5.1.5 Design Considerations
    - 5.1.6 Service High Level Design
      - 5.1.6.1 Component List
      - 5.1.6.2 Services
      - 5.1.6.3 Audit, Logging & Exceptions
        - 5.1.6.3.1 Logging
        - 5.1.6.3.2 Audit
        - 5.1.6.3.3 Exceptions
        - 5.1.6.3.4 Service consumers
        - 5.1.6.3.5 Service Operations
        - 5.1.6.3.6 Service Provider
        - 5.1.6.3.7 Communications Data Structures
        - 5.1.6.3.8 Input/Output
        - 5.1.6.3.9 Fulfillment Services

    - 5.1.7 SMC Onboarding
      - 5.1.7.1 Integration Onboarding
      - 5.1.7.1 SMC Load Estimations

    - 5.1.8 Monitoring
    - 5.1.9 Reporting
    - 5.1.10 Integration and Testing Requirements
      - 5.1.10.1 Development and Integration Strategy
      - 5.1.10.2 Unit Testing

- 6 Architecture Overview
  - 6.1 Physical Architecture Diagram
  - 6.2 Network Connectivity
  - 6.3 Security
    - 6.3.1 Data Handling and Encryption

  - 6.4 Infrastructure Support
  - 6.5 Infrastructure Requirements

- 7 Communication Overview
  - 7.1 Communication Components

- 8 Data Architecture
  - 8.1 Data Model
  - 8.2 Stored Procedures
  - 8.3 Stored Procedure Triggers
  - 8.4 Database Technical Specification
  - 8.5 Data Retention
    - 8.5.1 Data Retention Procedures
      - 8.5.1.1 Data storage and retention

    - 8.5.2 Data Backup
    - 8.5.3 Data Destruction Procedures
      - 8.5.3.1 Data destruction metrics and timeframes
      - 8.5.3.2 State process for data/system destruction

- 9 Deployment and Monitoring Considerations
  - 9.1 Transition Period
  - 9.2 Deployment Preference
  - 9.3 Deployment Environment Migration

- 10 Disaster Recovery
- 11 Support Documentation
- 12 Limitations and Constraints
- 13 Assumptions
- 14 Reference Documents and Architecture
- 15 TSD Approval Checklist

| **TSD Author** | [Anand Lokhande](https://metcash.atlassian.net/wiki/people/712020:c0f8bd46-f885-44a6-b73a-ff7234ab3c8c?ref=confluence) |
| --- | --- |

| **Document Approver** | **Approver Role** |
| --- | --- |
| Amrik Aujla | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Magesh Parthasarathy | Solution Architect |
| Mohanraj Vengiduswamy | Test Manager |

# 1 Document Overview

## 1.1 Background

This Technical Specification documents the implementation of the EAII-374 Item and Vendor Validation integration on Azure Integration Services (AIS). This integration is being developed to support master data validation flows between STIBO MDM (Master Data Management) and PE (Platform Engine) systems.

The STIBO to PE integration enables real-time validation of item and vendor data. When STIBO MDM requires validation of master data against business rules and constraints maintained in the PE system (IBM AS/400 DB2 database), it sends validation requests via REST API. The integration processes these requests through Azure API Management, orchestrates database operations through Logic App Standard with DB2 connector, and returns validation results synchronously to STIBO.

This integration is critical for maintaining data quality and consistency across enterprise systems by ensuring master data conforms to business rules before propagation to downstream systems.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the **Item and Vendor Validation** service between **STIBO MDM** (source) and **PE (Platform Engine)** (target) via **Azure API Management** and **Logic App Standard**.

## 1.3 Glossary

| **Term** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| APIM | Azure API Management - API gateway and policy enforcement layer |
| AS/400 | IBM midrange computer platform (also known as IBM i) hosting PE database |
| DB2 | IBM Database 2 - relational database management system on AS/400 |
| EAII | Enterprise Application Integration Interface - Metcash interface catalogue identifier |
| JWT | JSON Web Token - compact, URL-safe means of representing claims for OAuth2 |
| Logic App Standard | Azure Logic Apps Standard tier - workflow orchestration service on App Service Plan |
| MDM | Master Data Management - centralized management of enterprise master data |
| OAuth2 | Industry-standard protocol for authorization |
| PE | Platform Engine - enterprise order management and business rules system on IBM AS/400 |
| REST | Representational State Transfer - architectural style for distributed systems |
| STIBO | STIBO MDM - Master Data Management platform managing item, vendor, and customer master data |

# 2 Scope

## 2.1 In Scope

- **Item and Vendor Validation** request processing from STIBO MDM to PE database
- **OAuth2 JWT Token Validation** using APIM `validate-jwt` policy
- **Protocol and Format Handling**: REST/JSON request and response (no SOAP/XML)
- **Request Field Mapping** from STIBO JSON payload to PE database parameters
- **Database Integration** via Logic App Standard DB2 connector:
  - Stored procedure execution
  - SQL query execution
  - Parameter binding and result set handling

- **Response Transformation** from DB2 result sets to JSON response format
- **Synchronous Request-Reply Pattern** with configurable timeouts
- **Audit Logging** (begin, end, warning, error events) via SMC
  - Request correlation tracking with unique transaction ID
  - Business logic event logging

- **TLS/SSL Communication** with DB2 database using built-in DB2 connector
- **Error Handling** with structured JSON error responses
- **Connection Management**:
  - DB2 connection via Logic App connector
  - DB2 credential management via Azure Key Vault
  - Managed Identity authentication between Azure services

- **Request Validation** against JSON schema

## 2.2 Out of Scope

- Master data creation or modification in PE system (validation only)
- Batch processing of validation requests
- Asynchronous validation patterns
- Data synchronization between STIBO and PE
- Historical validation result storage
- Validation result caching (future enhancement)
- PE database schema changes or stored procedure development (assumed existing)
- STIBO MDM internal workflows and business logic
- Alternative authentication mechanisms (only OAuth2 JWT supported)

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- **API-First Design**: All integrations exposed as well-defined REST APIs
- **Security by Design**: OAuth2 authentication, TLS encryption
- **Cloud-Native Architecture**: Leverage Azure PaaS services, avoid infrastructure management
- **Observability**: Comprehensive logging, monitoring, and alerting
- **Resilience**: Retry logic, circuit breakers.
- **Scalability**: Auto-scaling capability for variable workloads depending on the requirement (No explicit scaling requirement for the interface since volume is low).
- **Separation of Concerns**: APIM for API gateway, Logic Apps for orchestration, separated by responsibility

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

| **Pattern Name** | **Implementation Description** |
| --- | --- |
| **Azure Logic Apps** | Azure Logic Apps are used to orchestrate the upload and asynchronous processing workflows. The workflows are stateless, modular, and designed around discrete business capabilities, improving maintainability and scalability. |
| **API Management Service** | Azure API Management (APIM) acts as the secure API gateway, exposing the upload REST endpoint to liquor suppliers. APIM provides request authentication, payload validation, policy enforcement, and abstracts the backend implementation from consumers. |
| **Retry and Resilience** | Azure-native retry mechanisms are implemented across Logic Apps, Azure Functions, Event Grid, and Service Bus to handle transient failures. Dead-letter queues are used for messages that cannot be successfully processed after the configured retry attempts. |
| **Logging and Observability** | Application Insights and SMC provide end-to-end monitoring, including request telemetry, dependency tracking, exception logging, transaction tracing, and operational diagnostics. |
| **Security Abstraction** | Security is enforced through Azure API Management using OAuth 2.0 Bearer Token authentication. Secrets, certificates, and application configuration are securely stored in Azure Key Vault and accessed using Managed Identity. |
| **Standardization and Governance** | The solution adheres to Metcash Azure Integration Services standards, including standardized API design, Azure resource naming conventions, consistent error handling, monitoring, and deployment practices. |

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

- Link to refer process diagram from FSD [Functional Specification - EAII-374 - STIBO to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3048767509/Functional+Specification+-+EAII-374+-+STIBO+to+PE#3.1.1.1-Process-Diagram)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-374 - STIBO to PE | [Functional Specification - EAII-374 - STIBO to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3048767509/Functional+Specification+-+EAII-374+-+STIBO+to+PE) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of:**

  - **REST** for web service communication protocol
  - **JSON** for request and response message format
  - **OAuth2 / JWT** for authentication and authorization
  - **TLS 1.2+** for transport security
  - **OpenAPI 3.0** for API specification and documentation
  - **JSON Schema** for request/response validation
  - **DB2** for database connectivity and operations

**Non-Functional Requirements:**

| **Category** | **Requirement** | **Target** |
| --- | --- | --- |
| **Performance** | Response Time (95th percentile) | < 5 seconds |
| **Performance** | Throughput | 100 requests/minute (peak) |
| **Availability** | Uptime SLA | 99.9% (8.76 hours downtime/year) |
| **Reliability** | Success Rate | > 99.5% |
| **Scalability** | Concurrent Requests | 20 concurrent (auto-scale enabled) |
| **Security** | Token Expiry | 60 minutes (configurable) |
| **Security** | TLS Version | TLS 1.2 minimum |

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization.

## 4.3 Required Components

The following components are required for this integration:

- Azure App Service Plan
- Azure Virtual Network
- Azure Key vault
- Azure Application Insights
- Azure Log Analytics workspace
- Azure Logic Apps
- Azure API management service
- Azure Service Bus (SMC endObservation queue)
- IBM AS400 DB2

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DV1)
- System Integration Testing (ST1)
- User Acceptance Test (UT1)
- Production (PRD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).

# 5 Integration Overview and Implementation

## 5.1 EAII-374 - SOH/SOO/TTG Product Information

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

- Refer description documented in FSD [Functional Specification - EAII-374 - STIBO to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3048767509/Functional+Specification+-+EAII-374+-+STIBO+to+PE#1.2-Integration-description)

#### 5.1.1.2 Process Flow Diagram

- Refer diagram in FSD [Functional Specification - EAII-374 - STIBO to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3048767509/Functional+Specification+-+EAII-374+-+STIBO+to+PE#1.2-Integration-description)

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

The EAII-374 integration is a **synchronous, request-reply pattern** that exposes four PE reference-data operations to STIBO MDM through a single Logic App Standard workflow (`MetProductERPServiceOperations`). The process operates as follows:

1. **Request Initiation (STIBO)** STIBO MDM initiates the interaction by issuing an HTTPS POST request to the appropriate operation endpoint (`/item-supplier-changes`, `/vendors/ttgs`, `/vendors/status`, or `/pack-changes/validation`). The request includes an OAuth2 bearer token and a JSON payload containing the operation-specific fields, including a `TrackingID`/correlation identifier used for end-to-end traceability.
2. **Perimeter Security (Application Gateway)** The request first reaches Azure Application Gateway, which terminates TLS, applies WAF inspection, and forwards the validated traffic to APIM. This layer protects the integration from malformed, malicious, or non-HTTPS traffic before it reaches the API layer.
3. **API Management (Gateway & Contract Enforcement)** APIM validates the OAuth2 JWT token, enforces the operation's request schema, and routes the request to the corresponding Logic App HTTP trigger. Requests that fail authentication, authorization, or schema validation are rejected here with a `401`, `403`, or `400` response and never reach the Logic App or PE database.
4. **Workflow Orchestration (Logic App Standard)** Once triggered, the Logic App workflow:
  - Initializes workflow variables (`correlationId`, `startTime`, `operationType`, `responsePayload`).
  - Parses the incoming JSON request and logs an `OperationStarted` event to SMC/Application Insights.
  - Evaluates a **Switch on Operation Type** control to route the request to the matching case (one of the four operations).

5. **Operation Execution (per case)** For the selected operation, the workflow:
  - **Transforms the request** from the STIBO field format into the DB2 parameter format.
  - **Retrieves the DB2 credentials** securely from Azure Key Vault using the Logic App's Managed Identity (no credentials are stored in the workflow definition).
  - **Invokes the PE database** via the DB2 Connector — executing the relevant stored procedure (`MDM0120R`, `MDM0055R`, `MDM0140R`) or querying the table function (`MDM0110Q`)
  - **Transforms the DB2 response** back into the STIBO response contract, echoing request fields and mapping return/status codes.
  - Logs `DB2CallStarted`/`DB2CallCompleted` and operation-level telemetry (duration, success/failure) to SMC.

6. **Response Assembly and Return** The workflow composes the final JSON response, calculates the total operation duration, logs an `OperationCompleted` event with the outcome status, and returns the HTTP response back through APIM and Application Gateway to STIBO. Errors encountered at any stage (validation, connectivity, timeout, or business-rule failure) are captured and returned using the standardized error format, with transient DB2 errors retried using exponential backoff before failing the request.
7. **Observability** Every step of the process emits correlated telemetry (tagged with `interfaceId`, `operationType`, `correlationId`, and `environment`) to SMC, enabling end-to-end tracing of a single request from STIBO through to the PE database and back, as well as alerting on error rate, and DB2 connectivity issues.

In summary, the process design centralizes cross-cutting concerns (security, validation, monitoring, secret management) in Application Gateway, APIM, and the Logic App's shared telemetry/Key Vault integration, while keeping each of the four operations as an isolated, independently maintainable branch within a single orchestrated workflow.

#### 5.1.2.2 Process Flow Diagram

![Process Diagram_v4.png](images/11.png)

#### 5.1.2.3 Sequence Diagram

![Sequence Diagram_v3.png](images/06.png)

#### 5.1.2.4 PlantUML

```
@startuml EAII-374 Sequence Diagram - STIBO to PE Reference Operations (No Mappings)
!theme plain
title EAII-374 - STIBO to PE Reference Operations - Sequence Diagram

skinparam backgroundColor #FEFEFE
skinparam sequenceMessageAlign center
skinparam BoxPadding 10
skinparam ParticipantPadding 20

actor "STIBO MDM" as STIBO
participant "App Gateway\n(TLS/WAF)" as APPGW
participant "API Management\n(OAuth2)" as APIM
participant "Logic App\nStandard \nt3-met-data-metproducts-{env}-ae-logic" as LA
participant "Key Vault" as KV
database "PE Database\n(AS/400 DB2)" as PE
participant "SMC Logging" as SMC

== Item Supplier Change Validation ==

STIBO -> APPGW: POST /item-supplier-changes\nRequest payload
activate APPGW
APPGW -> APIM: Forward with TLS
activate APIM
APIM -> APIM: Authenticate and validate request
APIM -> LA: POST /item-supplier-changes
activate LA

LA -> SMC: Log request received
activate SMC
deactivate SMC
LA -> LA: Prepare request
LA -> KV: Get DB2 credentials
activate KV
KV --> LA: DB2 credentials
deactivate KV
LA -> PE: Call MDM0120R
activate PE
PE --> LA: Result set
deactivate PE
LA -> SMC: Log database call completed
activate SMC
deactivate SMC
LA --> APIM: 200 OK\nResponse payload
deactivate LA
APIM --> APPGW: 200 OK
deactivate APIM
APPGW --> STIBO: 200 OK
deactivate APPGW

== List TTG for Vendor ==

STIBO -> APPGW: POST /vendors/ttgs\nRequest payload
activate APPGW
APPGW -> APIM: Forward with TLS
activate APIM
APIM -> APIM: Authenticate and validate request
APIM -> LA: POST /vendors/ttgs
activate LA

LA -> SMC: Log request received
activate SMC
deactivate SMC
LA -> LA: Prepare request
LA -> KV: Get DB2 credentials
activate KV
KV --> LA: DB2 credentials
deactivate KV
LA -> PE: Execute MDM0110Q query
activate PE
PE --> LA: Query results
deactivate PE
LA -> SMC: Log database query completed
activate SMC
deactivate SMC
LA --> APIM: 200 OK\nResponse payload
deactivate LA
APIM --> APPGW: 200 OK
deactivate APIM
APPGW --> STIBO: 200 OK
deactivate APPGW

== Update Vendor Status ==

STIBO -> APPGW: POST /vendors/status\nRequest payload
activate APPGW
APPGW -> APIM: Forward with TLS
activate APIM
APIM -> APIM: Authenticate and validate request
APIM -> LA: POST /vendors/status
activate LA

LA -> SMC: Log request received
activate SMC
deactivate SMC
LA -> LA: Prepare request
LA -> KV: Get DB2 credentials
activate KV
KV --> LA: DB2 credentials
deactivate KV
LA -> PE: Call MDM0055R
activate PE
PE --> LA: Result set
deactivate PE
LA -> SMC: Log database call completed
activate SMC
deactivate SMC
LA --> APIM: 200 OK\nResponse payload
deactivate LA
APIM --> APPGW: 200 OK
deactivate APIM
APPGW --> STIBO: 200 OK
deactivate APPGW

== Validate Pack Change ==

STIBO -> APPGW: POST /pack-changes/validation\nRequest payload
activate APPGW
APPGW -> APIM: Forward with TLS
activate APIM
APIM -> APIM: Authenticate and validate request
APIM -> LA: POST /pack-changes/validation
activate LA

LA -> SMC: Log request received
activate SMC
deactivate SMC
LA -> LA: Prepare request
LA -> KV: Get DB2 credentials
activate KV
KV --> LA: DB2 credentials
deactivate KV
LA -> PE: Call MDM0140R
activate PE
PE --> LA: Result set
deactivate PE
LA -> SMC: Log database call completed
activate SMC
deactivate SMC
LA --> APIM: 200 OK\nResponse payload
deactivate LA
APIM --> APPGW: 200 OK
deactivate APIM
APPGW --> STIBO: 200 OK
deactivate APPGW

== Invalid Request ==

STIBO -> APPGW: Request with invalid payload
activate APPGW
APPGW -> APIM: Forward request
activate APIM
APIM -> APIM: Authenticate request
APIM -> APIM: Request validation fails
APIM --> APPGW: 400 Bad Request
deactivate APIM
APPGW --> STIBO: 400 Bad Request
deactivate APPGW

@enduml
```

### 5.1.3 Coordination

NA

#### 5.1.3.1 Transaction Boundaries

NA

#### 5.1.3.2 State Management

NA

### 5.1.4 GoAnywhere Requirements

NA.

### 5.1.5 Design Considerations

The following legacy behaviors were identified during analysis of the existing TIBCO implementation and have been deliberately excluded or changed in this AIS design.

- The legacy BWCE proxy uses a `FixedTokenAuth` mechanism where APIM injects a static API key. The AIS implementation removes this pattern entirely and relies solely on APIM's **OAuth 2.0 JWT validation** for inbound authentication.

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| **Interface ID** | **Component** | **Component Type** | **Change Type** | **Repository** |
| --- | --- | --- | --- | --- |
| EAII-374 | Azure API Management<br> <br>`t3-met-core-{env}-ae-apim` | Azure APIM | Existing | NA |
| EAII-374 | Azure Logic App workflow<br> <br>`t3-met-data-metproducts-{env}-ae-logic` | Azure Logic Apps | New | NA |
| EAII-374 | Key Vault<br> <br>`t3data{env}ae1kv01` | Azure Key Vault | Existing | NA |
| EAII-374 | Key Vault<br>`t3enabling{env}ae1kv01` | Azure Key Vault | Existing | NA |
| EAII-374 | DB2<br> <br>DEV:<br> <br>`jdbc:as400://MCSDEV1/IDSCTLP25`<br> <br>ST1:<br> <br>`jdbc:as400://MCSDEV1/IDSCTLP25`<br> <br>UT1<br> <br>`jdbc:as400://MCSDEV1/IDSCTLP22`<br> <br>PRD:<br> <br>`jdbc:as400://PEPRD1/IDSCTLP25` | AS400 DB2 | Existing | NA |

#### 5.1.6.2 Services

The solution comprises the following services:

1. **APIM API** — Exposes the REST endpoint which STIBO can consume
2. **Logic App** — Makes call to DB2 stored procedures

#### 5.1.6.3 *Audit, Logging & Exceptions*

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

1. Interface ID : `EAII-374`
2. All significant events, including successful completions and errors, will be logged in SMC for monitoring and debugging purposes.

| **Sr. No.** | **API Name** | **Description** | **API URL** | **Method** |
| --- | --- | --- | --- | --- |
| 1 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The StartObservation API initiates the monitoring process for a business interface in AIS by creating an observation instance. | `t3-met-{env}-ae-apim/smc/startObservation` | POST |
| 2 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The ObservationPoint API is utilized to update the stage, status and other details of an ongoing observation for a business interface in AIS. | `t3-met-{env}-ae-apim/smc/observationPoint` | POST |

##### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interface are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to [https://metcash.atlassian.net/wiki/x/BQC_dg](https://metcash.atlassian.net/wiki/x/BQC_dg)

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |

##### 5.1.6.3.3 Exceptions

| **Observation Stage** | **Exception Scenario** | **Exception Code** | **Exception Handling** |
| --- | --- | --- | --- |
| Authentication (APIM) | Missing `Authorization` header | `EAII374-001` | Return **HTTP 401 Unauthorized** with error code `UNAUTHORIZED`; do not forward the request to the Logic App or PE; log the authentication failure to SMC. |
| Authentication (APIM) | Missing `Site_Id` header | `EAII374-001` | Return **HTTP 401 Unauthorized** with error code `UNAUTHORIZED`; do not forward the request to the Logic App or PE; log the authentication failure to SMC. |
| Authentication (APIM) | Invalid, malformed, or expired OAuth access token | `EAII374-002` | Return **HTTP 401 Unauthorized** with error code `UNAUTHORIZED`; do not forward the request; log the authentication failure to SMC. |
| Schema Validation (APIM) | Malformed JSON or missing request body | `EAII374-004` | Return **HTTP 400 Bad Request** with error code `INVALID_REQUEST`; do not invoke the Logic App or PE; log the validation failure. |
| Schema Validation (APIM) | A required operation field is missing or null | `EAII374-005` | Return **HTTP 400 Bad Request** with error code `INVALID_REQUEST`; identify the invalid field without echoing the complete payload; do not invoke PE. |
| Schema Validation (APIM) | Field length, data type, UUID format, or supported-value validation fails | `EAII374-006` | Return **HTTP 400 Bad Request** with error code `INVALID_REQUEST`; include safe validation details; do not invoke PE. |
| Request Routing (Logic App) | `X-Operation-Type` is missing or does not match `item-supplier-changes`, `vendors-ttgs`,<br> <br>`vendors-status`,<br> <br>or `pack-changes-validation` | `EAII374-008` | Return **HTTP 400 Bad Request** with error code `INVALID_OPERATION`; record `InvalidOperationType_ERROR` in SMC; do not invoke PE. |
| APIM Backend | Logic App endpoint is unavailable or APIM cannot establish the backend connection | `EAII374-009` | Retry only when the failure is transient and the operation is safe to retry; return **HTTP 503 Service Unavailable** if unavailable after retry; log the backend failure and raise the configured operational alert. |
| APIM Backend | Logic App execution exceeds the APIM backend timeout | `EAII374-010` | Stop waiting for the backend response and return **HTTP 504 Gateway Timeout**; log the timeout with the correlation identifier; avoid duplicate retries for operations that may update PE. |
| Key Vault Access | Logic App cannot retrieve PE credentials because Key Vault is unavailable | `EAII374-011` | Retry transient Key Vault failures according to policy; return **HTTP 503 Service Unavailable** after retries are exhausted; log only the vault operation and error category, never the secret value. |
| Key Vault Access | Logic App Managed Identity is not authorized to read the PE credential | `EAII374-012` | Do not retry an authorization failure; return **HTTP 500 Internal Server Error**; log the access failure and raise an operational alert for RBAC remediation. |
| PE Connectivity | Logic App cannot establish a connection to the PE AS/400 DB2 database | `EAII374-013` | Retry transient connectivity failures according to the configured policy; return **HTTP 502 Bad Gateway** with error code `DB2_CONNECTION` after retries are exhausted; log the failed DB2 stage to SMC. |
| PE Authentication | PE rejects the configured DB2 credentials | `EAII374-014` | Do not repeatedly retry invalid credentials; return **HTTP 502 Bad Gateway** with error code `DB2_CONNECTION`; log the authentication category without credentials and raise an operational alert. |
| PE Authorization | DB2 user is not authorized to execute the required procedure or table function | `EAII374-015` | Return **HTTP 502 Bad Gateway** with error code `DB2_CONNECTION`; log the affected operation and database object; raise an alert for PE access remediation. |
| Item Supplier Change - PE Call | Stored procedure `MDM0120R` is missing, unavailable, or fails with a SQL exception | `EAII374-016` | Return error message received from DB2 and log the failed `DB2Call` stage. |
| List TTG for Vendor - PE Query | Table function `MDM0110Q` is missing, unavailable, or returns a SQL execution error | `EAII374-017` | Return error message received from DB2 and log the failed `DB2Call` stage. |
| Update Vendor Status - PE Call | Stored procedure `MDM0055R` is missing, unavailable, or fails with a SQL exception | `EAII374-018` | Return error message received from DB2 and log the failed `DB2Call` stage. |
| Validate Pack Change - PE Call | Stored procedure `MDM0140R` is missing, unavailable, or fails with a SQL exception | `EAII374-019` | Return error message received from DB2 and log the failed `DB2Call` stage. |
| PE Operation Timeout | A stored procedure or `MDM0110Q` query exceeds the configured database timeout | `EAII374-020` | Retry 3 times only where the operation is safe and the error is transient; after retries are exhausted, return **PE Timeout** with error code `DB2_TIMEOUT`; log the timeout and retry count. |
| Response Transformation (Logic App) | PE output is missing, malformed, or cannot be transformed into the operation response | `EAII374-022` | Return **The exact error that occurred**wrapped in an exception object and log the failed `ResponseTransform` stage and preserve the correlation identifier. |
| Item Supplier Change - Business Result | `MDM0120R` returns a non-zero `XRETN` business return code | `EAII374-023` | Return **HTTP 200 OK** with the non-zero `RETURNCODE`; record the completed transaction and business result in SMC. This is a business outcome, not a transport exception. |
| Update Vendor Status - Business Result | `MDM0055R` returns a non-zero `XRETN` business return code | `EAII374-024` | Return **HTTP 200 OK** with the non-zero `ReturnCode`; record the completed transaction and business result in SMC. Do not retry a business rejection. |
| Validate Pack Change - Business Result | `MDM0140R` returns `XSTAT = "N"` | `EAII374-025` | Return **HTTP 200 OK** with `ItemCheckPassed = "N"`; record the failed validation result in SMC. Do not treat the result as a system exception. |
| List TTG for Vendor - Business Result | `MDM0110Q` returns no matching rows | `EAII374-026` | Return **HTTP 200 OK** with an empty `TTGList`; record successful completion in SMC. No retry or exception response is required. |
| SMC Logging | SMC logging endpoint is unavailable or rejects a log event | `EAII374-027` | Do not expose the logging failure to STIBO when business processing can continue; record the failure in platform diagnostics and retry asynchronously or according to the SMC policy. Business processing must not be duplicated. |
| Global Error Handler (Logic App) | Any unhandled workflow exception | `EAII374-099` | Record `UnexpectedError_ERROR`; return **HTTP 500 Internal Server Error** with error code `INTERNAL_ERROR`, correlation identifier, and timestamp; suppress stack traces and sensitive details; raise the configured operational alert. |

##### 5.1.6.3.4 Service consumers

1. STIBO Systems' STEP - By calling a synchronous REST API.

##### 5.1.6.3.5 Service Operations

| Operation | Protocol | Method | Endpoint | Description |
| --- | --- | --- | --- | --- |
| Item Supplier Change | HTTPS | POST | `/item-supplier-changes` | Validates an item supplier change for a given item number, sub-range, and location. Returns a status code indicating the validation result. |
| List TTGs for Vendor | HTTPS | POST | `/vendors/ttgs` | Queries PE for a list of Trading Terms Group (TTG) attachment values and descriptions associated with a vendor. Returns a multi-row result set. |
| Update Vendor Status | HTTPS | POST | `/vendors/status` | Updates a vendor's status in PE based on vendor number, pillar, and the requested status code. Returns a status code indicating success or failure. |
| Validate Pack Change | HTTPS | POST | `/pack-changes/validation` | Validates whether an item pack change is permitted for a given item number and location. Returns a pass/fail indicator. |

##### 5.1.6.3.6 Service Provider

| **Service / Component** | **Provider** | **Responsibility** |
| --- | --- | --- |
| PE System | AS400 DB2 | Execute stored procedures call from logic app and return response |

##### 5.1.6.3.7 Communications Data Structures

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Sample Files** | **Description** |
| --- | --- | --- | --- | --- | --- |
| STIBO → APIM → Logic App<br> <br>(ItemSupplierRequest) | `{ "TrackingID": "string", "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string" }` | `{ "TrackingID": "string", "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string" }` | [Mapping - EAII-374 - PE Item & Vendor Validation - Stibo to PE - Metcash Azure Platform - Confluence](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3579084808/Mapping+-+EAII-374+-+PE+Item+Vendor+Validation+-+Stibo+to+PE) | `{ "TrackingID": "string", "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string" }` | REST Json call from STIBO to APIM |
| Logic App → PE (DB2)<br> <br>(ItemSupplierRequest) | `{ "TrackingID": "string", "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string" }` | XITMN<br> <br>XITSR<br> <br>XDPTN | Refer above document |  |  |
| PE(DB2) → Logic App<br> <br>(ItemSupplierRequest) | ITEMNUMBER,<br> <br>SUBRANGE<br> <br>LOCATION<br> <br>XRETN | ITEMNUMBER<br> <br>SUBRANGE<br> <br>LOCATION<br> <br>RETURNCODE | Refer above document |  |  |
| Logic App → APIM → STIBO<br> <br>(ItemSupplierRequest) | `{ "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string", "RETURNCODE": "string" }` | `{ "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string", "RETURNCODE": "string" }` | Refer above document | `{ "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string", "RETURNCODE": "string" }` | JSON response |
| STIBO → APIM → Logic App<br> <br>(PackChangeValidation) | `{ "ItemNumber": "string", "Location": "string", "CheckType": "string" }` | `{ "ItemNumber": "string", "Location": "string", "CheckType": "string" }` | [Mapping - EAII-374 - PE Item & Vendor Validation - Stibo to PE - Metcash Azure Platform - Confluence](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3579084808/Mapping+-+EAII-374+-+PE+Item+Vendor+Validation+-+Stibo+to+PE) | `{ "TrackingID": "string", "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string" }` | REST Json call from STIBO to APIM |
| Logic App → PE (DB2)<br> <br>(PackChangeValidation) | `{ "ItemNumber": "string", "Location": "string", "CheckType": "string" }` | XITMN<br> <br>XITSR<br> <br>XDPTN | Refer above document |  |  |
| PE(DB2) → Logic App<br> <br>(PackChangeValidation) | ItemNumber,<br> <br>Location<br> <br>Location<br> <br>XSTAT | ItemNumber<br> <br>Location<br> <br>Location<br> <br>ItemCheckPassed | Refer above document |  |  |
| Logic App → APIM → STIBO<br> <br>(PackChangeValidation) | `{ "ItemNumber": "string", "Location": "string", "CheckType": "string", "ItemCheckPassed": "string" }` | `{ "ItemNumber": "string", "Location": "string", "CheckType": "string", "ItemCheckPassed": "string" }` | Refer above document | `{ "ItemNumber": "string", "Location": "string", "CheckType": "string", "ItemCheckPassed": "string" }` | JSON response |
| STIBO → APIM → Logic App<br> <br>(ListTTGVendor) | `{ "VENDORNUMBER": "string", "ATTACHTYPE": "string", "TrackingID": "string" }` | `{ "VENDORNUMBER": "string", "ATTACHTYPE": "string", "TrackingID": "string" }` | [Mapping - EAII-374 - PE Item & Vendor Validation - Stibo to PE - Metcash Azure Platform - Confluence](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3579084808/Mapping+-+EAII-374+-+PE+Item+Vendor+Validation+-+Stibo+to+PE) | `{ "TrackingID": "string", "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string" }` | REST Json call from STIBO to APIM |
| Logic App → PE (DB2)<br> <br>(ListTTGVendor) | `{ "VENDORNUMBER": "string", "ATTACHTYPE": "string", "TrackingID": "string" }` | VENDORNUMBER<br> <br>ATTACHTYPE | Refer above document |  |  |
| PE(DB2) → Logic App<br> <br>(ListTTGVendor) | VENDORNUMBER,<br> <br>ATTACHTYPE<br> <br>VTDTTNP<br> <br>VTAVTGD | `"VENDORNUMBER": "string", "ATTACHTYPE": "string", "TTGList": [ { "ATTACH_VALUE": "string", "ATTACH_DESCRIPTION": "string" } ]` | Refer above document |  |  |
| Logic App → APIM → STIBO<br> <br>(ListTTGVendor) | `"VENDORNUMBER": "string", "ATTACHTYPE": "string", "TTGList": [ { "ATTACH_VALUE": "string", "ATTACH_DESCRIPTION": "string" } ]` | `"VENDORNUMBER": "string", "ATTACHTYPE": "string", "TTGList": [ { "ATTACH_VALUE": "string", "ATTACH_DESCRIPTION": "string" } ]` | Refer above document | `"VENDORNUMBER": "string", "ATTACHTYPE": "string", "TTGList": [ { "ATTACH_VALUE": "string", "ATTACH_DESCRIPTION": "string" } ]` | JSON response |
| STIBO → APIM → Logic App<br> <br>(UpdateVendorStatus) | `{ "TrackingID": "string", "VendorNumber": "string", "VendorStatus": "string", "Pillar": "string" }` | `{ "TrackingID": "string", "VendorNumber": "string", "VendorStatus": "string", "Pillar": "string" }` | [Mapping - EAII-374 - PE Item & Vendor Validation - Stibo to PE - Metcash Azure Platform - Confluence](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3579084808/Mapping+-+EAII-374+-+PE+Item+Vendor+Validation+-+Stibo+to+PE) | `{ "TrackingID": "string", "ITEMNUMBER": "string", "SUBRANGE": "string", "LOCATION": "string" }` | REST Json call from STIBO to APIM |
| Logic App → PE (DB2)<br> <br>(UpdateVendorStatus) | `{ "TrackingID": "string", "VendorNumber": "string", "VendorStatus": "string", "Pillar": "string" }` | XVNDN<br> <br>XDIVN<br> <br>XARCD | Refer above document |  |  |
| PE(DB2) → Logic App<br> <br>(UpdateVendorStatus) | TrackingID,<br> <br>VendorNumber<br> <br>VendorStatus<br> <br>XRETN | TrackingID<br> <br>VendorNumber<br> <br>VendorStatus<br> <br>ReturnCode | Refer above document |  |  |
| Logic App → APIM → STIBO<br> <br>(UpdateVendorStatus) | `{ "TrackingID": "string", "VendorNumber": "string", "VendorStatus": "string", "ReturnCode": "string" }` | `{ "TrackingID": "string", "VendorNumber": "string", "VendorStatus": "string", "ReturnCode": "string" }` | Refer above document | `{ "TrackingID": "string", "VendorNumber": "string", "VendorStatus": "string", "ReturnCode": "string" }` | JSON response |

For all Interface Filename Conventions and Parameters, please refer to the below:

*Link to the spreadsheet*

##### 5.1.6.3.8 Input/Output

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | POST **/item-supplier-changes** | ![diagram](images/14.png) | - |
| Output | POST **/item-supplier-changes** | ![diagram](images/08.png) | - |
| Input | POST **/vendors/ttgs** | ![diagram](images/07.png) | - |
| Output | POST **/vendors/ttgs** | ![diagram](images/09.png) | - |
| Input | POST **/vendors/status** | ![diagram](images/01.png) | - |
| Output | POST **/vendors/status** | ![diagram](images/13.png) | - |
| Input | POST **/pack-changes/validation** | ![diagram](images/04.png) | - |
| Output | POST **/pack-changes/validation** | ![diagram](images/05.png) | - |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| IBM AS 400 DB2 | `MDM0055R` | ![diagram](images/14.png) | NA |
| IBM AS 400 DB2 | `MDM0110Q` | ![diagram](images/07.png) | NA |
| IBM AS 400 DB2 | `MDM0140R` | ![diagram](images/01.png) | NA |
| IBM AS 400 DB2 | `MDM0120R` | ![diagram](images/04.png) | NA |

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

*Enter the required SMC Integration Onboarding details. The corresponding Business Process and Applications must have already been onboarded to SMC. If not then onboarding details for these must also be provided (refer SMC User Guide in Reference Documents and Architecture below)*

| **Field** | **Value** |
| --- | --- |
| Business Process | MetProducts |
| Source Business Process | STIBO to PE |
| Source Application | STIBO |
| Destination Business Process | MetProductsERP |
| Destination Application | PE |
| Interface ID | EAII-374 |
| Interface Name | PE Item & Vendor Validation |
| Interface Type | Sender |
| Interface DataStore | NA |
| Tags | {} |
| Reference Keys | `CorrelationId` (`RequestId` generated by APIM), `OperationName`, and Unique ID present in payload (APIM operation name) |
| Notification Type | ERROR |
| Notification Email Address | IntegrationSupport@metcash.com |
| Grouping ID | EAII-374 |
| Correlation Properties | `CorrelationId` |
| Reprocessing Required | No |

#### 5.1.7.1 SMC Load Estimations

This section will include corresponding SMC load estimations for this interface, including peak and normal load scenarios.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | NA |
| Average volume | Update Vendor Status: ~10-20/day<br> <br>List TTG For Vendor: ~1,500/day<br> <br>Validate Pack Change: ~10-20/day<br> <br>Item Supplier Change: < 1/month |  |
| Seasonal considerations | NA |  |
| Expected growth | NA |  |
| Message Size | Average request | < 1KB |
| Average response | <1KB |  |
| Max request | NA |  |
| Max response | NA |  |

### 5.1.8 Monitoring

- Standard AIS platform monitoring applies via Azure Application Insights and Log Analytics Workspace.

### 5.1.9 Reporting

NA

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

*Make sure to include scenarios for any known issues to be addressed.*

| **ID** | **Work Item Type** | **Title** | **Step Action** | **Step Expected** |
| --- | --- | --- | --- | --- |
| **TC-001** | Test Case | **Verify EAII-374 API without an authorization token** | Invoke any EAII-374 endpoint without the `Authorization` header. | API returns **401 Unauthorized** with error code `UNAUTHORIZED`. The request is not forwarded to the Logic App or PE. |
| **TC-002** | Test Case | **Verify EAII-374 API with an invalid or expired token** | Invoke any EAII-374 endpoint with a malformed, invalid, or expired Bearer token. | API returns **401 Unauthorized** with error code `UNAUTHORIZED`. The request is not forwarded to the Logic App or PE. |
| **TC-003** | Test Case | **Verify EAII-374 API with insufficient permissions** | Invoke any EAII-374 endpoint with a valid token that does not contain the required role or permission. | API returns **403 Forbidden** with error code `FORBIDDEN`. The request is not forwarded to the Logic App or PE. |
| **TC-004** | Test Case | **Verify EAII-374 API with malformed JSON** | Invoke any EAII-374 endpoint with an authenticated request containing malformed JSON. | API returns **400 Bad Request** with error code `INVALID_REQUEST`. PE is not called. |
| **TC-005** | Test Case | **Verify EAII-374 API without a request body** | Invoke any EAII-374 endpoint with a valid token but no request body. | API returns **400 Bad Request** with error code `INVALID_REQUEST`. PE is not called. |
| **TC-006** | Test Case | **Verify Item Supplier Change with valid data** | Submit `POST /eis/pe/v1/api/item-supplier-changes` with valid `TrackingID`, `ITEMNUMBER`, `SUBRANGE`, and `LOCATION` values for which `MDM0120R` returns success. | API returns **200 OK**. The response contains the expected `ITEMNUMBER`, `SUBRANGE`, `LOCATION`, and `RETURNCODE = "0"`. |
| **TC-007** | Test Case | **Verify Item Supplier Change business validation failure** | Submit a valid Item Supplier Change request for which `MDM0120R` returns a non-zero return code. | API returns **200 OK** with the values returned by PE and a non-zero `RETURNCODE`. The business failure is not converted into a transport error. |
| **TC-008** | Test Case | **Verify Item Supplier Change with a missing required field** | Submit an Item Supplier Change request without `ITEMNUMBER`, `SUBRANGE`, `LOCATION`, or `TrackingID`. Repeat for each required field. | Each request returns **400 Bad Request** with error code `INVALID_REQUEST`. `MDM0120R` is not called. |
| **TC-009** | Test Case | **Verify Item Supplier Change field-length validation** | Submit an Item Supplier Change request with `ITEMNUMBER` longer than 20 characters, `SUBRANGE` longer than 10 characters, or `LOCATION` longer than 10 characters. | Each request returns **400 Bad Request** with error code `INVALID_REQUEST`. `MDM0120R` is not called. |
| **TC-010** | Test Case | **Verify List TTG for Vendor with matching records** | Submit `POST /eis/pe/v1/api/vendors/ttgs` with valid `VENDORNUMBER`, `ATTACHTYPE`, and `TrackingID` values that return multiple records from `MDM0110Q`. | API returns **200 OK**. The response echoes `VENDORNUMBER` and `ATTACHTYPE`, and `TTGList` contains every matching item with `ATTACH_VALUE` and `ATTACH_DESCRIPTION`. |
| **TC-011** | Test Case | **Verify List TTG for Vendor with no matching records** | Submit a valid List TTG for Vendor request for which `MDM0110Q` returns no rows. | API returns **200 OK** with the requested vendor and attachment type and an empty `TTGList` array. |
| **TC-012** | Test Case | **Verify List TTG for Vendor with a missing required field** | Submit a List TTG for Vendor request without `VENDORNUMBER`, `ATTACHTYPE`, or `TrackingID`. Repeat for each required field. | Each request returns **400 Bad Request** with error code `INVALID_REQUEST`. `MDM0110Q` is not queried. |
| **TC-013** | Test Case | **Verify List TTG for Vendor field-length validation** | Submit a request with `VENDORNUMBER` or `ATTACHTYPE` longer than 10 characters. | API returns **400 Bad Request** with error code `INVALID_REQUEST`. `MDM0110Q` is not queried. |
| **TC-014** | Test Case | **Verify Update Vendor Status with ACTIVE status** | Submit `POST /eis/pe/v1/api/vendors/status` with valid `TrackingID`, `VendorNumber`, `VendorStatus = "ACTIVE"`, and `Pillar` values for which `MDM0055R` succeeds. | API returns **200 OK**. The response echoes `TrackingID`, `VendorNumber`, and `VendorStatus`, and contains `ReturnCode = "0"`. |
| **TC-015** | Test Case | **Verify Update Vendor Status with supported status values** | Submit separate valid Update Vendor Status requests using `VendorStatus = "INACTIVE"` and `VendorStatus = "SUSPENDED"`. | Each request invokes `MDM0055R` and returns **200 OK** with the submitted status and the expected PE `ReturnCode`. |
| **TC-016** | Test Case | **Verify Update Vendor Status business failure** | Submit a valid Update Vendor Status request for which `MDM0055R` returns a non-zero return code. | API returns **200 OK** with the echoed request identifiers and a non-zero `ReturnCode`. The business failure is not converted into a transport error. |
| **TC-017** | Test Case | **Verify Update Vendor Status with an unsupported status** | Submit an Update Vendor Status request with a `VendorStatus` value other than `ACTIVE`, `INACTIVE`, or `SUSPENDED`. | API returns **400 Bad Request** with error code `INVALID_REQUEST`. `MDM0055R` is not called. |
| **TC-018** | Test Case | **Verify Update Vendor Status with a missing required field** | Submit an Update Vendor Status request without `TrackingID`, `VendorNumber`, `VendorStatus`, or `Pillar`. Repeat for each required field. | Each request returns **400 Bad Request** with error code `INVALID_REQUEST`. `MDM0055R` is not called. |
| **TC-019** | Test Case | **Verify Validate Pack Change when the check passes** | Submit `POST /eis/pe/v1/api/pack-changes/validation` with valid `ItemNumber`, `Location`, and `CheckType` values for which `MDM0140R` returns `Y`. | API returns **200 OK**. The response echoes `ItemNumber`, `Location`, and `CheckType`, and contains `ItemCheckPassed = "Y"`. |
| **TC-020** | Test Case | **Verify Validate Pack Change when the check fails** | Submit a valid Validate Pack Change request for which `MDM0140R` returns `N`. | API returns **200 OK** with `ItemCheckPassed = "N"`. The failed business check is not converted into a transport error. |
| **TC-021** | Test Case | **Verify Validate Pack Change with a missing required field** | Submit a Validate Pack Change request without `ItemNumber`, `Location`, or `CheckType`. Repeat for each required field. | Each request returns **400 Bad Request** with error code `INVALID_REQUEST`. `MDM0140R` is not called. |
| **TC-022** | Test Case | **Verify Validate Pack Change field-length validation** | Submit a request with `ItemNumber` longer than 20 characters, `Location` longer than 10 characters, or `CheckType` longer than 20 characters. | Each request returns **400 Bad Request** with error code `INVALID_REQUEST`. `MDM0140R` is not called. |
| **TC-023** | Test Case | **Verify API rate limiting** | Send requests from the same authenticated client until the configured APIM rate limit is exceeded. | Requests within the limit are processed. The excess request returns **429 Too Many Requests** with error code `RATE_LIMIT_EXCEEDED` and is not forwarded to the Logic App or PE. |
| **TC-024** | Test Case | **Verify PE database connection failure handling** | Make the PE AS/400 DB2 endpoint unavailable and submit a valid request for each operation. | After the configured transient retry attempts are exhausted, the API returns **502 Bad Gateway** with error code `DB2_CONNECTION` and a structured error response containing correlation and timestamp details. |
| **TC-025** | Test Case | **Verify PE database timeout and retry handling** | Configure the PE operation to exceed the database timeout and submit a valid request. | The integration retries the transient failure up to three times using exponential backoff. If all attempts fail, the API returns **504 Gateway Timeout** with error code `DB2_TIMEOUT`. |
| **TC-026** | Test Case | **Verify unexpected error handling** | Simulate an unhandled Logic App processing exception after APIM validation succeeds. | API returns **500 Internal Server Error** with error code `INTERNAL_ERROR` and a structured error response. No implementation details or credentials are exposed. |
| **TC-027** | Test Case | **Verify request correlation across the integration flow** | Submit a valid request containing a known `TrackingID`, then inspect the Logic App run and SMC records. | The same transaction/correlation identifier is available across APIM, Logic App, PE invocation context where applicable, and SMC logging records. |
| **TC-028** | Test Case | **Verify SMC logging for a successful operation** | Submit a valid request for each EAII-374 operation and inspect SMC after processing completes. | SMC contains the expected request-received, transformation, PE call/query, response-transformation, and completion stages for each transaction, including interface ID `EAII-374`, operation, correlation identifier, status, and timestamps. |
| **TC-029** | Test Case | **Verify SMC logging for a failed operation** | Trigger a schema error, PE connectivity error, and database timeout, then inspect SMC. | Each enabled logging path records the failure with the transaction identifier, failed stage, error status, error code, and timestamp without logging credentials or other secrets. |
| **TC-030** | Test Case | **Verify synchronous end-to-end response flow** | Submit a valid request to each of the four endpoints and observe the complete request-response path. | STIBO receives one synchronous response through Logic App, APIM, and Application Gateway for each request. No asynchronous callback or duplicate response is produced. |
| **TC-031** | Test Case | **Verify SQL exception handling from PE** | For each operation, invoke the PE stored procedure/table function with test data engineered to raise a SQL exception (e.g., data type mismatch or constraint violation) and submit a valid, schema-correct request. | API returns **400 Bad Request** with error code matching the SQL failure (e.g., `DB2_SQL_ERROR`/equivalent) and a structured error response containing correlation and timestamp details. SMC/Application Insights logs record the SQL state and error message without exposing internal SQL statements, stack traces, or connection details. |
| **TC-032** | Test Case | **Verify List TTG for Vendor with a large multi-row result set (>10 entries)** | Submit a valid List TTG for Vendor request for a vendor configured in PE with more than 10 TTG attachment rows returned by `MDM0110Q`. | API returns **200 OK**. `TTGList` contains every row returned by the table function (no truncation or dropped rows), each with the correct `ATTACH_VALUE`/`ATTACH_DESCRIPTION` pairing, confirming correct iteration/accumulation logic over large result sets. |
| **TC-033** | Test Case | **Verify no PE call occurs on authentication/authorization rejection** | Submit requests covering TC-001, TC-002, and TC-003 (missing token, invalid/expired token, insufficient permissions) and inspect Logic App run history and PE-side call logs. | No Logic App run is triggered, and no stored procedure/table function invocation occurs on PE for any of the three rejected requests. |

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![Architecture Diagram_v1.png](images/02.png)

## 6.2 Network Connectivity

![Network Diagram_v4.png](images/12.png)

## 6.3 Security

- API management and OAuth2 to be implemented for all APIs for Authentication/Authorisation.
- Incoming traffic for LogicApps is secured by creating private endpoints.
- LogicApps will be using managed identities to communicate with Azure storage accounts, Azure Service Bus and Azure Key Vaults.
- Deny public access to storage accounts and allow access from specific virtual networks.
- Azure key vault will be used to store all secrets.
- Control access to all Azure services/resources using RBAC.
- All communication between endpoints will be through https.

### 6.3.1 Data Handling and Encryption

**Data Classification**

- EAII-374 processes internal master-data attributes used for item, vendor, supplier, location, and packaging operations.
- Vendor and item identifiers are treated as internal business data. The defined API contracts are not intended to contain personal information, payment data, or authentication credentials.
- If future contract changes introduce personal or regulated data, the classification, logging rules, access controls, and retention requirements must be reassessed before deployment.

**Data in Transit**

- STIBO communicates with Azure Application Gateway and APIM over HTTPS using TLS 1.2 or later.
- Traffic between Application Gateway, APIM, and Logic App Standard is encrypted using HTTPS. The Logic App is accessed through its private endpoint and is not exposed directly to STIBO.
- Logic App outbound traffic to Azure Key Vault, SMC, and monitoring services uses HTTPS with TLS 1.2 or later.
- Connectivity from the Logic App to PE DB2 is routed through the approved VNet-integrated enterprise network path.
- Unencrypted HTTP endpoints and deprecated TLS versions are not permitted.

**Data at Rest**

- Logic App runtime content and supporting Storage Account data are encrypted at rest using Azure platform-managed encryption.
- Secrets held in Azure Key Vault are encrypted at rest by the Key Vault service. Secret values are not stored in workflow definitions, source control, APIM policies, or diagnostic messages.
- Application Insights and associated log storage use Azure service-side encryption at rest.
- Business data stored in PE remains subject to PE/AS400 platform encryption, backup, retention, and access-control standards.

**Processing and Persistence**

- The integration uses a synchronous request-response pattern. Request and response payloads are held only for the duration of workflow processing and are not intentionally persisted by the integration for business use.
- The Logic App does not create a separate master-data store or cache PE responses.
- `TrackingID` or the generated correlation identifier is propagated for traceability.
- APIM schema validation and Logic App processing restrict data to the fields required by the selected operation.

**Logging and Monitoring**

- SMC logging is limited to operational metadata such as interface ID, operation type, correlation identifier, stage, status, timestamp, duration, and sanitized error information.
- Full payload will be logged only when there’s any failure in completing the inteded operation.
- DB2 credentials, Key Vault secret values, OAuth tokens, authorization headers, connection strings, and unrestricted exception details must never be logged.
- Error messages returned to STIBO or written to telemetry must be sanitized and must not expose stack traces, database host details, SQL statements, or internal configuration values.

## 6.4 Infrastructure Support

| **Env** | **Target** | **Endpoint** | **Resource Path** |
| --- | --- | --- | --- |
| DV1 | PE/ AS400 DB2 | [MCSDEV1.metcash.com](http://MCSDEV1.metcash.com) | Schema: IDSCTLP24<br> <br>User Name: MDMUSERP24 |
| ST1 | PE/ AS400 DB2 | [MCSDEV1.metcash.com](http://MCSDEV1.metcash.com) | Schema: IDSCTLP24<br> <br>User Name: MDMUSERP24 |
| UT1 | PE/ AS400 DB2 | [MCSDEV1.metcash.com](http://MCSDEV1.metcash.com) | Schema: IDSCTLP22<br> <br>User Name: MDMUSERP22 |
| PRD | PE/ AS400 DB2 | [PEPRD1.metcash.com](http://PEPRD1.metcash.com) | Schema: IDSLIBPRD <br> User Name: MDMUSERPRD |

## 6.5 Infrastructure Requirements

| **Component** | **Non-Prod Specifications** | **Prod Specifications** | **New / Existing** |
| --- | --- | --- | --- |
| Azure Logic App | ASP(I1V2) | ASP(I2V2) | NEW |
| Key Vault | Standard | Standard | Existing |
| Azure APIM | Developer | Premium | Existing |

**Virtual Network Architecture**

The integration is deployed within the enterprise **Hub-and-Spoke** network architecture. Azure API Management is deployed in the **Hub Virtual Network**, while the Azure Logic App and supporting integration resources are deployed in the **AIS Spoke Virtual Network**. Secure communication between Azure resources and IBM AS/400 is achieved through Virtual Network Integration, Private Endpoints, Network Security Groups (NSGs), Route Tables, and enterprise networking controls.

**App Gateway Details**

| Resource | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| Azure Application Gateway | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| Azure API Management | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- |
| AIS Spoke Virtual Network | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | PRD | t2-met-ais-prd-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Logic App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway and secure routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets: -**

**SENS (Logic App Application Subnet): -**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Logic Apps** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | **t3-met-data-metproducts-dv1-ae-logic** |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | **t3-met-data-metproducts-st1-ae-logic** |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | **t3-met-data-metproducts-ut1-ae-logic** |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | **t3-met-data-metproducts-prd-ae-logic** |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets: -**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**App Gateway: -**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Managed Identity**

The Azure Logic App uses a System-Assigned Managed Identity. The identity is
 automatically created and managed by Azure, and its lifecycle is tied
 exclusively to the Logic App resource. When the Logic App is deleted, the
 identity is automatically deleted with it.

A User-Assigned Managed Identity (Microsoft.ManagedIdentity/userAssignedIdentities)
 was considered but was not selected for this integration. The System-Assigned
 model is preferred here because:

- The identity is used solely by this Logic App and no other resource.
- There is no requirement to share the same identity across multiple Azure resources.

No credentials, client secrets, or certificates are stored within the
 application. All Azure service authentication is performed at runtime via the
 System-Assigned Managed Identity token.

**Identity and Access Control (RBAC)**

The Logic App authenticates to Azure services using Microsoft Entra ID and its Managed Identity. The following Azure RBAC roles are assigned based on the principle of least privilege.

**Complete RBAC Assignments (**`Microsoft.Authorization/roleAssignments`**):**

| Source | Target | Identity | RBAC Role |
| --- | --- | --- | --- |
| `t3-met-data-metproducts-{env}-ae-logic` | `t3data{env}ae1kv01` | System-Assigned Managed Identity | `Key Vault Secrets User` |
| `t3-met-data-metproducts-{env}-ae-logic` | `t3enabling{env}ae1kv01` | System-Assigned Managed Identity | `Key Vault Secrets User` |
| `t3-met-data-metproducts-{env}-ae-logic` | `t2-met-{npr/prd}-ae-sb-001/smc.endobservation.{env}.sbq` | System-Assigned Managed Identity | `Azure Service Bus Data Owner` |
| `t3-met-data-metproducts-{env}-ae-logic` | `t3-met-data-metproducts-{env}-ae-ai` | System-Assigned Managed Identity | Monitoring Metrics Publisher |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

| Private Endpoint Name | Target Resource | Sub-resource | Private Zone | New / Existing |
| --- | --- | --- | --- | --- |
| `t3-met-data-metproducts-{env}-ae-pe-kv` | `t3data{env}ae1kv01` (Azure Key Vault) | `vault` | `privatelink.vaultcore.azure.net`<br> <br>`t3data{env}ae1kv01.vault.azure.net` | Existing |

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Logic App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`

# 7 Communication Overview

## 7.1 Communication Components

![EAII-374-Communication-Components_v2.png](images/15.png)

# 8 Data Architecture

## 8.1 Data Model

NA

## 8.2 Stored Procedures

| **Stored Procedure Name** | **Purpose** | **Explanation** |
| --- | --- | --- |
| `MDM0055R` | UpdateVendorStatus | UpdateVendorStatus |
| `MDM0110Q` | List TTG For Vendor API | List TTG For Vendor API |
| `MDM0140R` | Validate Pack Change API | Validate Pack Change API |
| `MDM0120R` | Item Supplier Change API | Item Supplier Change API |

## 8.3 Stored Procedure Triggers

| **Stored Procedure Name** | **Trigger Name** | **Trigger** |
| --- | --- | --- |
| `MDM0055R` | IBM DB2 built-in Connector in logic app | IBM DB2 built-in Connector in logic app |
| `MDM0110Q` | IBM DB2 built-in Connector in logic app | IBM DB2 built-in Connector in logic app |
| `MDM0140R` | IBM DB2 built-in Connector in logic app | IBM DB2 built-in Connector in logic app |
| `MDM0120R` | IBM DB2 built-in Connector in logic app | IBM DB2 built-in Connector in logic app |

## 8.4 Database Technical Specification

IBM AS400, DB2

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

NA

### 8.5.2 Data Backup

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

NA

#### 8.5.3.2 State process for data/system destruction

NA

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

NA

## 9.2 Deployment Preference

NA

## 9.3 Deployment Environment Migration

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PRD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.

Detailed deployment and rollback procedures for EAII-374 are maintained in the approved **Deployment Runsheets** for each environment.

The runsheets provide the step-by-step execution sequence required to deploy the integration components, validate the deployment, and restore the previous working state if deployment or post-deployment validation fails.

The deployment runsheets include, as applicable:

- Pre-deployment checks and prerequisites;
- Environment-specific configuration updates;
- Post-deployment tests and validation;
- Rollback procedures, including restoration of the previously deployed configuration/version.

# 10 Disaster Recovery

*Capture any specific disaster recovery requirements for the solution here.*

# 11 Support Documentation

![diagram](images/10.png)

![diagram](images/03.png)

# 12 Limitations and Constraints

No limitations are identified which are applicable for services of this interface

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
|  |  |  |  |

# 13 Assumptions

- STIBO will make the minor changes to the exiting API calls they are making because the new API calls are modified to follow REST.

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

# 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/16.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |
