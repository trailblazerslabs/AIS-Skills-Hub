<!-- Source: Technical+Specification+-+EAII-297+-+Metconnect+To+Supplier+MDM+-+Get_Release+Supplier+Number.doc -->
<!-- Title: Technical Specification - EAII-297 - Metconnect To Supplier MDM - Get_Release Supplier Number -->

# Technical Specification - EAII-297 - Metconnect To Supplier MDM - Get/Release Supplier Number

**Table of Contents**

- 1 Document Overview
  - 1.1 Background
  - 1.2 Document Purpose
  - 1.3 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope

- 3 Compliance
  - 3.1 Architecture Principles
  - 3.2 Standards, Guidelines and Patterns

- 4 Requirements Overview
  - 4.1 Business Process Requirement and Integration
    - 4.1.1 Process Diagram from FSD
    - 4.1.2 Functional Specification Document

  - 4.2 Technical standard and requirements
  - 4.3 Required Components
  - 4.4 Environmental Requirement

- 5 Integration Overview and Implementation
  - 5.1 EAII-297 - Metconnect To Supplier MDM - Get/Release Supplier Number
    - 5.1.1 As-is Process(es)
      - 5.1.1.1 Description of Process(es)
      - 5.1.1.2 Process Flow Diagram

    - 5.1.2 Proposed Process(es)
      - 5.1.2.1 Description of Process(es)
      - 5.1.2.2 Process Flow Diagram
      - 5.1.2.3 Sequence Diagram
      - 5.1.2.4 PlantUML

    - 5.1.3 Coordination
      - 5.1.3.1 Transaction Boundaries
      - 5.1.3.2 State Management

    - 5.1.4 GoAnywhere Requirements
    - 5.1.5 Design Considerations
    - 5.1.6 Service High Level Design
      - 5.1.6.1 Component List
      - 5.1.6.2 Services
      - 5.1.6.3 Audit, Logging & Exceptions
        - 5.1.6.3.1 Logging
        - 5.1.6.3.2 Audit
        - 5.1.6.3.3 Exceptions
        - 5.1.6.3.4 Service consumers
        - 5.1.6.3.5 Service Operations
        - 5.1.6.3.6 Service Provider
        - 5.1.6.3.7 Communications Data Structures
        - 5.1.6.3.8 Input/Output
        - 5.1.6.3.9 Fulfillment Services

    - 5.1.7 SMC Onboarding
      - 5.1.7.1 Integration Onboarding
      - 5.1.7.1 SMC Load Estimations

    - 5.1.8 Monitoring
    - 5.1.9 Reporting
    - 5.1.10 Integration and Testing Requirements
      - 5.1.10.1 Development and Integration Strategy
      - 5.1.10.2 Unit Testing

- 6 Architecture Overview
  - 6.1 Physical Architecture Diagram
  - 6.2 Network Connectivity
  - 6.3 Security
    - 6.3.1 Data Handling and Encryption

  - 6.4 Infrastructure Support
  - 6.5 Infrastructure Requirements

- 7 Communication Overview
  - 7.1 Communication Components

- 8 Data Architecture
  - 8.1 Data Model
  - 8.2 Stored Procedures
  - 8.3 Stored Procedure Triggers
  - 8.4 Database Technical Specification
  - 8.5 Data Retention
    - 8.5.1 Data Retention Procedures
      - 8.5.1.1 Data storage and retention

    - 8.5.2 Data Backup
    - 8.5.3 Data Destruction Procedures
      - 8.5.3.1 Data destruction metrics and timeframes
      - 8.5.3.2 State process for data/system destruction

- 9 Deployment and Monitoring Considerations
  - 9.1 Transition Period
  - 9.2 Deployment Preference
  - 9.3 Deployment Environment Migration

- 10 Disaster Recovery
- 11 Support Documentation
- 12 Limitations and Constraints
- 13 Assumptions
- 14 Reference Documents and Architecture
- 15 TSD Approval Checklist

| **TSD Author** | [Raj Duraisamy](https://metcash.atlassian.net/wiki/people/712020:f7f096f2-337c-41f4-85de-01ae39be92f0?ref=confluence) |
| --- | --- |

| **Document Approver** | **Approver Role** |
| --- | --- |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Magesh Parthasarathy | Solution Architect |
| Mohanraj Vengiduswamy | Test Manager |

# 1 Document Overview

## 1.1 Background

Metcash's supplier onboarding process requires each new supplier to be assigned a unique supplier number before they can be registered in Metcash's supplier agreement systems. The **MDM Supplier Number** integration enables Metcash's Salesforce-based supplier portal (MetConnect) to request a new, unique supplier number from the IBM Master Data Management (MDM) system at the point of agreement creation. If an agreement does not proceed, the reserved supplier number can be released back to MDM to prevent exhaustion of the number range.

This integration is being migrated from the legacy Tibco BusinessWorks platform to Azure Integration Services (AIS). The purpose of this document is to describe the technical implementation of the integration on AIS, achieving equivalent behaviour to the legacy Tibco process while addressing the known issue of API key rotation requiring a service restart.

The integration is classified as **RED** in the Metcash Horizon Impact Assessment, as it connects directly to IBM MDM, which is a HIGH-risk Master Data structure. Any deployment requires review and approval by the Horizon Platform Owner and Business Process Owner.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of **EAII-297 — Get/Release MDM Supplier Number** between **Salesforce** and **IBM MDM**.

## 1.3 Glossary

| **Item** | **Description** |
| --- | --- |
| AgreementID | Identifier for a supplier trading agreement, formatted as a Salesforce Record ID or a Metcash-assigned alphanumeric code |
| AIS | Azure Integration Services — the target integration platform for this migration. |
| IBM MDM | IBM Master Data Management system. Metcash's system of record for supplier and trading term master data, including the generation and management of supplier reference numbers. |
| MetConnect | Metcash's supplier portal, built on the Salesforce platform, used by staff to onboard suppliers and manage supplier agreements. |
| Salesforce | The CRM and portal platform underpinning MetConnect. The `SourceSystemID` value in all API requests from MetConnect is `Salesforce`. |
| Supplier Number | A unique 7-digit number assigned by IBM MDM to identify a supplier within Metcash's systems. The format is a 2-digit prefix (`10`) followed by a 5-digit zero-padded sequence number. |
| SuccessString | The result code returned by IBM MDM for the Release operation, derived from MDM's transaction result code |
| TransactionID | A unique identifier for the API call, passed by the caller or generated by the integration layer. Format observed in samples: `{SalesforceRecordID}_{YYYYMMDDHHmmss}` |
| WS-Security | A SOAP security standard used for authenticating calls to IBM MDM via a UsernameToken header. |

# 2 Scope

## 2.1 In Scope

- Reception of REST API requests (JSON) from the Salesforce-based MetConnect supplier portal via Azure API Management.
- OAuth2 Bearer token authentication for all inbound requests, enforced by APIM.
- Translation of Salesforce REST requests into the IBM MDM SOAP service format (JSON to SOAP/XML) within an Azure Logic App.
- Retrieval of a new, unique supplier number from the IBM MDM `getNextSupplierNumber` SOAP operation.
- Formatting of the final supplier number by prepending the configured prefix (`10`) and zero-padding the MDM sequence number to 5 digits.
- Release of a previously reserved supplier number via the IBM MDM `clearReservedSupplierNumbers` SOAP operation.
- Translation of IBM MDM SOAP responses back to the Salesforce REST JSON format.
- Audit logging of all request and response events to the Metcash SMC audit service.
- Return of structured error responses on authentication failure (HTTP 401) or MDM processing errors (Return MDM error codes).

## 2.2 Out of Scope

- Maintenance of supplier contracts, agreements, or trading terms in IBM MDM (the MDM service exposes these operations, but they are not invoked by this integration).
- Searching for supplier contracts or agreements in IBM MDM.
- Retrieval of agreement numbers.
- Any downstream processing once the supplier number is returned to the calling portal (e.g., Salesforce-side storage or further provisioning).
- Bulk or batch supplier number operations.
- Migration of historical audit or transaction data from the Tibco platform.

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

The following principles will apply:

| **Code** | **Principle** | **Why It Applies** |
| --- | --- | --- |
| **IDP-001** | **Generic and Reusable** | The APIM layer exposes a standardized REST interface that is independent of the underlying backend implementation. The Logic App implements a reusable request–response orchestration pattern. |
| **IDP-002** | **Decoupled Integrations** | APIM separates consumer applications from the integration implementation, while the Logic App isolates the external REST/JSON contract from the backend service contract. Backend interface or payload changes can be accommodated within the integration layer without impacting consuming applications. |
| **IDP-003** | **Integrated Security** | Authentication and authorization are enforced at APIM using OAuth 2.0 bearer tokens. Sensitive credentials are securely stored in Azure Key Vault and accessed through Managed Identity, ensuring they are never hardcoded or exposed in logs. All communication between integration components is secured using HTTPS/TLS. |
| **IDP-004** | **Standardization** | The solution follows Metcash Azure Integration Services standards by using REST/JSON over HTTPS for external interfaces, adhering to established Azure resource naming conventions, and implementing consistent logging, monitoring, and deployment practices across the platform. |
| **IDP-005** | **Resilient and Recoverable** | The solution incorporates built-in resiliency features, including fault handling, retry mechanisms where appropriate, and graceful error responses for downstream failures. Azure platform services provide high availability, while integration workflows are designed to recover from transient failures without affecting consumers. |
| **IDP-006** | **Observability** | End-to-end monitoring is provided through Application Insights and SMC, capturing request and response details, correlation identifiers, execution metrics, and exception information. This enables proactive monitoring, efficient troubleshooting, and operational support across the integration lifecycle. |

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

| **Pattern Name** | **Implementation Description** |
| --- | --- |
| **Azure Logic Apps** | Azure Logic Apps are used to implement integration workflows is designed to be stateless, modular, and focused on a single business capability, enabling easier maintenance and extensibility. |
| **API Management Service** | Azure API Management (APIM) acts as the API gateway, securely exposing Logic App endpoints to Salesforce To MDM. APIM abstracts the backend implementation, enabling versioning, and policy enforcement without impacting consumers. |
| **Retry and Resilience** | Azure API Management (APIM) retry policies and timeout controls to handle transient failures when interacting with logic apps. |
| **Logging and Observability** | Logging and telemetry are captured using **Application Insights** and **SMC**, providing visibility into request execution, response status, correlation IDs, and exception details. This enables effective monitoring, troubleshooting, and operational support. |
| **Security Abstraction** | Security is enforced at the API layer using APIM policies. Secrets and credentials required for backend access are stored securely in **Azure Key Vault** and accessed via Managed Identity. The solution is designed to support OAuth-based authentication, aligning with Gen-3 security standards and eliminating hardcoded credentials. |
| **Standard and Governance** | All interfaces comply with Metcash integration standards, including consistent API naming conventions, standardized error handling, and structured JSON responses. |

- Information related to all Standards, Guidelines and Patterns refer
  - [Guidelines](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1668874252/Guidelines)
  - [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

![image-20260715-010227.png](images/07.png)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-297 - **EAII-297 - Metconnect To Supplier MDM - Get/Release Supplier Number** | [Functional Specification - EAII-297 - Metconnect to Supplier MDM - Get/Clear Supplier Number](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3533865218/Functional+Specification+-+EAII-297+-+Metconnect+to+Supplier+MDM+-+Get+Clear+Supplier+Number) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol
- WSDL 1.1 for SOAP web service contract
- SOAP 1.2 for SOAP web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization

## 4.3 Required Components

| **Component** | **Purpose / Description** |
| --- | --- |
| **Azure App Service Plan** | Hosts the Azure Logic Apps Standard workflows that implement the integration services. |
| **Azure Virtual Network (VNet)** | Provides network isolation for the integration platform. Private endpoints ensure secure access to Azure resources such as Logic Apps and Azure Key Vault, preventing public network exposure. |
| **Azure Key Vault** | Securely stores application secrets, certificates, and configuration values, including OAuth2 credentials, backend service credentials, TLS certificates, and other sensitive parameters. All secrets are accessed using Managed Identity. |
| **Azure Application Insights** | Collects application telemetry, execution metrics, dependency tracking, and exception details from Logic App workflows. Supports operational monitoring, diagnostics, and alerting. |
| **Azure Log Analytics Workspace** | Centralizes logs from Application Insights and Azure resources, enabling advanced querying, monitoring, and alert generation for operational support. |
| **Azure Logic Apps (Standard)** | Implements the integration workflows, including request validation, data transformation, backend service orchestration, response mapping, exception handling, and audit logging. |
| **Azure API Management (APIM)** | Provides the external API gateway, exposing REST endpoints to consumers. APIM performs authentication and authorization, request validation, rate limiting, routing, and policy enforcement before forwarding requests to the Logic Apps. |

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DV1)
- System Integration Testing (ST1)
- User Acceptance Test (UT1)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).

# 5 Integration Overview and Implementation

## 5.1 EAII-297 - **Metconnect To Supplier MDM - Get/Release Supplier Number**

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The legacy integration is implemented on the Tibco platform as a single BWP process (`mdmSupplierNumberInterface.bwp`) that handles both REST endpoints via two `bpws:onMessage` handlers. The process uses the following Tibco components:

- `mdmSupplierNumberInterface.bwp` — Main entry-point process. Handles HTTP listener on two paths (`/newsupplier/v1` and `/releasesupplier/v1`), performs Bearer token validation by calling the OAuth2 subprocess, invokes the IBM MDM SOAP service using TIBCO's SOAP Invoke activity with embedded XSLT 2.0 mappings, formats the supplier number using `tib:pad-front()`, and returns the response. All embedded transformations use XSLT 2.0 within `tibex:partBinding` mapper activities.
- `Oauth2Authentication.bwp` — Authentication subprocess. Validates the `Authorization: Bearer` header against a pre-loaded API key from configuration (`default.substvar`). In the legacy system this key is loaded at startup — rotating it requires a service restart.
- `invokeLogEvent.bwp` (CommonLogging shared process) — Asynchronous audit logging subprocess. Performs a fire-and-forget SOAP call to the centralised logging service. Called at request receipt and response points.
- `default.substvar` — Configuration file containing MDM endpoint URL, MDM credentials (username/password), supplier number format parameters (prefix=`10`, pad length=`5`, pad char=`0`), and the API key.

The legacy process is a synchronous request-response implementation: Tibco receives the REST request, validates the Bearer token, translates the request to MDM SOAP format, calls MDM, formats the response, and returns the JSON result to the caller. Error handling uses Tibco fault handlers that catch MDM SOAP faults and return structured error responses.

#### 5.1.1.2 Process Flow Diagram

![image-20260717-065355.png](images/08.png)

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

The proposed Azure Integration Services (AIS) solution replaces the existing TIBCO Process with **Azure API Management (APIM)** and **Azure Logic Apps Standard**.

**Get New Supplier Number**

**Endpoint**

`POST /api/mdm/newsupplier/v1`

**Processing Flow**

1. **Request Submission**
  - Salesforce MetConnect invokes the APIM endpoint over HTTPS.
  - The request contains:
    - AgreementID (mandatory)
    - TransactionID (optional)
    - SourceSystemID (optional)

  - Uses the supplied TransactionID or generates a GUID if not provided for SMC.
  - The request includes an OAuth2 Bearer token in the Authorization header.

2. **Authentication**
  - **APIM** validates the OAuth2 Bearer token. If the token is missing or invalid, APIM returns **HTTP 401 Unauthorized** with the message **"Authentication Failed"**. If validation succeeds, APIM forwards the request to the Logic App.

3. **Logic App Processing**
  - Receives the request through an HTTP trigger.
  - Records the start of processing using SMC audit logging.
  - Using its **Managed Identity**, the Logic App retrieves the required IBM MDM configuration from **Azure Key Vault**, including:
    - MDM WS-Security username
    - MDM WS-Security password

4. **SOAP Request Construction**
  - The Logic App constructs the **getNextSupplierNumber** SOAP request with the following values:
    - **RequestControl/requestID** = Current date and time formatted as **YYYYMMDDHHmmssSSS** (17 digits)
    - **RequestControl/DWLControl/requesterName** = Value retrieved from Key Vault
    - **RequestControl/DWLControl/requesterLanguage** = **100**
    - **MTTSupNumbersBObj/Parent** = AgreementID from the request
    - **MTTSupNumbersBObj/RefType** = **SUPPLIER NUMBER**
    - **MTTSupNumbersBObj/Prefix** = **10**
    - **WS-Security Header** = UsernameToken containing the MDM username and password retrieved from Key Vault

5. **MDM Invocation**
  - Calls the IBM MDM SOAP service over HTTPS using mutual TLS authentication.

6. **Response Processing**
  - Extracts the supplier reference number returned by MDM.
  - Formats the supplier number according to business rules (prefix followed by a zero-padded reference number).
  - Records successful completion using SMC.
  - Returns an HTTP 200 response containing:
    - TransactionID
    - AgreementID
    - SupplierNumber
    - SourceSystemID (when supplied in the request)

7. **Error Handling**
  - SOAP faults and unexpected exceptions are logged to Application Insights when logging enabled.
  - Failure is recorded in SMC.
  - Returns an HTTP 200 response containing the TransactionID, AgreementID, and a user-friendly failure message.

8. **Response Delivery**
  - APIM forwards the Logic App response to Salesforce MetConnect.

**Release Reserved Supplier Number**

**Endpoint**

`POST /api/mdm/releasesupplier/v1`

**Processing Flow**

1. **Request Submission**
  - Salesforce MetConnect invokes the APIM endpoint over HTTPS.
  - The request includes:
    - AgreementID (mandatory)
    - TransactionID (optional)
    - SourceSystemID (optional)
    - OAuth2 Bearer token.

2. **Authentication**
  - **APIM** validates the OAuth2 Bearer token against the API key stored in **Azure Key Vault**. If validation fails, APIM returns **HTTP 401 Unauthorized**. Otherwise, the request is forwarded to the Logic App.

3. **Logic App Processing**
  - Receives the HTTP request.
  - Uses the supplied TransactionID or generates one.
  - Initiates SMC audit logging.
  - Retrieves the required MDM credentials from Azure Key Vault.

4. **SOAP Request Construction**
  - The Logic App constructs the **clearReservedSupplierNumbers** SOAP request with the following values:
    - **RequestControl/requestID** = Current date and time formatted as **YYYYMMDDHHmmssSSS**
    - **RequestControl/DWLControl/requesterName** = Value retrieved from Key Vault
    - **RequestControl/DWLControl/requesterLanguage** = **100**
    - **MTTSupNumbersBObj/Parent** = AgreementID from the request
    - **MTTSupNumbersBObj/RefType** = **SUPPLIER NUMBER**
    - **Prefix** is **not included** in the Release Supplier SOAP request.
    - **WS-Security Header** = UsernameToken containing the MDM username and password retrieved from Key Vault.

5. **MDM Invocation**
  - Calls the IBM MDM SOAP service over HTTPS using mutual TLS authentication.

6. **Response Processing**
  - Extracts the ResultCode from the SOAP response.
  - Records successful completion using SMC.
  - Returns an HTTP 200 response containing:
    - TransactionID
    - AgreementID
    - SuccessString
    - SourceSystemID (when supplied)

7. **Error Handling**
  - Logs SOAP faults and unexpected exceptions to Application Insights.
  - Records failure in SMC.
  - Returns an HTTP 200 response with **SuccessString = "FAILED"**.

8. **Response Delivery**
  - APIM forwards the Logic App response to Salesforce MetConnect.

#### 5.1.2.2 Process Flow Diagram

![EAII-297-Process Flow Design.drawio (2)-20260727-033023.png](images/01.png)

#### 5.1.2.3 Sequence Diagram

![image-20260724-014143.png](images/02.png)

#### 5.1.2.4 PlantUML

```
@startuml EAII-297-SupplierNumberManagement-Sequence

title EAII-297 - Supplier Number Management

actor "Salesforce" as SF
participant "Azure API Management\nt3-met-{env}-ae-apim" as APIM
participant "Logic App\nt3-met-data-suppliercontract-{env}-ae-logic" as LA
participant "IBM MDM" as MDM
participant "SMC" as OBS

== API Request ==

SF -> APIM : Supplier Number API\n(Get New / Release Reserved)\nAuthorization: Bearer <token>

alt Authentication Successful

    APIM -> LA : Forward Request

else Authentication Failed

    APIM -> OBS : Start Observation\n(TransactionId?, AgreementID?)
    APIM -> OBS : End Observation\n(Status=Authentication Failed,\nReason=Invalid/Missing Token)
    APIM --> SF : HTTP 401 Unauthorized

end

== Request Processing ==

LA -> OBS : Start Observation\n(TransactionId, AgreementID)

LA -> LA : Validate Request
LA -> LA : Generate TransactionId\n(if not provided)

alt Get New Supplier Number

    LA -> LA : Build getNextSupplierNumber\nSOAP Request

    loop Retry (Maximum 3 Attempts)
        LA -> MDM : getNextSupplierNumber\n(SOAP + WS-Security)
        MDM --> LA : Supplier Number Response
    end

    LA -> LA : Format Supplier Number

    alt MDM Success
        LA -> OBS : End Observation\n(Status=Success)
        LA --> APIM : HTTP 200\nSupplierNumber Response
    else MDM Fault / Timeout
        LA -> OBS : End Observation\n(Status=Failed)
        LA --> APIM : HTTP 200\nFailure Response
    end

else Release Reserved Supplier Number

    LA -> LA : Build clearReservedSupplierNumbers\nSOAP Request

    loop Retry (Maximum 3 Attempts)
        LA -> MDM : clearReservedSupplierNumbers\n(SOAP + WS-Security)
        MDM --> LA : Release Response
    end

    alt MDM Success
        LA -> OBS : End Observation\n(Status=Success)
        LA --> APIM : HTTP 200\nSuccess Response
    else MDM Fault / Timeout
        LA -> OBS : End Observation\n(Status=Failed)
        LA --> APIM : HTTP 200\nFailure Response
    end

end

== Monitoring ==

LA -> OBS : Log TransactionId,\nAgreementID,\nStatus & Exceptions

APIM --> SF : HTTP 200 Response

@enduml
```

### 5.1.3 Coordination

This integration operates synchronously. Salesforce MetConnect sends a request to either the **Get New Supplier Number** or **Release Reserved Supplier Number** API and waits for the response. The Azure Logic App validates the request, invokes the appropriate **IBM MDM SOAP service**, processes the response, and returns the result to the caller within the lifetime of the synchronous HTTP request.

#### 5.1.3.1 Transaction Boundaries

**Transaction Unit:** A single **Get New Supplier Number** or **Release Reserved Supplier Number** API request constitutes one transaction. Each request processes a single **Agreement ID** and results in a single IBM MDM SOAP service invocation.

**Atomicity:** Each request is processed as a single atomic transaction. If the IBM MDM service successfully completes the requested operation, the response is returned to Salesforce MetConnect. If the IBM MDM service returns a SOAP fault or the request times out after all retry attempts are exhausted, the transaction is considered failed, and an appropriate failure response is returned.

**Retry Policy:** Transient failures during IBM MDM SOAP service invocation are retried up to **three attempts** before the transaction is marked as failed.

**Timeout:** The Azure Logic App executes the complete request within the lifetime of the synchronous HTTP call. IBM MDM SOAP service invocations are subject to configured HTTP/SOAP timeout settings, and the overall request must complete within the Logic App execution timeout.

#### 5.1.3.2 State Management

**Stateless per Request:** The integration is stateless. No application state is persisted between requests within the Azure integration layer. Each **Get New Supplier Number** or **Release Reserved Supplier Number** request is processed independently based on the request payload and the corresponding IBM MDM SOAP service response.

### 5.1.4 GoAnywhere Requirements

*N/A*

### 5.1.5 Design Considerations

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| **Component** | **Purpose** |
| --- | --- |
| **Azure Logic App** (`t3-met-data-suppliercontract-{env}-ae-logic`) | Core orchestration workflow that receives requests from APIM, validates the request, invokes the IBM MDM SOAP service to either obtain or release a supplier number, records SMC observations, and returns the response to Salesforce MetConnect. |
| **App Service Plan** | Hosts the Azure Logic Apps Standard runtime. |
| **Azure API Management** (`t3-met-{env}-ae-apim`) | Exposes the **Get New Supplier Number** and **Release Reserved Supplier Number** REST APIs, performs OAuth 2.0 Bearer token authentication, executes API policies, routes requests to the appropriate Logic App workflow, and provides centralized monitoring. |
| **Azure Application Gateway** (`t1-met-core-{env}-ae1-apg-01`) | Provides secure routes external requests to Azure API Management. |
| **Azure Key Vault** (`t3b2b{env}ae1kv01`) | Stores IBM MDM credentials, client certificates, and other integration-specific secrets. Accessed securely using the Logic Apps' Managed Identity. |
| **Platform Key Vault** (`t3enabling{env}ae1kv01`) | Stores shared platform certificates, secrets, and configuration managed by the Enabling Platform team. |
| **Application Insights (Logic Apps)** | Captures Logic App telemetry, dependency tracking, exceptions, and performance metrics. |
| **Application Insights (APIM)** | Captures API Management gateway telemetry, request metrics, latency, authentication failures, and dependency information. |
| **Log Analytics Workspace** | Central repository for Application Insights telemetry, diagnostic logs, and operational monitoring. |
| **AIS Spoke Virtual Network** (`t2-met-ais-{env}-ae1-net-01`) | Provides network isolation and Virtual Network Integration for the Logic Apps and supporting Azure resources. |

#### 5.1.6.2 Services

The solution comprises the following services:

- **APIM** — Exposes the **Get New Supplier Number** and **Release Reserved Supplier Number** REST endpoints to Salesforce MetConnect. Performs OAuth 2.0 Bearer token authentication, executes API policies, and routes requests to the appropriate Azure Logic App workflow.
- **Get New Supplier Number** - Orchestrates the end-to-end workflow for generating a new supplier number, including request validation, transaction ID generation, IBM MDM `getNextSupplierNumber` SOAP service invocation, supplier number formatting, auditing, and response handling.
- **Release Reserved Supplier Number -** Orchestrates the workflow for releasing a reserved supplier number, including request validation, transaction ID generation, IBM MDM `clearReservedSupplierNumbers` SOAP service invocation, auditing, and response handling.

#### 5.1.6.3 Audit, Logging & Exceptions

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

- Interface ID = `EAII-297`
- All significant events, including successful completions and errors, will be logged in SMC for monitoring and debugging purposes.

| **Sr. No.** | **API Name** | **Description** | **API URL** | **Method** |
| --- | --- | --- | --- | --- |
| 1 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The StartObservation API initiates the monitoring process for a business interface in AIS by creating an observation instance. | met-{env}-ae-apim/smc/startObservation | POST |
| 2 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The ObservationPoint API is utilized to update the stage, status and other details of an ongoing observation for a business interface in AIS. | met-{env}-ae-apim/smc/observationPoint | POST |

##### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interface are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to [https://metcash.atlassian.net/wiki/x/BQC_dg](https://metcash.atlassian.net/wiki/x/BQC_dg) .

It uses **SMC** for end-to-end transaction observability across the integration flow and **Azure Application Insights** for Azure resource telemetry, diagnostics, and performance monitoring.

| **Component** | **Azure Resource Provider** | **Purpose** |
| --- | --- | --- |
| **SMC** | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, correlation, and auditing across Azure services and IBM MDM. |
| **Application Insights** | Microsoft.Insights/components | Captures Logic App and API Management telemetry, request traces, dependency calls, exceptions, and performance metrics. |
| **Azure Monitor** | Microsoft.Insights/* | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights for operational monitoring. |

##### 5.1.6.3.3 Exceptions

| **Observation Stage** | **Exception Scenario** | **Exception Code** | **Exception Handling** |
| --- | --- | --- | --- |
| Authentication (APIM) | Missing Authorization header | EAII297-001 | Return **HTTP 401 Unauthorized**; log authentication failure to **SMC** and **Application Insights**. |
| Authentication (APIM) | Invalid or expired OAuth access token | EAII297-002 | Return **HTTP 401 Unauthorized**; log authentication failure to **SMC** and **Application Insights**. |
| Authentication (APIM) | Insufficient OAuth permissions | EAII297-003 | Return **HTTP 403 Forbidden**; log security event to **SMC** and **Application Insights**. |
| Schema Validation (APIM) | Invalid request payload | EAII297-004 | Return **HTTP 400 Bad Request**; log validation failure to **Application Insights**. |
| Input Validation (Logic App) | Missing or invalid Agreement ID | EAII297-005 | Return **HTTP 400 Bad Request** with validation details; log validation failure. |
| IBM MDM Connectivity | Unable to establish connection to IBM MDM | EAII297-006 | Retry up to **3 attempts**. If unsuccessful, log the failure, return the configured failure response, and send an alert to [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| IBM MDM Authentication | Invalid IBM MDM credentials or WS-Security authentication failure | EAII297-007 | Log authentication failure, return the configured failure response, and send an alert to [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| IBM MDM Transport Security | Mutual TLS (mTLS) certificate validation failure | EAII297-008 | Log the certificate validation failure, return the configured failure response, and send an alert to [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| IBM MDM Service | `getNextSupplierNumber` SOAP fault | EAII297-009 | Retry up to **3 attempts**. If the fault persists, log the exception and return the configured failure response. |
| IBM MDM Service | `clearReservedSupplierNumbers` SOAP fault | EAII297-010 | Retry up to **3 attempts**. If the fault persists, log the exception and return the configured failure response. |
| IBM MDM Service | SOAP request timeout | EAII297-011 | Retry up to **3 attempts**. If the timeout persists, log the timeout and return the configured failure response. |
| Response Processing | Failed to format or process the supplier number response | EAII297-012 | Log the processing failure and return the configured failure response. |
| SMC Logging | Failed to record transaction in SMC | EAII297-013 | Log a warning to **Application Insights** and continue processing. Do not fail the API request. |
| Application Insights | Failed to write telemetry | EAII297-014 | Continue processing; no impact to the API response. |
| Global Error Handler | Any unhandled exception | EAII297-015 | Log the exception and transaction details to **Application Insights** and **SMC**, return the configured failure response, and send an alert to [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |

##### 5.1.6.3.4 Service consumers

**Salesforce MetConnect** — Invokes the **Get New Supplier Number** and **Release Reserved Supplier Number** APIs to reserve or release supplier numbers as part of the Supplier Agreement lifecycle.

Both operations are exposed through the same Azure API Management instance using separate REST endpoints:

- **Get New Supplier Number** – Requests a new supplier number from IBM MDM for the specified Agreement ID.
- **Release Reserved Supplier Number** – Releases a previously reserved supplier number associated with the specified Agreement ID.

The request is routed to the appropriate Azure Logic App workflow based on the API endpoint invoked.

##### 5.1.6.3.5 Service Operations

| **Operation** | **Protocol** | **Method** | **Endpoint** | **Description** |
| --- | --- | --- | --- | --- |
| **Get New Supplier Number** | HTTPS | POST | `/mdm/newsupplier/v1` | Requests a new supplier number from IBM MDM for the specified Agreement ID and returns the generated supplier number. |
| **Release Reserved Supplier Number** | HTTPS | POST | `/mdm/releasesupplier/v1` | Releases a previously reserved supplier number in IBM MDM for the specified Agreement ID and returns the operation status. |

##### 5.1.6.3.6 Service Provider

| **Service / Component** | **Provider** | **Responsibility** |
| --- | --- | --- |
| **IBM MDM – getNextSupplierNumber SOAP Service** | Metcash — MDM Platform Team | Generates and reserves a new supplier number for the specified Agreement ID and returns the generated supplier number. |
| **IBM MDM – clearReservedSupplierNumbers SOAP Service** | Metcash — MDM Platform Team | Releases a previously reserved supplier number associated with the specified Agreement ID and returns the operation status. |
| **IBM MDM SOAP Endpoint** | Metcash — Infrastructure / MDM Platform Team | Provides the secure SOAP endpoint used by the Azure Logic Apps to invoke the Supplier Number Management services over HTTPS using WS-Security UsernameToken and Mutual TLS (mTLS). |

##### 5.1.6.3.7 Communications Data Structures

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Description** |
| --- | --- | --- | --- | --- |
| **Salesforce MetConnect → APIM** | Get New Supplier Number Request / Release Reserved Supplier Number Request | NA | Mapping – EAII-297 | REST JSON request from Salesforce MetConnect. |
| **APIM → Logic App** | Get New Supplier Number Request (JSON) / Release Reserved Supplier Number Request (JSON) | NA | NA | Request forwarded to the appropriate Logic App after authentication and API policy validation. |
| **Logic App → IBM MDM** | IBM MDM SOAP Request | IBM MDM SOAP Response | Mapping – EAII-297 | Logic App transforms the inbound JSON request into the appropriate IBM MDM SOAP request (`getNextSupplierNumber` or `clearReservedSupplierNumbers`) and processes the SOAP response. |
| **Logic App → APIM** | NA | Get New Supplier Number Response (JSON) / Release Reserved Supplier Number Response (JSON) | Mapping – EAII-297 | Logic App transforms the IBM MDM SOAP response into the corresponding REST JSON response and returns it to Salesforce MetConnect. |

##### 5.1.6.3.8 Input/Output

**Get New Supplier Number:**

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | Receive Salesforce REST request | `TransactionID` (optional string), `SourceSystemID` (optional string), `AgreementID` (mandatory string) | `{"TransactionID":"001Rl00001O9viJIAR_20260709160955","SourceSystemID":"Salesforce","AgreementID":"P00029015"}` |
| Output | Return Salesforce REST response | `TransactionID` (string), `SourceSystemID` (optional string), `AgreementID` (string), `SupplierNumber` (string, 7 digits, format: 10 + 5-digit padded sequence) | `{"TransactionID":"001Rl00001O9viJIAR_20260709160955","SourceSystemID":"Salesforce","AgreementID":"P00029015","SupplierNumber":"1012695"}` |

**Release Reserved Supplier Number:**

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | Receive Salesforce REST request | `TransactionID` (optional string), `SourceSystemID` (optional string), `AgreementID` (mandatory string) | `{"TransactionID":"P00028593_20260709183546","SourceSystemID":"Salesforce","AgreementID":"P00028593"}` |
| Output | Return Salesforce REST response | `TransactionID` (string), `SourceSystemID` (optional string), `AgreementID` (string), `SuccessString` (string, MDM TxResult/ResultCode, e.g. `"01"` for success or `"FAILED"` on error) |  |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| IBM MDM Supplier Number Service | `getNextSupplierNumber` | `GetNextSupplierNumberInputType` / `GetNextSupplierNumberOutputType` (WSDL: `MTTSUPServices.wsdl`) | MDM response: `{"MTTSupNumbersBObj":{"Parent":"P00029015","ReferenceNumber":"12695"}}` (agent-derived from target response sample) |
| IBM MDM Supplier Number Service | `clearReservedSupplierNumbers` | `ClearReservedSupplierNumbersInputType` / `ClearReservedSupplierNumbersOutputType` (WSDL: `MTTSUPServices.wsdl`) | MDM response: `{"TxResult":{"ResultCode":"01"},"MTTSupNumbersBObj":{"Parent":"P00028593"}}` (agent-derived from target response sample) |

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | MDM Supplier |
| Source Business Process | Supplier Agreement Management |
| Source Application | Metconnect Salesforce |
| Destination Business Process | MDM Supplier |
| Destination Application | IBM MDM |
| Interface ID | EAII-297 |
| Interface Name | Get/Release MDM Supplier Number |
| Interface Type | Sender |
| Interface DataStore | N/A |
| Tags | `{"integration":"EAII-297","platform":"AIS","source":"Salesforce","target":"IBMMDM"}` |
| Reference Keys | TransactionID, AgreementID |
| Notification Type | Email |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | Get/Release MDM Supplier Number |
| Correlation Properties | TransactionID, AgreementID |
| Reprocessing Required | No |
| BusinessProcess Name | MDM Supplier |

#### 5.1.7.1 SMC Load Estimations

This section will include corresponding SMC load estimations for this interface, including peak and normal load scenarios.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | Tens to low-hundreds of requests per day during high-activity onboarding periods. Peak is estimated at up to 100 requests/day. |
| Average volume | Typically follows business-hours patterns (08:00–18:00 AEST) aligned to supplier onboarding activity. Estimated average: 10–50 requests/day. |  |
| Seasonal considerations | No significant seasonal variation expected. |  |
| Expected growth | No significant volume growth anticipated without a corresponding growth in supplier onboarding activity. |  |

### 5.1.8 Monitoring

*Capture any specific monitoring requirements for the solution here.*

### 5.1.9 Reporting

*Capture any specific reporting requirements for the solution here.*

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

| **ADO Test Case ID** | **Description** | **Location Of Sample Messages** |
| --- | --- | --- |
| T1 | Get New Supplier Number — valid AgreementID and valid API key. Expected: HTTP 200 with 7-digit SupplierNumber starting with `10`; AgreementID echoed; TransactionID echoed or generated. Sample: AgreementID=P00029015 → SupplierNumber=1012695. | `sample_payloads/EAII-297/source_samples/getNextSupplierNumber_SampleRequest_1.json` → `target_samples/getNextSupplierNumber_SampleResponse_1.json` |
| T2 | Get New Supplier Number — caller supplies TransactionID. Expected: HTTP 200 with caller-supplied TransactionID echoed back unchanged. Sample: TransactionID=001Rl00001O9viJIAR_20260709160955. | `sample_payloads/EAII-297/source_samples/getNextSupplierNumber_SampleRequest_1.json` |
| T3 | Get New Supplier Number — no TransactionID supplied. Expected: HTTP 200 with system-generated TransactionID (non-empty GUID-format string). | Custom request with TransactionID omitted |
| T4 | Release Reserved Supplier Number — valid AgreementID and valid API key. Expected: HTTP 200 with SuccessString populated with MDM ResultCode; AgreementID echoed. Sample: AgreementID=P00028593 → SuccessString=01. | `sample_payloads/EAII-297/source_samples/clearReservedSupplierNumber_SampleRequest_1.json` → `target_samples/clearReservedSupplierNumber_SampleResponse_1.json` |
| T5 | Get New Supplier Number — invalid or missing API key. Expected: HTTP 401 "Authentication Failed: Please check Authorization Key". No MDM call made. | Request with invalid/absent Authorization header |
| T6 | Release Reserved Supplier Number — invalid or missing API key. Expected: HTTP 401 "Authentication Failed: Please check Authorization Key". No MDM call made. | Request with invalid/absent Authorization header |
| T7 | Get New Supplier Number — MDM returns SOAP processing fault. Expected: HTTP 200 with `Message: "Request for new supplier failed. Please contact Metcash."` and no SupplierNumber field. | Simulate MDM SOAP fault via stub/mock |
| T8 | Release Reserved Supplier Number — MDM returns SOAP processing fault. Expected: HTTP 200 with `SuccessString: "FAILED"`. | Simulate MDM SOAP fault via stub/mock |
| T9 | Get New Supplier Number — MDM service unavailable (timeout). Expected: Error response returned to caller within configured timeout period; error event logged to Application Insights. | Simulate MDM timeout via stub/mock |
| T10 | All optional fields absent (TransactionID and SourceSystemID omitted from request). Expected: HTTP 200 success response; TransactionID auto-generated; SourceSystemID absent from response. | Custom request with optional fields omitted |
| T11 | API key rotation without restart (known issue). Rotate API key in Key Vault. Expected: Next request using new key succeeds (HTTP 200); request with old key fails (HTTP 401). No restart of APIM or Logic App required. | Rotate Key Vault secret; submit requests with new and old keys |
| T12 | Get New Supplier Number — second sample: AgreementID=P00029017 → SupplierNumber=1012525. | `sample_payloads/EAII-297/source_samples/getNextSupplierNumber_SampleRequest_2.json` → `target_samples/getNextSupplierNumber_SampleResponse_2.json` |

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![EAII-297-Architecture Diagram.drawio (2)-20260727-034142.png](images/05.png)

## 6.2 Network Connectivity

![EAII-297-Network Diagram.drawio (2)-20260727-034225.png](images/06.png)

## 6.3 Security

- API management and OAuth2 to be implemented for all APIs for Authentication/Authorisation.
- Incoming traffic for LogicApps are secured by creating private endpoints.
- LogicApps will be using managed identities to communicate with Azure Key Vaults.
- Azure key vault will be used to store all secrets.
- Control access to all Azure services/resources using RBAC.
- All communication between endpoints will be through https.

**Key Vault Secret**

The solution stores all sensitive configuration and credentials in Azure Key Vault. The Azure Logic App accesses the required secrets using its Managed Identity with the **Key Vault Secrets User** role. No secrets are stored in application configuration or source code.

| **Key Vault** | **Purpose** |
| --- | --- |
| **t3data{env}ae1kv01** | Stores integration-specific secrets required by the Supplier Number Management solution, including IBM MDM credentials and other application-specific configuration. |
| **t3enabling{env}ae1kv01** | Shared platform Key Vault managed by the Enabling Platform team, containing shared platform configuration, certificates, and platform-managed secrets where applicable. |

### 6.3.1 Data Handling and Encryption

**Data Classification:** Internal commercially sensitive supplier master data (Agreement ID, Supplier Number, transaction status), but no Personally Identifiable Information (PII).

**In Transit:** All communication is encrypted using **TLS 1.2+**. HTTPS is used for communication between **Salesforce , Azure API Management, Azure Logic Apps, SMC, and Azure Application Insights**. Communication between the Logic App and **IBM MDM** uses **SOAP over HTTPS** secured with **WS-Security UsernameToken** and **Mutual TLS (mTLS)**.

**At Rest:** The integration layer does not persist request or response payloads. Only transaction metadata (for example, Transaction ID, Agreement ID, timestamps, processing status, and error details) is recorded for operational monitoring and auditing.

**Business Identifiers:** **Agreement ID** and **Supplier Number** are treated as internal business identifiers (not PII). These values may be included in operational logs at the metadata level for traceability and auditing but are not logged as part of the complete request or response payload.

## 6.4 Infrastructure Support

*Capture any specific infrastructure support requirements for the solution here.*

## 6.5 Infrastructure Requirements

**Logic App Infrastructure**

| **Resource** | **SKU / Tier** | **Workflow Type** | **Hosting** | **Purpose** |
| --- | --- | --- | --- | --- |
| Azure Logic App | Standard | Stateless | Azure Logic Apps Standard | Hosts the Supplier Number Management workflow responsible for request validation, transaction ID generation, supplier number request/release processing, IBM MDM SOAP service invocation, response transformation, auditing, and exception handling. |
| App Service Plan | Standard | N/A | Dedicated | Provides the compute hosting environment for the Logic App Standard runtime. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **Azure Logic App** | **t3-met-data-suppliercontract-{env}-ae-logic** | New |
| **Azure Key Vault** | **t3data{env}ae1kv01**<br> <br>**t3enabling{env}ae1kv01** | Existing |
| **Resource Group** | **t3-met-ais-{env}-ae1-rsg-b2b** | Existing |
| **Subscription** | **COREIT-SERVICES-AIS-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / SENS** | Existing |
| **Azure Application Insights** | **t3-met-data-suppliercontract-{env}-ae-logic-ai** | New |

**{env} -** dv1, st1, ut1 and prd

**Workflow Details**

| **Workflow** | **Get New Supplier Number** | **Release Reserved Supplier Number** |
| --- | --- | --- |
| **Workflow Name** | `GetNewSupplierNumber` | `ReleaseReservedSupplierNumber` |
| **Workflow Type** | Stateless | Stateless |
| **Runtime** | Azure Logic Apps Standard | Azure Logic Apps Standard |
| **Hosting Model** | Dedicated App Service Plan | Dedicated App Service Plan |
| **Trigger Type** | HTTP Request Trigger | HTTP Request Trigger |
| **Logic App** | Processes supplier number requests by validating the request, invoking the IBM MDM `getNextSupplierNumber` SOAP service and returning the response to Salesforce. | Processes supplier number release requests by validating the request, invoking the IBM MDM `clearReservedSupplierNumbers` SOAP service, and returning the operation status to Salesforce. |
| **Outbound Service** | IBM MDM – `getNextSupplierNumber` | IBM MDM – `clearReservedSupplierNumbers` |
| **Retry Policy** | Maximum 3 retry attempts for transient SOAP service failures | Maximum 3 retry attempts for transient SOAP service failures |
| **Response** | Returns the formatted Supplier Number or a failure response. | Returns the release status or a failure response. |

**Azure API Management Infrastructure**

Azure API Management (APIM) serves as the secure gateway for the **Supplier Number Management API**, exposing the **Get New Supplier Number** and **Release Reserved Supplier Number** REST endpoints to Salesforce MetConnect. APIM is responsible for enforcing OAuth 2.0 Bearer token authentication, executing inbound and outbound policies, routing requests to the appropriate Azure Logic App workflow, handling error responses, and providing centralized monitoring and observability.

| Resource | Azure Resource Provider | SKU | Purpose |
| --- | --- | --- | --- |
| Azure API Management | `Microsoft.ApiManagement/service` | Standard | Exposes the **Supplier Number Management APIs** (**Get New Supplier Number** and **Release Reserved Supplier Number**), performs OAuth 2.0 Bearer token authentication, executes API policies, routes requests to the appropriate Azure Logic App workflow, handles request and response processing, and provides centralized monitoring and observability. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **APIM** | **t3-met-core-{env}-ae-apim** | Existing |
| **Resource Group** | **t3-met-core-{env}-ae1-rsg-apim** | Existing |
| **Subscription** | **COREIT-SERVICES-HUB-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / HSENS** | Existing |
| **Azure Application Insights** | **t3-met-core-{env}-ae-apim-ai** | New |

**API Endpoints**

| **API** | **Endpoint** |
| --- | --- |
| Get supplier data | `/newsupplier/v1` |
| Release supplier data | `/releasesupplier/v1` |

**APIM Policies**

Azure API Management policies are used to implement:

- OAuth 2.0 authentication and authorization
- Request validation
- SOAP-to-JSON and JSON-to-SOAP transformation
- Backend routing to the Azure Logic App
- Error handling and standardized fault responses
- Logging and telemetry integration with Azure Application Insights and SMC

**Virtual Network Architecture**

The **Supplier Number Management** integration is deployed within the enterprise **Hub-and-Spoke** network architecture. Azure API Management is deployed in the **Hub Virtual Network**, while the Azure Logic Apps and supporting integration resources are deployed in the **AIS Spoke Virtual Network**. Secure communication between Azure resources and **IBM MDM** is established over HTTPS using enterprise networking controls, including **Virtual Network Integration, Private Endpoints**and**Network Security Groups (NSGs)** for secure SOAP service communication.

**App Gateway Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure Application Gateway | Microsoft.Network/applicationGateways | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | Microsoft.Network/applicationGateways | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure API Management | Microsoft.ApiManagement | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | Microsoft.ApiManagement | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | Microsoft.ApiManagement | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | Microsoft.ApiManagement | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Logic App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway, providing Layer 7 load balancing and secure ingress routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**SENS (Logic App Application Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Logic Apps** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | **t3-met-data-suppliercontract-dv1-ae-logic** |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | **t3-met-data-suppliercontract-st1-ae-logic** |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | **t3-met-data-suppliercontract-ut1-ae-logic** |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | **t3-met-data-suppliercontract-prd-ae-logic** |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**App Gateway:-**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Managed Identity**

The Azure Logic App uses a System-Assigned Managed Identity. The identity is
 automatically created and managed by Azure, and its lifecycle is tied
 exclusively to the Logic App resource. When the Logic App is deleted, the
 identity is automatically deleted with it.

A User-Assigned Managed Identity (Microsoft.ManagedIdentity/userAssignedIdentities)
 was considered but was not selected for this integration. The System-Assigned
 model is preferred here because:

- The identity is used solely by this Logic App and no other resource.
- There is no requirement to share the same identity across multiple Azure resources.

No credentials, client secrets, or certificates are stored within the
 application. All Azure service authentication is performed at runtime via the
 System-Assigned Managed Identity token.

**Identity and Access Control (RBAC)**

The Logic App authenticates to Azure services using Microsoft Entra ID and its Managed Identity. The following Azure RBAC roles are assigned based on the principle of least privilege.

**Complete RBAC Assignments (**`Microsoft.Authorization/roleAssignments`**):**

| Source | Target | Identity | RBAC Role |
| --- | --- | --- | --- |
| `t3-met-data-suppliercontract-{env}-ae-logic` | `t3data{env}ae1kv01` | System-Assigned Managed Identity | Key Vault Secrets User |
| `t3-met-data-suppliercontract-{env}-ae-logic` | `t3-met-data-suppliercontract-{env}-ae-ai` | System-Assigned Managed Identity | Monitoring Metrics Publisher |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

| Private Endpoint Name | Target Resource | Sub-resource | Private Zone | New / Existing |
| --- | --- | --- | --- | --- |
| `t3-met-data-suppliercontract-{env}-ae-pe-kv` | `t3data{env}ae1kv01` (Azure Key Vault) | `vault` | `privatelink.vaultcore.azure.net`<br> <br>`t3data{env}ae1kv01.vault.azure.net` | Existing |
| `t3-met-data-suppliercontract-{env}-ae-pe-ai` | `t3-met-data-suppliercontract-{env}-ae-logic-ai` (Application Insights) | - | `privatelink.monitor.azure.com` | New |

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Logic App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`

# 7 Communication Overview

## 7.1 Communication Components

![EAII-297-Communication-Diagram.drawio (1)-20260724-100336.png](images/04.png)

| **Component** | **Source** | **Destination** | **Protocol** | **Port** |
| --- | --- | --- | --- | --- |
| Salesforce → APIM | Salesforce | Azure API Management | HTTPS | 443 |
| APIM → Logic App | Azure API Management | Logic App HTTP Trigger | HTTPS | 443 |
| Logic App → IBM MDM | Logic App | IBM MDM SOAP Service | HTTPS | 9443 |
| Logic App → SMC | Logic App | SMC (via APIM) | HTTPS | 443 |
| Logic App → Application Insights | Logic App | Application Insights | HTTPS | 443 |

# 8 Data Architecture

## 8.1 Data Model

*NA*

## 8.2 Stored Procedures

*NA*

## 8.3 Stored Procedure Triggers

*NA*

## 8.4 Database Technical Specification

**Azure SQL Database:** Not required for this integration. No Azure SQL Server (`Microsoft.Sql/servers`) or Azure SQL Database (`Microsoft.Sql/databases`) resource is provisioned for EAII-297.

**SMC :** The SMC platform manages its own backend datastore independently of this integration. Transaction metadata written to SMC via `startObservation` and `observationPoint` APIs is governed by the SMC platform's own data retention policy.

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

*N/A*

### 8.5.2 Data Backup

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

*N/A*

#### 8.5.3.2 State process for data/system destruction

*N/A*

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

*N/A*

## 9.2 Deployment Preference

*N/A*

## 9.3 Deployment Environment Migration

*All source code is managed under source control (currently Github or Azure Devops Repo).*

*Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure.*

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PROD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.

# 10 Disaster Recovery

*N/A*

# 11 Support Documentation

![diagram](images/03.png)

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | Azure function can accept the request data up to 100 MB. | The HTTP request length is limited to 100 MB (104,857,600 bytes), and the URL length is limited to 4 KB (4,096 bytes) | [https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits](https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits) |

# 13 Assumptions

- any assumption while designing solution

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

# 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/09.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |
