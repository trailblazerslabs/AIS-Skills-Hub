<!-- Source: Technical+Specification+-+EAII-514+-+Sorted+to+PE.doc -->
<!-- Title: Technical Specification - EAII-514 - Sorted to PE -->

# Technical Specification - EAII-514 - Sorted to PE

**Table of Contents**

- 1 Document Overview
  - 1.1 Background
  - 1.2 Document Purpose
  - 1.3 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope

- 3 Compliance
  - 3.1 Architecture Principles
  - 3.2 Standards, Guidelines and Patterns

- 4 Requirements Overview
  - 4.1 Business Process Requirement and Integration
    - 4.1.1 Process Diagram from FSD
    - 4.1.2 Functional Specification Document

  - 4.2 Technical standard and requirements
  - 4.3 Required Components
  - 4.4 Environmental Requirement

- 5 Integration Overview and Implementation
  - 5.1 EAII-514 - Realtime Pricing - Sorted to PE
    - 5.1.1 As-is Process(es)
      - 5.1.1.1 Description of Process(es)

    - Technical Process
      - 5.1.1.2 Process Flow Diagram
      - 5.1.2 Proposed Process(es)
      - 5.1.2.1 Description of Process(es)
      - 5.1.2.2 Process Flow Diagram
      - 5.1.2.3 Sequence Diagram
      - 5.1.2.4 PlantUML

    - 5.1.3 Coordination
      - 5.1.3.1 Transaction Boundaries
      - 5.1.3.2 State Management

    - 5.1.4 GoAnywhere Requirements
    - 5.1.5 Design Considerations
    - 5.1.6 Service High Level Design
      - 5.1.6.1 Component List
      - 5.1.6.2 Services
      - 5.1.6.3 Audit, Logging & Exceptions
        - 5.1.6.3.1 Logging
        - 5.1.6.3.2 Audit
        - 5.1.6.3.3 Exceptions
        - 5.1.6.3.4 Service consumers
        - 5.1.6.3.5 Service Operations
        - 5.1.6.3.6 Service Provider
        - 5.1.6.3.7 Communications Data Structures
        - 5.1.6.3.8 Input/Output
        - 5.1.6.3.9 Fulfillment Services

    - 5.1.7 SMC Onboarding
      - 5.1.7.1 Integration Onboarding
      - 5.1.7.2 SMC Load Estimations

    - 5.1.8 Monitoring
    - 5.1.9 Reporting
    - 5.1.10 Integration and Testing Requirements
      - 5.1.10.1 Development and Integration Strategy
      - 5.1.10.2 Unit Testing

- 6 Architecture Overview
  - 6.1 Physical Architecture Diagram
  - 6.2 Network Connectivity
  - 6.3 Security
    - Pillar Validation
    - 6.3.1 Data Handling and Encryption

  - 6.4 Infrastructure Support
  - 6.5 Infrastructure Requirements

- 7 Communication Overview
  - 7.1 Communication Components

- 8 Data Architecture
  - 8.1 Data Model
  - 8.2 Stored Procedures
  - 8.3 Stored Procedure Triggers
  - 8.4 Database Technical Specification
  - 8.5 Data Retention
    - 8.5.1 Data Retention Procedures
      - 8.5.1.1 Data storage and retention

    - 8.5.2 Data Backup
    - 8.5.3 Data Destruction Procedures
      - 8.5.3.1 Data destruction metrics and timeframes
      - 8.5.3.2 State process for data/system destruction

- 9 Deployment and Monitoring Considerations
  - 9.1 Transition Period
  - 9.2 Deployment Preference
  - 9.3 Deployment Environment Migration

- 10 Disaster Recovery
- 11 Support Documentation
- 12 Limitations and Constraints
- 13 Assumptions
- 14 Reference Documents and Architecture
- 15 TSD Approval Checklist

| **TSD Author** | [Raj Duraisamy](https://metcash.atlassian.net/wiki/people/712020:f7f096f2-337c-41f4-85de-01ae39be92f0?ref=confluence) |
| --- | --- |

| **Document Approver** | **Approver Role** |
| --- | --- |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Magesh Parthasarathy | Solution Architect |
| Mohanraj Vengiduswamy | Test Manager |

# 1 Document Overview

## 1.1 Background

Metcash operates a pricing enquiry service that enables downstream ordering and e-commerce systems collectively referred to as "Sorted" (encompassing the IGA, Campbells, and C-Store portals) to retrieve real-time product pricing information from Power Enterprise (PE), the legacy ERP system hosted on an IBM AS/400 platform. This service is invoked on-demand during the order placement workflow to ensure that pricing presented to retailers reflects the correct current wholesale cost, promotional pricing, allowances, and related pricing components for a given product, customer, warehouse, and date combination.

The integration currently runs on the TIBCO BusinessWorks 6 (BW6) platform and is being migrated to Azure Integration Services (AIS) as part of the enterprise integration modernization programmed. The service is highly utilized with a peak volume of 10,784 calls/hour (378 calls/minute) and migration to AIS is expected to reduce load on the existing BW Container (BWC) infrastructure. Both Sorted and PE are classified as RED systems under the Horizon Impact Assessment, meaning only business-critical changes are permitted after review.

The integration exposes one REST/JSON API at initial phase serving the business function via calling the AS/400 stored procedure (CX40K6B). The core pricing logic remains entirely within the AS/400 system; the integration layer is responsible solely for protocol translation, field transformation, and orchestration of per-product stored procedure calls.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the *EAII-514 Realtime Pricing* service between *Sorted* and *PE - Power Enterprise on IBM AS/400*.

## 1.3 Glossary

| **Term** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| AS/400 | IBM midrange server hosting Power Enterprise |
| CLE | Common Logging Events - the Metcash centralized logging framework |
| GSB | Gold/Silver/Bronze service classification |
| PE | Power Enterprise - legacy ERP system hosted on IBM AS/400, managing pricing among other business functions |
| Pillar | Metcash business division (IGA, ALM, CCC, CSD) |
| Sorted | Customer-facing ordering/e-commerce portal (encompasses IGA, Campbells, and C-Store portals) that invokes the pricing service |

# 2 Scope

## 2.1 In Scope

- Synchronous real-time pricing enquiry for up to 20 products per request
- REST/JSON API endpoint (POST)
- Stored procedure invocation against the AS/400 Power Enterprise system for price calculation
- Database outage mode with configurable error response
- Audit logging of service invocations (transaction history)
- Error handling with structured fault responses (HTTP 500)
- On-Premises Data Gateway connectivity from Azure VNet to IBM AS/400 JDBC endpoint

## 2.2 Out of Scope

- Changes to the AS/400 stored procedure (CX40K6B) or its calculation logic
- Changes to the consuming Sorted platform's integration client
- Batch pricing operations or scheduled pricing extracts
- Price data persistence or caching within the integration layer

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

| Code | Principle | Why It Applies |
| --- | --- | --- |
| **IDP-001** | Generic and Reusable | The pricing query Logic App is designed as a protocol-agnostic orchestrator. The AS/400 connector and field-transformation utilities are implemented as reusable inline functions. |
| **IDP-002** | Decoupled Integrations | The consumer-facing endpoints are decoupled from the AS/400 backend via Azure API Management and a Logic App orchestration layer. The AS/400 stored procedure interface is accessed only through the Logic App, not directly by consumers. |
| **IDP-003** | Integrated Security | All credentials (AS/400 JDBC connection string, AS/400 username/password) are<br> stored in Azure Key Vault and accessed exclusively via the Logic App's<br> System-Assigned Managed Identity at runtime. No secrets are stored in application<br> configuration or source code. Consumer-facing API security is enforced via OAuth<br> 2.0 Bearer token validation in Azure API Management. APIM subscription keys are<br> not used for this integration; authentication is token-based only, aligned with<br> the Gen-3 security standard. |
| **IDP-004** | Standardization | The integration implements the Metcash standard API patterns. Azure resource names follow the Azure Abbreviation Recommendations naming convention. |
| **IDP-005** | Resilient and Recoverable | The database outage flag provides a controlled degradation path for planned AS/400 maintenance windows. The AS/400 connection pool is configured with a 30-second query timeout per product call. |
| **IDP-006** | Observability | Every invocation logs a start event, end event, and error event to SMC. Transaction history is persisted with UUID, service name, timestamps, destination, and status fields. |

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

| **Pattern Name** | **Implementation Description** |
| --- | --- |
| **Azure Logic Apps** | Azure Logic Apps are used to implement integration workflows is designed to be stateless, modular, and focused on a single business capability, enabling easier maintenance and extensibility. |
| **API Management Service** | Azure API Management (APIM) acts as the API gateway, securely exposing Logic App endpoints to Sorted To PE. APIM abstracts the backend implementation, enabling versioning, and policy enforcement without impacting consumers. |
| **Retry and Resilience** | Azure API Management (APIM) retry policies and timeout controls to handle transient failures when interacting with logic apps. |
| **Logging and Observability** | Logging and telemetry are captured using **SMC**, providing visibility into request execution, response status, correlation IDs, and exception details. This enables effective monitoring, troubleshooting, and operational support. |
| **Security Abstraction** | Security is enforced at the API layer using APIM policies. Secrets and credentials required for backend access are stored securely in **Azure Key Vault** and accessed via Managed Identity. The solution is designed to support OAuth-based authentication, aligning with Gen-3 security standards and eliminating hardcoded credentials. |
| **Standardization and Governance** | All interfaces comply with Metcash integration standards, including consistent API naming conventions, standardized error handling, and structured JSON responses. |

Information related to all Standards, Guidelines and Patterns refer

- [Guidelines](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1668874252/Guidelines)
- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

[Functional Specification - EAII-514 - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3486121993/Functional+Specification+-+EAII-514+-+Sorted+to+PE#3.1.1.1-Process-Diagram)

![image-20260628-234851.png](images/04.png)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-514 - Sorted to PE | [Functional Specification - EAII-514 - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3486121993/Functional+Specification+-+EAII-514+-+Sorted+to+PE) |
| Mapping - EAII-514 - Realtime Pricing - Sorted to PE | [Mapping - EAII-514 - Realtime Pricing - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization

## 4.3 Required Components

The following components are required for this integration:

| **Azure Resource** | **Purpose** |
| --- | --- |
| **Azure Virtual Network** | Provides secure network isolation for integration resources. Logic Apps use VNet Integration for outbound connectivity to the on-premises gateway and IBM AS/400, while Private Endpoints restrict inbound access to Azure services. |
| **Azure Key Vault** | Securely stores and manages sensitive configuration, including the AS/400 connection string, credentials, and other application secrets. |
| **Azure Logic Apps (Standard)** | Implements the core orchestration workflow by receiving requests from Azure API Management, validating inputs, processing product requests, invoking the IBM AS/400 backend, and returning the consolidated response. |
| **Azure API Management** | Publishes the REST (`/eis/pricing/v1/getrealtimeprice`) endpoint for Sorted consumers, while enforcing authentication, authorization, request validation, and API policies. |

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DV1)
- System Integration Testing (ST1)
- User Acceptance Test (UT1)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).

# 5 Integration Overview and Implementation

## 5.1 EAII-514 - Realtime Pricing - Sorted to PE

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The current integration is implemented using **TIBCO BusinessWorks 6 (BW6)**. The service exposes both REST, which share a common business process for pricing retrieval.

### Technical Process

1. **Consumer invokes the service**

The Sorted consumer application (IGA, Campbells, or C-Store) sends a pricing request using either the REST interface.

- **REST Binding (**`RestPricingService.bwp`**)**
  - Accepts a JSON `PriceDataRequest` through an HTTP POST endpoint.
  - Converts the JSON payload into the internal XML request format using an inline XSLT transformation.
  - Invokes the common pricing subprocess.

1. **Common pricing subprocess**

Both service bindings invoke the shared process `QueryPriceData-CX40K6B.bwp`, which performs the core business logic.

1. **Database outage validation**

The subprocess checks the `dbOutageFlag` module property.

- If the flag is enabled, processing terminates immediately and a predefined error response is returned.
- Otherwise, the request proceeds to product processing.

1. **Product processing**

The subprocess iterates through each product contained in the request using a **For Each Group** activity.

For every product, the required stored procedure input parameters are prepared using TIBCO XSLT extension functions, including:

- `tib:trim`
- `tib:right`
- `tib:pad-front`

These functions perform field formatting such as trimming, substring extraction, and left-padding to satisfy the AS/400 stored procedure requirements.

1. **Stored procedure execution**

For each product, the process executes the **CX40K6B** stored procedure on the IBM AS/400 through a JDBC connection.

Each product is processed sequentially, with the next stored procedure call beginning only after the previous call completes.

1. **Response construction**

The stored procedure responses are accumulated and transformed into the `PriceDataResponsev2` XML schema using an **End** activity with an inline XSLT transformation.

1. **Logging**

The implementation includes two logging mechanisms:

- **CommonLogging.invokeLogEvent (CLE)**
  - Records start, completion, and error events.
  - Logging is controlled through the `CLELogOn` configuration flag.

- **CommonInterfaceLib.LogtoTransactionHistory**
  - Records transaction history for auditing and operational tracking.

Although CLE logging is implemented, it is currently disabled in the production environment due to performance considerations.

**Known Issues with the Current Implementation**

| Known Issue | Description |
| --- | --- |
| Sequential stored procedure execution | Products are processed one at a time. With up to 20 products per request, response time increases linearly with the number of products, resulting in approximately **30–60 ms per product** and an overall processing time of approximately **600 ms to 1.2 seconds** for a full request. |
| Static database outage configuration | The `dbOutageFlag` is maintained as a static module property. Planned maintenance requires manual configuration changes, and no automated database health-check mechanism is available. |
| Production logging disabled | Due to the high transaction volume (approximately **10,784 calls per hour**), CLE logging has been disabled in production to minimize performance impact. As a result, detailed operational logging and end-to-end observability are limited, while only transaction history continues to be recorded. |

#### 5.1.1.2 Process Flow Diagram

![image-20260628-234851.png](images/04.png)

#### 5.1.2 Proposed Process(es)

***Note:** This section may be revised as the project progresses, at this stage,*For the initial phase, **only the specified REST endpoint is in scope**:

- **Protocol:** HTTPS
- **Method:** POST
- **Endpoint:** `/eis/pricing/v1/getrealtimeprice`
- **Request:** `application/json`
- **Response:** `application/json`

#### 5.1.2.1 Description of Process(es)

**Proposed Azure Integration Services (AIS) Implementation**

The proposed AIS solution re-implements **EAII-514** using Azure Integration Services (AIS) components and the following processing flow.

1. **Consumer invokes the APIM endpoint**

The Sorted consumer application (IGA, Campbells, or C-Store) sends an HTTPS POST request to Azure API Management (APIM).

`POST /eis/pricing/v1/getrealtimeprice` with `Content-Type: application/json`

1. **APIM validates and routes the request**

Azure API Management (APIM) performs the following gateway validations before forwarding the request to the Logic App:

- Authenticates the request using OAuth 2.0.
- Validates the request payload against the REST JSON schema.
- Validates business rules to ensure:
  - Company equals **MTT**
  - Pillar is one of **IGA, ALM, CCC, or CSD**
  - PriceDate follows the **YYYY-MM-DD** format
  - A maximum of **20 products** is included in a single request.

- Checks the **dbOutageFlag** configuration.

If any validation fails, APIM immediately returns:

- **HTTP 400** for validation failures.
- **HTTP 401** for authentication failures.
- **HTTP 503** when the database outage flag is enabled.

Requests that fail validation or maintenance checks are not forwarded to the Logic App.

Upon successful validation, APIM forwards the request to the Azure Logic App Standard workflow over an internal HTTPS endpoint.

1. **Logic App receives the request**

The Logic App is triggered through an HTTP endpoint.

- REST requests are processed using the JSON payload received from APIM.

1. **Transaction start logging**

When enabled through the SMC logging configuration flag, the Logic App records a structured start event containing:

- Transaction ID
- Service name
- Company
- Pillar
- Department
- WarehouseId
- CustomerId
- PriceDate
- Product count

1. **Product processing**

The Logic App iterates through each product contained in the **Product[]** collection using a **For Each** loop configured with **Concurrency = 1**, ensuring products are processed sequentially.

1. **Field transformation**

The map action transforms request fields into the format required by the AS/400 stored procedure.

| AS/400 Field | Transformation |
| --- | --- |
| XPCMPN | Trim Company and left-pad to 3 characters |
| XPDIVN | Trim Pillar and left-pad to 3 characters |
| XPDPTN | Trim Department and left-pad to 3 characters |
| XPWHSN | Left-pad WarehouseId to 3 characters |
| XPCUSN | Take the rightmost 8 char of CustomerId, trim, and left-pad with zeros to 10 characters |
| XPITMN | Trim Product, convert to Long, convert back to String, and left-pad with zeros to 10 char |
| XPDTES | Convert `YYYY-MM-DD` to numeric `YYYYMMDD` |
| XPSFLG | Constant value `"0"` |

1. **Stored procedure execution**

For each product, the Logic App invokes the AS/400 stored procedure:

`CALL IDSPNDUR1.CX40K6B`

using the IBM AS/400 JDBC driver (`com.ibm.as400.access.AS400JDBCDriver`) with a 30-second query timeout.

The Logic App processes products using a **For Each** loop with the following behavior:

- **First Product:** Processed sequentially to verify the database/JDBC connection before initiating parallel processing. If a connectivity failure occurs, it is treated as a **circuit-breaker condition**, and an appropriate response is returned without proceeding with parallel processing.
- **Remaining Products:** Processed in parallel after the initial database/JDBC connection is successfully verified.
- **Retry Handling:** Transient JDBC/database connectivity failures and timeout errors are retried according to the configured retry policy. If the retry attempts are exhausted without success, the error is propagated to the Logic App for centralized error handling.
- **Stored Procedure Errors:** If the stored procedure returns `XOERROR = "Y"`, the corresponding `XOEMSG` is returned for that product, while processing continues for the remaining products.
- **Exception Handling:** Non-retryable JDBC exceptions, or errors that persist after the configured retry attempts, are propagated to the Logic App for centralized error handling.

**10. Result aggregation**

The Logic App aggregates all product responses into the `PriceData[]` collection.

- Responses from parallel processing are aggregated to accurately identify successful, failed scenario’s.

Any output fields returned as `xsi:nil` by the stored procedure are omitted from the final response.

**11. Response construction**

The aggregated stored procedure output is mapped to the `PriceDataResponsev2` response model.

The following request fields are echoed in the response:

- Company
- Pillar
- Department
- WarehouseId
- CustomerId
- PriceDate

Each product includes:

- Product
- ProductPrice (`XOTTLP`)
- Allowance (`XOTAWP`)
- UnitProductPrice (`XOLUCA`)
- ErrorMsg (`XOEMSG`, when `XOERROR = "Y"`)
- OriginalProductPrice (`XZPRCG`)
- OriginalUnitProductPrice (`XZLUCA`)
- RRPorSRP (`XOPRCE`)
- RetailMarginPercent (`XOPRFP`)
- CartonExcludingGST (`XZPGST`)
- SingleUnitPriceExcGST (`XZPEXG`)

The following schema fields are defined but are not populated by the stored procedure:

- PromotionalWholesaleCost
- WholesaleCost
- UnitPromotionalSale

**12. Transaction completion logging**

On completion, the Logic App records a structured end event to SMC when SMC logging is enabled.

- Transaction UUID
- Processing duration
- Product count
- Overall processing status (Success or Failure)

**13. Response returned to the consumer**

The Logic App returns:

- `PriceDataResponsev2` serialized as JSON for REST consumers,

with an **HTTP 200** status code.

**14. Centralized error handling**

Any unhandled exception is processed by the Logic App error handler, which:

- Logs exception details to SMC
- Records the failed transaction in SMC when SMC logging is enabled.
- Returns either:
  - **HTTP 500**

to the consumer.

**Resolution of Known Issues**

| Known Issue | Proposed Solution |
| --- | --- |
| Sequential product processing increases response time | Configure the Logic App **For Each** loop for parallel execution with a concurrency limit, subject to confirmation that concurrent execution of the AS/400 stored procedure. |
| Logging disabled in the current implementation | Enable comprehensive transaction logging by recording request start, completion, and error events in SMC based on configuration |

#### 5.1.2.2 Process Flow Diagram

![EAII-514-updated-1-Process Flow Design.drawio (1)-20260721-070842.png](images/09.png)

#### 5.1.2.3 Sequence Diagram

![image-20260724-062848.png](images/01.png)

#### 5.1.2.4 PlantUML

```
@startuml EAII-514 Realtime Pricing Sequence

title EAII-514 — Realtime Pricing — Sorted to PE\nProposed AIS Sequence

actor "Sorted Consumer\n(IGA/Campbells/C-Store)" as Consumer
participant "Azure APIM" as APIM
participant "Logic App\nt3-met-b2b-realtimepricing-{env}-ae-logic" as LA
participant "Inline Function" as FA
database "IBM AS/400 PE" as AS400
participant "SMC" as SMC

Consumer -> APIM : HTTPS POST PriceDataRequest\n(REST JSON)

group APIM Validation

note over APIM
- OAuth 2.0 Authentication
- Schema Validation
- Business Validation
  • Company = MTT
  • Pillar enumeration
  • Date format
  • Maximum 20 products
- Check dbOutageFlag
end note

APIM -> APIM : Authenticate Request
APIM -> APIM : Validate Schema
APIM -> APIM : Validate Business Rules
APIM -> APIM : Check dbOutageFlag

alt Authentication / Validation Failed

    alt smcLoggingEnabled = true
        APIM -> SMC : Log validation/authentication failure
    end

    APIM --> Consumer : HTTP 400 / 401\nSOAP Fault

else dbOutageFlag = true

    alt smcLoggingEnabled = true
        APIM -> SMC : Log maintenance outage
    end

    APIM --> Consumer : HTTP 503\nSOAP Fault\nService unavailable

else Request Accepted

    APIM -> LA : Forward validated request

    alt smcLoggingEnabled = true
        LA -> SMC : Log START\n(UUID,\nTransactionId,\nConsumer,\nTimestamp)
    end

    loop For each Product (up to 20)\n[Parallel if supported]

        LA -> FA : Invoke Transform\n(Current Product)

        FA -> FA : Transform request\nfields to AS/400 format\n(XPCUSN, XPITMN,\nXPDTES, XPCMPN,\nXPDIVN, XPDPTN,\nXPWHSN)

        LA -> AS400 : JDBC CALL\nIDSPNDUR1.CX40K6B

        AS400 --> LA : Stored Procedure Result

        alt XOERROR = "Y"

            LA -> LA : Build Product Error Result

        else Pricing Returned

            LA -> LA : Map Pricing Response

        end

    end

    LA -> LA : Aggregate Product Results
    LA -> LA : Build PriceDataResponsev2
    LA -> LA : Remove Nil Fields

    alt smcLoggingEnabled = true
        LA -> SMC : Log END\n(Duration,\nStatus=Success)
    end

    LA --> APIM : PriceDataResponse

    APIM --> Consumer : HTTP 200 OK\nPriceDataResponse

end

group Unhandled Exception

    alt smcLoggingEnabled = true
        LA -> SMC : Log ERROR\n(Exception,\nStack Trace,\nTransactionId)
    end

    LA --> APIM : HTTP 500 / SOAP Fault

    APIM --> Consumer : HTTP 500 / SOAP Fault

end

note over APIM
APIM Responsibilities
• OAuth Authentication
• Schema Validation
• Business Validation
• Maintenance (dbOutageFlag)
• Request Routing
end note

note over LA
Logic App Responsibilities
• Orchestrate Processing
• Transform Request
• Invoke AS/400 Stored Procedure
• Aggregate Product Responses
• Build Final Response
• Optional SMC Logging
end note

@enduml
```

### 5.1.3 Coordination

This integration operates **synchronously**. The Sorted consumer sends a request and blocks waiting for the pricing response. The Logic App executes the full per-product SP iteration within the lifetime of the synchronous HTTP call.

#### 5.1.3.1 Transaction Boundaries

- **Transaction unit:** A single `PriceDataRequest` call (containing 1–20 products) constitutes one transaction.
- **Atomicity:** The request is not atomic at the product level. A product-level SP error (XOERROR = "Y") is reported in the response without aborting the remaining products. A hard JDBC failure during any product call causes the entire request to fail (HTTP 500).
- **Timeout:** The Logic App HTTP trigger has a maximum run duration. Individual SP calls have a 30-second JDBC timeout. For 20 products with sequential calls, the theoretical maximum processing time is 20 × 30s = 600s.

#### 5.1.3.2 State Management

- **Stateless per request:** No state is persisted within the integration layer between calls.
- **In-flight state:** The Logic App maintains the accumulated `PriceData[]` array in memory during execution of the for-each loop.

### 5.1.4 GoAnywhere Requirements

*NA*

### 5.1.5 Design Considerations

1. **Response v2 Schema** — The current response contract is `PriceDataResponsev2`, which includes additional fields (RRPorSRP, RetailMarginPercent, CartonExcludingGST, SingleUnitPriceExcGST) not in the original v1 schema. The AIS implementation targets v2 as the current contract.
2. **DB Outage Flag Management** — The flag is migrated from a TIBCO module property to an **APIM Named Value** (`dbOutageFlag`).
3. **Performance at Scale** — The target capacity is 20,000 calls/hour (1,000/min). Logic Apps Standard supports horizontal scaling.

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| **Azure Logic App** (`t3-met-b2b-realtimepricing-{env}-ae-logic`) | `Microsoft.Logic/workflows` | Core orchestration workflow that receives requests from APIM, validates input, invokes the AS/400 stored procedure, aggregates results, and returns the pricing response. |
| **App Service Plan** | `Microsoft.Web/serverfarms` | Hosts the Logic App Standard runtime. |
| **Azure API Management** (`t3-met-core-{env}-ae-apim`) | `Microsoft.ApiManagement/service` | Exposes REST endpoint, performs authentication, schema validation, protocol transformation, and request routing. |
| **Azure Application Gateway** (`t1-met-core-{env}-ae1-apg-01`) | `Microsoft.Network/applicationGateways` | Provides secure Layer to APIM. |
| **Azure Key Vault** (`t3b2b{env}ae1kv01`) | `Microsoft.KeyVault/vaults` | Stores AS/400 JDBC connection details and credentials. Accessed using Managed Identity. |
| **Platform Key Vault** (`t3enabling{env}ae1kv01`) | `Microsoft.KeyVault/vaults` | Stores shared platform secrets and configuration. |
| **Log Analytics Workspace** (`t3-met-b2b-realtimepricing-{env}-ae-law`) | `Microsoft.OperationalInsights/workspaces` | Central repository for SMC logs, diagnostics, and platform monitoring. |
| **AIS Spoke Virtual Network** (`t2-met-ais-{env}-ae1-net-01`) | `Microsoft.Network/virtualNetworks` | Provides network isolation and VNet Integration for the Logic App. |
| **Private Endpoints** | `Microsoft.Network/privateEndpoints` | Enables private connectivity to Key Vault, Storage Account, App Configuration, and SMC. |
| **Private DNS Zones** | `Microsoft.Network/privateDnsZones` | Resolves Azure PaaS services to Private Endpoint IP addresses. |
| **Network Security Groups** | `Microsoft.Network/networkSecurityGroups` | Controls inbound and outbound subnet traffic. |

#### 5.1.6.2 Services

The solution comprises the following services:

1. **APIM Pricing API** — Exposes the REST pricing endpoint to Sorted consumers; handles authentication, schema validation, and routing.
2. **Pricing Orchestrator Logic App** — Orchestrates the end-to-end pricing workflow (DB outage check, validation, per-product iteration, response aggregation).

#### 5.1.6.3 Audit, Logging & Exceptions

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

- Interface ID = `EAII-514`
- All significant events, including successful completions and errors, will be logged in SMC for monitoring and debugging purposes.

| **Sr. No.** | **API Name** | **Description** | **API URL** | **Method** |
| --- | --- | --- | --- | --- |
| 1 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The StartObservation API initiates the monitoring process for a business interface in AIS by creating an observation instance. | t3-met-{env}-ae-apim/smc/startObservation | POST |
| 2 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The ObservationPoint API is utilized to update the stage, status and other details of an ongoing observation for a business interface in AIS. | t3-met-{env}-ae-apim/smc/observationPoint | POST |

##### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interface are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to [https://metcash.atlassian.net/wiki/x/BQC_dg](https://metcash.atlassian.net/wiki/x/BQC_dg) .

It uses **SMC** for end-to-end transaction observability across the integration flow.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |

SMC is the primary observability platform for the integration. A unique **Transaction ID (UUID)** is generated for each request and propagated throughout the entire processing pipeline. SMC records the lifecycle of each transaction, enabling complete traceability from the inbound API request through Azure Logic Apps and external IBM AS/400 interactions.

##### 5.1.6.3.3 Exceptions

| Observation Stage | Exception Scenario | Exception Code | Exception Handling |
| --- | --- | --- | --- |
| Authentication (APIM) | Missing Authorization header | EAII514-001 | Return **HTTP 401 Unauthorized** (REST); log authentication failure to SMC. |
| Authentication (APIM) | Invalid or expired OAuth access token | EAII514-002 | Return **HTTP 401 Unauthorized** (REST); log authentication failure to SMC. |
| Authentication (APIM) | Insufficient OAuth permissions | EAII514-003 | Return **HTTP 403 Forbidden** (REST); log security event to SMC. |
| Schema Validation (APIM) | Invalid JSON schema | EAII514-004 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| Input Validation (APIM) | Company code not "MTT" | EAII514-005 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| Input Validation (APIM) | Invalid Pillar code | EAII514-006 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| Input Validation (APIM) | Invalid PriceDate format | EAII514-007 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| Input Validation (APIM) | More than 20 products | EAII514-008 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| DB Outage Check (APIM) | dbOutageFlag = true | EAII514-009 | Return **HTTP 503 Service Unavailable** (REST); log to SMC; **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Azure Inline Function | Request transformation failure | EAII514-010 | Log error event with exception details; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| AS/400 Connectivity | Unable to establish connection to AS/400 | EAII514-011 | Log connectivity failure and transaction history; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| AS/400 Authentication | Invalid AS/400 credentials | EAII514-012 | Log authentication failure; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| AS/400 Authorization | User not authorized to execute stored procedure | EAII514-013 | Log authorization failure; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| JDBC Driver | IBM AS/400 JDBC driver initialization failure | EAII514-014 | Log driver initialization error; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| SP Call | Stored procedure CX40K6B unavailable | EAII514-015 | Log stored procedure execution failure; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| SP Call | JDBC connection timeout or SQL exception | EAII514-016 | Log error event with fault details and transaction history; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| SP Call | Query timeout (30 seconds) exceeded | EAII514-017 | Log timeout error; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| SP Call | Product-level error (XOERROR = "Y") | EAII514-018 | Populate **ErrorMsg** in the corresponding **PriceData** element and continue processing the remaining products. Do **not** fail the overall request. |
| Response Processing | Failed to aggregate or serialize response | EAII514-019 | Log response processing failure; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Global Error Handler | Any unhandled exception | EAII514-099 | Log error event and transaction history; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |

##### 5.1.6.3.4 Service consumers

- **Sorted - IGA Portal** — places orders for IGA retailers via the ordering platform
- **Sorted - Campbells Portal** — places orders for Campbells customers
- **Sorted - C-Store Portal** — places orders for C-Store customers

All consumers invoke the same REST endpoint. Consumer identity is distinguished by the `Pillar` field in the request (`IGA`, `ALM`, `CCC`, `CSD`).

##### 5.1.6.3.5 Service Operations

| Operation | Protocol | Method | Endpoint | Description |
| --- | --- | --- | --- | --- |
| GetPricing (REST) | HTTPS | POST | `/eis/pricing/v1/getrealtimeprice` | Real-time pricing lookup — returns `PriceDataResponsev2` as JSON |

##### 5.1.6.3.6 Service Provider

| **Service / Component** | **Provider** | **Responsibility** |
| --- | --- | --- |
| CX40K6B Stored Procedure | Metcash — PE / AS/400 Platform team | Executes pricing calculation logic; returns pricing output fields per product |
| On-Premises Data Gateway | Metcash — Infrastructure / Cloud Platform team | Bridges Azure VNet to IBM AS/400 JDBC |

##### 5.1.6.3.7 Communications Data Structures

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Description** |
| --- | --- | --- | --- | --- |
| REST Consumer → APIM | PriceDataRequest (JSON) | NA | [Mapping - EAII-514](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) | REST JSON request from Sorted consumer |
| APIM → Logic App | PriceDataRequest (JSON) | NA | NA | Forwarded request after APIM auth/validation |
| Logic App → AS/400 SP | CX40K6B Input Parameters (JDBC) | CX40K6B Output Parameters (JDBC) | [Mapping - EAII-514](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) | Stored procedure JDBC call |
| Logic App → Consumer (REST) | NA | PriceDataResponsev2 (JSON) | [Mapping - EAII-514](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) | REST JSON response to Sorted consumer |

For all field-level mapping details, transformation logic, and sample payloads, refer to the [Mapping - EAII-514 - Realtime Pricing - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE).

##### 5.1.6.3.8 Input/Output

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input (REST) | POST PriceDataRequest | `PriceDataRequest` — JSON: Company (MTT), Pillar (IGA/ALM/CCC/CSD), Department, WarehouseId, CustomerId, PriceDate (YYYY-MM-DD), Product[] (max 20) | ![diagram](images/08.png)<br> <br>![diagram](images/05.png) |
| Output (REST) | PriceDataResponsev2 | JSON: Company, Pillar, Department, WarehouseId, CustomerId, PriceDate (echo); PriceData[] — per product: Product, ProductPrice, Allowance, UnitProductPrice, ErrorMsg (conditional), OriginalProductPrice, OriginalUnitProductPrice, RRPorSRP, RetailMarginPercent, CartonExcludingGST, SingleUnitPriceExcGST | ![diagram](images/08.png)<br> <br>![diagram](images/05.png) |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| IBM AS/400 PE CX40K6B | CALL IDSPNDUR1.CX40K6B | Input: XPCMPN, XPDIVN, XPDPTN, XPWHSN, XPCUSN, XPITMN, XPDTES, XPSFLG (all CHAR/DECIMAL).<br> <br>Output: XOTTLP, XOTAWP, XOLUCA, XOEMSG, XZPRCG, XZLUCA, XOPRCE, XOPRFP, XZPGST, XZPEXG, XOERROR. | N/A |

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | Realtime Pricing |
| Source Business Process | Realtime Pricing |
| Source Application | Sorted |
| Destination Business Process | PE |
| Destination Application | PE — Power Enterprise (AS/400) |
| Interface ID | EAII-514 |
| Interface Name | Realtime Pricing |
| Interface Type | Synchronous Request-Response |
| Interface DataStore | N/A |
| Tags | `{"pillar": "multi", "protocol": "REST", "target": "AS400"}` |
| Reference Keys | Transaction UUID, Company, Pillar, CustomerId, PriceDate |
| Notification Type | Email on error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-514 |
| Correlation Properties | Transaction UUID |
| Reprocessing Required | No |

#### 5.1.7.2 SMC Load Estimations

This section includes the corresponding SMC load estimations for this interface under normal and peak load scenarios. SMC logging is enabled on demand through a configuration flag; therefore, the load estimations apply only when SMC logging is enabled.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | 10,784 calls/hour (378 calls/minute) — current observed peak |
| Target capacity | 20,000 calls/hour (1,000 calls/minute) — to accommodate Christmas peak and post-Horizon growth |  |
| Average volume | High — service is heavily utilized throughout business hours; traffic is combined across IGA, Campbells, and C-Store portals |  |
| Seasonal considerations | Christmas peak drives highest volumes; planned AS/400 maintenance windows should use the `dbOutageFlag` for controlled degradation |  |
| Expected growth | Significant increase expected post-Horizon go-live as Enterprise Portal features migrate to Sorted, bringing additional IGA customers placing warehouse orders |  |
| Message Size | Average request | ~500 bytes (5 products) |
| Average response | ~2 KB (5 products) |  |
| Max request | ~1.5 KB (20 products) |  |
| Max response | ~8 KB (20 products) |  |

### 5.1.8 Monitoring

N/A

### 5.1.9 Reporting

N/A

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

| ID | Work Item Type | Title | Step Action | Step Expected |
| --- | --- | --- | --- | --- |
| **TC-001** | Test Case | **Verify Pricing API without Auth token** | Invoke Pricing API without a Bearer token | API returns **401 Unauthorized** with error code **TokenNotPresent**. Error is logged in SMC. |
| **TC-002** | Test Case | **Verify Pricing API with invalid/expired Auth token** | Invoke Pricing API with a malformed, expired, or invalid Bearer token | API returns **401 Unauthorized** with the appropriate authentication error. Error is logged in SMC. |
| **TC-003** | Test Case | **Verify Pricing API without Requester header** | Invoke Pricing API without the `Requester` header | API returns **400 Bad Request** with **Requester header is missing**. Error is logged in SMC. |
| **TC-004** | Test Case | **Verify Pricing API without RequesterSiteId header** | Invoke Pricing API without the `RequesterSiteId` header | API returns **400 Bad Request** with **RequesterSiteId header is missing**. Error is logged in SMC. |
| **TC-005** | Test Case | **Verify Pricing API with invalid RequesterSiteId** | Invoke Pricing API with an invalid `RequesterSiteId` | API returns **401 Unauthorized** with **TokenClaimValueMismatch**. Error is logged in SMC. |
| **TC-006** | Test Case | **Verify Pricing API with single valid product for IGA pillar** | Submit a pricing request with one valid product and `Pillar = IGA` | API returns **200 OK** with all pricing fields populated. Successful transaction is logged in SMC. |
| **TC-007** | Test Case | **Verify Pricing API with 20 valid products** | Submit a pricing request containing **20 valid products** | API returns pricing data for **all 20 products** successfully. |
| **TC-008** | Test Case | **Verify Pricing API with one invalid product** | Submit a pricing request with valid products and one invalid product number | Valid products return pricing; the invalid product contains an **ErrorMsg**. |
| **TC-009** | Test Case | **Verify Pricing API when dbOutageFlag is true** | Set `dbOutageFlag = true` and submit a valid pricing request | API returns **503 Service Unavailable** for REST without calling AS/400. |
| **TC-010** | Test Case | **Verify Pricing API with invalid Company code** | Submit a pricing request with `Company` other than **MTT** | API returns **400 Bad Request** with Company validation error. |
| **TC-011** | Test Case | **Verify Pricing API with invalid Pillar code** | Submit a pricing request with an invalid `Pillar` value | API returns **400 Bad Request** with Pillar validation error. |
| **TC-012** | Test Case | **Verify Pricing API with invalid PriceDate format** | Submit a pricing request with `PriceDate` not in **YYYY-MM-DD** format | API returns **400 Bad Request** with date format validation error. |
| **TC-013** | Test Case | **Verify Pricing API when AS/400 is unreachable** | Make the AS/400 backend unavailable and submit a valid pricing request | API returns **500 Internal Server Error** with connectivity error. Error is logged in App Insights and SMC. |
| **TC-015** | Test Case | **Verify Pricing API with zero products** | Submit a pricing request with an empty `Product` array | API returns the request context with an **empty PriceData array**. |
| **TC-016** | Test Case | **Verify Pricing API for ALM, CCC, and CSD pillars** | Submit valid pricing requests for **ALM**, **CCC**, and **CSD** | API returns the correct pricing data for each pillar. |
| **TC-017** | Test Case | **Verify Pricing API with invalid Company enum value** | Submit a request with `Company = MTTE` | API returns **400 Bad Request** with JSON schema enum validation error. |
| **TC-018** | Test Case | **Verify Pricing API with invalid Pillar enum value** | Submit a request with `Pillar = ABC` | API returns **400 Bad Request** with JSON schema enum validation error. |
| **TC-019** | Test Case | **Verify Pricing API with more than 20 products** | Submit a request containing **more than 20 products** | API returns **400 Bad Request** with max-items validation error. |
| **TC-020** | Test Case | **Verify Pricing API with invalid Product length** | Submit a request with a Product value exceeding the maximum allowed length | API returns **400 Bad Request** with Product length validation error. |
| **TC-021** | Test Case | **Verify Pricing API with missing Company** | Submit a request without the `Company` field | API returns **400 Bad Request** with required-property validation error. |
| **TC-022** | Test Case | **Verify Pricing API with missing request body** | Invoke Pricing API without a request body | API returns **400 Bad Request** with request body validation error. |

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![EAII-514-updated-1-Architecture Diagram.drawio (1)-20260721-070940.png](images/07.png)

## 6.2 Network Connectivity

![EAII-514-updated-1-Network Diagram.drawio (1)-20260721-071007.png](images/02.png)

## 6.3 Security

- Azure API Management enforces authentication OAuth2 for all inbound requests to the pricing endpoints.The current design already specifies OAuth 2.0 Bearer-token authentication for Sorted-to-APIM communication.

**OAuth 2.0 Configuration**

| Setting | Value |
| --- | --- |
| Grant Type | `Client Credentials` |
| Identity Provider | Microsoft Entra ID |
| Tenant ID | `{tenantId}` |
| Token Endpoint | `https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token` |
| OAuth Version | OAuth 2.0 / Microsoft Identity Platform v2.0 |
| Client ID | `{clientId}` |
| Client Authentication | Client ID and Client Secret |
| Client Secret | Secure credential; not documented in the TSD |
| Scope | `https://{clientId}.metcash.onmicrosoft.com/.default` |
| Token Type | Bearer access token |
| Token Lifetime | Approximately 1 hour |
| RequesterSiteId | `This will be defined based on the consumers` |
| Authentication Enforcement Point | Azure API Management |

**Authentication Flow**

The authentication flow is as follows:

1. The Sorted consumer application requests an access token from Microsoft Entra ID using the OAuth 2.0 Client Credentials grant.
2. The token request is sent to: `https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token`
3. The request includes the configured Client ID, client credential, and the following scope: `https://{clientId}.metcash.onmicrosoft.com/.default`
4. Microsoft Entra ID authenticates the application and issues an OAuth 2.0 Bearer access token.
5. The access token has an approximate validity period of one hour.
6. The consumer invokes: `POST /eis/pricing/v1/getrealtimeprice` and supplies the token using the HTTP Authorization header: `Authorization: Bearer <access-token>`
7. APIM validates the access token before performing request schema and business validation.
8. Only successfully authenticated requests are forwarded for subsequent processing.

**Token Validation**

APIM shall validate the OAuth access token for every inbound request.

The following validations shall be applied:

| Validation | Requirement |
| --- | --- |
| Token signature | Must be cryptographically valid and issued by Microsoft Entra ID |
| Issuer | Must correspond to the approved Metcash Microsoft Entra tenant |
| Tenant | `{tenantId}` |
| Audience | Must match the audience configured for the approved API application registration |
| Expiry (`exp`) | Token must not be expired |
| Client identity | Token must represent an authorised application |
| Scope/Application permission | Must correspond to the configured API access using the `.default` scope |

The final accepted `aud` value shall be configured in the APIM token-validation policy using the value present in an approved access token issued for the API.

An access token that is missing, malformed, expired, issued by an untrusted issuer, or intended for an invalid audience shall be rejected with:

**HTTP 401 – Unauthorized**

Where authentication succeeds but the application does not have the required API permission, APIM shall return:

**HTTP 403 – Forbidden**

The TSD already distinguishes missing/invalid tokens as `401` and insufficient OAuth permissions as `403`.

**Token Lifetime**

The issued OAuth access token is valid for approximately **one hour**.

APIM validates the token expiry for every API request. An expired access token shall not be accepted.

The consumer is responsible for obtaining a new valid access token from Microsoft Entra ID when the existing token expires.

**RequesterSiteId Validation**

`RequesterSiteId` validation is performed by APIM before the request is forwarded to the Logic App.

The current test specification already contains scenarios for missing and invalid `RequesterSiteId` values.

The following behaviour applies:

| Scenario | Expected Behaviour |
| --- | --- |
| `RequesterSiteId` missing | HTTP 400 Bad Request |
| Valid `RequesterSiteId` | Continue request processing |
| Invalid `RequesterSiteId` | Request rejected according to APIM validation policy |
| Invalid/expired OAuth token | HTTP 401 Unauthorized |
| Valid token without required API permission | HTTP 403 Forbidden |

`RequesterSiteId` does not replace OAuth authentication. The authenticated caller identity is derived from the successfully validated OAuth access token.

### Pillar Validation

The `Pillar` field is part of the API request payload and represents the business context for the realtime pricing enquiry.

Pillar validation is performed using the **REST JSON schema specification** enforced by Azure API Management.

The supported Pillar values are:

- `IGA`
- `ALM`
- `CCC`
- `CSD`

The schema shall restrict the `Pillar` field to these approved enumeration values.

Example schema definition:

```
{
  "Pillar": {
    "type": "string",
    "enum": [
      "IGA",
      "ALM",
      "CCC",
      "CSD"
    ]
  }
}
```

If a request contains a Pillar value outside the approved enumeration, APIM shall reject the request with:

**HTTP 400 – Bad Request**

The request shall not be forwarded to the Logic App or IBM AS/400.

**APIM-to-Logic-App Authentication**

Azure API Management invokes the EAII-514 Logic App HTTP trigger using **Logic App SAS (Shared Access Signature) authentication**.

The Logic App is configured as an **APIM Backend**, with the Logic App base URL maintained separately from the SAS authentication parameters.

The Logic App callback parameters `api-version`, `sp`, `sv`, and `sig` are configured as **backend query credentials**. The security-sensitive `sig` value is referenced through an APIM Named Value backed by **Azure Key Vault**.

The actual SAS signature is therefore not hardcoded in the APIM policy, backend definition, source code, application configuration, or TSD.

This approach centralises management of the SAS credential in Azure Key Vault while allowing APIM Backend configuration to automatically apply the required Logic App authentication parameters when forwarding requests.

**Authentication Configuration**

| Attribute | Configuration |
| --- | --- |
| Source | Azure API Management |
| Destination | EAII-514 Logic App HTTP Trigger |
| Protocol | HTTPS |
| Port | 443 |
| Authentication | Logic App SAS / Shared Access Signature |
| Backend Configuration | APIM Backend |
| SAS Parameters | `api-version`, `sp`, `sv`, `sig` |
| SAS Signature Storage | Azure Key Vault |
| SAS Reference | Key Vault-backed APIM Named Value |
| SAS Hardcoded in Source Code | No |
| Transport Encryption | TLS 1.2+ |
| Backend Access | Through APIM |

**APIM Backend Configuration**

The Logic App is registered as an APIM Backend. The backend configuration defines the Logic App base endpoint and the required SAS query credentials.

Conceptually, the backend configuration follows the pattern below:

```
- name: t3-met-b2b-realtimepricing-logic-app
  properties:
    description: "B2B RealTimePricing Logic App GetPricingData Workflow"
    displayName: B2B-RealTimePricing-Logic-App-GetPricingData-Workflow
    url: "https://t3-met-b2b-realtimepricing-{env}-ae-logic.<ase-domain>:443/api"
    protocol: http
  credentials:
    query:
      api-version:
      - "{{LogicApp-Workflow-API-Version}}"
      sp:
      - "{{LogicApp-Workflow-SP}}"
      sv:
      - "{{LogicApp-Workflow-SV}}"
      sig:
      - "{{b2b-realtimepricing-logic-app-getpricingdata-workflow-sig}}"
```

The backend URL contains only the Logic App base endpoint. The SAS parameters required to authenticate the Logic App invocation are maintained separately under the APIM Backend `credentials.query` configuration.

The `sig` parameter references:

```
{{b2b-realtimepricing-logic-app-getpricingdata-workflow-sig}}
```

This APIM Named Value is backed by the corresponding Azure Key Vault secret.

**Authentication Flow**

The APIM-to-Logic-App authentication flow is as follows:

1. The Sorted consumer submits the realtime pricing request to Azure API Management.
2. APIM performs inbound OAuth authentication, schema validation, business validation, and the configured API policy checks.
3. APIM resolves the configured `t3-met-b2b-realtimepricing-logic-app` backend.
4. The APIM Backend configuration automatically applies the required Logic App query credentials:
  - `api-version`
  - `sp`
  - `sv`
  - `sig`

5. The `sig` backend credential is resolved through the configured Key Vault-backed APIM Named Value.
6. APIM forwards the validated request to the Logic App over HTTPS.
7. The Logic App runtime validates the supplied SAS parameters and signature.
8. When SAS validation succeeds, the `GetPricingData` workflow is executed.
9. Requests with missing or invalid SAS credentials are rejected by the Logic App runtime.

The application/API policy does **not explicitly construct the SAS URL or retrieve the SAS signature**. SAS authentication is handled as part of the APIM Backend configuration..

- Logic App uses **Managed Identities** to authenticate to Azure Key Vault, Azure App Configuration - no stored credentials in application configuration.
- Public access to the Logic App HTTP trigger is denied; access is via APIM only.
- Azure Key Vault stores all secrets (AS/400 JDBC connection string, AS/400 username/password).
- RBAC controls access to all Azure resources; principle of least privilege applied.
- All communication between Azure components and to/from Sorted consumers is via HTTPS/TLS 1.2+.

**Key Vault Secret**

The solution stores all sensitive configuration and credentials in Azure Key Vault. The Azure Logic App accesses the required secrets using its Managed Identity with the **Key Vault Secrets User** role. No secrets are stored in application configuration or source code.

| Key Vault | Purpose |
| --- | --- |
| `t3b2b{env}ae1kv01` | Application Key Vault containing integration-specific secrets required by the Pricing solution. |
| `t3enabling{env}ae1kv01` | Shared platform Key Vault managed by the Enabling Platform team, containing shared platform configuration and platform-managed secrets where applicable. |

### 6.3.1 Data Handling and Encryption

- **Data Classification:** Internal — commercially sensitive pricing data (wholesale costs, margins, promotional pricing), but no PII.
- **In transit:** All data encrypted in transit via TLS 1.2+ (HTTPS for all API calls; JDBC over encrypted channel to AS/400 where supported by the on-premises gateway).
- **At rest:** No pricing response payload data is persisted in the integration layer. Only transaction metadata (UUID, timestamps, status) is stored in SMC.
- **Logging restriction:** Full pricing response payloads (product prices, margins, allowances) are **not** logged in SMC in production. Only metadata fields are logged.
- **Customer IDs:** Treated as internal account references (not PII). Customer IDs appear in structured logs at metadata level only (not full payloads).

## 6.4 Infrastructure Support

*NA*

## 6.5 Infrastructure Requirements

**Logic App Infrastructure**

| Resource | Azure Resource Provider | SKU / Tier | Workflow Type | Hosting | Purpose |
| --- | --- | --- | --- | --- | --- |
| Azure Logic App | `Microsoft.Logic/workflows` | Standard | Stateless | Azure Logic Apps Standard (App Service Plan) | Hosts the pricing orchestration workflow responsible for request validation, product iteration, AS/400 invocation, response transformation, and error handling. |
| App Service Plan | `Microsoft.Web/serverfarms` | Standard | N/A | Dedicated | Provides the compute hosting environment for the Logic App Standard runtime. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **Azure Logic App** | **t3-met-b2b-realtimepricing-{env}-ae-logic** | New |
| **Azure Key Vault** | **t3b2b{env}ae1kv01**<br> <br>**t3enabling{env}ae1kv01** | Existing |
| **Resource Group** | **t3-met-ais-{env}-ae1-rsg-b2b** | Existing |
| **Subscription** | **COREIT-SERVICES-AIS-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / SENS** | Existing |

**{env} -** dv1, st1, ut1 and prd

**Workflow Details**

- **Workflow Name:** `PricingFromPE`
- **Workflow Type:** Stateless.
- **Runtime:** Azure Logic Apps Standard.
- **Hosting Model:** Dedicated App Service Plan.
- **Number of Workflows:** One orchestration workflow

**Azure API Management Infrastructure**

Azure API Management (APIM) serves as the secure gateway for the Pricing API, exposing REST endpoint to Sorted consumers while enforcing authentication, policy execution, request validation, routing, and observability.

**Azure API Management (APIM) Named Values** are used to externalize runtime configuration values required by the API gateway. APIM reads these values during policy execution to control request processing without requiring policy changes or redeployment.

Configuration includes, but is not limited to:

- `dbOutageFlag`

The `dbOutageFlag` is evaluated by APIM during request processing. When the flag is enabled, APIM immediately returns an **HTTP 503 Service Unavailable** response (REST) without forwarding the request to the Logic App.

| Resource | Azure Resource Provider | SKU | Purpose |
| --- | --- | --- | --- |
| Azure API Management | `Microsoft.ApiManagement/service` | Standard | Exposes the Pricing API, performs request validation, authentication, policy enforcement, request/response transformation and forwards requests to the Azure Logic App. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **APIM** | **t3-met-core-{env}-ae-apim** | Existing |
| **Resource Group** | **t3-met-core-{env}-ae1-rsg-apim** | Existing |
| **Subscription** | **COREIT-SERVICES-HUB-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / HSENS** | Existing |

**API Endpoints**

| **API** | **Endpoint** |
| --- | --- |
| REST Pricing API | `eis/pricing/v1/getrealtimeprice` |

**APIM Policies**

Azure API Management policies are used to implement:

- OAuth 2.0 authentication and authorization
- Request validation
- Backend routing to the Azure Logic App
- Error handling and standardized fault responses
- Logging with SMC

**Virtual Network Architecture**

The Pricing integration is deployed within the enterprise **Hub-and-Spoke** network architecture. Azure API Management is deployed in the **Hub Virtual Network**, while the Azure Logic App and supporting integration resources are deployed in the **AIS Spoke Virtual Network**. Secure communication between Azure resources and IBM AS/400 is achieved through Virtual Network Integration, Private Endpoints, Network Security Groups (NSGs), Route Tables, and enterprise networking controls.

**App Gateway Details**

| Resource | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| Azure Application Gateway | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| Azure API Management | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- |
| AIS Spoke Virtual Network | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | PRD | t2-met-ais-prd-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Logic App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway and secure routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**SENS (Logic App Application Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Logic Apps** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | **t3-met-b2b-realtimepricing-dv1-ae-logic** |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | **t3-met-b2b-realtimepricing-st1-ae-logic** |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | **t3-met-b2b-realtimepricing-ut1-ae-logic** |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | **t3-met-b2b-realtimepricing-prd-ae-logic** |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**App Gateway:-**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Managed Identity**

The Azure Logic App uses a System-Assigned Managed Identity. The identity is
 automatically created and managed by Azure, and its lifecycle is tied
 exclusively to the Logic App resource. When the Logic App is deleted, the
 identity is automatically deleted with it.

A User-Assigned Managed Identity (Microsoft.ManagedIdentity/userAssignedIdentities)
 was considered but was not selected for this integration. The System-Assigned
 model is preferred here because:

- The identity is used solely by this Logic App and no other resource.
- There is no requirement to share the same identity across multiple Azure resources.

No credentials, client secrets, or certificates are stored within the
 application. All Azure service authentication is performed at runtime via the
 System-Assigned Managed Identity token.

**Identity and Access Control (RBAC)**

The Logic App authenticates to Azure services using Microsoft Entra ID and its Managed Identity. The following Azure RBAC roles are assigned based on the principle of least privilege.

**Complete RBAC Assignments (**`Microsoft.Authorization/roleAssignments`**):**

| Source | Target | Identity | RBAC Role |
| --- | --- | --- | --- |
| `t3-met-b2b-realtimepricing-{env}-ae-logic` | `t3b2b{env}ae1kv01` | System-Assigned Managed Identity | Key Vault Secrets User |
| `t3-met-b2b-realtimepricing-{env}-ae-logic` | `t3-met-b2b-realtimepricing-{env}-ae-ai` | System-Assigned Managed Identity | Monitoring Metrics Publisher |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

| Private Endpoint Name | Target Resource | Sub-resource | Private Zone | New / Existing |
| --- | --- | --- | --- | --- |
| `t3-met-b2b-realtimepricing-{env}-ae-pe-kv` | `t3b2b{env}ae1kv01` (Azure Key Vault) | `vault` | `privatelink.vaultcore.azure.net`<br> <br>`t3b2b{env}ae1kv01.vault.azure.net` | Existing |

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Logic App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`

# 7 Communication Overview

## 7.1 Communication Components

![EAII-514-updated-1-Communication-Diagram.drawio-20260721-071336.png](images/06.png)

| Component | Source | Destination | Protocol | Port | Authentication |
| --- | --- | --- | --- | --- | --- |
| Sorted → APIM | Sorted consumer systems | Azure APIM | HTTPS | 443 | OAuth 2.0 Bearer token |
| APIM → Logic App | Azure APIM | Logic App HTTP trigger | HTTPS | 443 | SAS URL (shared access signature) |
| Logic App → App Configuration | Logic App | Azure App Configuration | HTTPS | 443 | System-Assigned Managed Identity |
| Logic App → Key Vault | Logic App | Azure Key Vault | HTTPS | 443 | System-Assigned Managed Identity |
| Logic App Gateway → AS/400 | Logic App | IBM AS/400 PE | JDBC | 446 | Username/Password (from Key Vault) |
| Logic App → SMC | Logic App | SMC (via APIM) | HTTPS | 443 | OAuth 2.0 |

# 8 Data Architecture

## 8.1 Data Model

*NA*

## 8.2 Stored Procedures

*NA*

## 8.3 Stored Procedure Triggers

*NA*

## 8.4 Database Technical Specification

**Azure SQL Database:** Not required for this integration. No Azure SQL Server (`Microsoft.Sql/servers`) or Azure SQL Database (`Microsoft.Sql/databases`) resource is provisioned for EAII-514. The sole external data source is the IBM AS/400 Power Enterprise system.

**SMC Datastore:** The SMC platform manages its own backend datastore independently of this integration. Transaction metadata written to SMC via `startObservation` and `observationPoint` APIs is governed by the SMC platform's own data retention policy.

**IBM AS/400 PE:** The source of truth for all pricing data. Connection details:

| Attribute | Value |
| --- | --- |
| Protocol | JDBC |
| Driver | `com.ibm.as400.access.AS400JDBCDriver` |
| Stored Procedure | `CX40K6B` |
| Schema | `IDSPNDUR1` |
| Query Timeout | 30 seconds |
| Login Timeout | 30 seconds |
| Max Connections (pool ceiling) | 1,000 |
| Username Secret | Key Vault: `as400-username` |
| Password Secret | Key Vault: `as400-password` |
| Environment Mapping | DV1 → AS/400 Dev LPAR;<br> <br>ST1 → AS/400 SIT LPAR;<br> <br>UT1 → AS/400 UAT LPAR;<br> <br>PRD → AS/400 Production LPAR |

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

*NA*

### 8.5.2 Data Backup

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

*NA*

#### 8.5.3.2 State process for data/system destruction

*NA*

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

NA

## 9.2 Deployment Preference

NA

## 9.3 Deployment Environment Migration

*All source code is managed under source control (currently Github or Azure Devops Repo).*

*Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure.*

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PRD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.

Detailed deployment and rollback procedures for EAII-514 are maintained in the approved **Deployment Runsheets** for each environment.

The runsheets provide the step-by-step execution sequence required to deploy the integration components, validate the deployment, and restore the previous working state if deployment or post-deployment validation fails.

The deployment runsheets include, as applicable:

- Pre-deployment checks and prerequisites;
- Environment-specific configuration updates;
- Post-deployment tests and validation;
- Rollback procedures, including restoration of the previously deployed configuration/version.

# 10 Disaster Recovery

*Capture any specific disaster recovery requirements for the solution here.*

# 11 Support Documentation

![diagram](images/03.png)

# 12 Limitations and Constraints

NA

# 13 Assumptions

- The IBM AS/400 CX40K6B stored procedure will not be modified as part of this migration.
- The Sorted consumer teams are responsible for updating their client configuration to the new AIS endpoint paths (`eis/pricing/v1/getrealtimeprice`) before cutover.

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

# 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/10.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |
