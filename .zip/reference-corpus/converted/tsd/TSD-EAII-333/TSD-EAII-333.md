<!-- Source: Technical+Specification+-+EAII-333+-+Storeline+to+CCC.doc -->
<!-- Title: Technical Specification - EAII-333 - Storeline to CCC -->

# Technical Specification - EAII-333 - Storeline to CCC

**Table of Contents**

- 1 Document Overview
  - 1.1 Background
  - 1.2 Document Purpose
  - 1.3 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope

- 3 Compliance
  - 3.1 Architecture Principles
  - 3.2 Standards, Guidelines and Patterns

- 4 Requirements Overview
  - 4.1 Business Process Requirement and Integration
    - 4.1.1 Process Diagram from FSD
    - 4.1.2 Functional Specification Document

  - 4.2 Technical standard and requirements
  - 4.3 Required Components
  - 4.4 Environmental Requirement

- 5 Integration Overview and Implementation
  - 5.1 EAII-333 - Campbells Payment
    - 5.1.1 As-is Process(es)
      - 5.1.1.1 Description of Process(es)

    - 5.1.2 Proposed Process(es)
      - 5.1.2.1 Description of Process(es)
      - 5.1.2.2 Process Flow Diagram
      - 5.1.2.3 Sequence Diagram
      - 5.1.2.4 PlantUML

    - 5.1.3 Coordination
      - 5.1.3.1 Transaction Boundaries
      - 5.1.3.2 State Management

    - 5.1.4 GoAnywhere Requirements
    - 5.1.5 Design Considerations
    - 5.1.6 Service High Level Design
      - 5.1.6.1 Component List
      - 5.1.6.2 Services
      - 5.1.6.3 EAII-333 Payment Capture API
        - 5.1.6.3.1 Logging
        - 5.1.6.3.2 Audit
        - 5.1.6.3.3 Exceptions
        - 5.1.6.3.4 Service consumers
        - 5.1.6.3.5 Service Operations
        - 5.1.6.3.6 Service Provider
        - 5.1.6.3.7 Communications Data Structures
        - 5.1.6.3.8 Input/Output
        - 5.1.6.3.9 Fulfillment Services

    - 5.1.7 SMC Onboarding
      - 5.1.7.1 Integration Onboarding
      - 5.1.7.1 SMC Load Estimations

    - 5.1.8 Monitoring
    - 5.1.9 Reporting
    - 5.1.10 Integration and Testing Requirements
      - 5.1.10.1 Development and Integration Strategy
      - 5.1.10.2 Unit Testing

- 6 Architecture Overview
  - 6.1 Physical Architecture Diagram
  - 6.2 Network Connectivity
  - 6.3 Security
    - 6.3.1 Data Handling and Encryption

  - 6.4 Infrastructure Support
  - 6.5 Infrastructure Requirements
  - 6.6 Infrastructure Resource Details

- 7 Communication Overview
  - 7.1 Communication Components

- 8 Data Architecture
  - 8.1 Data Model
  - 8.2 Stored Procedures
  - 8.3 Stored Procedure Triggers
  - 8.4 Database Technical Specification
  - 8.5 Data Retention
    - 8.5.1 Data Retention Procedures
      - 8.5.1.1 Data storage and retention

    - 8.5.2 Data Backup
    - 8.5.3 Data Destruction Procedures
      - 8.5.3.1 Data destruction metrics and timeframes
      - 8.5.3.2 State process for data/system destruction

- 9 Deployment and Monitoring Considerations
  - 9.1 Transition Period
  - 9.2 Deployment Preference
  - 9.3 Deployment Environment Migration

- 10 Disaster Recovery
- 11 Support Documentation
- 12 Limitations and Constraints
- 13 Assumptions
- 14 Reference Documents and Architecture
  - 14.1 External Dependencies

- 15 TSD Approval Checklist

| **TSD Author** |  |
| --- | --- |

| **Document Approver** | **Approver Role** |
| --- | --- |
| [Magesh.Parthasarathy](https://metcash.atlassian.net/wiki/people/61e640f385a2d60070401e54?ref=confluence) | Integration Platform Representative |
| [Sue Homsuwan](https://metcash.atlassian.net/wiki/people/62f1c17bb5b801a9aff0a845?ref=confluence) | Integration Platform Operations |
| [Magesh.Parthasarathy](https://metcash.atlassian.net/wiki/people/61e640f385a2d60070401e54?ref=confluence) | Solution Architect |
| [Mohanraj Vengiduswamy](https://metcash.atlassian.net/wiki/people/712020:cebae083-d404-4818-8553-34466e871c59?ref=confluence) | Test Manager |

# 1 Document Overview

## 1.1 Background

This Technical Specification documents the re-implementation of the EAII-333 Campbells Payment integration on Azure Integration Services (AIS). The integration is being migrated from TIBCO BusinessWorks Container Edition (BWC) to Azure API Management (APIM) as part of the enterprise integration platform modernisation.

The Campbells Payment integration supports the payment capture process for the Campbells Retailers division. After warehouse pick and pack is complete, Storeline (the legacy warehouse/POS system) sends a payment capture request which is forwarded to Sorted (SAP Commerce Cloud / Braintree payment gateway) for payment processing. The result is returned synchronously to Storeline.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the **Campbells Payment Capture** service between **Storeline** (source) and **Sorted / SAP Commerce Cloud** (target) via **Azure API Management**.

## 1.3 Glossary

| **Term** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| APIM | Azure API Management - the specific AIS component used for this integration |
| Braintree | Payment gateway provider used by SAP Commerce Cloud for payment processing |
| BW6 | BusinessWorks Container Edition - legacy TIBCO deployment model for this service |
| Campbells Portal | Customer-facing web storefront where Campbells retailers place orders |
| EAII | Enterprise Application Integration Interface - Metcash interface catalogue identifier |
| PE | Platform Engine - order management system that routes orders from the Campbells portal to Storeline |
| SAP Commerce Cloud | E-commerce platform (formerly Hybris) - the technology underpinning Sorted |
| SOAP | Simple Object Access Protocol - XML-based messaging protocol |
| Sorted | SaaS platform running SAP Commerce Cloud that processes payments for the Campbells division |
| Storeline | Legacy warehouse and point-of-sale system that initiates payment capture after order pick and pack |
| SMC | Service Management Console - monitoring and audit platform |

# 2 Scope

## 2.1 In Scope

- Payment capture request processing from Storeline to Sorted (SAP Commerce Cloud) via APIM
- Protocol translation from SOAP/XML to REST/JSON
- Request field mapping (orderId → URL path parameter, paymentAmount → captureAmount query parameter)
- Scientific notation to decimal conversion for paymentAmount (e.g., `2.9674E4` → `29674`)
- Response interpretation and error message formatting (responseCode evaluation)
- Synchronous request-reply pattern
- Audit logging (begin, end, warning, error events) via Application Insights
- TLS/SSL secured communication with the target system (mutual TLS with client certificate)
- Error handling with structured SOAP fault responses

## 2.2 Out of Scope

- Payment authorization (pre-capture step handled elsewhere)
- Payment refund processing
- Order management or order status updates
- Customer account management
- Batch payment processing
- The legacy SOAP-to-SOAP path (no longer active - not migrated)
- **Known Issue NOT addressed:** The `requestTimeout` field behavior - timeouts will continue to be managed at the HTTP client configuration level, not dynamically from the request payload

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

- *<Enterprise Pattern Catalogue>*
- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

Refer to FSD Section 3.1.1.1 Process Diagram.

![image-20260615-233229.png](images/06.png)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-333 - Storeline to CCC | [Functional Specification - EAII-333 - Campbells Retailers to Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3061612545/Functional+Specification+-+EAII-333+-+Campbells+Retailers+to+Sorted) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol
- WSDL 1.1 for SOAP web service contract
- SOAP 1.2 for SOAP web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization
- X509 digital certificate based for authentication, authorization as well as message encryption

## 4.3 Required Components

The following components are required for this integration:

- Azure App Service Plan Azure API Management service (APIM)
- Azure Key Vault (for client certificates and secrets)
- Azure Application Insights (for logging and monitoring)
- Azure Log Analytics workspace
- Azure Virtual Network (for network isolation)

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DEV)
- System Integration Testing (SIT)
- User Acceptance Test (UAT)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).

# 5 Integration Overview and Implementation

## 5.1 **EAII-333** - Campbells Payment

*Duplicate this section for each interface in the TSD*

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The legacy implementation runs on TIBCO BW6. The entry point is `RequestPayment.bwp` which exposes a SOAP endpoint (`/PaymentRequestService`) on port 7505. It receives payment capture requests from Storeline, generates a transaction ID, logs the start event, then calls the `InvokeHybrisPaymentService.bwp` subprocess which performs the REST POST to SAP Commerce Cloud's Braintree payment capture API. The JSON response is parsed, the response code is evaluated, and the result is returned synchronously as a SOAP response.

Key artifacts:

- `RequestPayment.bwp` - Main entry point (SOAP service)
- `InvokeHybrisPaymentService.bwp` - Active subprocess (REST call to SAP Commerce Cloud)
- `InvokeHybrisPaymentRequestService.bwp` - Legacy subprocess (inactive SOAP-to-SOAP, not migrated)
- `HybrisPaymentRequestWSDL.wsdl` - Inbound SOAP contract
- `interface.PaymentRequestService-PaymentRequest.xsd` - Intermediate JSON/XML schema
- `HybrisPaymentServiceParameterSchema.xsd` - REST URL parameters schema

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

**Process Steps:**

1. Storeline sends the SOAP payment capture request to the APIM endpoint using the APIM internal URL, as it does not support OAuth authentication.
2. APIM `inbound` policy extracts fields from SOAP XML body using XPath (customerId, orderId, paymentAmount, requestTimeout)
3. APIM generates a unique transaction ID (`Guid.NewGuid()`)
4. APIM converts `paymentAmount` from scientific notation to decimal (e.g., `2.9674E4` → `29674`)
5. APIM rewrites the URL to: `/occ/v2/campbellsretailersspa/orders/{orderId}/braintree/paymentcapture?captureAmount={captureAmount}`
6. APIM sends HTTP POST with empty body to SAP Commerce Cloud backend (mutual TLS)
7. APIM `outbound` policy parses JSON response
8. APIM evaluates `responseCode`:

- If `responseCode = 1` (success): Logs "End" event, constructs SOAP response
- If `responseCode = 2` (error): Formats message as `"Error {extendedErrorCode} - {message}"`, logs "Warning" event, constructs SOAP response
- If other `responseCode`: Logs "Warning" event, passes message through as-is, constructs SOAP response

1. APIM `on-error` policy: Logs "Error" event with exception details, returns SOAP fault to caller, similarly logs success.

#### 5.1.2.2 Process Flow Diagram

![image-20260708-093644.png](images/05.png)

#### 5.1.2.3 Sequence Diagram

![image-20260722-080112.png](images/03.png)

#### 5.1.2.4 PlantUML

```
@startuml
title EAII-333 - Campbells Payment Capture - Storeline to Sorted\nProposed AIS Architecture

skinparam backgroundColor #FEFEFE
skinparam sequenceArrowThickness 2
skinparam participantPadding 20
skinparam boxPadding 10

skinparam participant {
  BackgroundColor #E8F4FD
  BorderColor #0066CC
  FontStyle bold
}

skinparam note {
  BackgroundColor #FFFDE7
  BorderColor #FBC02D
}

box "Source (On-Premises)" #F5F5F5
participant "Storeline\n(Warehouse/POS)" as SL
end box

box "Azure Integration Services" #E3F2FD
participant "Azure APIM" as APIM
participant "SMC\n(Monitoring)" as SMC
end box

box "External SaaS" #FFF8E1
participant "SAP Commerce Cloud\n(Sorted / Braintree)" as SCC
end box

== Request Received ==

SL -> APIM : SOAP/HTTPS Request\n(paymentRequest operation)\n- customerId, orderId\n- paymentAmount, requestTimeout
activate APIM

APIM -> APIM : Validate SOAP request\nagainst WSDL schema

alt Validation fails
    APIM --> SL : SOAP Fault\n(Schema validation error)
else Validation passes
end

APIM -> APIM : Parse SOAP XML (XPath)\nExtract fields\nGenerate Transaction ID\nConvert paymentAmount\n(2.9674E4 → 29674)

== Backend Call ==

APIM -> APIM : Construct REST URL:\nPOST /occ/v2/campbellsretailersspa\n/orders/{orderId}/braintree\n/paymentcapture?captureAmount={amount}

APIM -> SCC : HTTP POST\nMutual TLS, Port 443
activate SCC
SCC -> SCC : Process payment capture\nvia Braintree gateway
SCC --> APIM : JSON Response\n{responseCode, extendedErrorCode, message}
deactivate SCC

== Response Evaluation ==

alt responseCode = 1 (Success)
    APIM -> APIM : Build SOAP response\n(pass-through fields)
else responseCode = 2 (Error with code)
    APIM -> APIM : Format message:\n"Error {extendedErrorCode} - {message}"
    APIM -> APIM : Build SOAP response
else responseCode = other (General failure)
    APIM -> APIM : Build SOAP response\n(message as-is)
end

== Response ==

alt responseCode = 1
    APIM -> SMC : Log **Success**
else responseCode != 1
    APIM -> SMC : Log **Failure**
end

APIM --> SL : SOAP/HTTPS Response\n<paymentResponse>\n  responseCode, extendedErrorCode, message\n</paymentResponse>
deactivate APIM

== Error Handling ==

note over APIM, SMC
  **SMC (Custom Monitoring Tool)**
  - APIM posts success or failure after response evaluation
  - Exception alerts on failure
  - Notification: IntegrationSupport@metcash.com
end note

@endum
```

### 5.1.3 Coordination

This integration operates **synchronously**. Storeline sends a SOAP request and blocks until it receives a response. APIM processes the request in a single policy execution pipeline (inbound → backend → outbound) without any asynchronous handoff.

#### 5.1.3.1 Transaction Boundaries

The transaction boundary is a single HTTP request-response cycle:

- Storeline → APIM → SAP Commerce Cloud → APIM → Storeline
- No intermediate state is persisted
- No message queuing or retry at the integration layer
- If any step fails, a SOAP fault is returned immediately to Storeline

#### 5.1.3.2 State Management

N/A - This is a stateless synchronous proxy. No state is maintained between requests.

### 5.1.4 GoAnywhere Requirements

*Leave blank if GoAnywhere is not used in this interface*

### 5.1.5 Design Considerations

1. **APIM-only implementation**: Given the simplicity of this integration (synchronous proxy with field mapping and conditional response formatting), APIM policies alone are sufficient. No Logic Apps or Function Apps are required, reducing operational complexity and cost.
2. **SOAP endpoint compatibility**: APIM will expose the same SOAP endpoint path (`/PaymentRequestService`) and operation (`paymentRequest`) to maintain backward compatibility with Storeline. No changes required on the source system.
3. **Scientific notation handling**: The `paymentAmount` field arrives in scientific notation (e.g., `2.9674E4`). APIM policy will cast this to a decimal value (`29674`) before passing as the `captureAmount` query parameter, matching the legacy TIBCO behaviour.
4. **Mutual TLS**: The client certificate for SAP Commerce Cloud authentication will be stored in Certificate store and referenced by the APIM backend entity configuration.
5. **Error message formatting**: The conditional logic for `responseCode = 2` (format as "Error {extendedErrorCode} - {message}") will be implemented in the outbound policy using C# expressions within a `choose`/`when` block.
6. **Customer ID not forwarded**: The `customerId` is extracted for logging purposes only and is NOT sent to the target system. The `orderId` alone is sufficient for SAP Commerce Cloud to identify the transaction.
7. **requestTimeout not used dynamically**: The `requestTimeout` value from the SOAP request is not used to dynamically control APIM's backend timeout. Timeout is configured statically on the APIM backend entity (aligned with legacy behaviour).

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| **Interface ID** | **Process** | **Component** | **Component Type** | **Change Type** | **Repository** |
| --- | --- | --- | --- | --- | --- |
| EAII-333 | Campbells Payment Capture | APIM API Definition | API | New | Azure DevOps |
| EAII-333 | Campbells Payment Capture | APIM Policy (Inbound) | Policy XML | New | Azure DevOps |
| EAII-333 | Campbells Payment Capture | APIM Policy (Outbound) | Policy XML | New | Azure DevOps |
| EAII-333 | Campbells Payment Capture | APIM Policy (On-Error) | Policy XML | New | Azure DevOps |
| EAII-333 | Campbells Payment Capture | APIM Backend Entity | Backend Config | New | Azure DevOps |

#### 5.1.6.2 Services

Single service: **EAII-333 Payment Capture API** hosted on Azure API Management.

#### 5.1.6.3 *EAII-333 Payment Capture API*

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

1. Interface ID
2. As below spreadsheet

| **Step** | **Document ID** | **Document Type** | **Delivery Type** | **Direction** | **Source System** | **Destination System** | **Status** | **Reference** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Success | Transaction ID (GUID) | Payment Response | SOAP/HTTP | Outbound | APIM | Storeline | Success | Response Code = 1 |
| Warning | Transaction ID (GUID) | Payment Response | SOAP/HTTP | Outbound | APIM | Storeline | Non-Success | Response Code, Error Message |
| Error | Transaction ID (GUID) | Payment Fault | SOAP/HTTP | Outbound | APIM | Storeline | Error | Exception Details |

##### 5.1.6.3.2 Audit

| **Observation Stage** | **Source/Target App** | **Information Captured**(Reference Keys) | **Description** | **Test Scenario**(FSD) |
| --- | --- | --- | --- | --- |
| Begin | Storeline → APIM | Transaction ID, Order ID, Customer ID, Payment Amount | Payment capture request received | T7 |
| End (Success) | APIM → Storeline | Transaction ID, Order ID, Response Code | Payment capture successful (responseCode=1) | T7 |
| Warning (Non-Success) | APIM → Storeline | Transaction ID, Order ID, Response Code, Error Message | Payment capture declined (responseCode≠1) | T8 |
| Error | APIM → Storeline | Transaction ID, Order ID, Exception Type, Exception Message | Unexpected error during processing | T8 |

##### 5.1.6.3.3 Exceptions

| **Observation Stage** | **Exception Scenario** | **Exception category (technical / Business)** | **Exception Code** | **Exception Message** | **Exception Handling** | **Status** |
| --- | --- | --- | --- | --- | --- | --- |
| Backend Call | Target system connectivity failure | Technical | 130 (HYBRIS-ERROR) | Unable to connect to SAP Commerce Cloud | Log error; return SOAP fault | SOAP Fault returned |
| Backend Call | Target system timeout | Technical | 111 (TIBCO-HYBRIS-TIMEOUT) | SAP Commerce Cloud did not respond within timeout | Log error; return SOAP fault | SOAP Fault returned |
| Backend Call | HTTP 4xx error | Technical | 130 (HYBRIS-ERROR) | Client error from SAP Commerce Cloud | Log error; return SOAP fault | SOAP Fault returned |
| Backend Call | HTTP 5xx error | Technical | 130 (HYBRIS-ERROR) | Server error from SAP Commerce Cloud | Log error; return SOAP fault | SOAP Fault returned |
| Response Processing | Payment capture declined | Business | N/A | responseCode ≠ 1 | Log warning; return response (not fault) | Response returned |
| Any Stage | Unexpected internal error | Technical | 111 (INTERNAL-ERROR) | Unhandled exception | Log error with stack trace; return SOAP fault | SOAP Fault returned |

##### 5.1.6.3.4 Service consumers

| **Consumer** | **Protocol** | **Description** |
| --- | --- | --- |
| Storeline (Campbells Retailers) | SOAP over HTTP/HTTPS | Legacy warehouse/POS system initiating payment capture after pick and pack |

##### 5.1.6.3.5 Service Operations

| **Operation** | **Method** | **Description** |
| --- | --- | --- |
| paymentRequest | SOAP (Request-Reply) | Synchronous payment capture operation |

##### 5.1.6.3.6 Service Provider

| **Provider** | **Protocol** | **Description** |
| --- | --- | --- |
| SAP Commerce Cloud (Sorted) | REST over HTTPS (mutual TLS) | Braintree payment capture endpoint |

##### 5.1.6.3.7 Communications Data Structures

*Place locations for all the mappings, schemas/specs, sample packages here.*

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Sample Files** | **Description** |
| --- | --- | --- | --- | --- | --- |
| Payment Request Mapping | HybrisPaymentRequestWSDL.wsdl (`paymentRequest`) | REST URL (path + query params) | See Mapping Document | Source_sample_request1.xml, Source_sample_request2.xml, Source_sample_request3.xml | SOAP fields → REST URL parameters |

**Response Mapping (JSON → SOAP):**

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Sample Files** | **Description** |
| --- | --- | --- | --- | --- | --- |
| Payment Response Mapping | JSON (responseCode, extendedErrorCode, message) | HybrisPaymentRequestWSDL.wsdl (`paymentResponse`) | See Mapping Document | Source_sample_response1.xml, Source_sample_response2.xml, Source_sample_response3.xml | JSON response → SOAP response with conditional error formatting |

**Request Field Mapping:**

| **Source Field** | **Source Path** | **Data Type** | **Target Parameter** | **Parameter Type** | **Transformation** |
| --- | --- | --- | --- | --- | --- |
| customerId | paymentRequest/customerId | xs:string | N/A (logging only) | N/A | Not forwarded to target - used for audit logging |
| orderId | paymentRequest/orderId | xs:string | {orderId} | URL Path | Direct mapping - 10-digit zero-padded |
| paymentAmount | paymentRequest/paymentAmount | xs:double | captureAmount | URL Query String | Cast to decimal (scientific notation → integer, e.g., 2.9674E4 → 29674) |
| requestTimeout | paymentRequest/requestTimeout | xs:integer | N/A | N/A | Not forwarded - timeout managed at HTTP client config |

**Response Field Mapping:**

| **Source Field (JSON)** | **Data Type** | **Target Field (SOAP)** | **Transformation** |
| --- | --- | --- | --- |
| responseCode | integer | responseCode | Direct mapping (1=success, 2=error with code, other=general failure) |
| extendedErrorCode | string | extendedErrorCode | Conditional - only included when present in source |
| message | string | message | If responseCode=2: `"Error {extendedErrorCode} - {message}"`; else: pass-through as-is |

**Target REST URL Construction:**

```
POST https://{host}/occ/v2/campbellsretailersspa/orders/{orderId}/braintree/paymentcapture?captureAmount={captureAmount}
```

- Request body: Empty
- Content-Type: N/A
- Authentication: Mutual TLS (client certificate)

##### 5.1.6.3.8 Input/Output

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | paymentRequest (SOAP) | HybrisPaymentRequestWSDL.wsdl | See Source_sample_request1.xml |
| Output | paymentResponse (SOAP) | HybrisPaymentRequestWSDL.wsdl | See Source_sample_response1.xml |

**Sample Input (SOAP Body):**

```
<paymentRequest xmlns="http://www.campbells.com.au/PaymentRequestService/">

  <customerId xmlns="">0033764325</customerId>

  <orderId xmlns="">0040797969</orderId>

  <paymentAmount xmlns="">2.9674E4</paymentAmount>

  <requestTimeout xmlns="">30000</requestTimeout>

</paymentRequest>
```

**Sample Output - Success (SOAP Body):**

```
<tns2:paymentResponse xmlns:tns2="/T1650939449914Converted/JsonSchema">

  <tns2:responseCode>1</tns2:responseCode>

  <tns2:extendedErrorCode>0</tns2:extendedErrorCode>

  <tns2:message>SUCCESFULL</tns2:message>

</tns2:paymentResponse>
```

**Sample Output - Error (SOAP Body):**

```
<tns2:paymentResponse xmlns:tns2="/T1650939449914Converted/JsonSchema">

  <tns2:responseCode>2</tns2:responseCode>

  <tns2:extendedErrorCode>4001</tns2:extendedErrorCode>

  <tns2:message>Error 4001 - Insufficient funds</tns2:message>

</tns2:paymentResponse>
```

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| SAP Commerce Cloud Braintree Payment Capture | POST /occ/v2/campbellsretailersspa/orders/{orderId}/braintree/paymentcapture | JSON response: {responseCode, extendedErrorCode, message} | `{"responseCode":1,"extendedErrorCode":"0","message":"SUCCESFULL"}` |

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | Campbells Payment Capture |
| Source Business Process | Order Fulfilment - Payment |
| Source Application | Storeline |
| Destination Business Process | Payment Processing |
| Destination Application | SAP Commerce Cloud (Sorted) |
| Interface ID | EAII-333 |
| Interface Name | Campbells Payment - Storeline to CCC |
| Interface Type | Synchronous Request-Reply |
| Interface DataStore | N/A (stateless) |
| Tags | `{"division": "campbells", "type": "payment", "priority": "P1"}` |
| Reference Keys | Transaction ID, Order ID, Customer ID |
| Notification Type | Error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-333 |
| Correlation Properties | Order ID, Transaction ID |
| Reprocessing Required | No (caller manages retries) |
| BusinessProcess Name | CampbellsPaymentCapture |

#### 5.1.7.1 SMC Load Estimations

This section will include corresponding SMC load estimations for this interface, including peak and normal load scenarios.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | ~200 messages/day |
|  | Average volume | ~200 messages/day (3,021 messages over 15 days) |
|  | Seasonal considerations | Standard retail patterns - higher during promotional periods |
|  | Expected growth | Low - stable customer base |

### 5.1.8 Monitoring

Standard AIS platform monitoring applies via Application Insights and Azure Monitor.

- **Health probe**: APIM built-in health endpoint
- **Alert rules**:
- Error rate > 5% over 5-minute window → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- Response time > 5 seconds (P95) → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- Backend connectivity failure → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- **Dashboard**: Standard APIM analytics dashboard with custom dimensions (Order ID, Response Code)

### 5.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

*Make sure to include scenarios for any known issues to be addressed.*

| **ADO Test Case ID***(Link)* | **Description** | **Location Of Sample Messages** |
| --- | --- | --- |
| T1 | Submit valid payment capture request with correct order ID and payment amount - expect responseCode=1 | Source_sample_request1.xml / Source_sample_response1.xml |
| T2 | Submit payment capture request with invalid/non-existent order ID - expect responseCode≠1 with error message | Mock SAP Commerce Cloud returning error |
| T3 | Submit payment capture request with zero amount - expect error response | Mock SAP Commerce Cloud returning error |
| T4 | Submit payment capture when SAP Commerce Cloud is unavailable - expect SOAP fault | Backend unreachable |
| T5 | Submit payment capture when SAP Commerce Cloud responds slowly (timeout) - expect SOAP fault | Backend delay > timeout |
| T6 | Submit payment capture that returns responseCode=2 - verify error message formatted as "Error {code} - {msg}" | Mock response with responseCode=2 |
| T7 | Verify audit logging records transaction ID, order ID, and response code for successful capture | App Insights query validation |
| T8 | Verify audit logging captures error details for failed payment capture | App Insights query validation |

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![image-20260806-101005.png](images/04.png)

## 6.2 Network Connectivity

![image-20260806-100927.png](images/02.png)

| **Connection** | **Source** | **Destination** | **Protocol** | **Port** | **Authentication** |
| --- | --- | --- | --- | --- | --- |
| Inbound | Storeline (on-premises) | APIM Gateway | SOAP over HTTPS | 443 | Network-level security (existing) |
| Outbound | APIM Backend | SAP Commerce Cloud | REST over HTTPS | 443 | Mutual TLS (client certificate) |
| Internal | APIM | Key Vault | HTTPS | 443 | Managed Identity |
| Internal | APIM | Application Insights | HTTPS | 443 | Instrumentation Key |

## 6.3 Security

- Control access to all Azure services/resources using RBAC.
- All communication between endpoints will be through https.

### 6.3.1 Data Handling and Encryption

- **Data classification**: Internal
- The integration handles order identifiers, customer identifiers, and payment amounts only
- No credit card numbers, CVVs, or sensitive payment instrument details pass through the integration
- Audit logs must NOT capture full request/response payloads in production to avoid exposure of customer identifiers at scale
- All data in transit is encrypted via TLS 1.2+
- Client certificate for mutual TLS stored in Azure Key Vault (FIPS 140-2 Level 2 compliant)

## 6.4 Infrastructure Support

Standard AIS platform infrastructure support applies. No special requirements beyond:

- Key Vault certificate rotation support (SAP Commerce Cloud client certificate renewal)
- APIM policy deployment via CI/CD

## 6.5 Infrastructure Requirements

| **Component** | **Non-Prod Specifications** | **Prod Specifications** | **New / Existing** |
| --- | --- | --- | --- |
| Azure API Management | Standard tier (shared instance) | Standard/Premium tier | Existing (shared) |
| Azure Key Vault | Standard | Standard | Existing (shared) |
| Azure Application Insights | Standard | Standard | Existing (shared) |
| Azure Log Analytics Workspace | Standard | Standard | Existing (shared) |
| Virtual Network | Standard (existing APIM subnet) | Standard (existing APIM subnet) | Existing |
| Azure App Gateway | Standard_v2 | Standard_v2 | Existing (shared) |

## 6.6 Infrastructure Resource Details

The following table captures the specific Azure resource names, subscription placement, and network configuration for this integration.

| **Resource Name** | **Type** | **Resource Group** | **Subscription** | **VNet** | **Subnet** | **IP Address** |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `t1-met-core-{env}-ae1-apg-01` | Application Gateway | `t1-met-core-{env}-ae1-rsg-net` | `COREIT-SERVICES-HUB-{env}` | App GW VNet | App GW Subnet | Public: 20.42.203.106, Private: 10.247.1.71 |  |
| `t3-met-core-{env}-ae1-apim` | API Management | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | APIM VNet | ECCS2 | Public VIP: 4.254.116.233, Private VIP: 10.247.1.4 |  |
| `t3-met-core-{env}-ae1-appi-apim` | Application Insights | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | N/A | N/A | N/A |  |
| `t3enabling{env}ae1kv01` | Key Vault | `t3-met-ais-{env}-ae1-rsg-enabling` | `COREIT-SERVICES-AIS-{env}` | `t2-met-ais-{env}-ae1-net-01` | HSENS (10.247.85.0) | PE: `t3enabling{env}ae1kv01-pe` |  |
| `t3enabling{env}ae1kv01` | Private Endpoint (Key Vault) | `t3-met-ais-{env}-ae1-rsg-enabling` | `COREIT-SERVICES-AIS-{env}` | `t2-met-ais-{env}-ae1-net-01` | HSENS (10.247.85.0) | N/A |  |
| APIM System-Assigned MI | Managed Identity | Microsoft.ManagedIdentity (system-assigned) | t3-met-core-{env}-ae1-rsg-apim | COREIT-SERVICES-HUB-{env} | N/A | N/A | N/A |
| SMC | Service Management Console | N/A (External SaaS) | N/A (External) | N/A | N/A | N/A | N/A |

**App Gateway Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure Application Gateway | Microsoft.Network/applicationGateways | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | Microsoft.Network/applicationGateways | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure API Management | Microsoft.ApiManagement/service | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | Microsoft.ApiManagement/service | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway, providing Layer 7 load balancing and secure ingress routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Notes:**

- APIM Gateway URL: `https://cloud-api-{env}-internal.metcash.com`
- Managed Identity: APIM uses a system-assigned managed identity (Microsoft.ManagedIdentity) to authenticate to Key Vault cross-subscription for mTLS client certificate retrieval. The identity is granted Key Vault Secrets User and Key Vault Certificates Officer RBAC roles (Microsoft.Authorization/roleAssignments) on `t3enabling{env}ae1kv01`.
- Log Analytics Workspace (Microsoft.OperationalInsights/workspaces) is linked to Application Insights for log query and retention. Exact resource name follows platform naming convention.
- Private Endpoint (Microsoft.Network/privateEndpoints): Key Vault is accessed via private endpoint within the HSENS subnet.
- Key Vault is accessed cross-subscription via Managed Identity (APIM → Key Vault) to retrieve the mTLS client certificate for SAP Commerce Cloud
- APIM interacts with SMC through REST API call for audit logging (Start/End/Warning/Error observations)

| **Variable** | **Values** |
| --- | --- |
| `{env}` | `dev` &#124; `sit` &#124; `uat` &#124; `prd` |

# 7 Communication Overview

## 7.1 Communication Components

| **Environment** | **APIM Endpoint (Inbound)** | **Backend Host (Outbound)** | **Port** |
| --- | --- | --- | --- |
| DEV | `https://t3-met-core-(env}-ae1-apim.azure-api.net/eis/campbellspayment/v1` | (environment-specific SAP Commerce Cloud host) | 443 |
| SIT | `https://t3-met-core-(env}-ae1-apim.azure-api.net/eis/campbellspayment/v1` | (environment-specific SAP Commerce Cloud host) | 443 |
| UAT | `https://t3-met-core-(env}-ae1-apim.azure-api.net/eis/campbellspayment/v1` | (environment-specific SAP Commerce Cloud host) | 443 |
| PROD | `https://t3-met-core-(env}-ae1-apim.azure-api.net/eis/campbellspayment/v1` | (environment-specific SAP Commerce Cloud host) | 443 |

# 8 Data Architecture

## 8.1 Data Model

N/A - This integration is stateless. No data is persisted.

## 8.2 Stored Procedures

N/A

| **Stored Procedure Name** | **Purpose** | **Explanation** |
| --- | --- | --- |
|  |  |  |

## 8.3 Stored Procedure Triggers

N/A

| **Stored Procedure Name** | **Trigger Name** | **Trigger** |
| --- | --- | --- |
|  |  |  |

## 8.4 Database Technical Specification

N/A

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

- **Application Insights logs**: Retained per corporate standard (default 90 days)
- **APIM request logs**: Retained per corporate standard
- No message payloads are persisted by the integration

### 8.5.2 Data Backup

N/A - Stateless integration. APIM configuration backed up via source control (Infrastructure as Code).

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

Application Insights data follows corporate retention policy. Logs are automatically purged after retention period.

#### 8.5.3.2 State process for data/system destruction

Log data lifecycle managed by Azure Log Analytics workspace retention settings.

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

A parallel-run transition period may be required where both TIBCO BWC and APIM endpoints are available. Storeline will be reconfigured to point to the new APIM endpoint. Rollback involves reverting Storeline's endpoint configuration to the legacy TIBCO address.

## 9.2 Deployment Preference

APIM provides built-in high availability within a region (Standard tier: 99.95% SLA). No additional load balancing configuration is required for ~200 messages/day. This is a stateless synchronous service so message ordering is inherently preserved.

## 9.3 Deployment Environment Migration

All source code (APIM policies, API definitions, Bicep/ARM templates) is managed under source control (Azure DevOps Repo).

Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure:

- DEV → SIT → UAT → PREPROD → PROD
- Environment-specific values (backend hosts, certificate references) managed via pipeline variables

# 10 Disaster Recovery

- APIM Standard/Premium tier provides built-in regional redundancy
- Backend (SAP Commerce Cloud) DR is managed by the SAP Commerce Cloud platform team
- No integration-level DR requirements beyond platform capabilities
- Recovery: Redeploy APIM configuration from source control in the event of catastrophic failure

# 11 Support Documentation

![diagram](images/01.png)

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | APIM policy execution timeout | APIM has a maximum policy execution time of 3 minutes 50 seconds for forwarded requests | Well within requirements (<5s target latency) |
| 2 | SOAP namespace handling | APIM SOAP pass-through requires careful namespace mapping in policy XPath expressions | Requires thorough testing of namespace-qualified XPath |
| 3 | Scientific notation conversion | Policy expression must handle xs:double to decimal conversion correctly | Use `Convert.ToDecimal()` or `Math.Round()` in C# expression |
| 4 | Client certificate renewal | SAP Commerce Cloud mutual TLS certificate must be rotated before expiry | Key Vault certificate auto-rotation or manual rotation process required |

# 13 Assumptions

- Storeline can be reconfigured to call the new APIM endpoint without code changes (only endpoint URL change)
- The SOAP contract (WSDL namespace, operation name, message structure) remains unchanged from the legacy implementation
- SAP Commerce Cloud's REST API contract remains unchanged during migration
- The existing APIM infrastructure (shared instance) has sufficient capacity for ~200 additional messages/day
- Network connectivity between APIM VNet and SAP Commerce Cloud is already established or can be established via existing network infrastructure
- The `"SUCCESFULL"` misspelling in the SAP Commerce Cloud response is preserved as-is (not corrected by the integration)
- Application Insights is the approved replacement for the legacy Metcash ESB Logging Service

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

### 14.1 External Dependencies

The following non-Azure external systems are dependencies for this integration and must be available for end-to-end operation:

| System | Type | Owner | Protocol | Direction | Purpose |
| --- | --- | --- | --- | --- | --- |
| Storeline (Campbells Retailers) | On-Premises (AS/400) | Metcash / Campbells | SOAP/HTTPS | Inbound (Source) | Initiates payment capture requests after pick and pack |
| SAP Commerce Cloud (Sorted) | External SaaS | SAP / Sorted | REST/HTTPS (mTLS) | Outbound (Target) | Processes payment capture via Braintree gateway |
| Braintree | External SaaS (via SAP CC) | PayPal / Braintree | N/A (internal to SAP CC) | Indirect | Actual payment gateway — invoked by SAP Commerce Cloud, not directly by this integration |
| SMC (Service Management Console) | External SaaS | Metcash | REST/HTTPS | Outbound (Monitoring) | Receives audit events (Start/End/Warning/Error) via API call from APIM |

# 15 TSD Approval Checklist

![diagram](images/07.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |
