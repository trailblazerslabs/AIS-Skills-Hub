<!-- Source: Technical+Specification+-+EAII-289+-+MDM+to+ATO.doc -->
<!-- Title: Technical Specification - EAII-289 - MDM to ATO -->

# Technical Specification - EAII-289 - MDM to ATO

**Table of Contents**

- 1 Document Overview
  - 1.1 Background
  - 1.2 Document Purpose
  - 1.3 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope

- 3 Compliance
  - 3.1 Architecture Principles
  - 3.2 Standards, Guidelines and Patterns

- 4 Requirements Overview
  - 4.1 Business Process Requirement and Integration
    - 4.1.1 Process Diagram from FSD
    - 4.1.2 Functional Specification Document

  - 4.2 Technical standard and requirements
  - 4.3 Required Components
  - 4.4 Environmental Requirement
    - 4.5 Non-Functional Requirements
      - 4.5.1 Retry Strategy

- 5 Integration Overview and Implementation
  - 5.1 EAII-289 - ATO Business Details Lookup
    - 5.1.1 As-is Process(es)
      - 5.1.1.1 Description of Process(es)
      - 5.1.1.2 Process Flow Diagram

    - 5.1.2 Proposed Process(es)
      - 5.1.2.1 Description of Process(es)
      - 5.1.2.2 Process Flow Diagram
      - 5.1.2.3 Sequence Diagram
      - 5.1.2.4 PlantUML

    - 5.1.3 Coordination
      - 5.1.3.1 Transaction Boundaries
      - 5.1.3.2 State Management

    - 5.1.4 GoAnywhere Requirements
    - 5.1.5 Design Considerations
    - 5.1.6 Service High Level Design
      - 5.1.6.1 Component List
      - 5.1.6.2 Services
      - 5.1.6.3 Logging
        - 5.1.6.3.2 Audit
        - 5.1.6.3.3 Exceptions
        - 5.1.6.3.4 Service consumers
        - 5.1.6.3.5 Service Operations
        - 5.1.6.3.6 Service Provider
        - 5.1.6.3.7 Communications Data Structures
        - 5.1.6.3.8 Input/Output
        - 5.1.6.3.9 Fulfillment Services

      - 5.1.7.1 Integration Onboarding
      - 5.1.7.2 SMC Load Estimations

    - 5.1.8 Monitoring
    - 5.1.9 Reporting
    - 5.1.10 Integration and Testing Requirements
      - 5.1.10.1 Development and Integration Strategy
      - 5.1.10.2 Unit Testing

- 6 Architecture Overview
  - 6.1 Physical Architecture Diagram
  - 6.2 Network Connectivity
  - 6.3 Security
    - 6.3.1 Data Handling and Encryption

  - 6.4 Infrastructure Support
  - 6.5 Infrastructure Requirements
  - 6.6 Infrastructure Resource Details
    - 6.6.1 Azure API Management Details
    - 6.6.2 AIS Spoke Virtual Network Details

- 7 Communication Overview
  - 7.1 Communication Components

- 8 Data Architecture
  - 8.1 Data Model
  - 8.2 Stored Procedures
  - 8.3 Stored Procedure Triggers
  - 8.4 Database Technical Specification
  - 8.5 Data Retention
    - 8.5.1 Data Retention Procedures
      - 8.5.1.1 Data storage and retention

    - 8.5.2 Data Backup
    - 8.5.3 Data Destruction Procedures
      - 8.5.3.1 Data destruction metrics and timeframes
      - 8.5.3.2 State process for data/system destruction

- 9 Deployment and Monitoring Considerations
  - 9.1 Transition Period
  - 9.2 Deployment Preference
  - 9.3 Deployment Environment Migration

- 10 Disaster Recovery
- 11 Support Documentation
- 12 Limitations and Constraints
- 13 Assumptions
- 14 Reference Documents and Architecture

| **TSD Author** |  |
| --- | --- |

| **Document Approver** | **Approver Role** |
| --- | --- |
| Magesh Parthasarathy | Integration Platform Representative |
| [Hemant Kamble](https://metcash.atlassian.net/wiki/people/712020:32685375-f7e5-4cbf-8a29-3e3e7555cddb?ref=confluence) | Integration Platform Operations |
| Magesh Parthasarathy | Solution Architect |
| [Mohanraj Vengiduswamy](https://metcash.atlassian.net/wiki/people/712020:cebae083-d404-4818-8553-34466e871c59?ref=confluence) | Test Manager |

# 1 Document Overview

## 1.1 Background

Metcash operates several internal business applications that need to verify the legitimacy and registration status of Australian businesses they trade with — suppliers, retailers, customers and other commercial counterparties. A centralised lookup capability is provided that allows any authorised Metcash application to query the official Australian Business Register (ABR) using either an Australian Business Number (ABN) or an Australian Company Number (ACN) and receive standardised business details in response.

**Legacy (As-is):** The integration was originally implemented as a TIBCO BusinessWorks BWCE service calling the ABR SOAP endpoints (`SearchByABNv201408` and `SearchByASICv201408`). The legacy service transforms the SOAP XML response into JSON and returns it to the consumer.

**Proposed (To-be):** The service is being migrated to Azure Integration Services (AIS). The new implementation is **APIM-only** — Azure API Management calls the ATO **REST** endpoints (which return XML), transforms the XML response into canonical `MetcashIdentifierBObj` JSON using XSLT templates, and returns JSON to the consumer. No SOAP calls are made in the proposed architecture.

The service exposes four synchronous REST API operations organised as two versions:

| **#** | **Operation** | **ATO Backend** | **Protocol** | **Transform** | **Response** |
| --- | --- | --- | --- | --- | --- |
| 1 | SearchByABN (v1) | ATO REST SearchByABN | REST (XML response) | XSLT v1 | JSON |
| 2 | SearchByABNv2 | ATO REST SearchByABN | REST (XML response) | XSLT v2 | JSON |
| 3 | SearchByACN (v1) | ATO REST SearchByACN | REST (XML response) | XSLT v1 | JSON |
| 4 | SearchByACNv2 | ATO REST SearchByACN | REST (XML response) | XSLT v2 | JSON |

All processing — routing, validation, backend call, transformation, and audit logging — is handled within APIM policies.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the **Business Details Lookup** service between **Metcash Internal Consumer Applications** (source) and the **Australian Business Register (ATO)** (target), implemented entirely on **Azure API Management (APIM)**.

## 1.3 Glossary

| **Term** | **Description** |
| --- | --- |
| ABN | Australian Business Number — the 11-digit unique identifier assigned to every entity registered in the Australian Business Register |
| ABR | Australian Business Register — the official register of all businesses and other entities operating in Australia, operated by the Australian Taxation Office |
| ACN | Australian Company Number — the 9-digit unique identifier assigned to Australian companies by ASIC |
| AIS | Azure Integration Services — the target integration platform |
| APIM | Azure API Management — the API gateway handling routing, validation, transformation, backend calls, and security |
| ASIC | Australian Securities and Investments Commission — the national corporate regulator that issues ACNs |
| ATO | Australian Taxation Office — operator of the Australian Business Register and provider of the REST API endpoints |
| MetcashIdentifierBObj | The canonical Metcash business object used to return business identification data in a standardised JSON format |
| SMC | Service Management Console — Metcash's custom monitoring and observability platform |
| Transaction ID | A correlation identifier generated for every lookup request and propagated through audit log events |

# 2 Scope

## 2.1 In Scope

  - `EAII-289 Business Details Lookup service providing four operations against the Australian Business Register:`
    - `SearchByABN — calls ATO REST SearchByABN endpoint, transforms XML response to JSON via XSLT v1`
    - `SearchByABNv2 — calls ATO REST SearchByABN endpoint, transforms XML response to JSON via XSLT v2`
    - `SearchByACN — calls ATO REST SearchByACN endpoint, transforms XML response to JSON via XSLT v1`
    - `SearchByACNv2 — calls ATO REST SearchByACN endpoint, transforms XML response to JSON via XSLT v2`

  - `APIM-only architecture: all routing, validation, backend proxying, XML-to-JSON transformation, and audit logging handled within APIM policies`
  - `Outbound connectivity to the ATO REST endpoints (XML responses)`
  - `Request/response correlation using a per-request Transaction ID`
  - `Audit logging of success and failure events through SMC tracked properties`
  - `Error handling for ATO connectivity failures, invalid input parameters, and unexpected responses`
  - `Input validation (ABN = 11 digits, ACN = 9 digits) at the APIM policy layer`
  - `ATO secrets (API keys/credentials) stored in data-specific Azure Key Vaults`

## 2.2 Out of Scope

- Caching of ATO/ABR responses (every lookup goes through to ATO)
- Changes to consumer application logic
- Changes to the upstream ATO REST service contract
- Bulk or batch lookup capability (the service is per-request only)

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

Refer to FSD Sections [3.1.1.1](https://media-cdn.atlassian.com/file/5b7cddcf-42f8-4bd6-b2e0-9dbb452cd2eb/image/cdn?allowAnimated=true&client=b2a0fec9-0c18-4ece-84e2-1fdd8532a29b&collection=contentId-3476422657&height=125&max-age=2592000&mode=full-fit&source=mediaCard&token=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJiMmEwZmVjOS0wYzE4LTRlY2UtODRlMi0xZmRkODUzMmEyOWIiLCJhY2Nlc3MiOnsidXJuOmZpbGVzdG9yZTpjb2xsZWN0aW9uOmNvbnRlbnRJZC0zNDc2NDIyNjU3IjpbInJlYWQiXX0sImV4cCI6MTc4NDUyMDQyMiwibmJmIjoxNzg0NTE3NTQyLCJhYUlkIjoiNzEyMDIwOjMwYjViYmVhLWI3N2ItNDk5Zi04ZTY2LTcwMzE4MmFkZmZkZSIsImh0dHBzOi8vaWQuYXRsYXNzaWFuLmNvbS9hcHBBY2NyZWRpdGVkIjpmYWxzZSwiYXV0aFR5cGUiOiJzZXNzaW9uIn0.JO-wkswPxWIZJcU7SJnLRxgknfZxwLmMRVEHIAkTlAk&width=1022#media-blob-url=true&id=5b7cddcf-42f8-4bd6-b2e0-9dbb452cd2eb&clientId=b2a0fec9-0c18-4ece-84e2-1fdd8532a29b&contextId=contentId-3476422657&collection=contentId-3476422657), [3.2.1.1](https://media-cdn.atlassian.com/file/afc7c3c2-547b-41e5-8c0e-9606b2514ef5/image/cdn?allowAnimated=true&client=b2a0fec9-0c18-4ece-84e2-1fdd8532a29b&collection=contentId-3476422657&height=125&max-age=2592000&mode=full-fit&source=mediaCard&token=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJiMmEwZmVjOS0wYzE4LTRlY2UtODRlMi0xZmRkODUzMmEyOWIiLCJhY2Nlc3MiOnsidXJuOmZpbGVzdG9yZTpjb2xsZWN0aW9uOmNvbnRlbnRJZC0zNDc2NDIyNjU3IjpbInJlYWQiXX0sImV4cCI6MTc4NDUyMDQyMiwibmJmIjoxNzg0NTE3NTQyLCJhYUlkIjoiNzEyMDIwOjMwYjViYmVhLWI3N2ItNDk5Zi04ZTY2LTcwMzE4MmFkZmZkZSIsImh0dHBzOi8vaWQuYXRsYXNzaWFuLmNvbS9hcHBBY2NyZWRpdGVkIjpmYWxzZSwiYXV0aFR5cGUiOiJzZXNzaW9uIn0.JO-wkswPxWIZJcU7SJnLRxgknfZxwLmMRVEHIAkTlAk&width=1036#media-blob-url=true&id=afc7c3c2-547b-41e5-8c0e-9606b2514ef5&clientId=b2a0fec9-0c18-4ece-84e2-1fdd8532a29b&contextId=contentId-3476422657&collection=contentId-3476422657), 3.3.1.1, and 3.4.1.1 Process Diagrams.

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-289 - MDM to ATO | [Functional Specification - EAII-289 - MDM Supplier to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3476422657/Functional+Specification+-+EAII-289+-+MDM+Supplier+to+ATO) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

  - JSON for REST web service response format (consumer-facing)
  - XML for ATO backend response format (ATO REST endpoints return XML)
  - REST for both inbound (consumer to APIM) and outbound (APIM to ATO) communication protocols
  - XSLT for XML-to-canonical-JSON transformation within APIM policies

**Adoption of Industry standard security best practice:**

  - OAuth2 for API authentication and authorization (inbound - consumer applications to APIM)
  - Azure Managed Identity for APIM to Key Vault authentication
  - ATO API credentials stored in data-specific Azure Key Vaults

## 4.3 Required Components

The following components are required for this integration:

  - Azure API Management service (APIM) — API gateway handling routing, input validation, backend proxying, XML-to-JSON transformation, security, and audit logging
  - Azure Key Vault (data-specific) — for storing ATO REST API authentication credentials
  - Azure Application Insights — for platform-level logging and monitoring
  - Azure Log Analytics workspace — for operational monitoring
  - Azure Virtual Network — for network isolation
  - SMC — Custom Monitoring Tool (observability via APIM diagnostics and tracked properties for success/failure logging)

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DEV)
- System Integration Testing (SIT)
- User Acceptance Test (UAT)
- Production (PROD)

### 4.5 Non-Functional Requirements

| **NFR Category** | **Requirement** | **Target** |
| --- | --- | --- |
| Availability | Service uptime during business hours | 95% (Silver SLA) |
| Availability | APIM platform SLA | 99.95% (Standard/Premium tier) |
| Response Time | P95 end-to-end latency (consumer to consumer) | < 5 seconds |
| Response Time | Maximum acceptable response time | 10 seconds |
| Throughput | Expected transactions per second (TPS) | < 1 TPS (ad-hoc lookups) |
| Throughput | Peak TPS | < 5 TPS |
| Concurrency | Maximum concurrent requests | 10 |
| Error Rate | Acceptable error rate (excluding ATO faults) | < 1% |
| Monitoring | Alert threshold — error rate | > 10% over 5-minute window |
| Monitoring | Alert threshold — latency | P95 > 5 seconds |
| Data Classification | Response data classification | Public |

#### 4.5.1 Retry Strategy

Retries are **not implemented at the APIM integration layer**. Rationale:

1. **Synchronous request-reply pattern**: The consumer blocks on the HTTP GET call. Retrying within APIM would increase latency for the consumer without visibility into whether the retry is progressing.
2. **Idempotent read operation**: All four operations are GET lookups with no side effects. Retrying at the consumer layer is safe and preferred.
3. **Consumer-managed retries**: Consumer applications are responsible for implementing their own retry logic (e.g. exponential backoff) based on the HTTP status code returned by APIM.
4. **APIM**`forward-request`**timeout**: The default APIM forward-request timeout of 300 seconds applies. If the ATO does not respond within this window, APIM returns an HTTP 504 to the consumer.

**Consumer retry guidance:**

| **HTTP Status** | **Consumer Action** |
| --- | --- |
| 200 | Success — no retry needed |
| 400 | Client error — do not retry (fix input) |
| 500 | Server error — retry with backoff |
| 502 | ATO backend error — retry with backoff |
| 504 | ATO timeout — retry with backoff |

# 5 Integration Overview and Implementation

### Architecture Decision - APIM

All four operations are implemented entirely within **Azure API Management**. APIM exposes four consumer-facing operations (`SearchByABN`, `SearchByABNv2`, `SearchByACN`, `SearchByACNv2`) that route to two ATO REST backend endpoints (SearchByABN and SearchByACN). Each operation transforms the XML response into canonical `MetcashIdentifierBObj` JSON using a per-version XSLT template, and returns JSON to the consumer. No separate compute backend is required.

**Protocol clarification:**

| **Layer** | **Protocol** | **Notes** |
| --- | --- | --- |
| Consumer → APIM (inbound) | REST over HTTPS | Consumer sends GET request, receives JSON |
| APIM → ATO (outbound) | REST over HTTP | ATO REST endpoints return XML responses |
| Legacy TIBCO → ABR (decommissioned) | SOAP over HTTP | Legacy used ABR SOAP operations (`SearchByABNv201408`, `SearchByASICv201408`); **not used in the proposed solution** |

**Endpoint Routing:**

| **APIM Operation** | **ATO Backend Endpoint** | **XSLT Template** |
| --- | --- | --- |
| SearchByABN | ATO SearchByABN | XSLT v1 |
| SearchByABNv2 | ATO SearchByABN | XSLT v2 |
| SearchByACN | ATO SearchByACN | XSLT v1 |
| SearchByACNv2 | ATO SearchByACN | XSLT v2 |

**Rationale:**

- **APIM-only, minimal infrastructure**: The ATO provides REST endpoints returning XML. APIM can natively proxy REST-to-REST calls and perform XML-to-JSON transformation within policies, eliminating the need for a separate compute layer.
- **Lower latency**: All processing occurs within the APIM policy pipeline. No additional HTTP hops to backend compute services.
- **Reduced operational complexity**: One Azure resource to deploy, monitor, and maintain. No App Service Plan, no workflow definitions, no additional CI/CD pipeline for backend compute.
- **Policy-based transformation**: APIM supports XSLT templates in outbound policies for XML-to-JSON transformation. The canonical `MetcashIdentifierBObj` JSON structure can be produced directly in the APIM outbound policy.
- **Built-in Key Vault integration**: APIM named values support Key Vault references with Managed Identity, allowing ATO credentials to be securely retrieved without a separate backend.
- **SMC integration**: APIM diagnostics and `send-request` policy actions can emit success and failure events to SMC for audit logging.

**APIM Policy Processing Flow:**

```
Consumer Request (GET /eis/abnlookup/{v1|v2}/{SearchByABN|SearchByACN})
  |
  +-- Inbound Policy:
  |     +-- Validate input parameters (ABN=11-digit, ACN=9-digit)
  |     +-- Generate Transaction ID (GUID)
  |     +-- Retrieve ATO credentials from Key Vault (named value)
  |     +-- Log SMC Begin event (send-request)
  |     +-- Set backend URL:
  |           SearchByABN/SearchByABNv2 → ATO SearchByABN
  |           SearchByACN/SearchByACNv2 → ATO SearchByACN
  |
  +-- Backend:
  |     +-- Forward request to ATO REST endpoint
  |     +-- Receive XML response
  |
  +-- Outbound Policy:
  |     +-- Transform XML response to canonical MetcashIdentifierBObj JSON
  |           (v1 endpoints use XSLT v1 template, v2 endpoints use XSLT v2 template)
  |     +-- Set Content-Type: application/json
  |     +-- Log SMC End event (send-request) on success
  |
  +-- On-Error Policy:
  |     +-- Log SMC Error event (send-request)
  |     +-- Return structured JSON error response
  |
  +-- Return JSON response to consumer
```

**Responsibility Split (all within APIM):**

| **Concern** | **APIM Policy Section** |
| --- | --- |
| URL routing (4 operations → 2 ATO endpoints) | API operation definitions |
| Input validation (ABN 11-digit, ACN 9-digit) | Inbound policy |
| Transaction ID generation | Inbound policy |
| API rate limiting, subscription keys | Inbound policy |
| OAuth2 / security | Inbound policy |
| ATO credential retrieval (Key Vault) | Inbound policy (named values) |
| Backend call to ATO REST endpoint | Backend section |
| XML-to-JSON transformation (canonical MetcashIdentifierBObj, per-version XSLT) | Outbound policy |
| SMC audit logging (success) | Outbound policy (send-request) |
| SMC audit logging (failure) | On-error policy (send-request) |
| Error handling and fault shaping | On-error policy |

---

## 5.1 EAII-289 - ATO Business Details Lookup

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The legacy implementation runs on TIBCO BusinessWorks BWCE (`TibcoATOBusinessDetails` service) and exposes synchronous REST API operations. The legacy service calls ABR **SOAP** endpoints and transforms the SOAP XML response into JSON.

| **Operation** | **Legacy Process** | **Endpoint** | **ABR SOAP Operation** | **Response Format** |
| --- | --- | --- | --- | --- |
| ABN Lookup | `fetchDetailsREST.bwp` | `/fetchDetailsREST/apn/getabn/v1?abn={abn}` | SOAP `SearchByABNv201408` | XML → JSON |
| ACN Lookup | `fetchDetailsREST.bwp` | `/fetchDetailsREST/apn/gettbn/v1?acn={acn}` | SOAP `SearchByASICv201408` | XML → JSON |

All operations share:

- A hardcoded ATO authentication GUID
- Common Logging (CLE) for audit events
- Synchronous request-response pattern with no intermediate state

> **Note:** The legacy service uses ABR SOAP endpoints. The proposed APIM solution replaces these with ATO REST endpoints. No SOAP calls are made in the proposed architecture.
>

#### 5.1.1.2 Process Flow Diagram

![image-20260624-055756.png](images/01.png)

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

The proposed implementation uses **APIM as the sole processing layer**. APIM exposes four consumer-facing operations (`SearchByABN`, `SearchByABNv2`, `SearchByACN`, `SearchByACNv2`) that route to two ATO **REST** endpoints. Each transforms the ATO XML response to canonical `MetcashIdentifierBObj` JSON using a per-version XSLT template, and returns JSON to the consumer. ATO credentials are retrieved from a data-specific Key Vault via APIM named values. Success and failure events are logged to SMC.

**Process Steps (all operations):**

1. Consumer application sends a GET request to an APIM endpoint (e.g. `/eis/abnlookup/v1/SearchByABN?abn={11-digit}`)
2. APIM inbound policy validates the query parameter (ABN=11-digit or ACN=9-digit)
3. APIM generates a Transaction ID (`context.RequestId` or `Guid.NewGuid()`)
4. APIM retrieves ATO API credentials from the data-specific Key Vault (via named value with Key Vault reference)
5. APIM logs SMC Begin event via `send-request` policy (TransactionID, lookup key, operation)
6. APIM sets the backend URL based on the operation:
  - SearchByABN / SearchByABNv2 → ATO SearchByABN
  - SearchByACN / SearchByACNv2 → ATO SearchByACN

7. APIM forwards the request to ATO REST endpoint with credentials; ATO returns XML response
8. APIM outbound policy transforms the XML to canonical `MetcashIdentifierBObj` JSON:
  - v1 endpoints (SearchByABN, SearchByACN) use XSLT v1 template
  - v2 endpoints (SearchByABNv2, SearchByACNv2) use XSLT v2 template

9. APIM sets `Content-Type: application/json`
10. APIM logs SMC End event via `send-request` policy (TransactionID, StatusCode=200)
11. APIM returns HTTP 200 + JSON response to consumer
12. On failure: APIM on-error policy logs SMC Error event (TransactionID, fault detail) and returns structured JSON error response

#### 5.1.2.2 Process Flow Diagram

![image-20260820-102840.png](images/04.png)

#### 5.1.2.3 Sequence Diagram

![image-20260820-103611.png](images/06.png)

#### 5.1.2.4 PlantUML

```
@startuml
title EAII-289 - ATO Business Details Lookup - Metcash Internal to ATO\nProcess Flow (APIM-Only Architecture)

skinparam backgroundColor #FEFEFE
skinparam sequenceArrowThickness 2
skinparam participantPadding 20
skinparam boxPadding 10

skinparam participant {
  BackgroundColor #E8F4FD
  BorderColor #0066CC
  FontStyle bold
}

skinparam database {
  BackgroundColor #FFF3E0
  BorderColor #FF9800
}

skinparam note {
  BackgroundColor #FFFDE7
  BorderColor #FBC02D
}

box "Internal Consumers" #F5F5F5
participant "Metcash\nConsumer Apps\n(MDM, CRM, etc.)" as CA
end box

box "Azure Integration Services" #E3F2FD
participant "Azure APIM\n(API Gateway)\n4 Endpoints" as APIM
participant "SMC\n(send-request\nLogging)" as SMC
participant "Azure\nKey Vault\n(ATO Credentials)" as KV
participant "Application\nInsights" as AI
end box

box "External - Australian Taxation Office" #E8F5E9
participant "ATO\nREST API\n(XML Response)" as ATO
end box

== 1. Consumer Request ==

CA -> APIM : REST/HTTPS GET\n/{operation endpoint}?{abn|acn}={value}\n\nEndpoints:\n- SearchByABN?abn=\n- SearchByABNv2?abn=\n- SearchByACN?acn=\n- SearchByACNv2?acn=

== 2. APIM Inbound Policy - Validate & Setup ==

APIM -> APIM : Match APIM Operation:\n- SearchByABN / SearchByABNv2\n- SearchByACN / SearchByACNv2

APIM -> APIM : Validate input parameter:\n- ABN: 11-digit numeric\n- ACN: 9-digit numeric

alt Validation fails (invalid ABN/ACN)
    APIM --> CA : HTTP 400 Bad Request\n(Invalid ABN/ACN format)
else Validation passes
end

APIM -> APIM : Generate Transaction ID\n(context.RequestId / Guid.NewGuid())

APIM -> KV : Retrieve ATO API Credentials\n(Named Value / Key Vault reference)\n(Managed Identity)
KV --> APIM : ATO credentials

APIM -> SMC : **SMC Begin Event** (send-request)\n(TransactionID, LookupKey, Operation)

== 3. APIM Backend - Route to ATO ==

APIM -> APIM : Set backend URL:\n- SearchByABN/ABNv2 → ATO SearchByABN\n- SearchByACN/ACNv2 → ATO SearchByACN

APIM -> ATO : REST/HTTP GET\n(with ATO credentials)
ATO --> APIM : XML Response\n(ATO business details)

== 4. APIM Outbound Policy - Transform ==

APIM -> APIM : XSLT Transform:\nATO XML → MetcashIdentifierBObj JSON\n(v1 endpoints use XSLT v1 template)\n(v2 endpoints use XSLT v2 template)

APIM -> APIM : Set Content-Type: application/json

APIM -> SMC : **SMC End Event** (send-request)\n(TransactionID, StatusCode=200)

== 5. Response to Consumer ==

APIM --> CA : HTTP 200 + JSON Response\n(MetcashIdentifierBObj)

== Exception Handling ==

note over APIM, SMC
  **On-Error Policy (any failure):**
  - ATO connectivity failure → SMC Error + HTTP 500
  - ATO timeout → SMC Error + HTTP 504
  - ATO error response → SMC Error + HTTP 502
  - XSLT transform failure → SMC Error + HTTP 500
  - Key Vault access failure → SMC Error + HTTP 500
  - All errors: TransactionID, fault detail, structured JSON error
end note

== Monitoring ==

note over APIM, AI
  **SMC / Application Insights**
  - APIM send-request: Begin → End/Error events
  - Custom dimensions: TransactionID, Operation,
    EventType, StatusCode, LookupKey
  - Alert rules: Error rate >10%, Latency >5s, ATO failure
  - Dashboard: Standard APIM analytics
end note

note over CA
  **Consumer Applications**
  - Protocol: REST over HTTPS (GET)
  - Auth: OAuth2 / Subscription Key
  - Response: MetcashIdentifierBObj JSON
  - No retry at integration layer
    (caller manages retries)
end note

note over ATO
  **Target System - ATO**
  - REST: SearchByABN, SearchByACN
  - Auth: ATO API Credentials (Key Vault)
  - Port: 80 (HTTP)
  - Response: XML
  - Routing:
    APIM SearchByABN/v2 → ATO SearchByABN
    APIM SearchByACN/v2 → ATO SearchByACN
end note

@enduml
```

### 5.1.3 Coordination

This integration operates **synchronously**. The consumer sends an HTTP GET and blocks until a response is received. APIM processes the request entirely within its policy pipeline without persisting state.

#### 5.1.3.1 Transaction Boundaries

Single HTTP request-response cycle: Consumer -> APIM -> ATO -> APIM -> Consumer. No intermediate state is persisted. No message queuing or retry at the integration layer.

#### 5.1.3.2 State Management

N/A - Stateless. No state is maintained between requests.

### 5.1.4 GoAnywhere Requirements

N/A - GoAnywhere is not used in this interface.

### 5.1.5 Design Considerations

1. **APIM-only architecture**: Since ATO provides REST endpoints returning XML, APIM can natively proxy the request and transform the XML response in outbound policies. No separate compute backend is required, reducing infrastructure and operational overhead.
2. **XML-to-JSON transformation in APIM**: The outbound policy uses XSLT templates to transform the ATO XML response into the canonical `MetcashIdentifierBObj` JSON format. The transformation is executed inline within the APIM policy pipeline.
3. **Data-specific Key Vault for ATO secrets**: ATO API credentials (API keys, authentication tokens) are stored in a data-specific Azure Key Vault, separate from platform secrets. APIM accesses these via named values with Key Vault references using Managed Identity.
4. **SMC logging for success and failure**: APIM policies use `send-request` actions to emit audit events to SMC. Success events are logged in the outbound policy; failure events are logged in the on-error policy. Both include the Transaction ID for correlation.
5. **No response format negotiation**: The consumer always receives JSON. APIM performs the XML-to-JSON transformation transparently, simplifying the consumer contract.
6. **No retry at integration layer**: Retries are the consumer's responsibility. See [4.5.1 Retry Strategy](https://dev.azure.com/METCASHDevOps/Squad%2020/_wiki/wikis/Squad-20.wiki?wikiVersion=GBwikiMaster&pagePath=/%22e81f28e8cac04291b10323d5aebfe9ac%22%20retry%20strategy) for rationale and consumer guidance.

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| **Interface ID** | **Process** | **Component** | **Component Type** | **Change Type** | **Repository** |
| --- | --- | --- | --- | --- | --- |
| EAII-289 | All Operations | APIM API Definition (4 operations) | API | New | Azure DevOps |
| EAII-289 | SearchByABN | APIM Policy (SearchByABN operation) | Policy XML | New | Azure DevOps |
| EAII-289 | SearchByABNv2 | APIM Policy (SearchByABNv2 operation) | Policy XML | New | Azure DevOps |
| EAII-289 | SearchByACN | APIM Policy (SearchByACN operation) | Policy XML | New | Azure DevOps |
| EAII-289 | SearchByACNv2 | APIM Policy (SearchByACNv2 operation) | Policy XML | New | Azure DevOps |
| EAII-289 | SearchByABN, SearchByACN | XSLT v1 Template (ATO XML to MetcashIdentifierBObj JSON) | Transform | New | Azure DevOps |
| EAII-289 | SearchByABNv2, SearchByACNv2 | XSLT v2 Template (ATO XML to MetcashIdentifierBObj JSON) | Transform | New | Azure DevOps |
| EAII-289 | All Operations | Key Vault Secret (ATO API credentials) | Secret | New | Azure Key Vault (data-specific) |

#### 5.1.6.2 Services

APIM API with four operations, each proxying to the corresponding ATO REST backend:

| **APIM Operation** | **Consumer Path** | **ATO Backend** | **Transform** | **Response** |
| --- | --- | --- | --- | --- |
| `SearchByABN` | `/api/ato/SearchByABN` | ATO REST SearchByABN (XML) | XSLT v1 → MetcashIdentifierBObj JSON | JSON |
| `SearchByABNv2` | `/api/ato/SearchByABNv2` | ATO REST SearchByABN (XML) | XSLT v2 → MetcashIdentifierBObj JSON | JSON |
| `SearchByACN` | `/api/ato/SearchByACN` | ATO REST SearchByACN (XML) | XSLT v1 → MetcashIdentifierBObj JSON | JSON |
| `SearchByACNv2` | `/api/ato/SearchByACNv2` | ATO REST SearchByACN (XML) | XSLT v2 → MetcashIdentifierBObj JSON | JSON |

#### 5.1.6.3 Logging

As per SMC specification and below information to be logged

1. Interface ID
2. As below spreadsheet

| **Step** | **Document ID** | **Document Type** | **Delivery Type** | **Direction** | **Source System** | **Destination System** | **Status** | **Reference** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Begin | Transaction ID (GUID) | Business Details Lookup Request | REST/HTTP | Inbound | Consumer App | APIM | Received | ABN or ACN value |
| End (Success) | Transaction ID (GUID) | Business Details Lookup Response | REST/HTTP | Outbound | APIM | Consumer App | Success | HTTP 200 |
| Error (Failure) | Transaction ID (GUID) | Business Details Lookup Fault | REST/HTTP | Outbound | APIM | Consumer App | Error | Fault detail |

##### 5.1.6.3.2 Audit

| **Observation Stage** | **Source/Target App** | **Information Captured**(Reference Keys) | **Description** | **Test Scenario**(FSD) |
| --- | --- | --- | --- | --- |
| Begin | Consumer -> APIM | TransactionID, ABN/ACN, Operation, Request endpoint | Lookup request received | T1 |
| End (Success) | APIM -> Consumer | TransactionID, Status Code (200), Operation | Lookup completed successfully | T1 |
| Error (Failure) | APIM -> Consumer | TransactionID, Fault detail, ATO response, Operation | ATO connectivity or business fault | T6, T7 |

##### 5.1.6.3.3 Exceptions

| **Observation Stage** | **Exception Scenario** | **Exception Category** | **Exception Code** | **Exception Message** | **Exception Handling** | **Status** |
| --- | --- | --- | --- | --- | --- | --- |
| APIM Inbound | ABN missing, empty, or not 11-digit numeric (SearchByABN / SearchByABNv2) | Business | HTTP 400 | ABN query parameter validation failure | APIM returns HTTP 400 JSON error; error event logged to SMC | Response returned |
| APIM Inbound | ACN missing, empty, or not 9-digit numeric (SearchByACN / SearchByACNv2) | Business | HTTP 400 | ACN query parameter validation failure | APIM returns HTTP 400 JSON error; error event logged to SMC | Response returned |
| Backend Call | ATO REST endpoint connectivity failure | Technical | HTTP 502 | Network error or timeout calling ATO | Log error to SMC; return HTTP 502 JSON error | Fault returned |
| Backend Call | ATO returns error response (invalid identifier, auth failure) | Technical | HTTP 502 | ATO error response detail | Log error to SMC; return JSON error with reason | Fault returned |
| Response Processing | XML-to-JSON transform failure (XSLT) | Technical | HTTP 500 | Cannot transform ATO XML response | Log error to SMC with details; return HTTP 500 JSON error | Fault returned |
| Any Stage | Key Vault access failure (ATO credentials unavailable) | Technical | HTTP 500 | Cannot retrieve ATO credentials | Log error to SMC; return HTTP 500 JSON error | Fault returned |
| Any Stage | SMC logging failure | Technical | N/A | SMC unavailable | Continue processing; raise platform alert | Lookup continues |
| Any Stage | Unexpected exception | Technical | HTTP 500 | Unhandled error | On-error policy catch-all; log to SMC; return HTTP 500 JSON error | Fault returned |

##### 5.1.6.3.4 Service consumers

| **Consumer** | **Protocol** | **Description** |
| --- | --- | --- |
| Metcash Internal Consumer Applications (MDM, CRM, Supplier Onboarding) | REST over HTTP/HTTPS | Internal applications performing business entity validation |

##### 5.1.6.3.5 Service Operations

| **Operation** | **Method** | **Path** | **Input** | **Response** | **Description** |
| --- | --- | --- | --- | --- | --- |
| SearchByABN | GET | `/eis/abnlookup/v1/SearchByABN` | `?abn={11-digit}` | JSON (MetcashIdentifierBObj) | ABN lookup via XSLT v1 transform |
| SearchByABNv2 | GET | `/eis/abnlookup/v2/SearchByABN` | `?abn={11-digit}` | JSON (MetcashIdentifierBObj) | ABN lookup via XSLT v2 transform |
| SearchByACN | GET | `/eis/abnlookup/v1/SearchByACN` | `?acn={9-digit}` | JSON (MetcashIdentifierBObj) | ACN lookup via XSLT v1 transform |
| SearchByACNv2 | GET | `/eis/abnlookup/v2/SearchByACN` | `?acn={9-digit}` | JSON (MetcashIdentifierBObj) | ACN lookup via XSLT v2 transform |

##### 5.1.6.3.6 Service Provider

| **Provider** | **Protocol** | **Operations** | **Description** |
| --- | --- | --- | --- |
| Australian Taxation Office (ATO) | REST over HTTP | SearchByABN, SearchByACN | ABN and ACN lookup operations returning XML (2 ATO REST endpoints serving 4 APIM operations) |

##### 5.1.6.3.7 Communications Data Structures

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Sample Files** | **Description** |
| --- | --- | --- | --- | --- | --- |
| Request (ABN) | Query: `abn` (11-digit) | ATO REST: ABN search request | See Mapping Document | `source_samples/abn/` | Consumer query to ATO REST request |
| Request (ACN) | Query: `acn` (9-digit) | ATO REST: ACN search request | See Mapping Document | `source_samples/acn/` | Consumer query to ATO REST request |
| Response (JSON) | ATO XML response | JSON (`MetcashIdentifierBObj`) | See Mapping Document | `target_samples/json/` | ATO XML to canonical JSON |

##### 5.1.6.3.8 Input/Output

| **Operation** | **Input** | **Input Schema** | **Output Schema (JSON)** |
| --- | --- | --- | --- |
| SearchByABN | `GET ...?abn={abn}` | Query: `abn` (11-digit string) | JSON (`MetcashIdentifierBObj`) |
| SearchByABNv2 | `GET ...?abn={abn}` | Query: `abn` (11-digit string) | JSON (`MetcashIdentifierBObj`) |
| SearchByACN | `GET ...?acn={acn}` | Query: `acn` (9-digit string) | JSON (`MetcashIdentifierBObj`) |
| SearchByACNv2 | `GET ...?acn={acn}` | Query: `acn` (9-digit string) | JSON (`MetcashIdentifierBObj`) |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Used By** |
| --- | --- | --- | --- |
| ATO REST — SearchByABN | GET to ATO SearchByABN endpoint | ATO API specification | SearchByABN, SearchByABNv2 operations |
| ATO REST — SearchByACN | GET to ATO SearchByACN endpoint | ATO API specification | SearchByACN, SearchByACNv2 operations |

**5.1.7 SMC Onboarding**

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | Business Details Lookup |
| Source Business Process | MDM |
| Source Application | MDM |
| Destination Business Process | Business Register Lookup |
| Destination Application | Australian Business Register (ATO) |
| Interface ID | EAII-289 |
| Interface Name | ATO Business Details Lookup - Metcash Internal to ATO |
| Interface Type | Synchronous Request-Reply |
| Interface DataStore | N/A (stateless) |
| Tags | `{"division": "corporate", "type": "lookup", "priority": "P3"}` |
| Reference Keys | TransactionID, ABN/ACN, X-Operation |
| Notification Type | Error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-289 |
| Correlation Properties | TransactionID, ABN/ACN |
| Reprocessing Required | No (consumer manages retries) |
| BusinessProcess Name | ATOBusinessDetailsLookup |

#### 5.1.7.2 SMC Load Estimations

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Average lookups/day | ~50–100 (ad-hoc, business-hours only) |
| Volume | Peak lookups/hour | ~20 |
| Volume | Concurrent requests | ≤ 10 |
| Volume | Seasonal considerations | None — stable, non-seasonal usage |
| Volume | Expected growth | Low — stable usage patterns |
| SMC Events | Events per lookup (success) | 2 (Begin + End) |
| SMC Events | Events per lookup (failure) | 2 (Begin + Error) |
| SMC Events | Estimated daily SMC events | 100–200 |

### 5.1.8 Monitoring

Standard AIS platform monitoring applies via Application Insights and Azure Monitor.

- **Alert rules**:
- Error rate > 10% over 5-minute window → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- Response time > 5 seconds (P95) → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- ABR backend connectivity failure → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)

### 5.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

**SearchByABN / SearchByABNv2**

| **ADO Test Case ID** | **Description** | **Location Of Sample Messages** |
| --- | --- | --- |
| T1 | Successful ABN lookup — expect HTTP 200 with MetcashIdentifierBObj JSON; TransactionID in SMC success log | source_samples/abn_valid.json |
| T2 | Lookup for an ABN that exists but is cancelled/no longer trading — expect HTTP 200 with response indicating current status (JSON) | source_samples/abn_cancelled.json |
| T3 | Lookup for a non-existent ABN — expect HTTP 200 with "not found" response payload (JSON) | source_samples/abn_notfound.json |
| T4 | Lookup with missing or empty ABN query parameter — expect HTTP 400 with JSON validation error; failure logged to SMC | N/A |
| T5 | Lookup with non-numeric or wrong-length ABN — expect HTTP 400 with JSON validation error | N/A |
| T6 | ATO service unavailable (simulated network failure) — expect HTTP 502 JSON error; failure event logged to SMC | N/A |
| T7 | ATO returns error response (e.g., bad authentication) — expect HTTP 502 JSON error with reason; failure event logged to SMC | N/A |
| T8 | XML-to-JSON transformation failure (malformed ATO response) — expect HTTP 500 JSON error; failure event logged to SMC | N/A |

**SearchByACN / SearchByACNv2**

| **ADO Test Case ID** | **Description** | **Location Of Sample Messages** |
| --- | --- | --- |
| T9 | Successful ACN lookup — expect HTTP 200 with MetcashIdentifierBObj JSON; TransactionID in SMC success log | source_samples/acn_valid.json |
| T10 | Lookup for an ACN where company is deregistered — expect HTTP 200 with current status (JSON) | source_samples/acn_deregistered.json |
| T11 | Lookup for a non-existent ACN — expect HTTP 200 with "not found" response (JSON) | source_samples/acn_notfound.json |
| T12 | Lookup with missing or empty ACN query parameter — expect HTTP 400 JSON error; failure logged to SMC | N/A |
| T13 | Lookup with non-numeric or wrong-length ACN — expect HTTP 400 JSON error | N/A |
| T14 | ATO service unavailable — expect HTTP 502 JSON error; failure event logged to SMC | N/A |
| T15 | ATO returns error response — expect HTTP 502 JSON error with reason; failure logged to SMC | N/A |

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![image-20260813-083248.png](images/08.png)

## 6.2 Network Connectivity

![image-20260813-083707.png](images/05.png)

| **Connection** | **Source** | **Destination** | **Protocol** | **Port** | **Authentication** |
| --- | --- | --- | --- | --- | --- |
| Inbound | Consumer Apps (internal) | APIM Gateway | REST over HTTPS | 443 | OAuth2 / Subscription Key |
| Outbound | APIM | ATO REST endpoints | REST over HTTP | 80 | ATO API credentials (from Key Vault) |
| Internal | APIM | Key Vault — Data (`t3datadv1ae1kv01`) | HTTPS | 443 | Managed Identity |
| Internal | APIM | Key Vault — Enabling (`t3enablingdevae1kv01`) | HTTPS | 443 | Managed Identity |
| Internal | APIM | Application Insights | HTTPS | 443 | Instrumentation Key |
| Internal | APIM | SMC | HTTPS | 443 | send-request policy |

## 6.3 Security

  - API Management and OAuth2 to be implemented for all APIs for Authentication/Authorisation.
  - APIM will use Managed Identity to access both Key Vaults.
  - Deny public access to Key Vaults and allow access from specific virtual networks.
  - Azure Key Vault — Data (`t3datadv1ae1kv01` in `COREIT-SERVICES-AIS-DV1`) will be used to store ATO REST API authentication credentials.
  - Azure Key Vault — Enabling (`t3enablingdevae1kv01` in `COREIT-SERVICES-AIS-NPR`) will be used to store platform secrets.
  - Control access to all Azure services/resources using RBAC.
  - All communication between internal endpoints will be through HTTPS.

### 6.3.1 Data Handling and Encryption

  - **Data classification**: Public
  - The data returned by the ATO/ABR is publicly available through the official Australian Business Register public search
  - ABN, ACN identifiers and the associated business name, status and address details are not classified as confidential
  - Standard logging and retention apply. No additional masking or encryption requirements above platform defaults
  - All internal data in transit is encrypted via TLS 1.2+

## 6.4 Infrastructure Support

Standard AIS platform infrastructure support applies. No special requirements beyond:

  - Key Vault secret rotation support (ATO API credential renewal)
  - APIM policy and transform template deployment via CI/CD

## 6.5 Infrastructure Requirements

| **Component** | **Non-Prod Specifications** | **Prod Specifications** | **New / Existing** |
| --- | --- | --- | --- |
| Azure API Management | Standard tier (shared instance) | Standard/Premium tier | Existing (shared) |
| Azure Key Vault - Data (`t3datadv1ae1kv01`) | Standard | Standard | Existing |
| Azure Key Vault - Enabling (`t3enablingdevae1kv01`) | Standard | Standard | Existing |
| Azure Application Insights | Standard | Standard | Existing (shared) |
| Azure Log Analytics Workspace | Standard | Standard | Existing (shared) |
| Virtual Network | Standard (existing subnets) | Standard (existing subnets) | Existing |

## 6.6 Infrastructure Resource Details

The following table captures the specific Azure resource names, subscription placement, and network configuration for this integration. `{env}` = `dev` | `sit` | `uat` | `prd`.

| **Resource Name** | **Type** | **Azure Resource Provider** | **Resource Group** | **Subscription** | **VNet** | **Subnet** | **IP Address** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `t1-met-core-{env}-ae1-apg-01` | Application Gateway | `Microsoft.Network/applicationGateways` | `t1-met-core-{env}-ae1-rsg-net` | `COREIT-SERVICES-HUB-{env}` | App GW VNet | App GW Subnet | Public: 20.42.203.106, Private: 10.247.1.71 |
| `t3-met-core-{env}-ae1-apim` | API Management | `Microsoft.ApiManagement/service` | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | APIM VNet | ECCS2 | Public VIP: 4.254.116.233, Private VIP: 10.247.1.4 |
| `t3-met-core-{env}-ae1-appi-apim` | Application Insights | `Microsoft.Insights/components` | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | N/A | N/A | N/A |
| (Log Analytics Workspace) | Log Analytics | `Microsoft.OperationalInsights/workspaces` | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | N/A | N/A | N/A |
| `t3datadv1ae1kv01` | Key Vault (data-specific) | `Microsoft.KeyVault/vaults` | `t3-met-ais-dv1-ae1-rsg-data` | `COREIT-SERVICES-AIS-DV1` | `t2-met-ais-dv1-ae1-net-01` | HSENS (10.247.85.0) | PE: `t3datadv1ae1kv01-pe` |
| `t3datadv1ae1kv01-pe` | Private Endpoint (Data KV) | `Microsoft.Network/privateEndpoints` | `t3-met-ais-dv1-ae1-rsg-data` | `COREIT-SERVICES-AIS-DV1` | `t2-met-ais-dv1-ae1-net-01` | HSENS (10.247.85.0) | N/A |
| `t3enablingdevae1kv01` | Key Vault (enabling) | `Microsoft.KeyVault/vaults` | `t3-met-ais-dev-ae1-rsg-enabling` | `COREIT-SERVICES-AIS-NPR` | `t2-met-ais-dev-ae1-net-01` | HSENS (10.247.85.0) | PE: `t3enablingdevae1kv01-pe` |
| `t3enablingdevae1kv01-pe` | Private Endpoint (Enabling KV) | `Microsoft.Network/privateEndpoints` | `t3-met-ais-dev-ae1-rsg-enabling` | `COREIT-SERVICES-AIS-NPR` | `t2-met-ais-dev-ae1-net-01` | HSENS (10.247.85.0) | N/A |
| APIM System-Assigned MI | Managed Identity | `Microsoft.ManagedIdentity` (system-assigned) | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | N/A | N/A | N/A |
| (RBAC Role Assignments) | Role Assignment | `Microsoft.Authorization/roleAssignments` | (both KV resource groups) | (both AIS subscriptions) | N/A | N/A | N/A |
| SMC | Service Management Console | N/A (External SaaS) | N/A (External) | N/A | N/A | N/A | N/A |

**Notes:**

  - **APIM Gateway URL**: `https://cloud-api-{env}-internal.metcash.com`
  - **Managed Identity**: APIM uses a **system-assigned managed identity** to authenticate to both Key Vaults. The identity is granted `Key Vault Secrets User` RBAC role on both `t3datadv1ae1kv01` and `t3enablingdevae1kv01`.
  - **Key Vault (Data)**: `t3datadv1ae1kv01` in `COREIT-SERVICES-AIS-DV1` / `t3-met-ais-dv1-ae1-rsg-data` — stores ATO API credentials.
  - **Key Vault (Enabling)**: `t3enablingdevae1kv01` in `COREIT-SERVICES-AIS-NPR` / `t3-met-ais-dev-ae1-rsg-enabling` — stores platform secrets.
  - **Log Analytics Workspace** is linked to Application Insights for log query and retention.
  - **Private Endpoints**: Both Key Vaults are accessed via private endpoints within their respective HSENS subnets.
  - APIM interacts with SMC via `send-request` policy actions for success and failure audit logging.

### **6.6.1 Azure API Management Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure API Management | Microsoft.ApiManagement/service | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | Microsoft.ApiManagement/service | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

### **6.6.2 AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**App Gateway:-**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

# 7 Communication Overview

## 7.1 Communication Components

All APIM endpoints use the consistent base URL pattern: `https://cloud-api-{env}-internal.metcash.com`

| **Environment** | **APIM Base URL** | **Operations** |
| --- | --- | --- |
| DEV | `https://cloud-api-dev-internal.metcash.com` | `/eis/abnlookup/v1/SearchByABN`, `/eis/abnlookup/v2/SearchByABN`, `/eis/abnlookup/v1/SearchByACN`, `/eis/abnlookup/v2/SearchByACN` |
| SIT | `https://cloud-api-sit-internal.metcash.com` | (same paths) |
| UAT | `https://cloud-api-uat-internal.metcash.com` | (same paths) |
| PREPROD | `https://cloud-api-preprod-internal.metcash.com` | (same paths) |
| PROD | `https://cloud-api-prd-internal.metcash.com` | (same paths) |

**ABR Backend Endpoints (per environment):**

| **Environment** | **ATO REST Endpoint** | **Notes** |
| --- | --- | --- |
| All | ATO ABN/ACN REST search endpoints<br> Base Url: `http://abr.business.gov.au:80/abrxmlsearch/AbrXmlSearch.asmx` | Per environment configuration via APIM named values |

# 8 Data Architecture

## 8.1 Data Model

*NA*

## 8.2 Stored Procedures

*NA*

## 8.3 Stored Procedure Triggers

*NA*

## 8.4 Database Technical Specification

*NA*

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

*NA*

### 8.5.2 Data Backup

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

*NA*

#### 8.5.3.2 State process for data/system destruction

*NA*

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

A parallel-run transition period may be required where both TIBCO BW6 and APIM endpoints are available. Consumer applications will be reconfigured to point to the new APIM endpoints. Rollback involves reverting endpoint configuration to the legacy TIBCO addresses.

## 9.2 Deployment Preference

APIM Standard/Premium tier provides 99.95% SLA with built-in regional redundancy. Given the low volume (ad-hoc lookups), no additional load balancing beyond platform defaults is required.

## 9.3 Deployment Environment Migration

All source code (APIM policies, XSLT transform templates, API definitions, Bicep/ARM templates) is managed under source control (Azure DevOps Repo).

Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure:

- DEV → SIT → UAT → PREPROD → PROD
- Environment-specific values (ATO endpoints, Key Vault references) managed via pipeline variables and APIM named values

# 10 Disaster Recovery

  - APIM Standard/Premium tier provides built-in regional redundancy
  - ATO (external) DR is managed by the Australian Taxation Office
  - No integration-level DR requirements beyond platform capabilities (Silver SLA — 95% availability during business hours)
  - Recovery: Redeploy APIM API definitions, policies, and transform templates from source control via CI/CD pipeline

# 11 Support Documentation

![diagram](images/03.png)![diagram](images/02.png)![diagram](images/07.png)

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | APIM policy execution timeout | APIM has a default forward request timeout of 300 seconds | Well within requirements (<5s target latency) |
| 2 | ATO REST endpoint uses HTTP (not HTTPS) | The ATO REST endpoint may operate on HTTP | This is the ATO's published endpoint; outside Metcash's control |
| 3 | ATO availability | The ATO REST API is externally managed by the ATO; its availability, throughput and contract changes are outside Metcash's control | Per FSD Section 2.3 |
| 4 | APIM transformation size limits | APIM policies have a body size limit for inline transformations (typically 256 KB for non-streaming) | ABR responses are small; not expected to be an issue |
| 5 | Key Vault secret rotation | ATO API credentials must be updated in Key Vault if the ATO issues new credentials | Manual rotation process unless auto-rotation is configured |
| 6 | XSLT version | APIM supports XSLT 1.0 only; complex transformations may require Liquid templates instead | Evaluate transform complexity during development |

# 13 Assumptions

  1. Consumer applications can be reconfigured to call the new APIM endpoints
  2. The `MetcashIdentifierBObj` canonical schema is defined and available in JSON Schema form
  3. The ATO REST API contract remains stable during and after migration
  4. The existing APIM infrastructure (shared instance) has sufficient capacity for low-volume ad-hoc lookups
  5. Network connectivity between the APIM VNet and the ATO REST endpoints is established or can be established
  6. SMC supports receiving audit events via HTTP calls from APIM `send-request` policy actions
  7. The ATO XML response structure is well-defined and can be reliably transformed to the canonical JSON format within APIM policies
  8. A data-specific Key Vault is available (or will be provisioned) for storing ATO API credentials
  9. Consumer applications always expect JSON responses; no XML response format is required

# 14 Reference Documents and Architecture

| **Document** | **Link** |
| --- | --- |
| Azure API Management policies reference | [Microsoft Learn — APIM policies](https://learn.microsoft.com/en-us/azure/api-management/api-management-policies) |
| Transform and protect APIs — Azure API Management | [Microsoft Learn — Transform API](https://learn.microsoft.com/en-us/azure/api-management/transform-api) |
| XSLT transformation in APIM policies | [Microsoft Learn — XSLT policy](https://learn.microsoft.com/en-us/azure/api-management/xslt-policy) |
| Azure API Management Named Values / Key Vault | [Microsoft Learn — Named Values](https://learn.microsoft.com/en-us/azure/api-management/api-management-howto-properties) |
| Functional Specification — EAII-289 — MDM Supplier to ATO | [FSD — EAII-289](https://metcash.sharepoint.com/sites/EAI/Shared%20Documents/EAII-289) |
| Mapping Manifest — EAII-289 — Metcash Internal to ATO | [Mapping Manifest — EAII-289](https://metcash.sharepoint.com/sites/EAI/Shared%20Documents/EAII-289) |
| Target canonical schema | `Schemas/MetcashIdentifierBObj.json` (JSON) |

![diagram](images/09.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |
