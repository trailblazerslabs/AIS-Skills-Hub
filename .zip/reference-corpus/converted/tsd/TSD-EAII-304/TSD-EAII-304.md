<!-- Source: Technical+Specification+-+EAII-304+-+Liquor+Suppliers+to+EIM.doc -->
<!-- Title: Technical Specification - EAII-304 - Liquor Suppliers to EIM -->

# Technical Specification - EAII-304 - Liquor Suppliers to EIM

**Table of Contents**

- 1 Document Overview
  - 1.1 Background
  - 1.2 Document Purpose
  - 1.3 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope

- 3 Compliance
  - 3.1 Architecture Principles
  - 3.2 Standards, Guidelines and Patterns

- 4 Requirements Overview
  - 4.1 Business Process Requirement and Integration
    - 4.1.1 Process Diagram from FSD
    - 4.1.2 Functional Specification Document

  - 4.2 Technical standard and requirements
  - 4.3 Required Components
  - 4.4 Environmental Requirement

- 5 Integration Overview and Implementation
  - 5.1 EAII-304 - Liquor Suppliers to EIM
    - 5.1.1 As-is Process(es)
      - 5.1.1.1 Description of Process(es)
      - 5.1.1.2 Process Flow Diagram

    - 5.1.2 Proposed Process(es)
      - 5.1.2.1 Description of Process(es)
      - 5.1.2.2 Process Flow Diagram
      - 5.1.2.3 Sequence Diagram
      - 5.1.2.4 PlantUML

    - 5.1.3 Coordination
      - 5.1.3.1 Transaction Boundaries
      - 5.1.3.2 State Management

    - 5.1.4 GoAnywhere Requirements
      - 5.1.4.1 PRONTO to Azure

    - 5.1.5 Design Considerations
    - 5.1.6 Service High Level Design
      - 5.1.6.1 Component List
      - 5.1.6.2 Services
      - 5.1.6.3 IBADirects Upload Service
        - 5.1.6.3.1 Logging
        - 5.1.6.3.2 Audit
        - 5.1.6.3.3 Exceptions
        - 5.1.6.3.4 Service consumers
        - 5.1.6.3.5 Service Operations
        - 5.1.6.3.6 Service Provider
        - 5.1.6.3.7 Communications Data Structures
        - 5.1.6.3.8 Input/Output
        - 5.1.6.3.9 Fulfillment Services

    - 5.1.7 SMC Onboarding
      - 5.1.7.1 Integration Onboarding
      - 5.1.7.1 SMC Load Estimations

    - 5.1.8 Monitoring
    - 5.1.9 Reporting
    - 5.1.10 Integration and Testing Requirements
      - 5.1.10.1 Development and Integration Strategy
      - 5.1.10.2 Unit Testing

- 6 Architecture Overview
  - 6.1 Physical Architecture Diagram
  - 6.2 Network Connectivity
  - 6.3 Security
    - Key Vault Secret

  - 6.4 Infrastructure Support
  - 6.5 Infrastructure Requirements

- 7 Communication Overview
  - 7.1 Communication Components

- 8 Data Architecture
  - 8.1 Data Model
  - 8.2 Stored Procedures
  - 8.3 Stored Procedure Triggers
  - 8.4 Database Technical Specification
  - 8.5 Data Retention
    - 8.5.1 Data Retention Procedures
      - 8.5.1.1 Data storage and retention

    - 8.5.2 Data Backup
    - 8.5.3 Data Destruction Procedures
      - 8.5.3.1 Data Destruction Metrics and Timeframes
      - 8.5.3.2 Standard Process for Data/System Destruction

- 9 Deployment and Monitoring Considerations
  - 9.1 Transition Period
  - 9.2 Deployment Preference
  - 9.3 Deployment Environment Migration

- 10 Disaster Recovery
- 11 Support Documentation
- 12 Limitations and Constraints
- 13 Assumptions
- 14 Reference Documents and Architecture
- 15 TSD Approval Checklist

| **TSD Author** | [Raj Duraisamy](https://metcash.atlassian.net/wiki/people/712020:f7f096f2-337c-41f4-85de-01ae39be92f0?ref=confluence) |
| --- | --- |

| **Document Approver** | **Approver Role** |
| --- | --- |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Magesh Parthasarathy | Solution Architect |
| Mohanraj Vengiduswamy | Test Manager |

# 1 Document Overview

## 1.1 Background

Independent Brands Australia (IBA), a division of Australian Liquor Marketers (ALM) within Metcash, manages several liquor retail brands, including **The Bottle-O**, **Cellarbrations**, and **Porters**. IBA operates the **Directs** service, which enables liquor suppliers, such as **CUB** and **Coopers**, to electronically submit direct delivery order data to Metcash. These transactions represent supplier-to-retailer deliveries that bypass the traditional Metcash warehouse distribution network.

The IBA Directs integration allows suppliers to upload direct delivery transaction data through a secure REST API. Each submission contains supplier information, product details (including item codes, descriptions, GTINs, and pack sizes), customer and retailer information (including account numbers, names, and addresses), and invoice details such as invoice numbers, dates, quantities, and monetary values.

Upon successful upload, the submitted source file is securely stored in Azure Blob Storage and processed asynchronously. The integration extracts and transforms the source JSON data into a pipe-separated values (PSV) file that conforms to the format required by the **Enterprise Information Management (EIM)** platform. The generated PSV file is then delivered to the ALM landing location for downstream processing and reporting.

This document describes the functional requirements and technical design for re-implementing the existing IBA Directs integration on **Azure Integration Services (AIS)** as part of the migration from the legacy **TIBCO BusinessWorks** platform. The solution leverages Azure API Management, Logic Apps, Azure Functions, Azure Blob Storage, Event Grid, Service Bus, and other Azure platform services to provide a secure, scalable, and event-driven integration architecture.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the *IBA Directs ALM Orders* (EAII-304) between *Liquor Suppliers* and *EIM*.

## 1.3 Glossary

| **Item** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| ALM | Australian Liquor Marketers - Metcash's liquor distribution division |
| EIM | Enterprise Information Management - downstream data processing platform |
| GTIN | Global Trade Item Number - international barcode standard for products |
| IBA | Independent Brands Australia - a division of ALM managing retail brands |
| PSV | Pipe-Separated Values - a flat file format using the pipe character as a delimiter |

# 2 Scope

*The scope of the integration should be clearly defined to ensure all stakeholders have a comprehensive understanding of its objectives and boundaries. This includes identifying the systems involved, the specific functionalities to be integrated, and the expected outcomes. By establishing a well-defined scope, we can facilitate smoother collaboration and ensure that all parties are aligned on the project goals.*

## 2.1 In Scope

The following capabilities are included in the scope of this integration:

- Receipt of direct delivery order data from liquor suppliers via a REST API.
- Authentication of API requests using OAuth 2.0 Bearer Tokens.
- Validation of incoming requests, including payload structure and file size.
- Storage of uploaded source files in Azure Blob Storage.
- Event-driven asynchronous processing of uploaded files.
- Decompression of uploaded ZIP files.
- Transformation of source data into the required Pipe-Separated Values (PSV) format.
- Delivery of generated PSV files to the designated output location.
- Archival of successfully processed source files.
- Error handling with retry mechanisms for transient failures.
- Transaction logging and auditability.
- Cleanup of temporary processing artifacts.

## 2.2 Out of Scope

The following items are outside the scope of this integration:

- Downstream processing of PSV files by the Enterprise Information Management (EIM) platform.
- File transfer from the Azure Blob Storage output location to downstream systems, which is performed by GoAnywhere Managed File Transfer (MFT).
- Business validation of direct delivery order data, such as supplier, product, or customer master data validation.
- Migration or reprocessing of historical direct delivery order data.

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

| **Code** | **Principle** | **Why It Applies** |
| --- | --- | --- |
| **IDP-001** | **Generic and Reusable** | The integration is implemented using reusable Azure components, including Azure API Management, Logic Apps, Azure Functions, and the shared Blob Management Function. The upload, transformation, and storage components are designed for reuse across integrations where applicable. |
| **IDP-002** | **Decoupled Integrations** | The consumer-facing REST API is decoupled from downstream processing through Azure Blob Storage, Event Grid, and Azure Service Bus. This event-driven architecture enables independent scaling, asynchronous processing, and loose coupling between file upload, transformation, and downstream delivery. |
| **IDP-003** | **Integrated Security** | Consumer-facing APIs are secured using OAuth 2.0 Bearer Token authentication through Azure API Management. Secrets, certificates, and connection information are stored in Azure Key Vault and accessed using Managed Identity. All communication between Azure services is secured using Azure-native authentication and HTTPS. |
| **IDP-004** | **Standardization** | The solution follows Metcash Azure Integration Services standards by exposing REST APIs through Azure API Management, implementing orchestration with Logic Apps, using inline functions for transformation, and following the Azure resource naming conventions and deployment standards. |
| **IDP-005** | **Resilient and Recoverable** | The solution uses Azure-native resiliency features, including Event Grid retry policies, Azure Service Bus durable messaging and dead-letter queues, and configurable retry policies in Logic Apps and Azure Functions to recover from transient failures and ensure reliable message processing. |
| **IDP-006** | **Observability** | End-to-end transaction monitoring is provided through SMC, while Azure Application Insights captures request telemetry, dependency tracking, exceptions, and performance metrics. Logic App run history, Azure Function logs, and Azure Monitor diagnostics support operational monitoring and troubleshooting. |

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

| **Pattern Name** | **Implementation Description** |
| --- | --- |
| **Azure Logic Apps** | Azure Logic Apps are used to orchestrate the upload and asynchronous processing workflows. The workflows are stateless, modular, and designed around discrete business capabilities, improving maintainability and scalability. |
| **API Management Service** | Azure API Management (APIM) acts as the secure API gateway, exposing the upload REST endpoint to liquor suppliers. APIM provides request authentication, payload validation, policy enforcement, and abstracts the backend implementation from consumers. |
| **Event-Driven Processing** | Azure Event Grid is used to trigger downstream processing when a source file is successfully uploaded to Azure Blob Storage. This enables an event-driven architecture and decouples file upload from transformation processing. |
| **Asynchronous Messaging** | Azure Service Bus is used to decouple file transformation from downstream processing. Queue-based messaging provides reliable, asynchronous processing and supports retry and dead-letter handling for failed messages. |
| **Azure Functions** | Azure Functions implement reusable processing components for blob management, ZIP file decompression, and transformation of source data into the required PSV format. |
| **Retry and Resilience** | Azure-native retry mechanisms are implemented across Logic Apps, Azure Functions, Event Grid, and Service Bus to handle transient failures. Dead-letter queues are used for messages that cannot be successfully processed after the configured retry attempts. |
| **Logging and Observability** | Application Insights and SMC provide end-to-end monitoring, including request telemetry, dependency tracking, exception logging, transaction tracing, and operational diagnostics. |
| **Security Abstraction** | Security is enforced through Azure API Management using OAuth 2.0 Bearer Token authentication. Secrets, certificates, and application configuration are securely stored in Azure Key Vault and accessed using Managed Identity. |
| **Standardization and Governance** | The solution adheres to Metcash Azure Integration Services standards, including standardized API design, Azure resource naming conventions, consistent error handling, monitoring, and deployment practices. |

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

![image-20260703-052306.png](images/02.png)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| FSD EAII-304 - Liquor Suppliers to EIM | [Functional Specification - EAII-304 - Liquor Suppliers to EIM](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3504013319/Functional+Specification+-+EAII-304+-+Liquor+Suppliers+to+EIM) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization
- Managed Identities for Azure service-to-service authentication (Logic Apps, Function Apps accessing Key Vault, Service Bus, Blob Storage)

## 4.3 Required Components

The following components are required for this integration:

| **Component** | **Purpose / Description** |
| --- | --- |
| **Azure API Management (APIM)** | Exposes the inbound REST API endpoint (**POST eis/ibadirects/v1/submitOrder**) to liquor suppliers. Performs OAuth 2.0 Bearer Token authentication, request validation, payload schema validation, and file size validation before forwarding requests to the backend. |
| **Azure Logic Apps** | The **Translation Logic App** is triggered by messages received from Azure Service Bus and orchestrates the end-to-end asynchronous processing workflow, including source ZIP retrieval, decompression, data transformation, PSV file generation, source file archival, and error handling. |
| **Azure Function Apps** | Provides reusable processing components, including Blob Management (UploadBlob), ZIP file decompression, and transformation of the extracted source data into the required PSV format. |
| **Azure Event Grid** | Monitors Azure Blob Storage for newly uploaded files and publishes Blob Created events to trigger asynchronous processing by the Processing Logic App. |
| **Azure Service Bus** | Provides reliable asynchronous messaging between the transformation process and downstream processing. Supports durable message delivery, retries, and dead-letter queues for failed processing. |
| **Azure Blob Storage** | Serves as the durable storage layer for uploaded source files, processed PSV files, archived files, and error files throughout the integration lifecycle. |
| **Azure Key Vault** | Securely stores application secrets, certificates, and configuration required by the integration. Secrets are accessed using Managed Identity. |
| **Azure Application Insights** | Provides application telemetry, request tracking, dependency monitoring, exception logging, and performance metrics for Logic Apps and Azure Functions. |
| **Azure Log Analytics Workspace** | Centralizes diagnostic logs and monitoring data from Azure resources, enabling cross-component log analysis, dashboards, and alerting. |
| **Azure Virtual Network (VNet)** | Provides secure network connectivity for Azure resources and supports private communication between integration components where required. |

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DV1)
- System Integration Testing (ST1)
- User Acceptance Test (UT1)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).

# 5 Integration Overview and Implementation

## 5.1 EAII-304 - **Liquor Suppliers to EIM**

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The legacy integration is implemented on TIBCO BusinessWorks and consists of two phases:

**Upload Phase (Legacy TIBCO):** The TIBCO `IBADirectsService.bwp` process exposes a REST API endpoint (`POST eis/ibadirects/v1/submitOrder`). A supplier submits a JSON request containing a `DocumentHeader` (Transaction ID, Document Type, Timestamp, Supplier ID) and the directs file content as a base64-encoded ZIP archive. The integration authenticates the request by validating the bearer token against a static set of pre-provisioned API keys loaded at startup from S3 cloud storage and cached in memory (`Activator.bwp`). If authentication succeeds, the `JMSUploadDirectsFile.bwp` subprocess (via `UploadAPI.bwp`) validates the payload, stores the ZIP to the S3 input directory, and places a message on a JMS queue. The API returns a synchronous success/error response.

**Translation Phase (Legacy TIBCO):** The `JMSTranslateToPSV.bwp` JMS listener picks up the queued message and invokes the `XlateToPSV.bwp` subprocess, which: downloads the source ZIP from S3, writes it to a temporary directory, decompresses it using the `UnzipFile.java` utility, parses the extracted JSON source file, transforms each record to PSV format using the `EIMFile.dataFormatResource` DataFormat configuration, uploads the PSV file to the S3 output directory, moves the source ZIP to the S3 archive directory, and deletes temporary files.

**Known Issues in Legacy Platform:**

1. Static token management — tokens loaded at startup, no dynamic rotation; requires service restart to update tokens.
2. Single-threaded translation (`MaxSessions=1`) — files processed sequentially.
3. File size validation only at API entry point; no secondary check in translation phase.

#### 5.1.1.2 Process Flow Diagram

![image-20260703-052306.png](images/02.png)

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

The proposed Azure Integration Services (AIS) solution retains the existing two-phase processing model while addressing the limitations of the legacy implementation. Authentication is performed using an OAuth2 Bearer token validated by Azure API Management (APIM), while Azure Service Bus decouples the upload and translation processes to improve reliability, scalability, and resilience.

**Upload Phase (AIS):**

1. **API Request Received** — A liquor supplier submits a `POST` request to APIM endpoint `eis/ibadirects/v1/submitOrder` with bearer token and a JSON `DirectsFileDocument` body containing a `SupplierID` and base64-encoded ZIP file content.
2. **Authentication** — APIM validates the bearer token. If invalid or missing, APIM returns `HTTP 401 Unauthorized`
3. **Payload Validation** — APIM validates: the request payload to ensure that the `SupplierID` is provided. If the `SupplierID` is missing, APIM returns an **HTTP 400 Bad Request** response.
4. **File Size Validation** — APIM validates the file size of **3 MB**. Based on the validation result, APIM generates the target Blob Storage path:
  - **Valid file:** `IBADirects/in/{SupplierId}_{yyyyMMddHHmmss}.zip`
  - **File exceeding 3 MB:** `IBADirects/error/{SupplierId}_{yyyyMMddHHmmss}.zip`

5. **Upload backend API call**— APIM forwards the request to the backend and uploads the ZIP file to the specified blob path using EAII-367 blob management upload API.
6. **Return Synchronous Response** — After successful upload response from backend If the file exceeds the 3 MB limit, returns the bad request. Otherwise, APIM receives the response from the backend and returns the same response to the consumers.
7. **Log Transaction** — The transaction outcome, including success or error status, is logged to SMC with Transaction ID, Supplier ID, Document Type, and status.

**Translation Phase (AIS):**

1. **Publish Blob Created Event** — After the ZIP file is successfully stored in `IBADirects/in`, Azure Blob Storage publishes a **Blob Created** event to **Azure Event Grid**.
2. **Route Event to Service Bus** — Azure Event Grid publishes a message to the `b2b.ibadirectstoeim.sbq-{env}` Azure Service Bus queue. The message contains the blob path and filename, along with the **Supplier ID, timestamp, and Transaction ID** required for downstream processing.
3. **Translation Logic App Triggered** — The **Translation Orchestrator Logic App** is triggered when a message is received from the `b2b.ibadirectstoeim.sbq-{env}` Azure Service Bus queue.
4. **Download Source File** — The Logic App retrieves the source ZIP file from `IBADirects/in` in Azure Blob Storage using the blob path provided in the Service Bus message.
5. **Decompress ZIP File** — The Logic App decompresses the ZIP archive and extracts the source JSON file to temporary storage.
  - **On failure:** Log and update the SMC transaction history with an error status.

6. **Transform to PSV** — The Translation Logic App reads the extracted JSON file from temporary storage and passes its content to the **Inline Azure Function**. The function iterates through all `DirectsData` records, transforms each record into a **20-field pipe-separated (PSV) row**, and returns the generated PSV content to the Logic App.
  - **On failure:** Log and update the SMC transaction history with an error status.

7. **Generate Output Files** — The Logic App generates the following output files:
  - **PSV file:** `{SourceFileNameWithoutExtension}.PSV`
  - **Deliver Output Files** — The Logic App uploads both the PSV file to `IBADirects/ToEIM` in Azure Blob Storage for pickup by **GoAnywhere/EIM**.
  - **On storage failure:** Retry the operation up to **3 times**. If all retries are exhausted, log the applicable storage error code and update the SMC transaction history with an error status.

8. **Archive Source File** — After successful transformation and output file delivery, the Logic App moves the original source ZIP file from `IBADirects/in` to `IBADirects/archive`.
  - **On failure:** Log and update the SMC transaction history with an error status.

9. **Cleanup Temporary Files** — The Logic App deletes any temporary files created during the processing from temporary storage.
10. **Log Transaction** — The translation outcome is logged to SMC with the **Transaction ID, Supplier ID, processing timestamps, and final transaction status**.

#### 5.1.2.2 Process Flow Diagram

![EAII-304-Process Flow Design.drawio (2)-20260805-155826.png](images/07.png)

#### 5.1.2.3 Sequence Diagram

![image-20260810-051801.png](images/01.png)

#### 5.1.2.4 PlantUML

```
@startuml EAII-304 IBADirects Upload Sequence

title EAII-304 - IBA Directs Upload & Processing\nProposed AIS Sequence

participant "Microsoft Entra ID" as AAD
actor "Liquor Supplier" as Supplier
participant "Azure APIM\nt3-met-core-{apim-env}-ae1-apim" as APIM
participant "UploadBlob\nAzure Function" as UploadBlob
database "Azure Blob Storage\nt3b2b{env}aesta01\nALM container" as Blob
participant "Azure Event Grid\nevt-t3b2b{env}aesta01-alm-ibadirects-in-create-sbq-{env}-ae" as EG
queue "Azure Service Bus\nt2-met-{npr/prd}-ae-sb001\nQueue: b2b.ibadirectstoeim.sbq-{env}" as SB
participant "Translation Logic App\nt3-met-b2b-ibadirects-{env}-ae-logic" as ProcessLA
participant "PSV Converter\nInline Azure Function" as PSV
participant "GoAnywhere Managed File Transfer" as MFT
participant "SMC" as SMC

== Upload Phase ==

Supplier -> AAD : Request OAuth Access Token
AAD --> Supplier : Access Token

Supplier -> APIM : POST eis/ibadirects/v1/submitOrder\nBearer Token + JSON Payload

APIM -> APIM : Validate Bearer Token
APIM -> APIM : Validate Request Payload

alt Authentication Failed

    APIM -> SMC : Log Authentication Failure
    APIM --> Supplier : HTTP 401 Unauthorized

else Payload Validation Failed

    APIM -> SMC : Log Validation Failure
    APIM --> Supplier : HTTP 400 Bad Request

else File Size > 3 MB

    APIM -> UploadBlob : Upload ZIP\nIBADirects/error/{SupplierId}_{Timestamp}.zip
    UploadBlob -> Blob : Store ZIP\nIBADirects/error
    Blob --> UploadBlob : Upload Result
    UploadBlob --> APIM : Upload Result

    APIM -> SMC : Log IBADIRECTS-ERR-001\nFile Size Exceeded
    APIM --> Supplier : Error Response

else Valid Request

    APIM -> UploadBlob : Upload ZIP\nIBADirects/in/{SupplierId}_{Timestamp}.zip
    UploadBlob -> Blob : Store ZIP\nIBADirects/in
    Blob --> UploadBlob : Upload Result
    UploadBlob --> APIM : Upload Success

    APIM -> SMC : Log Upload Success\nTransaction ID + Supplier ID
    APIM --> Supplier : Return Backend Response

end

== Asynchronous Translation Phase ==

Blob -> EG : Blob Created Event\nIBADirects/in

EG -> SB : Publish Event\nBlob Path + Metadata

SB -> ProcessLA : Service Bus Trigger

ProcessLA -> Blob : Download Source ZIP\nIBADirects/in
Blob --> ProcessLA : ZIP File

ProcessLA -> ProcessLA : Decompress ZIP
ProcessLA -> ProcessLA : Read Extracted JSON

ProcessLA -> PSV : Pass JSON Content
PSV --> ProcessLA : PSV Content

ProcessLA -> ProcessLA : Generate PSV File
ProcessLA -> ProcessLA : Generate Trigger File

ProcessLA -> Blob : Upload PSV\nIBADirects/ToEIM
Blob --> ProcessLA : Upload Successful

ProcessLA -> Blob : Upload PSV.trg\nIBADirects/ToEIM
Blob --> ProcessLA : Upload Successful

ProcessLA -> Blob : Move ZIP\nIBADirects/archive
Blob --> ProcessLA : Archive Complete

ProcessLA -> ProcessLA : Delete Temporary Files

ProcessLA -> SMC : Log Translation Success\nTransaction ID + Supplier ID

ProcessLA -> SB : Complete Message

MFT -> Blob : Pickup Files\nIBADirects/ToEIM
Blob --> MFT : PSV and Trigger Files

== Translation Error Handling ==

alt ZIP Decompression Failed

    ProcessLA -> SMC : Log IBADIRECTS-ERR-003
    ProcessLA -> SB : Abandon Message

else PSV Transformation Failed

    ProcessLA -> SMC : Log IBADIRECTS-ERR-002
    ProcessLA -> SB : Abandon Message

else Output Upload Failed

    ProcessLA -> SMC : Log Storage Failure
    ProcessLA -> SB : Abandon Message

else Archive Failed

    ProcessLA -> SMC : Log IBADIRECTS-ERR-004
    ProcessLA -> SB : Abandon Message

end

@enduml
```

### 5.1.3 Coordination

This integration operates in two modes:

  - **Synchronous (Upload Phase):** The supplier request is processed synchronously through **Azure APIM**. APIM authenticates and validates the request, determines the target Azure Blob Storage path, and invokes the **UploadBlob Function** to store the ZIP file. Once the upload is completed successfully, APIM returns the backend response to the supplier confirming receipt.
  - **Asynchronous (Translation Phase):** The translation process operates asynchronously and is decoupled from the supplier's upload request. Once the ZIP file is successfully stored in Azure Blob Storage, a **Blob Created** event is published to **Azure Event Grid**, which routes the event to the **Azure Service Bus** queue. The **Translation Logic App** is triggered by the Service Bus message and independently retrieves, decompresses, transforms, and delivers the output files to the `IBADirects/ToEIM` location. This decoupled approach enables reliable, scalable, and resilient background processing without impacting the synchronous upload response.

#### 5.1.3.1 Transaction Boundaries

  - **Upload Transaction Boundary:** The upload transaction begins when the supplier request is received by **Azure APIM** and includes request authentication, payload validation, ZIP file upload to Azure Blob Storage (`IBADirects/in` or `IBADirects/error`), and return of the backend response to the supplier. The successful upload is subsequently processed through the **Blob Created** event, **Azure Event Grid**, and **Azure Service Bus** for downstream translation. Any failure during authentication, validation, or file upload is treated as an upload transaction failure, logged to SMC, and returned to the supplier through the appropriate response. Event Grid and Service Bus processing are asynchronous and form part of the downstream processing flow rather than the synchronous APIM transaction boundary.
  - **Translation Transaction Boundary:** The translation transaction begins when the **Translation Logic App** receives the Azure Service Bus message and includes downloading the source ZIP file, decompression, JSON-to-PSV transformation, generation of the PSV file, upload of the output files to `IBADirects/ToEIM`, archival of the source ZIP file to `IBADirects/archive`, cleanup of temporary resources, completion of the Service Bus message, and logging of the final transaction outcome to SMC. If any processing step fails, the failure is logged to SMC and the Service Bus message is retried or abandoned according to the configured retry policy. If the configured delivery attempts are exhausted, the message is moved to the dead-letter queue for further investigation.

#### 5.1.3.2 State Management

State is maintained through **Azure Blob Storage** and **Azure Service Bus** to support reliable, event-driven asynchronous processing:

- `IBADirects/in` — Stores source ZIP files that have been successfully uploaded and are awaiting translation. A **Blob Created** event is generated when a new file is stored and published to Azure Event Grid.
- **Azure Event Grid** — Receives the Blob Created event for files in `IBADirects/in` and routes the event to the configured Azure Service Bus queue, enabling event-driven downstream processing.
- **Azure Service Bus (**`b2b.ibadirectstoeim.sbq-{env}`**)** — Maintains the translation processing state by queuing incoming processing requests. It provides reliable message delivery, retry handling, and dead-lettering until the Translation Logic App successfully processes the message.
- `IBADirects/ToEIM` — Stores the generated PSV file awaiting pickup by GoAnywhere MFT/EIM.
- `IBADirects/archive` — Stores source ZIP files that have been successfully translated and processed, providing a temporary archive for operational tracking and audit purposes.
- `IBADirects/error` — Stores source ZIP files that fail upload validation or processing-related validation, such as files exceeding the configured maximum size, allowing them to be retained for troubleshooting and audit purposes.

### 5.1.4 GoAnywhere Requirements

#### 5.1.4.1 PRONTO to Azure

1. GoAnywhere is configured to
  1. Poll *.psv files every 30 minutes from storage account.
  2. Copy the files in to EIM Azure blob storage
  3. Move the successfully processed file into archive folder

2. Success and failure status will be logged in SMC.
3. SMC is configured to send out alert notification to configured emailID’s on any failure log entries.
4. Log all the observation stages and observation points into SMC against InterfaceId `EAII-304`

| **Interface ID** |  | EAII-304 |
| --- | --- | --- |
| **Interface Name** |  | EAII-304-Azure-2-EIM |
| **Monitor Name** |  | EAII-304-Azure-2-EIM |
| **Source System** |  | Azure Blob Container (From IBA Direct) |
| **Source Encryption** |  | NA |
| **Target System** |  | EIM Azure Blob Container |
| **Target Encryption** |  | NA |
| **GroupName** |  | B2B/IBADirects |
| **Translator Source Filename Convention** |  | IBADIRECTS-COOPERSBREWERY-20260924132002.PSV |
| **Translator Source Filename Example** |  | IBADIRECTS-COOPERSBREWERY-20260924132002.PSV |
| **TransactionIDType** |  | string |
| **TransactionID** |  | ObservationID - GA Job id. |
| **TransactionID Example** |  | ObservationID - 1000003648618 |
| **Source File Protocol** |  | HTTPs |
| **Target File Protocol** |  | HTTPs |
| **File Delivery Routing Rules** |  | Pass through the file from Azure to EIM Azure Storage |
| **Source Connection Details** | **UAT** | resource:azureblob://t3b2but1aesta01-ibadirects/IBADirects/toeim<br> resource:azureblob://t3b2but1aesta01-ibadirects/IBADirects/archive/toeim |
|  | **PROD** | resource:azureblob://t3b2bprdaesta01-ibadirects/IBADirects/toeim<br> resource:azureblob://t3b2bprdaesta01-ibadirects/IBADirects/archive/toeim |
| **Target Connection Details** | **UAT** | resource:azureblob://eimuatg2lake-IBA_DIRECTS-TIBCO_LANDING |
|  | **PROD** | resource:azureblob://eimprdg2lake-IBA_DIRECTS-TIBCO_LANDING |
| **Destination Filename Convention/Trigger File** |  | No change to file name. File received from IBA Direct will be copied to blob storage |
| **Destination Filename Example/Trigger File** |  | No change to file name. File received from IBA Direct will be copied to blob storage |

### 5.1.5 Design Considerations

1. **Authentication Redesign (Known Issue Addressed):** The legacy static token mechanism, where tokens were loaded from a file at application startup, cached in memory, and required a service restart for updates, is replaced with **Azure APIM-based bearer token authentication**. Suppliers continue to use the `Authorization: Bearer {token}` header, maintaining the existing API authentication contract while removing the dependency on locally maintained static token files.

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| Interface ID | Process | Component | Component Type | Change Type | Repository |
| --- | --- | --- | --- | --- | --- |
| EAII-304 | API Exposure | [**cloud-api-{env}.metcash.com**](https://cloud-api-dev.metcash.com) | Azure API Management | Existing | AIS Repository |
| EAII-304 | File Upload | **t3-met-enabling-blobmgnt-{env}-ae-func** | Azure Function | Existing | AIS Repository |
| EAII-304 | Event Routing | **evt-t3b2b{env}aesta01-alm-ibadirects-in-create-sbq-{env}-ae** | Azure Event Grid Subscription | New | AIS Repository |
| EAII-304 | Asynchronous Messaging | **t2-met-{npr/prd}-ae-sb001**<br> <br>Queue: **b2b.ibadirectstoeim.sbq-{env}** | Azure Service Bus (Standard) | New | AIS Repository |
| EAII-304 | Translation Orchestration | **t3-met-b2b-ibadirects-{env}-ae-logic** | Logic App (Standard) | New | AIS Repository |
| EAII-304 | PSV Transformation | **PSV Converter (Inline Azure Function)** | Azure Function | New | AIS Repository |
| EAII-304 | File Storage | **t3b2b{env}aesta01** | Azure Storage Account (Blob) | New | AIS Repository |
| EAII-304 | Secret Management | **t3enabling{env}aekv01**<br>**t3b2b{env}aekv01** | Azure Key Vault | Existing | AIS Repository |

#### 5.1.6.2 Services

The IBA Directs integration is implemented through two logical services:

1. **IBADirects Upload Service** — Responsible for receiving inbound supplier requests, authenticating and validating the payload, storing the source ZIP file, and initiating asynchronous translation processing. **Components:** Azure API Management (APIM), UploadBlob Azure Function, Azure Blob Storage, Azure Event Grid, Azure Service Bus.
2. **IBADirects Translation Service** — Responsible for asynchronously processing the uploaded source files, transforming the extracted data into PSV format, delivering the output files to EIM, and archiving the processed source files. **Components:** Translation Logic App, PSV Converter (Inline Azure Function), Azure Blob Storage, Azure Service Bus, Azure Key Vault, Application Insights, and SMC.

#### 5.1.6.3 *IBADirects Upload Service*

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

- Interface ID = `EAII-304`
- All significant events, including successful completions and errors, will be logged in SMC for monitoring and debugging purposes.

| **Sr. No.** | **API Name** | **Description** | **API URL** | **Method** |
| --- | --- | --- | --- | --- |
| 1 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The StartObservation API initiates the monitoring process for a business interface in AIS by creating an observation instance. | t3-met-{env}-ae-apim/smc/startObservation | POST |
| 2 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The ObservationPoint API is utilized to update the stage, status and other details of an ongoing observation for a business interface in AIS. | t3-met-{env}-ae-apim/smc/observationPoint | POST |

##### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interface are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to [https://metcash.atlassian.net/wiki/x/BQC_dg](https://metcash.atlassian.net/wiki/x/BQC_dg) .

It uses **SMC (Service Monitoring Console)** for end-to-end transaction observability across the integration flow and **Azure Application Insights** for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for Azure resources. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique **Transaction ID (UUID)** is generated for each request and propagated throughout the entire processing pipeline. SMC records the lifecycle of each transaction, enabling complete traceability from the inbound API request through Azure Logic Apps and external IBM AS/400 interactions.

##### 5.1.6.3.3 Exceptions

| Observation Stage | Exception Scenario | Exception Category | Exception Code | Exception Message | Exception Handling |
| --- | --- | --- | --- | --- | --- |
| Authentication | Invalid or missing Bearer token | Business | HTTP-401 | Unauthorized | APIM returns **HTTP 401 Unauthorized**. Authentication failure is logged to SMC and Application Insights. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Payload Validation | Decoded ZIP payload exceeds 3 MB | Business | 400 | File size exceeded | APIM invokes the UploadBlob Azure Function to store the ZIP file in **IBADirects/error**. APIM returns **HTTP 400 Bad Request**. Transaction is logged to SMC. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Payload Validation | Required field **SupplierID** missing | Business | HTTP-400 | Bad Request – Missing required field | APIM returns **HTTP 400 Bad Request** with validation details. File is not uploaded. Validation failure is logged to SMC and Application Insights. |
| Payload Validation | Invalid JSON schema or malformed Base64 payload | Business | HTTP-400 | Bad Request – Invalid request payload | APIM returns **HTTP 400 Bad Request**. File is not uploaded. Validation failure is logged to SMC and Application Insights. |
| Blob Upload | Azure Blob Storage unavailable during upload | Technical | 503 | Cloud storage communication error | APIM retries the backend invocation for transient failures. The UploadBlob Azure Function retries Azure Storage operations (refer **EAII-367 UploadBlob**). If retries are exhausted, APIM returns **HTTP 503 Service Unavailable**. Failure is logged to SMC and Application Insights. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Translation Processing | ZIP decompression failed | Technical | 400 | Failed to decompress source ZIP | Translation Logic App logs the failure to SMC. The Service Bus message is abandoned and retried according to the configured retry policy. After the maximum delivery count is reached, the message is dead-lettered. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Translation Processing | PSV transformation failed | Technical | 400 | Failed to transform JSON to PSV | Translation Logic App logs the failure to SMC. The Service Bus message is abandoned and retried. After retry exhaustion, the message is dead-lettered for investigation. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Output Delivery | Failed to upload PSV file to **IBADirects/ToEIM** | Technical | 500 | Output file upload failed | Translation Logic App retries the Blob Storage operation using its configured retry policy. If retries are exhausted, the transaction is logged to SMC, the Service Bus message is abandoned, and the message is retried or dead-lettered according to Service Bus configuration. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Archive | Failed to archive source ZIP | Technical | 500 | Failed to archive source file | Translation Logic App retries the archive operation. If retries are exhausted, the failure is logged to SMC and the Service Bus message is abandoned for retry or dead-lettering. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Any | Unhandled exception in Translation Logic App or Azure Function | Technical | IBADIRECTS-ERR-UNHANDLED | Unexpected error | Error details are logged to SMC, Application Insights, and Log Analytics. The Service Bus message is abandoned and retried. If the maximum delivery count is exceeded, the message is moved to the dead-letter queue. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |

##### 5.1.6.3.4 Service consumers

- Liquor Suppliers (external systems) — Coopers Brewery, CUB, and any other suppliers onboarded to the IBA Directs service

##### 5.1.6.3.5 Service Operations

| Operation | Method | Path | Description |
| --- | --- | --- | --- |
| Upload Directs File | POST | `eis/ibadirects/v1/submitOrder` | Receives a `DirectsFileDocument` JSON payload from a liquor supplier. Returns a `DirectsResponse` confirming receipt or describing the error. |

##### 5.1.6.3.6 Service Provider

| **Service / Component** | **Provider** | **Responsibility** |
| --- | --- | --- |
| Azure API Management | Microsoft Azure / Metcash AIS Platform | Expose and secure the inbound REST API endpoint |
| Upload Orchestrator Logic App | Metcash AIS Platform | Validate, store, and queue inbound directs files |
| Azure Blob Storage | Microsoft Azure / Metcash AIS Platform | Store source files (input and error containers) |
| Azure Service Bus | Microsoft Azure / Metcash AIS Platform | Decouple upload and translation phases |

##### 5.1.6.3.7 Communications Data Structures

For all Interface Filename Conventions and Parameters, please refer to: [Mapping - EAII-304 - IBA Directs ALM Orders - Liquor Suppliers to EIM](https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3503849480)

##### 5.1.6.3.8 Input/Output

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | POST eis/ibadirects/v1/submitOrder | `DirectsFileDocument` (JSON) — `DocumentHeader.Supplier.SupplierID` (required), `DirectsFile.FileContent` (base64 ZIP, required) | `IBADIRECTS-COOPERSBREWERY-20260615000035.json` |
| Output | HTTP Response | `DirectsResponse` (JSON) — `Code` (integer), `Description` (string) | `{"Code": 200, "Description": "Success"}` |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Azure Blob Storage (`IBADirects/ToEIM`) | Put Blob (PSV file) | `{SourceFileNameWithoutExtension}.PSV` | `IBADIRECTS-COOPERSBREWERY-20260615000035.PSV` |
| Azure Blob Storage (`IBADirects/archive`) | Move Blob | `{SourceFileNameWithoutExtension}.zip` | N/A |

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

*Enter the required SMC Integration Onboarding details. The corresponding Business Process and Applications must have already been onboarded to SMC. If not then onboarding details for these must also be provided (refer SMC User Guide in Reference Documents and Architecture below)*

| **Field** | **Value** |
| --- | --- |
| Business Process | ALM / IBA Directs |
| Source Business Process | Liquor Supplier Operations |
| Source Application | Liquor Suppliers (external) |
| Destination Business Process | EIM Data Processing |
| Destination Application | EIM (Enterprise Information Management) |
| Interface ID | EAII-304 |
| Interface Name | IBA Directs ALM Orders - Liquor Suppliers to EIM |
| Interface Type | Sender |
| Interface DataStore | Azure Blob Storage |
| Tags | `{"integration": "EAII-304", "domain": "ALM", "platform": "AIS"}` |
| Reference Keys | Transaction ID, Supplier ID |
| Notification Type | Email |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-304 |
| Correlation Properties | Transaction ID, Supplier ID |
| Reprocessing Required | Yes — failed translation messages can be replayed from Service Bus dead-letter queue |
| BusinessProcess Name | IBADirects |

#### 5.1.7.1 SMC Load Estimations

This section will include corresponding SMC load estimations for this interface, including peak and normal load scenarios.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | ~8 files per month across all suppliers. Peak scenario: 2–3 files in a single day (very unlikely). |
| Average volume | ~2 files per week |  |
| Seasonal considerations | No significant seasonal variation expected |  |
| Expected growth | Low — supplier base is small and established. No growth forecast provided. |  |
| Message Size | Average message size | ZIP payloads: ~20 KB (Coopers) to ~685 KB (CUB). Unzipped: ~318 KB to ~5.3 MB. PSV output: ~144 KB to ~2.4 MB. |
| Message Size | Max message size | 3 MB (ZIP payload limit enforced at APIM) |

### 5.1.8 Monitoring

Standard AIS platform monitoring applies via Azure Application Insights and Log Analytics Workspace.

### 5.1.9 Reporting

*NA*

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

| Work Item Type | Title | Test Step | Step Action | Step Expected |
| --- | --- | --- | --- | --- |
| Test Case | Verify Upload Blob without authentication token |  |  |  |
|  |  | 1 | Invoke Upload Blob API without providing a Bearer token | API returns 401 Unauthorized and the request is rejected. Authentication failure is logged in SMC. |
| Test Case | Verify Upload Blob with invalid or expired authentication token |  |  |  |
|  |  | 1 | Invoke Upload Blob API using an invalid, malformed, or expired Bearer token | API returns 401 Unauthorized and the request is rejected. Authentication failure is logged in SMC. |
| Test Case | Verify Upload Blob with malformed authentication token |  |  |  |
|  |  | 1 | Invoke Upload Blob API using a malformed Bearer token | API returns 401 Unauthorized and the request is rejected. Authentication failure is logged in SMC. |
| Test Case | Verify Upload Blob without RequesterSiteId header |  |  |  |
|  |  | 1 | Invoke Upload Blob API without the RequesterSiteId header | API returns 400 Bad Request with a missing RequesterSiteId validation error. Error is logged in SMC. |
| Test Case | Verify Upload Blob with invalid RequesterSiteId |  |  |  |
|  |  | 1 | Invoke Upload Blob API with an invalid RequesterSiteId value | API returns 400 Bad Request with an invalid RequesterSiteId validation error. Error is logged in SMC. |
| Test Case | Verify Upload Blob with missing request body |  |  |  |
|  |  | 1 | Invoke Upload Blob API without a request body | API returns 400 Bad Request and the request is not processed. |
| Test Case | Verify Upload Blob with invalid JSON request body |  |  |  |
|  |  | 1 | Invoke Upload Blob API with malformed or invalid JSON | API returns 400 Bad Request with an invalid JSON validation error. |
| Test Case | Verify Upload Blob with missing SupplierID |  |  |  |
|  |  | 1 | Invoke Upload Blob API without the SupplierID field | API returns 400 Bad Request with a missing SupplierID validation error. |
| Test Case | Verify Upload Blob with empty SupplierID |  |  |  |
|  |  | 1 | Invoke Upload Blob API with an empty SupplierID value | API returns 400 Bad Request with a SupplierID validation error. |
| Test Case | Verify Upload Blob with missing FileContent |  |  |  |
|  |  | 1 | Invoke Upload Blob API without the FileContent field | API returns 400 Bad Request with a missing FileContent validation error. |
| Test Case | Verify Upload Blob with empty FileContent |  |  |  |
|  |  | 1 | Invoke Upload Blob API with an empty FileContent value | API returns 400 Bad Request with a FileContent validation error. |
| Test Case | Verify Upload Blob with invalid Base64 FileContent |  |  |  |
|  |  | 1 | Invoke Upload Blob API with FileContent containing invalid Base64 data | API returns 400 Bad Request with an invalid Base64 validation error. |
| Test Case | Verify Upload Blob with Base64 content that is not a ZIP file |  |  |  |
|  |  | 1 | Submit valid Base64 content representing a non-ZIP file | API returns 400 Bad Request because the decoded content is not a valid ZIP file. Error is logged in SMC. |
| Test Case | Verify Upload Blob with corrupted ZIP file |  |  |  |
|  |  | 1 | Upload a corrupted ZIP file encoded as valid Base64 | API returns 400 Bad Request and the ZIP decompression or validation failure is logged. |
| Test Case | Verify Upload Blob with valid ZIP file below 3 MB |  |  |  |
|  |  | 1 | Upload a valid ZIP file with a decoded size below 3 MB | API returns 200 OK and the ZIP file is stored in the input location. |
| Test Case | Verify Upload Blob with ZIP file exceeding 3 MB |  |  |  |
|  |  | 1 | Upload a valid ZIP file with a decoded size greater than 3 MB | API returns 400 Bad Request with IBADIRECTS-ERR-001. The file is stored in the error location. |
| Test Case | Verify Upload Blob with ZIP containing no files |  |  |  |
|  |  | 1 | Upload a valid ZIP archive containing no files | API returns 400 Bad Request because the ZIP does not contain a valid input file. |
| Test Case | Verify Upload Blob with ZIP containing invalid JSON |  |  |  |
|  |  | 1 | Upload a ZIP containing an invalid JSON file | API returns 400 Bad Request and the invalid JSON error is logged. |
| Test Case | Verify Upload Blob with ZIP containing empty JSON |  |  |  |
|  |  | 1 | Upload a ZIP containing an empty JSON file | API returns 400 Bad Request and the empty JSON validation error is logged. |
| Test Case | Verify end-to-end successful Upload Blob processing |  |  |  |
|  |  | 1 | Submit a valid request containing a valid Bearer token, SupplierID and ZIP file within the 3 MB limit | API accepts the request and stores the source file in the input location. |
|  |  | 2 | Allow the uploaded file event to trigger downstream processing | Queue message is created and consumed successfully. |
|  |  | 3 | Process the ZIP and transform the DirectsData records | ZIP is extracted and the PSV file is generated with the expected records and format. |
|  |  | 4 | Upload the generated PSV and complete source-file processing | PSV is uploaded successfully; source is archived and removed from the input location. |
|  |  | 5 | Verify transaction logging | SMC message is sent and the workflow completes successfully. |
| Test Case | Verify Upload Blob with multiple DirectsData records |  |  |  |
|  |  | 1 | Upload a ZIP containing multiple DirectsData objects | Generated PSV contains one header and one row for each input record. |
|  |  | 2 | Validate generated PSV row structure | PSV row count matches the number of source records and contains no missing or additional delimiters. |
| Test Case | Verify generated PSV schema format |  |  |  |
|  |  | 1 | Process a valid ZIP containing DirectsData records | Generated PSV header exactly matches the required 20-field schema: SUPPID&#124;PRODCODE&#124;PRODDESC&#124;SUPPPRODCODE&#124;SUPPPRODDESC&#124;PACKSIZE&#124;PRODCATEGORY&#124;GTIN&#124;LICNUMBER&#124;CUSTNUMBER&#124;CUSTNAME&#124;ADDRESS&#124;SUBURB&#124;POSTCODE&#124;STATE&#124;INVNUMBER&#124;INVDATE&#124;INVCASES&#124;INVLITRES&#124;INVVALUE. |
| Test Case | Verify metadata enrichment during processing |  |  |  |
|  |  | 1 | Upload a source blob containing SupplierID and DocumentType metadata | SupplierID and DocumentType from the source blob metadata are correctly propagated to the SMC message headers. |
| Test Case | Verify successful transformation and archive processing |  |  |  |
|  |  | 1 | Process a valid ZIP through TransformToPSV | TransformToPSV returns a successful status and the PSV is generated and uploaded. |
|  |  | 2 | Complete successful processing | Source file is copied to the archive location, removed from input, and the archive stage is marked completed. |
| Test Case | Verify transformation business failure handling |  |  |  |
|  |  | 1 | Force TransformToPSV to return a failed status | Source file is copied to the error location and removed from input. |
|  |  | 2 | Verify failure tracking | Transform failure stage is recorded and SMC error information is populated. |
| Test Case | Verify Finally execution after successful processing |  |  |  |
|  |  | 1 | Execute a successful processing flow where all Try actions complete successfully | Finally block executes after successful Try completion. |
|  |  | 2 | Verify final processing actions | SMC message is sent and observation completion status is recorded. |
| Test Case | Verify Finally execution after processing failure |  |  |  |
|  |  | 1 | Force an action within the Try block to fail | Try block fails and control moves to the configured failure handling logic. |
|  |  | 2 | Verify Finally execution | Finally block executes even when the Try block fails. SMC message is attempted and termination logic is evaluated. |
| Test Case | Verify retry mechanism for transient storage failure |  |  |  |
|  |  | 1 | Simulate a temporary Azure Storage failure during processing | Configured retry policy retries the failed storage action. |
|  |  | 2 | Allow the storage operation to recover within the configured retry limit | Storage operation subsequently succeeds without permanent workflow failure. |
| Test Case | Verify handling of ZIP file size exceeding 3 MB |  |  |  |
|  |  | 1 | Upload a ZIP file exceeding the 3 MB limit | API returns 400 Bad Request, stores the file in the error location, and logs IBADIRECTS-ERR-001. |
| Test Case | Verify handling of corrupted ZIP decompression failure |  |  |  |
|  |  | 1 | Process a corrupted ZIP file | ZIP decompression fails and IBADIRECTS-ERR-003 behaviour is logged. |
|  |  | 2 | Verify failure tracking | Failed processing stage is recorded and SMC contains the relevant technical error details. |
| Test Case | Verify handling of JSON parsing failure during transformation |  |  |  |
|  |  | 1 | Process a ZIP containing malformed JSON | Transformation fails and IBADIRECTS-ERR-002 behaviour is logged. |
|  |  | 2 | Verify transaction failure handling | Transaction is marked as failed and the error details are captured in SMC. |
| Test Case | Verify handling of missing DirectsData array |  |  |  |
|  |  | 1 | Process a JSON payload where the DirectsData array is missing | Transformation fails with an appropriate validation/processing error. |
|  |  | 2 | Verify error logging | Error details are captured and sent to SMC. |
| Test Case | Verify handling of empty DirectsData array |  |  |  |
|  |  | 1 | Process a JSON payload containing an empty DirectsData array | Transformation fails with a no-records error. |
|  |  | 2 | Verify error logging | SMC contains the corresponding transformation error. |
| Test Case | Verify handling of invalid DirectsData record structure |  |  |  |
|  |  | 1 | Process a DirectsData array containing a non-object item | Transformation fails because the record does not match the expected object structure. |
|  |  | 2 | Verify technical error handling | Technical error details are captured in SMC. |
| Test Case | Verify source blob read or metadata timeout handling |  |  |  |
|  |  | 1 | Simulate a timeout or failure while reading source blob content or metadata | Read_blob_content fails or times out and HasErrors is set to true. |
|  |  | 2 | Verify failure logging | Technical error is captured and the failed processing stage is logged in SMC. |
| Test Case | Verify PSV upload failure handling |  |  |  |
|  |  | 1 | Simulate a failure or timeout during Upload_PSV_to_output | PSV upload fails or times out and HasErrors is set to true. |
|  |  | 2 | Verify error handling | Upload stage is marked as failed and an SMC error entry is added. |
| Test Case | Verify SMC message send failure handling |  |  |  |
|  |  | 1 | Simulate a failure, timeout, or skipped execution of Send_message | SMC send failure is captured by the workflow. |
|  |  | 2 | Verify workflow termination | Workflow terminates as failed according to the configured termination logic. |
| Test Case | Verify HasErrors termination gate |  |  |  |
|  |  | 1 | Force a tracked blob action to fail or timeout | HasErrors is set to true and the technical error is captured. |
|  |  | 2 | Verify SMC notification | SMC message is attempted before workflow termination. |
|  |  | 3 | Verify termination logic | Workflow follows the HasErrors failure branch and terminates as failed. |
| Test Case | Verify handling of unexpected runtime exception |  |  |  |
|  |  | 1 | Force an unexpected or unhandled action failure inside the Try block | Catch handling is triggered and available exception details are captured. |
|  |  | 2 | Verify failure-stage tracking | Failed processing stage is recorded and SMC contains the error payload. |
| Test Case | Verify Upload Blob with missing required request fields |  |  |  |
|  |  | 1 | Submit a request with a required API field such as SupplierID missing | API returns 400 Bad Request with the appropriate validation error. |
|  |  | 2 | Verify failure logging | Validation failure is logged in SMC. |
| Test Case | Verify SMC error payload integrity |  |  |  |
|  |  | 1 | Trigger a processing failure and generate an SMC error message | SMCError array contains the failed action name, technical error message, status, and error code where available. |

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![EAII-304-Architecture Diagram.drawio (2)-20260806-072449.png](images/05.png)

## 6.2 Network Connectivity

![EAII-304-Network Diagram.drawio (1)-20260806-072559.png](images/04.png)

## 6.3 Security

**Azure API Management (APIM)** enforces **OAuth 2.0 Bearer Token authentication** for all inbound supplier requests. Each request to the IBADirects upload endpoint must include a valid `Authorization: Bearer {token}` header. APIM validates the bearer token before forwarding the request to the backend service.

The **UploadBlob Azure Function** and **Translation Logic App** use **Managed Identities** to authenticate with Azure Storage, Azure Service Bus, Azure Key Vault, and other supported Azure services. No credentials or secrets are stored in application configuration or source code.

The **UploadBlob Azure Function** and **Translation Logic App** are not directly exposed to the public internet. Backend services are accessed through the controlled integration path via **APIM** or **Azure Service Bus**, while Azure resources use **Private Endpoints** where supported to restrict direct public access.

**Azure Key Vault** is used to securely store sensitive configuration and integration credentials, including SMC credentials and other required secrets. Secrets are retrieved at runtime using Managed Identity.

Public network access to the **Azure Storage Account** is disabled. Access is restricted to approved virtual networks and private endpoints in accordance with Metcash security standards.

Access to Azure resources is controlled through **Azure Role-Based Access Control (RBAC)** following the principle of least privilege. Each Managed Identity is granted only the permissions required to perform its respective functions.

All communication between suppliers, Azure services, and downstream components is secured using **HTTPS/TLS 1.2 or later**. Communication between Azure services uses Azure-managed authentication and encrypted transport.

### **Key Vault Secret**

The solution stores all sensitive configuration and credentials in Azure Key Vault. The Azure Logic App accesses the required secrets using its Managed Identity with the **Key Vault Secrets User** role. No secrets are stored in application configuration or source code.

| Key Vault | Purpose |
| --- | --- |
| **t3b2b{env}ae1kv01** | Application Key Vault containing integration-specific secrets required by the IBADirects solution. |
| **t3enabling{env}aekv01** | Shared platform Key Vault managed by the Enabling Platform team, containing shared platform configuration and platform-managed secrets where applicable. |

**6.3.1 Data Handling and Encryption**

**Data Retention:** Source ZIP files are stored in the appropriate Azure Blob Storage paths (`IBADirects/in`, `IBADirects/archive`, or `IBADirects/error`) based on their processing status and are retained in accordance with the defined operational and data retention requirements. Generated PSV file are stored in `IBADirects/ToEIM` until they are picked up by GoAnywhere MFT/EIM.

## 6.4 Infrastructure Support

*NA*

## 6.5 Infrastructure Requirements

**Logic/Function App Infrastructure**

| Resource | Azure Resource Provider | SKU / Tier | Workflow Type | Hosting |
| --- | --- | --- | --- | --- |
| **Azure Logic App** | `Microsoft.Logic/workflows` | Standard | Stateless | Azure Logic Apps Standard (App Service Plan) |
| **Azure Function App** | `Microsoft.Web/sites` | Standard | HTTP Trigger | Azure Functions (App Service Plan) |
| **App Service Plan** | `Microsoft.Web/serverfarms` | Standard | N/A | Dedicated |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **Azure Logic App** | **t3-met-b2b-ibadirects-{env}-ae-logic** | New |
| **Azure Function App** | **t3-met-enabling-blobmgnt-{env}-ae-logic** | Existing |
| **Azure Key Vault** | **t3b2b{env}ae1kv01**<br> <br>**t3enabling{env}ae1kv01** | Existing |
| **Resource Group** | **t3-met-ais-{env}-ae1-rsg-b2b** | Existing |
| **Subscription** | **COREIT-SERVICES-AIS-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / SENS** | Existing |
| **Azure Application Insights** | **t3-met-b2b-ibadirects-{env}-ae-logic-ai** | New |

**{env} -** dv1, st1, ut1 and prd

**Azure API Management Infrastructure**

Azure API Management (APIM) serves as the secure API gateway for the IBA Directs interface, exposing the upload endpoint to liquor suppliers while enforcing authentication, request validation, policy execution, backend routing, error handling, and observability.

**Azure API Management (APIM) Named Values** are used to externalize runtime configuration values required by the API gateway. APIM reads these values during policy execution to control request processing without requiring policy changes or redeployment.

| Resource | Azure Resource Provider | SKU | Purpose |
| --- | --- | --- | --- |
| Azure API Management | `Microsoft.ApiManagement/service` | Standard | Exposes the IBADirects Upload API, performs OAuth 2.0 authentication, request validation, policy execution, backend routing, retry handling, and telemetry logging. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **APIM** | **t3-met-core-{env}-ae-apim**<br> <br>[cloud-api-{env}.metcash.com](https://cloud-api-dev.metcash.com) | Existing |
| **Resource Group** | **t3-met-core-{env}-ae1-rsg-apim** | Existing |
| **Subscription** | **COREIT-SERVICES-HUB-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / HSENS** | Existing |
| **Azure Application Insights** | **t3-met-core-{env}-ae-apim-ai** | New |

**API Endpoints**

|  | **API** |
| --- | --- |
| Upload API | `eis/ibadirects/v1/submitOrder` |

| **Environment** | **URL** |
| --- | --- |
| Dev | [https://cloud-api-dev.metcash.com/eis/ibadirects/v1/submitOrder](https://cloud-api-dev.metcash.com/eis/azureblobmgmt/v1) |
| SIT | [https://cloud-api-sit.metcash.com/](https://cloud-api-sit.metcash.com/eis/azureblobmgmt/v1)[eis/ibadirects/v1/submitOrder](https://cloud-api-dev.metcash.com/eis/azureblobmgmt/v1) |
| UAT | [https://cloud-api-uat.metcash.com/](https://cloud-api-uat.metcash.com/eis/azureblobmgmt/v1)[eis/ibadirects/v1/submitOrder](https://cloud-api-dev.metcash.com/eis/azureblobmgmt/v1) |
| Prod | [https://cloud-api.metcash.com/](https://cloud-api-uat.metcash.com/eis/azureblobmgmt/v1)[eis/ibadirects/v1/submitOrder](https://cloud-api-dev.metcash.com/eis/azureblobmgmt/v1) |

**APIM Policies**

Azure API Management (APIM) policies are used to implement the following controls and processing logic:

- **OAuth 2.0 Bearer Token Authentication and Authorization** — Validates the bearer token provided by the supplier before processing the request.
- **Request Validation** — Validates mandatory request fields, including `SupplierID`, and performs JSON payload/schema validation.
- **Base64 and File Size Validation** — Validates the Base64-encoded payload and ensures that the decoded ZIP file does not exceed the maximum allowed size of **3 MB**.
- **Blob Destination Determination** — Determines the appropriate Azure Blob Storage path based on the validation outcome:
  - Valid files → `IBADirects/in`
  - Files exceeding the size limit → `IBADirects/error`

- **Backend Routing** — Routes valid upload requests to the **UploadBlob Azure Function** for storage in Azure Blob Storage.
- **Retry Handling** — Applies retry policies for transient failures when invoking the UploadBlob Azure Function.
- **Standardized Error Handling** — Provides consistent error responses for authentication, payload validation, file size, and backend processing failures.

**Virtual Network Architecture**

The **IBADirects** integration is deployed within the enterprise **Hub-and-Spoke** network architecture. **Azure API Management (APIM)** is deployed in the **Hub Virtual Network**, while the **Translation Logic App**, **UploadBlob Azure Function**, **Azure Storage Account**, **Azure Event Grid**, **Azure Service Bus**, **Azure Key Vault**, and supporting integration resources are deployed within the **AIS Spoke Virtual Network**.

Secure communication between Azure resources is achieved through **Virtual Network Integration**, **Private Endpoints**, **Network Security Groups (NSGs)**, **Route Tables**, and enterprise networking controls. Public network access is disabled where supported, and Azure services communicate using **Managed Identity**, **Azure RBAC**, and **HTTPS/TLS 1.2 or later**. Event-driven communication between Azure Blob Storage, Azure Event Grid, and Azure Service Bus occurs over Azure-managed secure channels, ensuring reliable and secure asynchronous processing.

**App Gateway Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure Application Gateway | Microsoft.Network/applicationGateways | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | Microsoft.Network/applicationGateways | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure API Management | Microsoft.ApiManagement/service | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | Microsoft.ApiManagement/service | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Logic App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway, providing Layer 7 load balancing and secure ingress routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**SENS (Logic App Application Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Logic Apps** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | **t3-met-ibadirects-dv1-ae-logic** |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | **t3-met-ibadirects-st1-ae-logic** |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | **t3-met-ibadirects-ut1-ae-logic** |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | **t3-met-ibadirects-prd-ae-logic** |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**App Gateway:-**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Managed Identity**

The Azure Logic App uses a System-Assigned Managed Identity. The identity is
 automatically created and managed by Azure, and its lifecycle is tied
 exclusively to the Logic App resource. When the Logic App is deleted, the
 identity is automatically deleted with it.

A User-Assigned Managed Identity (Microsoft.ManagedIdentity/userAssignedIdentities)
 was considered but was not selected for this integration. The System-Assigned
 model is preferred here because:

- The identity is used solely by this Logic App and no other resource.
- There is no requirement to share the same identity across multiple Azure resources.

No credentials, client secrets, or certificates are stored within the
 application. All Azure service authentication is performed at runtime via the
 System-Assigned Managed Identity token.

**Identity and Access Control (RBAC)**

The Logic App authenticates to Azure services using Microsoft Entra ID and its Managed Identity. The following Azure RBAC roles are assigned based on the principle of least privilege.

**Complete RBAC Assignments (**`Microsoft.Authorization/roleAssignments`**):**

| Source | Target | Identity | RBAC Role |
| --- | --- | --- | --- |
| **t3-met-b2b-ibadirects-{env}-ae-logic** | **t3enabling{env}aekv01** | System-Assigned Managed Identity | Key Vault Secrets User |
| **t3-met-b2b-ibadirects-{env}-ae-logic** | **t3b2b{env}aesta01** | System-Assigned Managed Identity | Storage Blob Data Contributor |
| **t3-met-b2b-ibadirects-{env}-ae-logic** | **t2-met-{npr/prd}-ae-sb001** | System-Assigned Managed Identity | Azure Service Bus Data Receiver |
| **t3-met-b2b-ibadirects-{env}-ae-logic** | **t3-met-b2b-ibadirects-{env}-ae-logic-ai** | System-Assigned Managed Identity | Monitoring Metrics Publisher |
| **t3-met-enabling-blobmgmt-{env}-ae-func** | **t3enabling{env}aekv01** | System-Assigned Managed Identity | Key Vault Secrets User |
| **t3-met-enabling-blobmgmt-{env}-ae-func** | **t3b2b{env}aesta01** | System-Assigned Managed Identity | Storage Blob Data Contributor |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

| Private Endpoint Name | Target Resource | Sub-resource | Private DNS Zone | New / Existing |
| --- | --- | --- | --- | --- |
| **t3-met-b2b-ibadirects-{env}-ae-pe-kv** | **t3enabling{env}aekv01** (Azure Key Vault) | vault | [privatelink.vaultcore.azure.net](http://privatelink.vaultcore.azure.net) | Existing |
| **t3-met-b2b-ibadirects-{env}-ae-pe-storage** | **t3b2b{env}aesta01** (Azure Storage Account) | blob | [privatelink.blob.core.windows.net](http://privatelink.blob.core.windows.net) | Existing |
| **t3-met-b2b-ibadirects-{env}-ae-pe-sb** | **t2-met-{npr/prd}-ae-sb001** (Azure Service Bus Namespace) | namespace | [privatelink.servicebus.windows.net](http://privatelink.servicebus.windows.net) | Existing |

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Logic App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`

# 7 Communication Overview

## 7.1 Communication Components

![Untitled Diagram-Communication-Diagram.drawio-20260810-053516.png](images/06.png)

# 8 Data Architecture

## 8.1 Data Model

*NA*

## 8.2 Stored Procedures

*NA*

## 8.3 Stored Procedure Triggers

*NA*

## 8.4 Database Technical Specification

*NA*

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

The IBA Directs interface uses **Azure Blob Storage** to store source, output, archived, and error files. The files are organized into structured folders based on the processing stage:

| Blob Path | Purpose |
| --- | --- |
| `IBADirects/in/` | **Input** – ZIP files received from liquor suppliers and stored for downstream processing. |
| `IBADirects/ToEIM/` | **Output** – PSV file generated after successful translation and placed here for EIM pickup. |
| `IBADirects/archive/` | **Archive** – Source ZIP files moved here after successful translation and processing. |
| `IBADirects/error/` | **Error** – Files that fail validation or processing are stored here for investigation and error handling. |

To comply with **Metcash data retention policies and audit requirements**, the following retention rules are applied:

- Files stored under the `IBADirects/archive/` folder are retained for a maximum of **90 days** and are automatically deleted after the retention period.
- Files stored under the `IBADirects/error/` folder are retained for **30 days** and are automatically deleted thereafter.
- Files under the `IBADirects/in/` folder are retained only for the duration required for successful downstream processing and are subsequently moved to the `IBADirects/archive/` folder.
- PSV and trigger files under `IBADirects/ToEIM/` are retained based on the EIM pickup and downstream processing requirements.

The retention and deletion policies are enforced using **automated Azure Storage Account Lifecycle Management rules**. The lifecycle rule for `IBADirects/archive/` is configured to automatically delete files that are older than **90 days based on their last modified date**.

### 8.5.2 Data Backup

No separate backup mechanism is implemented specifically for the IBA Directs interface. Azure Blob Storage provides the underlying storage resilience required for the interface. Files required for audit or operational purposes are retained according to the defined data retention policies.

### 8.5.3 Data Destruction Procedures

#### **8.5.3.1 Data Destruction Metrics and Timeframes**

Files stored under the `IBADirects/archive/` folder are retained for a maximum of **90 days** and are automatically deleted thereafter, based on the blob's **last modified date**.

#### **8.5.3.2 Standard Process for Data/System Destruction**

Data destruction for archived files is implemented using **Azure Storage Account Lifecycle Management**. A lifecycle management rule is configured to automatically delete files from the `IBADirects/archive/` folder once they reach the defined 90-day retention period.

The lifecycle management rule is configured as follows:

- Add a lifecycle management rule for data destruction.
- Select **Base blobs** as the target blob type.
- Configure the condition based on **Last Modified**.
- Set the retention period to **90 days**.
- Configure the action to **Delete the blob**.
- Configure the rule filter to target the archive path.
- Specify the prefix as `IBADirects/archive/`.

This automated lifecycle management rule ensures that archived source ZIP files are automatically removed after **90 days** in accordance with the defined data retention requirement.

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

*NA*

## 9.2 Deployment Preference

*NA*

## 9.3 Deployment Environment Migration

*All source code is managed under source control (currently Github or Azure Devops Repo).*

*Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure.*

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PROD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.

# 10 Disaster Recovery

*NA*

# 11 Support Documentation

![diagram](images/03.png)

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | Azure function can accept the request data up to 100 MB. | The HTTP request length is limited to 100 MB (104,857,600 bytes), and the URL length is limited to 4 KB (4,096 bytes) | [https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits](https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits) |

# 13 Assumptions

- any assumption while designing solution

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

# 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/08.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |
