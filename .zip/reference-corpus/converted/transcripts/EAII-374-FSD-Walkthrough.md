<!-- Source: _EAII-374 - STIBO to PE - FSD Walkthrough.docx (Teams meeting recording transcript, converted) -->

# EAII-374 - STIBO to PE - FSD Walkthrough-20260804_103049-Meeting Recording

**Date:** 4 August 2026, 05:00am  
**Duration:** 26m 47s

---

*Kamya Saraswat started transcription*

**Turn 1 — Kamya Saraswat** *(0:04)*

Yeah, we can get started, like.

**Turn 2 — Vladimir Gurieff** *(0:08)*

OK, why am I set to do not disturb? Um, so... We have. This is interface 374, Steve-O to PE. As you all know, Steve-O is our PIM and PE is the legacy ERP. So Steve-O is the master data management platform. For products, and when Stevo needs to query or update product-related reference data in PE, such as validating item pack changes, checking item supplier associations, updating vendor statuses, or listing vendor attachment details, it calls a synchronous REST API, the integration service. receives these requests, executes the appropriate stored procedure on the PE database, and sends the results to Stevo. The integration supports 4 API operations that enables to perform these. These are stock on hand, stock on stock on order, and total Tools group, sorry, several tools group pillars. So, what, sorry, where are we got? So, here are, sorry, there are the there are the four in-scope operations. Update vendor status. list TCG for vendor, validate pack change and item supplier change. The service does have a fifth operation unit called get new customer number, which exists in the TIPCO service, but it's already been implemented as part of a separate credit application interface. So it's out of scope for this migration. In the legacy implementation, the integration consists of two TIPCO services. There's A CE service which is used as a proxy, and then a BW6 service that calls the actual PE. PE stored procedures. So the BWC proxy layer is just there for bridging connectivity and obviously this arrangement is not required for the AIS implementation. So here's our legacy architecture. So Steve-O calls the APM, which calls a proxy, which calls the backend, which does, which calls one of the four APIs. And... And stored for the stored procedure in in P.E. in the P.E. database. You just date. As usual, nice and simple, Steve-o, as your P.E. Horizon Impact is red, because P.E. both P.E. and the Steve-O pin are red. Read applications and any interfaces involving them are also read. Known issues, we've got the two-tier architecture we've discussed that's unnecessary. We have a fixed token authentication, which is... Dundant, so the RS implementation should use standard OAuth 2 or managed identity authentication provided by the APM. And the validate pack change has an unused D365 path. The legacy proxy for the validate pack change contains a sub-process for calling D365 in addition to B. If the 365 path is not in scope for this interface. Shouldn't be reimplemented. We have a glossary. So, what's in scope are the four? Of the of the four RS API operations for the four for the four different stored procedures. consolidation of the two-tier architecture into a single AIS service, replacement of the legacy fixed token authentication, maintaining the existing API contracts, and ordered logging environment caches, centralized logging service. What's out of scope is the new customer number of operation as already discussed, the out of scope D365 path as already discussed, and other TIPCO infrastructure. processes related to D365 path that are contained in the BWC code, which are not relevant for this either. No changes to the STEBO, no changes to PE and... No changes to Azure API management policies or routing. Limitations and constraints. The P stored procedures are hosted on AS 400 DB2 database requires JDBC connectivity. So the AS has to be able to establish that connection. Existing API contracts must be preserved. And PA stored procedures, our legacy A is 400 programs with fixed length character parameter types. So the input values may need padding or casting to match these parameter types. Here's the process flow diagram. So Steve-O sends a Jason post request, received, authenticated, logged the event. Map the request to the stored procedure parameters, execute the stored procedures, log any errors, map the stored procedure to the output JSON, and respond back to Steve-O. And here it all is all described, what we just went through. Here we have the operations and the requested fields and the restored field, the response fields and the stored procedure parameter mapping. It's all very simple, so there is no, there, oh sorry, no, there is a mapping document, my apologies. Here's the other operation. Same deal, all the information there. Validate pack change, request response, stored procedure parameters, and item supplier change. Again, request fields, response fields, and the stored procedure parameters. Nine issues, as previously discussed, the two-tier architecture not required, and the redundant fixed act and authentication should be replaced with an OAuth 2. Um... Authentication. We have the mapping sheet. Link to the TSD, link to the ADO. We've got sample, sample source, source files. We don't have any samples for the eight item supply change because that has not been executed in the last month, so it's very low volume. And we don't have any sample target response files available. Because they not logged. We have the API endpoints. We have the stored procedures. One of them is actually, I say stored procedures, but one of them is actually a table function, not a stored procedure. So we've got three stored procedures and a table function. Service level is silver. Data classification is internal, so no special handling requirements. They're all very low volume, so update vendor status is 10 to 20 a day. This TTG is reasonable, 1500 a day. Validate back changes, 10 to 20 a day. Item supply chain is less than one a month; we couldn't find any examples. Magesh message size is small, small number of fields, average message size is less than a K. Latency, it's a synchronous interface, so... We wanted to execute in a reasonable synchronous time. 95% availability as per Silver Service. You got tracking ID as per as the per the corporate requirements, there's the fields to be logged. And nothing else there. Failure scenarios, we got some listed, and as per usual, we do want a catch-all for all unhandled errors, all reported to integration support. No special monitoring, no special reporting, relevant context consideration. We've covered most of these. Get new customer number is excluded, validated pack change, the D365 path is excluded. The proxy is not required. It'll be All, you know, separate services not required. Fixed token authentication is redundant, should be re-implemented. P connectivity requires JDBC access. All operations are synchronous. The TTG vendor is a table function, not a stored procedure, and the P stored procedures use that fixed length which needs to be padded or cast. We have some test scenarios, testing some common errors for each of the, some errors for each of the operations. JDBC connection failures, SQL exceptions. So, time out, invalid authentication. Any operation, any operation verify audit logging. and verify multi-row iterations for the list DTG. We've got all the schemers attached. The original drawer IO is attached. And the traceability appendix for all the bits of TIPCO code, more schemas. Tip code customer number creation. This is the other, sir. This is the other service. the artifact mapping, all the zip code bits and pieces. And that's all. So, do we have any questions now that Magesh is here, and you can ask technical questions and that will not be answered?

**Turn 3 — Jagadeesh Sathyanarayanan** *(14:34)*

Uh, Magesh and Vlad, right? AS 400 is the same with Raj and Anand as work, right? It's the same database.

**Turn 4 — Magesh Parthasarathy** *(14:43)*

Yes.

**Turn 5 — Jagadeesh Sathyanarayanan** *(14:44)*

Same database and same servers and the kind of the similar right servers and everything the same the same ports and everything is same.

**Turn 6 — Magesh Parthasarathy** *(14:48)*

Yeah, yes, yeah. Yes, this short procedure will be different.

**Turn 7 — Jagadeesh Sathyanarayanan** *(14:57)*

Store procedure will be different, and I could see one table query.

**Turn 8 — Magesh Parthasarathy** *(15:03)*

Yeah, the connection details will all be the same, but if it's a direct table query, it will be a direct table query. If not, it is a stored. Mostly it will be a stored procedure.

**Turn 9 — Vladimir Gurieff** *(15:13)*

Yeah.

**Turn 10 — Jagadeesh Sathyanarayanan** *(15:14)*

Okay. And the. And the latency, like I said, trying to see, do should we need to use logic app or function? I could, I see that, you know, the number of calls are also less, and the size of the message is also less.

**Turn 11 — Magesh Parthasarathy** *(15:29)*

Logic App should be okay.

**Turn 12 — Jagadeesh Sathyanarayanan** *(15:33)*

Okay. And the mapping is also not.

**Turn 13 — Magesh Parthasarathy** *(15:35)*

Because anyway, P connectivity, sorry, P connectivity, we have tried it from Logic App, not from Function App. So this one, Logic App should be fine.

**Turn 14 — Jagadeesh Sathyanarayanan** *(15:50)*

Okay, okay, okay, right. Now, since Tibo, the Stibo is still kind of another product, right? I was just thinking, Stibo, if you can, if they can make a rest call, if they have the capability. Right. And then... We have the other stable integration, right, where we have a queue in between, like they are pushing the message to. I believe they are pushing the message to like the 283 and 284. They are pushing the message to, no, the go anywhere is pushing the message to blog, right, in between. Mohammed Yasin (Khoj)   16:29 Yes.

**Turn 15 — Magesh Parthasarathy** *(16:30)*

Yes, it is not the message, it is a file.

**Turn 16 — Jagadeesh Sathyanarayanan** *(16:31)*

But why we need to have a go anywhere in between if

**Turn 17 — Magesh Parthasarathy** *(16:34)*

File, file, as file-based interface.

**Turn 18 — Jagadeesh Sathyanarayanan** *(16:39)*

Okay. Since those are the file size is really less, right? Like I was just thinking why we have a go anywhere and then the blog, they can request the API management and then we can take it to a queue and then process it, right? How would you? I was just thinking you might have copied it from the old solution or something, and because I was just thinking that Steve will, if by looking at this interface, if they can do this OAuth and EPA management on REST calls, but why can't we just remove go anywhere in between? The size is really less.

**Turn 19 — Magesh Parthasarathy** *(17:12)*

Okay, it's not about the file size, it's about the batch processing. Within stable, there are multiple batches that gets executed and finally this batch will keep pushing the data into the SFTP location. Assume if you go for the API, it will. Will become kind of a partially synchronous one. What happens if the file fails in or the request fails an API call?

**Turn 20 — Jagadeesh Sathyanarayanan** *(17:40)*

No, at the same time. See, if it fails in SFTP, what they do? The same thing. We will respond back.

**Turn 21 — Magesh Parthasarathy** *(17:40)*

So. No, the batch process handles it, but API. I don't know, maybe.

**Turn 22 — Jagadeesh Sathyanarayanan** *(17:55)*

No, that is fine. I just want, you know.

**Turn 23 — Magesh Parthasarathy** *(17:59)*

Understand, but if we add a scope to it, right, then it's kind of we are requesting, I have not asked this to Stebo, but if we ask them, they will say it is a change request for them in order to support it. Funding stuff and all will come into picture, so lift and shift is easier for us.

**Turn 24 — Jagadeesh Sathyanarayanan** *(18:21)*

Yeah, makes sense.

**Turn 25 — Magesh Parthasarathy** *(18:22)*

It is not legacy, so the way they're connecting, it's not a legacy way of legacy approach, so I'm okay with it.

**Turn 26 — Jagadeesh Sathyanarayanan** *(18:32)*

Okay, fine. And the mapping complexity, or how do you rate mapping complexity? Is it simple, medium, complex, or...

**Turn 27 — Magesh Parthasarathy** *(18:38)*

This one is simple.

**Turn 28 — Vladimir Gurieff** *(18:40)*

Very simple, very, very small number of fields, and then...

**Turn 29 — Magesh Parthasarathy** *(18:43)*

Yeah.

**Turn 30 — Jagadeesh Sathyanarayanan** *(18:45)*

And.

**Turn 31 — Vladimir Gurieff** *(18:48)*

Yeah.

**Turn 32 — Jagadeesh Sathyanarayanan** *(18:48)*

OKOK under that.

**Turn 33 — Vladimir Gurieff** *(18:49)*

So...

**Turn 34 — Jagadeesh Sathyanarayanan** *(18:52)*

Is there any sequence of calls we need to do? There are four calls which we are doing to disturb. Is there any sequence?

**Turn 35 — Magesh Parthasarathy** *(18:56)*

No, no, all separate individual API calls, no sequence.

**Turn 36 — Jagadeesh Sathyanarayanan** *(19:01)*

If one fails, what do we need to do?

**Turn 37 — Vladimir Gurieff** *(19:05)*

No.

**Turn 38 — Jagadeesh Sathyanarayanan** *(19:05)*

Okay, request and response case, right? Even if it one fails, we'll send a failure back or click if update fails and list is successful then.

**Turn 39 — Vladimir Gurieff** *(19:14)*

No, they're separate calls.

**Turn 40 — Magesh Parthasarathy** *(19:16)*

Separate calls, separate API calls, update vendor status will be a separate API. Likewise, the other ones.

**Turn 41 — Jagadeesh Sathyanarayanan** *(19:21)*

All okay, okay, all four are separate API calls, 4 operations.

**Turn 42 — Magesh Parthasarathy** *(19:25)*

Yes, for the operations, yes.

**Turn 43 — Jagadeesh Sathyanarayanan** *(19:28)*

So, if it fails, it will send the response as failure.

**Turn 44 — Magesh Parthasarathy** *(19:31)*

Yes, it is synchronous, synchronous call. So whatever response we will send it back to.

**Turn 45 — Jagadeesh Sathyanarayanan** *(19:32)*

Oh. And then you want to create a service principle in the Steve or service principle in the API or in a tenant, Metcash tenant, and then you will share as the service principle or something which is already.

**Turn 46 — Magesh Parthasarathy** *(19:50)*

Yes, yes. No, no, we will create one. The first interface will be the ATO interface, which Jaya is working on. Once that is complete, I've already created an AWD for them. So that will be their first OAuth implementation. For that, I will create...

**Turn 47 — Jagadeesh Sathyanarayanan** *(19:55)*

Mm. UW2.

**Turn 48 — Magesh Parthasarathy** *(20:10)*

Hmm.

**Turn 49 — Jagadeesh Sathyanarayanan** *(20:11)*

A.W. to for whom?

**Turn 50 — Magesh Parthasarathy** *(20:13)*

Uh, to the SV team.

**Turn 51 — Jagadeesh Sathyanarayanan** *(20:16)*

Okay.

**Turn 52 — Magesh Parthasarathy** *(20:17)*

So now we are asking them to do a change, right? At the moment, they're consuming TIPCO interface, TIPCO service, without any security thing, directly invoke the API, it goes through. I mean, it comes through the Gen. 1 only, but there is no OAuth. So now we will ask them to implement work.

**Turn 53 — Jagadeesh Sathyanarayanan** *(20:40)*

Like sort and MDM. See, Stivo is not our internal system, right? Is it our internal system in Metcash or?

**Turn 54 — Magesh Parthasarathy** *(20:41)*

Muthu. No, no, no, stable assess.

**Turn 55 — Jagadeesh Sathyanarayanan** *(20:48)*

Stibo is SAS and a kind of they are selling a product like they're selling a product data right? It's a kind of not within like not like sorted and MDM OK.

**Turn 56 — Magesh Parthasarathy** *(20:50)*

Mm. Yes. Yes. Sorted is also a SaaS platform. The application is hosted on the SaaS platform.

**Turn 57 — Jagadeesh Sathyanarayanan** *(21:07)*

Our application is hosted on a SAT. OK, the SAS platform.

**Turn 58 — Magesh Parthasarathy** *(21:11)*

Yeah, that's not it.

**Turn 59 — Jagadeesh Sathyanarayanan** *(21:14)*

OK, now this is stable.

**Turn 60 — Magesh Parthasarathy** *(21:15)*

Say, take take it as Azure right now, we have integration is everything in Gen. Three. Similarly, they they provide a hybrid platform which is a SAS platform where everything is hosted, all this order related applications are hosted.

**Turn 61 — Jagadeesh Sathyanarayanan** *(21:32)*

OK, so sorted is providing a batch platform, and then we have deployed certain applications in the sorted data, and then we are using that task to provide a certain view out of it.

**Turn 62 — Magesh Parthasarathy** *(21:41)*

Yeah, yeah.

**Turn 63 — Jagadeesh Sathyanarayanan** *(21:44)*

Okay. Understood. OK, so this AS 400, I remember in the past we cannot now we are there are a lot of AS 400 integration coming in. Is there anything which we need to think in terms of number of calls which we are making to age 400 like?

**Turn 64 — Magesh Parthasarathy** *(22:01)*

No, no, no, no.

**Turn 65 — Jagadeesh Sathyanarayanan** *(22:04)*

No. Okay. And who wants this?

**Turn 66 — Magesh Parthasarathy** *(22:05)*

It is going to be the same. There will not be any change. Whatever is happening via Tipco, the same number of calls is going to go via Azure. That's the only difference.

**Turn 67 — Jagadeesh Sathyanarayanan** *(22:16)*

Who owns this PE? Is it an internal or external?

**Turn 68 — Magesh Parthasarathy** *(22:19)*

B as in Donald Metcash.

**Turn 69 — Jagadeesh Sathyanarayanan** *(22:22)*

Ace 400 is kind of a...

**Turn 70 — Magesh Parthasarathy** *(22:23)*

IBM, IBM AS 400 I series. Have you heard of the legacy ERP system?

**Turn 71 — Jagadeesh Sathyanarayanan** *(22:25)*

Yep. No, actually, I heard of AS 400, which is I know this IBM kind of an Oracle, right? It's a... Oh, I see.

**Turn 72 — Magesh Parthasarathy** *(22:41)*

This is I see this, I see this very old one, yeah.

**Turn 73 — Vladimir Gurieff** *(22:47)*

Yeah, this is this is DB2, not Oracle.

**Turn 74 — Magesh Parthasarathy** *(22:47)*

Yeah. Yeah.

**Turn 75 — Jagadeesh Sathyanarayanan** *(22:53)*

Oh, I'm...

**Turn 76 — Magesh Parthasarathy** *(22:53)*

But that is a very stable platform. So you name everything, everything is good there.

**Turn 77 — Jagadeesh Sathyanarayanan** *(23:01)*

Yeah, it has a black screen which I know. That's what I know. That's a black screen and...

**Turn 78 — Magesh Parthasarathy** *(23:03)*

The. Yeah, black screen with the fluorescent green font.

**Turn 79 — Vladimir Gurieff** *(23:09)*

Yes.

**Turn 80 — Jagadeesh Sathyanarayanan** *(23:09)*

Yeah, OK. I am done with my questions. I think Yasin was ready to send, so I will shift to Yasin. Thank you.

**Turn 81 — Magesh Parthasarathy** *(23:10)*

Okay. Mohammed Yasin (Khoj)   23:16 Yeah, yeah, my first question will be: Steve-O calling via API.M. Does it need what it going to do with the the in the response success or failure? Can't it be just to not to accept it?

**Turn 82 — Magesh Parthasarathy** *(23:33)*

No, no, no, no, this is not fight and forget. This is... Mohammed Yasin (Khoj)   23:36 Mhm.

**Turn 83 — Magesh Parthasarathy** *(23:39)*

Stable is requesting for some data. We go talk to P, get the data, and give it back to stable. Mohammed Yasin (Khoj)   23:45 Oh, okay, okay, I understand that.

**Turn 84 — Vladimir Gurieff** *(23:47)*

Yep, synchronous call. Mohammed Yasin (Khoj)   23:51 Yeah, okay, then in that case, no reprocessing, nothing is required here. Yeah, yeah. Regarding the, okay, the synchronous, I think a couple more questions that I have already answered with this. Yeah, that's it from my side.

**Turn 85 — Magesh Parthasarathy** *(23:57)*

No, no, this is synchronous.

**Turn 86 — Jagadeesh Sathyanarayanan** *(24:13)*

How do you do we need to group this integration with anything else for the production to go on?

**Turn 87 — Magesh Parthasarathy** *(24:20)*

No, we will keep it as a separate collection. One logic app and an APN collection.

**Turn 88 — Vladimir Gurieff** *(24:35)*

So, it'll be... They'll be disconnected from that fifth operation.

**Turn 89 — Magesh Parthasarathy** *(24:42)*

Show Khoi Khoj Baba song.

**Turn 90 — Vladimir Gurieff** *(24:46)*

Magesh.

**Turn 91 — Magesh Parthasarathy** *(24:48)*

The 5th operation is already there. We just have to ask them to point to the other operation.

**Turn 92 — Vladimir Gurieff** *(24:52)*

Yeah.

**Turn 93 — Jagadeesh Sathyanarayanan** *(24:58)*

No, I mean, like B2B for external product info, we took multiple integration together, right? Like, Anand, we are now taking 283, 284, the sorted NDPM and PE and this Kumar interface together for our production deployment. Like that, do we need to include this as part of any...

**Turn 94 — Magesh Parthasarathy** *(24:58)*

What do you mean? Yeah. Yes.

**Turn 95 — Jagadeesh Sathyanarayanan** *(25:17)*

Other.

**Turn 96 — Magesh Parthasarathy** *(25:17)*

No, no, this is separate.

**Turn 97 — Jagadeesh Sathyanarayanan** *(25:21)*

This is separate. We don't need to.

**Turn 98 — Magesh Parthasarathy** *(25:21)*

I understand, I understand we have 4 operations and that's something I was discussing with Vlad. Should we create 4 interface IDs or leave it with one interface ID? We decided to go with one interface ID.

**Turn 99 — Jagadeesh Sathyanarayanan** *(25:38)*

Mm.

**Turn 100 — Magesh Parthasarathy** *(25:38)*

No.

**Turn 101 — Jagadeesh Sathyanarayanan** *(25:40)*

Yeah. Okay. That's what I wanted. Okay. That's it. Thank you. So we, once the firewall is done, then I think somebody can, anybody can pick this up. I don't see any odds talking. Thank you.

**Turn 102 — Vladimir Gurieff** *(26:05)*

All done. Oh, Kamya has left. Right. We're finished.

**Turn 103 — Jagadeesh Sathyanarayanan** *(26:16)*

Yeah, if no questions, then we are good to go.

**Turn 104 — Vladimir Gurieff** *(26:20)*

Alright, thank you everybody.

**Turn 105 — Magesh Parthasarathy** *(26:22)*

Thank you.

**Turn 106 — Jagadeesh Sathyanarayanan** *(26:24)*

Thank you. Mohammed Yasin (Khoj)   26:24 Thank you all.

*Kamya Saraswat stopped transcription*
