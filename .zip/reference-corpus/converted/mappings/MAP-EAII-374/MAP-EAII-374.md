<!-- Source: Mapping+-+EAII-374+-+PE+Item+&+Vendor+Validation+-+Stibo+to+PE.doc -->
<!-- Title: Mapping - EAII-374 - PE Item & Vendor Validation - Stibo to PE -->

# Mapping - EAII-374 - PE Item & Vendor Validation - Stibo to PE

This mapping document covers all four API operations within the EAII-374 interface: Update Vendor Status, List TTG For Vendor, Validate Pack Change, and Item Supplier Change. Each operation is a synchronous REST API call from Stibo (STEP MDM) to PE (Power Enterprise - AS/400 DB2) via a JDBC stored procedure or table function.

**Sample Payloads:**

| Operation | Side | Sample File | Format | Notes |
| --- | --- | --- | --- | --- |
| Update Vendor Status | Source | sample_payloads/EAII-374/EAII-374 - Update Vendor Status/source_samples/Payload1.txt | XML | Pillar field empty |
| List TTG For Vendor | Source | sample_payloads/EAII-374/EAII-374 - List TTG For Vendor/source_samples/Payload1.txt | XML |  |
| Validate Pack Change | Source | sample_payloads/EAII-374/EAII-374 - Validate Pack Change/source_samples/Payload1.txt | XML |  |
| Item Supplier Change | Source | Auto-generated | N/A | Not executed in last month; no sample available |

Target sample values are derived by applying the documented transformation to source values. Item Supplier Change uses auto-generated values throughout.

> **Note:** Sample payloads are in XML format as captured from CLE audit logs (TIBCO internally represents all data as XML via `tib:render-xml()`). The actual inbound wire format from Stibo is JSON per the API contract.
>

---

## 1. UPDATE VENDOR STATUS

### Transformation: Vendor Status Request to MDM0055R Stored Procedure

**Context:**

| Field | Value |
| --- | --- |
| Used In | Update Vendor Status API |
| Activity Name | Map vendor status request fields to MDM0055R stored procedure parameters and map return code back to response |
| Transformation Type | Request field mapping + JDBC stored procedure call |

**Source Schema:**

- Format: JSON
- XSD: UpdateVendorStatus.xsd
- Root Element: VendorStatusRequest

**Target Schema:**

- Format: JDBC Stored Procedure Call
- Stored Procedure: MDM0055R
- Schema: Environment-specific (module property PESCHEMA)

**Description:**
 This transformation maps the inbound Vendor Status Request fields to the input parameters of the PE stored procedure MDM0055R. The stored procedure updates the vendor's status in PE and returns a code indicating success or failure. The response maps the return code back along with the original request fields for correlation.

**Tibco Reference:** UpdateVendorStatus.bwp

### Field Mapping Table - Request (Stibo to MDM0055R)

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vendor Number | VendorNumber | xs:string | 1501045 | Direct mapping | `<xsl:value-of select="$post.item/tns:VendorNumber"/>` | XVNDN | CHAR | 1501045 |
| Pillar | Pillar | xs:string |  | If field exists, map value; otherwise set xsi:nil=true | `<xsl:choose><xsl:when test="exists($post.item/tns:Pillar)"><xsl:value-of select="$post.item/tns:Pillar"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | XDIVN | CHAR | *nil* |
| Vendor Status | VendorStatus | xs:string | D | Direct mapping | `<xsl:value-of select="$post.item/tns:VendorStatus"/>` | XARCD | CHAR | D |

Source sample values extracted from Payload1.txt. *Italic values are derived by applying the transformation.*

### Field Mapping Table - Response (MDM0055R to Stibo)

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Target Field Path | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tracking ID | (internal variable) | xs:string | BPM1501045 | Passthrough from internal tracking ID (generated or received from request) | `<xsl:value-of select="$intTrackingId"/>` | TrackingID | TrackingID | xs:string | BPM1501045 |
| Vendor Number | VendorNumber | xs:string | 1501045 | Passthrough from original request | `<xsl:value-of select="$post.item/tns:VendorNumber"/>` | VendorNumber | VendorNumber | xs:string | 1501045 |
| Vendor Status | VendorStatus | xs:string | D | Passthrough from original request | `<xsl:value-of select="$post.item/tns:VendorStatus"/>` | VendorStatus | VendorStatus | xs:string | D |
| Return Code | XRETN | CHAR | *0* | Direct mapping from stored procedure output parameter | `<xsl:value-of select="$query-vendorStatusUpdate/outputSet/XRETN"/>` | ReturnCode | ReturnCode | xs:string | *0* |

Source sample values extracted from Payload1.txt. *Italic values are derived by applying the transformation.*

---

## 2. LIST TTG FOR VENDOR

### Transformation: List TTG Vendor Request to MDM0110Q Table Function

**Context:**

| Field | Value |
| --- | --- |
| Used In | List TTG For Vendor API |
| Activity Name | Map vendor lookup request to MDM0110Q table function query, iterate result set, and accumulate TTG list response |
| Transformation Type | Request field mapping + JDBC table function query + result set iteration |

**Source Schema:**

- Format: JSON
- XSD: ListTTGVendor.xsd
- Root Element: ListTTGVendorRequest

**Target Schema:**

- Format: JDBC Table Function Query
- Table Function: MDM0110Q
- SQL: `SELECT VTDTTNP, VTAVTGD FROM TABLE({Schema}.MDM0110Q(cast(? as CHAR(10)), cast(? as CHAR(1)))) AS TTGList`
- Schema: Environment-specific (module property)

**Description:**
 This transformation maps the inbound List TTG Vendor Request fields to the parameters of the PE table function MDM0110Q. The table function returns a result set of TTG attachment values and descriptions for the specified vendor. The integration iterates over each result row, maps the DB2 column names (VTDTTNP, VTAVTGD) to business names (ATTACH_VALUE, ATTACH_DESCRIPTION), accumulates the results into a TTGList array, and returns the complete list in the response along with the original request fields.

**Tibco Reference:** ListTTGForVendor.bwp

### Field Mapping Table - Request (Stibo to MDM0110Q)

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vendor Number | VENDORNUMBER | xs:string | 1011468 | If field exists, map value; otherwise set xsi:nil=true. Cast to CHAR(10) in SQL. | `<xsl:choose><xsl:when test="exists($post.item/tns:VENDORNUMBER)"><xsl:value-of select="$post.item/tns:VENDORNUMBER"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | VENDORNUMBER | VARCHAR | 1011468 |
| Attach Type | ATTACHTYPE | xs:string | T | If field exists, map value; otherwise set xsi:nil=true. Cast to CHAR(1) in SQL. | `<xsl:choose><xsl:when test="exists($post.item/tns:ATTACHTYPE)"><xsl:value-of select="$post.item/tns:ATTACHTYPE"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | ATTACHTYPE | VARCHAR | T |

Source sample values extracted from Payload1.txt.

### Field Mapping Table - Response (MDM0110Q to Stibo)

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Target Field Path | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vendor Number | VENDORNUMBER | xs:string | 1011468 | Passthrough from original request (if exists) | `<xsl:value-of select="$post.item/tns:VENDORNUMBER"/>` | VENDORNUMBER | VENDORNUMBER | xs:string | 1011468 |
| Attach Type | ATTACHTYPE | xs:string | T | Passthrough from original request (if exists) | `<xsl:value-of select="$post.item/tns:ATTACHTYPE"/>` | ATTACHTYPE | ATTACHTYPE | xs:string | T |

Source sample values extracted from Payload1.txt. Result set iteration values below are auto-generated (no target sample available).

### Field Mapping Table - Result Set Iteration (MDM0110Q Row to TTGList)

For each row returned by the MDM0110Q table function, the following mapping is applied within a ForEach loop, with results accumulated into the TTGList array:

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Target Field Path | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TTG Attachment Value | Record/VTDTTNP | CHAR | *PLUMBING* | Direct mapping (if exists) | `<xsl:value-of select="$currentElement/VTDTTNP"/>` | ATTACH_VALUE | TTGList/ATTACH_VALUE | xs:string | *PLUMBING* |
| TTG Attachment Description | Record/VTAVTGD | CHAR | *Plumbing Supplies* | Direct mapping (if exists) | `<xsl:value-of select="$currentElement/VTAVTGD"/>` | ATTACH_DESCRIPTION | TTGList/ATTACH_DESCRIPTION | xs:string | *Plumbing Supplies* |

*Italic values are generated - not from a supplied sample.*

**Loops/Iterations:**

```
FOR EACH Record in MDM0110Q result set
  IF VTDTTNP exists THEN
    map VTDTTNP -> ATTACH_VALUE
  END IF
  IF VTAVTGD exists THEN
    map VTAVTGD -> ATTACH_DESCRIPTION
  END IF
  Accumulate TTGList element
END FOR
```

---

## 3. VALIDATE PACK CHANGE

### Transformation: Pack Change Request to MDM0140R Stored Procedure

**Context:**

| Field | Value |
| --- | --- |
| Used In | Validate Pack Change API (PE path only) |
| Activity Name | Map pack change validation request fields to MDM0140R stored procedure parameters and map validation result back to response |
| Transformation Type | Request field mapping + JDBC stored procedure call |

**Source Schema:**

- Format: JSON
- XSD: PackChangeValidation.xsd
- Root Element: PackChangeRequest

**Target Schema:**

- Format: JDBC Stored Procedure Call
- Stored Procedure: MDM0140R
- Schema: Environment-specific (module property SCHEMA)

**Description:**
 This transformation maps the inbound Pack Change Request fields to the input parameters of the PE stored procedure MDM0140R. The stored procedure validates whether an item pack change is permitted for the given item number and location, and returns a status indicator. The response maps the validation result back along with the original request fields.

**Tibco Reference:** PECallForPackChange.bwp

### Field Mapping Table - Request (Stibo to MDM0140R)

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Item Number | ItemNumber | xs:string | 46019 | If field exists, map value; otherwise set xsi:nil=true | `<xsl:choose><xsl:when test="exists($post.item/tns1:ItemNumber)"><xsl:value-of select="$post.item/tns1:ItemNumber"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | XITMN | CHAR | 46019 |
| Location | Location | xs:string | 651 | If field exists, map value; otherwise set xsi:nil=true | `<xsl:choose><xsl:when test="exists($post.item/tns1:Location)"><xsl:value-of select="$post.item/tns1:Location"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | XDPTN | CHAR | 651 |
| Check Type | CheckType | xs:string | PCK | If field exists, map value; otherwise set xsi:nil=true | `<xsl:choose><xsl:when test="exists($post.item/tns1:CheckType)"><xsl:value-of select="$post.item/tns1:CheckType"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | XMODE | CHAR | PCK |

Source sample values extracted from Payload1.txt.

### Field Mapping Table - Response (MDM0140R to Stibo)

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Target Field Path | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Item Number | ItemNumber | xs:string | 46019 | Passthrough from original request (if exists) | `<xsl:value-of select="$post.item/tns1:ItemNumber"/>` | ItemNumber | ItemNumber | xs:string | 46019 |
| Location | Location | xs:string | 651 | Passthrough from original request (if exists) | `<xsl:value-of select="$post.item/tns1:Location"/>` | Location | Location | xs:string | 651 |
| Check Type | CheckType | xs:string | PCK | Passthrough from original request (if exists) | `<xsl:value-of select="$post.item/tns1:CheckType"/>` | CheckType | CheckType | xs:string | PCK |
| Validation Status | XSTAT | CHAR | *Y* | Map stored procedure output if not nil. If XSTAT is nil (xsi:nil=true or xsi:nil=1), omit ItemCheckPassed from response. | `<xsl:if test="not(($PackChangeValidation/outputSet/XSTAT/@xsi:nil=(&quot;true&quot;)) or ($PackChangeValidation/outputSet/XSTAT/@xsi:nil=(&quot;1&quot;)))"><xsl:value-of select="$PackChangeValidation/outputSet/XSTAT"/></xsl:if>` | ItemCheckPassed | ItemCheckPassed | xs:string | *Y* |

Source sample values extracted from Payload1.txt. *Italic values are derived by applying the transformation.*

---

## 4. ITEM SUPPLIER CHANGE

### Transformation: Item Supplier Request to MDM0120R Stored Procedure

**Context:**

| Field | Value |
| --- | --- |
| Used In | Item Supplier Change API |
| Activity Name | Map item supplier change request fields to MDM0120R stored procedure parameters and map return code back to response |
| Transformation Type | Request field mapping + JDBC stored procedure call |

**Source Schema:**

- Format: JSON
- XSD: ItemSupplierChangeValidation.xsd
- Root Element: ItemSupplierRequest

**Target Schema:**

- Format: JDBC Stored Procedure Call
- Stored Procedure: MDM0120R
- Schema: Environment-specific (module property SCHEMA)

**Description:**
 This transformation maps the inbound Item Supplier Request fields to the input parameters of the PE stored procedure MDM0120R. The stored procedure validates the item supplier change for the given item number, sub-range, and location, and returns a code indicating the validation result. The response maps the return code back along with the original request fields for correlation.

**Tibco Reference:** ItemSupplierChange.bwp

### Field Mapping Table - Request (Stibo to MDM0120R)

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Item Number | ITEMNUMBER | xs:string | *1234567* | If field exists, map value; otherwise set xsi:nil=true | `<xsl:choose><xsl:when test="exists($post.item/tns:ITEMNUMBER)"><xsl:value-of select="$post.item/tns:ITEMNUMBER"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | XITMN | CHAR | *1234567* |
| Sub-Range | SUBRANGE | xs:string | *01* | If field exists, map value; otherwise set xsi:nil=true | `<xsl:choose><xsl:when test="exists($post.item/tns:SUBRANGE)"><xsl:value-of select="$post.item/tns:SUBRANGE"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | XITSR | CHAR | *01* |
| Location | LOCATION | xs:string | *SOH01* | If field exists, map value; otherwise set xsi:nil=true | `<xsl:choose><xsl:when test="exists($post.item/tns:LOCATION)"><xsl:value-of select="$post.item/tns:LOCATION"/></xsl:when><xsl:otherwise><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:otherwise></xsl:choose>` | XDPTN | CHAR | *SOH01* |

*Italic values are generated - not from a supplied sample.*

### Field Mapping Table - Response (MDM0120R to Stibo)

| Source Field Name | Source Field Path | Data Type | Sample Value | Transformation | Legacy Tibco XSLT Code | Target Field Name | Target Field Path | Data Type | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Item Number | ITEMNUMBER | xs:string | *1234567* | Passthrough from original request (if exists) | `<xsl:value-of select="$post.item/tns:ITEMNUMBER"/>` | ITEMNUMBER | ITEMNUMBER | xs:string | *1234567* |
| Sub-Range | SUBRANGE | xs:string | *01* | Passthrough from original request (if exists) | `<xsl:value-of select="$post.item/tns:SUBRANGE"/>` | SUBRANGE | SUBRANGE | xs:string | *01* |
| Location | LOCATION | xs:string | *SOH01* | Passthrough from original request (if exists) | `<xsl:value-of select="$post.item/tns:LOCATION"/>` | LOCATION | LOCATION | xs:string | *SOH01* |
| Return Code | XRETN | CHAR | *0* | Map stored procedure output if not nil. If XRETN is nil (xsi:nil=true or xsi:nil=1), omit RETURNCODE from response. | `<xsl:if test="not(($ItemSupplierValidation/outputSet/XRETN/@xsi:nil=(&quot;true&quot;)) or ($ItemSupplierValidation/outputSet/XRETN/@xsi:nil=(&quot;1&quot;)))"><xsl:value-of select="$ItemSupplierValidation/outputSet/XRETN"/></xsl:if>` | RETURNCODE | RETURNCODE | xs:string | *0* |

*Italic values are generated - not from a supplied sample.*

---

## Tracking ID Derivation

Each API operation handles a tracking ID for audit/logging purposes. The derivation differs by operation:

| Operation | Tracking ID Logic |
| --- | --- |
| Update Vendor Status | The BWCE proxy generates a tracking ID. If the request contains a TrackingID field with a non-empty value, it is used; otherwise a UUID is generated. This ID is passed through to the response. |
| List TTG For Vendor | Same logic as above - uses request TrackingID if present and non-empty, otherwise generates a UUID. Used for CLE logging but not returned in the response. |
| Validate Pack Change | UUID generated unconditionally. Used for CLE logging only; not part of the request or response schema. |
| Item Supplier Change | UUID generated unconditionally. TrackingID is present in the request schema but is used only for CLE logging; not returned in the response. |
