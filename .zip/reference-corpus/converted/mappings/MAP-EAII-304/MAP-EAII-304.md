<!-- Source: Mapping+-+EAII-304+-+IBA+Directs+ALM+Orders+-+Liquor+Suppliers+to+EIM.doc -->
<!-- Title: Mapping - EAII-304 - IBA Directs ALM Orders - Liquor Suppliers to EIM -->

# Mapping - EAII-304 - IBA Directs ALM Orders - Liquor Suppliers to EIM

# Mapping - EAII-304 - IBA Directs ALM Orders - Liquor Suppliers to EIM

## Transformation: Directs Source Data to EIM Pipe-Separated Values

**Context:**

| Field | Value |
| --- | --- |
| Used In | IBA Directs Translation Pipeline |
| Activity Name | JSON parse + field mapping + DataFormat render to pipe-delimited flat file |
| Transformation Type | JSON Parse + Direct field mapping + RenderData (DataFormat) |

**Source Schema:**

- Format: JSON (parsed to XML via JSON Parser activity)
- Schema: `Directs.xsd`
- Root Element: `DirectsElement` / `DirectsData` (repeating)

**Target Schema:**

- Format: Pipe-delimited flat file (PSV)
- Target XSD: `DataFormatSchema.xsd` - element names are the column values, with column ordering defined by `EIMFile.dataFormatResource`
- Root Element: `DirectsData`

**Sample Payloads:**

| Side | Sample File | Format | Notes |
| --- | --- | --- | --- |
| Source | `EAII-304 - IBA Directs ALM Orders/source_samples/IBADIRECTS-COOPERSBREWERY-20260615000035.json` | JSON | Coopers Brewery - supplier 1046145, 49 records. Used for sample values in mapping table. |
| Source | `EAII-304 - IBA Directs ALM Orders/source_samples/IBADIRECTS-CUB-15062026052501.json` | JSON | CUB - supplier 1033388. Fields appear in different order in JSON but same schema. |
| Target | `EAII-304 - IBA Directs ALM Orders/target_samples/IBADIRECTS-COOPERSBREWERY-20260615000035.PSV.20260615004013535` | PSV (pipe-delimited) | Matching target for Coopers source above. Used for target sample values. |
| Target | `EAII-304 - IBA Directs ALM Orders/target_samples/IBADIRECTS-CUB-15062026052501.PSV.20260615053027450` | PSV (pipe-delimited) | Matching target for CUB source above. |

Sample pairing: Source and target files paired by filename prefix (e.g., `IBADIRECTS-COOPERSBREWERY-20260615000035.json` -> `IBADIRECTS-COOPERSBREWERY-20260615000035.PSV.*`). First record in each source matches first data row in corresponding target.

Additional source samples (ZIP archives): `1033388_20260615052502914.zip`, `1033388_20260629052431427.zip`, `1046145_20260615003040817.zip`, `1046145_20260622003031400.zip`, `1046145_20260629003125511.zip` - these are the original ZIP uploads before extraction.

**Output File / Message Naming:**

- Pattern: `{SourceFileNameWithoutExtension}.PSV`
- **SourceFileNameWithoutExtension**: Derived from the source file name by stripping the file extension (everything after the last dot)
- **How it is derived**: The source file is extracted from the ZIP archive and written to a temporary directory. The translation process reads this file and uses its filename (minus extension) as the PSV output filename base.
- **Trigger file**: A companion trigger file is also produced with the pattern `{SourceFileNameWithoutExtension}.PSV.trg` containing the static text "This is a Trigger File"
- **Output directory**: Configured via environment property (PSVTempDir)
- Example: Source file `IBADIRECTS-COOPERSBREWERY-20260615000035.json` -> Output `IBADIRECTS-COOPERSBREWERY-20260615000035.PSV` + `IBADIRECTS-COOPERSBREWERY-20260615000035.PSV.trg`
- Note: Target sample filenames have an additional timestamp suffix (e.g., `.20260615004013535`) which appears to be appended by the downstream delivery/archival layer - not by the Tibco translation process itself

**Tibco Reference:** XlateToPSV.bwp

**Description:**

This transformation maps direct delivery transaction records from the JSON source format submitted by liquor suppliers into a pipe-separated values (PSV) flat file for ingestion by the EIM platform. The mapping is a straightforward 1:1 field pass-through with one data type conversion (PACKSIZE cast to integer). The PSV output includes a header row containing all 20 field names separated by pipes, followed by data rows with pipe-separated field values. Each row is terminated by a carriage return. The source data iterates over a collection of `DirectsData` records, producing one pipe-delimited output row per source record.

## 1. Field Mapping Table - DirectsData Record

| # | Source Field Name | Source Field Path | Data Type | Pattern | Length | Sample Value | Transformation | Legacy Tibco XSLT Code | # | Target Field Name | Data Type | Pattern | Length | Sample Value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | SUPPID | DirectsData/SUPPID | string | `[0-9]+` | min 1, max 8 | 1046145 | Direct copy | `<xsl:value-of select="tns6:SUPPID"/>` | 1 | SUPPID | string | `[0-9]+` | min 1, max 8 | 1046145 |
| 2 | PRODCODE | DirectsData/PRODCODE | string | `[0-9]+` | max 8 | 507361 | Direct copy | `<xsl:value-of select="tns6:PRODCODE"/>` | 2 | PRODCODE | string | `[0-9]+` | max 8 | 507361 |
| 3 | PRODDESC | DirectsData/PRODDESC | string |  | max 30 | COOPERS STOUT BTL 375ML | Direct copy | `<xsl:value-of select="tns6:PRODDESC"/>` | 3 | PRODDESC | string |  | max 30 | COOPERS STOUT BTL 375ML |
| 4 | SUPPPRODCODE | DirectsData/SUPPPRODCODE | string |  | min 1, max 16 | 142 | Direct copy | `<xsl:value-of select="tns6:SUPPPRODCODE"/>` | 4 | SUPPPRODCODE | string |  | min 1, max 16 | 142 |
| 5 | SUPPPRODDESC | DirectsData/SUPPPRODDESC | string |  | min 1, max 128 | STOUT 375ml | Direct copy | `<xsl:value-of select="tns6:SUPPPRODDESC"/>` | 5 | SUPPPRODDESC | string |  | min 1, max 128 | STOUT 375ml |
| 6 | PACKSIZE | DirectsData/PACKSIZE | integer |  |  | 24 | Cast to integer | `<xsl:value-of select="xsd:int(tns6:PACKSIZE)"/>` | 6 | PACKSIZE | int |  |  | 24 |
| 7 | PRODCATEGORY | DirectsData/PRODCATEGORY | string |  | min 1, max 16 | Beer | Direct copy | `<xsl:value-of select="tns6:PRODCATEGORY"/>` | 7 | PRODCATEGORY | string |  | min 1, max 16 | Beer |
| 8 | GTIN | DirectsData/GTIN | string | `[0-9]+` | max 14 | 00000093302043 | Direct copy | `<xsl:value-of select="tns6:GTIN"/>` | 8 | GTIN | string | `[0-9]+` | min 1, max 14 | 00000093302043 |
| 9 | LICNUMBER | DirectsData/LICNUMBER | string |  | min 1, max 20 | 57000784 | Direct copy | `<xsl:value-of select="tns6:LICNUMBER"/>` | 9 | LICNUMBER | string |  | min 1, max 20 | 57000784 |
| 10 | CUSTNUMBER | DirectsData/CUSTNUMBER | string | `[0-9]+` | 8 | 75283022 | Direct copy | `<xsl:value-of select="tns6:CUSTNUMBER"/>` | 10 | CUSTNUMBER | string | `[0-9]+` | 8 | 75283022 |
| 11 | CUSTNAME | DirectsData/CUSTNAME | string |  | min 1, max 50 | CREMORNE HOTEL | Direct copy | `<xsl:value-of select="tns6:CUSTNAME"/>` | 11 | CUSTNAME | string |  | min 1, max 50 | CREMORNE HOTEL |
| 12 | ADDRESS | DirectsData/ADDRESS | string |  | min 1, max 60 | 207 UNLEY ROAD | Direct copy (source element ADDRESS maps to target element ADDRESS1) | `<xsl:value-of select="tns6:ADDRESS"/>` | 12 | ADDRESS1 | string |  | min 1, max 60 | 207 UNLEY ROAD |
| 13 | SUBURB | DirectsData/SUBURB | string |  | min 1, max 30 | UNLEY | Direct copy | `<xsl:value-of select="tns6:SUBURB"/>` | 13 | SUBURB | string |  | min 1, max 30 | UNLEY |
| 14 | POSTCODE | DirectsData/POSTCODE | string | `[0-9]+` | 4 | 5061 | Direct copy | `<xsl:value-of select="tns6:POSTCODE"/>` | 14 | POSTCODE | string | `[0-9]+` | 4 | 5061 |
| 15 | STATE | DirectsData/STATE | string |  | max 3 | SA | Direct copy | `<xsl:value-of select="tns6:STATE"/>` | 15 | STATE | string |  | max 3 | SA |
| 16 | INVNUMBER | DirectsData/INVNUMBER | string |  | min 1, max 16 | RI857693_4000 | Direct copy | `<xsl:value-of select="tns6:INVNUMBER"/>` | 16 | INVNUMBER | string |  | min 1, max 16 | RI857693_4000 |
| 17 | INVDATE | DirectsData/INVDATE | string | `\\d{4}[/]\\d{2}[/]\\d{2}` | 10 | 2026/06/09 | Direct copy | `<xsl:value-of select="tns6:INVDATE"/>` | 17 | INVDATE | string | `\\d{4}[/]\\d{2}[/]\\d{2}` | 10 | 2026/06/09 |
| 18 | INVCASES | DirectsData/INVCASES | decimal |  | min -9999.99, max 9999.99 | 4.0 | Decimal copy; trailing zeros stripped (e.g., `16.00` -> `16.0`) | `<xsl:value-of select="tns6:INVCASES"/>` | 18 | INVCASES | decimal |  | min -9999.99, max 9999.99 | 4.0 |
| 19 | INVLITRES | DirectsData/INVLITRES | decimal |  | min -99999.99, max 99999.99 | 36.0 | Decimal copy; trailing zeros stripped (e.g., `144.000` -> `144.0`) | `<xsl:value-of select="tns6:INVLITRES"/>` | 19 | INVLITRES | decimal |  | min -9999.999, max 9999.999 | 36.0 |
| 20 | INVVALUE | DirectsData/INVVALUE | decimal |  | min -9999999999.99, max 9999999999.99 | 234.8 | Decimal copy; trailing zeros stripped | `<xsl:value-of select="tns6:INVVALUE"/>` | 20 | INVVALUE | decimal |  | min -9999999999.99, max 9999999999.99 | 234.8 |

Sample values extracted from: source `IBADIRECTS-COOPERSBREWERY-20260615000035.json` record 1, target `IBADIRECTS-COOPERSBREWERY-20260615000035.PSV.20260615004013535` row 1. Source and target values match exactly (1:1 pass-through confirmed).

**Observations from sample cross-check:**

- CUB source submits numeric fields as strings with varying decimal places (e.g., `"INVCASES":"16.00"`, `"INVLITRES":"144.000"`); target PSV normalizes to minimal decimal representation (`16.0`, `144.0`). This is a side effect of the JSON parse + integer/decimal cast during RenderData.
- CUB source submits JSON fields in non-schema order (e.g., SUPPPRODCODE first); the transformation produces output in DataFormat-defined column order regardless of source field order.
- PRODCATEGORY values vary in case across suppliers: Coopers uses `Beer` (mixed case), CUB uses `BEER` (uppercase). The transformation performs no case normalization - values pass through as-is.

**Notes:**

- The PSV output header row is a static string: `SUPPID|PRODCODE|PRODDESC|SUPPPRODCODE|SUPPPRODDESC|PACKSIZE|PRODCATEGORY|GTIN|LICNUMBER|CUSTNUMBER|CUSTNAME|ADDRESS|SUBURB|POSTCODE|STATE|INVNUMBER|INVDATE|INVCASES|INVLITRES|INVVALUE`
- The header row uses `ADDRESS` (not `ADDRESS1`) matching the source field name
- The source schema element is named `ADDRESS` while the target schema element is named `ADDRESS1`; the transformation maps source field `ADDRESS` to target field `ADDRESS1`
- Each data row is terminated by a carriage return (line separator defined in DataFormat resource)
- Column separator is the pipe character (`|`)
- The transformation iterates over all `DirectsData` elements within the parsed JSON source
- INVLITRES: Source schema allows range -99999.99 to 99999.99 (updated 2021-Nov-23); target DataFormat schema retains the original range -9999.999 to 9999.999 - this is a known discrepancy in the legacy implementation

### Loops/Iterations

```
FOR EACH DirectsData record in parsed JSON source
  Map all 20 fields to target DirectsData element (1:1 field mapping)
  Convert each record to a pipe-delimited row via DataFormat render
END FOR
```

The complete XSLT iteration context is:

```
<xsl:for-each select="$ParseJSON/tns6:DirectsData">
    <dataformat:DirectsData>
        <!-- 20 field mappings -->
    </dataformat:DirectsData>
</xsl:for-each>
```
