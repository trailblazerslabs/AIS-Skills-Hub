<!-- Source: Mapping+Manifest+-+EAII-333+-+Campbells+Retailers+to+Sorted.doc -->
<!-- Title: Mapping Manifest - EAII-333 - Campbells Retailers to Sorted -->

# Mapping Manifest - EAII-333 - Campbells Retailers to Sorted

This manifest is emitted by the `tibco-to-fsd` skill after FSD generation. It provides the starting inventory for the `tibco-to-fsd-mapping` skill to generate field-level mapping documents in a separate conversation.

**Tibco Service:** TibcoPaymentProxyService
**FSD File:** `fsd/TibcoPaymentProxyService/Functional Specification - EAII-333 - Campbells Retailers to Sorted.md`
**Generated:** 2026-06-12

---

## Interfaces

### EAII-333 - Campbells Payment

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-333 |
| Business Name | Campbells Payment |
| Source System | Campbells Retailers |
| Source Format | SOAP/XML |
| Target System | SAP Commerce Cloud (Hybris) |
| Target Format | REST/JSON (URL parameters + JSON response) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoPaymentProxyService/SourceCode/TibcoPaymentProxyService/Service Descriptors/HybrisPaymentRequestWSDL.wsdl` | `paymentRequest` | Inbound SOAP contract - defines request (customerId, orderId, paymentAmount, requestTimeout) and response (responseCode, extendedErrorCode, message) |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoPaymentProxyService/SourceCode/TibcoPaymentProxyService/Schemas/interface.PaymentRequestService-PaymentRequest.xsd` | `paymentResponse` / `paymentRequest` | Intermediate XML structure whose element names map 1:1 to the JSON keys in the SAP Commerce Cloud payment capture REST API (EAII-333). Used as input/output for JSON render/parse; the XML is never transmitted. |
| `tibco/TibcoPaymentProxyService/SourceCode/TibcoPaymentProxyService/Schemas/HybrisPaymentServiceParameterSchema.xsd` | `HybrisPaymentServicePostParameters` | Defines REST API URL parameters (orderId as path param, captureAmount as query param) |

**DataFormat Resources (if flat-file target):**

Not applicable - target is REST/JSON.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoPaymentProxyService/SourceCode/TibcoPaymentProxyService/Processes/TibcoPayment/ProxyService/Interface/RequestPayment.bwp` | Entry point BWP | Receives SOAP request, maps request fields to paymentRequest schema, calls InvokeHybrisPaymentService subprocess, maps response back to SOAP |
| `tibco/TibcoPaymentProxyService/SourceCode/TibcoPaymentProxyService/Processes/TibcoPayment/ProxyService/Subprocesses/InvokeHybrisPaymentService.bwp` | Orchestrator BWP | Maps paymentRequest fields to REST URL parameters (orderId -> path, paymentAmount -> captureAmount query), invokes REST POST, parses JSON response to paymentResponse schema |

**Record Types:**

Not applicable - single request/response message pair, no record types.

**Branching:**

No conditional branches - single transformation path. The response evaluation (responseCode = 1 vs otherwise) only affects logging and error message formatting, not the field mapping.

**Sample Payloads:**

No sample payloads provided - mapping skill will auto-generate sample values.

---

*End of manifest. The*`tibco-to-fsd-mapping` skill reads this file to determine what to generate.
