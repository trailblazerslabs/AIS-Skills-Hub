<!-- Source: Mapping+Manifest+-+EAII-514+-+Sorted+to+PE.doc -->
<!-- Title: Mapping Manifest - EAII-514 - Sorted to PE -->

# Mapping Manifest - EAII-514 - Sorted to PE

## Overview

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-514 |
| Business Name | Realtime Pricing |
| Source System | Sorted (Consumer Systems) |
| Source Format | JSON (REST) / XML (SOAP) |
| Target System | PE (IBM AS/400 Power Enterprise) |
| Target Format | Stored Procedure Parameters (JDBC) |
| Direction | Request-Response (Synchronous) |

---

## EAII-514 - Realtime Pricing

### Source Schema

| Attribute | Value |
| --- | --- |
| Schema Path | `tibco/TibcoPricingServiceBW6/SourceCode/com.metcash.PricingService/Schemas/PriceRequest.xsd` |
| Root Element | `PriceDataRequest` |
| Namespace | `<http://www.metcash.com/Integration/PricingService/PricingRequest.xsd`> |
| Format | XML (mapped from JSON for REST, direct XML for SOAP) |

### Target Schema (Stored Procedure Interface)

| Attribute | Value |
| --- | --- |
| Stored Procedure | CX40K6B |
| Schema | IDSPNDUR1 |
| Connection Type | JDBC (IBM AS/400 Custom Driver) |
| Input/Output defined in | `tibco/TibcoPricingServiceBW6/SourceCode/com.metcash.PricingService/Processes/com/metcash/pricingservice/QueryPriceData-CX40K6B.bwp` (embedded JDBC schema) |

### Response Schema

| Attribute | Value |
| --- | --- |
| Schema Path | `tibco/TibcoPricingServiceBW6/SourceCode/com.metcash.PricingService/Schemas/PriceRequest.xsd` |
| Root Element | `PriceDataResponsev2` |
| Namespace | `<http://www.metcash.com/Integration/PricingService/PricingRequest.xsd`> |
| Format | XML (mapped to JSON for REST, direct XML for SOAP) |

### Transformation Entry Point(s)

| BWP / File | Role | Description |
| --- | --- | --- |
| `tibco/TibcoPricingServiceBW6/SourceCode/com.metcash.PricingService/Processes/com/metcash/pricingservice/QueryPriceData-CX40K6B.bwp` | Orchestrator | Core subprocess containing the request-to-SP-input mapping (inline XSLT), the stored procedure call, iteration logic, and SP-output-to-response mapping (inline XSLT in End activity) |
| `tibco/TibcoPricingServiceBW6/SourceCode/com.metcash.PricingService/Processes/com/metcash/pricingservice/RestPricingService.bwp` | REST Entry Point | Contains REST JSON-to-internal-XML input mapping and internal-XML-to-JSON response mapping (both inline XSLT) |
| `tibco/TibcoPricingServiceBW6/SourceCode/com.metcash.PricingService/Processes/com/metcash/pricingservice/SoapPricingService.bwp` | SOAP Entry Point | Contains SOAP namespace mapping from SoapPricingRequest.xsd to internal PriceRequest.xsd namespace, and response mapping back to SOAP namespace |

### Branching

No conditional branches. All products in the request follow the same transformation path through the stored procedure call.

### DataFormat Resources

Not applicable - no flat-file targets. Input/output is structured (JSON/XML/JDBC parameters).

### Record Types

Not applicable - single request produces a single response containing an array of product pricing results. No record type discrimination.

### Sample Payload Paths

| Type | Path |
| --- | --- |
| Source samples (request + response) | `sample_payloads/TibcoPricingServiceBW6/EAII-514 - Realtime Pricing/source_samples/` |

All samples are source-side (Sorted request/response pairs). No target-side samples available - target is an AS/400 stored procedure.

---

## Mapping Notes

### Request Mapping (Source to Stored Procedure Input)

The inline XSLT in `QueryPriceData-CX40K6B.bwp` (CX40K6B-input binding) performs the following transformations:

- `Company` -> `XPCMPN`: `tib:pad-front(tib:trim($Start/ns:Company), 3)`
- `Pillar` -> `XPDIVN`: `tib:pad-front(tib:trim($Start/ns:Pillar), 3)`
- `Department` -> `XPDPTN`: `tib:pad-front(tib:trim($Start/ns:Department), 3)`
- `WarehouseId` -> `XPWHSN`: `tib:pad-front($Start/ns:WarehouseId, 3)`
- `CustomerId` -> `XPCUSN`: `tib:pad-front(tib:right(tib:trim($Start/ns:CustomerId), 8), 10)`
- `Product[n]` -> `XPITMN`: `tib:pad-front(xsd:string(xsd:long(tib:trim($item))), 10)`
- `PriceDate` -> `XPDTES`: `xsd:decimal(concat(YYYY, MM, DD))` (strips hyphens, converts to decimal)
- (hardcoded) -> `XPSFLG`: `"0"`

### Response Mapping (Stored Procedure Output to Response)

The inline XSLT in the End activity of `QueryPriceData-CX40K6B.bwp` maps accumulated stored procedure results back to `PriceDataResponsev2`. The mapping uses positional correlation - `$AccumulatedResults/tns3:resultSet[$pos]/outputSet/FIELD` maps to `PriceData[$pos]/ResponseField`.

Key output field mappings (SP output -> Response field):

- `XOTTLP` -> `ProductPrice`
- `XOTAWP` -> `Allowance`
- `XOLUCA` -> `UnitProductPrice`
- `XOEMSG` -> `ErrorMsg` (conditional on XOERROR = "Y")
- `XZPRCG` -> `OriginalProductPrice`
- `XZLUCA` -> `OriginalUnitProductPrice`
- `XOPRCE` -> `RRPorSRP`
- `XOPRFP` -> `RetailMarginPercent`
- `XZPGST` -> `CartonExcludingGST`
- `XZPEXG` -> `SingleUnitPriceExcGST`

Note: `PromotionalWholesaleCost`, `WholesaleCost`, and `UnitPromotionalSale` are defined in the PriceDataResponsev2 schema but are NOT mapped from any SP output field.

Null handling: Fields with `@xsi:nil="true"` or `@xsi:nil="1"` are omitted from the response (not rendered as empty elements).
