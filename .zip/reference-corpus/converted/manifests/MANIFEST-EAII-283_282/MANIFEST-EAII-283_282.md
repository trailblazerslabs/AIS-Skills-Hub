<!-- Source: Mapping+Manifest+-+EAII-283,+EAII-282+-+STIBO+to+Multiple+Targets.doc -->
<!-- Title: Mapping Manifest - EAII-283, EAII-282 - STIBO to Multiple Targets -->

# Mapping Manifest - EAII-283, EAII-282 - STIBO to Multiple Targets

This manifest is emitted by the `tibco-to-fsd` skill after FSD generation. It provides the starting inventory for the `tibco-to-fsd-mapping` skill to generate field-level mapping documents in a separate conversation.

**Tibco Service:** TibcoPIMService
**FSD File:** `fsd/TibcoPIMService/Functional Specification - EAII-284, EAII-283, EAII-282, EAII-MON, EAII-385 - STIBO to Multiple Targets.md`
**Generated:** 2026-04-15

---

## Shared Source Definition

Both interfaces consume PIM (Stibo STEP) `STEP-ProductInformation` XML messages. The source schema is the same for corporate item interfaces (EAII-283, EAII-284); EAII-282 consumes a supplier item variant of the same structure.

| Field | Value |
| --- | --- |
| Source System | PIM (Stibo Systems STEP) |
| Source Format | XML |
| Source Schema | External schema (`<http://www.stibosystems.com/step`)> - no local XSD; structure defined by PIM export configuration |
| Root Element | `STEP-ProductInformation` |
| Corporate item user type | `pph_msc_item` (consumed by EAII-283) |
| Supplier item user type | `pph_msc_sitm` (consumed by EAII-282) |

See FSD section 1.6 for full source XML structure documentation.

---

## Interfaces

### EAII-283 - Distribute Corporate Item Data (STIBO to Sorted)

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-283 |
| Business Name | Distribute Corporate Item Data |
| Source System | PIM |
| Source Format | XML |
| Target System | Sorted |
| Target Format | JSON (via intermediate XML + JsonRender) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| External (`<http://www.stibosystems.com/step`)> | `STEP-ProductInformation` | No local XSD - PIM STEP export schema |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoPIMService/sourcecode/TibcoPIMPEService/Schemas/CorporateItemMDM.xsd` | `corporateItem` | Intermediate XSD whose element names map 1:1 to JSON keys in the Sorted REST API payload. Used as input to JsonRender; the XML is never transmitted. |

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoPIMService/sourcecode/TibcoPIMPEService/Processes/com/tibco/metcash/pimtosorted/corporate/PIM2SortedCorporateJMSReceiver.bwp` | Entry point BWP | Single BWP contains complete Mapper transformation + JsonRender |

**Record Types:**

| Record Type | Description | Target Schema Element/Path |
| --- | --- | --- |
| Root | Corporate item attributes | `corporateItem/*` (flat fields) |
| locationItem | Location-specific data (array) | `corporateItem/locationItem[N]` |
| asset | Asset/image data (array) | `corporateItem/asset[N]` |

**Branching:**

No conditional branches - single transformation path. Conditional field inclusion via `xsl:if(exists())` but no action code branching.

**Sample Payloads:**

| Side | Branch | File Path | Format |
| --- | --- | --- | --- |
| Source | N/A | `sample_payloads/TibcoPIMService/EAII-283 - Distribute Corporate Item Data/source_samples/1360581885952-1360581885952-682179.xml` | XML |
| Source | N/A | `sample_payloads/TibcoPIMService/EAII-283 - Distribute Corporate Item Data/source_samples/1375178063872-1375178063872-40007694.xml` | XML |
| Target | N/A | `sample_payloads/TibcoPIMService/EAII-283 - Distribute Corporate Item Data/target_samples/transformed data for sorted-682179.json` | JSON |
| Target | N/A | `sample_payloads/TibcoPIMService/EAII-283 - Distribute Corporate Item Data/target_samples/Transformed-Corpitems-40007694-sorted.json` | JSON |

---

### EAII-282 - Distribute Supplier Item Data (STIBO to Sorted)

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-282 |
| Business Name | Distribute Supplier Item Data |
| Source System | PIM |
| Source Format | XML |
| Target System | Sorted |
| Target Format | JSON (via intermediate XML + JsonRender) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| External (`<http://www.stibosystems.com/step`)> | `STEP-ProductInformation` | No local XSD - PIM STEP export schema. Supplier item variant (`pph_msc_sitm` user type). |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoPIMService/sourcecode/TibcoPIMPEService/Schemas/SupplierItem.xsd` | `supplierItem` | Intermediate XSD whose element names map 1:1 to JSON keys in the Sorted REST API payload. Used as input to JsonRender; the XML is never transmitted. |

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoPIMService/sourcecode/TibcoPIMPEService/Processes/com/tibco/metcash/pimtosorted/supplier/PIM2SortedSupplierInternalJMSReceiver.bwp` | Entry point BWP | JMS delivery path - Mapper transformation + JsonRender |
| `tibco/TibcoPIMService/sourcecode/TibcoPIMPEService/Processes/com/tibco/metcash/pimtosorted/supplier/PIM2SortedSupplierAMQPReceiver.bwp` | Entry point BWP | AMQP delivery path - different pipeline but same JSON output (Known Issue #4 in FSD) |

**Record Types:**

| Record Type | Description | Target Schema Element/Path |
| --- | --- | --- |
| Root | Supplier item attributes | `supplierItem/*` (flat fields) |
| barcode | Barcode data (array) | `supplierItem/barcode[N]` |
| itemPrice | Price data per location (array) | `supplierItem/itemPrice[N]` |
| asset | Asset/image data (array) | `supplierItem/asset[N]` |

**Branching:**

No conditional branches - single transformation path. Conditional field inclusion via `xsl:if(exists())` but no action code branching.

> **Note:** Two delivery paths (JMS and AMQP) produce identical JSON output but use different transformation pipelines. The mapping document should use the JMS path (Mapper + JsonRender) as the primary reference and note the AMQP path divergence. See FSD Known Issue #4.
>

**Sample Payloads:**

| Side | Branch | File Path | Format |
| --- | --- | --- | --- |
| Source | N/A | `sample_payloads/TibcoPIMService/EAII-282 - Distribute Supplier Item Data/source_samples/1066225631233-1066225631233_682179.xml` | XML |
| Source | N/A | `sample_payloads/TibcoPIMService/EAII-282 - Distribute Supplier Item Data/source_samples/1076459732992-1076459732992-661746.xml` | XML |
| Target | N/A | `sample_payloads/TibcoPIMService/EAII-282 - Distribute Supplier Item Data/target_samples/Transformed Payload for Sorted_682179.json` | JSON |
| Target | N/A | `sample_payloads/TibcoPIMService/EAII-282 - Distribute Supplier Item Data/target_samples/TransformedPayload-Supplier-Sorted-661746.json` | JSON |

---

*End of manifest. The*`tibco-to-fsd-mapping` skill reads this file to determine what to generate.
