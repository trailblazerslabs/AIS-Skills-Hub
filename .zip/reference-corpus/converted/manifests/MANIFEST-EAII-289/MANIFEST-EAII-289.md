<!-- Source: Mapping+Manifest+-+EAII-289+-+Metcash+Internal+to+ATO.doc -->
<!-- Title: Mapping Manifest - EAII-289 - Metcash Internal to ATO -->

# Mapping Manifest - EAII-289 - Metcash Internal to ATO

This manifest is emitted by the `tibco-to-fsd` skill after FSD generation. It provides the starting inventory for the `tibco-to-fsd-mapping` skill to generate field-level mapping documents in a separate conversation.

**Tibco Service:** TibcoATOBusinessDetails **FSD File:** `fsd/TibcoATOBusinessDetails/Functional Specification - EAII-289 - Metcash Internal to ATO.md` **Generated:** 2026-04-12

---

## Interfaces

### EAII-289 - ABN Business Details Lookup v1

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-289 |
| Business Name | ABN Business Details Lookup v1 |
| Source System | Metcash Internal |
| Source Format | HTTP GET query parameter (`abn`) |
| Target System | ATO (Australian Business Register) |
| Target Format | SOAP 1.2 / XML response (returned to consumer with namespace rebranded to a Metcash namespace) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/fetchDetailsRESTParameterSchema.xsd` | `abn` (string query parameter) | Inbound request parameter schema for `getabn` branch |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/AbrXmlSearch.xsd` | `SearchByABNv201408Response` | ABR-native response schema with namespace rebranded from `http://abr.business.gov.au/ABRXMLSearch/` to `http://atoservice.metcash.com/AbrXmlSearch.xsd` for consumer-facing reply |

**DataFormat Resources (if flat-file target):**

N/A - not a flat-file target.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Processes/com/metcash/atobusinessdetails/fetchDetailsREST.bwp` | Entry point BWP | REST-to-SOAP facade; `pick onMessage` branch `getabn`. Steps: extract `abn` → assign Transaction ID → log begin → invoke `ABRXMLSearchSoap12.SearchByABNv201408` → response XSLT (namespace rebrand) → reply → log end. Per-branch fault handler + top-level catchAll. |

**Record Types:**

N/A - single record per request/response.

**Branching:**

| Discriminator Field | Branch Values | XSLT Condition Pattern |
| --- | --- | --- |
| `pick onMessage` operation name | `getabn` (this interface) vs `getacn` (sibling) | BPEL `<pick>` activity routes by inbound REST operation |

The response XSLT itself is a near-pass-through with namespace rebranding. Element-by-element mapping is the same as ABR's `SearchByABNv201408Response` shape; the only transformation is the namespace URI on every output element.

**Sample Payloads:**

| Side | Branch | File Path | Format |
| --- | --- | --- | --- |
| Source | getabn | `sample_payloads/TibcoATOBusinessDetails/EAII-289 - ABN Business Details Lookup v1/source_samples/` | HTTP GET (URL with query parameter) |
| Target | getabn | `sample_payloads/TibcoATOBusinessDetails/EAII-289 - ABN Business Details Lookup v1/target_samples/` | XML (Metcash-namespaced ABR response) |

No sample payloads provided - mapping skill will auto-generate sample values.

---

### EAII-289 - ACN Business Details Lookup v1

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-289 |
| Business Name | ACN Business Details Lookup v1 |
| Source System | Metcash Internal |
| Source Format | HTTP GET query parameter (`acn`) |
| Target System | ATO (Australian Business Register) |
| Target Format | SOAP 1.2 / XML response (returned to consumer with namespace rebranded to a Metcash namespace) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/fetchDetailsRESTParameterSchema.xsd` | `acn` (string query parameter) | Inbound request parameter schema for `getacn` branch |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/AbrXmlSearch.xsd` | `SearchByASICv201408Response` | ABR-native response schema with namespace rebranded from `http://abr.business.gov.au/ABRXMLSearch/` to `http://atoservice.metcash.com/AbrXmlSearch.xsd` for consumer-facing reply |

**DataFormat Resources (if flat-file target):**

N/A - not a flat-file target.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Processes/com/metcash/atobusinessdetails/fetchDetailsREST.bwp` | Entry point BWP | REST-to-SOAP facade; `pick onMessage` branch `getacn`. Steps: extract `acn` → assign Transaction ID → log begin → invoke `ABRXMLSearchSoap12.SearchByASICv201408` → response XSLT (namespace rebrand) → reply → log end. Per-branch fault handler + top-level catchAll. |

**Record Types:**

N/A - single record per request/response.

**Branching:**

| Discriminator Field | Branch Values | XSLT Condition Pattern |
| --- | --- | --- |
| `pick onMessage` operation name | `getacn` (this interface) vs `getabn` (sibling) | BPEL `<pick>` activity routes by inbound REST operation |

The response XSLT itself is a near-pass-through with namespace rebranding. Element-by-element mapping is the same as ABR's `SearchByASICv201408Response` shape; the only transformation is the namespace URI on every output element.

**Sample Payloads:**

| Side | Branch | File Path | Format |
| --- | --- | --- | --- |
| Source | getacn | `sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v1/source_samples/` | HTTP GET (URL with query parameter) |
| Target | getacn | `sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v1/target_samples/` | XML (Metcash-namespaced ABR response) |

No sample payloads provided - mapping skill will auto-generate sample values.

---

### EAII-289 - ABN Business Details Lookup v2

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-289 |
| Business Name | ABN Business Details Lookup v2 |
| Source System | Metcash Internal |
| Source Format | HTTP GET query parameter (`abn`) - ABR REST upstream returns JSON which is parsed into `SearchByABNv201408Response` XML element shape before mapping |
| Target System | Metcash Internal Consumer (canonical response) |
| Target Format | XML - canonical `MetcashIdentifierBObj` |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/fetchDetailsResourceParameterSchema.xsd` | `abn` (string query parameter) | Inbound request parameter schema for v2 `getabn` branch |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/AbrXmlSearch.xsd` | `SearchByABNv201408Response` | Intermediate XML shape that the ABR JSON response is parsed into (via JsonParser) before XSLT mapping. JSON keys map 1:1 to the XSD element names. |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/IdentifierResponse.xsd` | `MetcashIdentifierBObj` | Canonical response: `MTTIdentifierBObj` (IdentifierSubType, Description) + `TCRMPartyIdentificationBObj` (IdentificationDescription, IdentificationStatusValue) |

**DataFormat Resources (if flat-file target):**

N/A - not a flat-file target.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Processes/com/metcash/atobusinessdetails/v2/fetchATODetails.bwp` | Entry point BWP | REST-to-REST facade with canonical mapping; `pick onMessage` branch `getabn`. Steps: OnMessageStart → SetTrackingID → LogCLE Start → InvokeRESTAPI (`/api/ato/getabn/v1?abn`) → ParseJSON (output element `SearchByABNv201408Response`) → response XSLT (maps to `MetcashIdentifierBObj`) → reply → LogCLE End. |

**Record Types:**

N/A - single record per request/response.

**Branching:**

| Discriminator Field | Branch Values | XSLT Condition Pattern |
| --- | --- | --- |
| `pick onMessage` operation name | `getabn` (this interface) vs `getacn` (sibling) | BPEL `<pick>` activity routes by inbound REST operation |

The response XSLT maps from the ABR-native shape into the canonical Metcash shape: `MTTIdentifierBObj.IdentifierSubType` is a fixed value (`1000998`) and `MTTIdentifierBObj.Description` is sourced from `entityType.entityDescription`; the `TCRMPartyIdentificationBObj` block carries the ABN identifier value and current registration status from the ABR response.

**Sample Payloads:**

| Side | Branch | File Path | Format |
| --- | --- | --- | --- |
| Source | getabn | `sample_payloads/TibcoATOBusinessDetails/EAII-289 - ABN Business Details Lookup v2/source_samples/` | HTTP GET (URL with query parameter); upstream returns JSON |
| Target | getabn | `sample_payloads/TibcoATOBusinessDetails/EAII-289 - ABN Business Details Lookup v2/target_samples/` | XML (canonical `MetcashIdentifierBObj`) |

No sample payloads provided - mapping skill will auto-generate sample values.

---

### EAII-289 - ACN Business Details Lookup v2

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-289 |
| Business Name | ACN Business Details Lookup v2 |
| Source System | Metcash Internal |
| Source Format | HTTP GET query parameter (`acn`) - ABR REST upstream returns JSON which is parsed into `SearchByASICv201408Response` XML element shape before mapping |
| Target System | Metcash Internal Consumer (canonical response) |
| Target Format | XML - canonical `MetcashIdentifierBObj` |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/fetchDetailsResourceParameterSchema.xsd` | `acn` (string query parameter) | Inbound request parameter schema for v2 `getacn` branch |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/AbrXmlSearch.xsd` | `SearchByASICv201408Response` | Intermediate XML shape that the ABR JSON response is parsed into (via JsonParser) before XSLT mapping. JSON keys map 1:1 to the XSD element names. |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/IdentifierResponse.xsd` | `MetcashIdentifierBObj` | Canonical response: `MTTIdentifierBObj` (IdentifierSubType, Description) + `TCRMPartyIdentificationBObj` (IdentificationDescription, IdentificationStatusValue) |

**DataFormat Resources (if flat-file target):**

N/A - not a flat-file target.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Processes/com/metcash/atobusinessdetails/v2/fetchATODetails.bwp` | Entry point BWP | REST-to-REST facade with canonical mapping; `pick onMessage` branch `getacn`. Steps: OnMessageStart → SetTrackingID → LogCLE Start → InvokeRESTAPI (`/api/ato/getacn/v1?acn`) → ParseJSON (output element `SearchByASICv201408Response`) → response XSLT (maps to `MetcashIdentifierBObj`) → reply → LogCLE End. |

**Record Types:**

N/A - single record per request/response.

**Branching:**

| Discriminator Field | Branch Values | XSLT Condition Pattern |
| --- | --- | --- |
| `pick onMessage` operation name | `getacn` (this interface) vs `getabn` (sibling) | BPEL `<pick>` activity routes by inbound REST operation |

The response XSLT maps from the ABR-native shape into the canonical Metcash shape: `MTTIdentifierBObj.IdentifierSubType` is a fixed value (`1000998`) and `MTTIdentifierBObj.Description` is sourced from `entityType.entityDescription`; the `TCRMPartyIdentificationBObj` block carries the ACN identifier value and current registration status from the ABR response.

**Sample Payloads:**

| Side | Branch | File Path | Format |
| --- | --- | --- | --- |
| Source | getacn | `sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v2/source_samples/` | HTTP GET (URL with query parameter); upstream returns JSON |
| Target | getacn | `sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v2/target_samples/` | XML (canonical `MetcashIdentifierBObj`) |

No sample payloads provided - mapping skill will auto-generate sample values.

---

*End of manifest. The*`tibco-to-fsd-mapping`*skill reads this file to determine what to generate.*
