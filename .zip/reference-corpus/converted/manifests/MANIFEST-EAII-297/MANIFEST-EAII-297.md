<!-- Source: Mapping+Manifest+-+EAII-297+-+Metconnect+to+Supplier+MDM+-+Get_Release+Supplier+Number.doc -->
<!-- Title: Mapping Manifest - EAII-297 - Metconnect to Supplier MDM - Get_Release Supplier Number -->

# Mapping Manifest - EAII-297 - Metconnect to Supplier MDM - Get/Release Supplier Number

## Interfaces

### EAII-297 - Get/Release MDM Supplier Number

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-297 |
| Business Name | Get/Release MDM Supplier Number |
| Source System | Salesforce (MetConnect Portal) |
| Source Format | JSON (REST API request body) |
| Target System | IBM MDM |
| Target Format | JSON (REST API response body) |

> **Note:** This interface covers two operations — Get New Supplier Number and Release Reserved Supplier Number — both exposed as REST endpoints and both invoking the IBM MDM SOAP service. There is a single transformation entry-point BWP that handles both operations via separate `onMessage` handlers. The mapping document must cover both operations.
>

---

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Schemas/NewSupplier.xsd` | `NewSupplierRequest` | Defines the Get New Supplier Number REST request body. Namespace: `http://www.metcash.com/mdm/NewSupplier`. |
| `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Schemas/NewSupplier.xsd` | `clearSupplierRequest` | Defines the Release Reserved Supplier Number REST request body. Same schema file, different root element. |

---

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Schemas/NewSupplier.xsd` | `NewSupplierResponse` | Defines the Get New Supplier Number REST response body. Element names map 1:1 to JSON keys returned to the caller. |
| `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Schemas/NewSupplier.xsd` | `clearSupplierResponse` | Defines the Release Reserved Supplier Number REST response body. Element names map 1:1 to JSON keys returned to the caller. |
| `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Service Descriptors/MTTSUPServices.wsdl` | `getNextSupplierNumber` / `getNextSupplierNumberResponse` | IBM MDM SOAP service definition. The response body contains `MTTSupNumbersBObj/ReferenceNumber` (raw sequence) and `MTTSupNumbersBObj/Parent` (AgreementID echo-back). Used as intermediate input to response mapping. |
| `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Service Descriptors/MTTSUPServices.wsdl` | `clearReservedSupplierNumbers` / `clearReservedSupplierNumbersResponse` | IBM MDM SOAP service definition for Release operation. Response contains `MTTSupNumbersBObj/Parent` and `TxResult/ResultCode` (mapped to `SuccessString`). |

> **Intermediate schemas note:** The MDM WSDL types reference `PhysicalMDM.xsd` (IBM MDM schema, not in this repo) and `MDMWSDLCommon.xsd` (available at `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Schemas/MDMWSDLCommon.xsd`). The mapping skill should read `MDMWSDLCommon.xsd` for `RequestControl`, `TxResult`, and `MTTSupNumbersBObj` type definitions.
>

---

**DataFormat Resources:** Not applicable — target format is JSON, not flat-file. No DataFormat resources.

---

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Processes/com/metcash/mdmsupplier/mdmSupplierNumberInterface.bwp` | Entry-point BWP (combined) | Single BWP handles both REST endpoints via two `bpws:onMessage` handlers. Contains all embedded XSLT mapper logic for request translation, response mapping, supplier number formatting, logging, and error handling. No further subprocess tracing required for transformation logic — all field mappings are embedded in this file. |
| `tibco/TibcoMDMSupplierNumberService/sourcecode/com.metcash.MDMSupplierNumber/Processes/com/metcash/oauth/Oauth2Authentication.bwp` | Auth subprocess | Validates Bearer token. No field-level data transformation — exclude from mapping tables. |

> **Subprocess tracing note:** The `mdmSupplierNumberInterface.bwp` calls `commonlogging.sh.invokeLogEvent` for audit logging. The logging subprocess does NOT contain data transformation relevant to the source-to-target mapping — it only structures log events. Do NOT trace into the CommonLogging subprocesses.
>

---

**Record Types:**

This interface does not use record types (HDR/COR/DTL etc.). Each operation is a flat single-record request-response.

| Operation | Request Root | Response Root |
| --- | --- | --- |
| Get New Supplier Number | `NewSupplierRequest` | `NewSupplierResponse` |
| Release Reserved Supplier Number | `clearSupplierRequest` | `clearSupplierResponse` |

---

**Branching:**

No conditional branches — single transformation path per operation. The two operations (Get and Release) are handled by separate `onMessage` handlers within the same BWP, but each is a distinct linear flow with no internal branching on payload content.

---

**Key Transformation Rules (for mapping skill reference):**

| Target Field | Source / Derivation Rule | XSLT Reference Location |
| --- | --- | --- |
| `NewSupplierResponse/TransactionID` | From process variable `TransactionID` — set from `post.item/tns:TransactionID` if present, else `tib:uuid()` | `mdmSupplierNumberInterface.bwp` — BWAssign "TransactionID", then Reply mapper |
| `NewSupplierResponse/SourceSystemID` | Conditional pass-through: only populated if present in source request (`post.item/tns1:SourceSystemID`) | `mdmSupplierNumberInterface.bwp` — Reply mapper `xsl:if test="$post.item/tns1:SourceSystemID"` |
| `NewSupplierResponse/AgreementID` | From MDM response: `getNextSupplierNumber.parameters/ns1:MTTSupNumbersBObj/ns1:Parent` (MDM echoes the input AgreementID back) | `mdmSupplierNumberInterface.bwp` — Reply mapper for `newSupplierResponse` |
| `NewSupplierResponse/SupplierNumber` | `concat($Prefix, tib:pad-front(ReferenceNumber, $RefPadLength, $RefPadChar))` where `Prefix="10"`, `RefPadLength=5`, `RefPadChar="0"`, `ReferenceNumber` = `getNextSupplierNumber.parameters/ns8:MTTSupNumbersBObj/ns8:ReferenceNumber` | `mdmSupplierNumberInterface.bwp` — BWAssign "supplierNumber" activity |
| MDM request `RequestControl/requestID` | `format-dateTime(current-dateTime(), "[Y0001][M01][D01][H01][m01][s01][f001]")` (timestamp as 17-digit string) | `mdmSupplierNumberInterface.bwp` — `getNextSupplierNumber` invoke mapper |
| MDM request `MTTSupNumbersBObj/Parent` | `post.item/tns1:AgreementID` (source AgreementID) | `mdmSupplierNumberInterface.bwp` — `getNextSupplierNumber` invoke mapper |
| MDM request `MTTSupNumbersBObj/RefType` | Config value: `"SUPPLIER NUMBER"` (from `$RefType` property `/MDM/MDMAttributes/RefType`) | `mdmSupplierNumberInterface.bwp` — `getNextSupplierNumber` invoke mapper |
| MDM request `MTTSupNumbersBObj/Prefix` | Config value: `"10"` (from `$Prefix` property `/MDM/MDMAttributes/Prefix`) | `mdmSupplierNumberInterface.bwp` — `getNextSupplierNumber` invoke mapper |
| MDM request `DWLControl/requesterName` | Config value from `$RequesterName` property `/MDM/MDMAttributes/RequesterName` | `mdmSupplierNumberInterface.bwp` — `getNextSupplierNumber` invoke mapper |
| MDM request `DWLControl/requesterLanguage` | Config value from `$RequesterLanguage` property `/MDM/MDMAttributes/RequesterLanguage` (value: `"100"`) | `mdmSupplierNumberInterface.bwp` — `getNextSupplierNumber` invoke mapper |
| `clearSupplierResponse/SuccessString` | `clearSupplierNumber.parameters/ns1:TxResult/ns1:ResultCode` (MDM transaction result code) | `mdmSupplierNumberInterface.bwp` — Reply mapper for `clearSupplierResponse` |
| `clearSupplierResponse/AgreementID` | `clearSupplierNumber.parameters/ns1:MTTSupNumbersBObj/ns1:Parent` (MDM echo of input AgreementID) | `mdmSupplierNumberInterface.bwp` — Reply mapper for `clearSupplierResponse` |

---

**Sample Payloads:**

Source and target samples have been provided and converted to JSON format.

| Side | Operation | File Path | Format | Notes |
| --- | --- | --- | --- | --- |
| Source | Get New Supplier Number | `sample_payloads/TibcoMDMSupplierNumberService/EAII-297 - Get-Release MDM Supplier Number/source_samples/getNextSupplierNumber_SampleRequest_1.json` | JSON | `AgreementID=P00029015`, `SourceSystemID=Salesforce` |
| Source | Get New Supplier Number | `sample_payloads/TibcoMDMSupplierNumberService/EAII-297 - Get-Release MDM Supplier Number/source_samples/getNextSupplierNumber_SampleRequest_2.json` | JSON | `AgreementID=P00029017`, `SourceSystemID=Salesforce` |
| Source | Release Reserved Supplier Number | `sample_payloads/TibcoMDMSupplierNumberService/EAII-297 - Get-Release MDM Supplier Number/source_samples/clearReservedSupplierNumber_SampleRequest_1.json` | JSON | `AgreementID=P00028593`, `SourceSystemID=Salesforce` |
| Target | Get New Supplier Number | `sample_payloads/TibcoMDMSupplierNumberService/EAII-297 - Get-Release MDM Supplier Number/target_samples/getNextSupplierNumber_SampleResponse_1.json` | JSON | `SupplierNumber=1012695` (paired with SampleRequest_1) |
| Target | Get New Supplier Number | `sample_payloads/TibcoMDMSupplierNumberService/EAII-297 - Get-Release MDM Supplier Number/target_samples/getNextSupplierNumber_SampleResponse_2.json` | JSON | `SupplierNumber=1012525` (paired with SampleRequest_2) |
| Target | Release Reserved Supplier Number | `sample_payloads/TibcoMDMSupplierNumberService/EAII-297 - Get-Release MDM Supplier Number/target_samples/clearReservedSupplierNumber_SampleResponse_1.json` | JSON | `SuccessString=01` (paired with SampleRequest_1) |

**Sample Pairing:** Matched by AgreementID:

- `P00029015`: SampleRequest_1 ↔ SampleResponse_1 (`SupplierNumber=1012695`)
- `P00029017`: SampleRequest_2 ↔ SampleResponse_2 (`SupplierNumber=1012525`)
- `P00028593`: ClearRequest_1 ↔ ClearResponse_1 (`SuccessString=01`)

---
