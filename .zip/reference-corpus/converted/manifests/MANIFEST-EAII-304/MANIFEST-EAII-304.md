<!-- Source: Mapping+Manifest+-+EAII-304+-+Liquor+Suppliers+to+EIM.doc -->
<!-- Title: Mapping Manifest - EAII-304 - Liquor Suppliers to EIM -->

# Mapping Manifest - EAII-304 - Liquor Suppliers to EIM

This manifest is emitted by the `tibco-to-fsd` skill after FSD generation. It provides the starting inventory for the `tibco-to-fsd-mapping` skill to generate field-level mapping documents in a separate conversation.

**Tibco Service:** TibcoIBADirectsService
**FSD File:** `fsd/TibcoIBADirectsService/Functional Specification - EAII-304 - Liquor Suppliers to EIM.md`
**Generated:** 2026-06-17

---

## Interfaces

### EAII-304 - IBA Directs ALM Orders

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-304 |
| Business Name | IBA Directs ALM Orders |
| Source System | Liquor Suppliers |
| Source Format | JSON (REST API request with base64-encoded ZIP containing source data) |
| Target System | EIM (Enterprise Information Management) |
| Target Format | Pipe-delimited flat file (PSV) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/IBADirectsRequest.xsd` | `DirectsFileDocument` | REST API request schema - contains DocumentHeader (Transaction, Supplier) and DirectsFile (base64-encoded ZIP) |
| `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/Directs.xsd` | `DirectsElement` | Defines `DirectsData` complex type with all 20 source fields and their validation constraints (patterns, lengths, ranges) |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/DataFormatSchema.xsd` | `DirectsData` | Intermediate XSD for RenderData - element names become pipe-delimited column values in the EIM PSV flat file. 20 fields matching source schema with corresponding validation constraints. |

**DataFormat Resources (flat-file target):**

| Resource File | Record Type | Notes |
| --- | --- | --- |
| `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Resources/com/metcash/ibadirects/service/EIMFile.dataFormatResource` | DirectsData | Defines pipe-delimited column ordering (pipe separator, carriage return line separator) for 20 fields: SUPPID, PRODCODE, PRODDESC, SUPPPRODCODE, SUPPPRODDESC, PACKSIZE, PRODCATEGORY, GTIN, LICNUMBER, CUSTNUMBER, CUSTNAME, ADDRESS1, SUBURB, POSTCODE, STATE, INVNUMBER, INVDATE, INVCASES, INVLITRES, INVVALUE |

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Processes/com/metcash/ibadirects/service/JMSTranslateToPSV.bwp` | Entry point BWP | JMS listener on IBADirects.Xlate.Q - orchestrates the full translation pipeline: S3 download, unzip, transform, upload, archive |
| `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Processes/com/metcash/ibadirects/backend/XlateToPSV.bwp` | Orchestrator BWP | Subprocess called by JMSTranslateToPSV - reads source file, parses data, transforms to PSV format using DataFormat resource |

**Record Types:**

| Record Type | Description | Target Schema Element/Path |
| --- | --- | --- |
| DirectsData | Single record type - direct delivery transaction record containing supplier, product, customer, and invoice details | `DirectsData` (flat - no nested record types) |

**Branching:**

No conditional branches - single transformation path. All records are transformed identically regardless of content.

**Sample Payloads:**

No sample payloads provided - mapping skill will auto-generate sample values.

---

*End of manifest. The*`tibco-to-fsd-mapping` skill reads this file to determine what to generate.
