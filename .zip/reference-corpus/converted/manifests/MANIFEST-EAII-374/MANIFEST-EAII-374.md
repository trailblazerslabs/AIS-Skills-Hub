<!-- Source: Mapping+Manifest+-+EAII-374+-+Stibo+to+PE.doc -->
<!-- Title: Mapping Manifest - EAII-374 - Stibo to PE -->

# Mapping Manifest - EAII-374 - Stibo to PE

This manifest is emitted by the `tibco-to-fsd` skill after FSD generation. It provides the starting inventory for the `tibco-to-fsd-mapping` skill to generate field-level mapping documents in a separate conversation.

**Tibco Services:** TibcoMetProductERPService (BWCE proxy) + TibcoMDMCustomerNumberCreation (BW6 backend)
**FSD File:** `fsd/EAII-374/Functional Specification - EAII-374 - Stibo to PE.md`
**Generated:** 2026-07-17

---

## Interfaces

### EAII-374 - Update Vendor Status

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-374 (Operation 1 of 4) |
| Business Name | Update Vendor Status |
| Source System | Stibo (STEP MDM) |
| Source Format | JSON |
| Target System | PE (Power Enterprise - AS/400 DB2) |
| Target Format | JDBC Stored Procedure Call |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Schemas/UpdateVendorStatus.xsd` | `VendorStatusRequest` | Request schema - TrackingID, VendorNumber, VendorStatus, Pillar |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Schemas/UpdateVendorStatus.xsd` | `VendorStatusResponse` | Response schema - TrackingID, VendorNumber, VendorStatus, ReturnCode |

**DataFormat Resources (if flat-file target):**

N/A - target is JDBC stored procedure, not flat file.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Processes/UpdateVendorStatus/BusinessProcesses/UpdateVendorStatusProcess.bwp` | Entry point BWP (BWCE) | Receives REST POST, validates auth, renders JSON, invokes BW6 |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMDMCustomerNumberCreation-3.0.2/TibcoMDMCustomerNumberCreation-3.0.2/sourcecode/com.metcash.mdmcustomernumbercreationservice/Processes/com/metcash/mdmcustomernumbercreationservice/UpdateVendorStatus.bwp` | Orchestrator BWP (BW6) | Maps request to stored procedure MDM0055R parameters, executes, maps response |

**Record Types:**

N/A - single request-response, no record types.

**Branching:**

No conditional branches - single transformation path.

**Sample Payloads:**

No sample payloads provided - mapping skill will auto-generate sample values.

---

### EAII-374 - List TTG For Vendor

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-374 (Operation 2 of 4) |
| Business Name | List TTG For Vendor |
| Source System | Stibo (STEP MDM) |
| Source Format | JSON |
| Target System | PE (Power Enterprise - AS/400 DB2) |
| Target Format | JDBC Table Function Query |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Schemas/ListTTGVendor.xsd` | `ListTTGVendorRequest` | Request schema - VENDORNUMBER, ATTACHTYPE, TrackingID |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Schemas/ListTTGVendor.xsd` | `ListTTGVendorResponse` | Response schema - VENDORNUMBER, ATTACHTYPE, TTGList array of {ATTACH_VALUE, ATTACH_DESCRIPTION} |

**DataFormat Resources (if flat-file target):**

N/A - target is JDBC table function query, not flat file.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Processes/ListTTGForVendor/BusinessProcesses/ListTTGForVendorProcess.bwp` | Entry point BWP (BWCE) | Receives REST POST, validates auth, renders JSON, invokes BW6 |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMDMCustomerNumberCreation-3.0.2/TibcoMDMCustomerNumberCreation-3.0.2/sourcecode/com.metcash.mdmcustomernumbercreationservice/Processes/com/metcash/mdmcustomernumbercreationservice/ListTTGForVendor.bwp` | Orchestrator BWP (BW6) | Executes table function MDM0110Q, iterates result set, maps VTDTTNP/VTAVTGD to ATTACH_VALUE/ATTACH_DESCRIPTION |

**Record Types:**

N/A - single request-response with multi-row result accumulation.

**Branching:**

No conditional branches - single transformation path.

**Sample Payloads:**

No sample payloads provided - mapping skill will auto-generate sample values.

---

### EAII-374 - Validate Pack Change

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-374 (Operation 3 of 4) |
| Business Name | Validate Pack Change |
| Source System | Stibo (STEP MDM) |
| Source Format | JSON |
| Target System | PE (Power Enterprise - AS/400 DB2) |
| Target Format | JDBC Stored Procedure Call |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Schemas/PIMSchema.xsd` | `PERequest` | BWCE endpoint schema - ItemNumber, Location, CheckType |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMDMCustomerNumberCreation-3.0.2/TibcoMDMCustomerNumberCreation-3.0.2/sourcecode/com.metcash.mdmcustomernumbercreationservice/Schemas/PackChangeValidation.xsd` | `PackChangeRequest` | BW6 backend schema - ItemNumber, Location, CheckType |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Schemas/PIMSchema.xsd` | `PEResponse` | BWCE endpoint response - ItemNumber, Location, CheckType, ItemCheckPassed |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMDMCustomerNumberCreation-3.0.2/TibcoMDMCustomerNumberCreation-3.0.2/sourcecode/com.metcash.mdmcustomernumbercreationservice/Schemas/PackChangeValidation.xsd` | `PackChangeResponse` | BW6 backend response - ItemNumber, Location, CheckType, ItemCheckPassed |

**DataFormat Resources (if flat-file target):**

N/A - target is JDBC stored procedure, not flat file.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Processes/ItemPackChangeValidation/BusinessProcesses/ReceiveValidationRequest.bwp` | Entry point BWP (BWCE) | Receives REST POST, validates auth, calls ValidateItemPackChangePEReq subprocess |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Processes/ItemPackChangeValidation/SubProcesses/ValidateItemPackChangePEReq.bwp` | Subprocess BWP (BWCE) | Renders JSON, invokes BW6 PECallForPackChange endpoint |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMDMCustomerNumberCreation-3.0.2/TibcoMDMCustomerNumberCreation-3.0.2/sourcecode/com.metcash.mdmcustomernumbercreationservice/Processes/com/metcash/mdmcustomernumbercreationservice/PECallForPackChange.bwp` | Orchestrator BWP (BW6) | Maps request to stored procedure MDM0140R parameters, executes, maps response |

**Record Types:**

N/A - single request-response, no record types.

**Branching:**

No conditional branches - single transformation path (PE path only; D365 path excluded from scope).

**Sample Payloads:**

No sample payloads provided - mapping skill will auto-generate sample values.

---

### EAII-374 - Item Supplier Change

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-374 (Operation 4 of 4) |
| Business Name | Item Supplier Change |
| Source System | Stibo (STEP MDM) |
| Source Format | JSON |
| Target System | PE (Power Enterprise - AS/400 DB2) |
| Target Format | JDBC Stored Procedure Call |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Schemas/ItemSupplierChangeValidation.xsd` | `ItemSupplierRequest` | Request schema - TrackingID, ITEMNUMBER, SUBRANGE, LOCATION |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Schemas/ItemSupplierChangeValidation.xsd` | `ItemSupplierResponse` | Response schema - ITEMNUMBER, SUBRANGE, LOCATION, RETURNCODE |

**DataFormat Resources (if flat-file target):**

N/A - target is JDBC stored procedure, not flat file.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMetProductERPService-bwce-v1.0.0/sourcecode/TibcoMetProductERPService/Processes/ItemSupplierChange/BusinessProcesses/ItemSupplierChangeProcess.bwp` | Entry point BWP (BWCE) | Receives REST POST, validates auth, renders JSON, invokes BW6 |
| `tibco/EAII-374 - SOH,SOO,TTG Product Information/TibcoMDMCustomerNumberCreation-3.0.2/TibcoMDMCustomerNumberCreation-3.0.2/sourcecode/com.metcash.mdmcustomernumbercreationservice/Processes/com/metcash/mdmcustomernumbercreationservice/ItemSupplierChange.bwp` | Orchestrator BWP (BW6) | Maps request to stored procedure MDM0120R parameters, executes, maps response |

**Record Types:**

N/A - single request-response, no record types.

**Branching:**

No conditional branches - single transformation path.

**Sample Payloads:**

No sample payloads provided - mapping skill will auto-generate sample values.

---

*End of manifest. The*`tibco-to-fsd-mapping` skill reads this file to determine what to generate.
