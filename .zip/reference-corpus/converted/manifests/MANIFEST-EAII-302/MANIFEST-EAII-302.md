<!-- Source: Mapping+Manifest+-+EAII-302+-+MDM+to+PIM+(STIBO).doc -->
<!-- Title: Mapping Manifest - EAII-302 - MDM to PIM (STIBO) -->

# Mapping Manifest - EAII-302 - MDM to PIM (STIBO)

This manifest is emitted by the `tibco-to-fsd` skill after FSD generation. It provides the starting inventory for the `tibco-to-fsd-mapping` skill to generate field-level mapping documents in a separate conversation.

**Tibco Service:** TibcoSupplierMDMPIMService **FSD File:** `fsd/TibcoSupplierMDMPIMService/Functional Specification - EAII-302 - MDM to PIM.md` **Generated:** 2026-07-02

---

## Interfaces

### EAII-302 - Supplier Contract

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-302 |
| Business Name | Supplier Contract |
| Source System | IBM InfoSphere MDM |
| Source Format | XML (TCRMService) |
| Target System | STIBO STEP PIM |
| Target Format | XML (STEP-ProductInformation) posted to REST endpoint |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Schemas/PhysicalMDM.xsd` | `TCRMService` | IBM InfoSphere MDM core schema; defines `TCRMService`, `TxResponse`, `ResponseObject` and the base MDM structural types. |
| `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Schemas/MDMWSDLCommon.xsd` | (common types) | Common IBM MDM types referenced by `PhysicalMDM.xsd`. |
| `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Schemas/MDMPESalesforceSchema.xsd` | (MDM extensions) | MDM Metcash-specific supplier extension types, including `MTTSupplierDetailsBObj`, `MTTSupplierContractBObj`, `TCRMContractComponentBObj`, `TCRMAdminNativeKeyBObj`. |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Schemas/mdmsupplier/PIM.xsd` | `STEP-ProductInformation` | STIBO STEP master schema for the PIM Supplier Hierarchy import. The transformation output is XML conforming to this schema and is POSTed as the request body to the PIM REST endpoint. |
| `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Schemas/mdmsupplier/SupplierPEFileSchema.xsd` | (supplier types) | Supplier-specific STEP structures referenced by the transformation. |

**DataFormat Resources (if flat-file target):**

Not applicable — target is XML posted to a REST endpoint. No `.dataFormatResource` files are used.

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Processes/com/metcash/mdmpim/SupplierContractToPIM.bwp` | Entry point BWP | JMS receiver on the Supplier Contract queue. Extracts `Body/TCRMService` from the inbound envelope and passes it to `TransformSupplierToPIM`. |
| `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Processes/com/metcash/mdmpim/TransformSupplierToPIM.bwp` | Orchestrator / Transformation BWP | Contains the `MapToPIM` Mapper activity that produces the STEP-ProductInformation XML from the TCRMService input. This is the primary source of field-level mapping evidence. Also contains the REST invocation and retry loop. |
| `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Processes/com/metcash/mdmpim/getOpenidToken.bwp` | OAuth helper BWP | Not part of field-level mapping — included here only for completeness. Manages OAuth token acquisition; no business data transformation. |

**Record Types:**

The target payload is a single-root XML document (`STEP-ProductInformation`) that carries a Classifications hierarchy for one supplier per message. There are no discrete "record types" in the flat-file sense.

| Record Type | Description | Target Schema Element/Path |
| --- | --- | --- |
| Root envelope | Wraps the entire supplier delivery with context/workspace attributes | `STEP-ProductInformation` (attributes: `ContextID`, `ExportContext`, `UseContextLocale`, `WorkspaceID`, `ExportTime`) |
| Classification (supplier contract component) | One `Classification` element per supplier contract component under the `sph-root` parent | `STEP-ProductInformation/Classifications/Classification` |

**Branching:**

No conditional branches - single transformation path. Every inbound supplier contract message is transformed by the same XSLT into a `STEP-ProductInformation` document containing one or more `Classification` entries derived from the supplier's `TCRMContractComponentBObj` elements (filtered to `AdminFieldNameType='2000002'`).

**Sample Payloads:**

| Side | Branch | File Path | Format |
| --- | --- | --- | --- |
| Source | N/A | *No sample placed under*`sample_payloads/TibcoSupplierMDMPIMService/EAII-302 - Supplier Contract/source_samples/`*at time of FSD generation.* | XML (TCRMService) |
| Target | N/A | `sample_payloads/TibcoSupplierMDMPIMService/EAII-302 - Supplier Contract Hierarchy/target_samples/SupplierHierSampleSTEPXml.xml` | XML (STEP-ProductInformation) |
| Target | N/A | `sample_payloads/TibcoSupplierMDMPIMService/EAII-302 - Supplier Contract Hierarchy/target_samples/SupplierHierSampleSTEPXml_V2.xml` | XML (STEP-ProductInformation) |

Sample payloads under `EAII-302 - Supplier Contract Hierarchy/` were placed by an earlier discovery run and may be moved into `EAII-302 - Supplier Contract/target_samples/` before running the mapping skill. If they are not moved, update the paths above before invoking the mapping skill. Additional reference target samples are also available in `tibco/TibcoSupplierMDMPIMService/Docs/MDM-PIM/` (`SupplierHierSampleSTEPXml.xml`, `SupplierHierSampleSTEPXml_V2.xml`, `SampleSTEPXml.xml`).

---

*End of manifest. The*`tibco-to-fsd-mapping`*skill reads this file to determine what to generate.*
