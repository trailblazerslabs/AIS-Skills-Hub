<!-- Source: Mapping+Manifest+-+EAII-301,+EAII-517,+EAII-516+-+Supplier+MDM+to+EIM,+ALM+Sorted,+Food+Sorted.doc -->
<!-- Title: Mapping Manifest - EAII-301, EAII-517, EAII-516 - Supplier MDM to EIM, ALM Sorted, Food Sorted -->

# Mapping Manifest - EAII-301, EAII-517, EAII-516 - Supplier MDM to EIM, ALM Sorted, Food Sorted

This manifest is emitted by the `tibco-to-fsd` skill after FSD generation. It provides the starting inventory for the `tibco-to-fsd-mapping` skill to generate field-level mapping documents in a separate conversation.

**Tibco Service:** TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1
**FSD File:** fsd/TibcoSupplierMDMEIMService/Functional Specification - EAII-301, EAII-517, EAII-516 - Supplier MDM to EIM, ALM Sorted, Food Sorted.md
**Generated:** 2026-07-03

---

## Interfaces

### EAII-301 - Supplier Contract to EIM

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-301 |
| Business Name | Supplier Contract to EIM |
| Source System | Supplier MDM |
| Source Format | XML (IBM MDM TCRMService) |
| Target System | EIM |
| Target Format | Pipe-delimited flat file (11 record types) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/PhysicalMDM.xsd` | `TCRMService` | IBM MDM physical schema - defines source message structure for supplier contract events |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/EIMRecords.xsd` | `root` | Intermediate XSD for RenderData - element names become pipe-delimited column values. Contains 11 record type elements (REF_MDM_PARENT_COMPANY through REF_MDM_TERM). |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/MDMDuplicateRecords.xsd` | `root` | Defines structure for duplicate record detection - reference data values extracted for deduplication before transformation |

**DataFormat Resources (flat-file target):**

| Resource File | Record Type | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_PARENT_COMPANY.dataFormatResource` | REF_MDM_PARENT_COMPANY | Pipe-delimited: RECORD_TYPE, PARENT_COMPANY_ID, PARENT_COMPANY_NM, SOURCE_SYSTEM_CD, MDM_UPDATE_DATE_TIME |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_LEGAL_ENTITY.dataFormatResource` | REF_MDM_LEGAL_ENTITY | Pipe-delimited legal entity record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_LEGAL_IDENTIFIER.dataFormatResource` | REF_MDM_LEGAL_IDENTIFIER | Pipe-delimited legal identifier record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_INDIVIDUAL.dataFormatResource` | REF_MDM_INDIVIDUAL | Pipe-delimited individual contact record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_SUPPLIER_PAY_TO.dataFormatResource` | REF_MDM_SUPPLIER_PAY_TO | Pipe-delimited pay-to supplier record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_SUPPLIER_BUY_FROM.dataFormatResource` | REF_MDM_SUPPLIER_BUY_FROM | Pipe-delimited buy-from supplier record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_AGREEMENT.dataFormatResource` | REF_MDM_AGREEMENT | Pipe-delimited agreement record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_AGREEMENT_GROUP.dataFormatResource` | REF_MDM_AGREEMENT_GROUP | Pipe-delimited agreement group record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_CATEGORY_SPLIT.dataFormatResource` | REF_MDM_CATEGORY_SPLIT | Pipe-delimited category split record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_REBATE.dataFormatResource` | REF_MDM_REBATE | Pipe-delimited rebate record format |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Resources/com/metcash/genarateDatatoEIM/REF_MDM_TERM.dataFormatResource` | REF_MDM_TERM | Pipe-delimited term record format |

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/mdmevent/MDMEventJMSReceiver.bwp` | Entry point BWP | Receives JMS message, calls GenerateDatatoEIM |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/GenerateDatatoEIM/GenerateDatatoEIM.bwp` | Orchestrator BWP | Contains all transformation logic: GetMDMDataForLegal enrichment, duplicate detection, XSLT to EIMRecords, 11 RenderData activities, PushToTarget call |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/mdmevent/GetMDMDataForLegal.bwp` | Subprocess BWP | MDM REST API enrichment - namespace removal + HTTP PUT + response parse |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/XSLTFiles/NamespaceRemoval.xsl` | Standalone XSLT | Strips XML namespaces before MDM REST call |

**Record Types:**

| Record Type | Description | Target Schema Element/Path |
| --- | --- | --- |
| REF_MDM_PARENT_COMPANY | Parent company record | `root/REF_MDM_PARENT_COMPANY` |
| REF_MDM_LEGAL_ENTITY | Legal entity record | `root/REF_MDM_LEGAL_ENTITY` |
| REF_MDM_LEGAL_IDENTIFIER | Legal identifier (ABN, ACN, etc.) | `root/REF_MDM_LEGAL_IDENTIFIER` |
| REF_MDM_INDIVIDUAL | Individual contact record | `root/REF_MDM_INDIVIDUAL` |
| REF_MDM_SUPPLIER_PAY_TO | Pay-to supplier record | `root/REF_MDM_SUPPLIER_PAY_TO` |
| REF_MDM_SUPPLIER_BUY_FROM | Buy-from supplier record | `root/REF_MDM_SUPPLIER_BUY_FROM` |
| REF_MDM_AGREEMENT | Agreement record | `root/REF_MDM_AGREEMENT` |
| REF_MDM_AGREEMENT_GROUP | Agreement group record | `root/REF_MDM_AGREEMENT_GROUP` |
| REF_MDM_CATEGORY_SPLIT | Category split record | `root/REF_MDM_CATEGORY_SPLIT` |
| REF_MDM_REBATE | Rebate record | `root/REF_MDM_REBATE` |
| REF_MDM_TERM | Term record | `root/REF_MDM_TERM` |

**Branching:**

No conditional branches - single transformation path. All 11 record types are always generated from every source message (with zero rows for unpopulated types).

**Sample Payloads:**

| Type | File |
| --- | --- |
| Source | `sample_payloads/TibcoSupplierMDMEIMService/EAII-301 - Supplier Contract to EIM/source_samples/supplier 1012250.txt` |
| Target | `sample_payloads/TibcoSupplierMDMEIMService/EAII-301 - Supplier Contract to EIM/target_samples/MDS_1012250_20260708121741465.bw0a106l5.txt` |
| Source | `sample_payloads/TibcoSupplierMDMEIMService/EAII-301 - Supplier Contract to EIM/source_samples/supplier 1008423.txt` |
| Target | `sample_payloads/TibcoSupplierMDMEIMService/EAII-301 - Supplier Contract to EIM/target_samples/MDS_1008423_20260708114156687.bw0a106km.txt` |
| Source | `sample_payloads/TibcoSupplierMDMEIMService/EAII-301 - Supplier Contract to EIM/source_samples/supplier 1002385.txt` |
| Target | `sample_payloads/TibcoSupplierMDMEIMService/EAII-301 - Supplier Contract to EIM/target_samples/MDS_1002385_20260708102202481.bw0a106ih.txt` |

---

### EAII-517 - Supplier Contract to ALM Sorted

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-517 |
| Business Name | Supplier Contract to ALM Sorted |
| Source System | Supplier MDM |
| Source Format | XML (IBM MDM TCRMService) |
| Target System | ALM Sorted |
| Target Format | JSON (REST API payload) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/PhysicalMDM.xsd` | `TCRMService` | IBM MDM physical schema |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/AutoCTSchema.xsd` | `root` | Intermediate XSD for JsonRender - element names map 1:1 to JSON keys in the ALM Sorted REST API payload. Contains supplierEntity with legalEntityBObj, requestType, mTTSupplierDetailsBObj hierarchy. |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/AutoCT_tCRMOrganizationNameBObj_Schema.xsd` | N/A | Organisation name structure for legal entity mapping |

**DataFormat Resources (flat-file target):**

N/A - JSON target format (no DataFormat resources).

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/mdmevent/ALMEventJMSReceiver.bwp` | Entry point BWP | Receives JMS message from ALM queue, calls GenrateDatatoALM |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/GenerateDatatoAutoCT/GenrateDatatoALM.bwp` | Orchestrator BWP | Contains transformation logic: GetMDMDataForLegal enrichment, MDM XML to AutoCT schema mapper, JsonRender, HTTP POST to ALM |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/mdmevent/GetMDMDataForLegal.bwp` | Subprocess BWP | MDM REST API enrichment |

**Record Types:**

N/A - Single JSON payload structure (not record-type-based).

**Branching:**

No conditional branches - single transformation path.

**Sample Payloads:**

No sample payloads provided - mapping skill will auto-generate sample values.

---

### EAII-516 - Supplier Contract to Food Sorted

| Field | Value |
| --- | --- |
| AIS Interface ID | EAII-516 |
| Business Name | Supplier Contract to Food Sorted |
| Source System | Supplier MDM |
| Source Format | XML (IBM MDM TCRMService) |
| Target System | Food Sorted |
| Target Format | JSON (REST API payload) |

**Source Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/PhysicalMDM.xsd` | `TCRMService` | IBM MDM physical schema |

**Target Schema(s):**

| Schema File | Root Element | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/AutoCTSchema.xsd` | `root` | Same intermediate XSD as EAII-517 - element names map 1:1 to JSON keys in the Food Sorted REST API payload |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Schemas/AutoCT_tCRMOrganizationNameBObj_Schema.xsd` | N/A | Organisation name structure for legal entity mapping |

**DataFormat Resources (flat-file target):**

N/A - JSON target format (no DataFormat resources).

**Transformation Entry Point(s):**

| File | Type | Notes |
| --- | --- | --- |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/mdmevent/AutoCTEventJMSReceiver.bwp` | Entry point BWP | Receives JMS message from AutoCT queue, calls GenrateDatatoAutoCT |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/GenerateDatatoAutoCT/GenrateDatatoAutoCT.bwp` | Orchestrator BWP | Contains transformation logic: GetMDMDataForLegal enrichment, MDM XML to AutoCT schema mapper, JsonRender, HTTP POST to Food Sorted |
| `tibco/TibcoSupplierMDMEIMService-ocp4-bwce.v6.0.1/sourcecode/com.metcash.mdmeimservice/Processes/com/metcash/mdmevent/GetMDMDataForLegal.bwp` | Subprocess BWP | MDM REST API enrichment |

**Record Types:**

N/A - Single JSON payload structure (not record-type-based).

**Branching:**

No conditional branches - single transformation path.

**Sample Payloads:**

No sample payloads provided - mapping skill will auto-generate sample values.

---

*End of manifest. The*`tibco-to-fsd-mapping` skill reads this file to determine what to generate.
