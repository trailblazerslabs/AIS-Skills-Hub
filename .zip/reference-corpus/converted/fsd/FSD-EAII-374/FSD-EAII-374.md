<!-- Source: Functional+Specification+-+EAII-374+-+STIBO+to+PE.doc -->
<!-- Title: Functional Specification - EAII-374 - STIBO to PE -->

# Functional Specification - EAII-374 - STIBO to PE

**Table of Contents**

- 1 Document Overview
  - 1.1 Business context
  - 1.2 Integration description
  - 1.3 Horizon Impact Assessment
  - 1.4 Known Issues
  - 1.5 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope
  - 2.3 Limitations and Constraints

- 3 Requirements Overview
  - 3.1 EAII-374 - PE Item & Vendor Validation - Stibo to PE
    - 3.1.1 Interface Process
      - 3.1.1.1 Process Diagram
      - 3.1.1.2 Process Description
      - 3.1.1.3 Known Issues

    - 3.1.2 Interface requirements / Mapping details
    - 3.1.3 API Endpoint(s) information
    - 3.1.4 Interface Service Level - Gold/Silver/Bronze
    - 3.1.5 Interface Data Classification
    - 3.1.6 Non-functional requirements
    - 3.1.7 Exception handling
    - 3.1.8 Integration Component Monitoring
    - 3.1.9 Reporting
    - 3.1.10 Relevant context considerations
    - 3.1.11 Test scenarios

- 4 Appendices & Supporting Information
  - 4.1 Supporting Material
    - FSD Artifacts
    - Diagram Source Files

  - 4.2 Traceability Appendix
    - Tibco Service Inventory
    - EIP Step to Tibco Artifact Mapping

- 5 FSD Approval Checklist

| **Document Approver** | **Approver Role** |
| --- | --- |
| Amrik Aujla | Platform Representative |
| Vladimir Gurieff | Technical Business Analyst |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Mohanraj Vengiduswamy | Test Manager |

---

# 1 Document Overview

## 1.1 Business context

This Functional Specification Document (FSD) describes an existing integration between Stibo STEP (Master Data Management) and PE (Power Enterprise), Metcash's legacy ERP system running on AS/400. The integration is being migrated from TIBCO BusinessWorks to Azure Integration Services (AIS), and the purpose of this document is to capture the functional requirements so the integration can be re-implemented on the new platform.

Stibo STEP is the master data management platform used by Metcash to manage product and supplier information across the business. When Stibo needs to query or update product-related reference data in PE - such as validating item pack changes, checking item supplier associations, updating vendor statuses, or listing vendor attachment details - it calls a synchronous REST API. The integration service receives these requests, executes the appropriate stored procedure on the PE AS/400 database, and returns the result to Stibo.

The integration supports four API operations that enable Stibo to perform real-time data validation and updates against PE, supporting core product information management workflows.

## 1.2 Integration description

The integration exposes a set of synchronous REST API operations that Stibo calls on demand. Each operation follows the same pattern: Stibo sends a JSON POST request, the integration service maps the request parameters to the corresponding PE stored procedure, executes the stored procedure via JDBC against the AS/400 DB2 database, maps the result back to a JSON response, and returns it to Stibo.

The four in-scope operations are:

1. **Update Vendor Status** - Updates a vendor's status in PE based on vendor number, pillar, and the requested status code. Returns a status code indicating success or failure.
2. **List TTG For Vendor** - Queries PE for a list of Trading Terms Group (TTG) attachment values and descriptions associated with a vendor. Returns a multi-row result set.
3. **Validate Pack Change** - Validates whether an item pack change is permitted for a given item number and location. Returns a pass/fail indicator.
4. **Item Supplier Change** - Validates an item supplier change for a given item number, sub-range, and location. Returns a status code indicating the validation result.

A fifth operation, **Get New Customer Number**, also exists in the legacy service but is excluded from this FSD as it has already been implemented as part of a separate Credit Application interface.

In the legacy implementation, the integration consists of two TIBCO services deployed in a two-tier architecture:

- A BWCE (BusinessWorks Container Edition) proxy service running on OpenShift, which receives inbound API requests from Azure API Management (APIM), performs token-based authentication, and forwards the request to the backend service.
- A BW6 (BusinessWorks 6) backend service running on-premises, which receives the forwarded request, executes the appropriate stored procedure against PE via JDBC, and returns the response.

The BWCE proxy layer exists solely to bridge connectivity between APIM (cloud) and BW6 (on-premises) and performs no business logic. In the AIS implementation, this two-tier architecture will be consolidated into a single integration service.

**Legacy High Level Architecture**

![image-20260728-044523.png](images/06.png)

**Proposed High Level Architecture**

![image-20260728-044555.png](images/07.png)

## 1.3 Horizon Impact Assessment

| **System** | **Colour** | **Rationale** |
| --- | --- | --- |
| PE (Power Enterprise) | 🔴 RED | Explicitly listed in the HIGH risk tier as a named system |
| PIM (Stibo) | 🔴 RED | Explicitly listed in the HIGH risk tier as "PIM (Stibo)" |
| AIS / TIBCO Integration | 🔴 RED | AIS or TIBCO/GoAnywhere Integrations that hit any Red system are classified as RED |

**Impact Summary:** This integration connects two RED-classified systems (PE and Stibo). Under the Horizon Operations Freeze policy, only Business Critical changes are permitted after review by (1) the IT Platform Owner and (2) approval by the Horizon Platform Owner and Business Process Owner. The migration from TIBCO to AIS must follow this approval path.

## 1.4 Known Issues

1. **Legacy two-tier proxy architecture is unnecessary** - The BWCE proxy layer exists only to bridge APIM-to-BW6 connectivity. In the AIS implementation, this can be consolidated into a single service that connects directly to PE, eliminating the extra network hop and simplifying the architecture.
2. **Fixed token authentication is redundant** - The legacy implementation uses a "FixedTokenAuth" mechanism where APIM injects an API key into the request header and the BWCE proxy validates it against a configured value. Since APIM itself supplies and validates the key, this provides no real security benefit. The AIS implementation should use standard OAuth 2.0 or managed identity authentication as provided by APIM.
3. **Validate Pack Change has an unused D365 path** - The legacy BWCE proxy for the Validate Pack Change operation contains a subprocess for calling Dynamics 365 in addition to PE. This D365 path is not in scope for this interface and should not be re-implemented. Only the PE validation path is required.

## 1.5 Glossary

| **Item** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform replacing TIBCO |
| APIM | Azure API Management - the API gateway fronting the integration services |
| AS/400 | IBM iSeries midrange server platform hosting the PE database |
| BWCE | TIBCO BusinessWorks Container Edition - containerised integration runtime |
| BW6 | TIBCO BusinessWorks 6 - on-premises integration runtime |
| CLE | Common Logging Event - Metcash's centralised audit logging service |
| DB2 | IBM DB2 database running on AS/400 |
| JDBC | Java Database Connectivity - protocol for database access |
| PE | Power Enterprise - Metcash's legacy ERP system running on AS/400 |
| Stibo STEP | Stibo Systems' STEP MDM platform for master data management |
| TTG | Trading Terms Group - supplier pricing terms attachment type in PE |

---

# 2 Scope

## 2.1 In Scope

- Migration of four synchronous REST API operations from TIBCO BusinessWorks to Azure Integration Services:
  - Update Vendor Status
  - List TTG For Vendor
  - Validate Pack Change (PE path only)
  - Item Supplier Change

- Consolidation of the two-tier BWCE proxy + BW6 backend architecture into a single AIS service
- Replacement of the legacy fixed token authentication with standard APIM authentication
- Maintaining the existing API contract (JSON request/response schemas) to ensure Stibo can connect without modification
- Audit logging via Metcash's centralised logging service (or AIS equivalent)

## 2.2 Out of Scope

- **Get New Customer Number operation** - Already implemented as part of the Credit Application interface. The existing AIS endpoint will continue to serve this operation.
- **Validate Pack Change - D365 path** - The legacy BWCE proxy contains a subprocess for validating pack changes against Dynamics 365. This path is not required for EAII-374 and will not be re-implemented.
- **Activator, XDock Location Data, and credential refresh processes** - These are TIBCO infrastructure processes related to the D365 path and BWCE container lifecycle management. They are not relevant to the AIS implementation.
- Changes to the Stibo STEP MDM platform
- Changes to the PE stored procedures or AS/400 database schema
- Changes to Azure API Management policies or routing

## 2.3 Limitations and Constraints

- The PE stored procedures are hosted on an AS/400 DB2 database that requires JDBC connectivity. The AIS implementation must be able to establish JDBC connections to the on-premises AS/400 system, which may require a hybrid connectivity solution (e.g., on-premises data gateway or VNet integration).
- The existing API contract (JSON request and response schemas) must be preserved to avoid changes to Stibo STEP MDM.
- The PE stored procedures are legacy AS/400 programs with fixed-length character parameter types (e.g., CHAR(10)). Input values may need padding or casting to match these parameter types.

---

# 3 Requirements Overview

## 3.1 EAII-374 - PE Item & Vendor Validation - Stibo to PE

### 3.1.1 Interface Process

#### 3.1.1.1 Process Diagram

![image-20260728-044636.png](images/08.png)

#### 3.1.1.2 Process Description

This interface provides four synchronous REST API operations that enable Stibo STEP MDM to query and update product-related reference data in PE (Power Enterprise). All four operations follow the same request-reply pattern:

1. Stibo sends a JSON POST request to the designated API endpoint.
2. The integration service authenticates the request.
3. The service maps the JSON request fields to the input parameters of the corresponding PE stored procedure.
4. The service executes the stored procedure against the PE AS/400 DB2 database via JDBC.
5. The service maps the stored procedure output parameters to a JSON response.
6. The service logs the start and end of the transaction for audit purposes.
7. The JSON response is returned to Stibo.

**Operation 1: Update Vendor Status**

Updates a vendor's status in PE. The caller provides the vendor number, the pillar (division), and the requested status code. PE processes the update via stored procedure `MDM0055R` and returns a result code indicating success or failure.

- Request fields: TrackingID, VendorNumber, VendorStatus, Pillar
- Response fields: TrackingID, VendorNumber, VendorStatus, ReturnCode
- Stored procedure parameter mapping:
  - VendorNumber -> XVNDN
  - Pillar -> XDIVN
  - VendorStatus -> XARCD
  - ReturnCode <- XRETN

**Operation 2: List TTG For Vendor**

Queries PE for a list of TTG attachment values associated with a vendor. This operation uses a table function (`MDM0110Q`) rather than a stored procedure, which returns a multi-row result set. The integration iterates over the result rows and accumulates them into an array in the JSON response.

- Request fields: VENDORNUMBER, ATTACHTYPE, TrackingID
- Response fields: VENDORNUMBER, ATTACHTYPE, TTGList (array of ATTACH_VALUE, ATTACH_DESCRIPTION)
- Table function parameter mapping:
  - VENDORNUMBER -> first parameter (CHAR(10))
  - ATTACHTYPE -> second parameter (CHAR(1))
  - VTDTTNP <- ATTACH_VALUE
  - VTAVTGD <- ATTACH_DESCRIPTION

**Operation 3: Validate Pack Change**

Validates whether an item pack change is permitted for a given item number, location, and check type. PE processes the validation via stored procedure `MDM0140R` and returns a status indicator.

- Request fields: ItemNumber, Location, CheckType
- Response fields: ItemNumber, Location, CheckType, ItemCheckPassed
- Stored procedure parameter mapping:
  - ItemNumber -> XITMN
  - Location -> XDPTN
  - CheckType -> XMODE
  - ItemCheckPassed <- XSTAT

**Operation 4: Item Supplier Change**

Validates an item supplier change for a given item number, sub-range, and location. PE processes the validation via stored procedure `MDM0120R` and returns a result code.

- Request fields: TrackingID, ITEMNUMBER, SUBRANGE, LOCATION
- Response fields: ITEMNUMBER, SUBRANGE, LOCATION, RETURNCODE
- Stored procedure parameter mapping:
  - ITEMNUMBER -> XITMN
  - SUBRANGE -> XITSR
  - LOCATION -> XDPTN
  - RETURNCODE <- XRETN

#### 3.1.1.3 Known Issues

1. **Legacy two-tier proxy architecture** - The obligation is to provide synchronous REST API access to PE stored procedures. The legacy implementation uses a two-tier architecture (BWCE proxy on OpenShift forwarding to BW6 on-premises) to bridge APIM cloud connectivity to the on-premises BW6 runtime. In the AIS implementation, this can be consolidated into a single service, as AIS can connect directly to on-premises systems via hybrid connectivity. **Impact on source/target systems:** None - Stibo continues to call the same API endpoint via APIM, and PE stored procedures remain unchanged.
2. **Redundant fixed token authentication** - The obligation is to authenticate inbound API requests. The legacy mechanism uses a "FixedTokenAuth" pattern where APIM injects an API key and the TIBCO service validates it - effectively the integration supplies and validates its own credential. The AIS alternative is to rely on standard APIM authentication (OAuth 2.0, subscription keys, or managed identity) which is already handled at the gateway level. **Impact on source/target systems:** None - authentication is handled between Stibo and APIM, not at the PE layer.

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-374 - PE Item & Vendor Validation - Stibo to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3579084808/Mapping+-+EAII-374+-+PE+Item+Vendor+Validation+-+Stibo+to+PE) |
| TSD for the interface(s) | [Technical Specification - EAII-374 - STIBO to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3048767703/Technical+Specification+-+EAII-374+-+STIBO+to+PE) |
| ADO link for the feature | [Task 333800](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/333800)`: EAII-374 - MDM Item - PE Item & Vendor Validation - Functional Specification` |
| Source file(s) - Update Vendor Status | ![diagram](images/01.png)![diagram](images/03.png) |
| Source file(s) - List TTG For Vendor | ![diagram](images/01.png)![diagram](images/03.png) |
| Source file(s) - Validate Pack Change | ![diagram](images/01.png)![diagram](images/03.png) |
| Source file(s) - Item Supplier Change | None available |
| Target file(s) | None available |

**Note:** Source samples are in XML format as captured from CLE audit logs (TIBCO serializes the internal XML DOM via `tib:render-xml()` regardless of inbound wire format). The actual inbound wire format from Stibo is JSON per the API contract.

### 3.1.3 API Endpoint(s) information

The integration exposes four REST API operations, all using HTTP POST. In the legacy implementation, these are exposed through Azure APIM with the following paths:

| Operation | HTTP Method | API Path | Request Schema | Response Schema |
| --- | --- | --- | --- | --- |
| Update Vendor Status | POST | `/api/item/updateVendorStatus/v1` | VendorStatusRequest | VendorStatusResponse |
| List TTG For Vendor | POST | `/api/item/ListTTGForVendor/v1` | ListTTGVendorRequest | ListTTGVendorResponse |
| Validate Pack Change | POST | `/api/item/validatePackChange/v1` | PERequest | PEResponse |
| Item Supplier Change | POST | `/api/item/ItemSupplierChange/v1` | ItemSupplierRequest | ItemSupplierResponse |

The target system (PE) is accessed via JDBC stored procedure/function calls against the AS/400 DB2 database:

| Operation | PE Stored Procedure/Function | Type |
| --- | --- | --- |
| Update Vendor Status | `MDM0055R` | Stored Procedure (Call) |
| List TTG For Vendor | `MDM0110Q` | Table Function (SQL Query) |
| Validate Pack Change | `MDM0140R` | Stored Procedure (Call) |
| Item Supplier Change | `MDM0120R` | Stored Procedure (Call) |

**Authentication:** Stibo authenticates to APIM using the standard APIM authentication mechanism. The legacy fixed token authentication between APIM and the TIBCO services is a platform internal concern and will not be carried forward.

### 3.1.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Silver (Business Operational) | This integration supports internal product data management operations (vendor status updates, item validation queries) used by the master data management team. While important for operational efficiency, these are not directly customer-facing or revenue-generating transactions. A service disruption would reduce operational efficiency but would not directly impact customers or revenue. The 95% availability SLA (Silver tier) is appropriate. |

### 3.1.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Internal | The data exchanged (vendor numbers, item numbers, location codes, status codes) is internal business reference data. It does not contain customer PII, financial transactions, or commercially sensitive pricing information. | Standard internal data handling. No encryption at rest required beyond platform defaults. Encryption in transit via TLS. No special data masking or anonymisation required. |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume / Average volume / Seasonal considerations / Expected growth | Low volume - on-demand requests. Update Vendor Status: ~10-20/day. List TTG For Vendor: ~1,500/day. Validate Pack Change: ~10-20/day. Item Supplier Change: < 1/month. No batch or scheduled processing. No seasonal considerations identified. |
| Y | Message Size | Average msg size / Max. msg size / Expected growth | Small payloads - each request and response contains 3-4 fields. Average message size < 1 KB. List TTG For Vendor may return multi-row results but remains small (< 10 KB). |
| N | Performance Testing | Performance / Load / Stress |  |
| Y | Latency | Any specific latency requirements | Synchronous request-reply - Stibo expects a response within the stored procedure execution time. Target response time < 5 seconds end-to-end (Silver SLA: < 500ms server response time). |
| N | Scalability | Any specific scalability requirements |  |
| Y | Reliability | Reliability / Disaster Recovery | 95% availability (Silver SLA). Standard AIS platform disaster recovery applies. |
| Y | Auditability & Observability | Fields to be traced | TrackingID, operation name, request timestamp, response timestamp, success/failure status. Refer to the Corporate Global Auditability and Observability requirements. |
| Y | Logging | Fields or key message identifiers to be logged | TrackingID, operation name (e.g., UpdateVendorStatus), start/end timestamps, error details on failure. Legacy implementation logs via CLE (Common Logging Event) service at start and end of each transaction. |
| N | Sequencing or scheduling | Msg/file schedule / Msg/file sequence |  |
| N | Backup & Archiving | Backup / Archiving |  |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Authentication failure | Invalid or missing API credentials on inbound request | Return HTTP 401 Unauthorized response to caller. Log authentication failure for audit. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| JDBC connection failure | Unable to establish connection to PE AS/400 database | Return HTTP 500 Internal Server Error to caller. Log connection error with details. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Stored procedure timeout | PE stored procedure execution exceeds configured timeout (default 60 seconds) | Return HTTP 500 Internal Server Error to caller. Log timeout error with stored procedure name and parameters. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| SQL exception | PE stored procedure returns a SQL error (e.g., data type mismatch, constraint violation) | Return HTTP 400 Bad Request to caller with error details. Log SQL exception with error code and message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unexpected error | Any unhandled exception during processing | Return HTTP 500 Internal Server Error to caller. Log full error details including stack trace. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.1.10 Relevant context considerations

| **Item** | **Status** | **Outcome** *(Noted/Confirmed/Agreed)* | **Outcome Date** |
| --- | --- | --- | --- |
| Get New Customer Number operation is excluded from EAII-374 - already implemented as part of Credit Application interface | Confirmed | Confirmed by Magesh Parthasarathy in briefing | 2026-07-17 |
| Validate Pack Change - D365 path is excluded from scope, only PE path is required | Confirmed | Confirmed by Magesh Parthasarathy in briefing | 2026-07-17 |
| BWCE proxy is a passthrough with no business logic - consolidate to single AIS service | Confirmed | Confirmed by Magesh Parthasarathy in briefing | 2026-07-17 |
| Fixed token authentication is redundant and should not be re-implemented | Noted | Noted - APIM supplies and validates its own key, providing no security value | 2026-07-17 |
| PE connectivity requires JDBC access to on-premises AS/400 DB2 | Noted | AIS implementation will need hybrid connectivity (e.g., on-premises data gateway) | 2026-07-17 |
| All operations are synchronous request-reply with no asynchronous or batch processing | Confirmed | Confirmed from source code analysis | 2026-07-17 |
| List TTG For Vendor uses a table function (MDM0110Q) not a stored procedure, returning multi-row results | Confirmed | Confirmed from BW6 BWP source code - JDBC Query with `SELECT FROM TABLE(...)` syntax | 2026-07-17 |
| PE stored procedure parameters use fixed-length AS/400 character types (CHAR(10), CHAR(1)) | Confirmed | Confirmed from BW6 BWP source code - SQL uses `cast(? as CHAR(n))` | 2026-07-17 |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Update Vendor Status - valid request with vendor number, status, and pillar | PE stored procedure executes successfully, returns ReturnCode indicating success | Verify VendorNumber, VendorStatus echoed back in response |
| T2 | Update Vendor Status - invalid vendor number | PE stored procedure returns appropriate error ReturnCode | Verify error code is meaningful |
| T3 | List TTG For Vendor - valid vendor with multiple TTG entries | Response contains TTGList array with multiple ATTACH_VALUE/ATTACH_DESCRIPTION pairs | Verify all rows from table function are returned |
| T4 | List TTG For Vendor - vendor with no TTG entries | Response contains empty TTGList array | Verify graceful handling of empty result set |
| T5 | Validate Pack Change - item pack change is permitted | Response contains ItemCheckPassed = 'X' (or equivalent success indicator) | Verify all input fields echoed back |
| T6 | Validate Pack Change - item pack change is not permitted | Response contains ItemCheckPassed indicating failure | Verify appropriate failure indicator |
| T7 | Item Supplier Change - valid item supplier change | PE stored procedure executes successfully, returns RETURNCODE indicating success | Verify ITEMNUMBER, SUBRANGE, LOCATION echoed back |
| T8 | Item Supplier Change - invalid item/supplier combination | PE stored procedure returns appropriate error RETURNCODE | Verify error handling |
| T9 | Any operation - JDBC connection failure | HTTP 500 returned to caller with appropriate error message | Verify error is logged |
| T10 | Any operation - stored procedure timeout | HTTP 500 returned to caller with timeout indication | Verify timeout is logged with procedure name |
| T11 | Any operation - SQL exception from PE | HTTP 400 returned to caller with SQL error details | Verify SQL state and error message are logged |
| T12 | Any operation - invalid authentication | HTTP 401 returned to caller | Verify no stored procedure execution occurs |
| T13 | Any operation - verify audit logging | Start and end log events are recorded with TrackingID and operation name | Verify logging service receives events |
| T14 | List TTG For Vendor - verify multi-row iteration | Response correctly accumulates all result rows from table function | Test with vendor having > 10 TTG entries |

---

# 4 Appendices & Supporting Information

## 4.1 Supporting Material

### FSD Artifacts

| **Artifact** | **Type** | **Location** | **Description** |
| --- | --- | --- | --- |
| ![diagram](images/04.png) | XSD | Schemas/ | Defines the VendorStatusRequest and VendorStatusResponse XML structures. Request contains TrackingID, VendorNumber, VendorStatus, Pillar. Response contains TrackingID, VendorNumber, VendorStatus, ReturnCode. Used as the contract for the Update Vendor Status operation. |
| ![diagram](images/10.png) | XSD | Schemas/ | Defines the ListTTGVendorRequest and ListTTGVendorResponse XML structures. Request contains VENDORNUMBER, ATTACHTYPE, TrackingID. Response contains VENDORNUMBER, ATTACHTYPE, and a TTGList array of ATTACH_VALUE/ATTACH_DESCRIPTION pairs. |
| ![diagram](images/13.png) | XSD | Schemas/ | Defines the PackChangeRequest and PackChangeResponse XML structures. Request contains ItemNumber, Location, CheckType. Response adds ItemCheckPassed. |
| ![diagram](images/11.png) | XSD | Schemas/ | Defines the ItemSupplierRequest and ItemSupplierResponse XML structures. Request contains TrackingID, ITEMNUMBER, SUBRANGE, LOCATION. Response contains ITEMNUMBER, SUBRANGE, LOCATION, RETURNCODE. |
| ![diagram](images/02.png) | XSD | Schemas/ (BWCE) | Defines PERequest and PEResponse elements used by the Validate Pack Change BWCE proxy endpoint. Contains the same fields as PackChangeValidation.xsd (ItemNumber, Location, CheckType, ItemCheckPassed). |

### Diagram Source Files

| **Diagram** | **File** |
| --- | --- |
| Legacy High Level Architecture | ![diagram](images/05.png) |
| Proposed High Level Architecture | ![diagram](images/05.png) |
| EAII-374 Process Flow | ![diagram](images/12.png) |

## 4.2 Traceability Appendix

This appendix maps FSD content to the specific TIBCO source artifacts from which it was derived.

### Tibco Service Inventory

**Service 1: TibcoMetProductERPService (BWCE Proxy - OpenShift)**

| **Artifact** | **Type** | **Path** | **Purpose** |
| --- | --- | --- | --- |
| UpdateVendorStatusProcess.bwp | BWP | Processes/UpdateVendorStatus/BusinessProcesses/ | REST endpoint for Update Vendor Status - receives POST, validates token, forwards to BW6 |
| ListTTGForVendorProcess.bwp | BWP | Processes/ListTTGForVendor/BusinessProcesses/ | REST endpoint for List TTG For Vendor - receives POST, validates token, forwards to BW6 |
| ReceiveValidationRequest.bwp | BWP | Processes/ItemPackChangeValidation/BusinessProcesses/ | REST endpoint for Validate Pack Change - receives POST, routes to PE or D365 subprocess |
| ValidateItemPackChangePEReq.bwp | BWP | Processes/ItemPackChangeValidation/SubProcesses/ | Subprocess for PE validation path - renders JSON, invokes BW6, parses response |
| ValidateItemPackChangeD365Req.bwp | BWP | Processes/ItemPackChangeValidation/SubProcesses/ | Subprocess for D365 validation path - OUT OF SCOPE |
| ItemSupplierChangeProcess.bwp | BWP | Processes/ItemSupplierChange/BusinessProcesses/ | REST endpoint for Item Supplier Change - receives POST, validates token, forwards to BW6 |
| Activator.bwp | BWP | Processes/ItemPackChangeValidation/Activator/ | Module activator - initialises Azure Vault and D365 variables on startup - OUT OF SCOPE (D365 infrastructure) |
| getXDockLocationData.bwp | BWP | Processes/ItemPackChangeValidation/Activator/ | Fetches XDock location reference data - OUT OF SCOPE (D365 infrastructure) |
| UpdateVars.bwp | BWP | Processes/ItemPackChangeValidation/Activator/ | Timer-based credential refresh - OUT OF SCOPE (D365 infrastructure) |
| NewCustomerNumberProcess.bwp | BWP | Processes/NewCustomerNumber/BusinessProcesses/ | REST endpoint for Get New Customer Number - OUT OF SCOPE (already implemented) |
| PEHttpClientResource | HTTP Client | Resources/PE/ | HTTP client configuration for BW6 backend REST API calls |
| common.httpConnResource | HTTP Connector | Resources/tibcometproducterpservice/ | HTTP connector for inbound REST service hosting |
| ![diagram](images/04.png) | XSD | Schemas/ | Request/response schema for Update Vendor Status |
| ![diagram](images/10.png) | XSD | Schemas/ | Request/response schema for List TTG For Vendor |
| ![diagram](images/13.png) | XSD | Schemas/ | Request/response schema for Validate Pack Change |
| ![diagram](images/11.png) | XSD | Schemas/ | Request/response schema for Item Supplier Change |
| ![diagram](images/02.png) | XSD | Schemas/ | PERequest/PEResponse schema for Validate Pack Change endpoint |
| ![diagram](images/09.png) | XSD | Schemas/ | REST transport schema with HTTP headers, JWT claims, error types |

**Service 2: TibcoMDMCustomerNumberCreation (BW6 Backend - On-Premises)**

| **Artifact** | **Type** | **Path** | **Purpose** |
| --- | --- | --- | --- |
| UpdateVendorStatus.bwp | BWP | Processes/com/metcash/mdmcustomernumbercreationservice/ | REST endpoint + JDBC Call Procedure MDM0055R |
| ListTTGForVendor.bwp | BWP | Processes/com/metcash/mdmcustomernumbercreationservice/ | REST endpoint + JDBC Query (table function MDM0110Q) |
| PECallForPackChange.bwp | BWP | Processes/com/metcash/mdmcustomernumbercreationservice/ | REST endpoint + JDBC Call Procedure MDM0140R |
| ItemSupplierChange.bwp | BWP | Processes/com/metcash/mdmcustomernumbercreationservice/ | REST endpoint + JDBC Call Procedure MDM0120R |
| NewCustomerNumber.bwp | BWP | Processes/com/metcash/mdmcustomernumbercreationservice/ | REST endpoint + JDBC Call Procedure MDM0050R - OUT OF SCOPE |
| PEJDBCConnectionResource.jdbcResource | JDBC Resource | Resources/com/metcash/mdmcustomernumbercreationservice/ | JDBC connection to PE AS/400 DB2 database |
| LogCLEHttpClient.httpClientResource | HTTP Client | Resources/com/metcash/mdmcustomernumbercreationservice/ | HTTP client for CLE audit logging |
| Resource.httpConnResource | HTTP Connector | Resources/com/metcash/mdmcustomernumbercreationservice/ | HTTP connector for inbound REST service hosting |

### EIP Step to Tibco Artifact Mapping

| **EIP Step** | **Description** | **BWCE Artifact** | **BW6 Artifact** |
| --- | --- | --- | --- |
| Message Receiver | Receive inbound REST API request | Each operation's main BWP (e.g., UpdateVendorStatusProcess.bwp) | Each operation's BWP (e.g., UpdateVendorStatus.bwp) |
| Authentication | Validate inbound request credentials | FixedTokenAuth activity in each BWCE BWP | N/A (trusts BWCE proxy) |
| Message Translator (Request) | Map JSON request to stored procedure parameters | RenderJSON + InvokeRESTAPI-PE in BWCE BWP | Input binding XSLT in BW6 BWP |
| Database Call | Execute PE stored procedure via JDBC | N/A (delegated to BW6) | JDBCCallProcedure / JDBC Query activity |
| Message Translator (Response) | Map stored procedure output to JSON response | ParseJSON in BWCE BWP | Output binding XSLT in BW6 BWP |
| Audit Log | Log transaction start/end/error | LogEventPub (CLE) in each BWCE BWP | LogCLE + WriteToLog in each BW6 BWP |
| Error Handler | Handle and report errors | Catch block in each BWCE BWP | Catch blocks for Timeout, SQL, General errors |

---

# 5 FSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the FSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/14.png)

Click here to expand...

| # | **Checklist Item** |  |
| --- | --- | --- |
|  | **Project Overview** |  |
| 1 | Are the business requirements and objectives of the project defined? | Y |
| 2 | Are the current and future state contexts of the project defined? | Y |
| 3 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 4 | Have any dependencies (technical or otherwise) been defined? | Y |
| 5 | Have any risks (technical or otherwise) and associated mitigation approaches been identified? | Y |
| 6 | Are growth forecasts included in the document? | Y |
|  | **Business Process and Functional Requirements** |  |
| 7 | Has a Business Process Diagram, including the AIS/Orchestration Layer, been included? | Y |
| 8 | Are the functions specific to integrations adequately described? | Y |
| 9 | Have mapping documents for Source and Target systems been captured? | Y |
| 10 | Have lookup logic and handling of failed lookups been defined? | Y |
| 11 | Have the source and target entities been defined? | Y |
| 12 | Have the Source and Target File formats been defined? | Y |
| 13 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 14 | Is the classification of data identified? | Y |
| 15 | Have data handling requirements according to the information classification been defined? | Y |
| 16 | Have the audit requirements for data been defined? | Y |
| 17 | Has each integration been assigned a GSB rating? | Y |
| 18 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 19 | Is logging free of any restricted data fields? | Y |
| 20 | Are any integration component monitoring requirements defined? | Y |
| 21 | Are any specific reporting requirements defined? | Y |
| 22 | Are the batch scheduling requirements defined? | Y |
| 23 | Are the disaster recovery (DR) requirements defined? | Y |
| 24 | Are the storage and data retention requirements defined? | Y |
| 25 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 26 | Are the functional test scenarios defined? | Y |
| 27 | Are the exception test scenarios defined? | Y |
| 28 | Are the performance, load, or stress testing scenarios (if any) defined? | Y |
| 29 | Are the average and peak message/file sizes defined? | Y |
| 30 | Are the average and peak transaction volumes defined? | Y |
| 31 | Are the average and peak transaction frequencies defined? | Y |
| 32 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 33 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 34 | Has a walkthrough of the document been completed? | Y |
|  | **Interface Catalogue** |  |
| 35 | Have all the Metcash columns in the [EAI Interface Catalogue.xlsx](https://metcash.sharepoint.com/:x:/r/sites/AISDevelopmentCentre/Shared%20Documents/General/06.%20EAI%20Interface%20Catalogue/EAI%20Interface%20Catalogue.xlsx?d=wf70ab37d2042493992a3c636da2ab023&csf=1&web=1&e=oZTmqQ) been updated? | Y |
|  | **Approval** |  |
| 36 | Has/have the Interface ID entry/s been added to the EAI Interface Catalogue? | Y |
| 37 | Has the FSD been submitted for reviewed and approval by a Platform Representative? | Y |
| 38 | Has the FSD been submitted for reviewed and approval by a Technical Business Analyst? | Y |
| 39 | Has the FSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 40 | Has the FSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 41 | Has the FSD been submitted for reviewed and approval by a Test Manager? | Y |
