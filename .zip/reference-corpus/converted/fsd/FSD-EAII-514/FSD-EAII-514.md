<!-- Source: Functional+Specification+-+EAII-514+-+Sorted+to+PE.doc -->
<!-- Title: Functional Specification - EAII-514 - Sorted to PE -->

# Functional Specification - EAII-514 - Sorted to PE

**Table of Contents**

- 1 Document Overview
  - 1.1 Business context
  - 1.2 Integration description
  - 1.3 Horizon Impact Assessment
  - 1.4 Known Issues
  - 1.5 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope
  - 2.3 Limitations and Constraints

- 3 Requirements Overview
  - 3.1 EAII-514 - Realtime Pricing - Sorted to PE
    - 3.1.1 Interface Process
      - 3.1.1.1 Process Diagram
      - 3.1.1.2 Process Description
      - 3.1.1.3 Known Issues

    - 3.1.2 Interface requirements / Mapping details
    - 3.1.3 API Endpoint(s) information
    - 3.1.4 Interface Service Level - Gold/Silver/Bronze
    - 3.1.5 Interface Data Classification
    - 3.1.6 Non-functional requirements
    - 3.1.7 Exception handling
    - 3.1.8 Integration Component Monitoring
    - 3.1.9 Reporting
    - 3.1.10 Relevant context considerations
    - 3.1.11 Test scenarios

- 4 Appendices & Supporting Information
  - 4.1 Supporting Material
  - 4.2 Traceability Mapping
  - 4.3 Request/Response Schema Summary
  - 4.4 Stored Procedure Parameter Mapping
  - 4.5 Drawio Diagrams

- 5 FSD Approval Checklist

| **Document Approver** | **Approver Role** |
| --- | --- |
| Shashidhar Kommalapati | Platform Representative |
| Vladimir Gurieff | Technical Business Analyst |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Mohanraj Vengiduswamy | Test Manager |

---

# 1 Document Overview

## 1.1 Business context

Metcash operates a pricing enquiry service that enables downstream ordering and e-commerce systems (collectively referred to as "Sorted") to retrieve real-time product pricing information from Power Enterprise (PE), the legacy ERP system hosted on an IBM AS/400 platform. This service is invoked on-demand during the order placement workflow to ensure that pricing presented to retailers reflects the correct current wholesale cost, promotional pricing, allowances, and related pricing components for a given product, customer, warehouse, and date combination.

The integration currently runs on the TIBCO BusinessWorks 6 platform and is being migrated to Azure Integration Services (AIS) as part of the enterprise integration modernisation programme. The service is highly utilised and migration to AIS is expected to reduce load on the existing BW Container (BWC) infrastructure. This FSD captures the functional requirements so the integration can be re-implemented on the new platform without impacting source or target systems.

## 1.2 Integration description

The Realtime Pricing integration provides a synchronous request-response service where consuming systems submit a pricing enquiry containing customer context (company, pillar, department, warehouse, customer) and a list of product numbers (up to 20), and receive back the calculated pricing breakdown for each product.

The service exposes two protocol bindings - a REST/JSON API and a SOAP/XML web service - both serving the same business function. Both bindings accept identical logical request parameters and return equivalent response structures. The core pricing logic delegates to a stored procedure on the AS/400 Power Enterprise system which performs the actual price calculation.

The service includes a configurable database outage mode that allows the integration to return a controlled error response when the AS/400 is unavailable for planned maintenance, without failing unexpectedly.

**Legacy High Level Architecture**

![image-20260628-234851.png](images/01.png)

**Proposed High Level Architecture**

![image-20260628-234911.png](images/11.png)

## 1.3 Horizon Impact Assessment

| **System** | **Colour** | **Rationale** |
| --- | --- | --- |
| Sorted | 🔴 RED | Explicitly listed as a RED system on the Horizon Impact Assessment |
| PE (AS/400) | 🔴 RED | Explicitly listed as a RED system on the Horizon Impact Assessment |
| AIS | 🔴 RED | AIS/TIBCO integrations that connect to any RED system inherit RED classification |

This integration connects two RED-classified systems (Sorted and PE). Only business-critical changes are permitted after review by (1) IT Platform Owner and (2) approval by Horizon Platform Owner and Business Process Owner.

## 1.4 Known Issues

1. **Sequential per-product stored procedure calls** - The current implementation iterates through requested products one at a time, calling the stored procedure individually for each product. With up to 20 products per request, this creates latency proportional to the product count. A batch-capable stored procedure or parallel execution strategy could reduce response times.
2. **Database outage flag is a static configuration** - The outage flag is a module property that must be manually toggled for planned maintenance windows. An automated health-check mechanism could provide more responsive failover behaviour.

## 1.5 Glossary

| **Item** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| AS/400 | IBM midrange server hosting Power Enterprise |
| CLE | Common Logging Events - the Metcash centralised logging framework |
| GSB | Gold/Silver/Bronze service classification |
| PE | Power Enterprise - legacy ERP system hosted on IBM AS/400, managing pricing among other business functions |
| Pillar | Metcash business division (IGA, ALM, CCC, CSD) |
| Sorted | Customer-facing ordering/e-commerce portal (encompasses IGA, Campbells, and C-Store portals) that invokes the pricing service |

---

# 2 Scope

## 2.1 In Scope

- Synchronous real-time pricing enquiry for up to 20 products per request
- REST/JSON API endpoint (POST)
- SOAP/XML web service endpoint (GetPricingData operation)
- Stored procedure invocation against the AS/400 Power Enterprise system for price calculation
- Database outage mode with configurable error response
- Audit logging of service invocations (transaction history)
- Event logging (start, end, error events) via centralised logging service
- Error handling with structured fault responses (HTTP 500 / SOAP Fault)

## 2.2 Out of Scope

- Changes to the AS/400 stored procedure (CX40K6B) or its calculation logic
- Changes to the consuming Sorted platform's integration client
- Batch pricing operations or scheduled pricing extracts
- Price data persistence or caching within the integration layer
- Authentication and authorisation mechanism changes (to be defined in TSD)

## 2.3 Limitations and Constraints

- The AS/400 Power Enterprise stored procedure processes one product at a time; bulk pricing requires sequential calls
- Maximum of 20 products per single pricing request (schema-enforced constraint)
- Database query timeout is configured at 30 seconds per product call
- Response time is directly proportional to the number of products requested due to sequential processing
- Message queue endpoints are environment-specific with failover configuration
- The service requires JDBC connectivity to the AS/400 using an IBM-specific driver

---

# 3 Requirements Overview

## 3.1 EAII-514 - Realtime Pricing - Sorted to PE

### 3.1.1 Interface Process

#### 3.1.1.1 Process Diagram

![image-20260628-235023.png](images/12.png)

#### 3.1.1.2 Process Description

The Realtime Pricing interface provides an on-demand pricing lookup capability. When a consuming system requires current pricing for one or more products, it submits a pricing enquiry specifying the business context (company, pillar, department, warehouse, customer identifier, and pricing date) along with a list of product numbers.

The integration service validates the request, then for each product in the list, queries the Power Enterprise system to calculate the applicable pricing breakdown. Power Enterprise evaluates the product's pricing rules considering the specific customer, warehouse, and date context to return a comprehensive set of pricing components including wholesale cost, promotional pricing, allowances, retail recommended price, margin percentages, and applicable fees.

If the database outage flag is active (indicating planned maintenance), the service immediately returns a controlled error response without attempting database connectivity, preserving a predictable failure mode for consuming systems.

The response aggregates pricing results for all requested products and returns them synchronously to the caller. Each product's pricing result includes an error indicator that communicates product-level issues (e.g., product not found, pricing not configured) without failing the entire request.

**Business Rules:**

1. **Company validation** - Only the company code "MTT" (Metcash Trading) is accepted
2. **Pillar validation** - Must be one of: IGA, ALM, CCC, CSD
3. **Product limit** - Maximum 20 products per request
4. **Date format** - Pricing date must be in YYYY-MM-DD format
5. **Customer ID formatting** - Right-justified, padded to 10 characters for the stored procedure call
6. **Item number formatting** - Converted to numeric (long), then left-padded to 10 characters
7. **Database outage mode** - When active, returns a configured error message without database access

#### 3.1.1.3 Known Issues

- Sequential stored procedure calls create latency proportional to product count (see Section 1.4 item 1). The AIS implementation could explore parallel execution if the stored procedure supports concurrent invocations for the same customer context.

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-514 - Realtime Pricing - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) |
| TSD for the interface(s) | [Technical Specification - - EAII-514 - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3487301633/Technical+Specification+-+EAII-514+-+Sorted+to+PE) |
| ADO link for the feature | [Task 396069](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/396069)`: EAII-514 - Realtime Pricing - Functional Specification` |
| Source file(s) | ![diagram](images/04.png)![diagram](images/08.png)<br> <br>![diagram](images/09.png)![diagram](images/03.png) |
| Target file(s) | N/A - target is AS/400 stored procedure (no file-based samples available) |

### 3.1.3 API Endpoint(s) information

**REST Endpoint:**

| Attribute | Value |
| --- | --- |
| Protocol | HTTPS |
| Method | POST |
| Path | `/api/pricing/api/rest/PricingServiceBW6/v3` |
| Content-Type (Request) | application/json |
| Content-Type (Response) | application/json |
| Authentication | TBD (to be defined in TSD) |

**SOAP Endpoint:**

| Attribute | Value |
| --- | --- |
| Protocol | HTTPS |
| Method | POST (SOAP) |
| Path | `/api/pricing/api/soap/PricingServiceBW6/v3` |
| SOAP Action | /GetPricingData |
| WSDL Operation | GetPricingData |
| Authentication | TBD (to be defined in TSD) |

**Target System (AS/400 Power Enterprise):**

| Attribute | Value |
| --- | --- |
| Protocol | JDBC |
| Driver | IBM AS/400 JDBC Driver |
| Stored Procedure | CX40K6B |
| Schema | IDSPNDUR1 |
| Query Timeout | 30 seconds |
| Max Connections | 1000 |
| Login Timeout | 30 seconds |

### 3.1.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Gold | This integration is business-critical: it serves real-time pricing lookups to the Sorted customer-facing portal during order placement. An outage directly impacts retailer ordering capability and revenue. The service is highly utilised with enormous transaction volumes, and pricing accuracy is essential for correct wholesale cost presentation to customers. The database outage flag provides a controlled degradation mechanism but does not mitigate customer impact during unplanned failures. |

### 3.1.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Internal | Pricing data is commercially sensitive (wholesale costs, margins, promotional pricing) but is exchanged between internal Metcash systems. No personally identifiable information (PII) is transmitted. Customer IDs are internal account references. | Encrypt in transit. No logging of full pricing response payloads in production (current legacy behaviour - CLE logging disabled due to volume). Restrict access to pricing data to authorised internal systems only. |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume | 10,784 calls/hour (378 calls/minute). Target capacity: 20,000 calls/hour (1,000 calls/minute) to accommodate Christmas peak and post-Horizon growth |
|  |  | Average volume | High - CLE logging disabled in production due to volume/performance impact. Traffic is combined across IGA, Campbells, and C-Store portals |
|  |  | Seasonal considerations | Christmas peak drives highest volumes. Planned capacity targets +50% above current peak |
|  |  | Expected growth | Significant increase expected post-Horizon go-live as legacy Enterprise Portal features migrate to Sorted, bringing more IGA customers placing warehouse orders (including Allocation orders) |
| Y | Message Size | Average msg size | Request: ~500 bytes (5 products). Response: ~2KB (5 products) |
|  |  | Max. msg size | Request: ~1.5KB (20 products). Response: ~8KB (20 products) |
|  |  | Expected growth | Stable - schema limits to 20 products max |
| Y | Performance Testing | Performance / Load / Stress | Load testing required. Target: sustain 1,000 calls/minute (20,000 calls/hour) with <2s response time at 20 products per request |
| Y | Latency | Any specific latency requirements | Response time proportional to product count. Single product: ~30-60ms (stored proc + overhead). 20 products: ~600ms-1.2s (sequential). Target: <2 seconds for max 20 products |
| N | Scalability | Any specific scalability requirements | Standard platform auto-scaling applies |
| Y | Reliability | Reliability | 99% (Gold SLA) |
|  |  | Disaster Recovery | Gold-tier DR: Active-Active, RTO <=1 Hr, RPO <=15 min |
| Y | Auditability & Observability | Fields to be traced | Transaction ID (UUID), Service Name, Start/End DateTime, Destination (Schema.StoredProc.User), Status (1=success, 0=failure) |
| Y | Logging | Fields or key message identifiers to be logged | Transaction UUID, Company, Pillar, Department, WarehouseId, CustomerId, Product list, Error details (on failure) |
| N | Sequencing or scheduling | Msg/file schedule | Not applicable - synchronous on-demand service |
| N | Backup & Archiving | Backup / Archiving | No integration-layer data persistence requiring backup |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Database outage (planned) | Database outage flag is set to true | Return configured error message immediately without attempting database connection | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Database connectivity failure | JDBC connection timeout or SQL exception during stored procedure call | Log error event with fault details, log error to transaction history, return HTTP 500 / SOAP Fault with error message | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Query timeout | Stored procedure execution exceeds 30-second timeout | Log timeout error, return HTTP 500 / SOAP Fault indicating timeout | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Invalid request | Request fails schema validation (missing required fields, invalid format) | Return HTTP 4XX client error / SOAP Fault with validation details | None (client error) |
| Unexpected error | Any unhandled exception during processing | Catch-all fault handler logs error event and transaction history, returns HTTP 500 / SOAP Fault with error message | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Product-level error | Stored procedure returns error for a specific product (e.g., product not found) | Include error message in the product's PriceData response element; do not fail entire request | None (included in response) |

### 3.1.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.1.10 Relevant context considerations

| **Item** | **Status** | **Outcome** *(Noted/Confirmed/Agreed)* | **Outcome Date** |
| --- | --- | --- | --- |
| Both REST and SOAP endpoints serve the same business function and call the same stored procedure. SOAP endpoint may be obsolete - confirmation required | Noted | Both endpoints remain in scope until SOAP retirement is confirmed. The AIS implementation may consolidate to a single protocol if SOAP is confirmed unused |  |
| The stored procedure CX40K6B is called sequentially per product - no batch capability observed | Noted | Investigate whether a batch-capable variant exists on the AS/400 |  |
| CLE logging is controlled by a configurable flag (CLELogOn) - currently disabled in production due to high volume/performance impact | Noted | AIS implementation should always log for observability using a low-overhead mechanism; CLE flag may be retired |  |
| Service uses IBM AS/400 custom JDBC driver (com.ibm.as400.access.AS400JDBCDriver) | Noted | AIS will require equivalent database connectivity - confirm supported mechanisms |  |
| Response v2 schema includes additional fields (RRPorSRP, RetailMarginPercent, CartonExcludingGST, SingleUnitPriceExcGST) not present in original v1 response | Noted | Both versions documented; v2 is the current contract |  |
| Service is highly utilised with significant transaction volumes - logging disabled in production confirms performance sensitivity | Confirmed | Peak: 10,784 calls/hour (378/min). Target capacity: 20,000 calls/hour (1,000/min). Traffic combined from IGA, Campbells, and C-Store portals. Growth expected post-Horizon go-live | 2026-06-18 |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit pricing request with single valid product for IGA pillar | Response contains pricing breakdown for the product with all applicable pricing fields populated | Happy path - single product |
| T2 | Submit pricing request with 20 valid products | Response contains pricing data for all 20 products | Maximum products boundary test |
| T3 | Submit pricing request with invalid product number | Response contains the product entry with ErrorMsg field populated; other valid products still return pricing | Product-level error isolation |
| T4 | Submit pricing request with database outage flag active | Service returns configured error message without attempting database call | Planned outage behaviour |
| T5 | Submit pricing request with invalid company code (not MTT) | Request rejected with validation error | Schema validation |
| T6 | Submit pricing request with invalid pillar code | Request rejected with validation error | Schema validation |
| T7 | Submit pricing request with invalid date format | Request rejected with validation error | Date pattern validation |
| T8 | Submit pricing request when AS/400 is unreachable | Error response returned with timeout/connectivity error details; error logged to transaction history | Unplanned outage |
| T9 | Submit pricing request via SOAP endpoint | Response contains same pricing data as equivalent REST request | Protocol parity |
| T10 | Submit pricing request with 0 products | Response returns context fields (Company, Pillar etc.) with empty PriceData array | Edge case - no products |
| T11 | Submit pricing request for different pillars (ALM, CCC, CSD) | Correct pricing returned per pillar context | Multi-pillar validation |

---

# 4 Appendices & Supporting Information

## 4.1 Supporting Material

| **Artifact** | **Type** | **Description** |
| --- | --- | --- |
| ![diagram](images/10.png) | XSD | Defines the PriceDataRequest, PriceDataResponse, PriceDataResponsev2, and Fault message structures used by both REST and SOAP bindings |
| ![diagram](images/07.png) | WSDL | SOAP web service definition for the GetPricingData operation |
| ![diagram](images/06.png) | Swagger 2.0 | REST API specification defining the POST endpoint and JSON request/response schemas |
| default.substvar | Configuration | Environment-specific configuration including JDBC connection details, port numbers, database outage flag, and logging settings |
| ![diagram](images/13.png) | Postman Collection | API test collection (located in documentation folder) |

## 4.2 Traceability Mapping

| **EIP Step** | **Tibco Artifact** | **Description** |
| --- | --- | --- |
| Message Receiver (REST) | `Processes/com/metcash/pricingservice/RestPricingService.bwp` | REST HTTP receiver - POST endpoint accepting JSON PriceDataRequest |
| Message Receiver (SOAP) | `Processes/com/metcash/pricingservice/SoapPricingService.bwp` | SOAP receiver - GetPricingData operation accepting XML PriceDataRequest |
| Message Translator (Request) | `RestPricingService.bwp` (inline XSLT) | Maps REST JSON body to internal PriceDataRequest XML structure |
| Message Translator (SOAP Request) | `SoapPricingService.bwp` (inline XSLT) | Maps SOAP PriceDataRequest from SOAP namespace to internal namespace |
| Service Activator | `Processes/com/metcash/pricingservice/QueryPriceData-CX40K6B.bwp` | Core subprocess - orchestrates product iteration and stored procedure calls |
| Content-Based Router (Outage Check) | `QueryPriceData-CX40K6B.bwp` (transition condition) | Routes to immediate error response if dbOutageFlag=true, otherwise proceeds to pricing lookup |
| Iterator (Product Loop) | `QueryPriceData-CX40K6B.bwp` (forEach group) | Iterates through each Product in the request, calling stored procedure per product |
| Service Activator (Database) | `QueryPriceData-CX40K6B.bwp` (JDBCCallProcedure) | Calls AS/400 stored procedure CX40K6B with formatted input parameters |
| Aggregator (Results) | `QueryPriceData-CX40K6B.bwp` (AccumulatedResults) | Accumulates individual stored procedure results into combined response |
| Message Translator (Response) | `QueryPriceData-CX40K6B.bwp` (End activity XSLT) | Maps accumulated stored procedure output fields to PriceDataResponsev2 XML |
| Message Translator (REST Response) | `RestPricingService.bwp` (postOut reply XSLT) | Maps PriceDataResponsev2 to REST JSON response |
| Message Translator (SOAP Response) | `SoapPricingService.bwp` (GetPricingDataOut reply XSLT) | Maps PriceDataResponsev2 to SOAP PriceDataResponse |
| Logging (Start) | `RestPricingService.bwp` / `SoapPricingService.bwp` | Calls CommonLogging.invokeLogEvent with start event (conditional on CLELogOn flag) |
| Logging (End) | `RestPricingService.bwp` / `SoapPricingService.bwp` | Calls CommonLogging.invokeLogEvent with end event including response payload |
| Logging (Transaction History) | `RestPricingService.bwp` / `SoapPricingService.bwp` | Calls CommonInterfaceLib.LogtoTransactionHistory with service invocation details |
| Error Handler | `RestPricingService.bwp` / `SoapPricingService.bwp` (catchAll) | Catches all faults, logs error event, logs error transaction history, returns fault response |

## 4.3 Request/Response Schema Summary

**PriceDataRequest (Input):**

| Field | Type | Length/Format | Required | Description |
| --- | --- | --- | --- | --- |
| Company | String | 3 chars (enum: MTT) | Yes | Metcash company code |
| Pillar | String | 3 chars (enum: IGA, ALM, CCC, CSD) | Yes | Business division |
| Department | String | 2-3 chars | Yes | Department code |
| WarehouseId | String | 3 chars | Yes | Warehouse identifier |
| CustomerId | String | 6-10 chars | Yes | Customer account number |
| PriceDate | String | YYYY-MM-DD | Yes | Date for price calculation |
| StateFlag | Integer | Default: 0 | Yes | State flag parameter |
| Product | String[] | Max 10 chars each, max 20 elements | No | List of product numbers to price |

**PriceDataResponsev2 (Output):**

| Field | Type | Description |
| --- | --- | --- |
| Company | String | Echo of request Company |
| Pillar | String | Echo of request Pillar |
| Department | String | Echo of request Department |
| WarehouseId | String | Echo of request WarehouseId |
| CustomerId | String | Echo of request CustomerId |
| PriceDate | String | Echo of request PriceDate |
| PriceData[] | Array | Array of pricing results (one per product) |
| PriceData.Product | String | Product number |
| PriceData.ProductPrice | String | Calculated product price |
| PriceData.PromotionalWholesaleCost | String | Promotional wholesale cost |
| PriceData.Allowance | String | Allowance amount |
| PriceData.WholesaleCost | String | Wholesale cost |
| PriceData.UnitProductPrice | String | Unit product price |
| PriceData.UnitPromotionalSale | String | Unit promotional sale price |
| PriceData.ErrorMsg | String | Product-level error message (if applicable) |
| PriceData.OriginalProductPrice | String | Original product price (before promotion) |
| PriceData.OriginalUnitProductPrice | String | Original unit product price |
| PriceData.RRPorSRP | String | Recommended Retail Price or Suggested Retail Price |
| PriceData.RetailMarginPercent | String | Retail margin percentage |
| PriceData.CartonExcludingGST | String | Carton price excluding GST |
| PriceData.SingleUnitPriceExcGST | String | Single unit price excluding GST |

## 4.4 Stored Procedure Parameter Mapping

**Input Parameters (CX40K6B):**

| SP Parameter | Type | Source Field | Transformation |
| --- | --- | --- | --- |
| XPCMPN | CHAR | Company | pad-front to 3 chars |
| XPDIVN | CHAR | Pillar | pad-front to 3 chars |
| XPDPTN | CHAR | Department | pad-front to 3 chars |
| XPWHSN | CHAR | WarehouseId | pad-front to 3 chars |
| XPCUSN | CHAR | CustomerId | right 8 chars, then pad-front to 10 chars |
| XPITMN | CHAR | Product (current iteration) | Convert to long, then pad-front to 10 chars |
| XPDTES | DECIMAL | PriceDate | Concatenate YYYY+MM+DD as decimal |
| XPSFLG | CHAR | (hardcoded) | Always "0" |

**Output Parameters (CX40K6B):**

| SP Parameter | Maps To | Description |
| --- | --- | --- |
| XOTTLP | ProductPrice | Total product price |
| XOTAWP | Allowance | Allowance value |
| XOLUCA | UnitProductPrice | Unit product price |
| XOEMSG | ErrorMsg | Error message (conditional on XOERROR = "Y") |
| XZPRCG | OriginalProductPrice | Original product price |
| XZLUCA | OriginalUnitProductPrice | Original unit product price |
| XOPRCE | RRPorSRP | Recommended Retail Price / Suggested Retail Price |
| XOPRFP | RetailMarginPercent | Retail margin percentage |
| XZPGST | CartonExcludingGST | Carton price excluding GST |
| XZPEXG | SingleUnitPriceExcGST | Single unit price excluding GST |
| XOERROR | (error flag) | Error indicator |

Note: PromotionalWholesaleCost, WholesaleCost, and UnitPromotionalSale are defined in the PriceDataResponsev2 schema but are not mapped from any SP output parameter.

## 4.5 Drawio Diagrams

| **Diagram** | **File** |
| --- | --- |
| Functional Specification - EAII-514 - Sorted to PE - Legacy High Level Architecture | ![diagram](images/05.png) |
| Functional Specification - EAII-514 - Sorted to PE - Proposed High Level Architecture | ![diagram](images/05.png) |
| EAII-514 - Realtime Pricing - Sorted to PE | ![diagram](images/02.png) |

---

# 5 FSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the FSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/14.png)

Click here to expand...

| # | **Checklist Item** |  |
| --- | --- | --- |
|  | **Project Overview** |  |
| 1 | Are the business requirements and objectives of the project defined? | Y |
| 2 | Are the current and future state contexts of the project defined? | Y |
| 3 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 4 | Have any dependencies (technical or otherwise) been defined? | Y |
| 5 | Have any risks (technical or otherwise) and associated mitigation approaches been identified? | Y |
| 6 | Are growth forecasts included in the document? | Y |
|  | **Business Process and Functional Requirements** |  |
| 7 | Has a Business Process Diagram, including the AIS/Orchestration Layer, been included? | Y |
| 8 | Are the functions specific to integrations adequately described? | Y |
| 9 | Have mapping documents for Source and Target systems been captured? | Y |
| 10 | Have lookup logic and handling of failed lookups been defined? | Y |
| 11 | Have the source and target entities been defined? | Y |
| 12 | Have the Source and Target File formats been defined? | Y |
| 13 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 14 | Is the classification of data identified? | Y |
| 15 | Have data handling requirements according to the information classification been defined? | Y |
| 16 | Have the audit requirements for data been defined? | Y |
| 17 | Has each integration been assigned a GSB rating? | Y |
| 18 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 19 | Is logging free of any restricted data fields? | Y |
| 20 | Are any integration component monitoring requirements defined? | Y |
| 21 | Are any specific reporting requirements defined? | Y |
| 22 | Are the batch scheduling requirements defined? | Y |
| 23 | Are the disaster recovery (DR) requirements defined? | Y |
| 24 | Are the storage and data retention requirements defined? | Y |
| 25 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 26 | Are the functional test scenarios defined? | Y |
| 27 | Are the exception test scenarios defined? | Y |
| 28 | Are the performance, load, or stress testing scenarios (if any) defined? | Y |
| 29 | Are the average and peak message/file sizes defined? | Y |
| 30 | Are the average and peak transaction volumes defined? | Y |
| 31 | Are the average and peak transaction frequencies defined? | Y |
| 32 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 33 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 34 | Has a walkthrough of the document been completed? | Y |
|  | **Interface Catalogue** |  |
| 35 | Have all the Metcash columns in the [EAI Interface Catalogue.xlsx](https://metcash.sharepoint.com/:x:/r/sites/AISDevelopmentCentre/Shared%20Documents/General/06.%20EAI%20Interface%20Catalogue/EAI%20Interface%20Catalogue.xlsx?d=wf70ab37d2042493992a3c636da2ab023&csf=1&web=1&e=oZTmqQ) been updated? | Y |
|  | **Approval** |  |
| 36 | Has/have the Interface ID entry/s been added to the EAI Interface Catalogue? | Y |
| 37 | Has the FSD been submitted for reviewed and approval by a Platform Representative? | Y |
| 38 | Has the FSD been submitted for reviewed and approval by a Technical Business Analyst? | Y |
| 39 | Has the FSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 40 | Has the FSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 41 | Has the FSD been submitted for reviewed and approval by a Test Manager? | Y |
