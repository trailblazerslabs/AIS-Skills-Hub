<!-- Source: Functional+Specification+-+EAII-333+-+Campbells+Retailers+to+Sorted.doc -->
<!-- Title: Functional Specification - EAII-333 - Campbells Retailers to Sorted -->

# Functional Specification - EAII-333 - Campbells Retailers to Sorted

**Table of Contents**

- 1 Document Overview
  - 1.1 Business context
  - 1.2 Integration description
  - 1.3 Horizon Impact Assessment
  - 1.4 Known Issues
  - 1.5 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope
  - 2.3 Limitations and Constraints

- 3 Requirements Overview
  - 3.1 EAII-333 - Campbells Payment - Campbells Retailers to Sorted
    - 3.1.1 Interface Process
      - 3.1.1.1 Process Diagram
      - 3.1.1.2 Process Description
      - 3.1.1.3 Known Issues

    - 3.1.2 Interface requirements / Mapping details
    - 3.1.3 API Endpoint(s) information
    - 3.1.4 Interface Service Level - Gold/Silver/Bronze
    - 3.1.5 Interface Data Classification
    - 3.1.6 Non-functional requirements
    - 3.1.7 Exception handling
    - 3.1.8 Integration Component Monitoring
    - 3.1.9 Reporting
    - 3.1.10 Relevant context considerations
    - 3.1.11 Test scenarios

- 4 Appendices & Supporting Information
  - 4.1 Supporting Material
    - Source Artifacts Inventory
    - Traceability Mapping
    - Configuration Parameters
    - Drawio Diagrams
    - 4.2 Sample Payloads

- 5 FSD Approval Checklist

| **Document Approver** | **Approver Role** |
| --- | --- |
|  | Platform Representative |
| Vladimir Gurieff | Technical Business Analyst |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Mohanraj Vengiduswamy | Test Manager |

---

# 1 Document Overview

## 1.1 Business context

This Functional Specification documents an existing integration being migrated from TIBCO BusinessWorks to Azure Integration Services (AIS). The purpose is to capture the functional requirements so the integration can be re-implemented on the new platform.

The Campbells Payment integration supports the payment capture process for the Campbells Retailers division. Customers place orders through the Campbells portal, and the order information flows to PE (the order management platform) and then to Storeline - the legacy warehouse and point-of-sale system. After the warehouse completes pick and pack, Storeline calculates the actual final payment amount (which may differ from the original order amount due to substitutions or adjustments) and initiates a payment capture request.

This integration receives that payment capture request from Storeline and forwards it to Sorted - the SaaS platform running SAP Commerce Cloud (formerly an in-house Hybris system) - which processes the payment capture through the Braintree payment gateway. The result is returned synchronously to Storeline.

The integration is critical for completing the financial transaction associated with customer orders - without it, payments cannot be captured against placed orders. Campbells operates two account types: credit accounts (used by most customers) and direct accounts.

## 1.2 Integration description

The integration provides a synchronous request-reply payment capture service. Storeline (the warehouse/POS system) sends a SOAP payment capture request containing the customer identifier, order identifier, actual final payment amount, and a request timeout value. The integration translates this to a REST/JSON call to Sorted (SAP Commerce Cloud) and returns the response synchronously.

The payment amount in the request represents the actual amount to be charged to the customer after pick and pack is complete - not the amount displayed at order placement time. The customer identifier is included in the inbound request for traceability but is not forwarded to the target system; the order identifier alone is sufficient for Sorted to identify the transaction.

The integration performs protocol translation: the source system communicates using SOAP/XML while the target system exposes a REST/JSON API over HTTPS. The integration maps the request fields to the target API's URL parameters and interprets the JSON response, formatting error messages when the payment capture is unsuccessful.

**Legacy High Level Architecture**

![image-20260615-233057.png](images/02.png)

**Proposed High Level Architecture**

![image-20260615-233135.png](images/07.png)

## 1.3 Horizon Impact Assessment

| **System** | **Colour** | **Rationale** |
| --- | --- | --- |
| Sorted (SAP Commerce Cloud) | 🔴 RED | Sorted is explicitly listed in the HIGH risk tier |
| Storeline | 🔴 RED | Storeline is explicitly listed in the HIGH risk tier |
| AIS (Integration Platform) | 🔴 RED | Conditional item - AIS/TIBCO integration that hits a Red system (Sorted, Storeline) |

All systems are RED (HIGH risk). Only Business Critical changes permitted after review by (1) IT Platform Owner and (2) approval by Horizon Platform Owner, Business Process Owner.

## 1.4 Known Issues

1. **Legacy SOAP-to-SOAP path still present in codebase** - The original implementation used a SOAP-to-SOAP call to SAP Commerce Cloud. This was replaced with a REST call in November 2024, but the legacy subprocess remains in the source code. Only the REST path is active.
2. **No explicit retry mechanism** - The integration does not implement retry logic for transient failures when calling the target payment capture API. A failed call results in an immediate error response to the caller. This is appropriate for synchronous payment processing where the caller manages retries.

## 1.5 Glossary

| **Item** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| Braintree | Payment gateway provider used by SAP Commerce Cloud for payment processing |
| BWC | BusinessWorks Container Edition - TIBCO deployment model for this service |
| Campbells Portal | Customer-facing web storefront where Campbells retailers place orders |
| EAII | Enterprise Application Integration Interface - Metcash interface catalogue identifier |
| PE | Platform Engine - order management system that routes orders from the Campbells portal to Storeline |
| SAP Commerce Cloud | E-commerce platform (formerly Hybris) - the technology underpinning Sorted |
| SOAP | Simple Object Access Protocol - XML-based messaging protocol |
| Sorted | SaaS platform running SAP Commerce Cloud that processes payments for the Campbells division (replaced the in-house Hybris system) |
| Storeline | Legacy warehouse and point-of-sale system that initiates payment capture after order pick and pack |

---

# 2 Scope

## 2.1 In Scope

- Payment capture request processing from Storeline to Sorted (SAP Commerce Cloud)
- Protocol translation from SOAP/XML to REST/JSON
- Request field mapping (customer ID, order ID, payment amount)
- Response interpretation and error message formatting
- Synchronous request-reply pattern
- Audit logging (begin, end, warning, error events)
- TLS/SSL secured communication with the target system
- Error handling with structured fault responses

## 2.2 Out of Scope

- Payment authorisation (pre-capture step handled elsewhere)
- Payment refund processing
- Order management or order status updates
- Customer account management
- Batch payment processing
- The legacy SOAP-to-SOAP path (no longer active)

## 2.3 Limitations and Constraints

- The integration operates as a synchronous proxy - the response time is directly dependent on the SAP Commerce Cloud payment capture endpoint's response time
- The source system (Storeline) provides a `requestTimeout` value in the request; the integration does not use this value to control its own timeout behaviour - timeouts are managed at the HTTP client configuration level
- Communication with SAP Commerce Cloud (Sorted) requires mutual TLS authentication via a certificate keystore
- Connection endpoints are environment-specific (SIT, UAT, PROD) and managed through deployment configuration
- This is a Phase 2 Priority 1 interface (BWC - BusinessWorks Container Edition service)

---

# 3 Requirements Overview

## 3.1 EAII-333 - Campbells Payment - Campbells Retailers to Sorted

### 3.1.1 Interface Process

#### 3.1.1.1 Process Diagram

![image-20260615-233229.png](images/04.png)

#### 3.1.1.2 Process Description

The Campbells Payment interface provides a synchronous payment capture service that enables Storeline (the warehouse/POS system) to capture (charge) the actual final payment amount against customer orders via the Sorted platform (SAP Commerce Cloud / Braintree payment gateway).

**Process Flow:**

1. Storeline submits a payment capture request (after completing pick and pack) containing:
  - Customer identifier (for traceability; not forwarded to target)
  - Order identifier
  - Actual final payment amount (post pick-and-pack calculation)
  - Request timeout value (provided by source system)

2. The integration generates a unique transaction identifier for audit traceability and logs the start of processing.
3. The integration maps the request to the Sorted (SAP Commerce Cloud) payment capture API:
  - The order identifier is used as a path parameter in the target URL
  - The payment amount is passed as the capture amount query parameter
  - The customer identifier is NOT forwarded to the target (the order ID is sufficient for Sorted to identify the transaction)
  - The request is sent as an HTTP POST to the target endpoint over HTTPS

4. The target system processes the payment capture with Braintree and returns a JSON response containing:
  - Response code (1 = success, 2 = error with extended code, other = general failure)
  - Extended error code (optional - present when response code indicates an error)
  - Message (optional - descriptive text)

5. The integration evaluates the response:
  - **If response code = 1 (success):** Logs a successful completion event and returns the response to the caller
  - **If response code != 1 (non-success):** Logs a warning event. If response code = 2, formats the message as "Error {extendedErrorCode} - {message}". Returns the response to the caller

6. In all cases, the response (success or failure) is returned synchronously to Storeline.

**Error Handling:**

If an unexpected error occurs at any point during processing (connectivity failure, timeout, malformed response), the integration:

- Logs an error event with full exception details for diagnostic purposes
- Returns a SOAP fault to the calling application containing the error details

#### 3.1.1.3 Known Issues

No known issues requiring specific remediation for this interface.

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3452108805&draftShareId=b6cba10e-05e7-493e-85f1-d1f650c71ff6&atlOrigin=eyJpIjoiZWM4NDlkYzE1MDZjNDc1ZWE0ZDI3MWQ1NTY5YWZkZTIiLCJwIjoiYyJ9](https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3452108805&draftShareId=b6cba10e-05e7-493e-85f1-d1f650c71ff6&atlOrigin=eyJpIjoiZWM4NDlkYzE1MDZjNDc1ZWE0ZDI3MWQ1NTY5YWZkZTIiLCJwIjoiYyJ9) |
| TSD for the interface(s) | [Technical Specification - EAII-333 - Storeline to CCC](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3061514242/Technical+Specification+-+EAII-333+-+Storeline+to+CCC) |
| ADO link for the feature | [Task 263999](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/263999)`: EAII-333 - Campbells Payment - Storeline sending payment request to Sorted for a customer order &#124; Storeline to CCC - Functional Specification` |
| Source file(s) | Source_sample_request1.xml Source_sample_request2.xml Source_sample_request3.xml Source_sample_response1.xml Source_sample_response2.xml Source_sample_response3.xml |
| Target file(s) | Not available |

### 3.1.3 API Endpoint(s) information

**Source (Inbound) - Storeline:**

| Attribute | Value |
| --- | --- |
| Protocol | SOAP over HTTP/HTTPS |
| Endpoint Path | `/PaymentRequestService` |
| Operation | `paymentRequest` |
| WSDL Namespace | `<http://www.campbells.com.au/PaymentRequestService/`> |
| Authentication | None (network-level security assumed) |

**Target (Outbound) - Sorted (SAP Commerce Cloud):**

| Attribute | Value |
| --- | --- |
| Protocol | REST over HTTPS |
| HTTP Method | POST |
| Endpoint Path | `/occ/v2/campbellsretailersspa/orders/{orderId}/braintree/paymentcapture?captureAmount={captureAmount}` |
| Request Body | Empty (parameters passed via URL path and query string) |
| Response Format | JSON |
| Authentication | Mutual TLS (client certificate) |
| Port | 443 |

**Request Parameter Mapping:**

| Source Field | Target Parameter | Parameter Type | Format |
| --- | --- | --- | --- |
| orderId | `{orderId}` | URL Path | 10-digit zero-padded numeric string (e.g., `0040797969`) |
| paymentAmount | `{captureAmount}` | URL Query String | Numeric, may use scientific notation (e.g., `2.9674E4` = $296.74) |

**Response Schema (JSON):**

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| responseCode | integer | Yes | 1 = success, 2 = error with extended code, other = general failure |
| extendedErrorCode | string | No | Present when responseCode indicates an error; "0" on success |
| message | string | No | Descriptive text; "SUCCESFULL" on success (note: misspelling present in actual system); formatted as "Error {code} - {msg}" when responseCode = 2 |

### 3.1.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Gold | This integration processes payment captures for B2B retail orders, directly impacting revenue collection. Payment processing failures prevent order completion and revenue recognition. Availability target: 99.5% (Gold SLA). |

### 3.1.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Internal | The integration handles order identifiers, customer identifiers, and payment amounts. No credit card numbers, CVVs, or sensitive payment instrument details pass through the integration - those are handled directly by the Braintree payment gateway. Data is limited to transaction identifiers and monetary values. | Standard internal data handling. Ensure audit logs do not capture full request/response payloads in production to avoid exposure of customer identifiers at scale. |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume / Average volume | ~200 messages/day average (based on 3,021 messages observed over 15 days). Individual payment captures triggered by customer order completion. |
| Y | Message Size | Average msg size / Max. msg size | Small payloads. Request: ~350 bytes (SOAP XML envelope). Response: ~120 bytes (JSON). See sample payloads in Appendix 4.2. |
| N | Performance Testing | Performance / Load / Stress |  |
| Y | Latency | Any specific latency requirements | Synchronous - end-to-end response time dependent on SAP Commerce Cloud. Target: <5 seconds including network round trip. |
| N | Scalability | Any specific scalability requirements |  |
| Y | Reliability | Reliability / Disaster Recovery | 99.5% availability (Gold SLA). No built-in retry - caller is responsible for retry on failure. |
| Y | Auditability & Observability | Fields to be traced | Transaction ID, Order ID, Customer ID, Response Code. Refer to the Corporate Global Auditability and Observability requirements. |
| Y | Logging | Fields or key message identifiers to be logged | Transaction ID, Service Name, Order ID, Payment Amount, Response Code, Error details (on failure). |
| N | Sequencing or scheduling | Msg/file schedule / Msg/file sequence |  |
| N | Backup & Archiving | Backup / Archiving |  |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Target system connectivity failure | Unable to establish HTTPS connection to SAP Commerce Cloud | Log error event with exception details; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Target system timeout | SAP Commerce Cloud does not respond within configured timeout | Log error event with timeout details; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Target system HTTP 4xx error | Client error response from SAP Commerce Cloud (e.g., invalid order ID) | Log error event; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Target system HTTP 5xx error | Server error response from SAP Commerce Cloud | Log error event; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Payment capture declined | responseCode != 1 returned by target | Log warning event with response details; return response (not fault) to caller with formatted error message | No notification - caller handles business-level failures |
| Unexpected internal error | Any unhandled exception during processing | Log error event with full stack trace; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.1.10 Relevant context considerations

| **Item** | **Status** | **Outcome** | **Outcome Date** |
| --- | --- | --- | --- |
| The source system (Storeline) communicates via SOAP - AIS redesign may offer the source system a REST endpoint as an alternative, reducing protocol translation overhead | Open | Noted - requires confirmation from Storeline team whether they can migrate to REST |  |
| The `requestTimeout` field in the request payload is provided by Storeline but is not used by the integration to dynamically control timeout - timeouts are managed at the HTTP client configuration level | Confirmed | Confirmed by SME - the timeout parameter comes from the source system request | 2026-06-12 |
| The `customerId` field is present in the request but is NOT passed to the target API (only orderId and paymentAmount are used) | Confirmed | Confirmed by SME - the order ID is sufficient for Sorted to identify the transaction; customer ID is included for traceability/logging only | 2026-06-12 |
| Legacy SOAP-to-SOAP subprocess (`InvokeHybrisPaymentRequestService`) remains in codebase but is no longer invoked | Open | Noted - confirmed inactive; the active path uses REST |  |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit valid payment capture request with correct order ID and payment amount | Response code = 1 returned; payment successfully captured | Happy path |
| T2 | Submit payment capture request with invalid/non-existent order ID | Response code != 1 with appropriate error message returned | Verify error message formatting |
| T3 | Submit payment capture request with zero amount | Target system returns error response; formatted error returned to caller | Edge case validation |
| T4 | Submit payment capture when SAP Commerce Cloud is unavailable | SOAP fault returned to caller; error logged with connectivity details | Connectivity failure |
| T5 | Submit payment capture when SAP Commerce Cloud responds slowly (timeout) | SOAP fault returned to caller; timeout error logged | Timeout handling |
| T6 | Submit payment capture that returns responseCode = 2 | Error message formatted as "Error {extendedErrorCode} - {message}" | Error formatting logic |
| T7 | Verify audit logging records transaction ID, order ID, and response code for successful capture | Log entries contain expected fields at begin and end audit steps | Auditability |
| T8 | Verify audit logging captures error details for failed payment capture | Log entry contains error type, exception details, and transaction context | Error auditability |

---

# 4 Appendices & Supporting Information

## 4.1 Supporting Material

### Source Artifacts Inventory

| **Artifact** | **Type** | **Path** | **Description** |
| --- | --- | --- | --- |
| RequestPayment.bwp | BWP (Interface) | `Processes/TibcoPayment/ProxyService/Interface/` | Main entry point - SOAP service receiving payment capture requests from Campbells Retailers |
| InvokeHybrisPaymentService.bwp | BWP (Subprocess) | `Processes/TibcoPayment/ProxyService/Subprocesses/` | Active subprocess - invokes SAP Commerce Cloud payment capture REST API, parses JSON response |
| InvokeHybrisPaymentRequestService.bwp | BWP (Subprocess) | `Processes/TibcoPayment/ProxyService/Subprocesses/` | Legacy subprocess (inactive) - original SOAP-to-SOAP implementation |
| ![diagram](images/08.png) | WSDL | `Service Descriptors/` | Defines the inbound SOAP contract (paymentRequest operation) |
| ![diagram](images/01.png) | XSD | `Schemas/` | Defines the intermediate XML structure whose element names map 1:1 to the JSON keys in the SAP Commerce Cloud payment capture REST API response (EAII-333). Used as output schema for JSON parsing; the XML is never transmitted. |
| ![diagram](images/03.png) | XSD | `Schemas/` | Defines REST API URL parameters (orderId path parameter, captureAmount query parameter) |
| TibcoPaymentProxyServiceHTTPConnector.httpConnResource | HTTP Connector | `Resources/tibcopaymentproxyservice/` | Inbound HTTP listener configuration |
| HttpClientResource.httpClientResource | HTTP Client | `Resources/tibcopaymentproxyservice/` | Outbound REST HTTP client with SSL |
| SSLClientResource.sslClientResource | SSL Config | `Resources/HybrisPaymentRequestService/` | TLS configuration for outbound connection |
| KeystoreProviderResource.keystoreProviderResource | Keystore | `Resources/HybrisPaymentRequestService/` | JKS trust store for mutual TLS |
| default.substvar | Substvar | `META-INF/` | Environment-specific configuration (hosts, ports, error codes) |

### Traceability Mapping

| **Functional Step** | **Tibco Artifact** | **Activity/Element** |
| --- | --- | --- |
| Receive SOAP payment request | RequestPayment.bwp | `paymentRequestIn` (bpws:receive) |
| Generate transaction ID | RequestPayment.bwp | `SetTransactionID` (getSharedVariable from CommonLib) |
| Log start event | RequestPayment.bwp | `LogStart` (CallProcess -> CommonLib.LogEvent) |
| Map request and invoke payment capture API | InvokeHybrisPaymentService.bwp | `InvokeHybrisPaymentAPI` (bpws:invoke, REST POST) |
| Parse JSON response | InvokeHybrisPaymentService.bwp | `ParseResponseJSON` (JsonParser activity) |
| Evaluate response code (success/failure routing) | RequestPayment.bwp | Transition condition: `$InvokeHybrisPaymentRequestService/ns8:responseCode=1` |
| Log end event (success) | RequestPayment.bwp | `LogEnd` (CallProcess -> CommonLib.LogEvent) |
| Log warning event (non-success) | RequestPayment.bwp | `LogEvent` (CallProcess -> CommonLib.LogEvent) |
| Format and return SOAP response | RequestPayment.bwp | `paymentRequestOut` (bpws:reply) |
| Handle unexpected errors | RequestPayment.bwp | `catchAll` fault handler -> `LogError` + `Reply` (UndeclaredFault) |

### Configuration Parameters

| **Parameter** | **Description** | **Default Value** |
| --- | --- | --- |
| /Connections/PaymentProxyService/Host | Inbound listener host | localhost |
| /Connections/PaymentProxyService/Port | Inbound listener port | 7505 |
| /Connections/HybrisPaymentService/Host | Target system host | (environment-specific) |
| /Connections/HybrisPaymentService/Port | Target system port | 443 |
| /Connections/HybrisPaymentService/Keystore | Path to JKS keystore file | (environment-specific) |
| /Connections/HybrisPaymentService/KeystorePassword | Keystore password | (encrypted) |
| /Connections/HybrisPaymentService/Endpoint | Target SOAP endpoint (legacy) | (environment-specific) |
| /TibcoPaymentProxyService/ServiceName | Service name for logging | TibcoPaymentProxyService |
| /TibcoPaymentProxyService/ErrorCode/RespCode-HYBRIS-ERROR | Response code for Hybris errors | 3 |
| /TibcoPaymentProxyService/ErrorCode/HYBRIS-ERROR | Error code identifier | 130 |
| /TibcoPaymentProxyService/ErrorCode/TIBCO-HYBRIS-TIMEOUT | Timeout error code | 111 |
| /TibcoPaymentProxyService/ErrorCode/INTERNAL-ERROR | Internal error code | 111 |
| /TibcoPaymentProxyService/ErrorCode/TIBCO-PAYMENT-TIMEOUT | Payment timeout error code | 111 |

### Drawio Diagrams

| **Diagram** | **File** |
| --- | --- |
| Functional Specification - EAII-333 - Campbells Retailers to Sorted - Legacy High Level Architecture | ![diagram](images/06.png) |
| Functional Specification - EAII-333 - Campbells Retailers to Sorted - Proposed High Level Architecture | ![diagram](images/06.png) |
| EAII-333 - Campbells Payment - Campbells Retailers to Sorted | ![diagram](images/05.png) |

### 4.2 Sample Payloads

Refer to section 3.1.2 for links to source sample files.

**Source Request (SOAP Body):**

```
<paymentRequest xmlns="http://www.campbells.com.au/PaymentRequestService/">
  <customerId xmlns="">0033764325</customerId>
  <orderId xmlns="">0040797969</orderId>
  <paymentAmount xmlns="">2.9674E4</paymentAmount>
  <requestTimeout xmlns="">30000</requestTimeout>
</paymentRequest>
```

**Source Response (returned to Storeline as SOAP Body):**

```
<tns2:paymentResponse xmlns:tns2="/T1650939449914Converted/JsonSchema">
  <tns2:responseCode>1</tns2:responseCode>
  <tns2:extendedErrorCode>0</tns2:extendedErrorCode>
  <tns2:message>SUCCESFULL</tns2:message>
</tns2:paymentResponse>
```

**Observations from Sample Data:**

| Field | Observed Values | Notes |
| --- | --- | --- |
| customerId | `0033764325`, `0034174292`, `0032220303` | 10-digit zero-padded |
| orderId | `0040797969`, `0040796947`, `0040795841` | 10-digit zero-padded |
| paymentAmount | `2.9674E4`, `6.3173E4`, `9.2216E4` | Scientific notation (cents); equivalent to $296.74, $631.73, $922.16 |
| requestTimeout | `30000` | Consistent across all samples (30 seconds) |
| responseCode | `1` | All samples show success |
| message | `SUCCESFULL` | Misspelling present in the actual system (correct spelling: SUCCESSFUL) |

---

# 5 FSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the FSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/09.png)

Click here to expand...

| # | **Checklist Item** |  |
| --- | --- | --- |
|  | **Project Overview** |  |
| 1 | Are the business requirements and objectives of the project defined? | Y |
| 2 | Are the current and future state contexts of the project defined? | Y |
| 3 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 4 | Have any dependencies (technical or otherwise) been defined? | Y |
| 5 | Have any risks (technical or otherwise) and associated mitigation approaches been identified? | Y |
| 6 | Are growth forecasts included in the document? | Y |
|  | **Business Process and Functional Requirements** |  |
| 7 | Has a Business Process Diagram, including the AIS/Orchestration Layer, been included? | Y |
| 8 | Are the functions specific to integrations adequately described? | Y |
| 9 | Have mapping documents for Source and Target systems been captured? | Y |
| 10 | Have lookup logic and handling of failed lookups been defined? | Y |
| 11 | Have the source and target entities been defined? | Y |
| 12 | Have the Source and Target File formats been defined? | Y |
| 13 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 14 | Is the classification of data identified? | Y |
| 15 | Have data handling requirements according to the information classification been defined? | Y |
| 16 | Have the audit requirements for data been defined? | Y |
| 17 | Has each integration been assigned a GSB rating? | Y |
| 18 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 19 | Is logging free of any restricted data fields? | Y |
| 20 | Are any integration component monitoring requirements defined? | Y |
| 21 | Are any specific reporting requirements defined? | Y |
| 22 | Are the batch scheduling requirements defined? | Y |
| 23 | Are the disaster recovery (DR) requirements defined? | Y |
| 24 | Are the storage and data retention requirements defined? | Y |
| 25 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 26 | Are the functional test scenarios defined? | Y |
| 27 | Are the exception test scenarios defined? | Y |
| 28 | Are the performance, load, or stress testing scenarios (if any) defined? | Y |
| 29 | Are the average and peak message/file sizes defined? | Y |
| 30 | Are the average and peak transaction volumes defined? | Y |
| 31 | Are the average and peak transaction frequencies defined? | Y |
| 32 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 33 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 34 | Has a walkthrough of the document been completed? | Y |
|  | **Interface Catalogue** |  |
| 35 | Have all the Metcash columns in the [EAI Interface Catalogue.xlsx](https://metcash.sharepoint.com/:x:/r/sites/AISDevelopmentCentre/Shared%20Documents/General/06.%20EAI%20Interface%20Catalogue/EAI%20Interface%20Catalogue.xlsx?d=wf70ab37d2042493992a3c636da2ab023&csf=1&web=1&e=oZTmqQ) been updated? | Y |
|  | **Approval** |  |
| 36 | Has/have the Interface ID entry/s been added to the EAI Interface Catalogue? | Y |
| 37 | Has the FSD been submitted for reviewed and approval by a Platform Representative? | Y |
| 38 | Has the FSD been submitted for reviewed and approval by a Technical Business Analyst? | Y |
| 39 | Has the FSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 40 | Has the FSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 41 | Has the FSD been submitted for reviewed and approval by a Test Manager? | Y |
