<!-- Source: Functional+Specification+-+EAII-304+-+Liquor+Suppliers+to+EIM.doc -->
<!-- Title: Functional Specification - EAII-304 - Liquor Suppliers to EIM -->

# Functional Specification - EAII-304 - Liquor Suppliers to EIM

**Table of Contents**

- 1 Document Overview
  - 1.1 Business context
  - 1.2 Integration description
  - 1.3 Horizon Impact Assessment
  - 1.4 Known Issues
  - 1.5 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope
  - 2.3 Limitations and Constraints

- 3 Requirements Overview
  - 3.1 EAII-304 - IBA Directs ALM Orders - Liquor Suppliers to EIM
    - 3.1.1 Interface Process
      - 3.1.1.1 Process Diagram
      - 3.1.1.2 Process Description
      - 3.1.1.3 Known Issues

    - 3.1.2 Interface requirements / Mapping details
    - 3.1.3 API Endpoint(s) information
    - 3.1.4 Interface Service Level - Gold/Silver/Bronze
    - 3.1.5 Interface Data Classification
    - 3.1.6 Non-functional requirements
    - 3.1.7 Exception handling
    - 3.1.8 Integration Component Monitoring
    - 3.1.9 Reporting
    - 3.1.10 Relevant context considerations
    - 3.1.11 Test scenarios

- 4 Appendices & Supporting Information
  - 4.1 Supporting Material
    - FSD Artifacts
    - Traceability - EIP Step to Tibco Artifact Mapping
    - Drawio Diagrams

- 5 FSD Approval Checklist

| **Document Approver** | **Approver Role** |
| --- | --- |
| Natalia Kitsa | Platform Representative |
| Vladimir Gurieff | Technical Business Analyst |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Mohanraj Vengiduswamy | Test Manager |

---

# 1 Document Overview

## 1.1 Business context

Independent Brands Australia (IBA), a division of Australian Liquor Marketers (ALM) within Metcash, manages several liquor retail brands including The Bottle-O, Cellarbrations, and Porters. IBA operates a Directs service that enables liquor suppliers - such as CUB and Coopers - to submit direct delivery order data to Metcash. This data captures supplier-to-retailer deliveries that bypass the traditional Metcash warehouse distribution channel.

This FSD documents an existing integration being migrated from TIBCO BusinessWorks to Azure Integration Services (AIS). The purpose is to capture the functional requirements so the integration can be re-implemented on the new platform.

The IBA Directs integration provides a mechanism for liquor suppliers to upload direct delivery transaction data electronically. Each submission contains product details (item codes, descriptions, GTINs, pack sizes), customer/retailer details (account numbers, names, addresses), and invoice details (numbers, dates, quantities in cases and litres, monetary values). The uploaded data is transformed from its source format into a pipe-separated values (PSV) format suitable for ingestion by the Enterprise Information Management (EIM) platform, which handles downstream processing and reporting for the ALM business.

## 1.2 Integration description

The IBA Directs integration receives direct delivery order data from liquor suppliers and delivers it to the EIM platform in the required format. The integration operates as an asynchronous, two-phase pipeline:

1. **Upload phase** - Suppliers submit direct delivery data via a REST API endpoint. The integration authenticates the request, validates the payload, and stores the submitted file in cloud storage. A message is placed on an internal queue to trigger asynchronous processing.
2. **Translation phase** - An asynchronous message listener retrieves the stored file from cloud storage, decompresses it, transforms the data from its source format into pipe-separated values (PSV), and delivers the resulting file (with an accompanying trigger file) to a designated cloud storage output location for pickup by EIM.

The integration uses a shared Storage Service for all cloud storage operations (upload, download, list, copy, move) and a shared Logging and Reconsolidation Service for transaction history and audit logging.

**Legacy High Level Architecture**

![image-20260703-051915.png](images/20.png)

**Proposed High Level Architecture**

![image-20260703-051947.png](images/03.png)

## 1.3 Horizon Impact Assessment

| **System** | **Colour** | **Rationale** |
| --- | --- | --- |
| Liquor Suppliers (external) | 🟢 GREEN | Not listed in Horizon assessment; external third-party systems |
| EIM | 🟢 GREEN | Not listed in RED or AMBER tiers |
| AIS (Integration Platform) | 🟢 GREEN | This integration does not connect to any RED or AMBER system; therefore the AIS/TIBCO conditional item does not apply |
| Storage Service (S3/Azure Blob) | 🟢 GREEN | Cloud storage infrastructure; not listed |

All systems involved in this integration are GREEN (LOW risk to Horizon). Normal approval process applies.

## 1.4 Known Issues

1. **File size validation at API level only** - The maximum upload file size (3 MB) is enforced at the REST API entry point. If a file exceeding this size bypasses the API (e.g., placed directly to cloud storage input), there is no secondary size check during the translation phase.
2. **Single-threaded translation processing** - The translation phase is configured for a single concurrent session (`MaxSessions=1`), which means files are processed sequentially. Under high volume, this could introduce latency.
3. **OAuth2 token management via static file** - API authentication tokens are loaded from a static file in cloud storage at service startup and cached in memory. Token refresh requires a service restart or re-initialisation; there is no dynamic token rotation mechanism.

## 1.5 Glossary

| **Item** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| ALM | Australian Liquor Marketers - Metcash's liquor distribution division |
| EIM | Enterprise Information Management - downstream data processing platform |
| GTIN | Global Trade Item Number - international barcode standard for products |
| IBA | Independent Brands Australia - a division of ALM managing retail brands |
| PSV | Pipe-Separated Values - a flat file format using the pipe character as a delimiter |

---

# 2 Scope

## 2.1 In Scope

- Receipt of direct delivery order data from liquor suppliers via REST API
- Authentication of API requests using bearer tokens
- Validation of incoming payloads (structure and file size)
- Storage of source files to cloud storage with appropriate path structure (input, output, archive, error)
- Asynchronous processing triggered by internal message queue
- Decompression of zipped source files
- Transformation of source data into pipe-separated values (PSV) format for EIM consumption
- Delivery of PSV output files and trigger files to cloud storage output location
- Archival of processed source files
- Error handling with retry logic for transient failures
- Transaction history logging and audit trail
- Cleanup of temporary files after processing

## 2.2 Out of Scope

- Downstream processing of PSV files by EIM
- Supplier onboarding and token provisioning
- File transfer from cloud storage output to EIM staging directory (handled by separate file transfer mechanism)
- Business validation of directs order data content (e.g., valid supplier IDs, valid product codes)

## 2.3 Limitations and Constraints

- Maximum upload file size is 3 MB
- Translation processing is single-threaded; files are processed one at a time
- Authentication tokens are statically provisioned and cached at service startup
- The integration depends on a shared Storage Service for all cloud storage operations
- The integration depends on a shared Logging and Reconsolidation Service for transaction history

---

# 3 Requirements Overview

## 3.1 EAII-304 - IBA Directs ALM Orders - Liquor Suppliers to EIM

### 3.1.1 Interface Process

#### 3.1.1.1 Process Diagram

![image-20260703-052306.png](images/24.png)

#### 3.1.1.2 Process Description

The IBA Directs ALM Orders integration enables liquor suppliers to electronically submit direct delivery transaction data to Metcash for processing by the EIM platform.

**Upload Phase:**

A supplier submits a JSON request to the REST API endpoint containing a document header (transaction ID, document type, timestamp, supplier ID) and the directs file content as a base64-encoded ZIP archive. The integration authenticates the request by validating the bearer token against a set of pre-provisioned API keys. If authentication succeeds, the integration stores the zipped file to the cloud storage input directory and places a message on an internal queue to trigger asynchronous translation. The API returns a synchronous response confirming receipt.

If the uploaded file fails validation (e.g., exceeds maximum size, invalid format), it is stored to the cloud storage error directory and the API returns an appropriate error response. The transaction outcome is recorded in the transaction history.

**Translation Phase:**

An asynchronous message listener picks up the queued message and initiates the translation pipeline:

1. **Retrieve** - Download the source file from the cloud storage input directory
2. **Decompress** - Write the file to a temporary directory and extract the contents from the ZIP archive
3. **Transform** - Parse the extracted data and transform it into pipe-separated values (PSV) format using the EIM data format specification. The PSV output contains 20 fields per record: Supplier ID, Product Code, Product Description, Supplier Product Code, Supplier Product Description, Pack Size, Product Category, GTIN, Licence Number, Customer Number, Customer Name, Address, Suburb, Postcode, State, Invoice Number, Invoice Date, Invoice Cases, Invoice Litres, and Invoice Value.
4. **Deliver** - Upload the PSV file and an accompanying trigger file to the cloud storage output directory for pickup by EIM
5. **Archive** - Move the original source file from the input directory to the archive directory
6. **Cleanup** - Delete temporary files (ZIP, extracted source, PSV) from the local file system

If any step fails, the integration logs the error with the appropriate error code and updates the transaction history. For transient cloud storage communication errors, the integration retries up to the configured maximum retry count before abandoning the message.

#### 3.1.1.3 Known Issues

- **Static token management** - Authentication tokens are loaded from a static file at startup and cached. There is no dynamic refresh. If a token is revoked or expired, the service must be restarted to load updated tokens. This is a redesign candidate for AIS implementation, where a standard OAuth2 client credentials flow or API Management subscription keys could replace the static token mechanism with no impact on supplier systems (the API contract remains the same).

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3503849480&draftShareId=d527b0b5-81af-4e93-ae7f-0664b0596e36&atlOrigin=eyJpIjoiNzE3MGUwNjc3MDAzNDM2YzhkZWFmZGRlM2I1YWQ0NjgiLCJwIjoiYyJ9](https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3503849480&draftShareId=d527b0b5-81af-4e93-ae7f-0664b0596e36&atlOrigin=eyJpIjoiNzE3MGUwNjc3MDAzNDM2YzhkZWFmZGRlM2I1YWQ0NjgiLCJwIjoiYyJ9) |
| TSD for the interface(s) | [Technical Specification - EAII-304 - Liquor Suppliers to EIM](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3502997507/Technical+Specification+-+EAII-304+-+Liquor+Suppliers+to+EIM) |
| ADO link for the feature | [Task 263674](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/263674)`: EAII-304 - IBA Directs ALM Orders &#124; Supplier to EIM - Functional Specification` |
| Source file(s) | ![diagram](images/14.png)![diagram](images/18.png)<br> <br>![diagram](images/09.png)![diagram](images/22.png)<br> <br>![diagram](images/23.png) |
| Target file(s) | ![diagram](images/01.png)![diagram](images/13.png)<br> <br>![diagram](images/17.png)![diagram](images/25.png)<br> <br>![diagram](images/08.png) |

### 3.1.3 API Endpoint(s) information

**Inbound REST API (Supplier Upload):**

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/api/iba/directs/v1/upload` |
| Content-Type | `application/json` |
| Authentication | Bearer token (via `Authorization` HTTP header) |
| Request Body | JSON `DirectsFileDocument` (see schema below) |
| Response Body | JSON `DirectsResponse` with `Code` (integer) and `Description` (string) |

**Request Schema (**`DirectsFileDocument`):

```
{
  "DocumentHeader": {
    "Transaction": {
      "TransactionID": "string (optional)",
      "DocumentType": "string (optional)",
      "TransactionDateTime": "datetime (optional)"
    },
    "Supplier": {
      "SupplierID": "string (required)"
    }
  },
  "DirectsFile": {
    "FileContent": "string (base64-encoded ZIP, required)"
  }
}
```

**Response Schema (**`DirectsResponse`):

```
{
  "Code": 200,
  "Description": "Success"
}
```

**Cloud Storage Paths (Target Delivery):**

| Path | Purpose |
| --- | --- |
| `IBADirects/in` | Input staging - source files stored here on upload |
| `IBADirects/toeim` | Output delivery - PSV and trigger files placed here for EIM pickup |
| `IBADirects/archive` | Archive - processed source files moved here after successful translation |
| `IBADirects/error` | Error - files that fail validation stored here |

**Target File Delivery:**

The PSV output file and an accompanying trigger file are uploaded to the cloud storage output directory (`IBADirects/toeim`). **[Assumption]** GoAnywhere MFT is expected to mediate file delivery between cloud storage and the EIM staging directory (`eim-alm-int-files/IBA_DIRECTS/TIBCO_LANDING`). The exact trigger file naming convention and pickup mechanism require confirmation.

### 3.1.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Silver | The IBA Directs integration supports business operational efficiency for ALM's direct delivery reporting. While it handles supplier transaction data, it does not directly face end customers or generate real-time revenue. Failures would reduce operational visibility into direct deliveries but would not immediately disrupt customer-facing services. Silver tier provides 95% availability, 12x6 support hours, and RTO of 4 hours. |

### 3.1.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Internal | The data contains supplier product details, retailer account numbers, names, addresses, and invoice values. This is internal business transaction data shared between Metcash and its trading partners. It does not contain consumer PII or payment card data. | Standard internal data handling - encrypted in transit (TLS), access restricted to authorised systems and personnel. |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume / Average volume / Seasonal considerations / Expected growth | Approximately 8 files per month across all suppliers (very low volume). Each submission contains a batch of direct delivery records for a single supplier. No significant seasonal variation expected. |
| Y | Message Size | Average msg size / Max. msg size / Expected growth | Maximum file size: 3 MB (configured as `MaxFileByteSize`) - applies to the decoded ZIP payload within the API request, not the unzipped content. Based on sample data: ZIP payloads range from ~20 KB (Coopers) to ~685 KB (CUB); unzipped source data ranges from ~318 KB to ~5.3 MB; target PSV output ranges from ~144 KB to ~2.4 MB. |
| N | Performance Testing | Performance / Load / Stress |  |
| N | Latency | Any specific latency requirements | Asynchronous processing; no real-time latency requirement. The synchronous upload response confirms receipt only. |
| N | Scalability | Any specific scalability requirements | Currently single-threaded (`MaxSessions=1`). May require scaling if submission volumes increase. |
| Y | Reliability | Reliability / Disaster Recovery | Retry on transient cloud storage communication errors up to configured maximum (10 retries). Failed messages remain on the queue for redelivery. 95% availability (Silver SLA). |
| Y | Auditability & Observability | Fields to be traced | Transaction ID, Supplier ID, Document Type, processing timestamps, error codes. Refer to the Corporate Global Auditability and Observability requirements. |
| Y | Logging | Fields or key message identifiers to be logged | Transaction ID, Supplier ID, processing status (start/success/error), error codes (IBADIRECTS-ERR-001 through IBADIRECTS-ERR-004), file names. |
| N | Sequencing or scheduling | Msg/file schedule / Msg/file sequence | Event-driven (on-demand supplier uploads). No scheduled processing. |
| Y | Backup & Archiving | Backup / Archiving | Processed source files are archived to cloud storage archive directory (`IBADirects/archive`). Output PSV files delivered to EIM output directory. |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Authentication failure | Invalid or missing bearer token in API request | Return HTTP 401 Unauthorized response. Log authentication failure. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| File size exceeded | Uploaded file exceeds 3 MB maximum | Return HTTP 400 Bad Request response. Store file to error directory. Log error with code IBADIRECTS-ERR-001. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Decompression failure | ZIP file is corrupted or cannot be extracted | Log error with code IBADIRECTS-ERR-003. Update transaction history with error status. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Transformation failure | Data cannot be parsed or transformed to PSV format | Log error with code IBADIRECTS-ERR-002. Update transaction history with error status. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Cloud storage communication error | Storage Service is unavailable or returns error | Retry up to configured maximum (10 attempts). If retries exhausted, log error with storage-specific code and update transaction history. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Archive failure | Source file cannot be moved to archive directory | Log error with code IBADIRECTS-ERR-004. Update transaction history with error status. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unexpected error | Any unhandled exception during processing | Log full error details. Update transaction history with error status. Message remains on queue for potential redelivery. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.1.10 Relevant context considerations

| **Item** | **Status** | **Outcome** *(Noted/Confirmed/Agreed)* | **Outcome Date** |
| --- | --- | --- | --- |
| Source suppliers will need to change their calling API endpoints and authentication method for UAT and production. | Open | Spoke to Natalia Kitsa and advised that this is coming. Contact Natalia or her manager , Andrew Pearce, if she is not available. | 15/07/2026 |
| GoAnywhere MFT is assumed to mediate file delivery between cloud storage output and EIM staging directory | Open | Noted - to be confirmed |  |
| Trigger file naming convention and content for EIM pickup | Open | Noted - to be confirmed |  |
| Exact PSV file naming convention | Open | Noted - to be confirmed from code analysis or SME |  |
| Static token management to be replaced with standard OAuth2 or APIM subscription keys in AIS | Open | Noted - redesign candidate |  |
| EIM staging directory path: `eim-alm-int-files/IBA_DIRECTS/TIBCO_LANDING` observed in reference diagram | Open | Noted - to be confirmed |  |
| Source data format within ZIP (JSON vs CSV) | Open | Noted - code uses JSON parsing; to be confirmed with sample |  |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit valid directs file with correct bearer token | API returns HTTP 200 with success response. File stored to input directory. Translation triggered. PSV file and trigger file delivered to output directory. Source archived. | Happy path |
| T2 | Submit file with invalid bearer token | API returns HTTP 401 Unauthorized. File is not stored. Error logged. | Authentication test |
| T3 | Submit file exceeding 3 MB size limit | API returns HTTP 400 Bad Request. File stored to error directory. Error code IBADIRECTS-ERR-001 logged. | File size validation |
| T4 | Submit corrupted ZIP file (valid token, valid size) | API returns success (file accepted for processing). During translation, decompression fails. Error code IBADIRECTS-ERR-003 logged. Transaction history updated with error. | Error handling - decompression |
| T5 | Submit file with invalid data format (cannot transform to PSV) | Translation fails. Error code IBADIRECTS-ERR-002 logged. Transaction history updated with error. | Error handling - transformation |
| T6 | Cloud storage service unavailable during translation | Translation retries up to 10 times. If still unavailable, error logged with storage error code. | Retry logic test |
| T7 | Verify PSV output format contains all 20 fields with pipe delimiter | PSV file contains pipe-separated records with fields: SUPPID, PRODCODE, PRODDESC, SUPPPRODCODE, SUPPPRODDESC, PACKSIZE, PRODCATEGORY, GTIN, LICNUMBER, CUSTNUMBER, CUSTNAME, ADDRESS1, SUBURB, POSTCODE, STATE, INVNUMBER, INVDATE, INVCASES, INVLITRES, INVVALUE | Format verification |
| T8 | Verify source file is archived after successful processing | Source file moved from input directory to archive directory. Temporary files cleaned up. | Archive and cleanup |
| T9 | Submit valid file and verify trigger file is created alongside PSV | Both PSV file and trigger file present in output directory | Trigger file generation |
| T10 | Submit request with missing required fields (e.g., no SupplierID) | API returns HTTP 400 Bad Request with validation error | Input validation |

---

# 4 Appendices & Supporting Information

## 4.1 Supporting Material

### FSD Artifacts

| Artifact | Type | Location | Description |
| --- | --- | --- | --- |
| ![diagram](images/21.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines the `DirectsFileDocument` REST API request schema containing DocumentHeader (Transaction, Supplier) and DirectsFile (base64-encoded content) |
| ![diagram](images/12.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines the `DirectsResponse` API response schema with Code (integer) and Description (string) |
| ![diagram](images/11.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines the `DirectsElement` data structure with typed fields for all 20 directs data columns including validation constraints (patterns, lengths, ranges) |
| ![diagram](images/07.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines the intermediate XML structure whose element names become the pipe-delimited column values in the EIM PSV flat file (EAII-304). Each element maps 1:1 to a PSV column. Used as input to the data format rendering activity; the XML is never transmitted. |
| EIMFile.dataFormatResource | DataFormat | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Resources/com/metcash/ibadirects/service/` | Defines pipe-delimited column ordering for PSV output: 20 fields (SUPPID through INVVALUE) with pipe separator and carriage return line separator |
| ![diagram](images/15.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines `DirectsUploadInputType` - wraps the request document with an authentication Token field for internal processing |
| ![diagram](images/10.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines OAuth2 authentication structures: request (AuthenticationKey, TransactionID), response (Success, RespMessage), and token file format (User, AuthenticationKey pairs) |
| ![diagram](images/04.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines `UnzipFileReq` with ZipFilePath and UnzipFileLocation |
| ![diagram](images/02.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines shared types: Token, FileContent, UnzipFileName, and PSVFile (PSVFileName + FileContent) |
| ![diagram](images/19.png) | XSD | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Schemas/` | Defines Storage Service REST API schema types: S3BucketReq, S3ListRequest, S3CopyReq, S3MoveReq, InsertDocument, RestResp, AzureUploadReq, DownloadFile, PushToLocalFile |
| ![diagram](images/16.png) | Swagger | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/Service Descriptors/` | Swagger 2.0 API specification for the IBA Directs Upload REST service |
| UnzipFile.java | Java | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/src/com/metcash/unzip/` | Java utility for ZIP file extraction |
| FileTransferService.java | Java | `tibco/TibcoIBADirectsService/sourcecode/com.metcash.ibadirects.service/src/com/metcash/storageservice/` | Java utility for file download and ZIP extraction |

### Traceability - EIP Step to Tibco Artifact Mapping

| EIP Step | Tibco Artifact | Purpose |
| --- | --- | --- |
| REST API Endpoint | `Processes/com/metcash/ibadirects/service/IBADirectsService.bwp` | REST service entry point - POST /api/iba/directs/v1/upload |
| Upload Orchestrator | `Processes/com/metcash/ibadirects/service/JMSUploadDirectsFile.bwp` | JMS listener on Upload queue - coordinates file validation, S3 storage, and translation trigger |
| API Upload Handler | `Processes/com/metcash/ibadirects/backend/UploadAPI.bwp` | Subprocess handling authentication, validation, and S3 upload |
| Token Authenticator | `Processes/com/metcash/ibadirects/common/OAuth2Athentication.bwp` | OAuth2 token validation against cached keys |
| Module Activator | `Processes/com/metcash/ibadirects/service/Activator.bwp` | Startup process - loads API tokens from S3 into shared variable cache |
| Translation Orchestrator | `Processes/com/metcash/ibadirects/service/JMSTranslateToPSV.bwp` | JMS listener on Translation queue - coordinates S3 download, unzip, translate, upload, archive |
| Storage Service Client | `Processes/com/metcash/ibadirects/backend/S3BucketRequest.bwp` | Shared subprocess for S3 bucket operations (list, download, upload, copy, move) via Storage Service REST API |
| File Decompressor | `Processes/com/metcash/ibadirects/backend/UnzipFile.bwp` | Subprocess wrapping Java ZIP extraction |
| Message Translator | `Processes/com/metcash/ibadirects/backend/XlateToPSV.bwp` | Transforms source data to PSV format using DataFormat resource |
| Shared Resources | `Resources/com/metcash/ibadirects/service/` | HTTP connector, JMS connection, SSL/keystore, EIM DataFormat |
| Shared Logging | `CommonLogging/` module | Transaction history logging and audit via Reconsolidation Service |

### Drawio Diagrams

| **Diagram** | **File** |
| --- | --- |
| Functional Specification - EAII-304 - Liquor Suppliers to EIM - Legacy High Level Architecture | ![diagram](images/06.png) |
| Functional Specification - EAII-304 - Liquor Suppliers to EIM - Proposed High Level Architecture | ![diagram](images/06.png) |
| EAII-304 - IBA Directs ALM Orders - Liquor Suppliers to EIM | ![diagram](images/05.png) |

---

# 5 FSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the FSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/26.png)

Click here to expand...

| # | **Checklist Item** |  |
| --- | --- | --- |
|  | **Project Overview** |  |
| 1 | Are the business requirements and objectives of the project defined? | Y |
| 2 | Are the current and future state contexts of the project defined? | Y |
| 3 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 4 | Have any dependencies (technical or otherwise) been defined? | Y |
| 5 | Have any risks (technical or otherwise) and associated mitigation approaches been identified? | Y |
| 6 | Are growth forecasts included in the document? | Y |
|  | **Business Process and Functional Requirements** |  |
| 7 | Has a Business Process Diagram, including the AIS/Orchestration Layer, been included? | Y |
| 8 | Are the functions specific to integrations adequately described? | Y |
| 9 | Have mapping documents for Source and Target systems been captured? | Y |
| 10 | Have lookup logic and handling of failed lookups been defined? | Y |
| 11 | Have the source and target entities been defined? | Y |
| 12 | Have the Source and Target File formats been defined? | Y |
| 13 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 14 | Is the classification of data identified? | Y |
| 15 | Have data handling requirements according to the information classification been defined? | Y |
| 16 | Have the audit requirements for data been defined? | Y |
| 17 | Has each integration been assigned a GSB rating? | Y |
| 18 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 19 | Is logging free of any restricted data fields? | Y |
| 20 | Are any integration component monitoring requirements defined? | Y |
| 21 | Are any specific reporting requirements defined? | Y |
| 22 | Are the batch scheduling requirements defined? | Y |
| 23 | Are the disaster recovery (DR) requirements defined? | Y |
| 24 | Are the storage and data retention requirements defined? | Y |
| 25 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 26 | Are the functional test scenarios defined? | Y |
| 27 | Are the exception test scenarios defined? | Y |
| 28 | Are the performance, load, or stress testing scenarios (if any) defined? | Y |
| 29 | Are the average and peak message/file sizes defined? | Y |
| 30 | Are the average and peak transaction volumes defined? | Y |
| 31 | Are the average and peak transaction frequencies defined? | Y |
| 32 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 33 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 34 | Has a walkthrough of the document been completed? | Y |
|  | **Interface Catalogue** |  |
| 35 | Have all the Metcash columns in the [EAI Interface Catalogue.xlsx](https://metcash.sharepoint.com/:x:/r/sites/AISDevelopmentCentre/Shared%20Documents/General/06.%20EAI%20Interface%20Catalogue/EAI%20Interface%20Catalogue.xlsx?d=wf70ab37d2042493992a3c636da2ab023&csf=1&web=1&e=oZTmqQ) been updated? | Y |
|  | **Approval** |  |
| 36 | Has/have the Interface ID entry/s been added to the EAI Interface Catalogue? | Y |
| 37 | Has the FSD been submitted for reviewed and approval by a Platform Representative? | Y |
| 38 | Has the FSD been submitted for reviewed and approval by a Technical Business Analyst? | Y |
| 39 | Has the FSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 40 | Has the FSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 41 | Has the FSD been submitted for reviewed and approval by a Test Manager? | Y |
