<!-- Source: Functional+Specification+-+EAII-302+-+Supplier+MDM+to+STIBO.doc -->
<!-- Title: Functional Specification - EAII-302 - Supplier MDM to STIBO -->

# Functional Specification - EAII-302 - Supplier MDM to STIBO

**Table of Contents**

- 1 Document Overview
  - 1.1 Business context
  - 1.2 Integration description
  - 1.3 Horizon Impact Assessment
  - 1.4 Known Issues
  - 1.5 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope
  - 2.3 Limitations and Constraints

- 3 Requirements Overview
  - 3.1 EAII-302 - Supplier Contract - IBM MDM to STIBO STEP PIM
    - 3.1.1 Interface Process
      - 3.1.1.1 Process Diagram
      - 3.1.1.2 Process Description
      - 3.1.1.3 Known Issues

    - 3.1.2 Interface requirements / Mapping details
    - 3.1.3 API Endpoint(s) information
    - 3.1.4 Interface Service Level - Gold/Silver/Bronze
    - 3.1.5 Interface Data Classification
    - 3.1.6 Non-functional requirements
    - 3.1.7 Exception handling
    - 3.1.8 Integration Component Monitoring
    - 3.1.9 Reporting
    - 3.1.10 Relevant context considerations
    - 3.1.11 Test scenarios

- 4 Appendices & Supporting Information
  - 4.1 Supporting Material
    - 4.1.1 Source artifacts (traceability)
    - 4.1.2 EIP-step to source-artifact traceability
    - 4.1.3 Configuration parameters observed in legacy substvar files
    - 4.1.4 Diagrams

- 5 FSD Approval Checklist

| **Document Approver** | **Approver Role** |
| --- | --- |
| Amrik Aujla | Platform Representative |
| Magesh Parthasarathy | Technical Business Analyst |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Mohanraj Vengiduswamy | Test Manager |

# 1 Document Overview

## 1.1 Business context

Metcash operates a Master Data Management (MDM) platform that holds the authoritative view of supplier commercial relationships — the trading agreements, contract terms and related supplier-hierarchy attributes that govern how the business trades with each supplier. When a supplier's contract information is created or amended in MDM, the same information must be reflected in Metcash's Product Information Management (PIM) platform so that product catalogue data curated in PIM can be linked to the correct commercial context.

This Functional Specification documents an existing integration that is currently implemented on TIBCO BusinessWorks and is being migrated to Azure Integration Services (AIS). The purpose of this document is to capture the functional requirements of the interface so it can be re-implemented on the new platform without changing the behaviour observed by MDM or PIM. The migration is intended to be transparent to both systems: MDM continues to publish supplier contract data in the same format, and PIM continues to receive it against the same REST endpoint.

## 1.2 Integration description

The integration receives supplier contract data published by IBM InfoSphere MDM as an XML message and delivers a corresponding STEP-format XML payload to STIBO STEP PIM through a REST API. Each MDM message contains one supplier and its associated contract components; the interface transforms this into a STEP `Classification` hierarchy that PIM stores under the Australian context of the `Main` workspace. Delivery is authenticated using an OAuth 2.0 access token obtained from the PIM authorization server, and PIM signals successful acceptance of the payload with an HTTP 202 response. Where PIM is temporarily unavailable, the integration retries a small number of times with a backoff pause before flagging the message as failed.

**Legacy High Level Architecture**

![image-20260702-235850.png](images/05.png)

**Proposed High Level Architecture**

![image-20260702-235917.png](images/03.png)

## 1.3 Horizon Impact Assessment

| **System** | **Colour** | **Rationale** |
| --- | --- | --- |
| IBM InfoSphere MDM (Master Data Structures) | 🔴 RED | Explicitly listed in the HIGH risk tier as *Master Data Structures* |
| STIBO STEP PIM | 🔴 RED | Explicitly listed in the HIGH risk tier as *PIM (Stibo)* |
| AIS integration layer replacing this interface | 🔴 RED | Conditional item — *AIS or TIBCO/GoAnywhere Integrations that hit any Red system* |

**Impact summary:** Because the interface connects two RED-tier systems (MDM and PIM), any change to this interface is treated as HIGH risk to Horizon. Only Business Critical changes may be deployed, and each change requires (1) review by the IT Platform Owner and (2) approval by the Horizon Platform Owner and the Business Process Owner before it can be scheduled through CAB.

## 1.4 Known Issues

- OAuth access-token acquisition uses the OpenID Connect discovery endpoint on every token-refresh cycle to determine the token endpoint URL — redesign candidate for AIS (see section 3.1.1.3).
- Correlation ID handling accepts a transaction identifier carried on the inbound message and generates a new UUID only if none is provided — no functional issue, but should be preserved to maintain end-to-end traceability with MDM.

## 1.5 Glossary

| **Item** | **Description** |
| --- | --- |
| AIS | Azure Integration Services — Metcash's target integration platform. |
| CAB | Change Advisory Board. |
| CLE | Corporate Logging Event — Metcash's enterprise audit/logging channel. |
| Classification (STEP) | A node in the STEP hierarchy used to represent classification/organisational data such as supplier structures. |
| EAII | Enterprise Application Integration Interface — Metcash's TO-BE interface identifier. |
| MDM | Master Data Management — the IBM InfoSphere MDM platform holding supplier master data. |
| OAuth 2.0 | Authorisation protocol used to obtain a bearer token for PIM API calls (client_credentials grant). |
| PIM | Product Information Management — Metcash's STIBO STEP PIM platform. |
| STEP | STIBO's product/master data model and its XML representation. |
| Supplier Hierarchy | The PIM representation of a supplier and its contract components as a classification tree. |
| TCRMService | The IBM MDM XML element that carries master data payloads. |

---

# 2 Scope

## 2.1 In Scope

- Receipt of supplier contract messages published by IBM MDM in the TCRMService XML format.
- Transformation of each supplier contract into the STEP-ProductInformation XML representation used by STIBO STEP PIM to model the supplier hierarchy.
- Authenticated delivery of the STEP payload to the PIM Supplier Hierarchy REST endpoint using OAuth 2.0 (client_credentials).
- Acknowledgement of the inbound MDM message only after PIM confirms successful acceptance (HTTP 202).
- Retry of the PIM delivery on transient failure, with a bounded number of attempts and a fixed backoff pause.
- Publication of request, response and error events to the Corporate Logging Event channel for audit and traceability.
- Notification of Integration Support when delivery to PIM cannot be completed after the retry budget is exhausted.

## 2.2 Out of Scope

- Any change to the way MDM prepares or publishes supplier contract data. MDM continues to publish messages in the current TCRMService XML format.
- Any change to the PIM Supplier Hierarchy REST endpoint contract, request format or authentication mechanism. PIM continues to accept the same STEP-ProductInformation payload against the same URL path with the same OAuth authorisation model.
- Bulk or batch reconciliation between MDM and PIM (e.g., full daily extracts). This interface handles per-supplier update events only.
- Downstream processing performed by PIM after the payload is accepted (e.g., publication approval workflow).
- The parallel MDM-to-PE integration for the same supplier contract dataset. That interface is handled by a separate Tibco service and is not in scope here.

## 2.3 Limitations and Constraints

- The upstream message channel is asynchronous: MDM does not receive a synchronous acknowledgement from PIM. Delivery outcomes are visible only through audit logs and Integration Support notifications.
- The interface authenticates to PIM as a single service principal. All updates are attributed to that principal in PIM audit logs, so end-user attribution from MDM is not preserved across the boundary.
- The PIM endpoint returns HTTP 202 to signal that the payload has been accepted for processing, not that it has been fully committed. Downstream processing errors inside PIM are not surfaced back to this interface.
- The interface is bound to STIBO STEP's `Australian` context and `Main` workspace. Publishing to any other context/workspace combination is not supported without a configuration change.

---

# 3 Requirements Overview

## 3.1 EAII-302 - Supplier Contract - IBM MDM to STIBO STEP PIM

### 3.1.1 Interface Process

#### 3.1.1.1 Process Diagram

![image-20260703-000007.png](images/01.png)

#### 3.1.1.2 Process Description

The interface is event-driven. When a supplier contract is created or amended in IBM MDM, MDM publishes an XML message to Metcash's message-broker infrastructure. A dedicated inbound channel (Supplier Contract message channel) delivers the message to the integration platform.

On receipt, the integration platform assigns a correlation identifier — reusing any transaction identifier carried on the inbound message so that events can be tied back to the originating MDM change, or generating a new identifier when none is supplied. It then transforms the MDM payload from its native TCRMService representation into the STEP-ProductInformation XML that PIM expects, mapping the supplier and its contract components into a classification hierarchy under the Australian context and Main workspace.

Before calling PIM, the integration platform acquires an OAuth 2.0 access token from the PIM authorization server using the client_credentials grant. Access tokens are held in memory and reused until they are close to expiry, so that a token request is only made when strictly necessary. The STEP payload is then sent to the PIM Supplier Hierarchy REST endpoint by HTTPS POST, carrying the token as a Bearer authorisation header.

PIM signals successful acceptance with an HTTP 202 response. On acceptance, the interface publishes a success event to the Corporate Logging channel and acknowledges the inbound MDM message so it will not be redelivered. If PIM returns any other response or the call fails, the interface retries a bounded number of times with a fixed pause between attempts. If the retry budget is exhausted without acceptance, the interface publishes an error event to the Corporate Logging channel, notifies Integration Support, and returns the source message to the platform's poison-message handling.

Every request, response and error is logged to the Corporate Logging Event channel with the correlation identifier so that operations staff can trace an individual supplier update end-to-end.

#### 3.1.1.3 Known Issues

- **OAuth discovery on every token refresh.** The legacy integration derives the OAuth token endpoint URL by calling the OpenID Connect discovery endpoint (`.well-known/openid-configuration`) each time the cached token is close to expiry, then posts the client credentials to the discovered token endpoint. This adds a network round-trip to every token refresh even though the token endpoint does not change between refreshes.
  - **Legacy mechanism:** Two sequential HTTP calls per token refresh (discovery + token grant), driven by a shared-variable cache with a 60-second expiry buffer.
  - **Alternative approach for AIS:** Configure the token endpoint URL directly, or use the platform's built-in OAuth 2.0 client which handles discovery, caching and refresh natively.
  - **Impact on source/target systems:** None. The change is entirely internal to the integration platform. STIBO STEP continues to expose the same OpenID Connect discovery document; the integration simply chooses to bypass it once the token endpoint is known.

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-302 - Supplier Contract (MDM) to PIM (STIBO)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3495985203/Mapping+-+EAII-302+-+Supplier+Contract+MDM+to+PIM+STIBO) |
| TSD for the interface(s) | [Technical Specification - EAII-302 - Supplier MDM to STIBO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035725825/Technical+Specification+-+EAII-302+-+Supplier+MDM+to+STIBO) |
| ADO link for the feature | [ADO 262920](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/262920) |
| Source file(s) (MDM Request) | ![diagram](images/08.png)<br> <br>![diagram](images/04.png)<br> <br>![diagram](images/02.png) |
| Target file(s) (PIM Transformed Sample) | ![diagram](images/10.png)<br> <br>![diagram](images/12.png)<br> <br>![diagram](images/11.png) |
| PIM Response | ![diagram](images/09.png) |
| JMS Properties | ![diagram](images/14.png) |

### 3.1.3 API Endpoint(s) information

**Target — STIBO STEP PIM Supplier Hierarchy endpoint**

| Attribute | Value |
| --- | --- |
| Protocol | HTTPS |
| HTTP method | `POST` |
| URL path | `/restapi/integrationendpoints/iiep_REST_SupplierHier/upload` |
| Query parameters | `context=Australian`, `workspace=Main` |
| Request content type | `application/xml` |
| Request body | STEP-ProductInformation XML (Classifications hierarchy) |
| Authentication | OAuth 2.0 bearer token in `Authorization` header |
| Success response | HTTP 202 (Accepted for processing) |

**Target — OAuth 2.0 Authorization Server**

| Attribute | Value |
| --- | --- |
| Protocol | HTTPS |
| Discovery endpoint | `/auth/.well-known/openid-configuration` (returns `token_endpoint` URL) |
| Grant type | `client_credentials` |
| Credentials | Service `client_id` and `client_secret` provisioned per environment (stored as secrets) |
| Token type | Bearer |

**Source — inbound message channel**

The source is an asynchronous message channel that delivers TCRMService XML messages published by IBM MDM. The channel provides at-least-once delivery and requires the integration to acknowledge each message only after downstream processing has succeeded. The specific broker/topic/queue names are Metcash infrastructure configuration and are captured in the traceability appendix rather than as part of the external contract.

### 3.1.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Gold | The interface connects two Business-Critical systems (IBM MDM and STIBO STEP PIM, both classified RED under the Horizon Impact Assessment). Supplier contract data is the trading foundation for the product catalogue and must remain synchronised for downstream commercial and merchandising processes to operate correctly. Failure to deliver supplier updates promptly directly impacts the accuracy of the PIM product catalogue and, consequently, revenue-generating operations. A Gold classification aligns the SLA to the criticality of the systems it serves. |

### 3.1.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Internal | Payload contains supplier and contract identifiers, supplier legal-entity and hierarchy attributes. This information is commercially sensitive to Metcash and its suppliers but does not contain personal, financial or regulated data. | Transport data over TLS. Do not log full payloads to non-restricted log stores; log only correlation identifiers and outcomes. Store OAuth client secrets in a managed secret store. |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | To be confirmed by MDM operations team based on the rate of supplier contract changes in production. |
| Y | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Message size varies with the number of contract components per supplier. Typical payloads are within a few tens of kilobytes; exact figures to be confirmed from production samples. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance-test requirement beyond standard AIS platform testing. |
| Y | Latency | Any specific latency requirements | End-to-end latency (MDM publish → PIM 202) should be seconds under normal conditions. No hard real-time requirement — the interface is asynchronous and does not participate in an interactive flow. |
| Y | Scalability | Any specific scalability requirements | The interface must scale horizontally with the source message channel's parallelism to absorb bursts of supplier updates without backlog. |
| Y | Reliability | Reliability<br> Disaster Recovery | 99.9% (Gold SLA). No message loss: the inbound message must not be acknowledged until PIM has accepted the payload. Disaster recovery aligned with the Gold-tier target platform. |
| Y | Auditability & Observability | Fields to be traced | Correlation identifier, supplier identifier and contract identifier(s) must be traceable across the request, response and any error events published to Corporate Logging. Refer to the Corporate Global Auditability and Observability requirements. |
| Y | Logging | Fields or key message identifiers to be logged | Correlation identifier, service name, PIM endpoint, request outcome (HTTP status), retry count, error code and error message. Full request/response payloads are logged only to the audit/error channels, not to general operations logs. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Event-driven; no schedule. Message ordering is not required — each supplier update is self-contained. |
| Y | Backup & Archiving | Backup<br> Archiving | Not applicable at the interface layer — supplier master data is retained in MDM and PIM. Audit events are retained per the Corporate Logging retention policy. |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Connectivity failure to PIM | Network error, DNS resolution failure or TLS handshake failure when calling the PIM endpoint | Retry the call up to a bounded number of attempts with a fixed backoff pause. If still failing, publish an error event to Corporate Logging and route the source message to the platform's poison-message handling. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Connectivity failure to OAuth authorization server | Network error obtaining an access token | Fail the current delivery attempt; the outer retry loop will re-attempt token acquisition on the next iteration. If still failing after retries, treat as a delivery failure (see above). | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| PIM authentication rejected | HTTP 401/403 from PIM or the token endpoint | Publish an error event and route the source message to poison-message handling. Do not silently retry indefinitely — an authentication rejection typically indicates a credential or configuration issue that requires human intervention. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| PIM business rejection | HTTP 4xx (other than 401/403) from the Supplier Hierarchy endpoint indicating the payload is not acceptable | Publish an error event with the response body and route to poison-message handling. Do not retry, as the payload will not become acceptable on re-submission. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| PIM temporarily unavailable | HTTP 5xx from PIM or connection reset | Retry as per the connectivity-failure scenario. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Transformation error | The inbound message does not contain the required fields to construct the STEP payload | Publish an error event with the correlation identifier and route to poison-message handling. Do not retry. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Retry budget exhausted | The bounded retry count for a message is reached without an accepted response | Publish a final error event, route the message to poison-message handling, and notify Integration Support. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.1.10 Relevant context considerations

| **Item** | **Status** | **Outcome** *(Noted/Confirmed/Agreed)* | **Outcome Date** |
| --- | --- | --- | --- |
| Peak/average supplier-update volumes to be confirmed with MDM operations | Open |  |  |
| Confirm whether the AIS implementation should preserve the "reuse cached OAuth token until 60 s before expiry" behaviour or defer to the platform's built-in token cache | Open |  |  |
| Confirm PIM environment endpoints for SIT / UAT / PROD (host names, client IDs) | Open |  |  |
| Verify that all HTTP 4xx responses other than 401/403 should be treated as non-retryable business rejections | Open |  |  |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Happy-path: MDM publishes a well-formed supplier contract message, PIM responds HTTP 202 | Message is transformed to STEP XML, POSTed to PIM, PIM returns 202, inbound message is acknowledged, success event is published to Corporate Logging | Cover both "new supplier" and "amended supplier" MDM payloads |
| T2 | Correlation identifier reuse: inbound message carries a `TRANSACTIONID` property | The value is used as the correlation identifier for all downstream log events; no new UUID is generated | Verify by checking Corporate Logging events for the correlation ID |
| T3 | Correlation identifier fallback: inbound message does not carry a `TRANSACTIONID` property | A new UUID is generated and used for all downstream log events |  |
| T4 | PIM transient failure recovery: PIM returns HTTP 5xx on the first attempt, HTTP 202 on the second | Message is retried after the backoff pause and ultimately accepted; inbound message is acknowledged |  |
| T5 | PIM persistent unavailability: PIM returns HTTP 5xx on every attempt | After the retry budget is exhausted, an error event is published and Integration Support is notified; the inbound message is routed to poison-message handling |  |
| T6 | PIM authentication rejection: PIM returns HTTP 401 | No further retries; error event is published and Integration Support is notified |  |
| T7 | Transformation error: inbound message is missing mandatory fields required to build the STEP payload | Interface publishes an error event and routes the message to poison-message handling without calling PIM |  |
| T8 | Token refresh: cached token is close to expiry | Interface acquires a new token from the authorization server and continues successfully |  |
| T9 | Concurrent supplier updates: multiple supplier contract messages arrive in a short window | All messages are processed independently, each with its own correlation identifier and acknowledgement |  |
| T10 | Known issue T-KI-01 (OAuth discovery bypass, if adopted): AIS uses a directly configured token endpoint without invoking the discovery URL | Token acquisition still succeeds and each supplier update is delivered to PIM | Cover both cold-start and cached-token scenarios |

---

# 4 Appendices & Supporting Information

## 4.1 Supporting Material

### 4.1.1 Source artifacts (traceability)

The FSD is derived from the following TIBCO BusinessWorks artifacts. Names are retained here for audit only — the functional narrative in sections 1–3 does not rely on them.

| Artifact | Type | Location | Purpose in legacy implementation |
| --- | --- | --- | --- |
| `com.metcash.mdmpim.SupplierContractToPIM.bwp` | Process (Message Receiver) | `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Processes/com/metcash/mdmpim/` | Consumes inbound JMS messages from the Supplier Contract queue, assigns the correlation identifier, invokes the transformation/delivery subprocess and confirms the inbound message after success. |
| `com.metcash.mdmpim.TransformSupplierToPIM.bwp` | Sub-process (Mapper + REST) | Same directory | Transforms TCRMService XML into STEP-ProductInformation XML (Classifications hierarchy), retrieves an access token, calls the PIM Supplier Hierarchy REST endpoint and manages retry-on-error. |
| `com.metcash.mdmpim.getOpenidToken.bwp` | Sub-process (OAuth) | Same directory | Retrieves the OpenID Connect discovery document, obtains a `client_credentials` access token and caches it in a shared variable until 60 s before expiry. |
| `Schemas/mdmsupplier/PIM.xsd` | XSD | `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Schemas/mdmsupplier/` | Defines the STEP-ProductInformation XML root and structures used to construct the PIM payload. This is the target request-body schema — although the XSD is only used inside the transformation, its element structure is the contract that PIM's REST endpoint accepts. |
| `Schemas/mdmsupplier/SupplierPEFileSchema.xsd` | XSD | Same directory | Supplier-specific structures referenced by the STEP mapping. |
| `Schemas/PhysicalMDM.xsd`, `MDMPESalesforceSchema.xsd`, `MDMWSDLCommon.xsd` | XSD | `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Schemas/` | Define the IBM MDM `TCRMService` inbound structure and MDM common types. |
| `Schemas/OpenidToken.xsd` | XSD | Same directory | Structure of the OAuth token cache. |
| `Resources/com/metcash/integration/jms/JMSConnectionResource.jmsConnResource` | Shared resource | `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Resources/com/metcash/integration/jms/` | JMS connection to the Metcash EMS broker. |
| `Resources/com/metcash/pim/PIMClientResource.httpClientResource` | Shared resource | `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice/Resources/com/metcash/pim/` | HTTP client for the STIBO STEP PIM host. |
| `Resources/com/metcash/pim/openidConnect.httpClientResource` | Shared resource | Same directory | HTTP client for the OAuth authorization server. |
| `Resources/com/metcash/pim/TLS13SSLClientResource.sslClientResource` | Shared resource | Same directory | TLS 1.3 configuration used by both HTTP clients. |
| `META-INF/*.substvar` (Development, Release, Production, docker_sit/sit2/uat/uat2/prod, container) | Substitution variables | `tibco/TibcoSupplierMDMPIMService/SourceCode/com.metcash.mdmpimservice.application/META-INF/` | Environment-specific values for JMS destination, PIM host/URI, OAuth host/URI, retry count, sleep interval and service name. |
| `CommonLib::com.metcash.horizon.logging.LogEvent` | External library process | Not in this repository | Publishes Corporate Logging Events (request/response/error) with a common envelope. |

### 4.1.2 EIP-step to source-artifact traceability

| Functional step (EIP) | Source artifact | Notes |
| --- | --- | --- |
| Message Receiver | `SupplierContractToPIM.bwp` — `ReceivePIMMsg` activity (`bw.jms.receive`) | Queue name provided at deployment (`DESTINATION` property = `Service.MDM.SupplierContractPIM.Q`). Client-acknowledged; body type is TCRMService XML. |
| Correlation ID assignment | `SupplierContractToPIM.bwp` — `SetSharedVariable` / `Assign` | Uses `TRANSACTIONID` dynamic property if present, otherwise generates a UUID. |
| Message Translator | `TransformSupplierToPIM.bwp` — `MapToPIM` (`bw.generalactivities.mapper`) | Inline XSLT: `TCRMService → STEP-ProductInformation` (Classifications). |
| Access-token acquisition (enricher) | `getOpenidToken.bwp` — `GetCurrentToken` → conditional (`getTokenURL` + `getToken`) → `SetNewToken` | Cached in shared variable `openidToken` with a 60-second pre-expiry refresh trigger. |
| HTTP Request Sender | `TransformSupplierToPIM.bwp` — `InvokePIMService` (`bw.restjson.Rest`, POST XML) | `URI` property = `/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main`. Authorization header composed as `{tokenType} {accessToken}`. |
| Retry loop | `TransformSupplierToPIM.bwp` — `RepeatOnError` scope wrapping `InvokePIMService` + `Sleep` | Exit condition: `index = RetryCount OR statusCode = 202`. Retry count = 3, sleep interval = 30 000 ms. |
| Wait / backoff | `TransformSupplierToPIM.bwp` — `Sleep` (`bw.generalactivities.sleep`) | Interval sourced from `/Resources/Connection/HttpConnections/PIM/SleepInterval`. |
| Error handling | `catchAll` fault handlers in both BWP files → `LogError`, `LogPIMError` → `Throw` | Errors captured with the correlation ID and the PIM error code (`PIMErrorCode` = `SupplierMDMToPIMError`). |
| Cross-cutting audit logging (CLE) | `LogCLERequest`, `LogCLEResponse`, `LogPIMResponse`, `LogError`, `LogPIMError` — all call `CommonLib::com.metcash.horizon.logging.LogEvent` (spawn) | Publishes `LogEventPub` messages to the Corporate Logging channel. |
| Message Confirm | `SupplierContractToPIM.bwp` — `Confirm` (`bw.generalactivities.confirm`) | Acknowledges the JMS message after successful delivery to PIM (or after error handling on failure — inspection of the catchAll shows Confirm on the error path so the message is not redelivered; error notification is emitted instead). |

### 4.1.3 Configuration parameters observed in legacy substvar files

| Parameter | Legacy value (development) | Purpose |
| --- | --- | --- |
| `/Resources/Connection/JMSConnection/InboundJMSConnection/DESTINATION` | `Service.MDM.SupplierContractPIM.Q` | Inbound queue name. |
| `/Resources/Connection/JMSConnection/InboundJMSConnection/MAXSESSIONS` | `3` | Concurrency of the inbound receiver. |
| `/Resources/Connection/HttpConnections/PIM/Host` | `aws-poc9.stibo.com` | STIBO STEP PIM host. |
| `/Resources/Connection/HttpConnections/PIM/Port` | `443` | HTTPS port. |
| `/Resources/Connection/HttpConnections/PIM/URI` | `/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main` | Supplier Hierarchy endpoint. |
| `/Resources/Connection/HttpConnections/PIM/Retry` | `3` | Retry attempts. |
| `/Resources/Connection/HttpConnections/PIM/SleepInterval` | `30000` (ms) | Backoff pause between retries. |
| `/Common/MDMtoPIMServiceName` | `MDMSupplierContractToPIM` | Service name used in Corporate Logging Event payloads. |
| `/ErrorCodes/PIMErrorCode` | `SupplierMDMToPIMError` | Error code prefix used for logged errors. |
| `/OpenId/Host` | `metcash-test.mdm.stibosystems.com` | OAuth authorisation server host. |
| `/OpenId/URI` | `/auth/.well-known/openid-configuration` | OpenID Connect discovery endpoint. |
| `/OpenId/GrantType` | `client_credentials` | OAuth 2.0 grant type. |
| `/OpenId/ClientId`, `/OpenId/ClientSecret` | (secret) | Service credentials for the OAuth grant. |

All secrets in the substvar files are managed as encrypted values in the legacy platform and must be re-provisioned to a managed secret store in AIS.

### 4.1.4 Diagrams

![diagram](images/13.png)

![diagram](images/06.png)

![diagram](images/06.png)

![diagram](images/07.png)

---

# 5 FSD Approval Checklist

> *To approve the document, please leave a comment with the word "Approved" in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the FSD have been answered to the approver's satisfaction where applicable.*
>
> *Click on the arrow (>) below to view the checklist.*
>

| # | **Checklist Item** |  |
| --- | --- | --- |
|  | **Project Overview** |  |
| 1 | Are the business requirements and objectives of the project defined? | Y |
| 2 | Are the current and future state contexts of the project defined? | Y |
| 3 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 4 | Have any dependencies (technical or otherwise) been defined? | Y |
| 5 | Have any risks (technical or otherwise) and associated mitigation approaches been identified? | Y |
| 6 | Are growth forecasts included in the document? | Y |
|  | **Business Process and Functional Requirements** |  |
| 7 | Has a Business Process Diagram, including the AIS/Orchestration Layer, been included? | Y |
| 8 | Are the functions specific to integrations adequately described? | Y |
| 9 | Have mapping documents for Source and Target systems been captured? | Y |
| 10 | Have lookup logic and handling of failed lookups been defined? | Y |
| 11 | Have the source and target entities been defined? | Y |
| 12 | Have the Source and Target File formats been defined? | Y |
| 13 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 14 | Is the classification of data identified? | Y |
| 15 | Have data handling requirements according to the information classification been defined? | Y |
| 16 | Have the audit requirements for data been defined? | Y |
| 17 | Has each integration been assigned a GSB rating? | Y |
| 18 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 19 | Is logging free of any restricted data fields? | Y |
| 20 | Are any integration component monitoring requirements defined? | Y |
| 21 | Are any specific reporting requirements defined? | Y |
| 22 | Are the batch scheduling requirements defined? | Y |
| 23 | Are the disaster recovery (DR) requirements defined? | Y |
| 24 | Are the storage and data retention requirements defined? | Y |
| 25 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 26 | Are the functional test scenarios defined? | Y |
| 27 | Are the exception test scenarios defined? | Y |
| 28 | Are the performance, load, or stress testing scenarios (if any) defined? | Y |
| 29 | Are the average and peak message/file sizes defined? | Y |
| 30 | Are the average and peak transaction volumes defined? | Y |
| 31 | Are the average and peak transaction frequencies defined? | Y |
| 32 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 33 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 34 | Has a walkthrough of the document been completed? | Y |
|  | **Interface Catalogue** |  |
| 35 | Have all the Metcash columns in the [EAI Interface Catalogue.xlsx](https://metcash.sharepoint.com/:x:/r/sites/AISDevelopmentCentre/Shared%20Documents/General/06.%20EAI%20Interface%20Catalogue/EAI%20Interface%20Catalogue.xlsx?d=wf70ab37d2042493992a3c636da2ab023&csf=1&web=1&e=oZTmqQ) been updated? | Y |
|  | **Approval** |  |
| 36 | Has/have the Interface ID entry/s been added to the EAI Interface Catalogue? | Y |
| 37 | Has the FSD been submitted for reviewed and approval by a Platform Representative? | Y |
| 38 | Has the FSD been submitted for reviewed and approval by a Technical Business Analyst? | Y |
| 39 | Has the FSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 40 | Has the FSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 41 | Has the FSD been submitted for reviewed and approval by a Test Manager? | Y |
