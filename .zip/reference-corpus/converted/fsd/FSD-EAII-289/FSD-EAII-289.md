<!-- Source: Functional+Specification+-+EAII-289++-+MDM+Supplier+to+ATO.doc -->
<!-- Title: Functional Specification - EAII-289  - MDM Supplier to ATO -->

# Functional Specification - EAII-289 - MDM Supplier to ATO

**Table of Contents**

- 1 Document Overview
  - 1.1 Business context
  - 1.2 Integration description
  - 1.3 Horizon Impact Assessment
  - 1.4 Known Issues
  - 1.5 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope
  - 2.3 Limitations and Constraints

- 3 Requirements Overview
  - 3.1 EAII-289 - ABN Business Details Lookup v1 - Metcash Internal to ATO
    - 3.1.1 Interface Process
      - 3.1.1.1 Process Diagram
      - 3.1.1.2 Process Description
      - 3.1.1.3 Known Issues

    - 3.1.2 Interface requirements / Mapping details
    - 3.1.3 API Endpoint(s) information
    - 3.1.4 Interface Service Level - Gold/Silver/Bronze
    - 3.1.5 Interface Data Classification
    - 3.1.6 Non-functional requirements
    - 3.1.7 Exception handling
    - 3.1.8 Integration Component Monitoring
    - 3.1.9 Reporting
    - 3.1.10 Relevant context considerations
    - 3.1.11 Test scenarios

  - 3.2 EAII-289 - ACN Business Details Lookup v1 - Metcash Internal to ATO
    - 3.2.1 Interface Process
      - 3.2.1.1 Process Diagram
      - 3.2.1.2 Process Description
      - 3.2.1.3 Known Issues

    - 3.2.2 Interface requirements / Mapping details
    - 3.2.3 API Endpoint(s) information
    - 3.2.4 Interface Service Level - Gold/Silver/Bronze
    - 3.2.5 Interface Data Classification
    - 3.2.6 Non-functional requirements
    - 3.2.7 Exception handling
    - 3.2.8 Integration Component Monitoring
    - 3.2.9 Reporting
    - 3.2.10 Relevant context considerations
    - 3.2.11 Test scenarios

  - 3.3 EAII-289 - ABN Business Details Lookup v2 - Metcash Internal to ATO
    - 3.3.1 Interface Process
      - 3.3.1.1 Process Diagram
      - 3.3.1.2 Process Description
      - 3.3.1.3 Known Issues

    - 3.3.2 Interface requirements / Mapping details
    - 3.3.3 API Endpoint(s) information
    - 3.3.4 Interface Service Level - Gold/Silver/Bronze
    - 3.3.5 Interface Data Classification
    - 3.3.6 Non-functional requirements
    - 3.3.7 Exception handling
    - 3.3.8 Integration Component Monitoring
    - 3.3.9 Reporting
    - 3.3.10 Relevant context considerations
    - 3.3.11 Test scenarios

  - 3.4 EAII-289 - ACN Business Details Lookup v2 - Metcash Internal to ATO
    - 3.4.1 Interface Process
      - 3.4.1.1 Process Diagram
      - 3.4.1.2 Process Description
      - 3.4.1.3 Known Issues

    - 3.4.2 Interface requirements / Mapping details
    - 3.4.3 API Endpoint(s) information
    - 3.4.4 Interface Service Level - Gold/Silver/Bronze
    - 3.4.5 Interface Data Classification
    - 3.4.6 Non-functional requirements
    - 3.4.7 Exception handling
    - 3.4.8 Integration Component Monitoring
    - 3.4.9 Reporting
    - 3.4.10 Relevant context considerations
    - 3.4.11 Test scenarios

- 4 Appendices & Supporting Information
  - 4.1 Supporting Material

- 5 FSD Approval Checklist

| **Document Approver** | **Approver Role** |
| --- | --- |
| Amrik Aujla | Platform Representative |
| Magesh Parthasarathy | Technical Business Analyst |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Mohanraj Vengiduswamy | Test Manager |

---

# 1 Document Overview

## 1.1 Business context

Metcash operates several internal business applications that need to verify the legitimacy and registration status of Australian businesses they trade with - suppliers, retailers, customers and other commercial counterparties. To support this, a centralised lookup capability is provided that allows any authorised Metcash application to query the official Australian Business Register (ABR) using either an Australian Business Number (ABN) or an Australian Company Number (ACN) and receive standardised business details in response.

This capability underpins activities such as new supplier and customer onboarding, master data validation, and operational checks performed by finance, merchandise, and corporate teams. By providing a single common point of access to the Australian Business Register, Metcash ensures every consumer application sees consistent, authoritative business identification data regardless of which system originated the lookup.

This FSD documents the existing integration that delivers this lookup capability. The integration is currently implemented as a legacy TIBCO BusinessWorks service and is being migrated to Azure Integration Services (AIS). The purpose of this document is to capture the functional requirements so the integration can be re-implemented on the new platform without impacting the consumer applications or the target system.

## 1.2 Integration description

The integration exposes a synchronous REST API that acts as a facade between Metcash internal consumer applications and the Australian Business Register (ABR). Four operations are provided, organised as two versions:

1. **ABN Business Details Lookup (v1)** - allows a consumer to retrieve business details for a given Australian Business Number. The response is returned in the ABR's native XML structure (with the namespace rebranded to a Metcash namespace), preserving full ABR fidelity for consumers that need access to the raw record.
2. **ACN Business Details Lookup (v1)** - same as the ABN v1 operation but keyed by Australian Company Number. Returned in the same ABR-native XML structure.
3. **ABN Business Details Lookup (v2)** - allows a consumer to retrieve business details for a given ABN and receive the result in a canonical Metcash business object format (`MetcashIdentifierBObj`). This format is designed for consumers that want a simplified, normalized representation rather than the raw ABR record.
4. **ACN Business Details Lookup (v2)** - same as the ABN v2 operation but keyed by ACN, returning the canonical Metcash format.

All four operations look up data from the same external source - the Australian Business Register. The v1 operations call the ABR's SOAP service directly, while the v2 operations call an ABR REST/JSON endpoint and then transform the response into the canonical Metcash business object format. Every request and response is audit-logged through Metcash's CommonLogging Event (CLE) framework so that lookup activity can be traced for compliance and troubleshooting purposes.

**Legacy High Level Architecture**

![image-20260624-055636.png](images/05.png)

**Proposed High Level Architecture**

![image-20260624-055649.png](images/01.png)

## 1.3 Horizon Impact Assessment

| **System** | **Colour** | **Rationale** |
| --- | --- | --- |
| Australian Business Register (ABR) | 🟢 GREEN | External Australian Government service, not listed in the HIGH or MEDIUM risk tiers on the Horizon Operations Freeze register |
| Metcash Internal Consumer Applications | 🟢 GREEN | Internal applications not listed in the HIGH or MEDIUM risk tiers |
| Integration Platform (legacy TIBCO / AIS) | 🟢 GREEN | Integration platform, not explicitly listed in the HIGH or MEDIUM risk tiers |
| CommonLogging (CLE) | 🟢 GREEN | Internal audit logging utility, not listed in the HIGH or MEDIUM risk tiers |

All systems involved in this integration fall under the LOW risk category. None of the source or target systems are listed in the HIGH or MEDIUM risk tiers on the Horizon Impact Assessment. Normal approval processes apply.

## 1.4 Known Issues

1. **Misleading configuration variable naming on the v2 outbound HTTP client** - The legacy v2 implementation uses an HTTP client resource whose configuration is bound to substitution variables prefixed `/Resources/Inbound/HOST` and `/Resources/Inbound/PORT`, despite being used for the outbound call from the integration to the ABR REST endpoint. This is confusing and risks misconfiguration during environment promotion. The variable naming should be corrected during the AIS rebuild to clearly distinguish inbound listener configuration from outbound destination configuration.
2. **Static authentication credential for the ABR SOAP service (v1)** - The v1 SOAP calls to ABR use a hardcoded authentication GUID stored in a deployment substitution variable. This credential is currently in plain text within the deployed configuration. During the AIS rebuild this credential should be moved into a managed secret store (e.g., Azure Key Vault) and accessed via managed identity.
3. **Duplicated surface area between v1 and v2** - Both the v1 (ABR-native XML) and v2 (Metcash canonical) operations exist in parallel and are functionally overlapping - they look up the same underlying ABR data and differ only in response shape. If no consumer application still depends on the raw ABR XML format, the v1 surface could be retired during or shortly after the AIS migration to simplify the long-term support footprint. This should be validated with consumer owners as part of the migration.

## 1.5 Glossary

| **Item** | **Description** |
| --- | --- |
| ABN | Australian Business Number - the 11-digit unique identifier assigned to every entity registered in the Australian Business Register |
| ABR | Australian Business Register - the official register of all businesses and other entities operating in Australia, operated by the Australian Taxation Office |
| ACN | Australian Company Number - the 9-digit unique identifier assigned by ASIC to every Australian company |
| AIS | Azure Integration Services - the target integration platform |
| ASIC | Australian Securities and Investments Commission - the regulator that issues ACNs |
| ATO | Australian Taxation Office - operator of the Australian Business Register |
| CLE | Common Logging Event - Metcash's centralised audit logging framework |
| MetcashIdentifierBObj | The canonical Metcash business object used by the v2 operations to return business identification data in a simplified, normalised format |
| TBN | Trading Business Number - the qualifier used in the v1 ACN URL path (`/gettbn/v1?acn=...`); functionally an ACN lookup |
| Transaction ID | A correlation identifier generated for every lookup request and propagated through audit log events |

---

# 2 Scope

## 2.1 In Scope

- **EAII-289** - Business Details Lookup service providing four operations against the Australian Business Register:
  - ABN Business Details Lookup (v1) - returns ABR-native XML with namespace rebranded to a Metcash namespace
  - ACN Business Details Lookup (v1) - returns ABR-native XML with namespace rebranded to a Metcash namespace
  - ABN Business Details Lookup (v2) - returns the canonical `MetcashIdentifierBObj` XML format
  - ACN Business Details Lookup (v2) - returns the canonical `MetcashIdentifierBObj` XML format

- Outbound connectivity to the Australian Business Register (SOAP for v1, REST/JSON for v2)
- Request/response correlation using a per-request Transaction ID
- Audit logging of begin, end and error events for every lookup through the CommonLogging Event (CLE) framework
- Error handling for ABR connectivity failures, invalid input parameters and unexpected responses

## 2.2 Out of Scope

- Caching of ABR responses (every lookup goes through to ABR)
- Changes to consumer application logic
- Changes to the upstream Australian Business Register service contract
- Bulk or batch lookup capability (the service is per-request only)
- Retirement decisions for the v1 operations - that decision is captured as a known issue for separate consideration during migration
- Replacement of the static ABR authentication GUID with a managed secret - flagged as a known issue but the remediation itself is delivered as part of the AIS build, not as a separate integration feature

## 2.3 Limitations and Constraints

- Consumer applications must continue to use the same request/response contract (URL path, query parameters, response schema) so no consumer code changes are required during the AIS migration.
- The Australian Business Register service is externally managed by the ATO. Its availability, throughput and contract changes are outside Metcash's control.
- The v1 operations depend on the ABR SOAP service; the v2 operations depend on an ABR REST/JSON endpoint. Both endpoint contracts must be preserved by the migration.
- Outbound calls to the ABR are environment-specific (host, port and trust store configuration vary per environment).
- The audit logging endpoint (CLE) is environment-specific and must be available for all lookup activity to be traceable.

---

# 3 Requirements Overview

## 3.1 EAII-289 - ABN Business Details Lookup v1 - Metcash Internal to ATO

### 3.1.1 Interface Process

#### 3.1.1.1 Process Diagram

![image-20260624-055756.png](images/04.png)

#### 3.1.1.2 Process Description

A consumer application issues an HTTPs GET to the integration with the Australian Business Number it wants to look up provided as a query parameter. On receipt of the request:

1. The integration
  1. extracts the ABN value from the query parameter.
  2. constructs a Business Register search request using the ABN, a pre-configured authentication credential, and a flag indicating whether historical details should be included (currently set to `N`).
  3. calls the Australian Business Register and waits for a response.
  4. If the Register responds successfully, the response is reformatted so it presents as a Metcash-namespaced response rather than an ABR-namespaced one, then returned to the consumer with HTTP 200.
  5. If the Register returns an error or the call fails, an audit "error" event is published, an error response is returned to the consumer, and the lookup ends.
  6. returns the response to the consumer.

#### 3.1.1.3 Known Issues

The static ABR authentication credential (see Section 1.4 Known Issue 2) applies to this interface. No ServiceNow incidents have been recorded specifically against this v1 ABN operation; behaviour has been stable in production.

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-289 - ABN Business Details Lookup v1 - Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3476390056/Mapping+-+EAII-289+-+ABN+Business+Details+Lookup+v1+-+Metcash+Internal+to+ATO)<br>[Mapping - EAII-289 - ABN Business Details Lookup v2 - Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3487301968/Mapping+-+EAII-289+-+ABN+Business+Details+Lookup+v2+-+Metcash+Internal+to+ATO)<br>[Mapping - EAII-289 - ACN Business Details Lookup v1 - Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3487301984/Mapping+-+EAII-289+-+ACN+Business+Details+Lookup+v1+-+Metcash+Internal+to+ATO)<br>[Mapping - EAII-289 - ACN Business Details Lookup v2 - Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3487531010/Mapping+-+EAII-289+-+ACN+Business+Details+Lookup+v2+-+Metcash+Internal+to+ATO) |
| TSD for the interface(s) | [TSD EAII-289 Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3041787905/Technical+Specification+-+EAII-289+-+MDM+to+ATO) |
| ADO link for the feature | [ADO 262907](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/262907) |
| Source file(s) |  |
| Target file(s) |  |

### 3.1.3 API Endpoint(s) information

| **Item** | **Value** |
| --- | --- |
| Consumer-facing URL path | `GET /fetchDetailsREST/apn/getabn/v1?abn={abn}` |
| Consumer-facing transport | HTTP, synchronous request/response |
| Consumer-facing response format | XML (ABR-native structure under a Metcash namespace) |
| Target system URL | `http://abr.business.gov.au:80/abrxmlsearch/AbrXmlSearch.asmx` |
| Target system protocol | SOAP 1.2 |
| Target system operation | `SearchByABNv201408` |
| Target system authentication | `authenticationGuid` provided in the SOAP request body, value held in a deployment configuration variable |

### 3.1.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Silver | The service is used by business-operational applications during onboarding and master data validation activities. Lookup failures cause user-facing delays but do not stop business-critical revenue-generating systems. A 95% availability target with normal business-hours support is appropriate. |

### 3.1.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Public | The data returned by the ABR is publicly available through the official Australian Business Register public search. ABN and ACN identifiers and the associated business name, status and address details are not classified as confidential. | Standard logging and retention apply. No additional masking or encryption requirements above the platform defaults. |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| N | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | Volumes are low (driven by ad-hoc lookups). No specific peak/average volume targets defined. |
| N | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Single record lookup; response is a small XML document (a few KB). No specific size requirements. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance test requirements beyond confirming response within the latency target. |
| Y | Latency | Any specific latency requirements | End-to-end response time SHOULD be under 5 seconds for 95% of requests; dominated by ABR response time. |
| Y | Scalability | Any specific scalability requirements | Must scale to support concurrent ad-hoc lookups from all authorised internal consumer applications. |
| Y | Reliability | Reliability<br> Disaster Recovery | 95% availability target during business hours (Silver). DR per AIS platform standards. |
| Y | Auditability & Observability | Fields to be traced | Per Corporate Global Auditability and Observability requirements: TransactionID, request endpoint, ABN value, target endpoint, response status. |
| Y | Logging | Fields or key message identifiers to be logged | TransactionID, target service (`ATOService-getBusinessDetails`), begin/end/error event types, status code. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Synchronous on-demand lookup. No scheduling or sequencing requirements. |
| N | Backup & Archiving | Backup<br> Archiving | No persistent storage. No backup/archive requirements beyond audit log retention which is managed by the CLE platform. |
| N | Other / Misc. |  | None identified. |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ABR connectivity failure | Network error or timeout calling the ABR SOAP endpoint | Log error event with TransactionID; return HTTP fault to the consumer | Standard AIS platform alerting; no per-event notification required |
| ABR business fault | ABR returns a SOAP fault (e.g., invalid ABN, authentication failure) | Log error event with TransactionID and fault detail; return HTTP fault with the fault reason to the consumer | Standard AIS platform alerting |
| Invalid input parameter | ABN query parameter missing, empty, or not a valid 11-digit number | Log error event with TransactionID; return HTTP 400 to the consumer with a description of the validation failure | None - consumer-side error |
| Audit logging failure | CLE endpoint unavailable when publishing begin/end/error event | Continue processing the lookup; raise platform alert | Standard AIS platform alerting |
| Unexpected exception | Any other unhandled error during processing | Top-level catch-all logs the error with TransactionID and returns a generic HTTP 500 fault to the consumer | Standard AIS platform alerting |

### 3.1.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.1.10 Relevant context considerations

| **Item** | **Status** | **Outcome** *(Noted/Confirmed/Agreed)* | **Outcome Date** |
| --- | --- | --- | --- |
| Consumer applications consuming the v1 ABN response (raw ABR XML) need to be identified before any decision is made on retiring v1 post-migration | Open | Noted |  |
| Static ABR authentication GUID to be moved into a managed secret (Azure Key Vault) during AIS rebuild | Open | Noted |  |
| Existing TIBCO process `Processes/com/metcash/atobusinessdetails/fetchDetailsREST.bwp` (branch `getabn`) is the source of truth for behavior | Confirmed | Confirmed |  |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Successful ABN lookup for a valid, currently-registered Australian business | HTTP 200 with the ABR business details returned under the Metcash namespace; TransactionID recorded in audit logs (begin + end events) | Happy path |
| T2 | Lookup for an ABN that exists in the Register but is cancelled or no longer trading | HTTP 200 with the ABR response indicating the entity's current status; lookup is still logged as a success |  |
| T3 | Lookup for a non-existent ABN | HTTP 200 with the ABR's standard "not found" response payload | ABR returns a valid response indicating no record; not treated as an error |
| T4 | Lookup with missing or empty ABN query parameter | HTTP 400 returned to consumer with a validation error description; error event logged | Input validation |
| T5 | ABR service unavailable (simulated network failure) | HTTP fault returned to consumer; error event logged with TransactionID | Connectivity failure |
| T6 | ABR returns a SOAP fault (e.g., bad authentication GUID) | HTTP fault returned to consumer with fault reason; error event logged | Backend failure |

---

## 3.2 EAII-289 - ACN Business Details Lookup v1 - Metcash Internal to ATO

### 3.2.1 Interface Process

#### 3.2.1.1 Process Diagram

![image-20260624-055846.png](images/10.png)

#### 3.2.1.2 Process Description

A consumer application issues an HTTP GET to the integration with the Australian Company Number it wants to look up provided as a query parameter. On receipt of the request:

1. The integration
  1. extracts the ACN value from the query parameter.
  2. constructs an ASIC search request using the ACN, a pre-configured authentication credential, and a flag indicating whether historical details should be included (currently set to `N`).
  3. calls the Australian Business Register and waits for a response.
  4. If the Register responds successfully, the response is reformatted so it presents as a Metcash-namespaced response rather than an ABR-namespaced one, then returned to the consumer with HTTP 200.
  5. If the Register returns an error or the call fails, an audit "error" event is published, an error response is returned to the consumer, and the lookup ends.
  6. integration returns the response to the consumer.

#### 3.2.1.3 Known Issues

The static ABR authentication credential (see Section 1.4 Known Issue 2) applies to this interface. The consumer-facing URL path uses the qualifier `gettbn` (Trading Business Number) rather than `getacn`; functionally this is an ACN lookup. The naming inconsistency is historical and should be reviewed for renaming during the AIS rebuild, with the existing path preserved or aliased if any consumer is still using it.

### 3.2.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping Manifest - EAII-289 - Metcash Internal to ATO](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/fsd/TibcoATOBusinessDetails/Mapping%20Manifest%20-%20EAII-289%20-%20Metcash%20Internal%20to%20ATO.md) |
| TSD for the interface(s) | *To be created in tsd/EAII-289/* |
| ADO link for the feature | *To be added by the delivery team* |
| Source file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v1/source_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ACN%20Business%20Details%20Lookup%20v1/source_samples/) *(no samples provided - to be auto-generated)* |
| Target file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v1/target_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ACN%20Business%20Details%20Lookup%20v1/target_samples/) *(no samples provided - to be auto-generated)* |

### 3.2.3 API Endpoint(s) information

| **Item** | **Value** |
| --- | --- |
| Consumer-facing URL path | `GET /fetchDetailsREST/apn/gettbn/v1?acn={acn}` |
| Consumer-facing transport | HTTP, synchronous request/response |
| Consumer-facing response format | XML (ABR-native structure under a Metcash namespace) |
| Target system URL | `http://abr.business.gov.au:80/abrxmlsearch/AbrXmlSearch.asmx` |
| Target system protocol | SOAP 1.2 |
| Target system operation | `SearchByASICv201408` |
| Target system authentication | `authenticationGuid` provided in the SOAP request body, value held in a deployment configuration variable |

### 3.2.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Silver | Same rationale as Section 3.1.4 - business-operational usage with a 95% availability target. |

### 3.2.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Public | ACN and the associated company name, status and address details are publicly available through the official Australian Business Register and ASIC public search. | Standard logging and retention apply. No additional masking or encryption requirements above the platform defaults. |

### 3.2.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| N | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | Volumes are low (driven by ad-hoc lookups). No specific peak/average volume targets defined. |
| N | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Single record lookup; response is a small XML document (a few KB). No specific size requirements. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance test requirements beyond confirming response within the latency target. |
| Y | Latency | Any specific latency requirements | End-to-end response time SHOULD be under 5 seconds for 95% of requests; dominated by ABR response time. |
| Y | Scalability | Any specific scalability requirements | Must scale to support concurrent ad-hoc lookups from all authorised internal consumer applications. |
| Y | Reliability | Reliability<br> Disaster Recovery | 95% availability target during business hours (Silver). DR per AIS platform standards. |
| Y | Auditability & Observability | Fields to be traced | Per Corporate Global Auditability and Observability requirements: TransactionID, request endpoint, ACN value, target endpoint, response status. |
| Y | Logging | Fields or key message identifiers to be logged | TransactionID, target service (`ATOService-getBusinessDetails`), begin/end/error event types, status code. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Synchronous on-demand lookup. No scheduling or sequencing requirements. |
| N | Backup & Archiving | Backup<br> Archiving | No persistent storage. No backup/archive requirements beyond audit log retention which is managed by the CLE platform. |
| N | Other / Misc. |  | None identified. |

### 3.2.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ABR connectivity failure | Network error or timeout calling the ABR SOAP endpoint | Log error event with TransactionID; return HTTP fault to the consumer | Standard AIS platform alerting; no per-event notification required |
| ABR business fault | ABR returns a SOAP fault (e.g., invalid ACN, authentication failure) | Log error event with TransactionID and fault detail; return HTTP fault with the fault reason to the consumer | Standard AIS platform alerting |
| Invalid input parameter | ACN query parameter missing, empty, or not a valid 9-digit number | Log error event with TransactionID; return HTTP 400 to the consumer with a description of the validation failure | None - consumer-side error |
| Audit logging failure | CLE endpoint unavailable when publishing begin/end/error event | Continue processing the lookup; raise platform alert | Standard AIS platform alerting |
| Unexpected exception | Any other unhandled error during processing | Top-level catch-all logs the error with TransactionID and returns a generic HTTP 500 fault to the consumer | Standard AIS platform alerting |

### 3.2.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.2.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.2.10 Relevant context considerations

| **Item** | **Status** | **Outcome** *(Noted/Confirmed/Agreed)* | **Outcome Date** |
| --- | --- | --- | --- |
| Naming inconsistency `gettbn` for ACN lookups - confirm whether path should be renamed to `getacn` during AIS rebuild | Open | Noted |  |
| Consumer applications using the v1 ACN response need to be identified before any decision is made on retiring v1 post-migration | Open | Noted |  |
| Existing TIBCO process `Processes/com/metcash/atobusinessdetails/fetchDetailsREST.bwp` (branch `getacn`) is the source of truth for behaviour | Confirmed | Confirmed |  |

### 3.2.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Successful ACN lookup for a valid, currently-registered Australian company | HTTP 200 with the ABR business details returned under the Metcash namespace; TransactionID recorded in audit logs (begin + end events) | Happy path |
| T2 | Lookup for an ACN that exists but the company is deregistered | HTTP 200 with the ABR response indicating the entity's current status; lookup is still logged as a success |  |
| T3 | Lookup for a non-existent ACN | HTTP 200 with the ABR's standard "not found" response payload | ABR returns a valid response indicating no record; not treated as an error |
| T4 | Lookup with missing or empty ACN query parameter | HTTP 400 returned to consumer with a validation error description; error event logged | Input validation |
| T5 | ABR service unavailable (simulated network failure) | HTTP fault returned to consumer; error event logged with TransactionID | Connectivity failure |
| T6 | ABR returns a SOAP fault (e.g., bad authentication GUID) | HTTP fault returned to consumer with fault reason; error event logged | Backend failure |

---

## 3.3 EAII-289 - ABN Business Details Lookup v2 - Metcash Internal to ATO

### 3.3.1 Interface Process

#### 3.3.1.1 Process Diagram

![image-20260624-060052.png](images/12.png)

#### 3.3.1.2 Process Description

A consumer application issues an HTTP GET to the integration with the Australian Business Number it wants to look up provided as a query parameter. The v2 operation returns the result in a canonical Metcash business object format. On receipt of the request:

1. The integration
  1. extracts the ABN value from the query parameter.
  2. calls the Australian Business Register's REST endpoint, passing the ABN as a query parameter, and waits for a JSON response.
  3. If the Register responds successfully, the JSON payload is parsed into structured data, then mapped into the canonical Metcash business object (`MetcashIdentifierBObj`). The canonical object exposes the entity description and identifier sub-type plus a party identification block that carries the ABN identifier description and current registration status.
  4. The canonical response is returned to the consumer with HTTP 200.
  5. If the Register returns an error or the call fails, an error response is returned to the consumer, and the lookup ends.
  6. returns the response to the consumer.

#### 3.3.1.3 Known Issues

The misleading configuration variable naming on the outbound HTTP client (see Section 1.4 Known Issue 1) applies to this interface. No ServiceNow incidents have been recorded specifically against this v2 ABN operation.

### 3.3.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping Manifest - EAII-289 - Metcash Internal to ATO](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/fsd/TibcoATOBusinessDetails/Mapping%20Manifest%20-%20EAII-289%20-%20Metcash%20Internal%20to%20ATO.md) |
| TSD for the interface(s) | *To be created in tsd/EAII-289/* |
| ADO link for the feature | *To be added by the delivery team* |
| Source file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ABN Business Details Lookup v2/source_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ABN%20Business%20Details%20Lookup%20v2/source_samples/) *(no samples provided - to be auto-generated)* |
| Target file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ABN Business Details Lookup v2/target_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ABN%20Business%20Details%20Lookup%20v2/target_samples/) *(no samples provided - to be auto-generated)* |

### 3.3.3 API Endpoint(s) information

| **Item** | **Value** |
| --- | --- |
| Consumer-facing URL path | `GET /fetchDetailsResource/api/ato/getabn/v2?abn={abn}` |
| Consumer-facing transport | HTTP, synchronous request/response |
| Consumer-facing response format | XML - canonical `MetcashIdentifierBObj` |
| Target system URL path | `GET /api/ato/getabn/v1?abn={abn}` on the configured ABR REST host |
| Target system protocol | REST (HTTP) returning JSON |
| Target system authentication | Per environment configuration (no per-request credential in the request body for v2) |

### 3.3.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Silver | Same rationale as Section 3.1.4 - business-operational usage with a 95% availability target. |

### 3.3.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Public | ABN, entity description and registration status are publicly available through the official Australian Business Register. | Standard logging and retention apply. No additional masking or encryption requirements above the platform defaults. |

### 3.3.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| N | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | Volumes are low (driven by ad-hoc lookups). No specific peak/average volume targets defined. |
| N | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Single record lookup; canonical response is a small XML document (under 5 KB). No specific size requirements. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance test requirements beyond confirming response within the latency target. |
| Y | Latency | Any specific latency requirements | End-to-end response time SHOULD be under 5 seconds for 95% of requests; dominated by ABR response time. |
| Y | Scalability | Any specific scalability requirements | Must scale to support concurrent ad-hoc lookups from all authorised internal consumer applications. |
| Y | Reliability | Reliability<br> Disaster Recovery | 95% availability target during business hours (Silver). DR per AIS platform standards. |
| Y | Auditability & Observability | Fields to be traced | Per Corporate Global Auditability and Observability requirements: TransactionID, request endpoint, ABN value, target endpoint, response status. |
| Y | Logging | Fields or key message identifiers to be logged | TransactionID, target service (`ATOService-getABNv2`), begin/end/error event types, status code. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Synchronous on-demand lookup. No scheduling or sequencing requirements. |
| N | Backup & Archiving | Backup<br> Archiving | No persistent storage. No backup/archive requirements beyond audit log retention which is managed by the CLE platform. |
| N | Other / Misc. |  | None identified. |

### 3.3.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ABR connectivity failure | Network error or timeout calling the ABR REST endpoint | Log error event with TransactionID; return HTTP fault to the consumer | Standard AIS platform alerting |
| ABR HTTP error response | ABR returns 4xx/5xx | Log error event with TransactionID, status code and any payload returned; return HTTP fault to the consumer | Standard AIS platform alerting |
| JSON parse failure | The ABR response cannot be parsed into the expected structure | Log error event with TransactionID and the raw payload; return HTTP fault to the consumer | Standard AIS platform alerting |
| Invalid input parameter | ABN query parameter missing, empty, or not a valid 11-digit number | Log error event with TransactionID; return HTTP 400 to the consumer with a description of the validation failure | None - consumer-side error |
| Audit logging failure | CLE endpoint unavailable when publishing begin/end/error event | Continue processing the lookup; raise platform alert | Standard AIS platform alerting |
| Unexpected exception | Any other unhandled error during processing | Top-level catch-all logs the error with TransactionID and returns a generic HTTP 500 fault to the consumer | Standard AIS platform alerting |

### 3.3.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.3.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.3.10 Relevant context considerations

| **Item** | **Status** | **Outcome** *(Noted/Confirmed/Agreed)* | **Outcome Date** |
| --- | --- | --- | --- |
| Confirm the canonical response shape (`MetcashIdentifierBObj`) is the contract consumers depend on - no consumer changes required during AIS migration | Open | Noted |  |
| Configuration variable naming on the outbound HTTP client to be corrected during AIS rebuild | Open | Noted |  |
| Existing TIBCO process `Processes/com/metcash/atobusinessdetails/v2/fetchATODetails.bwp` (branch `getabn`) is the source of truth for behaviour | Confirmed | Confirmed |  |

### 3.3.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Successful ABN lookup for a valid, currently-registered Australian business | HTTP 200 with `MetcashIdentifierBObj` populated with the entity description, identifier sub-type and party identification block; TransactionID recorded in audit logs | Happy path |
| T2 | Lookup for an ABN that exists but the entity is cancelled | HTTP 200 with the canonical response indicating the entity's current registration status | Status mapping |
| T3 | Lookup for a non-existent ABN | HTTP 200 with the canonical response indicating no record found |  |
| T4 | Lookup with missing or empty ABN query parameter | HTTP 400 returned to consumer with a validation error description; error event logged | Input validation |
| T5 | ABR REST service unavailable (simulated network failure) | HTTP fault returned to consumer; error event logged with TransactionID | Connectivity failure |
| T6 | ABR returns a 5xx HTTP error | HTTP fault returned to consumer; error event logged with status code | Backend failure |
| T7 | ABR returns an unexpected JSON payload that cannot be parsed | HTTP fault returned to consumer; error event logged with the raw payload | Schema drift |

---

## 3.4 EAII-289 - ACN Business Details Lookup v2 - Metcash Internal to ATO

### 3.4.1 Interface Process

#### 3.4.1.1 Process Diagram

![image-20260624-060111.png](images/06.png)

#### 3.4.1.2 Process Description

A consumer application issues an HTTP GET to the integration with the Australian Company Number it wants to look up provided as a query parameter. The v2 operation returns the result in a canonical Metcash business object format. On receipt of the request:

1. The integration
  1. extracts the ACN value from the query parameter.
  2. calls the Australian Business Register's REST endpoint, passing the ACN as a query parameter, and waits for a JSON response.
  3. If the Register responds successfully, the JSON payload is parsed into structured data, then mapped into the canonical Metcash business object (`MetcashIdentifierBObj`). The canonical object exposes the entity description and identifier sub-type plus a party identification block that carries the ACN identifier description and current registration status.
  4. The canonical response is returned to the consumer with HTTP 200.
  5. If the Register returns an error or the call fails, an error response is returned to the consumer, and the lookup ends.
  6. returns the response to the consumer.

#### 3.4.1.3 Known Issues

The misleading configuration variable naming on the outbound HTTP client (see Section 1.4 Known Issue 1) applies to this interface. No ServiceNow incidents have been recorded specifically against this v2 ACN operation.

### 3.4.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping Manifest - EAII-289 - Metcash Internal to ATO](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/fsd/TibcoATOBusinessDetails/Mapping%20Manifest%20-%20EAII-289%20-%20Metcash%20Internal%20to%20ATO.md) |
| TSD for the interface(s) | *To be created in tsd/EAII-289/* |
| ADO link for the feature | *To be added by the delivery team* |
| Source file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v2/source_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ACN%20Business%20Details%20Lookup%20v2/source_samples/) *(no samples provided - to be auto-generated)* |
| Target file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v2/target_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ACN%20Business%20Details%20Lookup%20v2/target_samples/) *(no samples provided - to be auto-generated)* |

### 3.4.3 API Endpoint(s) information

| **Item** | **Value** |
| --- | --- |
| Consumer-facing URL path | `GET /fetchDetailsResource/api/ato/getacn/v2?acn={acn}` |
| Consumer-facing transport | HTTP, synchronous request/response |
| Consumer-facing response format | XML - canonical `MetcashIdentifierBObj` |
| Target system URL path | `GET /api/ato/getacn/v1?acn={acn}` on the configured ABR REST host |
| Target system protocol | REST (HTTP) returning JSON |
| Target system authentication | Per environment configuration (no per-request credential in the request body for v2) |

### 3.4.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Silver | Same rationale as Section 3.1.4 - business-operational usage with a 95% availability target. |

### 3.4.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Public | ACN, entity description and registration status are publicly available through the official Australian Business Register and ASIC public search. | Standard logging and retention apply. No additional masking or encryption requirements above the platform defaults. |

### 3.4.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| N | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | Volumes are low (driven by ad-hoc lookups). No specific peak/average volume targets defined. |
| N | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Single record lookup; canonical response is a small XML document (under 5 KB). No specific size requirements. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance test requirements beyond confirming response within the latency target. |
| Y | Latency | Any specific latency requirements | End-to-end response time SHOULD be under 5 seconds for 95% of requests; dominated by ABR response time. |
| Y | Scalability | Any specific scalability requirements | Must scale to support concurrent ad-hoc lookups from all authorised internal consumer applications. |
| Y | Reliability | Reliability<br> Disaster Recovery | 95% availability target during business hours (Silver). DR per AIS platform standards. |
| Y | Auditability & Observability | Fields to be traced | Per Corporate Global Auditability and Observability requirements: TransactionID, request endpoint, ACN value, target endpoint, response status. |
| Y | Logging | Fields or key message identifiers to be logged | TransactionID, target service (`ATOService-getACNv2`), begin/end/error event types, status code. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Synchronous on-demand lookup. No scheduling or sequencing requirements. |
| N | Backup & Archiving | Backup<br> Archiving | No persistent storage. No backup/archive requirements beyond audit log retention which is managed by the CLE platform. |
| N | Other / Misc. |  | None identified. |

### 3.4.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ABR connectivity failure | Network error or timeout calling the ABR REST endpoint | Log error event with TransactionID; return HTTP fault to the consumer | Standard AIS platform alerting |
| ABR HTTP error response | ABR returns 4xx/5xx | Log error event with TransactionID, status code and any payload returned; return HTTP fault to the consumer | Standard AIS platform alerting |
| JSON parse failure | The ABR response cannot be parsed into the expected structure | Log error event with TransactionID and the raw payload; return HTTP fault to the consumer | Standard AIS platform alerting |
| Invalid input parameter | ACN query parameter missing, empty, or not a valid 9-digit number | Log error event with TransactionID; return HTTP 400 to the consumer with a description of the validation failure | None - consumer-side error |
| Audit logging failure | CLE endpoint unavailable when publishing begin/end/error event | Continue processing the lookup; raise platform alert | Standard AIS platform alerting |
| Unexpected exception | Any other unhandled error during processing | Top-level catch-all logs the error with TransactionID and returns a generic HTTP 500 fault to the consumer | Standard AIS platform alerting |

### 3.4.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.4.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.4.10 Relevant context considerations

| **Item** | **Status** | **Outcome** *(Noted/Confirmed/Agreed)* | **Outcome Date** |
| --- | --- | --- | --- |
| Confirm the canonical response shape (`MetcashIdentifierBObj`) is the contract consumers depend on - no consumer changes required during AIS migration | Open | Noted |  |
| Configuration variable naming on the outbound HTTP client to be corrected during AIS rebuild | Open | Noted |  |
| Existing TIBCO process `Processes/com/metcash/atobusinessdetails/v2/fetchATODetails.bwp` (branch `getacn`) is the source of truth for behaviour | Confirmed | Confirmed |  |

### 3.4.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Successful ACN lookup for a valid, currently-registered Australian company | HTTP 200 with `MetcashIdentifierBObj` populated with the entity description, identifier sub-type and party identification block; TransactionID recorded in audit logs | Happy path |
| T2 | Lookup for an ACN that exists but the company is deregistered | HTTP 200 with the canonical response indicating the entity's current registration status | Status mapping |
| T3 | Lookup for a non-existent ACN | HTTP 200 with the canonical response indicating no record found |  |
| T4 | Lookup with missing or empty ACN query parameter | HTTP 400 returned to consumer with a validation error description; error event logged | Input validation |
| T5 | ABR REST service unavailable (simulated network failure) | HTTP fault returned to consumer; error event logged with TransactionID | Connectivity failure |
| T6 | ABR returns a 5xx HTTP error | HTTP fault returned to consumer; error event logged with status code | Backend failure |
| T7 | ABR returns an unexpected JSON payload that cannot be parsed | HTTP fault returned to consumer; error event logged with the raw payload | Schema drift |

---

# 4 Appendices & Supporting Information

## 4.1 Supporting Material

- Mapping Manifest: [Mapping Manifest - EAII-289 - Metcash Internal to ATO](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/fsd/TibcoATOBusinessDetails/Mapping%20Manifest%20-%20EAII-289%20-%20Metcash%20Internal%20to%20ATO.md)
- Legacy TIBCO source module: `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/`
- Legacy v1 process file: `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Processes/com/metcash/atobusinessdetails/fetchDetailsREST.bwp`
- Legacy v2 process file: `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Processes/com/metcash/atobusinessdetails/v2/fetchATODetails.bwp`
- Source schema (ABR-native, namespace rebranded): ![diagram](images/11.png) `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/AbrXmlSearch.xsd`
- Target canonical schema (v2): ![diagram](images/09.png) `tibco/TibcoATOBusinessDetails/sourcecode/com.metcash.atobusinessdetails/Schemas/IdentifierResponse.xsd`
- ![diagram](images/03.png)
- ![diagram](images/07.png)
- ![diagram](images/02.png)
- ![diagram](images/02.png)
- ![diagram](images/08.png)
- ![diagram](images/08.png)
- ![diagram](images/07.png)

---

# 5 FSD Approval Checklist

> *To approve the document, please leave a comment with the word "Approved" in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the FSD have been answered to the approver's satisfaction where applicable.*
>
> *Click on the arrow (>) below to view the checklist.*
>

| # | **Checklist Item** |  |
| --- | --- | --- |
|  | **Project Overview** |  |
| 1 | Are the business requirements and objectives of the project defined? | Y |
| 2 | Are the current and future state contexts of the project defined? | Y |
| 3 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 4 | Have any dependencies (technical or otherwise) been defined? | Y |
| 5 | Have any risks (technical or otherwise) and associated mitigation approaches been identified? | Y |
| 6 | Are growth forecasts included in the document? | Y |
|  | **Business Process and Functional Requirements** |  |
| 7 | Has a Business Process Diagram, including the AIS/Orchestration Layer, been included? | Y |
| 8 | Are the functions specific to integrations adequately described? | Y |
| 9 | Have mapping documents for Source and Target systems been captured? | Y |
| 10 | Have lookup logic and handling of failed lookups been defined? | Y |
| 11 | Have the source and target entities been defined? | Y |
| 12 | Have the Source and Target File formats been defined? | Y |
| 13 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 14 | Is the classification of data identified? | Y |
| 15 | Have data handling requirements according to the information classification been defined? | Y |
| 16 | Have the audit requirements for data been defined? | Y |
| 17 | Has each integration been assigned a GSB rating? | Y |
| 18 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 19 | Is logging free of any restricted data fields? | Y |
| 20 | Are any integration component monitoring requirements defined? | Y |
| 21 | Are any specific reporting requirements defined? | Y |
| 22 | Are the batch scheduling requirements defined? | Y |
| 23 | Are the disaster recovery (DR) requirements defined? | Y |
| 24 | Are the storage and data retention requirements defined? | Y |
| 25 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 26 | Are the functional test scenarios defined? | Y |
| 27 | Are the exception test scenarios defined? | Y |
| 28 | Are the performance, load, or stress testing scenarios (if any) defined? | Y |
| 29 | Are the average and peak message/file sizes defined? | Y |
| 30 | Are the average and peak transaction volumes defined? | Y |
| 31 | Are the average and peak transaction frequencies defined? | Y |
| 32 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 33 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 34 | Has a walkthrough of the document been completed? | Y |
|  | **Interface Catalogue** |  |
| 35 | Have all the Metcash columns in the [EAI Interface Catalogue.xlsx](https://metcash.sharepoint.com/:x:/r/sites/AISDevelopmentCentre/Shared%20Documents/General/06.%20EAI%20Interface%20Catalogue/EAI%20Interface%20Catalogue.xlsx?d=wf70ab37d2042493992a3c636da2ab023&csf=1&web=1&e=oZTmqQ) been updated? | Y |
|  | **Approval** |  |
| 36 | Has/have the Interface ID entry/s been added to the EAI Interface Catalogue? | Y |
| 37 | Has the FSD been submitted for reviewed and approval by a Platform Representative? | Y |
| 38 | Has the FSD been submitted for reviewed and approval by a Technical Business Analyst? | Y |
| 39 | Has the FSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 40 | Has the FSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 41 | Has the FSD been submitted for reviewed and approval by a Test Manager? | Y |
