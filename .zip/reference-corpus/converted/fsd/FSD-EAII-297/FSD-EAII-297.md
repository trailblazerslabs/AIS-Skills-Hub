<!-- Source: Functional+Specification+-+EAII-297+-+Metconnect+to+Supplier+MDM+-+Get_Clear+Supplier+Number.doc -->
<!-- Title: Functional Specification - EAII-297 - Metconnect to Supplier MDM - Get_Clear Supplier Number -->

# Functional Specification - EAII-297 - Metconnect to Supplier MDM - Get/Clear Supplier Number

**Table of Contents**

- 1 Document Overview
  - 1.1 Business Context
  - 1.2 Integration Description
  - 1.3 Horizon Impact Assessment
  - 1.4 Known Issues
  - 1.5 Glossary

- 2 Scope
  - 2.1 In Scope
  - 2.2 Out of Scope
  - 2.3 Limitations and Constraints

- 3 Requirements Overview
  - 3.1 EAII-297 – Get/Release MDM Supplier Number – Salesforce to IBM MDM
    - 3.1.1 Interface Process
      - 3.1.1.1 Process Diagram
      - 3.1.1.2 Process Description

    - 3.1.2 Interface Requirements / Mapping Details
    - 3.1.3 API Endpoint(s) Information
      - Inbound REST Endpoints (exposed by integration platform)
      - Outbound SOAP Endpoint (called by integration platform)

    - 3.1.4 Interface Service Level - Gold/Silver/Bronze
    - 3.1.5 Interface Data Classification
    - 3.1.6 Non-Functional Requirements
    - 3.1.7 Exception Handling
    - 3.1.8 Integration Component Monitoring
    - 3.1.9 Reporting
    - 3.1.10 Relevant Context Considerations
    - 3.1.11 Test Scenarios

- 4 Appendices & Supporting Information
  - 4.1 Supporting Material
    - Artifact Inventory
    - Traceability: EIP Step → Source Artifact
    - Diagram Source Files

- 5 FSD Approval Checklist

| **Document Approver** | **Approver Role** |
| --- | --- |
| Amrik Aujla | Platform Representative |
| Magesh Parthasarathy | Technical Business Analyst |
| Magesh Parthasarathy | Integration Platform Representative |
| Sue Homsuwan | Integration Platform Operations |
| Mohanraj Vengiduswamy | Test Manager |

---

# 1 Document Overview

## 1.1 Business Context

Metcash's supplier onboarding process requires each new supplier to be assigned a unique supplier number before they can be registered in Metcash's supplier agreement systems. The MDM Supplier Number integration enables Metcash's Salesforce-based supplier portal (MetConnect) to request a new, unique supplier number from the Master Data Management system at the point of agreement creation. If an agreement does not proceed, the reserved supplier number can be released back to the Master Data Management system to prevent exhaustion of the number range.

This integration is being migrated from the legacy integration platform to Azure Integration Services (AIS). The purpose of this document is to capture the functional requirements so that the integration can be re-implemented on the new platform with equivalent behaviour.

## 1.2 Integration Description

This FSD covers **one interface** (EAII-297) that exposes two synchronous REST API operations to the Salesforce-based supplier portal:

1. **Get New Supplier Number** — the portal requests a unique supplier number for a given supplier agreement. The integration forwards the request to the Master Data Management system and returns the generated supplier number to the caller.
2. **Release Reserved Supplier Number** — the portal requests that a previously reserved supplier number for a given agreement be cancelled. The integration forwards the cancellation request to the Master Data Management system and returns the outcome.

Both operations are authenticated via a pre-shared API key supplied in the request's `Authorization` header (Bearer token). Requests that fail authentication are rejected with an HTTP 401 response. All requests and responses are logged to Metcash's centralized audit logging service.

The integration is synchronous and request-response: the calling application waits for a response before continuing the onboarding workflow.

**Legacy High Level Architecture**

![image-20260717-065355.png](images/04.png)

**Proposed High Level Architecture**

![image-20260714-112801.png](images/08.png)

## 1.3 Horizon Impact Assessment

> 🟡 INFERRED - to be confirmed with Horizon Pillar Leads.
>

| **System** | **Colour** | **Rationale** |
| --- | --- | --- |
| IBM MDM (Supplier Number Service) | 🔴 RED | IBM MDM is Metcash's Master Data Management system, classified under "Master Data Structures" — explicitly listed in the HIGH risk tier. |
| Salesforce (MetConnect Portal) | 🟠 AMBER | MetConnect is built on Salesforce. While Salesforce is not explicitly listed, the conditional item "AIS or TIBCO/GoAnywhere Integrations that hit any Amber system" applies — Salesforce-based systems may be assessed as Amber depending on portfolio alignment. |
| AIS / TIBCO Integration | 🔴 RED | This integration directly connects to IBM MDM (a RED system), triggering the conditional rule: "AIS or TIBCO/GoAnywhere Integrations that hit any Red system → RED". |

**Impact Summary:** This integration is assessed as RED. Any change or deployment requires review by the IT Platform Owner and approval by the Horizon Platform Owner and Business Process Owner before proceeding.

## 1.4 Known Issues

- **API key rotation requires restart:** The service currently loads API keys from configuration at startup. Rotating a key requires a service restart, causing brief unavailability. AIS should address this by using a secrets management service with hot-reload capability (e.g., Azure Key Vault with dynamic secret reference), eliminating the need for a restart on key rotation.

## 1.5 Glossary

| **Item** | **Description** |
| --- | --- |
| AgreementID | Identifier for a supplier trading agreement, formatted as a Salesforce Record ID or a Metcash-assigned alphanumeric code (e.g., `P00029015`). Passed by the calling portal to associate the supplier number with a specific agreement record. |
| AIS | Azure Integration Services — the target integration platform for this migration. |
| IBM MDM | IBM Master Data Management system. Metcash's system of record for supplier and trading term master data, including the generation and management of supplier reference numbers. |
| MetConnect | Metcash's supplier portal, built on the Salesforce platform, used by staff to onboard suppliers and manage supplier agreements. |
| Salesforce | The CRM and portal platform underpinning MetConnect. The `SourceSystemID` value in all API requests from MetConnect is `Salesforce`. |
| Supplier Number | A unique 7-digit number assigned by IBM MDM to identify a supplier within Metcash's systems. The format is a 2-digit prefix (`10`) followed by a 5-digit zero-padded sequence number (e.g., `1012695`). |
| SuccessString | The result code returned by IBM MDM for the Release operation, derived from MDM's transaction result code (e.g., `01` for success). |
| TransactionID | A unique identifier for the API call, passed by the caller or generated by the integration layer. Format observed in samples: `{SalesforceRecordID}_{YYYYMMDDHHmmss}` (e.g., `001Rl00001O9viJIAR_20260709160955`). |
| WS-Security | A SOAP security standard used for authenticating calls to IBM MDM via a UsernameToken header. |

---

# 2 Scope

## 2.1 In Scope

- **EAII-297 – Get/Release MDM Supplier Number — Salesforce to IBM MDM:**
  - Reception of REST API requests from the Salesforce-based MetConnect supplier portal.
  - oAuth for all inbound requests.
  - Translation of REST requests into the format required by the Master Data Management system.
  - Retrieval of a new, unique supplier number from the Master Data Management system.
  - Release of a reserved supplier number back to the Master Data Management system.
  - Translation of MDM responses back to the REST JSON format expected by the calling portal.
  - Audit logging of all request and response events to the centralized logging service.
  - Return of structured error responses on authentication failure or MDM processing errors.

## 2.2 Out of Scope

- Maintenance of supplier contracts, agreements, or trading terms in the Master Data Management system (the MDM service exposes these operations, but they are not invoked by this integration).
- Searching for supplier contracts or agreements in the Master Data Management system.
- Retrieval of agreement numbers.
- Any downstream processing once the supplier number is returned to the calling portal (e.g., Salesforce-side storage or further provisioning).
- Bulk or batch supplier number operations.

## 2.3 Limitations and Constraints

- The integration is synchronous: the calling portal waits for a complete response. If the Master Data Management system is unavailable or slow, the calling application will be blocked until a timeout occurs.
- TLS mutual authentication is required for connectivity to the Master Data Management system. Valid keystores and certificates must be provisioned and managed per environment.
- MDM service credentials (username and password) are environment-specific and must be stored securely.
- The supplier number format (prefix and padding length) is configuration-driven. If Metcash changes the supplier number format, a configuration change is required.

---

# 3 Requirements Overview

## 3.1 EAII-297 – Get/Release MDM Supplier Number – Salesforce to IBM MDM

### 3.1.1 Interface Process

#### 3.1.1.1 Process Diagram

![image-20260715-010227.png](images/05.png)

#### 3.1.1.2 Process Description

**Get New Supplier Number**

The Salesforce portal sends a synchronous HTTP POST request to the integration platform's `/newsupplier/v1` endpoint. The request body contains a mandatory Agreement ID and an optional Transaction ID and Source System ID (JSON format).

The integration platform:

1. Receives the request and assigns a Transaction ID — using the value supplied in the request if present, or generating a new unique identifier if absent.
2. Logs the request receipt as an audit start event.
3. Validates the oAuth`Authorization: Bearer` header. If validation fails, the platform logs the authentication failure and returns an HTTP 401 response with a descriptive error message.
4. If authentication succeeds, the platform constructs the authenticated context required by the Master Data Management system (UsernameToken credential header).
5. Translates the REST request into the MDM service format: populates the Agreement ID as the parent reference, sets the reference type to "SUPPLIER NUMBER", applies the configured number prefix and padding parameters, and generates a request ID from the current timestamp.
6. Calls the Master Data Management system's Get Next Supplier Number operation over HTTPS.
7. Receives the MDM response containing a raw sequence number.
8. Formats the final supplier number by prepending the configured prefix (`10`) and zero-padding the sequence to 5 digits (e.g., sequence `12695` → supplier number `1012695`).
9. Logs the successful completion as an audit end event.
10. Returns a JSON response to the caller containing the Transaction ID, Agreement ID, and the formatted Supplier Number.

On any MDM processing fault or unhandled exception, the platform logs the error and returns a JSON response with a failure message: `"Request for new supplier failed. Please contact Metcash."` with an HTTP 500 status.

**Release Reserved Supplier Number**

The Salesforce portal sends a synchronous HTTP POST request to the integration platform's `/releasesupplier/v1` endpoint. The request body contains a mandatory Agreement ID (JSON format).

The integration platform follows the same authentication and MDM credential steps as the Get operation, then:

1. Translates the REST request into the MDM service format for the Clear Reserved Supplier Numbers operation, populating the Agreement ID as the parent reference.
2. Calls the Master Data Management system's Clear Reserved Supplier Numbers operation over HTTPS.
3. Receives the MDM transaction result code.
4. Logs the completion.
5. Returns a JSON response containing the Transaction ID, Agreement ID, and the MDM transaction result code as `SuccessString`.

On failure, the integration returns a JSON response with `SuccessString` set to `"FAILED"`.

### 3.1.2 Interface Requirements / Mapping Details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface |  |
| TSD for the interface |  |
| ADO link for the feature | [ADO 262915](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/262915) |
| Source file(s) | ![diagram](images/03.png)<br> <br>![diagram](images/02.png)<br> <br>![diagram](images/07.png) |
| Target file(s) | ![diagram](images/01.png)<br> <br>![diagram](images/10.png)<br> <br>![diagram](images/11.png) |

### 3.1.3 API Endpoint(s) Information

#### Inbound REST Endpoints (exposed by integration platform)

| **Operation** | **HTTP Method** | **Path** | **Request Format** | **Response Format** |
| --- | --- | --- | --- | --- |
| Get New Supplier Number | POST | `/api/mdm/api/suppliermgmt/newsupplier/v1` | JSON (`NewSupplierRequest`) | JSON (`NewSupplierResponse`) |
| Release Reserved Supplier Number | POST | `/api/mdm/api/suppliermgmt/releasesupplier/v1` | JSON (`clearSupplierRequest`) | JSON (`clearSupplierResponse`) |

**Authentication:** Bearer token in `Authorization` header. Invalid → HTTP 401 Unauthorized.

**Request schema — Get New Supplier Number:**

```
{
  "TransactionID": "001Rl00001O9viJIAR_20260709160955",
  "SourceSystemID": "Salesforce",
  "AgreementID": "P00029015"
}
```

- `TransactionID`: optional — caller-supplied correlation ID; generated by integration if absent
- `SourceSystemID`: optional — identifies the calling system
- `AgreementID`: **mandatory** — the supplier agreement identifier to associate with the new supplier number

**Response schema — Get New Supplier Number:**

```
{
  "TransactionID": "001Rl00001O9viJIAR_20260709160955",
  "SourceSystemID": "Salesforce",
  "AgreementID": "P00029015",
  "SupplierNumber": "1012695"
}
```

**Request schema — Release Reserved Supplier Number:**

```
{
  "TransactionID": "P00028593_20260709183546",
  "SourceSystemID": "Salesforce",
  "AgreementID": "P00028593"
}
```

**Response schema — Release Reserved Supplier Number:**

```
{
  "TransactionID": "P00028593_20260709183546",
  "SourceSystemID": "Salesforce",
  "AgreementID": "P00028593",
  "SuccessString": "01"
}
```

#### Outbound SOAP Endpoint (called by integration platform)

| **Operation** | **Protocol** | **Transport** | **Service** | **WSDL** |
| --- | --- | --- | --- | --- |
| Get Next Supplier Number | SOAP 1.1 | HTTPS | MDM Supplier Number Service | ![diagram](images/12.png) |
| Clear Reserved Supplier Numbers | SOAP 1.1 | HTTPS | MDM Supplier Number Service |  |

- **Authentication:** WS-Security UsernameToken (username and password per environment — stored in secrets management, not embedded in code)
- **TLS:** Mutual authentication with environment-specific keystore
- **Endpoint URL:** Environment-specific; configured via deployment variables

### 3.1.4 Interface Service Level - Gold/Silver/Bronze

| **Service Level** | **Service Level Rationale** |
| --- | --- |
| Silver | This integration supports new supplier onboarding, a business-critical operational process. Unavailability blocks the creation of supplier numbers, preventing agreements from being completed. However, the process is not directly customer-facing in real time and can tolerate brief outages within business hours. Silver (Business Operational) — 95% availability, 12×6 support hours — is appropriate. |

### 3.1.5 Interface Data Classification

| **Data Classification** | **Data Classification Rationale** | **Data Handling Requirements** |
| --- | --- | --- |
| Internal | The integration transmits supplier agreement identifiers and generated supplier numbers. These are internal Metcash operational data items — not publicly available, but not Restricted or Confidential. | Data must not be logged in plain text beyond the Transaction ID and Agreement ID. MDM credentials and API keys must never appear in application logs. Use secrets management for all credentials. |

### 3.1.6 Non-Functional Requirements

| **Applicable** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume | Volume is driven by new supplier onboarding events. Expected volume is low (tens to hundreds of requests per day), with peaks during high-activity onboarding periods. |
| Y | Volume | Average volume | Typically follows business-hours patterns aligned to supplier onboarding activity. |
| N | Volume | Seasonal considerations | Not expected to vary significantly by season. |
| N | Volume | Expected growth | No significant volume growth anticipated without a corresponding growth in supplier onboarding activity. |
| Y | Message Size | Average msg size | Very small — request and response payloads are under 1 KB each. |
| N | Message Size | Max msg size | No practical upper bound given the simple field structures. |
| N | Performance Testing | Performance / Load / Stress | Low volume service; no dedicated performance testing required unless integration platform imposes constraints. |
| Y | Latency | Any specific latency requirements | Synchronous integration — caller waits for response. Acceptable end-to-end latency: <5 seconds under normal conditions. MDM SLA is the dominant factor. |
| N | Scalability | Any specific scalability requirements | No scaling requirements beyond standard platform capabilities. |
| Y | Reliability | Reliability | Silver SLA — 95% availability. Outages that block supplier onboarding should be resolved within the Silver MTTR SLA (≤20 working days). |
| Y | Reliability | Disaster Recovery | RTO ≤ 4 hours, RPO ≤ 2 hours (Silver tier). |
| Y | Auditability & Observability | Fields to be traced | Transaction ID, Agreement ID, Source System ID, operation name (Get or Release), outcome (success/failure), timestamp. Refer to Corporate Global Auditability and Observability requirements. |
| Y | Logging | Key identifiers to be logged | Transaction ID and Agreement ID must be logged on every request and response. Error details (fault code, message) must be logged on failure. MDM credentials and API keys must NOT be logged. |
| N | Sequencing or scheduling | Msg/file schedule | No scheduling — purely on-demand synchronous requests. |
| N | Backup & Archiving | Backup / Archiving | No state maintained by the integration layer. Master data is held in IBM MDM; backup and archiving are the responsibility of the MDM platform. |
| N | Other / Misc |  |  |

### 3.1.7 Exception Handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Authentication failure | Invalid or missing Bearer token in `Authorization` header | Reject request; log authentication failure event with Transaction ID; return HTTP 401 with message: `"Authentication Failed: Please check Authorization Key"` | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| MDM processing fault | MDM returns a SOAP fault (`processingFault`) | Log fault details (fault code and message) with Transaction ID and Agreement ID; return HTTP 200 JSON response with failure message: `"Request for new supplier failed. Please contact Metcash."` (Get) or `SuccessString: "FAILED"` (Release) | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| MDM timeout | Call to MDM exceeds configured timeout threshold | Log timeout exception with Transaction ID and Agreement ID; return error response to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unhandled exception | Any unexpected runtime error in the integration layer | Log exception details (stack trace, fault message) with Transaction ID; return error response to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.8 Integration Component Monitoring

N/A - No special monitoring requirements. Standard AIS platform monitoring applies.

### 3.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 3.1.10 Relevant Context Considerations

| **Item** | **Status** | **Outcome** | **Outcome Date** |
| --- | --- | --- | --- |
| Source system confirmed as Salesforce (MetConnect Portal) | Confirmed | Sample payloads show `SourceSystemID: "Salesforce"` and Salesforce-format record IDs in the TransactionID field. The integration's OAuth2 auth key is named `metconnect-test`, confirming the MetConnect supplier portal (Salesforce-based) is the only authorized caller. | 2026-07-14 |
| Supplier number format | Confirmed | Derived from source code: prefix `10` + 5-digit zero-padded MDM sequence number. Sample responses confirm: sequence numbers map to 7-digit supplier numbers starting with `10` (e.g., `1012695`, `1012525`). | 2026-07-14 |
| SuccessString for Release operation | Confirmed | Sample response shows `SuccessString: "01"`. This value is the MDM transaction result code (`TxResult/ResultCode`) returned by the `clearReservedSupplierNumbers` operation. | 2026-07-14 |
| JMS queue `Service.MDM.Supplier.Clear.Q` in substvar | Noted — TBD | A JMS queue name is configured in the legacy service's connection variables for failed clear supplier operations. The main process flow does not invoke this queue in the analysed code path; it may be unused or reserved for a dead-letter pattern not exercised in normal processing. Confirm during TSD design. | 2026-07-14 |
| GoAnywhere MFT | Not applicable | This integration has no file-based delivery component. GoAnywhere is not involved. | 2026-07-14 |

### 3.1.11 Test Scenarios

| **#** | **Test Scenario** | **Expected Results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Request a new supplier number with a valid Agreement ID and valid API key | HTTP 200 response with a 7-digit supplier number starting with `10` in the `SupplierNumber` field; `AgreementID` matches the request; `TransactionID` echoed or generated | Sample: `AgreementID=P00029015` → `SupplierNumber=1012695` |
| T2 | Request a new supplier number where the request supplies its own TransactionID | HTTP 200 response with the caller-supplied `TransactionID` echoed back unchanged | Verify pass-through of caller's correlation ID |
| T3 | Request a new supplier number without a TransactionID | HTTP 200 response with a system-generated TransactionID (non-empty unique value) | Verify auto-generation behaviour |
| T4 | Release a reserved supplier number with a valid Agreement ID and valid API key | HTTP 200 response with `SuccessString` populated with MDM result code; `AgreementID` matches request | Sample: `AgreementID=P00028593` → `SuccessString=01` |
| T5 | Submit a Get request with an invalid or missing API key | HTTP 401 response with message `"Authentication Failed: Please check Authorization Key"` | Verify no MDM call is made |
| T6 | Submit a Release request with an invalid or missing API key | HTTP 401 response with message `"Authentication Failed: Please check Authorization Key"` | Verify no MDM call is made |
| T7 | Submit a Get request when the MDM service returns a processing fault | HTTP 200 response with `Message: "Request for new supplier failed. Please contact Metcash."` and no `SupplierNumber` | Simulate MDM SOAP fault |
| T8 | Submit a Release request when the MDM service returns a processing fault | HTTP 200 response with `SuccessString: "FAILED"` | Simulate MDM SOAP fault |
| T9 | Submit a Get request when the MDM service is unavailable (timeout) | Error response returned to caller within configured timeout period; error event logged | Verify graceful timeout handling |
| T10 | Submit a request with all optional fields absent (TransactionID and SourceSystemID omitted) | HTTP 200 success response; TransactionID auto-generated; SourceSystemID absent from response | Verify optional field handling |

---

# 4 Appendices & Supporting Information

## 4.1 Supporting Material

### Artifact Inventory

The following artifacts were discovered and analyzed to produce this FSD.

| **Artifact** | **Type** | **Path** | **Purpose** |
| --- | --- | --- | --- |
| `mdmSupplierNumberInterface.bwp` | TIBCO BW Process | `sourcecode/com.metcash.MDMSupplierNumber/Processes/com/metcash/mdmsupplier/` | Main entry-point process; handles both REST endpoints, authentication, MDM invocation, response mapping, and error handling. **Tibco Reference:** mdmSupplierNumberInterface.bwp |
| `Oauth2Authentication.bwp` | TIBCO BW Process | `sourcecode/com.metcash.MDMSupplierNumber/Processes/com/metcash/oauth/` | API key validation subprocess; validates Bearer token against pre-loaded key store. **Tibco Reference:** Oauth2Authentication.bwp |
| `NewSupplier.xsd` | XSD Schema | `sourcecode/com.metcash.MDMSupplierNumber/Schemas/` | Defines the REST API request and response message structures: `NewSupplierRequest`, `NewSupplierResponse`, `clearSupplierRequest`, `clearSupplierResponse`. |
| `MTTSUPServices.wsdl` | WSDL | `sourcecode/com.metcash.MDMSupplierNumber/Service Descriptors/` | IBM MDM SOAP service definition; defines `getNextSupplierNumber` and `clearReservedSupplierNumbers` operations and their request/response schemas. |
| `default.substvar` | Configuration | `sourcecode/com.metcash.MDMSupplierNumber/META-INF/` | Baseline configuration variables; defines service name, HTTP listener port, MDM endpoint, MDM credentials (environment-specific), supplier number format parameters (prefix, pad length, pad char), and API key. |
| `invokeLogEvent.bwp` | TIBCO BW Process | `sourcecode/CommonLogging/Processes/commonlogging/sh/` | Shared asynchronous audit logging subprocess; fire-and-forget SOAP call to the centralized logging service. **Tibco Reference:** invokeLogEvent.bwp |

### Traceability: EIP Step → Source Artifact

| **Functional Step** | **EIP Pattern** | **Source Artifact** |
| --- | --- | --- |
| Receive REST request | Message Receiver | `mdmSupplierNumberInterface.bwp` — `onMessage` handler for `getsuppliernumber` and `releasesuppliernumber` partner links |
| Generate / extract Transaction ID | Correlation Identifier | `mdmSupplierNumberInterface.bwp` — BWAssign activity: `if(exists($post.item/tns:TransactionID)) then $post.item/tns:TransactionID else tib:uuid()` |
| Validate API key | Message Filter / Security | `Oauth2Authentication.bwp` — validates Bearer token extracted via `substring-after($post.httpHeaders/Authorization, 'Bearer ')` against `FileAuthenticationKeys` shared variable |
| Build MDM security credentials | Message Enricher | `mdmSupplierNumberInterface.bwp` — SetContext activity constructing WS-Security `ns:UsernameToken` from `MDMUserName` and `MDMPassword` config variables |
| Translate request to MDM format | Message Translator | `mdmSupplierNumberInterface.bwp` — Mapper for `getNextSupplierNumber` input: maps AgreementID → `MTTSupNumbersBObj/Parent`, applies `RefType`, `Prefix`, `RequesterName`, `RequesterLanguage` from config |
| Call MDM (Get Supplier Number) | Service Invocator | `mdmSupplierNumberInterface.bwp` — `bpws:invoke` on `getNextSupplierNumber` operation via `MTTSUPServicesPortType` partner link |
| Call MDM (Clear Supplier Numbers) | Service Invocator | `mdmSupplierNumberInterface.bwp` — `bpws:invoke` on `clearReservedSupplierNumbers` operation via `MTTSUPServicesPortType` partner link |
| Format supplier number | Message Translator | `mdmSupplierNumberInterface.bwp` — BWAssign: `concat($Prefix, tib:pad-front($getNextSupplierNumber.parameters/ns8:MTTSupNumbersBObj/ns8:ReferenceNumber, $RefPadLength, $RefPadChar))` |
| Return JSON response | Message Sender | `mdmSupplierNumberInterface.bwp` — `bpws:reply` to caller with mapped `NewSupplierResponse` / `clearSupplierResponse` |
| Audit logging | Wire Tap | `mdmSupplierNumberInterface.bwp` — CallProcess to `invokeLogEvent` at request start, request end, and on error |

### Diagram Source Files

| **Diagram** | **File** |
| --- | --- |
| Legacy High Level Architecture | ![diagram](images/06.png) |
| Proposed High Level Architecture | ![diagram](images/06.png) |
| Get/Release MDM Supplier Number Process Flow | ![diagram](images/09.png) |

---

# 5 FSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the FSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/13.png)

Click here to expand...

| # | **Checklist Item** |  |
| --- | --- | --- |
|  | **Project Overview** |  |
| 1 | Are the business requirements and objectives of the project defined? | Y |
| 2 | Are the current and future state contexts of the project defined? | Y |
| 3 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 4 | Have any dependencies (technical or otherwise) been defined? | Y |
| 5 | Have any risks (technical or otherwise) and associated mitigation approaches been identified? | Y |
| 6 | Are growth forecasts included in the document? | Y |
|  | **Business Process and Functional Requirements** |  |
| 7 | Has a Business Process Diagram, including the AIS/Orchestration Layer, been included? | Y |
| 8 | Are the functions specific to integrations adequately described? | Y |
| 9 | Have mapping documents for Source and Target systems been captured? | Y |
| 10 | Have lookup logic and handling of failed lookups been defined? | Y |
| 11 | Have the source and target entities been defined? | Y |
| 12 | Have the Source and Target File formats been defined? | Y |
| 13 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 14 | Is the classification of data identified? | Y |
| 15 | Have data handling requirements according to the information classification been defined? | Y |
| 16 | Have the audit requirements for data been defined? | Y |
| 17 | Has each integration been assigned a GSB rating? | Y |
| 18 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 19 | Is logging free of any restricted data fields? | Y |
| 20 | Are any integration component monitoring requirements defined? | Y |
| 21 | Are any specific reporting requirements defined? | Y |
| 22 | Are the batch scheduling requirements defined? | Y |
| 23 | Are the disaster recovery (DR) requirements defined? | Y |
| 24 | Are the storage and data retention requirements defined? | Y |
| 25 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 26 | Are the functional test scenarios defined? | Y |
| 27 | Are the exception test scenarios defined? | Y |
| 28 | Are the performance, load, or stress testing scenarios (if any) defined? | Y |
| 29 | Are the average and peak message/file sizes defined? | Y |
| 30 | Are the average and peak transaction volumes defined? | Y |
| 31 | Are the average and peak transaction frequencies defined? | Y |
| 32 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 33 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 34 | Has a walkthrough of the document been completed? | Y |
|  | **Interface Catalogue** |  |
| 35 | Have all the Metcash columns in the [EAI Interface Catalogue.xlsx](https://metcash.sharepoint.com/:x:/r/sites/AISDevelopmentCentre/Shared%20Documents/General/06.%20EAI%20Interface%20Catalogue/EAI%20Interface%20Catalogue.xlsx?d=wf70ab37d2042493992a3c636da2ab023&csf=1&web=1&e=oZTmqQ) been updated? | Y |
|  | **Approval** |  |
| 36 | Has/have the Interface ID entry/s been added to the EAI Interface Catalogue? | Y |
| 37 | Has the FSD been submitted for reviewed and approval by a Platform Representative? | Y |
| 38 | Has the FSD been submitted for reviewed and approval by a Technical Business Analyst? | Y |
| 39 | Has the FSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 40 | Has the FSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 41 | Has the FSD been submitted for reviewed and approval by a Test Manager? | Y |
