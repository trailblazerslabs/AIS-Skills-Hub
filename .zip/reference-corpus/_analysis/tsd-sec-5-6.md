

====================================================================================================
## DOC: TSD-EAII-284_283_282_385
====================================================================================================

## 5.1.6 Service High Level Design

### 5.1.6.1 Component List

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-metproducts-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts the `CorporateItemToIndiPIM` function — the Service Bus–triggered runtime that receives the corporate item event, downloads the source XML, acquires an OAuth token, and posts the payload to IndiPIM unchanged. |
| App Service Plan | `Microsoft.Web/serverfarms` | Hosts the Function App runtime. |
| Azure Service Bus Topic (`data.metproducts.{env}.sbt`, subscription `toindipim.corporateitem`) | `Microsoft.ServiceBus/topics` | Delivers the `BlobCreated` event for the corporate item file to the `CorporateItemToIndiPIM` function via a pull-triggered subscription. |
| Azure Blob Storage (`stibo/frompim/corporateitem` on `t3datadv1aesta01` / per-env equivalent) | `Microsoft.Storage/storageAccounts` | Staging location for the STIBO corporate item XML written by GoAnywhere; source of the payload forwarded to IndiPIM. |
| Azure Event Grid System Topic (`metproducts`) | `Microsoft.EventGrid/systemTopics` | Raises the `Microsoft.Storage.BlobCreated` event when GoAnywhere writes the XML file, publishing it to the Service Bus topic. |
| Azure Key Vault — AIS (`t3datadv1ae1kv01` / per-env equivalent) | `Microsoft.KeyVault/vaults` | Stores the IndiPIM OAuth 2.0 client credentials (`IndiPIMClientId`, `IndiPIMClientSecret`) and scope. Accessed via Managed Identity. |
| Azure Key Vault — SMC (`t3enablingdv1ae1kv01` / per-env equivalent) | `Microsoft.KeyVault/vaults` | Stores the shared SMC APIM subscription key used for observation logging. |
| Azure API Management — SMC gateway (`t3-met-core-{env}-ae1-apim`) | `Microsoft.ApiManagement/service` | Gateway for the SMC `StartObservation` call; provides authentication and routing for the observation POST. |
| Application Insights (`t3-met-metproducts-{env}-ae-func-ai`) | `Microsoft.Insights/components` | Captures Function telemetry — trigger/completion events, exceptions, and outbound HTTP dependency calls to Auth0 and IndiPIM. |
| Log Analytics Workspace (`t3-met-metproducts-{env}-ae-law`) | `Microsoft.OperationalInsights/workspaces` | Central repository for Application Insights logs and diagnostics. |
| AIS Spoke Virtual Network (`t2-met-ais-{env}-ae1-net-01`) | `Microsoft.Network/virtualNetworks` | Provides network isolation and VNet Integration for the Function App (SENS subnet). |
| Private Endpoints | `Microsoft.Network/privateEndpoints` | Enables private connectivity to Blob Storage and Key Vault (HSENS subnet). |
| Private DNS Zones | `Microsoft.Network/privateDnsZones` | Resolves Azure PaaS services to their Private Endpoint IP addresses. |
| Network Security Groups | `Microsoft.Network/networkSecurityGroups` | Controls inbound and outbound subnet traffic for the SENS/HSENS subnets. |

### 5.1.6.2 Services

- `CorporateItemToIndiPIM` (Function trigger) — Service Bus pull-triggered entry point; delegates to the shared `ServiceBusFunctionExecutor` for correlation ID generation, blob URL extraction, telemetry, and SMC observation logging.
- `CorporateItemToIndiPIMService` (business logic) — Downloads the source XML from Blob Storage, forwards it unchanged (byte-for-byte pass-through, no mapping) to the IndiPIM REST endpoint, and drives the retry/token-invalidation behaviour described in §5.1.2.
- `IndiPIMTokenService` — Acquires and caches the OAuth 2.0 bearer token from IndiPIM using password grant (initial login) with refresh_token grant renewal; falls back to a fresh password-grant login if the refresh_token grant fails, and invalidates the cached token on a 401 response.

### 5.1.6.3 Audit, Logging & Exceptions

#### 5.1.6.3.1 Logging

As per SMC specification, the following information is logged:

Interface ID = **EAII-284**

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes. Because the Function App issues a single complete observation per invocation (`IsObservationComplete = true`) rather than the multi-stage `ObservationPoint` pattern, only the `StartObservation` API is called.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and, in the same call, completes the monitoring record for this Function invocation — creating an observation instance already marked `IsObservationComplete = true`, carrying the outcome (Success/Failure), correlation ID, and exception detail if applicable. | `t3-met-core-{env}-ae1-apim/smc/startObservation` | POST |

#### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interface are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for Azure resources. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique CorrelationId (GUID) is generated per Service Bus message and propagated throughout the entire processing pipeline — from message receipt, through blob download and OAuth token acquisition, to the outbound POST to IndiPIM. SMC records the outcome of each transaction as a single complete observation per invocation, enabling full traceability from the inbound Service Bus trigger through to the external IndiPIM response.

#### 5.1.6.3.3 Exceptions

| Observation Stage | Exception Scenario | Exception Code | Exception Handling |
| --- | --- | --- | --- |
| Blob Download | Blob missing or inaccessible | EAII284-001 | Log error event to Application Insights and SMC (Failed); propagate exception — Service Bus abandons message, redelivers per `maxDeliveryCount`, then moves to DLQ on exhaustion. |
| Token Acquisition (Auth0) | Unable to acquire OAuth token — Auth0 unavailable or invalid client credentials | EAII284-002 | Log error event; propagate exception — SB redelivery → DLQ. No POST attempt is made without a valid token. |
| IndiPIM POST | HTTP 401 Unauthorized | EAII284-003 | Invalidate cached token via `IndiPIMTokenService.InvalidateToken`; retry once immediately with a freshly acquired token. |
| IndiPIM POST | HTTP 4xx (non-retryable, excl. 401) | EAII284-004 | Log error event with response body captured; return `ProcessingResult.Failure`; log to SMC (Failed); propagate exception — SB redelivery → DLQ. Not retried. |
| IndiPIM POST | HTTP 5xx or timeout | EAII284-005 | Log warning with response body captured; retry up to 3 attempts, fixed 2-second delay. On exhaustion, log error, log to SMC (Failed) with `lastErrorDetail`, propagate exception — SB redelivery → DLQ. |
| IndiPIM POST | Network/connection exception (`HttpRequestException`, `TaskCanceledException`) | EAII284-006 | Log warning with exception message; retry up to 3 attempts, fixed 2-second delay. On exhaustion, log error and propagate — SB redelivery → DLQ. |
| SMC Logging | SMC/APIM unavailable, or `StartObservation` fails after Polly retry (2 attempts, exponential backoff) | EAII284-007 | Log warning to Application Insights and continue. Does not fail or block message processing — SMC logging always executes in a `finally` block; any exception is caught internally. |
| Application Insights | Failed to write telemetry | EAII284-008 | Continue processing; no impact on message outcome. |
| Global / Unhandled | Any unhandled exception not captured above | EAII284-099 | Log error via `ILogger` and `TelemetryClient.TrackException`; re-throw — Service Bus abandons the message, incrementing `DeliveryCount`; DLQ on exhaustion. SMC records "Observation Failed" via the `finally` block regardless. |

> EAII-284 has no schema/input validation stage — as a byte-for-byte pass-through with no transformation, there is no validation surface prior to forwarding the XML to IndiPIM.
>

#### 5.1.6.3.4 Service Consumers

Not applicable — EAII-284 is a single-producer, single-consumer, event-driven integration. One upstream producer (STIBO, via GoAnywhere and the shared corporate item topic) and one downstream consumer (IndiPIM). The subscription `toindipim.corporateitem` is consumed exclusively by the `CorporateItemToIndiPIM` Function.

#### 5.1.6.3.5 Input / Output

| Operation Type | Operation | Schema / Spec | Sample |
| --- | --- | --- | --- |
| Input | Read blob — STEP XML from corporate-items topic | `<STEP-ProductInformation>` XML envelope; `FilterUserType ID="pph_msc_item"` | `1360581885952-1360581885952-682179.xml` |
| Input | Read blob — STEP XML (second fixture) | Same schema | `1375178063872-1375178063872-40007694.xml` |
| Output | HTTP POST to IndiPIM — unchanged STEP XML (pass-through) | `application/xml`; no transformation | Same as input — blob bytes forwarded verbatim |

## 5.2.6 Service High Level Design

### 5.2.6.1 Component List

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-metproducts-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts the `CorporateItemToSorted` function. |
| App Service Plan | `Microsoft.Web/serverfarms` | Hosts the Function App runtime. |
| Azure Service Bus Topic (`data.metproducts.{env}.sbt`, subscription `tosorted.corporateitem`) | `Microsoft.ServiceBus/topics` | Delivers the `BlobCreated` event for the corporate item file to the `CorporateItemToSorted` function via a pull-triggered subscription. |
| Azure Blob Storage (`stibo/frompim/corporateitem`) | `Microsoft.Storage/storageAccounts` | Staging location for the STIBO corporate item XML; shared source with EAII-284 and EAII-385. |
| Azure Event Grid System Topic (`metproducts`) | `Microsoft.EventGrid/systemTopics` | Raises the `BlobCreated` event, publishing it to the Service Bus topic. |
| Azure Key Vault — AIS | `Microsoft.KeyVault/vaults` | Stores the Sorted mTLS client certificate thumbprint reference. Accessed via Managed Identity. |
| Azure Key Vault — SMC | `Microsoft.KeyVault/vaults` | Stores the shared SMC APIM subscription key. |
| Azure API Management — SMC gateway | `Microsoft.ApiManagement/service` | Gateway for the SMC `StartObservation` call. |
| Application Insights | `Microsoft.Insights/components` | Captures Function telemetry, exceptions, dependency calls to Sorted. |
| Log Analytics Workspace | `Microsoft.OperationalInsights/workspaces` | Central repository for Application Insights logs and diagnostics. |
| AIS Spoke Virtual Network | `Microsoft.Network/virtualNetworks` | Network isolation and VNet Integration for the Function App (SENS subnet). |
| Private Endpoints | `Microsoft.Network/privateEndpoints` | Private connectivity to Blob Storage and Key Vault (HSENS subnet). |
| Private DNS Zones | `Microsoft.Network/privateDnsZones` | Resolves Azure PaaS services to Private Endpoint IPs. |
| Network Security Groups | `Microsoft.Network/networkSecurityGroups` | Controls inbound/outbound subnet traffic. |

### 5.2.6.2 Services

- `CorporateItemToSorted` (Function trigger) — Service Bus pull-triggered entry point; delegates to `ServiceBusFunctionExecutor`.
- `CorporateItemToSortedService` (business logic) —downloads XML, transforms via `ISortedCorporateTransformService`, POSTs via `ISortedHttpService`, drives the retry logic in §5.2.2.2.
- `SortedHttpService` (shared with EAII-282) — mTLS-secured HTTP client wrapper for outbound calls to Sorted Marketplace.
- `SortedCorporateTransformService` — XML → Sorted corporate item JSON transformation.

### 5.2.6.2.1 Communication Data Structure

**Message Payload — Function App (**`CorporateItemToSorted`) Output → Sorted POST (representative sample):

```
{
  "itemNumber": "40007694",
  "itemDescription": "MM SLOW MELT CKIE/CRM PCH 70GM",
  "uiMscDepartment": "11 FROZEN",
  "uiMscCategory": "222 ICE CREAM",
  "uiMscCommodity": "22203 SINGLES",
  "uiMscSubcommodity": "2220302 SINGLES PREMIUM",
  "gstCode": "7-G.S.T 10% WET NIL",
  "gstRate": "10",
  "consumerGtin": "04750075001094",
  "unitPricingRequired": "Yes",
  "itemSize": "70GM",
  "warehouseCategory": "F-FROZEN",
  "asset": [
    {
      "assetId": "71061709",
      "assetURL": "https://cdn.metcash.media/...",
      "imageApprovalStatus": "Active",
      "imageSource": "Metproducts",
      "imageType": "front3Dfront_image",
      "imageURLDateAdded": "2026-03-31 19:03:37",
      "imageURLLastModifiedDate": "2026-04-01 10:52:22"
    }
  ]
}
```

### 5.2.6.3 Audit, Logging & Exceptions

#### 5.2.6.3.1 Logging

Interface ID = **EAII-283**. Single-call SMC `StartObservation` pattern — see §5.1.6.3.1 for the shared API detail (same pattern applies to all four interfaces).

#### 5.2.6.3.3 Exceptions

| Observation Stage | Exception Scenario | Category | Exception Handling |
| --- | --- | --- | --- |
| Blob download | Blob missing/inaccessible | Technical | Propagated → SB redelivery → DLQ. |
| Sorted POST | HTTP 400 | Business | **Non-retryable** — immediate failure, SB redelivery → DLQ. |
| Sorted POST | HTTP 401 / 403 / other 4xx (excl. 400) | Technical/Auth | **Currently retried** up to 3×/2s, same as 5xx |
| Sorted POST | HTTP 5xx / timeout / network error | Technical | Retry up to 3×/2s, then SB redelivery → DLQ. |
| Sorted POST | mTLS handshake failure | Technical | Falls into the generic retry path above, then SB redelivery → DLQ. |
| SMC logging | SMC/APIM unavailable | Technical | Caught internally — no message impact. |

## 5.3.6 Service High Level Design

### 5.3.6.1 Component List

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-metproducts-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts the `SupplierItemToSorted` function. |
| Azure Service Bus Topic (`data.metproducts.{env}.sbt`, subscription `tosorted.supplieritem`) | `Microsoft.ServiceBus/topics` | Delivers the `BlobCreated` event for the supplier item file. |
| Azure Blob Storage (`stibo/frompim/supplieritem`) | `Microsoft.Storage/storageAccounts` | Staging location for STIBO supplier item XML — not shared with any other interface (unlike the corporate path). |
| `SortedHttpService`, `SortedGatingService` (shared with EAII-283) | Class (Service) | mTLS HTTP wrapper and availability gating — see §5.2.6.1 for the rest of the shared component list (Key Vaults, APIM, App Insights, VNet, private endpoints, NSGs — identical to EAII-283). |

### 5.3.6.2 Services

- `SupplierItemToSorted` (Function trigger) — Service Bus pull-triggered entry point.
- `SupplierItemToSortedService` (business logic) — Runs the gating check, downloads XML, transforms via `SortedSupplierTransformService`, POSTs via `SortedHttpService`.
- `SortedSupplierTransformService` — XML → Sorted supplier item JSON transformation (pricing fields included, not redacted).

### 5.3.6.2.1 Communication Data Structure

**Message Payload — Function App (**`SupplierItemToSorted`) Output → Sorted POST (representative sample):

```
{
  "itemNumber": "682179",
  "fullItemDescription": "DISPRIN ASPIRIN TABLETS REGULAR 24EA X 12 X 6",
  "payToSupplierName": "RECKITT BENCKISER AUST",
  "rangeWithIGA": "Yes",
  "packSize": "12",
  "masterPack": "6",
  "gstRate": "10",
  "consumerGtin": "09300631017707",
  "supplierItemNumber": "45764821",
  "barcode": [
    { "payToSupplierId": "1011247", "outerGtin": "19300631976209" }
  ],
  "itemPrice": [
    {
      "poListCost": "223.0900",
      "standardCost": "223.0900",
      "masterPack": "6",
      "distributionMethod": "W-Warehouse",
      "itemPriceEffDt": "2022-11-04",
      "priceState": "NSW",
      "pricePillar": "IGA"
    }
  ]
}
```

> `itemPrice` and `rangeWithIGA` fields are passed through verbatim to Sorted — this is intentionalThey must not appear in SMC stages, App Insights traces, or DLQ message bodies (the code satisfies this today because `LogMessage` entries carry status metadata only, never the payload).
>

### 5.3.6.3 Audit, Logging & Exceptions

Interface ID = **EAII-282**. Single-call SMC `StartObservation` pattern — see §5.1.6.3.1 for the shared API detail.

#### 5.3.6.3.3 Exceptions

Identical to EAII-283 (§5.2.6.3.3), substituting interface ID, with one addition:

| Observation Stage | Exception Scenario | Category | Exception Handling |
| --- | --- | --- | --- |
| Payload construction / logging | Pricing fields present in source XML | Compliance | Fields **are** sent to Sorted (intentional, per code comment); must **not** appear in any SMC `LogMessage` stage entry or Application Insights trace. Currently satisfied by construction (stage entries never include the payload body) |

## 5.4.6 Service High Level Design

### 5.4.6.1 Component List

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-metproducts-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts the `CorporateItemToMetProms` function. |
| Azure Service Bus Topic (`data.metproducts.{env}.sbt`, subscription `tometproms.corporateitem`) | `Microsoft.ServiceBus/topics` | Delivers the `BlobCreated` event for the corporate item file. |
| Azure Blob Storage (`stibo/frompim/corporateitem`) | `Microsoft.Storage/storageAccounts` | Shared staging location with EAII-283/284. |
| Azure Key Vault — AIS | `Microsoft.KeyVault/vaults` | Stores `MetPromsClientId`, `MetPromsClientSecret`, `MetPromsScope` — client secret/scope values currently outstanding. |
| `TokenService` | Class (Service) | OAuth2 client-credentials token acquisition, shared cache. |
| Remaining shared infrastructure (Key Vault SMC, APIM, App Insights, Log Analytics, VNet, private endpoints, NSGs) | — | Identical to EAII-284 — see §5.1.6.1. |

### 5.4.6.2 Services

- `CorporateItemToMetProms` (Function trigger) — Service Bus pull-triggered entry point.
- `CorporateItemToMetPromsService` (business logic) — Downloads XML, transforms via `MetPromsTransformService`, drives the PUT-then-POST-on-404 / 409-discard logic described in §5.4.2.2.
- `MetPromsTransformService` — XML → `item-attribute-records` JSON transformation; returns `null` when the item is not eligible (no IGA-pillar location), causing an upstream skip.

### 5.4.6.2.1 Communication Data Structure

**Message Payload — Function App Output → MetProms PUT/POST (representative sample):**

```
{
  "id": "13011",
  "last-modified-time": "2026-06-25T04:00:00.000Z",
  "attributes": [
    { "type": "OWN_BRAND", "value": false },
    { "type": "SIZE", "value": "350ML" },
    { "type": "TAX_RATE", "value": 10.0 },
    { "type": "PARENT_ITEM_GROUP_ID", "value": "640103" },
    { "type": "ITEM_TYPE", "value": "S-SOFT DRINKS" },
    { "type": "DESCRIPTION", "value": "COCA COLA 1.25L" },
    { "type": "CONSUMER_DESCRIPTION", "value": "SOFT DRINK" },
    { "type": "PRIMARY_UPC", "value": "19300652803096" },
    { "type": "SECONDARY_UPCS", "value": "9300675085021" },
    { "type": "LIKE_ITEM_ID", "value": "6683" },
    { "type": "DEPARTMENT_ID", "value": "06" },
    { "type": "THERAPEUTIC_GOOD", "value": true },
    { "type": "IMAGE_URL", "value": "https://cdn.metcash.media/..." },
    { "type": "IMAGE_TYPE", "value": "front3Dfront_image" }
  ],
  "location-attributes": [
    {
      "id": "NSW",
      "location-type": "STORE_DISTRICT",
      "attributes": [
        { "type": "FAMILY_ID", "value": "1478" },
        { "type": "PACK_SIZE", "value": 12.0 }
      ]
    }
  ]
}
```

`id` = bare Metcash item number. `last-modified-time` is generated by the integration layer at send time (UTC, ISO-8601), not extracted from STIBO — this is what MetProms uses for its 409 out-of-sequence check.

### 5.4.6.3 Audit, Logging & Exceptions

Interface ID = **EAII-385**. Single-call SMC `StartObservation` pattern — see §5.1.6.3.1.

#### 5.4.6.3.3 Exceptions

| Observation Stage | Exception Scenario | Category | Exception Handling |
| --- | --- | --- | --- |
| Blob download | Blob missing/inaccessible | Technical | Propagated → SB redelivery → DLQ. |
| Eligibility filter | Item has no IGA-pillar location | Business | Skip — treated as success, no delivery attempt, no token acquired. |
| Token acquisition | OAuth2 failure | Technical | Propagated → SB redelivery → DLQ. No PUT/POST attempted without a valid token. |
| MetProms PUT | HTTP 404 | Business (expected) | Fall back to POST (create) — not treated as a failure. |
| MetProms PUT or POST | HTTP 409 (stale timestamp) | Business | **Discard** — logged as Skipped, no retry, no DLQ. |
| MetProms PUT or POST | Other 4xx (non-404, non-409) | Business | Non-retryable — immediate failure, SB redelivery → DLQ. |
| MetProms PUT or POST | 5xx / timeout / network error | Technical | Retry up to 3×/2s, then SB redelivery → DLQ. |
| SMC logging | SMC/APIM unavailable | Technical | Caught internally — no message impact. |



====================================================================================================
## DOC: TSD-EAII-289
====================================================================================================

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| **Interface ID** | **Process** | **Component** | **Component Type** | **Change Type** | **Repository** |
| --- | --- | --- | --- | --- | --- |
| EAII-289 | All Operations | APIM API Definition (4 operations) | API | New | Azure DevOps |
| EAII-289 | SearchByABN | APIM Policy (SearchByABN operation) | Policy XML | New | Azure DevOps |
| EAII-289 | SearchByABNv2 | APIM Policy (SearchByABNv2 operation) | Policy XML | New | Azure DevOps |
| EAII-289 | SearchByACN | APIM Policy (SearchByACN operation) | Policy XML | New | Azure DevOps |
| EAII-289 | SearchByACNv2 | APIM Policy (SearchByACNv2 operation) | Policy XML | New | Azure DevOps |
| EAII-289 | SearchByABN, SearchByACN | XSLT v1 Template (ATO XML to MetcashIdentifierBObj JSON) | Transform | New | Azure DevOps |
| EAII-289 | SearchByABNv2, SearchByACNv2 | XSLT v2 Template (ATO XML to MetcashIdentifierBObj JSON) | Transform | New | Azure DevOps |
| EAII-289 | All Operations | Key Vault Secret (ATO API credentials) | Secret | New | Azure Key Vault (data-specific) |

#### 5.1.6.2 Services

APIM API with four operations, each proxying to the corresponding ATO REST backend:

| **APIM Operation** | **Consumer Path** | **ATO Backend** | **Transform** | **Response** |
| --- | --- | --- | --- | --- |
| `SearchByABN` | `/api/ato/SearchByABN` | ATO REST SearchByABN (XML) | XSLT v1 → MetcashIdentifierBObj JSON | JSON |
| `SearchByABNv2` | `/api/ato/SearchByABNv2` | ATO REST SearchByABN (XML) | XSLT v2 → MetcashIdentifierBObj JSON | JSON |
| `SearchByACN` | `/api/ato/SearchByACN` | ATO REST SearchByACN (XML) | XSLT v1 → MetcashIdentifierBObj JSON | JSON |
| `SearchByACNv2` | `/api/ato/SearchByACNv2` | ATO REST SearchByACN (XML) | XSLT v2 → MetcashIdentifierBObj JSON | JSON |

#### 5.1.6.3 Logging

As per SMC specification and below information to be logged

1. Interface ID
2. As below spreadsheet

| **Step** | **Document ID** | **Document Type** | **Delivery Type** | **Direction** | **Source System** | **Destination System** | **Status** | **Reference** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Begin | Transaction ID (GUID) | Business Details Lookup Request | REST/HTTP | Inbound | Consumer App | APIM | Received | ABN or ACN value |
| End (Success) | Transaction ID (GUID) | Business Details Lookup Response | REST/HTTP | Outbound | APIM | Consumer App | Success | HTTP 200 |
| Error (Failure) | Transaction ID (GUID) | Business Details Lookup Fault | REST/HTTP | Outbound | APIM | Consumer App | Error | Fault detail |

##### 5.1.6.3.2 Audit

| **Observation Stage** | **Source/Target App** | **Information Captured**(Reference Keys) | **Description** | **Test Scenario**(FSD) |
| --- | --- | --- | --- | --- |
| Begin | Consumer -> APIM | TransactionID, ABN/ACN, Operation, Request endpoint | Lookup request received | T1 |
| End (Success) | APIM -> Consumer | TransactionID, Status Code (200), Operation | Lookup completed successfully | T1 |
| Error (Failure) | APIM -> Consumer | TransactionID, Fault detail, ATO response, Operation | ATO connectivity or business fault | T6, T7 |

##### 5.1.6.3.3 Exceptions

| **Observation Stage** | **Exception Scenario** | **Exception Category** | **Exception Code** | **Exception Message** | **Exception Handling** | **Status** |
| --- | --- | --- | --- | --- | --- | --- |
| APIM Inbound | ABN missing, empty, or not 11-digit numeric (SearchByABN / SearchByABNv2) | Business | HTTP 400 | ABN query parameter validation failure | APIM returns HTTP 400 JSON error; error event logged to SMC | Response returned |
| APIM Inbound | ACN missing, empty, or not 9-digit numeric (SearchByACN / SearchByACNv2) | Business | HTTP 400 | ACN query parameter validation failure | APIM returns HTTP 400 JSON error; error event logged to SMC | Response returned |
| Backend Call | ATO REST endpoint connectivity failure | Technical | HTTP 502 | Network error or timeout calling ATO | Log error to SMC; return HTTP 502 JSON error | Fault returned |
| Backend Call | ATO returns error response (invalid identifier, auth failure) | Technical | HTTP 502 | ATO error response detail | Log error to SMC; return JSON error with reason | Fault returned |
| Response Processing | XML-to-JSON transform failure (XSLT) | Technical | HTTP 500 | Cannot transform ATO XML response | Log error to SMC with details; return HTTP 500 JSON error | Fault returned |
| Any Stage | Key Vault access failure (ATO credentials unavailable) | Technical | HTTP 500 | Cannot retrieve ATO credentials | Log error to SMC; return HTTP 500 JSON error | Fault returned |
| Any Stage | SMC logging failure | Technical | N/A | SMC unavailable | Continue processing; raise platform alert | Lookup continues |
| Any Stage | Unexpected exception | Technical | HTTP 500 | Unhandled error | On-error policy catch-all; log to SMC; return HTTP 500 JSON error | Fault returned |

##### 5.1.6.3.4 Service consumers

| **Consumer** | **Protocol** | **Description** |
| --- | --- | --- |
| Metcash Internal Consumer Applications (MDM, CRM, Supplier Onboarding) | REST over HTTP/HTTPS | Internal applications performing business entity validation |

##### 5.1.6.3.5 Service Operations

| **Operation** | **Method** | **Path** | **Input** | **Response** | **Description** |
| --- | --- | --- | --- | --- | --- |
| SearchByABN | GET | `/eis/abnlookup/v1/SearchByABN` | `?abn={11-digit}` | JSON (MetcashIdentifierBObj) | ABN lookup via XSLT v1 transform |
| SearchByABNv2 | GET | `/eis/abnlookup/v2/SearchByABN` | `?abn={11-digit}` | JSON (MetcashIdentifierBObj) | ABN lookup via XSLT v2 transform |
| SearchByACN | GET | `/eis/abnlookup/v1/SearchByACN` | `?acn={9-digit}` | JSON (MetcashIdentifierBObj) | ACN lookup via XSLT v1 transform |
| SearchByACNv2 | GET | `/eis/abnlookup/v2/SearchByACN` | `?acn={9-digit}` | JSON (MetcashIdentifierBObj) | ACN lookup via XSLT v2 transform |

##### 5.1.6.3.6 Service Provider

| **Provider** | **Protocol** | **Operations** | **Description** |
| --- | --- | --- | --- |
| Australian Taxation Office (ATO) | REST over HTTP | SearchByABN, SearchByACN | ABN and ACN lookup operations returning XML (2 ATO REST endpoints serving 4 APIM operations) |

##### 5.1.6.3.7 Communications Data Structures

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Sample Files** | **Description** |
| --- | --- | --- | --- | --- | --- |
| Request (ABN) | Query: `abn` (11-digit) | ATO REST: ABN search request | See Mapping Document | `source_samples/abn/` | Consumer query to ATO REST request |
| Request (ACN) | Query: `acn` (9-digit) | ATO REST: ACN search request | See Mapping Document | `source_samples/acn/` | Consumer query to ATO REST request |
| Response (JSON) | ATO XML response | JSON (`MetcashIdentifierBObj`) | See Mapping Document | `target_samples/json/` | ATO XML to canonical JSON |

##### 5.1.6.3.8 Input/Output

| **Operation** | **Input** | **Input Schema** | **Output Schema (JSON)** |
| --- | --- | --- | --- |
| SearchByABN | `GET ...?abn={abn}` | Query: `abn` (11-digit string) | JSON (`MetcashIdentifierBObj`) |
| SearchByABNv2 | `GET ...?abn={abn}` | Query: `abn` (11-digit string) | JSON (`MetcashIdentifierBObj`) |
| SearchByACN | `GET ...?acn={acn}` | Query: `acn` (9-digit string) | JSON (`MetcashIdentifierBObj`) |
| SearchByACNv2 | `GET ...?acn={acn}` | Query: `acn` (9-digit string) | JSON (`MetcashIdentifierBObj`) |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Used By** |
| --- | --- | --- | --- |
| ATO REST — SearchByABN | GET to ATO SearchByABN endpoint | ATO API specification | SearchByABN, SearchByABNv2 operations |
| ATO REST — SearchByACN | GET to ATO SearchByACN endpoint | ATO API specification | SearchByACN, SearchByACNv2 operations |

**5.1.7 SMC Onboarding**

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | Business Details Lookup |
| Source Business Process | MDM |
| Source Application | MDM |
| Destination Business Process | Business Register Lookup |
| Destination Application | Australian Business Register (ATO) |
| Interface ID | EAII-289 |
| Interface Name | ATO Business Details Lookup - Metcash Internal to ATO |
| Interface Type | Synchronous Request-Reply |
| Interface DataStore | N/A (stateless) |
| Tags | `{"division": "corporate", "type": "lookup", "priority": "P3"}` |
| Reference Keys | TransactionID, ABN/ACN, X-Operation |
| Notification Type | Error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-289 |
| Correlation Properties | TransactionID, ABN/ACN |
| Reprocessing Required | No (consumer manages retries) |
| BusinessProcess Name | ATOBusinessDetailsLookup |

#### 5.1.7.2 SMC Load Estimations

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Average lookups/day | ~50–100 (ad-hoc, business-hours only) |
| Volume | Peak lookups/hour | ~20 |
| Volume | Concurrent requests | ≤ 10 |
| Volume | Seasonal considerations | None — stable, non-seasonal usage |
| Volume | Expected growth | Low — stable usage patterns |
| SMC Events | Events per lookup (success) | 2 (Begin + End) |
| SMC Events | Events per lookup (failure) | 2 (Begin + Error) |
| SMC Events | Estimated daily SMC events | 100–200 |



====================================================================================================
## DOC: TSD-EAII-297
====================================================================================================

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| **Component** | **Purpose** |
| --- | --- |
| **Azure Logic App** (`t3-met-data-suppliercontract-{env}-ae-logic`) | Core orchestration workflow that receives requests from APIM, validates the request, invokes the IBM MDM SOAP service to either obtain or release a supplier number, records SMC observations, and returns the response to Salesforce MetConnect. |
| **App Service Plan** | Hosts the Azure Logic Apps Standard runtime. |
| **Azure API Management** (`t3-met-{env}-ae-apim`) | Exposes the **Get New Supplier Number** and **Release Reserved Supplier Number** REST APIs, performs OAuth 2.0 Bearer token authentication, executes API policies, routes requests to the appropriate Logic App workflow, and provides centralized monitoring. |
| **Azure Application Gateway** (`t1-met-core-{env}-ae1-apg-01`) | Provides secure routes external requests to Azure API Management. |
| **Azure Key Vault** (`t3b2b{env}ae1kv01`) | Stores IBM MDM credentials, client certificates, and other integration-specific secrets. Accessed securely using the Logic Apps' Managed Identity. |
| **Platform Key Vault** (`t3enabling{env}ae1kv01`) | Stores shared platform certificates, secrets, and configuration managed by the Enabling Platform team. |
| **Application Insights (Logic Apps)** | Captures Logic App telemetry, dependency tracking, exceptions, and performance metrics. |
| **Application Insights (APIM)** | Captures API Management gateway telemetry, request metrics, latency, authentication failures, and dependency information. |
| **Log Analytics Workspace** | Central repository for Application Insights telemetry, diagnostic logs, and operational monitoring. |
| **AIS Spoke Virtual Network** (`t2-met-ais-{env}-ae1-net-01`) | Provides network isolation and Virtual Network Integration for the Logic Apps and supporting Azure resources. |

#### 5.1.6.2 Services

The solution comprises the following services:

- **APIM** — Exposes the **Get New Supplier Number** and **Release Reserved Supplier Number** REST endpoints to Salesforce MetConnect. Performs OAuth 2.0 Bearer token authentication, executes API policies, and routes requests to the appropriate Azure Logic App workflow.
- **Get New Supplier Number** - Orchestrates the end-to-end workflow for generating a new supplier number, including request validation, transaction ID generation, IBM MDM `getNextSupplierNumber` SOAP service invocation, supplier number formatting, auditing, and response handling.
- **Release Reserved Supplier Number -** Orchestrates the workflow for releasing a reserved supplier number, including request validation, transaction ID generation, IBM MDM `clearReservedSupplierNumbers` SOAP service invocation, auditing, and response handling.

#### 5.1.6.3 Audit, Logging & Exceptions

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

- Interface ID = `EAII-297`
- All significant events, including successful completions and errors, will be logged in SMC for monitoring and debugging purposes.

| **Sr. No.** | **API Name** | **Description** | **API URL** | **Method** |
| --- | --- | --- | --- | --- |
| 1 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The StartObservation API initiates the monitoring process for a business interface in AIS by creating an observation instance. | met-{env}-ae-apim/smc/startObservation | POST |
| 2 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The ObservationPoint API is utilized to update the stage, status and other details of an ongoing observation for a business interface in AIS. | met-{env}-ae-apim/smc/observationPoint | POST |

##### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interface are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to [https://metcash.atlassian.net/wiki/x/BQC_dg](https://metcash.atlassian.net/wiki/x/BQC_dg) .

It uses **SMC** for end-to-end transaction observability across the integration flow and **Azure Application Insights** for Azure resource telemetry, diagnostics, and performance monitoring.

| **Component** | **Azure Resource Provider** | **Purpose** |
| --- | --- | --- |
| **SMC** | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, correlation, and auditing across Azure services and IBM MDM. |
| **Application Insights** | Microsoft.Insights/components | Captures Logic App and API Management telemetry, request traces, dependency calls, exceptions, and performance metrics. |
| **Azure Monitor** | Microsoft.Insights/* | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights for operational monitoring. |

##### 5.1.6.3.3 Exceptions

| **Observation Stage** | **Exception Scenario** | **Exception Code** | **Exception Handling** |
| --- | --- | --- | --- |
| Authentication (APIM) | Missing Authorization header | EAII297-001 | Return **HTTP 401 Unauthorized**; log authentication failure to **SMC** and **Application Insights**. |
| Authentication (APIM) | Invalid or expired OAuth access token | EAII297-002 | Return **HTTP 401 Unauthorized**; log authentication failure to **SMC** and **Application Insights**. |
| Authentication (APIM) | Insufficient OAuth permissions | EAII297-003 | Return **HTTP 403 Forbidden**; log security event to **SMC** and **Application Insights**. |
| Schema Validation (APIM) | Invalid request payload | EAII297-004 | Return **HTTP 400 Bad Request**; log validation failure to **Application Insights**. |
| Input Validation (Logic App) | Missing or invalid Agreement ID | EAII297-005 | Return **HTTP 400 Bad Request** with validation details; log validation failure. |
| IBM MDM Connectivity | Unable to establish connection to IBM MDM | EAII297-006 | Retry up to **3 attempts**. If unsuccessful, log the failure, return the configured failure response, and send an alert to [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| IBM MDM Authentication | Invalid IBM MDM credentials or WS-Security authentication failure | EAII297-007 | Log authentication failure, return the configured failure response, and send an alert to [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| IBM MDM Transport Security | Mutual TLS (mTLS) certificate validation failure | EAII297-008 | Log the certificate validation failure, return the configured failure response, and send an alert to [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| IBM MDM Service | `getNextSupplierNumber` SOAP fault | EAII297-009 | Retry up to **3 attempts**. If the fault persists, log the exception and return the configured failure response. |
| IBM MDM Service | `clearReservedSupplierNumbers` SOAP fault | EAII297-010 | Retry up to **3 attempts**. If the fault persists, log the exception and return the configured failure response. |
| IBM MDM Service | SOAP request timeout | EAII297-011 | Retry up to **3 attempts**. If the timeout persists, log the timeout and return the configured failure response. |
| Response Processing | Failed to format or process the supplier number response | EAII297-012 | Log the processing failure and return the configured failure response. |
| SMC Logging | Failed to record transaction in SMC | EAII297-013 | Log a warning to **Application Insights** and continue processing. Do not fail the API request. |
| Application Insights | Failed to write telemetry | EAII297-014 | Continue processing; no impact to the API response. |
| Global Error Handler | Any unhandled exception | EAII297-015 | Log the exception and transaction details to **Application Insights** and **SMC**, return the configured failure response, and send an alert to [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |

##### 5.1.6.3.4 Service consumers

**Salesforce MetConnect** — Invokes the **Get New Supplier Number** and **Release Reserved Supplier Number** APIs to reserve or release supplier numbers as part of the Supplier Agreement lifecycle.

Both operations are exposed through the same Azure API Management instance using separate REST endpoints:

- **Get New Supplier Number** – Requests a new supplier number from IBM MDM for the specified Agreement ID.
- **Release Reserved Supplier Number** – Releases a previously reserved supplier number associated with the specified Agreement ID.

The request is routed to the appropriate Azure Logic App workflow based on the API endpoint invoked.

##### 5.1.6.3.5 Service Operations

| **Operation** | **Protocol** | **Method** | **Endpoint** | **Description** |
| --- | --- | --- | --- | --- |
| **Get New Supplier Number** | HTTPS | POST | `/mdm/newsupplier/v1` | Requests a new supplier number from IBM MDM for the specified Agreement ID and returns the generated supplier number. |
| **Release Reserved Supplier Number** | HTTPS | POST | `/mdm/releasesupplier/v1` | Releases a previously reserved supplier number in IBM MDM for the specified Agreement ID and returns the operation status. |

##### 5.1.6.3.6 Service Provider

| **Service / Component** | **Provider** | **Responsibility** |
| --- | --- | --- |
| **IBM MDM – getNextSupplierNumber SOAP Service** | Metcash — MDM Platform Team | Generates and reserves a new supplier number for the specified Agreement ID and returns the generated supplier number. |
| **IBM MDM – clearReservedSupplierNumbers SOAP Service** | Metcash — MDM Platform Team | Releases a previously reserved supplier number associated with the specified Agreement ID and returns the operation status. |
| **IBM MDM SOAP Endpoint** | Metcash — Infrastructure / MDM Platform Team | Provides the secure SOAP endpoint used by the Azure Logic Apps to invoke the Supplier Number Management services over HTTPS using WS-Security UsernameToken and Mutual TLS (mTLS). |

##### 5.1.6.3.7 Communications Data Structures

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Description** |
| --- | --- | --- | --- | --- |
| **Salesforce MetConnect → APIM** | Get New Supplier Number Request / Release Reserved Supplier Number Request | NA | Mapping – EAII-297 | REST JSON request from Salesforce MetConnect. |
| **APIM → Logic App** | Get New Supplier Number Request (JSON) / Release Reserved Supplier Number Request (JSON) | NA | NA | Request forwarded to the appropriate Logic App after authentication and API policy validation. |
| **Logic App → IBM MDM** | IBM MDM SOAP Request | IBM MDM SOAP Response | Mapping – EAII-297 | Logic App transforms the inbound JSON request into the appropriate IBM MDM SOAP request (`getNextSupplierNumber` or `clearReservedSupplierNumbers`) and processes the SOAP response. |
| **Logic App → APIM** | NA | Get New Supplier Number Response (JSON) / Release Reserved Supplier Number Response (JSON) | Mapping – EAII-297 | Logic App transforms the IBM MDM SOAP response into the corresponding REST JSON response and returns it to Salesforce MetConnect. |

##### 5.1.6.3.8 Input/Output

**Get New Supplier Number:**

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | Receive Salesforce REST request | `TransactionID` (optional string), `SourceSystemID` (optional string), `AgreementID` (mandatory string) | `{"TransactionID":"001Rl00001O9viJIAR_20260709160955","SourceSystemID":"Salesforce","AgreementID":"P00029015"}` |
| Output | Return Salesforce REST response | `TransactionID` (string), `SourceSystemID` (optional string), `AgreementID` (string), `SupplierNumber` (string, 7 digits, format: 10 + 5-digit padded sequence) | `{"TransactionID":"001Rl00001O9viJIAR_20260709160955","SourceSystemID":"Salesforce","AgreementID":"P00029015","SupplierNumber":"1012695"}` |

**Release Reserved Supplier Number:**

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | Receive Salesforce REST request | `TransactionID` (optional string), `SourceSystemID` (optional string), `AgreementID` (mandatory string) | `{"TransactionID":"P00028593_20260709183546","SourceSystemID":"Salesforce","AgreementID":"P00028593"}` |
| Output | Return Salesforce REST response | `TransactionID` (string), `SourceSystemID` (optional string), `AgreementID` (string), `SuccessString` (string, MDM TxResult/ResultCode, e.g. `"01"` for success or `"FAILED"` on error) |  |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| IBM MDM Supplier Number Service | `getNextSupplierNumber` | `GetNextSupplierNumberInputType` / `GetNextSupplierNumberOutputType` (WSDL: `MTTSUPServices.wsdl`) | MDM response: `{"MTTSupNumbersBObj":{"Parent":"P00029015","ReferenceNumber":"12695"}}` (agent-derived from target response sample) |
| IBM MDM Supplier Number Service | `clearReservedSupplierNumbers` | `ClearReservedSupplierNumbersInputType` / `ClearReservedSupplierNumbersOutputType` (WSDL: `MTTSUPServices.wsdl`) | MDM response: `{"TxResult":{"ResultCode":"01"},"MTTSupNumbersBObj":{"Parent":"P00028593"}}` (agent-derived from target response sample) |



====================================================================================================
## DOC: TSD-EAII-301_302_516_517
====================================================================================================

#### 5.1.6 Service High-Level Design

##### 5.1.6.1 Component List

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts `MDMSupplierInfoToEIM` (and the other three interfaces' functions — shared host: EAII-517, EAII-516, EAII-302). |
| Azure Service Bus Subscription (`toeaim.supplierinfo`, on shared topic) | `Microsoft.ServiceBus/topics` | Delivers the reference message. |
| MDM REST API | N/A | Supplier contract data retrieval — no authentication (plain REST PUT). |
| Azure Blob Storage (`eim/toeim/supplierinfo`) | `Microsoft.Storage/storageAccounts` | Output flat-file location, monitored by GoAnywhere. Reuses existing `t3data{env}aesta01` account. |
| Azure Key Vault (AIS + Enabling) | `Microsoft.KeyVault/vaults` | SMC subscription key, PIM OAuth client credentials (EAII-302) — existing vaults, reused. |
| Application Insights / SMC (via APIM) | N/A | Observability — see §3.2 Error Handling and Monitoring. |

##### 5.1.6.2 Services

- `MDMSupplierInfoToEIM` (Function trigger) — Service Bus pull-triggered entry point using standard default trigger concurrency.
- `MDMSupplierInfoToEIM` service (business logic) — Calls the MDM REST client, runs dedup, transforms to the 11 record types, assembles the flat file, uploads to Blob.
- Shared `MdmService` (library, shared with EAII-517/516/302) — Builds the MDM request, sends the unauthenticated REST PUT, parses the response.
- In-message dedup logic — deduplicates repeated reference-data values, scoped per invocation (no persisted state — see §5.1.3.2).
- `SupplierContractToEimTransformService` — MDM XML → 11 pipe-delimited record types, per the mapping document.

##### 5.1.6.3 Audit, Logging & Exceptions

###### 5.1.6.3.1 Logging

As per the SMC specification, the following information is logged.

Interface IDs = EAII-301 (Supplier MDM → EIM), EAII-517 (Supplier MDM → ALM Sorted), EAII-516 (Supplier MDM → Food Sorted), EAII-302 (Supplier MDM → STIBO STEP PIM)

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and completes the observation for a single Function invocation in one call — `IsObservationComplete = true` is always set, since each of our four interfaces makes exactly one MDM retrieval + one delivery attempt per message (no multi-stage pipeline to report incremental progress on). `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), linking each interface's observation for the same source event. | `{SmcBaseUrl}/{SmcStartObservationApiName}` → `https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1/start-observation` | POST |

###### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interfaces (EAII-301/517/516/302) are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for the Function App (`TrackEvent`/`TrackException`/dependency tracking — see §6.3 Security). |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique correlation ID is generated for each Service Bus message and propagated throughout the entire processing pipeline (MDM retrieval → transformation → delivery). SMC records the lifecycle of each transaction via a single completed observation per Function invocation, enabling end-to-end traceability from the inbound Service Bus trigger through the MDM REST call and delivery to the downstream target (EIM blob, ALM Sorted, Food Sorted, or STIBO STEP PIM).

###### 5.1.6.3.3 Exceptions

| Observation Stage | Failure Scenario | Trigger | Action | Notification |
| --- | --- | --- | --- | --- |
| MDM retrieval | MDM REST API retrieval failure | HTTP error or timeout from MDM REST endpoint | Log error with Transaction ID, PartyId/RequestID context. Dead-letter the message immediately. | Standard DLQ-accumulation alerting (§9.2/monitoring), not a separate email notification. |
| Blob upload | Blob storage upload failure | Error from Azure Blob Storage | Retry up to 3 times with a 2-second fixed delay. On exhaustion, log error and dead-letter the message. | Standard DLQ-accumulation alerting. |
| Transformation | Transformation error | Invalid/unexpected data in MDM message causing mapping failure | Log error with full exception details and correlation identifiers. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |

#### 5.3.6 Service High-Level Design

**5.3.6.1 Component List**

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts `MDMSupplierInfoToALMSorted` (shared host with EAII-301/516/302). |
| Azure Service Bus Subscription (`toalmsorted.supplierinfo`, on shared topic) | `Microsoft.ServiceBus/topics` | Delivers the reference message. |
| MDM REST API | N/A | Supplier contract data retrieval — no authentication (plain REST PUT). |
| ALM Sorted API | N/A | Accepts the supplier JSON payload. No authentication required. |
| Azure Key Vault (AIS) | `Microsoft.KeyVault/vaults` | SMC subscription key — existing vault, reused. |
| Application Insights / SMC (via APIM) | N/A | Observability — see §3.2 Error Handling and Monitoring. |

**5.3.6.2 Services**

- `MDMSupplierInfoToALMSorted` (Function trigger) — Service Bus pull-triggered entry point, manual Service Bus settlement.
- `MdmSupplierInfoToAlmSortedService` (business logic) — downloads the Reference Message, calls MDM once, transforms the response, POSTs to ALM Sorted, applies retry/dead-letter policy.
- Shared `MdmService` (library, shared with EAII-301/516/302) — builds the MDM request, sends the unauthenticated REST PUT, parses the response.
- `AlmSortedTransformService` — MDM XML → supplier JSON structure (legal entity, Pay To/per-state Buy From components, supplier group, core + extended data).
- `AlmSortedHttpService` — POSTs the transformed JSON to ALM Sorted, no authentication.

Representative output:

```
{
  "legalEntityBObj": {
    "legalEntityId": "193452435834868302",
    "legalEntityName": "CORDINA",
    "abn": "29003058428",
    "acn": "003058428"
  },
  "requestType": "getSupplierDetailsByContractId",
  "mTTSupplierDetailsBObj": {
    "mTTSupplierContractBObj": {
      "tCRMContractBObj": {
        "agreementName": "CORDINA CHICKEN FARMS XD",
        "tCRMContractComponentBObj": [
          { "contractComponentValue": "Pay To" },
          { "contractComponentValue": "Buy From", "contractComponentServiceArrangementValue": "NSW" }
        ]
      }
    }
  }
}
```

**5.3.6.3 Audit, Logging & Exceptions**

**5.3.6.3.1 Logging**

As per the SMC specification, the following information is logged.

Interface ID = EAII-517 (Supplier MDM → ALM Sorted)

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and completes the observation for a single Function invocation in one call — `IsObservationComplete = true` is always set, since this interface makes exactly one MDM retrieval + one ALM Sorted delivery attempt per message. `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), linking this interface's observation with EAII-301/516/302's for the same source event. | `{SmcBaseUrl}/{SmcStartObservationApiName}` → `https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1/start-observation` | POST |

**5.3.6.3.2 Audit**

All critical events and exceptions are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for the Function App. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique correlation ID is generated for each Service Bus message and propagated throughout the entire processing pipeline (MDM retrieval → transformation → ALM Sorted delivery). SMC records the lifecycle of each transaction via a single completed observation per Function invocation.

**5.3.6.3.3 Exceptions**

| Observation Stage | Failure Scenario | Trigger | Action | Notification |
| --- | --- | --- | --- | --- |
| MDM retrieval | MDM REST API retrieval failure | HTTP error or timeout from MDM REST endpoint | Log error with Transaction ID/PartyId context. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |
| Transformation | Transformation error | Invalid/unexpected data in MDM response causing mapping failure | Log error with full exception details and correlation identifiers. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |
| ALM Sorted delivery — non-retryable | HTTP 400 | ALM Sorted rejects the payload as invalid | Log error, dead-letter immediately (non-retryable). | Standard DLQ-accumulation alerting. |
| ALM Sorted delivery — transient failure | Other non-2xx response, connectivity failure, or exception | Network error, timeout, or ALM Sorted server error | Retry up to 3 times with a 2-second fixed delay; dead-letter on exhaustion. | Standard DLQ-accumulation alerting. |

**5.3.7 SMC Onboarding and Load**

**5.3.7.1 Integration Onboarding**

| Field | Value |
| --- | --- |
| Interface ID | EAII-517 |
| Interface Name | `MDMSupplierInfoToALMSorted` |
| Source Application | Supplier MDM |
| Destination Application | ALM Sorted |
| Interface Type | Async, event-driven, single-threaded |
| Interface DataStore | N/A (no persistent output store — ALM Sorted delivery only) |
| Reference Keys | CorrelationId, PartyId, Contract Component ID |

**5.3.7.1**Load

| Field | Value |
| --- | --- |
| Interface ID | EAII-517 |
| Interface name | `MDMSupplierInfoToALMSorted` |
| Source | Supplier MDM |
| Destination | ALM Sorted |
| Type | Async, event-driven |
| Data store | N/A |
| Reference keys | CorrelationId, PartyId, Contract Component ID |
| Average volume | 10–15 messages/day |
| Observations | 1 complete observation per message |

**5.3.8 Monitoring**

Application Insights telemetry and one SMC Gen 3 observation per invocation. Monitoring includes Function errors, DLQ accumulation, and target delivery failures.

---

**5.3.9 Reporting**

No bespoke reporting required.

---

**5.3.10 Integration and Testing Requirements**

**5.3.10.1 Development and Integration Strategy**

Standard Function App development lifecycle: local development against sample MDM request/response payloads, deployed per-environment via the existing AIS pipeline pattern.

**5.3.10.2 Unit Testing**

| ADO Test Case ID | Description |
| --- | --- |
| EAII-517-UT-01 | Happy path — successful MDM retrieval, correct transform, ALM Sorted returns HTTP 2xx, message completed |
| EAII-517-UT-02 | MDM retrieval failure (timeout/HTTP error) — message dead-lettered immediately |
| EAII-517-UT-03 | Transformation error (malformed/unexpected MDM data) — message dead-lettered, no ALM Sorted call made |
| EAII-517-UT-04 | ALM Sorted HTTP 400 — non-retryable, message dead-lettered immediately |
| EAII-517-UT-05 | ALM Sorted other non-2xx / connectivity failure — retried up to 3 times, then dead-lettered on exhaustion |
| EAII-517-UT-06 | Multi-component payload — verify Pay To and multiple per-state Buy From components all transform correctly in one message |
| EAII-517-UT-07 | SMC StartObservation failure — flow continues unblocked |
| EAII-517-UT-08 | Endpoint-path confirmation — verify the FSD-documented path (`/occ/v2/alm/mdm/supplier`), not the legacy-config path, is used |

#### 5.4.6 Service High-Level Design

##### 5.4.6.1 Component List

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts `MDMSupplierInfoToSorted` (shared host with EAII-301/517/302). |
| Azure Service Bus Subscription (`tosorted.supplierinfo`, on shared topic) | `Microsoft.ServiceBus/topics` | Delivers the reference message. |
| MDM REST API | N/A | Supplier contract data retrieval — no authentication (plain REST PUT). |
| Food Sorted API | N/A | Accepts the supplier JSON payload. mTLS client-certificate authentication. |
| Platform trust store | N/A | Supplies the leaf + intermediate CA certificate for mTLS. |
| Azure Key Vault (AIS) | `Microsoft.KeyVault/vaults` | SMC subscription key — existing vault, reused. |
| Application Insights / SMC (via APIM) | N/A | Observability — see §3.2 Error Handling and Monitoring. |

##### 5.4.6.2 Services

- `MDMSupplierInfoToSorted` (Function trigger) — Service Bus pull-triggered entry point, manual Service Bus settlement.
- `MdmSupplierInfoToFoodSortedService` (business logic) — downloads the Reference Message, calls MDM once, transforms the response, POSTs to Food Sorted with mTLS, applies retry/dead-letter policy.
- Shared `MdmService` (library, shared with EAII-301/517/302) — builds the MDM request, sends the unauthenticated REST PUT, parses the response.
- `FoodSortedTransformService` — MDM XML → supplier JSON structure, structurally identical shape to `AlmSortedTransformService` but a separate class.
- `FoodSortedHttpService` — POSTs the transformed JSON to Food Sorted using mTLS client-certificate authentication.

##### 5.4.6.3 Audit, Logging & Exceptions

###### 5.4.6.3.1 Logging

As per the SMC specification, the following information is logged.

Interface ID = EAII-516 (Supplier MDM → Food Sorted)

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and completes the observation for a single Function invocation in one call — `IsObservationComplete = true` is always set, since this interface makes exactly one MDM retrieval + one Food Sorted delivery attempt per message. `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), linking this interface's observation with EAII-301/517/302's for the same source event. | `{SmcBaseUrl}/{SmcStartObservationApiName}` → `https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1/start-observation` | POST |

**5.4.6.3.2 Audit**

All critical events and exceptions are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for the Function App. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique correlation ID is generated for each Service Bus message and propagated throughout the entire processing pipeline (MDM retrieval → transformation → Food Sorted delivery). SMC records the lifecycle of each transaction via a single completed observation per Function invocation.

**5.4.6.3.3 Exceptions**

| Observation Stage | Failure Scenario | Trigger | Action | Notification |
| --- | --- | --- | --- | --- |
| MDM retrieval | MDM REST API retrieval failure | HTTP error or timeout from MDM REST endpoint | Log error with Transaction ID/PartyId context. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |
| Transformation | Transformation error | Invalid/unexpected data in MDM response causing mapping failure | Log error with full exception details and correlation identifiers. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |
| mTLS authentication | Certificate rejected or expired | Food Sorted rejects the mTLS handshake | Log error, dead-letter immediately (non-retryable — a bad certificate will not succeed on retry). | Standard DLQ-accumulation alerting; certificate expiry should also be tracked separately for proactive renewal. |
| Food Sorted delivery — transient failure | Non-2xx response, connectivity failure, or exception | Network error, timeout, or Food Sorted server error | Retry up to 3 times with a 2-second fixed delay; dead-letter on exhaustion. | Standard DLQ-accumulation alerting. |

**5.4.7 SMC Onboarding and Load**

**5.4.7.1 Integration Onboarding**

| Field | Value |
| --- | --- |
| Interface ID | EAII-516 |
| Interface Name | `MDMSupplierInfoToSorted` |
| Source Application | Supplier MDM |
| Destination Application | Food Sorted |
| Interface Type | Async, event-driven, single-threaded |
| Interface DataStore | N/A (no persistent output store — Food Sorted delivery only) |
| Reference Keys | CorrelationId, PartyId, Contract Component ID |

**5.4.7.1** Load

| Field | Value |
| --- | --- |
| Interface ID | EAII-516 |
| Interface name | `MDMSupplierInfoToSorted` |
| Source | Supplier MDM |
| Destination | Food Sorted |
| Type | Async, event-driven |
| Data store | N/A |
| Reference keys | CorrelationId, PartyId, Contract Component ID |
| Average volume | 10–15 messages/day |
| Observations | 1 complete observation per message |

---

**5.4.8 Monitoring**

Application Insights telemetry and one SMC Gen 3 observation per invocation. Monitoring covers Function failures, SMC observations, DLQ accumulation, and mTLS certificate expiry.

---

**5.4.9 Reporting**

No bespoke reporting required.

---

**5.4.10 Integration and Testing Requirements**

**5.4.10.1 Development and Integration Strategy**

Standard Function App development lifecycle: local development against sample MDM request/response payloads, deployed per-environment via the existing AIS pipeline pattern.

**5.4.10.2 Unit Testing**

| ADO Test Case ID | Description |
| --- | --- |
| EAII-516-UT-01 | Happy path — successful MDM retrieval, correct transform, Food Sorted returns HTTP 2xx, message completed |
| EAII-516-UT-02 | MDM retrieval failure (timeout/HTTP error) — message dead-lettered immediately |
| EAII-516-UT-03 | Transformation error (malformed/unexpected MDM data) — message dead-lettered, no Food Sorted call made |
| EAII-516-UT-04 | mTLS certificate rejected/expired — non-retryable, message dead-lettered immediately |
| EAII-516-UT-05 | Food Sorted non-2xx / connectivity failure — retried up to 3 times, then dead-lettered on exhaustion |
| EAII-516-UT-06 | Transform-output equivalence — verify `FoodSortedTransformService` produces the same JSON shape as `AlmSortedTransformService` for equivalent input |
| EAII-516-UT-07 | SMC StartObservation failure — flow continues unblocked |
| EAII-516-UT-08 | Endpoint-path confirmation — verify the FSD-documented path (`/metcashcommercewebservices/v2/mdm/supplier`), not the legacy-config path, is used |



====================================================================================================
## DOC: TSD-EAII-304
====================================================================================================

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| Interface ID | Process | Component | Component Type | Change Type | Repository |
| --- | --- | --- | --- | --- | --- |
| EAII-304 | API Exposure | [**cloud-api-{env}.metcash.com**](https://cloud-api-dev.metcash.com) | Azure API Management | Existing | AIS Repository |
| EAII-304 | File Upload | **t3-met-enabling-blobmgnt-{env}-ae-func** | Azure Function | Existing | AIS Repository |
| EAII-304 | Event Routing | **evt-t3b2b{env}aesta01-alm-ibadirects-in-create-sbq-{env}-ae** | Azure Event Grid Subscription | New | AIS Repository |
| EAII-304 | Asynchronous Messaging | **t2-met-{npr/prd}-ae-sb001**<br> <br>Queue: **b2b.ibadirectstoeim.sbq-{env}** | Azure Service Bus (Standard) | New | AIS Repository |
| EAII-304 | Translation Orchestration | **t3-met-b2b-ibadirects-{env}-ae-logic** | Logic App (Standard) | New | AIS Repository |
| EAII-304 | PSV Transformation | **PSV Converter (Inline Azure Function)** | Azure Function | New | AIS Repository |
| EAII-304 | File Storage | **t3b2b{env}aesta01** | Azure Storage Account (Blob) | New | AIS Repository |
| EAII-304 | Secret Management | **t3enabling{env}aekv01**<br>**t3b2b{env}aekv01** | Azure Key Vault | Existing | AIS Repository |

#### 5.1.6.2 Services

The IBA Directs integration is implemented through two logical services:

1. **IBADirects Upload Service** — Responsible for receiving inbound supplier requests, authenticating and validating the payload, storing the source ZIP file, and initiating asynchronous translation processing. **Components:** Azure API Management (APIM), UploadBlob Azure Function, Azure Blob Storage, Azure Event Grid, Azure Service Bus.
2. **IBADirects Translation Service** — Responsible for asynchronously processing the uploaded source files, transforming the extracted data into PSV format, delivering the output files to EIM, and archiving the processed source files. **Components:** Translation Logic App, PSV Converter (Inline Azure Function), Azure Blob Storage, Azure Service Bus, Azure Key Vault, Application Insights, and SMC.

#### 5.1.6.3 *IBADirects Upload Service*

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

- Interface ID = `EAII-304`
- All significant events, including successful completions and errors, will be logged in SMC for monitoring and debugging purposes.

| **Sr. No.** | **API Name** | **Description** | **API URL** | **Method** |
| --- | --- | --- | --- | --- |
| 1 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The StartObservation API initiates the monitoring process for a business interface in AIS by creating an observation instance. | t3-met-{env}-ae-apim/smc/startObservation | POST |
| 2 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The ObservationPoint API is utilized to update the stage, status and other details of an ongoing observation for a business interface in AIS. | t3-met-{env}-ae-apim/smc/observationPoint | POST |

##### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interface are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to [https://metcash.atlassian.net/wiki/x/BQC_dg](https://metcash.atlassian.net/wiki/x/BQC_dg) .

It uses **SMC (Service Monitoring Console)** for end-to-end transaction observability across the integration flow and **Azure Application Insights** for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for Azure resources. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique **Transaction ID (UUID)** is generated for each request and propagated throughout the entire processing pipeline. SMC records the lifecycle of each transaction, enabling complete traceability from the inbound API request through Azure Logic Apps and external IBM AS/400 interactions.

##### 5.1.6.3.3 Exceptions

| Observation Stage | Exception Scenario | Exception Category | Exception Code | Exception Message | Exception Handling |
| --- | --- | --- | --- | --- | --- |
| Authentication | Invalid or missing Bearer token | Business | HTTP-401 | Unauthorized | APIM returns **HTTP 401 Unauthorized**. Authentication failure is logged to SMC and Application Insights. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Payload Validation | Decoded ZIP payload exceeds 3 MB | Business | 400 | File size exceeded | APIM invokes the UploadBlob Azure Function to store the ZIP file in **IBADirects/error**. APIM returns **HTTP 400 Bad Request**. Transaction is logged to SMC. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Payload Validation | Required field **SupplierID** missing | Business | HTTP-400 | Bad Request – Missing required field | APIM returns **HTTP 400 Bad Request** with validation details. File is not uploaded. Validation failure is logged to SMC and Application Insights. |
| Payload Validation | Invalid JSON schema or malformed Base64 payload | Business | HTTP-400 | Bad Request – Invalid request payload | APIM returns **HTTP 400 Bad Request**. File is not uploaded. Validation failure is logged to SMC and Application Insights. |
| Blob Upload | Azure Blob Storage unavailable during upload | Technical | 503 | Cloud storage communication error | APIM retries the backend invocation for transient failures. The UploadBlob Azure Function retries Azure Storage operations (refer **EAII-367 UploadBlob**). If retries are exhausted, APIM returns **HTTP 503 Service Unavailable**. Failure is logged to SMC and Application Insights. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Translation Processing | ZIP decompression failed | Technical | 400 | Failed to decompress source ZIP | Translation Logic App logs the failure to SMC. The Service Bus message is abandoned and retried according to the configured retry policy. After the maximum delivery count is reached, the message is dead-lettered. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Translation Processing | PSV transformation failed | Technical | 400 | Failed to transform JSON to PSV | Translation Logic App logs the failure to SMC. The Service Bus message is abandoned and retried. After retry exhaustion, the message is dead-lettered for investigation. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Output Delivery | Failed to upload PSV file to **IBADirects/ToEIM** | Technical | 500 | Output file upload failed | Translation Logic App retries the Blob Storage operation using its configured retry policy. If retries are exhausted, the transaction is logged to SMC, the Service Bus message is abandoned, and the message is retried or dead-lettered according to Service Bus configuration. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Archive | Failed to archive source ZIP | Technical | 500 | Failed to archive source file | Translation Logic App retries the archive operation. If retries are exhausted, the failure is logged to SMC and the Service Bus message is abandoned for retry or dead-lettering. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Any | Unhandled exception in Translation Logic App or Azure Function | Technical | IBADIRECTS-ERR-UNHANDLED | Unexpected error | Error details are logged to SMC, Application Insights, and Log Analytics. The Service Bus message is abandoned and retried. If the maximum delivery count is exceeded, the message is moved to the dead-letter queue. Notification: [**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |

##### 5.1.6.3.4 Service consumers

- Liquor Suppliers (external systems) — Coopers Brewery, CUB, and any other suppliers onboarded to the IBA Directs service

##### 5.1.6.3.5 Service Operations

| Operation | Method | Path | Description |
| --- | --- | --- | --- |
| Upload Directs File | POST | `eis/ibadirects/v1/submitOrder` | Receives a `DirectsFileDocument` JSON payload from a liquor supplier. Returns a `DirectsResponse` confirming receipt or describing the error. |

##### 5.1.6.3.6 Service Provider

| **Service / Component** | **Provider** | **Responsibility** |
| --- | --- | --- |
| Azure API Management | Microsoft Azure / Metcash AIS Platform | Expose and secure the inbound REST API endpoint |
| Upload Orchestrator Logic App | Metcash AIS Platform | Validate, store, and queue inbound directs files |
| Azure Blob Storage | Microsoft Azure / Metcash AIS Platform | Store source files (input and error containers) |
| Azure Service Bus | Microsoft Azure / Metcash AIS Platform | Decouple upload and translation phases |

##### 5.1.6.3.7 Communications Data Structures

For all Interface Filename Conventions and Parameters, please refer to: [Mapping - EAII-304 - IBA Directs ALM Orders - Liquor Suppliers to EIM](https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3503849480)

##### 5.1.6.3.8 Input/Output

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | POST eis/ibadirects/v1/submitOrder | `DirectsFileDocument` (JSON) — `DocumentHeader.Supplier.SupplierID` (required), `DirectsFile.FileContent` (base64 ZIP, required) | `IBADIRECTS-COOPERSBREWERY-20260615000035.json` |
| Output | HTTP Response | `DirectsResponse` (JSON) — `Code` (integer), `Description` (string) | `{"Code": 200, "Description": "Success"}` |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Azure Blob Storage (`IBADirects/ToEIM`) | Put Blob (PSV file) | `{SourceFileNameWithoutExtension}.PSV` | `IBADIRECTS-COOPERSBREWERY-20260615000035.PSV` |
| Azure Blob Storage (`IBADirects/archive`) | Move Blob | `{SourceFileNameWithoutExtension}.zip` | N/A |



====================================================================================================
## DOC: TSD-EAII-333
====================================================================================================

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| **Interface ID** | **Process** | **Component** | **Component Type** | **Change Type** | **Repository** |
| --- | --- | --- | --- | --- | --- |
| EAII-333 | Campbells Payment Capture | APIM API Definition | API | New | Azure DevOps |
| EAII-333 | Campbells Payment Capture | APIM Policy (Inbound) | Policy XML | New | Azure DevOps |
| EAII-333 | Campbells Payment Capture | APIM Policy (Outbound) | Policy XML | New | Azure DevOps |
| EAII-333 | Campbells Payment Capture | APIM Policy (On-Error) | Policy XML | New | Azure DevOps |
| EAII-333 | Campbells Payment Capture | APIM Backend Entity | Backend Config | New | Azure DevOps |

#### 5.1.6.2 Services

Single service: **EAII-333 Payment Capture API** hosted on Azure API Management.

#### 5.1.6.3 *EAII-333 Payment Capture API*

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

1. Interface ID
2. As below spreadsheet

| **Step** | **Document ID** | **Document Type** | **Delivery Type** | **Direction** | **Source System** | **Destination System** | **Status** | **Reference** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Success | Transaction ID (GUID) | Payment Response | SOAP/HTTP | Outbound | APIM | Storeline | Success | Response Code = 1 |
| Warning | Transaction ID (GUID) | Payment Response | SOAP/HTTP | Outbound | APIM | Storeline | Non-Success | Response Code, Error Message |
| Error | Transaction ID (GUID) | Payment Fault | SOAP/HTTP | Outbound | APIM | Storeline | Error | Exception Details |

##### 5.1.6.3.2 Audit

| **Observation Stage** | **Source/Target App** | **Information Captured**(Reference Keys) | **Description** | **Test Scenario**(FSD) |
| --- | --- | --- | --- | --- |
| Begin | Storeline → APIM | Transaction ID, Order ID, Customer ID, Payment Amount | Payment capture request received | T7 |
| End (Success) | APIM → Storeline | Transaction ID, Order ID, Response Code | Payment capture successful (responseCode=1) | T7 |
| Warning (Non-Success) | APIM → Storeline | Transaction ID, Order ID, Response Code, Error Message | Payment capture declined (responseCode≠1) | T8 |
| Error | APIM → Storeline | Transaction ID, Order ID, Exception Type, Exception Message | Unexpected error during processing | T8 |

##### 5.1.6.3.3 Exceptions

| **Observation Stage** | **Exception Scenario** | **Exception category (technical / Business)** | **Exception Code** | **Exception Message** | **Exception Handling** | **Status** |
| --- | --- | --- | --- | --- | --- | --- |
| Backend Call | Target system connectivity failure | Technical | 130 (HYBRIS-ERROR) | Unable to connect to SAP Commerce Cloud | Log error; return SOAP fault | SOAP Fault returned |
| Backend Call | Target system timeout | Technical | 111 (TIBCO-HYBRIS-TIMEOUT) | SAP Commerce Cloud did not respond within timeout | Log error; return SOAP fault | SOAP Fault returned |
| Backend Call | HTTP 4xx error | Technical | 130 (HYBRIS-ERROR) | Client error from SAP Commerce Cloud | Log error; return SOAP fault | SOAP Fault returned |
| Backend Call | HTTP 5xx error | Technical | 130 (HYBRIS-ERROR) | Server error from SAP Commerce Cloud | Log error; return SOAP fault | SOAP Fault returned |
| Response Processing | Payment capture declined | Business | N/A | responseCode ≠ 1 | Log warning; return response (not fault) | Response returned |
| Any Stage | Unexpected internal error | Technical | 111 (INTERNAL-ERROR) | Unhandled exception | Log error with stack trace; return SOAP fault | SOAP Fault returned |

##### 5.1.6.3.4 Service consumers

| **Consumer** | **Protocol** | **Description** |
| --- | --- | --- |
| Storeline (Campbells Retailers) | SOAP over HTTP/HTTPS | Legacy warehouse/POS system initiating payment capture after pick and pack |

##### 5.1.6.3.5 Service Operations

| **Operation** | **Method** | **Description** |
| --- | --- | --- |
| paymentRequest | SOAP (Request-Reply) | Synchronous payment capture operation |

##### 5.1.6.3.6 Service Provider

| **Provider** | **Protocol** | **Description** |
| --- | --- | --- |
| SAP Commerce Cloud (Sorted) | REST over HTTPS (mutual TLS) | Braintree payment capture endpoint |

##### 5.1.6.3.7 Communications Data Structures

*Place locations for all the mappings, schemas/specs, sample packages here.*

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Sample Files** | **Description** |
| --- | --- | --- | --- | --- | --- |
| Payment Request Mapping | HybrisPaymentRequestWSDL.wsdl (`paymentRequest`) | REST URL (path + query params) | See Mapping Document | Source_sample_request1.xml, Source_sample_request2.xml, Source_sample_request3.xml | SOAP fields → REST URL parameters |

**Response Mapping (JSON → SOAP):**

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Sample Files** | **Description** |
| --- | --- | --- | --- | --- | --- |
| Payment Response Mapping | JSON (responseCode, extendedErrorCode, message) | HybrisPaymentRequestWSDL.wsdl (`paymentResponse`) | See Mapping Document | Source_sample_response1.xml, Source_sample_response2.xml, Source_sample_response3.xml | JSON response → SOAP response with conditional error formatting |

**Request Field Mapping:**

| **Source Field** | **Source Path** | **Data Type** | **Target Parameter** | **Parameter Type** | **Transformation** |
| --- | --- | --- | --- | --- | --- |
| customerId | paymentRequest/customerId | xs:string | N/A (logging only) | N/A | Not forwarded to target - used for audit logging |
| orderId | paymentRequest/orderId | xs:string | {orderId} | URL Path | Direct mapping - 10-digit zero-padded |
| paymentAmount | paymentRequest/paymentAmount | xs:double | captureAmount | URL Query String | Cast to decimal (scientific notation → integer, e.g., 2.9674E4 → 29674) |
| requestTimeout | paymentRequest/requestTimeout | xs:integer | N/A | N/A | Not forwarded - timeout managed at HTTP client config |

**Response Field Mapping:**

| **Source Field (JSON)** | **Data Type** | **Target Field (SOAP)** | **Transformation** |
| --- | --- | --- | --- |
| responseCode | integer | responseCode | Direct mapping (1=success, 2=error with code, other=general failure) |
| extendedErrorCode | string | extendedErrorCode | Conditional - only included when present in source |
| message | string | message | If responseCode=2: `"Error {extendedErrorCode} - {message}"`; else: pass-through as-is |

**Target REST URL Construction:**

```
POST https://{host}/occ/v2/campbellsretailersspa/orders/{orderId}/braintree/paymentcapture?captureAmount={captureAmount}
```

- Request body: Empty
- Content-Type: N/A
- Authentication: Mutual TLS (client certificate)

##### 5.1.6.3.8 Input/Output

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input | paymentRequest (SOAP) | HybrisPaymentRequestWSDL.wsdl | See Source_sample_request1.xml |
| Output | paymentResponse (SOAP) | HybrisPaymentRequestWSDL.wsdl | See Source_sample_response1.xml |

**Sample Input (SOAP Body):**

```
<paymentRequest xmlns="http://www.campbells.com.au/PaymentRequestService/">

  <customerId xmlns="">0033764325</customerId>

  <orderId xmlns="">0040797969</orderId>

  <paymentAmount xmlns="">2.9674E4</paymentAmount>

  <requestTimeout xmlns="">30000</requestTimeout>

</paymentRequest>
```

**Sample Output - Success (SOAP Body):**

```
<tns2:paymentResponse xmlns:tns2="/T1650939449914Converted/JsonSchema">

  <tns2:responseCode>1</tns2:responseCode>

  <tns2:extendedErrorCode>0</tns2:extendedErrorCode>

  <tns2:message>SUCCESFULL</tns2:message>

</tns2:paymentResponse>
```

**Sample Output - Error (SOAP Body):**

```
<tns2:paymentResponse xmlns:tns2="/T1650939449914Converted/JsonSchema">

  <tns2:responseCode>2</tns2:responseCode>

  <tns2:extendedErrorCode>4001</tns2:extendedErrorCode>

  <tns2:message>Error 4001 - Insufficient funds</tns2:message>

</tns2:paymentResponse>
```

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| SAP Commerce Cloud Braintree Payment Capture | POST /occ/v2/campbellsretailersspa/orders/{orderId}/braintree/paymentcapture | JSON response: {responseCode, extendedErrorCode, message} | `{"responseCode":1,"extendedErrorCode":"0","message":"SUCCESFULL"}` |



====================================================================================================
## DOC: TSD-EAII-514
====================================================================================================

### 5.1.6 Service High Level Design

#### 5.1.6.1 Component List

The following tables captures the overview of the processes, components and messages impacted, and / or required to be modified / created for this project:

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| **Azure Logic App** (`t3-met-b2b-realtimepricing-{env}-ae-logic`) | `Microsoft.Logic/workflows` | Core orchestration workflow that receives requests from APIM, validates input, invokes the AS/400 stored procedure, aggregates results, and returns the pricing response. |
| **App Service Plan** | `Microsoft.Web/serverfarms` | Hosts the Logic App Standard runtime. |
| **Azure API Management** (`t3-met-core-{env}-ae-apim`) | `Microsoft.ApiManagement/service` | Exposes REST endpoint, performs authentication, schema validation, protocol transformation, and request routing. |
| **Azure Application Gateway** (`t1-met-core-{env}-ae1-apg-01`) | `Microsoft.Network/applicationGateways` | Provides secure Layer to APIM. |
| **Azure Key Vault** (`t3b2b{env}ae1kv01`) | `Microsoft.KeyVault/vaults` | Stores AS/400 JDBC connection details and credentials. Accessed using Managed Identity. |
| **Platform Key Vault** (`t3enabling{env}ae1kv01`) | `Microsoft.KeyVault/vaults` | Stores shared platform secrets and configuration. |
| **Log Analytics Workspace** (`t3-met-b2b-realtimepricing-{env}-ae-law`) | `Microsoft.OperationalInsights/workspaces` | Central repository for SMC logs, diagnostics, and platform monitoring. |
| **AIS Spoke Virtual Network** (`t2-met-ais-{env}-ae1-net-01`) | `Microsoft.Network/virtualNetworks` | Provides network isolation and VNet Integration for the Logic App. |
| **Private Endpoints** | `Microsoft.Network/privateEndpoints` | Enables private connectivity to Key Vault, Storage Account, App Configuration, and SMC. |
| **Private DNS Zones** | `Microsoft.Network/privateDnsZones` | Resolves Azure PaaS services to Private Endpoint IP addresses. |
| **Network Security Groups** | `Microsoft.Network/networkSecurityGroups` | Controls inbound and outbound subnet traffic. |

#### 5.1.6.2 Services

The solution comprises the following services:

1. **APIM Pricing API** — Exposes the REST pricing endpoint to Sorted consumers; handles authentication, schema validation, and routing.
2. **Pricing Orchestrator Logic App** — Orchestrates the end-to-end pricing workflow (DB outage check, validation, per-product iteration, response aggregation).

#### 5.1.6.3 Audit, Logging & Exceptions

##### 5.1.6.3.1 Logging

As per SMC specification and below information to be logged

- Interface ID = `EAII-514`
- All significant events, including successful completions and errors, will be logged in SMC for monitoring and debugging purposes.

| **Sr. No.** | **API Name** | **Description** | **API URL** | **Method** |
| --- | --- | --- | --- | --- |
| 1 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The StartObservation API initiates the monitoring process for a business interface in AIS by creating an observation instance. | t3-met-{env}-ae-apim/smc/startObservation | POST |
| 2 | [/wiki/spaces/MDTS/pages/1854636053](https://metcash.atlassian.net/wiki/spaces/MDTS/pages/1854636053) | The ObservationPoint API is utilized to update the stage, status and other details of an ongoing observation for a business interface in AIS. | t3-met-{env}-ae-apim/smc/observationPoint | POST |

##### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interface are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to [https://metcash.atlassian.net/wiki/x/BQC_dg](https://metcash.atlassian.net/wiki/x/BQC_dg) .

It uses **SMC** for end-to-end transaction observability across the integration flow.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |

SMC is the primary observability platform for the integration. A unique **Transaction ID (UUID)** is generated for each request and propagated throughout the entire processing pipeline. SMC records the lifecycle of each transaction, enabling complete traceability from the inbound API request through Azure Logic Apps and external IBM AS/400 interactions.

##### 5.1.6.3.3 Exceptions

| Observation Stage | Exception Scenario | Exception Code | Exception Handling |
| --- | --- | --- | --- |
| Authentication (APIM) | Missing Authorization header | EAII514-001 | Return **HTTP 401 Unauthorized** (REST); log authentication failure to SMC. |
| Authentication (APIM) | Invalid or expired OAuth access token | EAII514-002 | Return **HTTP 401 Unauthorized** (REST); log authentication failure to SMC. |
| Authentication (APIM) | Insufficient OAuth permissions | EAII514-003 | Return **HTTP 403 Forbidden** (REST); log security event to SMC. |
| Schema Validation (APIM) | Invalid JSON schema | EAII514-004 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| Input Validation (APIM) | Company code not "MTT" | EAII514-005 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| Input Validation (APIM) | Invalid Pillar code | EAII514-006 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| Input Validation (APIM) | Invalid PriceDate format | EAII514-007 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| Input Validation (APIM) | More than 20 products | EAII514-008 | Return **HTTP 400 Bad Request** (REST); log validation error. |
| DB Outage Check (APIM) | dbOutageFlag = true | EAII514-009 | Return **HTTP 503 Service Unavailable** (REST); log to SMC; **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Azure Inline Function | Request transformation failure | EAII514-010 | Log error event with exception details; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| AS/400 Connectivity | Unable to establish connection to AS/400 | EAII514-011 | Log connectivity failure and transaction history; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| AS/400 Authentication | Invalid AS/400 credentials | EAII514-012 | Log authentication failure; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| AS/400 Authorization | User not authorized to execute stored procedure | EAII514-013 | Log authorization failure; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| JDBC Driver | IBM AS/400 JDBC driver initialization failure | EAII514-014 | Log driver initialization error; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| SP Call | Stored procedure CX40K6B unavailable | EAII514-015 | Log stored procedure execution failure; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| SP Call | JDBC connection timeout or SQL exception | EAII514-016 | Log error event with fault details and transaction history; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| SP Call | Query timeout (30 seconds) exceeded | EAII514-017 | Log timeout error; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| SP Call | Product-level error (XOERROR = "Y") | EAII514-018 | Populate **ErrorMsg** in the corresponding **PriceData** element and continue processing the remaining products. Do **not** fail the overall request. |
| Response Processing | Failed to aggregate or serialize response | EAII514-019 | Log response processing failure; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |
| Global Error Handler | Any unhandled exception | EAII514-099 | Log error event and transaction history; return **HTTP 500** (REST); **send alert to**[**IntegrationSupport@metcash.com**](mailto:IntegrationSupport@metcash.com). |

##### 5.1.6.3.4 Service consumers

- **Sorted - IGA Portal** — places orders for IGA retailers via the ordering platform
- **Sorted - Campbells Portal** — places orders for Campbells customers
- **Sorted - C-Store Portal** — places orders for C-Store customers

All consumers invoke the same REST endpoint. Consumer identity is distinguished by the `Pillar` field in the request (`IGA`, `ALM`, `CCC`, `CSD`).

##### 5.1.6.3.5 Service Operations

| Operation | Protocol | Method | Endpoint | Description |
| --- | --- | --- | --- | --- |
| GetPricing (REST) | HTTPS | POST | `/eis/pricing/v1/getrealtimeprice` | Real-time pricing lookup — returns `PriceDataResponsev2` as JSON |

##### 5.1.6.3.6 Service Provider

| **Service / Component** | **Provider** | **Responsibility** |
| --- | --- | --- |
| CX40K6B Stored Procedure | Metcash — PE / AS/400 Platform team | Executes pricing calculation logic; returns pricing output fields per product |
| On-Premises Data Gateway | Metcash — Infrastructure / Cloud Platform team | Bridges Azure VNet to IBM AS/400 JDBC |

##### 5.1.6.3.7 Communications Data Structures

| **Stage Name** | **Input Schema** | **Output Schema** | **Mapping Sheet** | **Description** |
| --- | --- | --- | --- | --- |
| REST Consumer → APIM | PriceDataRequest (JSON) | NA | [Mapping - EAII-514](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) | REST JSON request from Sorted consumer |
| APIM → Logic App | PriceDataRequest (JSON) | NA | NA | Forwarded request after APIM auth/validation |
| Logic App → AS/400 SP | CX40K6B Input Parameters (JDBC) | CX40K6B Output Parameters (JDBC) | [Mapping - EAII-514](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) | Stored procedure JDBC call |
| Logic App → Consumer (REST) | NA | PriceDataResponsev2 (JSON) | [Mapping - EAII-514](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) | REST JSON response to Sorted consumer |

For all field-level mapping details, transformation logic, and sample payloads, refer to the [Mapping - EAII-514 - Realtime Pricing - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE).

##### 5.1.6.3.8 Input/Output

| **Operation Type** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| Input (REST) | POST PriceDataRequest | `PriceDataRequest` — JSON: Company (MTT), Pillar (IGA/ALM/CCC/CSD), Department, WarehouseId, CustomerId, PriceDate (YYYY-MM-DD), Product[] (max 20) | ![diagram](images/08.png)<br> <br>![diagram](images/05.png) |
| Output (REST) | PriceDataResponsev2 | JSON: Company, Pillar, Department, WarehouseId, CustomerId, PriceDate (echo); PriceData[] — per product: Product, ProductPrice, Allowance, UnitProductPrice, ErrorMsg (conditional), OriginalProductPrice, OriginalUnitProductPrice, RRPorSRP, RetailMarginPercent, CartonExcludingGST, SingleUnitPriceExcGST | ![diagram](images/08.png)<br> <br>![diagram](images/05.png) |

##### 5.1.6.3.9 Fulfillment Services

| **Service Name** | **Operation** | **Schema/Specs** | **Sample** |
| --- | --- | --- | --- |
| IBM AS/400 PE CX40K6B | CALL IDSPNDUR1.CX40K6B | Input: XPCMPN, XPDIVN, XPDPTN, XPWHSN, XPCUSN, XPITMN, XPDTES, XPSFLG (all CHAR/DECIMAL).<br> <br>Output: XOTTLP, XOTAWP, XOLUCA, XOEMSG, XZPRCG, XZLUCA, XOPRCE, XOPRFP, XZPGST, XZPEXG, XOERROR. | N/A |
