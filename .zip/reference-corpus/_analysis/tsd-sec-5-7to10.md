

====================================================================================================
## DOC: TSD-EAII-284_283_282_385
====================================================================================================

## 5.1.7 SMC Onboarding

### 5.1.7.1 Integration Onboarding

| Field | Value |
| --- | --- |
| Business Process | STIBO to IndiPIM Corporate Item Distribution |
| Source Business Process | MetProducts PIM Publish |
| Source Application | STIBO |
| Destination Business Process | IndiPIM Ingestion |
| Destination Application | IndiPIM |
| Interface ID | EAII-284 |
| Interface Name | STIBO_to_IndiPIM_CorporateItem |
| Interface Type | Async, event-driven, pass-through |
| Interface DataStore | Azure Blob Storage (`stibo/frompim/corporateitem`) |
| Reference Keys | CorrelationId |
| Notification Type | Email on error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Correlation Properties | CorrelationId |
| Reprocessing Required | Yes — via SMC replay of source blob within 30-day retention window |

### 5.1.7.2 SMC Load Estimations

SMC logging is enabled on every invocation (`IsObservationComplete = true`, single complete observation per Function execution) — there is no on-demand/configuration-flag gating of SMC logging for this interface, so the load estimations below equal the full message volume.

| Category | Sub-category | Requirement |
| --- | --- | --- |
| Volume | Average volume | 500 items/day average (~21/hour) — per FSD §3.1.6 |
| Volume | Peak volume | 5,000 items/day peak (~208/hour) — per FSD §3.1.6 |
| Volume | Target capacity | 10,000 items/day (~417/hour) — headroom for Christmas peak and post-Horizon growth |
| Volume | Seasonal considerations | Christmas peak drives highest STIBO publication volumes; no scheduled outage window — IndiPIM downtime handled via retry/DLQ, not a gating flag |
| Message Size | Average request | ~500 KB per STEP XML (pass-through) |
| Message Size | Average response | N/A — IndiPIM returns an HTTP status only; no response body persisted to SMC |
| Message Size | SMC observation payload size | Small — one `ReqStartObservation` JSON object per invocation, containing CorrelationId, InterfaceID, exception detail (if any), and the `LogMessage` stage array (typically 2–4 entries) |

## 5.1.8 Monitoring

Application Insights telemetry per invocation; SMC Gen 3 observation per invocation; Azure Monitor alerting on DLQ accumulation and Function error rate.

## 5.1.9 Reporting

NA — No bespoke reporting is required. Operational reporting is provided via SMC dashboards (§5.1.8).

## 5.1.10 Integration and Testing Requirements

### 5.1.10.1 Development and Integration Strategy

Developer develops solution on their own workstation using development tools. After sound unit testing cases are completed, the binary is deployed to the target runtime environment through the automated build and deployment process (Azure DevOps).

### 5.1.10.2 Unit Testing

Sample source files: `1360581885952-1360581885952-682179.xml`, `1375178063872-1375178063872-40007694.xml`.

| ADO Test Case ID | Description |
| --- | --- |
| TC-001 | Corporate item published from PIM — verify STEP XML is delivered to IndiPIM via HTTP POST, byte-for-byte identical to the source XML, with a valid OAuth bearer token attached |
| TC-002 | OAuth token expired during processing — verify the cached token is refreshed automatically (300s pre-refresh buffer) and the message is delivered successfully |
| TC-003 | HTTP 401 from IndiPIM — verify the cached token is invalidated, a fresh token is acquired, and the request is retried once; verify success on the retried attempt |
| TC-004 | EAII284-005: IndiPIM returns HTTP 5xx — verify retry up to 3 attempts with a fixed 2-second delay; on exhaustion, verify `ProcessingResult.Failure` with `lastErrorDetail` populated |
| TC-005 | EAII284-004: IndiPIM returns a non-retryable HTTP 4xx (excl. 401) — verify immediate failure with no retry attempt |
| TC-006 | EAII284-001: Blob missing/inaccessible — verify the exception propagates for Service Bus redelivery |
| TC-007 | EAII284-002: Auth0 token endpoint unreachable/invalid credentials — verify no POST attempt is made and the exception propagates |
| TC-008 | EAII284-006: Network-level exception during POST on an attempt before the final one — verify it is treated as retryable |
| TC-009 | EAII284-007: SMC `StartObservation` call fails (simulated outage) — verify message processing still completes successfully |
| TC-010 | Pass-through integrity — verify no field-level transformation occurs; content-type `application/xml`; payload bytes match the source blob exactly |
| TC-011 | Correlation ID resolution — verify native message property → `ApplicationProperties["CorrelationId"]` → new GUID fallback precedence |
| TC-012 | Telemetry — verify `Triggered`/`Completed` events fire correctly on success, and `Completed` is **not** emitted when `ProcessAsync` throws |
| TC-013 | Known issue: unnecessary update triggers — document current pass-through behaviour (no relevance filtering) |
| TC-014 | Known issue: no out-of-sequence protection — verify two out-of-order messages are both forwarded independently, no sequencing check |

## 5.2.7 SMC Onboarding

### 5.2.7.1 Integration Onboarding

| Field | Value |
| --- | --- |
| Interface ID | EAII-283 |
| Interface Name | STIBO_to_Sorted_CorporateItem |
| Source Application | STIBO |
| Destination Application | Sorted |
| Interface Type | Async, event-driven |
| Interface DataStore | Azure Blob Storage (`stibo/frompim/corporateitem`) |
| Reference Keys | CorrelationId |
| Notification Type | Email on error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Reprocessing Required | Yes — via SMC replay within 30-day blob retention window |

### 5.2.7.2 SMC Load Estimations

| Category | Sub-category | Requirement |
| --- | --- | --- |
| Volume | Average volume | 500 items/day average (~21/hour), 5,000 items/day peak (~208/hour), 10% expected growth — per FSD §3.2.6 |
| Message Size | Average message size | ~500 KB per STEP XML; JSON output is smaller |
| SMC observation count per message | — | 1 (single complete `StartObservation` call, `IsObservationComplete = true`) |

## 5.2.8 Monitoring

Application Insights telemetry per invocation; SMC Gen 3 observation per invocation; Azure Monitor alerting on DLQ accumulation and Function error rate.

## 5.2.9 Reporting

NA — No bespoke reporting required. Operational reporting via SMC dashboards.

## 5.2.10 Integration and Testing Requirements

### 5.2.10.1 Development and Integration Strategy

Developer develops solution on their own workstation using development tools. After sound unit testing cases are completed, the binary is deployed to the target runtime environment through the automated build and deployment process.

### 5.2.10.2 Unit Testing

| ADO Test Case ID | Description |
| --- | --- |
| EAII-283-UT-01 | Happy path — successful POST to Sorted, correct JSON contract, gating reports available |
| EAII-283-UT-02 | HTTP 400 — non-retryable, immediate failure, single POST attempt only |
| EAII-283-UT-03 | HTTP 5xx (`ServiceUnavailable`) — exhausts all 3 retries, then fails |
| EAII-283-UT-04 | Gating unavailable — message skipped, no blob download, no outbound call, SMC logged as Skipped |
| EAII-283-UT-05 | **SMC StartObservation failure — flow continues unblocked** |
| EAII-283-UT-06 | Transformation correctness — verify captured payload contains transformed JSON fields (e.g. `itemNumber`, `locLocation`) and does **not** contain raw XML |
| EAII-283-UT-07 | *(Gap — not yet implemented)* HTTP 401/403 differentiated from generic 5xx retry |
| EAII-283-UT-08 | Replay a failed message via SMC reprocessing — new observation logged; Sorted receives the same transformed payload |

## 5.3.7 SMC Onboarding

### 5.3.7.1 Integration Onboarding

| Field | Value |
| --- | --- |
| Interface ID | EAII-282 |
| Interface Name | STIBO_to_Sorted_SupplierItem |
| Source Application | STIBO |
| Destination Application | Sorted |
| Interface Type | Async, event-driven |
| Interface DataStore | Azure Blob Storage (`stibo/frompim/supplieritem`) |
| Reference Keys | CorrelationId |
| Reprocessing Required | Yes — via SMC replay within 30-day blob retention window |

### 5.3.7.2 SMC Load Estimations

| Category | Sub-category | Requirement |
| --- | --- | --- |
| Volume | Average volume | **TBD — to be confirmed with support staff (per FSD §3.3.6, not yet provided)** |
| Message Size | Average message size | **TBD — to be confirmed with support staff (per FSD §3.3.6, not yet provided)** |
| SMC observation count per message | — | 1 (single complete `StartObservation` call) |

> Unlike EAII-283/284/385, the FSD does not provide volume/message-size figures for EAII-282
>

## 5.3.8 Monitoring

Application Insights telemetry per invocation; SMC Gen 3 observation per invocation; Azure Monitor alerting on DLQ accumulation and Function error rate.

## 5.3.9 Reporting

NA — No bespoke reporting required.

## 5.3.10 Integration and Testing Requirements

### 5.3.10.1 Development and Integration Strategy

Same as EAII-283 (§5.2.10.1).

### 5.3.10.2 Unit Testing

| ADO Test Case ID | Description |
| --- | --- |
| EAII-282-UT-01 | Happy path — successful POST to Sorted, correct JSON contract, gating reports available |
| EAII-282-UT-02 | HTTP 400 — non-retryable, immediate failure |
| EAII-282-UT-03 | **Pricing field logging check** — source XML contains `itemPrice[]`, `pricePillar`, `rangeWithIGA`; verify these values **do** appear in the outbound Sorted payload (intentional) but **do not** appear in any `LogMessage` entry sent to SMC, nor in Application Insights trace properties |
| EAII-282-UT-04 | HTTP 5xx — retry 3×/2s then fail |
| EAII-282-UT-06 | **SMC StartObservation failure — flow continues unblocked** |
| EAII-282-UT-07 | IGA WA only fixture (`ANGEL BAY` perishable) — verify correct pricing-pillar mapping (not exclusion — see corrected redaction note in §5.3.2.1) |
| EAII-282-UT-08 | *(Gap — not yet implemented)* HTTP 401/403 differentiated from generic 5xx retry — shared gap with EAII-283 |

## 5.4.7 SMC Onboarding

### 5.4.7.1 Integration Onboarding

| Field | Value |
| --- | --- |
| Interface ID | EAII-385 |
| Interface Name | STIBO_to_RetailExpress |
| Source Application | STIBO (via MetProducts) |
| Destination Application | MetProms (Retail Express) |
| Interface Type | Async, event-driven, update-with-create-fallback |
| Interface DataStore | Azure Blob Storage (`stibo/frompim/corporateitem`) |
| Reference Keys | CorrelationId |
| Reprocessing Required | Yes, except conflict (409) outcomes — those are deliberately not reprocessed |

### 5.4.7.2 SMC Load Estimations

| Category | Sub-category | Requirement |
| --- | --- | --- |
| Volume | Average volume | 500 items/day average (~21/hour), 5,000 items/day peak (~208/hour), 10% expected growth — per FSD §3.4.6 |
| Message Size | Average message size | ~500 KB per STEP XML; JSON output is smaller |
| SMC observation count per message | — | 1 (single complete `StartObservation` call) |

## 5.4.8 Monitoring

Application Insights telemetry per invocation; SMC Gen 3 observation per invocation; Azure Monitor alerting on DLQ accumulation and Function error rate.

## 5.4.9 Reporting

NA — No bespoke reporting required.

## 5.4.10 Integration and Testing Requirements

### 5.4.10.1 Development and Integration Strategy

Same pattern as the other three interfaces (§5.1.10.1).

### 5.4.10.2 Unit Testing

| ADO Test Case ID | Description |
| --- | --- |
| EAII-385-UT-01 | Happy path — item with IGA-pillar location, PUT returns 2xx, verify mapping against representative fixture |
| EAII-385-UT-02 | Item with no IGA-pillar location — verify `Transform` returns null, message skipped, no token acquired, no outbound call |
| EAII-385-UT-03 | PUT returns 404 — verify fallback POST is attempted; verify success on POST 2xx |
| EAII-385-UT-04 | PUT returns 409 — verify discard (Skipped), no retry, no fallback POST attempted |
| EAII-385-UT-05 | POST (after 404 fallback) returns 409 — verify discard (Skipped) |
| EAII-385-UT-06 | PUT returns non-retryable 4xx (excl. 404/409) — verify immediate failure, no retry |
| EAII-385-UT-07 | PUT/POST returns 5xx — verify retry up to 3×/2s then failure |
| EAII-385-UT-08 | OAuth2 token acquisition fails — verify no PUT/POST attempted, exception propagates |
| EAII-385-UT-09 | **SMC StartObservation failure — flow continues unblocked** |
| EAII-385-UT-10 | `last-modified-time` is generated at send time (UTC, ISO-8601) — verify it is not extracted from the source XML |
| EAII-385-UT-11 | *(Gap)* Bulk/initial-full-load path — **not covered**, since no bulk logic exists in the current implementation (see design consideration in §5.4.5) |



====================================================================================================
## DOC: TSD-EAII-289
====================================================================================================

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | Business Details Lookup |
| Source Business Process | MDM |
| Source Application | MDM |
| Destination Business Process | Business Register Lookup |
| Destination Application | Australian Business Register (ATO) |
| Interface ID | EAII-289 |
| Interface Name | ATO Business Details Lookup - Metcash Internal to ATO |
| Interface Type | Synchronous Request-Reply |
| Interface DataStore | N/A (stateless) |
| Tags | `{"division": "corporate", "type": "lookup", "priority": "P3"}` |
| Reference Keys | TransactionID, ABN/ACN, X-Operation |
| Notification Type | Error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-289 |
| Correlation Properties | TransactionID, ABN/ACN |
| Reprocessing Required | No (consumer manages retries) |
| BusinessProcess Name | ATOBusinessDetailsLookup |

#### 5.1.7.2 SMC Load Estimations

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Average lookups/day | ~50–100 (ad-hoc, business-hours only) |
| Volume | Peak lookups/hour | ~20 |
| Volume | Concurrent requests | ≤ 10 |
| Volume | Seasonal considerations | None — stable, non-seasonal usage |
| Volume | Expected growth | Low — stable usage patterns |
| SMC Events | Events per lookup (success) | 2 (Begin + End) |
| SMC Events | Events per lookup (failure) | 2 (Begin + Error) |
| SMC Events | Estimated daily SMC events | 100–200 |

### 5.1.8 Monitoring

Standard AIS platform monitoring applies via Application Insights and Azure Monitor.

- **Alert rules**:
- Error rate > 10% over 5-minute window → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- Response time > 5 seconds (P95) → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- ABR backend connectivity failure → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)

### 5.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

**SearchByABN / SearchByABNv2**

| **ADO Test Case ID** | **Description** | **Location Of Sample Messages** |
| --- | --- | --- |
| T1 | Successful ABN lookup — expect HTTP 200 with MetcashIdentifierBObj JSON; TransactionID in SMC success log | source_samples/abn_valid.json |
| T2 | Lookup for an ABN that exists but is cancelled/no longer trading — expect HTTP 200 with response indicating current status (JSON) | source_samples/abn_cancelled.json |
| T3 | Lookup for a non-existent ABN — expect HTTP 200 with "not found" response payload (JSON) | source_samples/abn_notfound.json |
| T4 | Lookup with missing or empty ABN query parameter — expect HTTP 400 with JSON validation error; failure logged to SMC | N/A |
| T5 | Lookup with non-numeric or wrong-length ABN — expect HTTP 400 with JSON validation error | N/A |
| T6 | ATO service unavailable (simulated network failure) — expect HTTP 502 JSON error; failure event logged to SMC | N/A |
| T7 | ATO returns error response (e.g., bad authentication) — expect HTTP 502 JSON error with reason; failure event logged to SMC | N/A |
| T8 | XML-to-JSON transformation failure (malformed ATO response) — expect HTTP 500 JSON error; failure event logged to SMC | N/A |

**SearchByACN / SearchByACNv2**

| **ADO Test Case ID** | **Description** | **Location Of Sample Messages** |
| --- | --- | --- |
| T9 | Successful ACN lookup — expect HTTP 200 with MetcashIdentifierBObj JSON; TransactionID in SMC success log | source_samples/acn_valid.json |
| T10 | Lookup for an ACN where company is deregistered — expect HTTP 200 with current status (JSON) | source_samples/acn_deregistered.json |
| T11 | Lookup for a non-existent ACN — expect HTTP 200 with "not found" response (JSON) | source_samples/acn_notfound.json |
| T12 | Lookup with missing or empty ACN query parameter — expect HTTP 400 JSON error; failure logged to SMC | N/A |
| T13 | Lookup with non-numeric or wrong-length ACN — expect HTTP 400 JSON error | N/A |
| T14 | ATO service unavailable — expect HTTP 502 JSON error; failure event logged to SMC | N/A |
| T15 | ATO returns error response — expect HTTP 502 JSON error with reason; failure logged to SMC | N/A |



====================================================================================================
## DOC: TSD-EAII-297
====================================================================================================

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | MDM Supplier |
| Source Business Process | Supplier Agreement Management |
| Source Application | Metconnect Salesforce |
| Destination Business Process | MDM Supplier |
| Destination Application | IBM MDM |
| Interface ID | EAII-297 |
| Interface Name | Get/Release MDM Supplier Number |
| Interface Type | Sender |
| Interface DataStore | N/A |
| Tags | `{"integration":"EAII-297","platform":"AIS","source":"Salesforce","target":"IBMMDM"}` |
| Reference Keys | TransactionID, AgreementID |
| Notification Type | Email |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | Get/Release MDM Supplier Number |
| Correlation Properties | TransactionID, AgreementID |
| Reprocessing Required | No |
| BusinessProcess Name | MDM Supplier |

#### 5.1.7.1 SMC Load Estimations

This section will include corresponding SMC load estimations for this interface, including peak and normal load scenarios.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | Tens to low-hundreds of requests per day during high-activity onboarding periods. Peak is estimated at up to 100 requests/day. |
| Average volume | Typically follows business-hours patterns (08:00–18:00 AEST) aligned to supplier onboarding activity. Estimated average: 10–50 requests/day. |  |
| Seasonal considerations | No significant seasonal variation expected. |  |
| Expected growth | No significant volume growth anticipated without a corresponding growth in supplier onboarding activity. |  |

### 5.1.8 Monitoring

*Capture any specific monitoring requirements for the solution here.*

### 5.1.9 Reporting

*Capture any specific reporting requirements for the solution here.*

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

| **ADO Test Case ID** | **Description** | **Location Of Sample Messages** |
| --- | --- | --- |
| T1 | Get New Supplier Number — valid AgreementID and valid API key. Expected: HTTP 200 with 7-digit SupplierNumber starting with `10`; AgreementID echoed; TransactionID echoed or generated. Sample: AgreementID=P00029015 → SupplierNumber=1012695. | `sample_payloads/EAII-297/source_samples/getNextSupplierNumber_SampleRequest_1.json` → `target_samples/getNextSupplierNumber_SampleResponse_1.json` |
| T2 | Get New Supplier Number — caller supplies TransactionID. Expected: HTTP 200 with caller-supplied TransactionID echoed back unchanged. Sample: TransactionID=001Rl00001O9viJIAR_20260709160955. | `sample_payloads/EAII-297/source_samples/getNextSupplierNumber_SampleRequest_1.json` |
| T3 | Get New Supplier Number — no TransactionID supplied. Expected: HTTP 200 with system-generated TransactionID (non-empty GUID-format string). | Custom request with TransactionID omitted |
| T4 | Release Reserved Supplier Number — valid AgreementID and valid API key. Expected: HTTP 200 with SuccessString populated with MDM ResultCode; AgreementID echoed. Sample: AgreementID=P00028593 → SuccessString=01. | `sample_payloads/EAII-297/source_samples/clearReservedSupplierNumber_SampleRequest_1.json` → `target_samples/clearReservedSupplierNumber_SampleResponse_1.json` |
| T5 | Get New Supplier Number — invalid or missing API key. Expected: HTTP 401 "Authentication Failed: Please check Authorization Key". No MDM call made. | Request with invalid/absent Authorization header |
| T6 | Release Reserved Supplier Number — invalid or missing API key. Expected: HTTP 401 "Authentication Failed: Please check Authorization Key". No MDM call made. | Request with invalid/absent Authorization header |
| T7 | Get New Supplier Number — MDM returns SOAP processing fault. Expected: HTTP 200 with `Message: "Request for new supplier failed. Please contact Metcash."` and no SupplierNumber field. | Simulate MDM SOAP fault via stub/mock |
| T8 | Release Reserved Supplier Number — MDM returns SOAP processing fault. Expected: HTTP 200 with `SuccessString: "FAILED"`. | Simulate MDM SOAP fault via stub/mock |
| T9 | Get New Supplier Number — MDM service unavailable (timeout). Expected: Error response returned to caller within configured timeout period; error event logged to Application Insights. | Simulate MDM timeout via stub/mock |
| T10 | All optional fields absent (TransactionID and SourceSystemID omitted from request). Expected: HTTP 200 success response; TransactionID auto-generated; SourceSystemID absent from response. | Custom request with optional fields omitted |
| T11 | API key rotation without restart (known issue). Rotate API key in Key Vault. Expected: Next request using new key succeeds (HTTP 200); request with old key fails (HTTP 401). No restart of APIM or Logic App required. | Rotate Key Vault secret; submit requests with new and old keys |
| T12 | Get New Supplier Number — second sample: AgreementID=P00029017 → SupplierNumber=1012525. | `sample_payloads/EAII-297/source_samples/getNextSupplierNumber_SampleRequest_2.json` → `target_samples/getNextSupplierNumber_SampleResponse_2.json` |



====================================================================================================
## DOC: TSD-EAII-301_302_516_517
====================================================================================================

#### 5.1.7 SMC Onboarding and Load

#### 5.1.8 Monitoring

Application Insights telemetry and one SMC Gen 3 observation per invocation.

#### 5.1.9 Reporting

No bespoke reporting required.

#### 5.1.10 Integration and Testing Requirements

#### 5.2.8 Monitoring

Application Insights telemetry and one SMC Gen 3 observation per invocation. Given the Gold SLA and RED-RED Horizon classification, DLQ accumulation on `topim.supplierinfo` warrants alerting at the same or higher priority than EAII-517/516.

#### 5.2.9 Reporting

No bespoke reporting required.

**5.2.10 Integration and Testing Requirements**

**5.2.10.1 Development and Integration Strategy**

Standard Function App development lifecycle: local development against real sample MDM request/response and STEP-PIM output payloads (`inbox/EAII-302/Attachments/`), deployed per-environment via the existing AIS pipeline pattern.

**5.2.10.2 Unit Testing**

| ADO Test Case ID | Description |
| --- | --- |
| EAII-302-UT-01 | Happy path — successful transform, PIM returns HTTP 202, message completed |
| EAII-302-UT-02 | OAuth discovery failure — discovery document unreachable/malformed, message dead-lettered, no PIM call attempted |
| EAII-302-UT-03 | OAuth token request failure — client_credentials grant rejected, message dead-lettered |
| EAII-302-UT-04 | PIM authentication rejection (401/403) — retried up to 3 times, then dead-lettered on exhaustion |
| EAII-302-UT-05 | PIM business rejection (other 4xx) — non-retryable, message dead-lettered immediately |
| EAII-302-UT-06 | PIM transient failure (5xx/timeout) — retried up to 3 times, then dead-lettered on exhaustion |
| EAII-302-UT-07 | Transformation error (malformed/unexpected MDM data) — message dead-lettered, no PIM call made |
| EAII-302-UT-08 | Multi-Buy-From-component payload — verify each Buy-From classification reads its own status/name data, not Pay-To's |
| EAII-302-UT-09 | No duplicate `attr_paytosupplierName` in output — single occurrence per Pay-To classification |
| EAII-302-UT-10 | Products/Agreement-Terms qualifying filter — verify both OR-branches (`PaymentMethodDesc='Off Invoice'`, `DiscountType='2000008'`) produce a Product when the matching Party Role exists |
| EAII-302-UT-11 | `attr_ImportSupplier` Yes/No branches — `IntendedMarketValue='I'` → `"Yes"`, else `"No"` |
| EAII-302-UT-12 | SMC observation logging — `ParentObservationID` populated from `TRANSACTIONID` (or fallback), one complete observation per invocation |
| EAII-302-UT-13 | OAuth token cache — cold-start (discovery + token) vs. cached-token (no discovery call) scenarios |
| EAII-302-UT-14 | Blob/pointer-extraction failure — malformed or missing blob pointer, message dead-lettered |



====================================================================================================
## DOC: TSD-EAII-304
====================================================================================================

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

*Enter the required SMC Integration Onboarding details. The corresponding Business Process and Applications must have already been onboarded to SMC. If not then onboarding details for these must also be provided (refer SMC User Guide in Reference Documents and Architecture below)*

| **Field** | **Value** |
| --- | --- |
| Business Process | ALM / IBA Directs |
| Source Business Process | Liquor Supplier Operations |
| Source Application | Liquor Suppliers (external) |
| Destination Business Process | EIM Data Processing |
| Destination Application | EIM (Enterprise Information Management) |
| Interface ID | EAII-304 |
| Interface Name | IBA Directs ALM Orders - Liquor Suppliers to EIM |
| Interface Type | Sender |
| Interface DataStore | Azure Blob Storage |
| Tags | `{"integration": "EAII-304", "domain": "ALM", "platform": "AIS"}` |
| Reference Keys | Transaction ID, Supplier ID |
| Notification Type | Email |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-304 |
| Correlation Properties | Transaction ID, Supplier ID |
| Reprocessing Required | Yes — failed translation messages can be replayed from Service Bus dead-letter queue |
| BusinessProcess Name | IBADirects |

#### 5.1.7.1 SMC Load Estimations

This section will include corresponding SMC load estimations for this interface, including peak and normal load scenarios.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | ~8 files per month across all suppliers. Peak scenario: 2–3 files in a single day (very unlikely). |
| Average volume | ~2 files per week |  |
| Seasonal considerations | No significant seasonal variation expected |  |
| Expected growth | Low — supplier base is small and established. No growth forecast provided. |  |
| Message Size | Average message size | ZIP payloads: ~20 KB (Coopers) to ~685 KB (CUB). Unzipped: ~318 KB to ~5.3 MB. PSV output: ~144 KB to ~2.4 MB. |
| Message Size | Max message size | 3 MB (ZIP payload limit enforced at APIM) |

### 5.1.8 Monitoring

Standard AIS platform monitoring applies via Azure Application Insights and Log Analytics Workspace.

### 5.1.9 Reporting

*NA*

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

| Work Item Type | Title | Test Step | Step Action | Step Expected |
| --- | --- | --- | --- | --- |
| Test Case | Verify Upload Blob without authentication token |  |  |  |
|  |  | 1 | Invoke Upload Blob API without providing a Bearer token | API returns 401 Unauthorized and the request is rejected. Authentication failure is logged in SMC. |
| Test Case | Verify Upload Blob with invalid or expired authentication token |  |  |  |
|  |  | 1 | Invoke Upload Blob API using an invalid, malformed, or expired Bearer token | API returns 401 Unauthorized and the request is rejected. Authentication failure is logged in SMC. |
| Test Case | Verify Upload Blob with malformed authentication token |  |  |  |
|  |  | 1 | Invoke Upload Blob API using a malformed Bearer token | API returns 401 Unauthorized and the request is rejected. Authentication failure is logged in SMC. |
| Test Case | Verify Upload Blob without RequesterSiteId header |  |  |  |
|  |  | 1 | Invoke Upload Blob API without the RequesterSiteId header | API returns 400 Bad Request with a missing RequesterSiteId validation error. Error is logged in SMC. |
| Test Case | Verify Upload Blob with invalid RequesterSiteId |  |  |  |
|  |  | 1 | Invoke Upload Blob API with an invalid RequesterSiteId value | API returns 400 Bad Request with an invalid RequesterSiteId validation error. Error is logged in SMC. |
| Test Case | Verify Upload Blob with missing request body |  |  |  |
|  |  | 1 | Invoke Upload Blob API without a request body | API returns 400 Bad Request and the request is not processed. |
| Test Case | Verify Upload Blob with invalid JSON request body |  |  |  |
|  |  | 1 | Invoke Upload Blob API with malformed or invalid JSON | API returns 400 Bad Request with an invalid JSON validation error. |
| Test Case | Verify Upload Blob with missing SupplierID |  |  |  |
|  |  | 1 | Invoke Upload Blob API without the SupplierID field | API returns 400 Bad Request with a missing SupplierID validation error. |
| Test Case | Verify Upload Blob with empty SupplierID |  |  |  |
|  |  | 1 | Invoke Upload Blob API with an empty SupplierID value | API returns 400 Bad Request with a SupplierID validation error. |
| Test Case | Verify Upload Blob with missing FileContent |  |  |  |
|  |  | 1 | Invoke Upload Blob API without the FileContent field | API returns 400 Bad Request with a missing FileContent validation error. |
| Test Case | Verify Upload Blob with empty FileContent |  |  |  |
|  |  | 1 | Invoke Upload Blob API with an empty FileContent value | API returns 400 Bad Request with a FileContent validation error. |
| Test Case | Verify Upload Blob with invalid Base64 FileContent |  |  |  |
|  |  | 1 | Invoke Upload Blob API with FileContent containing invalid Base64 data | API returns 400 Bad Request with an invalid Base64 validation error. |
| Test Case | Verify Upload Blob with Base64 content that is not a ZIP file |  |  |  |
|  |  | 1 | Submit valid Base64 content representing a non-ZIP file | API returns 400 Bad Request because the decoded content is not a valid ZIP file. Error is logged in SMC. |
| Test Case | Verify Upload Blob with corrupted ZIP file |  |  |  |
|  |  | 1 | Upload a corrupted ZIP file encoded as valid Base64 | API returns 400 Bad Request and the ZIP decompression or validation failure is logged. |
| Test Case | Verify Upload Blob with valid ZIP file below 3 MB |  |  |  |
|  |  | 1 | Upload a valid ZIP file with a decoded size below 3 MB | API returns 200 OK and the ZIP file is stored in the input location. |
| Test Case | Verify Upload Blob with ZIP file exceeding 3 MB |  |  |  |
|  |  | 1 | Upload a valid ZIP file with a decoded size greater than 3 MB | API returns 400 Bad Request with IBADIRECTS-ERR-001. The file is stored in the error location. |
| Test Case | Verify Upload Blob with ZIP containing no files |  |  |  |
|  |  | 1 | Upload a valid ZIP archive containing no files | API returns 400 Bad Request because the ZIP does not contain a valid input file. |
| Test Case | Verify Upload Blob with ZIP containing invalid JSON |  |  |  |
|  |  | 1 | Upload a ZIP containing an invalid JSON file | API returns 400 Bad Request and the invalid JSON error is logged. |
| Test Case | Verify Upload Blob with ZIP containing empty JSON |  |  |  |
|  |  | 1 | Upload a ZIP containing an empty JSON file | API returns 400 Bad Request and the empty JSON validation error is logged. |
| Test Case | Verify end-to-end successful Upload Blob processing |  |  |  |
|  |  | 1 | Submit a valid request containing a valid Bearer token, SupplierID and ZIP file within the 3 MB limit | API accepts the request and stores the source file in the input location. |
|  |  | 2 | Allow the uploaded file event to trigger downstream processing | Queue message is created and consumed successfully. |
|  |  | 3 | Process the ZIP and transform the DirectsData records | ZIP is extracted and the PSV file is generated with the expected records and format. |
|  |  | 4 | Upload the generated PSV and complete source-file processing | PSV is uploaded successfully; source is archived and removed from the input location. |
|  |  | 5 | Verify transaction logging | SMC message is sent and the workflow completes successfully. |
| Test Case | Verify Upload Blob with multiple DirectsData records |  |  |  |
|  |  | 1 | Upload a ZIP containing multiple DirectsData objects | Generated PSV contains one header and one row for each input record. |
|  |  | 2 | Validate generated PSV row structure | PSV row count matches the number of source records and contains no missing or additional delimiters. |
| Test Case | Verify generated PSV schema format |  |  |  |
|  |  | 1 | Process a valid ZIP containing DirectsData records | Generated PSV header exactly matches the required 20-field schema: SUPPID&#124;PRODCODE&#124;PRODDESC&#124;SUPPPRODCODE&#124;SUPPPRODDESC&#124;PACKSIZE&#124;PRODCATEGORY&#124;GTIN&#124;LICNUMBER&#124;CUSTNUMBER&#124;CUSTNAME&#124;ADDRESS&#124;SUBURB&#124;POSTCODE&#124;STATE&#124;INVNUMBER&#124;INVDATE&#124;INVCASES&#124;INVLITRES&#124;INVVALUE. |
| Test Case | Verify metadata enrichment during processing |  |  |  |
|  |  | 1 | Upload a source blob containing SupplierID and DocumentType metadata | SupplierID and DocumentType from the source blob metadata are correctly propagated to the SMC message headers. |
| Test Case | Verify successful transformation and archive processing |  |  |  |
|  |  | 1 | Process a valid ZIP through TransformToPSV | TransformToPSV returns a successful status and the PSV is generated and uploaded. |
|  |  | 2 | Complete successful processing | Source file is copied to the archive location, removed from input, and the archive stage is marked completed. |
| Test Case | Verify transformation business failure handling |  |  |  |
|  |  | 1 | Force TransformToPSV to return a failed status | Source file is copied to the error location and removed from input. |
|  |  | 2 | Verify failure tracking | Transform failure stage is recorded and SMC error information is populated. |
| Test Case | Verify Finally execution after successful processing |  |  |  |
|  |  | 1 | Execute a successful processing flow where all Try actions complete successfully | Finally block executes after successful Try completion. |
|  |  | 2 | Verify final processing actions | SMC message is sent and observation completion status is recorded. |
| Test Case | Verify Finally execution after processing failure |  |  |  |
|  |  | 1 | Force an action within the Try block to fail | Try block fails and control moves to the configured failure handling logic. |
|  |  | 2 | Verify Finally execution | Finally block executes even when the Try block fails. SMC message is attempted and termination logic is evaluated. |
| Test Case | Verify retry mechanism for transient storage failure |  |  |  |
|  |  | 1 | Simulate a temporary Azure Storage failure during processing | Configured retry policy retries the failed storage action. |
|  |  | 2 | Allow the storage operation to recover within the configured retry limit | Storage operation subsequently succeeds without permanent workflow failure. |
| Test Case | Verify handling of ZIP file size exceeding 3 MB |  |  |  |
|  |  | 1 | Upload a ZIP file exceeding the 3 MB limit | API returns 400 Bad Request, stores the file in the error location, and logs IBADIRECTS-ERR-001. |
| Test Case | Verify handling of corrupted ZIP decompression failure |  |  |  |
|  |  | 1 | Process a corrupted ZIP file | ZIP decompression fails and IBADIRECTS-ERR-003 behaviour is logged. |
|  |  | 2 | Verify failure tracking | Failed processing stage is recorded and SMC contains the relevant technical error details. |
| Test Case | Verify handling of JSON parsing failure during transformation |  |  |  |
|  |  | 1 | Process a ZIP containing malformed JSON | Transformation fails and IBADIRECTS-ERR-002 behaviour is logged. |
|  |  | 2 | Verify transaction failure handling | Transaction is marked as failed and the error details are captured in SMC. |
| Test Case | Verify handling of missing DirectsData array |  |  |  |
|  |  | 1 | Process a JSON payload where the DirectsData array is missing | Transformation fails with an appropriate validation/processing error. |
|  |  | 2 | Verify error logging | Error details are captured and sent to SMC. |
| Test Case | Verify handling of empty DirectsData array |  |  |  |
|  |  | 1 | Process a JSON payload containing an empty DirectsData array | Transformation fails with a no-records error. |
|  |  | 2 | Verify error logging | SMC contains the corresponding transformation error. |
| Test Case | Verify handling of invalid DirectsData record structure |  |  |  |
|  |  | 1 | Process a DirectsData array containing a non-object item | Transformation fails because the record does not match the expected object structure. |
|  |  | 2 | Verify technical error handling | Technical error details are captured in SMC. |
| Test Case | Verify source blob read or metadata timeout handling |  |  |  |
|  |  | 1 | Simulate a timeout or failure while reading source blob content or metadata | Read_blob_content fails or times out and HasErrors is set to true. |
|  |  | 2 | Verify failure logging | Technical error is captured and the failed processing stage is logged in SMC. |
| Test Case | Verify PSV upload failure handling |  |  |  |
|  |  | 1 | Simulate a failure or timeout during Upload_PSV_to_output | PSV upload fails or times out and HasErrors is set to true. |
|  |  | 2 | Verify error handling | Upload stage is marked as failed and an SMC error entry is added. |
| Test Case | Verify SMC message send failure handling |  |  |  |
|  |  | 1 | Simulate a failure, timeout, or skipped execution of Send_message | SMC send failure is captured by the workflow. |
|  |  | 2 | Verify workflow termination | Workflow terminates as failed according to the configured termination logic. |
| Test Case | Verify HasErrors termination gate |  |  |  |
|  |  | 1 | Force a tracked blob action to fail or timeout | HasErrors is set to true and the technical error is captured. |
|  |  | 2 | Verify SMC notification | SMC message is attempted before workflow termination. |
|  |  | 3 | Verify termination logic | Workflow follows the HasErrors failure branch and terminates as failed. |
| Test Case | Verify handling of unexpected runtime exception |  |  |  |
|  |  | 1 | Force an unexpected or unhandled action failure inside the Try block | Catch handling is triggered and available exception details are captured. |
|  |  | 2 | Verify failure-stage tracking | Failed processing stage is recorded and SMC contains the error payload. |
| Test Case | Verify Upload Blob with missing required request fields |  |  |  |
|  |  | 1 | Submit a request with a required API field such as SupplierID missing | API returns 400 Bad Request with the appropriate validation error. |
|  |  | 2 | Verify failure logging | Validation failure is logged in SMC. |
| Test Case | Verify SMC error payload integrity |  |  |  |
|  |  | 1 | Trigger a processing failure and generate an SMC error message | SMCError array contains the failed action name, technical error message, status, and error code where available. |



====================================================================================================
## DOC: TSD-EAII-333
====================================================================================================

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | Campbells Payment Capture |
| Source Business Process | Order Fulfilment - Payment |
| Source Application | Storeline |
| Destination Business Process | Payment Processing |
| Destination Application | SAP Commerce Cloud (Sorted) |
| Interface ID | EAII-333 |
| Interface Name | Campbells Payment - Storeline to CCC |
| Interface Type | Synchronous Request-Reply |
| Interface DataStore | N/A (stateless) |
| Tags | `{"division": "campbells", "type": "payment", "priority": "P1"}` |
| Reference Keys | Transaction ID, Order ID, Customer ID |
| Notification Type | Error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-333 |
| Correlation Properties | Order ID, Transaction ID |
| Reprocessing Required | No (caller manages retries) |
| BusinessProcess Name | CampbellsPaymentCapture |

#### 5.1.7.1 SMC Load Estimations

This section will include corresponding SMC load estimations for this interface, including peak and normal load scenarios.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | ~200 messages/day |
|  | Average volume | ~200 messages/day (3,021 messages over 15 days) |
|  | Seasonal considerations | Standard retail patterns - higher during promotional periods |
|  | Expected growth | Low - stable customer base |

### 5.1.8 Monitoring

Standard AIS platform monitoring applies via Application Insights and Azure Monitor.

- **Health probe**: APIM built-in health endpoint
- **Alert rules**:
- Error rate > 5% over 5-minute window → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- Response time > 5 seconds (P95) → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- Backend connectivity failure → [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com)
- **Dashboard**: Standard APIM analytics dashboard with custom dimensions (Order ID, Response Code)

### 5.1.9 Reporting

N/A - No special reporting requirements. Standard AIS platform reporting applies.

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

*Make sure to include scenarios for any known issues to be addressed.*

| **ADO Test Case ID***(Link)* | **Description** | **Location Of Sample Messages** |
| --- | --- | --- |
| T1 | Submit valid payment capture request with correct order ID and payment amount - expect responseCode=1 | Source_sample_request1.xml / Source_sample_response1.xml |
| T2 | Submit payment capture request with invalid/non-existent order ID - expect responseCode≠1 with error message | Mock SAP Commerce Cloud returning error |
| T3 | Submit payment capture request with zero amount - expect error response | Mock SAP Commerce Cloud returning error |
| T4 | Submit payment capture when SAP Commerce Cloud is unavailable - expect SOAP fault | Backend unreachable |
| T5 | Submit payment capture when SAP Commerce Cloud responds slowly (timeout) - expect SOAP fault | Backend delay > timeout |
| T6 | Submit payment capture that returns responseCode=2 - verify error message formatted as "Error {code} - {msg}" | Mock response with responseCode=2 |
| T7 | Verify audit logging records transaction ID, order ID, and response code for successful capture | App Insights query validation |
| T8 | Verify audit logging captures error details for failed payment capture | App Insights query validation |



====================================================================================================
## DOC: TSD-EAII-514
====================================================================================================

### 5.1.7 SMC Onboarding

#### 5.1.7.1 Integration Onboarding

| **Field** | **Value** |
| --- | --- |
| Business Process | Realtime Pricing |
| Source Business Process | Realtime Pricing |
| Source Application | Sorted |
| Destination Business Process | PE |
| Destination Application | PE — Power Enterprise (AS/400) |
| Interface ID | EAII-514 |
| Interface Name | Realtime Pricing |
| Interface Type | Synchronous Request-Response |
| Interface DataStore | N/A |
| Tags | `{"pillar": "multi", "protocol": "REST", "target": "AS400"}` |
| Reference Keys | Transaction UUID, Company, Pillar, CustomerId, PriceDate |
| Notification Type | Email on error |
| Notification Email Address | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Grouping ID | EAII-514 |
| Correlation Properties | Transaction UUID |
| Reprocessing Required | No |

#### 5.1.7.2 SMC Load Estimations

This section includes the corresponding SMC load estimations for this interface under normal and peak load scenarios. SMC logging is enabled on demand through a configuration flag; therefore, the load estimations apply only when SMC logging is enabled.

| **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- |
| Volume | Peak volume | 10,784 calls/hour (378 calls/minute) — current observed peak |
| Target capacity | 20,000 calls/hour (1,000 calls/minute) — to accommodate Christmas peak and post-Horizon growth |  |
| Average volume | High — service is heavily utilized throughout business hours; traffic is combined across IGA, Campbells, and C-Store portals |  |
| Seasonal considerations | Christmas peak drives highest volumes; planned AS/400 maintenance windows should use the `dbOutageFlag` for controlled degradation |  |
| Expected growth | Significant increase expected post-Horizon go-live as Enterprise Portal features migrate to Sorted, bringing additional IGA customers placing warehouse orders |  |
| Message Size | Average request | ~500 bytes (5 products) |
| Average response | ~2 KB (5 products) |  |
| Max request | ~1.5 KB (20 products) |  |
| Max response | ~8 KB (20 products) |  |

### 5.1.8 Monitoring

N/A

### 5.1.9 Reporting

N/A

### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

*Check boxes to confirm completed.*

- Developer develops solution on his / her own workstation using development tools.
- After sound unit testing cases are completed, the binary needs to be deployed to the run time environment to ensure compatibility / consistency with the targeted runtime environment through the automated build and deployment process.

Refer to [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy) for detail.

#### 5.1.10.2 Unit Testing

Unit test cases have to be included below spreadsheet. The relevant sample messages need to be made available that each unit testing scenario can be repeated and reproduced independently with consistent results.

| ID | Work Item Type | Title | Step Action | Step Expected |
| --- | --- | --- | --- | --- |
| **TC-001** | Test Case | **Verify Pricing API without Auth token** | Invoke Pricing API without a Bearer token | API returns **401 Unauthorized** with error code **TokenNotPresent**. Error is logged in SMC. |
| **TC-002** | Test Case | **Verify Pricing API with invalid/expired Auth token** | Invoke Pricing API with a malformed, expired, or invalid Bearer token | API returns **401 Unauthorized** with the appropriate authentication error. Error is logged in SMC. |
| **TC-003** | Test Case | **Verify Pricing API without Requester header** | Invoke Pricing API without the `Requester` header | API returns **400 Bad Request** with **Requester header is missing**. Error is logged in SMC. |
| **TC-004** | Test Case | **Verify Pricing API without RequesterSiteId header** | Invoke Pricing API without the `RequesterSiteId` header | API returns **400 Bad Request** with **RequesterSiteId header is missing**. Error is logged in SMC. |
| **TC-005** | Test Case | **Verify Pricing API with invalid RequesterSiteId** | Invoke Pricing API with an invalid `RequesterSiteId` | API returns **401 Unauthorized** with **TokenClaimValueMismatch**. Error is logged in SMC. |
| **TC-006** | Test Case | **Verify Pricing API with single valid product for IGA pillar** | Submit a pricing request with one valid product and `Pillar = IGA` | API returns **200 OK** with all pricing fields populated. Successful transaction is logged in SMC. |
| **TC-007** | Test Case | **Verify Pricing API with 20 valid products** | Submit a pricing request containing **20 valid products** | API returns pricing data for **all 20 products** successfully. |
| **TC-008** | Test Case | **Verify Pricing API with one invalid product** | Submit a pricing request with valid products and one invalid product number | Valid products return pricing; the invalid product contains an **ErrorMsg**. |
| **TC-009** | Test Case | **Verify Pricing API when dbOutageFlag is true** | Set `dbOutageFlag = true` and submit a valid pricing request | API returns **503 Service Unavailable** for REST without calling AS/400. |
| **TC-010** | Test Case | **Verify Pricing API with invalid Company code** | Submit a pricing request with `Company` other than **MTT** | API returns **400 Bad Request** with Company validation error. |
| **TC-011** | Test Case | **Verify Pricing API with invalid Pillar code** | Submit a pricing request with an invalid `Pillar` value | API returns **400 Bad Request** with Pillar validation error. |
| **TC-012** | Test Case | **Verify Pricing API with invalid PriceDate format** | Submit a pricing request with `PriceDate` not in **YYYY-MM-DD** format | API returns **400 Bad Request** with date format validation error. |
| **TC-013** | Test Case | **Verify Pricing API when AS/400 is unreachable** | Make the AS/400 backend unavailable and submit a valid pricing request | API returns **500 Internal Server Error** with connectivity error. Error is logged in App Insights and SMC. |
| **TC-015** | Test Case | **Verify Pricing API with zero products** | Submit a pricing request with an empty `Product` array | API returns the request context with an **empty PriceData array**. |
| **TC-016** | Test Case | **Verify Pricing API for ALM, CCC, and CSD pillars** | Submit valid pricing requests for **ALM**, **CCC**, and **CSD** | API returns the correct pricing data for each pillar. |
| **TC-017** | Test Case | **Verify Pricing API with invalid Company enum value** | Submit a request with `Company = MTTE` | API returns **400 Bad Request** with JSON schema enum validation error. |
| **TC-018** | Test Case | **Verify Pricing API with invalid Pillar enum value** | Submit a request with `Pillar = ABC` | API returns **400 Bad Request** with JSON schema enum validation error. |
| **TC-019** | Test Case | **Verify Pricing API with more than 20 products** | Submit a request containing **more than 20 products** | API returns **400 Bad Request** with max-items validation error. |
| **TC-020** | Test Case | **Verify Pricing API with invalid Product length** | Submit a request with a Product value exceeding the maximum allowed length | API returns **400 Bad Request** with Product length validation error. |
| **TC-021** | Test Case | **Verify Pricing API with missing Company** | Submit a request without the `Company` field | API returns **400 Bad Request** with required-property validation error. |
| **TC-022** | Test Case | **Verify Pricing API with missing request body** | Invoke Pricing API without a request body | API returns **400 Bad Request** with request body validation error. |
