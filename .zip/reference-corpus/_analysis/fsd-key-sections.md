

====================================================================================================
## DOC: FSD-EAII-284_283_282_385
====================================================================================================

### 3.1.2 Interface requirements / Mapping details

No field-level mapping - this is a pass-through interface. The source Corporate Item XML is delivered unchanged to IndiPIM.

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | N/A - pass-through, no transformation |
| TSD for the interface(s) | [Technical Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311599664/Technical+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets) |
| ADO link for the feature | [ADO Work Item 263534](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/263534) |
| Source file(s) | ![diagram](images/16.png)![diagram](images/23.png) |
| Target file(s) | Same as source (pass-through) |

### 3.1.3 API Endpoint(s) information

| **Endpoint** | **HTTP Method** | **URL Pattern** | **Authentication** | **Content Type** |
| --- | --- | --- | --- | --- |
| IndiPIM Product API | POST | `<https://{IndiPIMHost}:{Port}{Uri}`> | OAuth 2.0 Bearer Token (Auth0) | application/xml (rendered STEP XML) |
| Auth0 Token Endpoint | POST | `<https://{Auth0Host}:{Port}{TokenUri}`> | Client credentials (client_id, client_secret, audience, grant_type) | application/x-www-form-urlencoded |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Average volume | 500 items/day average (~21/hour), 5,000 items/day peak (~208/hour) |
| Y | Message Size | Average msg size | ~500 KB per STEP XML (pass-through, no size change) |
| N | Performance Testing | Performance / Load / Stress | N/A |
| Y | Latency | Any specific latency requirements | Near real-time delivery (within minutes of PIM publication) |
| N | Scalability | Any specific scalability requirements | N/A |
| Y | Reliability | Reliability | 95% (Silver SLA). Failed messages retried up to 3 times. |
| Y | Reliability | Disaster Recovery | RTO ≤ 4 hours, RPO ≤ 2 hours |
| Y | Auditability & Observability | Fields to be traced | Refer to the Corporate Global Auditability and Observability requirements |
| Y | Logging | Fields or key message identifiers to be logged | Item number, transaction ID, IndiPIM API response status |
| Y | Sequencing or scheduling | Msg/file schedule | Event-driven |
| N | Backup & Archiving | Backup / Archiving | N/A |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| IndiPIM API connectivity failure | HTTP connection timeout or network error | Retry up to 3 times. On persistent failure, route to error queue. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| IndiPIM API authentication failure | OAuth token expired or invalid, Auth0 error | Refresh token and retry. If refresh fails, route to error queue. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| IndiPIM API error matching configurable error code | HTTP 5xx (default pattern) | Conditional retry based on error code match. If retry count exceeded, log and alert. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unexpected error | Any unhandled exception | Log error. Route to error queue. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Corporate item published from PIM | STEP XML delivered to IndiPIM via HTTP POST with valid OAuth bearer token | Verify full round-trip |
| T2 | OAuth token expired during processing | Token refreshed automatically. Message delivered successfully. | Verify token pre-refresh logic |
| T3 | IndiPIM API returns configurable error code | Message retried up to 3 times. On final failure, routed to error queue. | Verify error-code-based retry |
| T4 | IndiPIM API returns non-retryable error | Message logged and routed to error queue immediately. No retry. | Verify no-retry path |

---

### 3.2.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-283 - Distribute Corporate Item Data - STIBO to Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311009815/Mapping+-+EAII-283+-+Distribute+Corporate+Item+Data+-+STIBO+to+Sorted) |
| TSD for the interface(s) | [Technical Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311599664/Technical+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets) |
| ADO link for the feature | [ADO Work Item 263523](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/263523) |
| Source file(s) | ![diagram](images/16.png)![diagram](images/23.png) |
| Target file(s) | ![diagram](images/01.png)![diagram](images/22.png) |

### 3.2.3 API Endpoint(s) information

| **Endpoint** | **HTTP Method** | **URL Pattern** | **Authentication** | **Content Type** |
| --- | --- | --- | --- | --- |
| Sorted Corporate Item API | POST | `<https://{SortedHost}:{Port}{CorporateItemURI}`> | Mutual TLS (client certificate) | application/json |

### 3.2.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Average volume | 500 items/day average (~21/hour), 5,000 items/day peak (~208/hour), 10% expected growth |
| Y | Message Size | Average msg size | ~500 KB per STEP XML; JSON output is smaller |
| N | Performance Testing | Performance / Load / Stress | N/A |
| Y | Latency | Any specific latency requirements | Near real-time delivery |
| N | Scalability | Any specific scalability requirements | N/A |
| Y | Reliability | Reliability | 95% (Silver SLA) |
| Y | Reliability | Disaster Recovery | RTO ≤ 4 hours, RPO ≤ 2 hours |
| Y | Auditability & Observability | Fields to be traced | Refer to the Corporate Global Auditability and Observability requirements |
| Y | Logging | Fields or key message identifiers to be logged | Item number, transaction ID, Sorted API response status |
| Y | Sequencing or scheduling | Msg/file schedule | Event-driven |
| N | Backup & Archiving | Backup / Archiving | N/A |

### 3.2.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Sorted API connectivity failure | HTTP connection timeout or network error | Check Sorted system status. If system is up, retry with configurable sleep timer. If system is down, set system state to down and wait. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Sorted API technical error matching configured error code | HTTP 5xx or communication exception (default pattern) | Apply sleep timer. Retry. Track system state. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unexpected error | Any unhandled exception | Log error. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.2.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Corporate item published from PIM | CorporateItemMDM XML mapped to JSON and delivered to Sorted API | Verify JSON structure matches CorporateItemMDM schema |
| T2 | Sorted API returns technical error | Message retried with sleep timer. System state tracked. | Verify retry with backoff |
| T3 | Sorted system reported as down | Sorted messages delayed with sleep timer until system status recovers | Verify system state gating |

---

### 3.3.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-282 - Distribute Supplier Item Data - STIBO to Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311271942/Mapping+-+EAII-282+-+Distribute+Supplier+Item+Data+-+STIBO+to+Sorted) |
| TSD for the interface(s) | [Technical Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311599664/Technical+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets) |
| ADO link for the feature | [ADO Work Item 263502](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/263502) |
| Source file(s) | ![diagram](images/06.png)![diagram](images/02.png) |
| Target file(s) | ![diagram](images/14.png)![diagram](images/25.png) |

### 3.3.3 API Endpoint(s) information

| **Endpoint** | **HTTP Method** | **URL Pattern** | **Authentication** | **Content Type** |
| --- | --- | --- | --- | --- |
| Sorted Supplier Data API | POST | `<https://{SortedHost}:{Port}{SupplierDataURI}`> | Mutual TLS (client certificate) | application/json |

### 3.3.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Average volume | TBD - to be confirmed with support staff |
| Y | Message Size | Average msg size | TBD - to be confirmed with support staff |
| N | Performance Testing | Performance / Load / Stress | N/A |
| Y | Latency | Any specific latency requirements | Near real-time delivery |
| N | Scalability | Any specific scalability requirements | N/A |
| Y | Reliability | Reliability | 95% (Silver SLA) |
| Y | Reliability | Disaster Recovery | RTO ≤ 4 hours, RPO ≤ 2 hours |
| Y | Auditability & Observability | Fields to be traced | Refer to the Corporate Global Auditability and Observability requirements |
| Y | Logging | Fields or key message identifiers to be logged | Item number, transaction ID, Sorted API response status |
| Y | Sequencing or scheduling | Msg/file schedule | Event-driven |
| N | Backup & Archiving | Backup / Archiving | N/A |

### 3.3.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Sorted API connectivity failure | HTTP connection timeout or network error | Check Sorted system status. If system is up, retry with configurable sleep timer. If system is down, set system state to down and wait. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Sorted API technical error matching configured error code | HTTP 5xx or communication exception (default pattern) | Apply sleep timer. Retry. Track system state. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unexpected error | Any unhandled exception | Log error. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.3.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Supplier item published from PIM | SupplierItem XML mapped to JSON and delivered to Sorted API | Verify JSON structure matches SupplierItem schema |
| T2 | Sorted API returns technical error | Message retried with sleep timer. System state tracked. | Verify retry with backoff |
| T3 | Sorted system reported as down | Sorted messages delayed with sleep timer until system status recovers | Verify system state gating |

---

### 3.4.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-385 - Product Master Data - STIBO to Retail Express](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3310321687/Mapping+-+EAII-385+-+Product+Master+Data+-+STIBO+to+Retail+Express) |
| TSD for the interface(s) | [Technical Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311599664/Technical+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets) |
| ADO link for the feature | [265000 - EAII-385 - Functional Specification](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/265000) |
| Source file(s) | ![diagram](images/04.png)![diagram](images/15.png)<br> <br>![diagram](images/05.png) |
| Target file(s) | ![diagram](images/12.png)![diagram](images/18.png) |

### 3.4.3 API Endpoint(s) information

The target system (MetProms / Retail Express) exposes a REST API for item attribute management.

| **Property** | **Detail** |
| --- | --- |
| **Base URL** | Provided by Retail Express per environment |
| **Authentication** | OAuth 2.0 Client Credentials flow |
| **Token Endpoint (Test)** | `<https://id.test.retailexp.com/oauth/token`> |
| **Token Endpoint (Production)** | `<https://id.retailexp.com/oauth/token`> |
| **Content Type** | `application/vnd.retailexpress.api.v1+json` |
| **IP Whitelisting** | Required - integration platform IP must be registered with Retail Express |

| **Operation** | **Method** | **Endpoint** | **Description** |
| --- | --- | --- | --- |
| Create item attributes | POST | `/item-attribute-records` | Creates attributes for a new item |
| Update item attributes | PUT | `/item-attribute-records/{id}` | Updates attributes for an existing item (identified by item ID, e.g., `I-10001701`). Returns 409 if `last-modified-time` is older than current. |
| Bulk update | POST | `/item-attribute-records/bulk` | Updates attributes for 1-100 items atomically. Returns 409 on conflict. |
| Get item attributes | GET | `/item-attribute-records/{id}` | Retrieves attributes for a specific item |

### 3.4.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Average volume | 500 items/day average (~21/hour), 5,000 items/day peak (~208/hour), 10% expected growth |
| Y | Message Size | Average msg size | ~500 KB per STEP XML; JSON output is smaller |
| N | Performance Testing | Performance / Load / Stress | N/A |
| Y | Latency | Any specific latency requirements | Near real-time delivery |
| N | Scalability | Any specific scalability requirements | N/A |
| Y | Reliability | Reliability | 95% (Silver SLA) |
| Y | Reliability | Disaster Recovery | RTO ≤ 4 hours, RPO ≤ 2 hours |
| Y | Auditability & Observability | Fields to be traced | Refer to the Corporate Global Auditability and Observability requirements |
| Y | Logging | Fields or key message identifiers to be logged | Metcash item number, transaction ID, MetProms API response status |
| Y | Sequencing or scheduling | Msg/file schedule | Event-driven, out-of-sequence handling by target system (HTTP 409) |
| N | Backup & Archiving | Backup / Archiving | N/A |

### 3.4.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| API call failure (connectivity, authentication, transformation) | HTTP 5xx or communication error from the MetProms API | Retry up to 3 times. If the failure persists, log the error and enable manual retry from the monitoring console. | Email [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Out-of-sequence update (HTTP 409 Conflict) | MetProms returns 409 indicating the incoming message has an older timestamp than the current data | Log the conflict for auditability. No retry required - the more recent data is already applied. | No notification required (expected operational scenario). |
| Unexpected error | Any unhandled exception | Log error. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.4.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Product attribute changed in MetProducts | Updated attributes are applied in MetProms | End-to-end happy path: XML to cloud storage, transform to JSON, PUT to MetProms API |
| T2 | Message processed out of sequence | Out-of-sequence message is rejected by MetProms | MetProms rejects with HTTP 409 (Conflict) - no data overwritten |
| T3 | New item created in MetProducts | New item attributes are created in MetProms | POST endpoint returns 201 (Created) |
| T4 | API call fails (connectivity/authentication error) | Retry logic is applied, failed message logged to SMC | Verify SMC retry after configured attempts exhausted |
| T5 | Source message contains changes only to non-consumed fields | MetProms receives update but no meaningful change to stored attributes | Non-consumed field change verification |
| T6 | Location-level attributes updated for a specific state | Location-specific attributes are applied under the correct location in MetProms | E.g. CDS Levy for a specific state/region |

---



====================================================================================================
## DOC: FSD-EAII-289
====================================================================================================

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-289 - ABN Business Details Lookup v1 - Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3476390056/Mapping+-+EAII-289+-+ABN+Business+Details+Lookup+v1+-+Metcash+Internal+to+ATO)<br>[Mapping - EAII-289 - ABN Business Details Lookup v2 - Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3487301968/Mapping+-+EAII-289+-+ABN+Business+Details+Lookup+v2+-+Metcash+Internal+to+ATO)<br>[Mapping - EAII-289 - ACN Business Details Lookup v1 - Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3487301984/Mapping+-+EAII-289+-+ACN+Business+Details+Lookup+v1+-+Metcash+Internal+to+ATO)<br>[Mapping - EAII-289 - ACN Business Details Lookup v2 - Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3487531010/Mapping+-+EAII-289+-+ACN+Business+Details+Lookup+v2+-+Metcash+Internal+to+ATO) |
| TSD for the interface(s) | [TSD EAII-289 Metcash Internal to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3041787905/Technical+Specification+-+EAII-289+-+MDM+to+ATO) |
| ADO link for the feature | [ADO 262907](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/262907) |
| Source file(s) |  |
| Target file(s) |  |

### 3.1.3 API Endpoint(s) information

| **Item** | **Value** |
| --- | --- |
| Consumer-facing URL path | `GET /fetchDetailsREST/apn/getabn/v1?abn={abn}` |
| Consumer-facing transport | HTTP, synchronous request/response |
| Consumer-facing response format | XML (ABR-native structure under a Metcash namespace) |
| Target system URL | `http://abr.business.gov.au:80/abrxmlsearch/AbrXmlSearch.asmx` |
| Target system protocol | SOAP 1.2 |
| Target system operation | `SearchByABNv201408` |
| Target system authentication | `authenticationGuid` provided in the SOAP request body, value held in a deployment configuration variable |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| N | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | Volumes are low (driven by ad-hoc lookups). No specific peak/average volume targets defined. |
| N | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Single record lookup; response is a small XML document (a few KB). No specific size requirements. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance test requirements beyond confirming response within the latency target. |
| Y | Latency | Any specific latency requirements | End-to-end response time SHOULD be under 5 seconds for 95% of requests; dominated by ABR response time. |
| Y | Scalability | Any specific scalability requirements | Must scale to support concurrent ad-hoc lookups from all authorised internal consumer applications. |
| Y | Reliability | Reliability<br> Disaster Recovery | 95% availability target during business hours (Silver). DR per AIS platform standards. |
| Y | Auditability & Observability | Fields to be traced | Per Corporate Global Auditability and Observability requirements: TransactionID, request endpoint, ABN value, target endpoint, response status. |
| Y | Logging | Fields or key message identifiers to be logged | TransactionID, target service (`ATOService-getBusinessDetails`), begin/end/error event types, status code. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Synchronous on-demand lookup. No scheduling or sequencing requirements. |
| N | Backup & Archiving | Backup<br> Archiving | No persistent storage. No backup/archive requirements beyond audit log retention which is managed by the CLE platform. |
| N | Other / Misc. |  | None identified. |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ABR connectivity failure | Network error or timeout calling the ABR SOAP endpoint | Log error event with TransactionID; return HTTP fault to the consumer | Standard AIS platform alerting; no per-event notification required |
| ABR business fault | ABR returns a SOAP fault (e.g., invalid ABN, authentication failure) | Log error event with TransactionID and fault detail; return HTTP fault with the fault reason to the consumer | Standard AIS platform alerting |
| Invalid input parameter | ABN query parameter missing, empty, or not a valid 11-digit number | Log error event with TransactionID; return HTTP 400 to the consumer with a description of the validation failure | None - consumer-side error |
| Audit logging failure | CLE endpoint unavailable when publishing begin/end/error event | Continue processing the lookup; raise platform alert | Standard AIS platform alerting |
| Unexpected exception | Any other unhandled error during processing | Top-level catch-all logs the error with TransactionID and returns a generic HTTP 500 fault to the consumer | Standard AIS platform alerting |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Successful ABN lookup for a valid, currently-registered Australian business | HTTP 200 with the ABR business details returned under the Metcash namespace; TransactionID recorded in audit logs (begin + end events) | Happy path |
| T2 | Lookup for an ABN that exists in the Register but is cancelled or no longer trading | HTTP 200 with the ABR response indicating the entity's current status; lookup is still logged as a success |  |
| T3 | Lookup for a non-existent ABN | HTTP 200 with the ABR's standard "not found" response payload | ABR returns a valid response indicating no record; not treated as an error |
| T4 | Lookup with missing or empty ABN query parameter | HTTP 400 returned to consumer with a validation error description; error event logged | Input validation |
| T5 | ABR service unavailable (simulated network failure) | HTTP fault returned to consumer; error event logged with TransactionID | Connectivity failure |
| T6 | ABR returns a SOAP fault (e.g., bad authentication GUID) | HTTP fault returned to consumer with fault reason; error event logged | Backend failure |

---

### 3.2.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping Manifest - EAII-289 - Metcash Internal to ATO](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/fsd/TibcoATOBusinessDetails/Mapping%20Manifest%20-%20EAII-289%20-%20Metcash%20Internal%20to%20ATO.md) |
| TSD for the interface(s) | *To be created in tsd/EAII-289/* |
| ADO link for the feature | *To be added by the delivery team* |
| Source file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v1/source_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ACN%20Business%20Details%20Lookup%20v1/source_samples/) *(no samples provided - to be auto-generated)* |
| Target file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v1/target_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ACN%20Business%20Details%20Lookup%20v1/target_samples/) *(no samples provided - to be auto-generated)* |

### 3.2.3 API Endpoint(s) information

| **Item** | **Value** |
| --- | --- |
| Consumer-facing URL path | `GET /fetchDetailsREST/apn/gettbn/v1?acn={acn}` |
| Consumer-facing transport | HTTP, synchronous request/response |
| Consumer-facing response format | XML (ABR-native structure under a Metcash namespace) |
| Target system URL | `http://abr.business.gov.au:80/abrxmlsearch/AbrXmlSearch.asmx` |
| Target system protocol | SOAP 1.2 |
| Target system operation | `SearchByASICv201408` |
| Target system authentication | `authenticationGuid` provided in the SOAP request body, value held in a deployment configuration variable |

### 3.2.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| N | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | Volumes are low (driven by ad-hoc lookups). No specific peak/average volume targets defined. |
| N | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Single record lookup; response is a small XML document (a few KB). No specific size requirements. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance test requirements beyond confirming response within the latency target. |
| Y | Latency | Any specific latency requirements | End-to-end response time SHOULD be under 5 seconds for 95% of requests; dominated by ABR response time. |
| Y | Scalability | Any specific scalability requirements | Must scale to support concurrent ad-hoc lookups from all authorised internal consumer applications. |
| Y | Reliability | Reliability<br> Disaster Recovery | 95% availability target during business hours (Silver). DR per AIS platform standards. |
| Y | Auditability & Observability | Fields to be traced | Per Corporate Global Auditability and Observability requirements: TransactionID, request endpoint, ACN value, target endpoint, response status. |
| Y | Logging | Fields or key message identifiers to be logged | TransactionID, target service (`ATOService-getBusinessDetails`), begin/end/error event types, status code. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Synchronous on-demand lookup. No scheduling or sequencing requirements. |
| N | Backup & Archiving | Backup<br> Archiving | No persistent storage. No backup/archive requirements beyond audit log retention which is managed by the CLE platform. |
| N | Other / Misc. |  | None identified. |

### 3.2.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ABR connectivity failure | Network error or timeout calling the ABR SOAP endpoint | Log error event with TransactionID; return HTTP fault to the consumer | Standard AIS platform alerting; no per-event notification required |
| ABR business fault | ABR returns a SOAP fault (e.g., invalid ACN, authentication failure) | Log error event with TransactionID and fault detail; return HTTP fault with the fault reason to the consumer | Standard AIS platform alerting |
| Invalid input parameter | ACN query parameter missing, empty, or not a valid 9-digit number | Log error event with TransactionID; return HTTP 400 to the consumer with a description of the validation failure | None - consumer-side error |
| Audit logging failure | CLE endpoint unavailable when publishing begin/end/error event | Continue processing the lookup; raise platform alert | Standard AIS platform alerting |
| Unexpected exception | Any other unhandled error during processing | Top-level catch-all logs the error with TransactionID and returns a generic HTTP 500 fault to the consumer | Standard AIS platform alerting |

### 3.2.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Successful ACN lookup for a valid, currently-registered Australian company | HTTP 200 with the ABR business details returned under the Metcash namespace; TransactionID recorded in audit logs (begin + end events) | Happy path |
| T2 | Lookup for an ACN that exists but the company is deregistered | HTTP 200 with the ABR response indicating the entity's current status; lookup is still logged as a success |  |
| T3 | Lookup for a non-existent ACN | HTTP 200 with the ABR's standard "not found" response payload | ABR returns a valid response indicating no record; not treated as an error |
| T4 | Lookup with missing or empty ACN query parameter | HTTP 400 returned to consumer with a validation error description; error event logged | Input validation |
| T5 | ABR service unavailable (simulated network failure) | HTTP fault returned to consumer; error event logged with TransactionID | Connectivity failure |
| T6 | ABR returns a SOAP fault (e.g., bad authentication GUID) | HTTP fault returned to consumer with fault reason; error event logged | Backend failure |

---

### 3.3.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping Manifest - EAII-289 - Metcash Internal to ATO](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/fsd/TibcoATOBusinessDetails/Mapping%20Manifest%20-%20EAII-289%20-%20Metcash%20Internal%20to%20ATO.md) |
| TSD for the interface(s) | *To be created in tsd/EAII-289/* |
| ADO link for the feature | *To be added by the delivery team* |
| Source file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ABN Business Details Lookup v2/source_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ABN%20Business%20Details%20Lookup%20v2/source_samples/) *(no samples provided - to be auto-generated)* |
| Target file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ABN Business Details Lookup v2/target_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ABN%20Business%20Details%20Lookup%20v2/target_samples/) *(no samples provided - to be auto-generated)* |

### 3.3.3 API Endpoint(s) information

| **Item** | **Value** |
| --- | --- |
| Consumer-facing URL path | `GET /fetchDetailsResource/api/ato/getabn/v2?abn={abn}` |
| Consumer-facing transport | HTTP, synchronous request/response |
| Consumer-facing response format | XML - canonical `MetcashIdentifierBObj` |
| Target system URL path | `GET /api/ato/getabn/v1?abn={abn}` on the configured ABR REST host |
| Target system protocol | REST (HTTP) returning JSON |
| Target system authentication | Per environment configuration (no per-request credential in the request body for v2) |

### 3.3.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| N | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | Volumes are low (driven by ad-hoc lookups). No specific peak/average volume targets defined. |
| N | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Single record lookup; canonical response is a small XML document (under 5 KB). No specific size requirements. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance test requirements beyond confirming response within the latency target. |
| Y | Latency | Any specific latency requirements | End-to-end response time SHOULD be under 5 seconds for 95% of requests; dominated by ABR response time. |
| Y | Scalability | Any specific scalability requirements | Must scale to support concurrent ad-hoc lookups from all authorised internal consumer applications. |
| Y | Reliability | Reliability<br> Disaster Recovery | 95% availability target during business hours (Silver). DR per AIS platform standards. |
| Y | Auditability & Observability | Fields to be traced | Per Corporate Global Auditability and Observability requirements: TransactionID, request endpoint, ABN value, target endpoint, response status. |
| Y | Logging | Fields or key message identifiers to be logged | TransactionID, target service (`ATOService-getABNv2`), begin/end/error event types, status code. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Synchronous on-demand lookup. No scheduling or sequencing requirements. |
| N | Backup & Archiving | Backup<br> Archiving | No persistent storage. No backup/archive requirements beyond audit log retention which is managed by the CLE platform. |
| N | Other / Misc. |  | None identified. |

### 3.3.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ABR connectivity failure | Network error or timeout calling the ABR REST endpoint | Log error event with TransactionID; return HTTP fault to the consumer | Standard AIS platform alerting |
| ABR HTTP error response | ABR returns 4xx/5xx | Log error event with TransactionID, status code and any payload returned; return HTTP fault to the consumer | Standard AIS platform alerting |
| JSON parse failure | The ABR response cannot be parsed into the expected structure | Log error event with TransactionID and the raw payload; return HTTP fault to the consumer | Standard AIS platform alerting |
| Invalid input parameter | ABN query parameter missing, empty, or not a valid 11-digit number | Log error event with TransactionID; return HTTP 400 to the consumer with a description of the validation failure | None - consumer-side error |
| Audit logging failure | CLE endpoint unavailable when publishing begin/end/error event | Continue processing the lookup; raise platform alert | Standard AIS platform alerting |
| Unexpected exception | Any other unhandled error during processing | Top-level catch-all logs the error with TransactionID and returns a generic HTTP 500 fault to the consumer | Standard AIS platform alerting |

### 3.3.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Successful ABN lookup for a valid, currently-registered Australian business | HTTP 200 with `MetcashIdentifierBObj` populated with the entity description, identifier sub-type and party identification block; TransactionID recorded in audit logs | Happy path |
| T2 | Lookup for an ABN that exists but the entity is cancelled | HTTP 200 with the canonical response indicating the entity's current registration status | Status mapping |
| T3 | Lookup for a non-existent ABN | HTTP 200 with the canonical response indicating no record found |  |
| T4 | Lookup with missing or empty ABN query parameter | HTTP 400 returned to consumer with a validation error description; error event logged | Input validation |
| T5 | ABR REST service unavailable (simulated network failure) | HTTP fault returned to consumer; error event logged with TransactionID | Connectivity failure |
| T6 | ABR returns a 5xx HTTP error | HTTP fault returned to consumer; error event logged with status code | Backend failure |
| T7 | ABR returns an unexpected JSON payload that cannot be parsed | HTTP fault returned to consumer; error event logged with the raw payload | Schema drift |

---

### 3.4.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping Manifest - EAII-289 - Metcash Internal to ATO](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/fsd/TibcoATOBusinessDetails/Mapping%20Manifest%20-%20EAII-289%20-%20Metcash%20Internal%20to%20ATO.md) |
| TSD for the interface(s) | *To be created in tsd/EAII-289/* |
| ADO link for the feature | *To be added by the delivery team* |
| Source file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v2/source_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ACN%20Business%20Details%20Lookup%20v2/source_samples/) *(no samples provided - to be auto-generated)* |
| Target file(s) | [sample_payloads/TibcoATOBusinessDetails/EAII-289 - ACN Business Details Lookup v2/target_samples/](https://file+.vscode-resource.vscode-cdn.net/c%3A/Magesh/Project/GITHubCoPilot/TibcoToAIS-main/sample_payloads/TibcoATOBusinessDetails/EAII-289%20-%20ACN%20Business%20Details%20Lookup%20v2/target_samples/) *(no samples provided - to be auto-generated)* |

### 3.4.3 API Endpoint(s) information

| **Item** | **Value** |
| --- | --- |
| Consumer-facing URL path | `GET /fetchDetailsResource/api/ato/getacn/v2?acn={acn}` |
| Consumer-facing transport | HTTP, synchronous request/response |
| Consumer-facing response format | XML - canonical `MetcashIdentifierBObj` |
| Target system URL path | `GET /api/ato/getacn/v1?acn={acn}` on the configured ABR REST host |
| Target system protocol | REST (HTTP) returning JSON |
| Target system authentication | Per environment configuration (no per-request credential in the request body for v2) |

### 3.4.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| N | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | Volumes are low (driven by ad-hoc lookups). No specific peak/average volume targets defined. |
| N | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Single record lookup; canonical response is a small XML document (under 5 KB). No specific size requirements. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance test requirements beyond confirming response within the latency target. |
| Y | Latency | Any specific latency requirements | End-to-end response time SHOULD be under 5 seconds for 95% of requests; dominated by ABR response time. |
| Y | Scalability | Any specific scalability requirements | Must scale to support concurrent ad-hoc lookups from all authorised internal consumer applications. |
| Y | Reliability | Reliability<br> Disaster Recovery | 95% availability target during business hours (Silver). DR per AIS platform standards. |
| Y | Auditability & Observability | Fields to be traced | Per Corporate Global Auditability and Observability requirements: TransactionID, request endpoint, ACN value, target endpoint, response status. |
| Y | Logging | Fields or key message identifiers to be logged | TransactionID, target service (`ATOService-getACNv2`), begin/end/error event types, status code. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Synchronous on-demand lookup. No scheduling or sequencing requirements. |
| N | Backup & Archiving | Backup<br> Archiving | No persistent storage. No backup/archive requirements beyond audit log retention which is managed by the CLE platform. |
| N | Other / Misc. |  | None identified. |

### 3.4.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ABR connectivity failure | Network error or timeout calling the ABR REST endpoint | Log error event with TransactionID; return HTTP fault to the consumer | Standard AIS platform alerting |
| ABR HTTP error response | ABR returns 4xx/5xx | Log error event with TransactionID, status code and any payload returned; return HTTP fault to the consumer | Standard AIS platform alerting |
| JSON parse failure | The ABR response cannot be parsed into the expected structure | Log error event with TransactionID and the raw payload; return HTTP fault to the consumer | Standard AIS platform alerting |
| Invalid input parameter | ACN query parameter missing, empty, or not a valid 9-digit number | Log error event with TransactionID; return HTTP 400 to the consumer with a description of the validation failure | None - consumer-side error |
| Audit logging failure | CLE endpoint unavailable when publishing begin/end/error event | Continue processing the lookup; raise platform alert | Standard AIS platform alerting |
| Unexpected exception | Any other unhandled error during processing | Top-level catch-all logs the error with TransactionID and returns a generic HTTP 500 fault to the consumer | Standard AIS platform alerting |

### 3.4.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Successful ACN lookup for a valid, currently-registered Australian company | HTTP 200 with `MetcashIdentifierBObj` populated with the entity description, identifier sub-type and party identification block; TransactionID recorded in audit logs | Happy path |
| T2 | Lookup for an ACN that exists but the company is deregistered | HTTP 200 with the canonical response indicating the entity's current registration status | Status mapping |
| T3 | Lookup for a non-existent ACN | HTTP 200 with the canonical response indicating no record found |  |
| T4 | Lookup with missing or empty ACN query parameter | HTTP 400 returned to consumer with a validation error description; error event logged | Input validation |
| T5 | ABR REST service unavailable (simulated network failure) | HTTP fault returned to consumer; error event logged with TransactionID | Connectivity failure |
| T6 | ABR returns a 5xx HTTP error | HTTP fault returned to consumer; error event logged with status code | Backend failure |
| T7 | ABR returns an unexpected JSON payload that cannot be parsed | HTTP fault returned to consumer; error event logged with the raw payload | Schema drift |

---



====================================================================================================
## DOC: FSD-EAII-297
====================================================================================================

### 3.1.2 Interface Requirements / Mapping Details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface |  |
| TSD for the interface |  |
| ADO link for the feature | [ADO 262915](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/262915) |
| Source file(s) | ![diagram](images/03.png)<br> <br>![diagram](images/02.png)<br> <br>![diagram](images/07.png) |
| Target file(s) | ![diagram](images/01.png)<br> <br>![diagram](images/10.png)<br> <br>![diagram](images/11.png) |

### 3.1.3 API Endpoint(s) Information

#### Inbound REST Endpoints (exposed by integration platform)

| **Operation** | **HTTP Method** | **Path** | **Request Format** | **Response Format** |
| --- | --- | --- | --- | --- |
| Get New Supplier Number | POST | `/api/mdm/api/suppliermgmt/newsupplier/v1` | JSON (`NewSupplierRequest`) | JSON (`NewSupplierResponse`) |
| Release Reserved Supplier Number | POST | `/api/mdm/api/suppliermgmt/releasesupplier/v1` | JSON (`clearSupplierRequest`) | JSON (`clearSupplierResponse`) |

**Authentication:** Bearer token in `Authorization` header. Invalid → HTTP 401 Unauthorized.

**Request schema — Get New Supplier Number:**

```
{
  "TransactionID": "001Rl00001O9viJIAR_20260709160955",
  "SourceSystemID": "Salesforce",
  "AgreementID": "P00029015"
}
```

- `TransactionID`: optional — caller-supplied correlation ID; generated by integration if absent
- `SourceSystemID`: optional — identifies the calling system
- `AgreementID`: **mandatory** — the supplier agreement identifier to associate with the new supplier number

**Response schema — Get New Supplier Number:**

```
{
  "TransactionID": "001Rl00001O9viJIAR_20260709160955",
  "SourceSystemID": "Salesforce",
  "AgreementID": "P00029015",
  "SupplierNumber": "1012695"
}
```

**Request schema — Release Reserved Supplier Number:**

```
{
  "TransactionID": "P00028593_20260709183546",
  "SourceSystemID": "Salesforce",
  "AgreementID": "P00028593"
}
```

**Response schema — Release Reserved Supplier Number:**

```
{
  "TransactionID": "P00028593_20260709183546",
  "SourceSystemID": "Salesforce",
  "AgreementID": "P00028593",
  "SuccessString": "01"
}
```

#### Outbound SOAP Endpoint (called by integration platform)

| **Operation** | **Protocol** | **Transport** | **Service** | **WSDL** |
| --- | --- | --- | --- | --- |
| Get Next Supplier Number | SOAP 1.1 | HTTPS | MDM Supplier Number Service | ![diagram](images/12.png) |
| Clear Reserved Supplier Numbers | SOAP 1.1 | HTTPS | MDM Supplier Number Service |  |

- **Authentication:** WS-Security UsernameToken (username and password per environment — stored in secrets management, not embedded in code)
- **TLS:** Mutual authentication with environment-specific keystore
- **Endpoint URL:** Environment-specific; configured via deployment variables

### 3.1.6 Non-Functional Requirements

| **Applicable** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume | Volume is driven by new supplier onboarding events. Expected volume is low (tens to hundreds of requests per day), with peaks during high-activity onboarding periods. |
| Y | Volume | Average volume | Typically follows business-hours patterns aligned to supplier onboarding activity. |
| N | Volume | Seasonal considerations | Not expected to vary significantly by season. |
| N | Volume | Expected growth | No significant volume growth anticipated without a corresponding growth in supplier onboarding activity. |
| Y | Message Size | Average msg size | Very small — request and response payloads are under 1 KB each. |
| N | Message Size | Max msg size | No practical upper bound given the simple field structures. |
| N | Performance Testing | Performance / Load / Stress | Low volume service; no dedicated performance testing required unless integration platform imposes constraints. |
| Y | Latency | Any specific latency requirements | Synchronous integration — caller waits for response. Acceptable end-to-end latency: <5 seconds under normal conditions. MDM SLA is the dominant factor. |
| N | Scalability | Any specific scalability requirements | No scaling requirements beyond standard platform capabilities. |
| Y | Reliability | Reliability | Silver SLA — 95% availability. Outages that block supplier onboarding should be resolved within the Silver MTTR SLA (≤20 working days). |
| Y | Reliability | Disaster Recovery | RTO ≤ 4 hours, RPO ≤ 2 hours (Silver tier). |
| Y | Auditability & Observability | Fields to be traced | Transaction ID, Agreement ID, Source System ID, operation name (Get or Release), outcome (success/failure), timestamp. Refer to Corporate Global Auditability and Observability requirements. |
| Y | Logging | Key identifiers to be logged | Transaction ID and Agreement ID must be logged on every request and response. Error details (fault code, message) must be logged on failure. MDM credentials and API keys must NOT be logged. |
| N | Sequencing or scheduling | Msg/file schedule | No scheduling — purely on-demand synchronous requests. |
| N | Backup & Archiving | Backup / Archiving | No state maintained by the integration layer. Master data is held in IBM MDM; backup and archiving are the responsibility of the MDM platform. |
| N | Other / Misc |  |  |

### 3.1.7 Exception Handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Authentication failure | Invalid or missing Bearer token in `Authorization` header | Reject request; log authentication failure event with Transaction ID; return HTTP 401 with message: `"Authentication Failed: Please check Authorization Key"` | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| MDM processing fault | MDM returns a SOAP fault (`processingFault`) | Log fault details (fault code and message) with Transaction ID and Agreement ID; return HTTP 200 JSON response with failure message: `"Request for new supplier failed. Please contact Metcash."` (Get) or `SuccessString: "FAILED"` (Release) | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| MDM timeout | Call to MDM exceeds configured timeout threshold | Log timeout exception with Transaction ID and Agreement ID; return error response to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unhandled exception | Any unexpected runtime error in the integration layer | Log exception details (stack trace, fault message) with Transaction ID; return error response to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.11 Test Scenarios

| **#** | **Test Scenario** | **Expected Results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Request a new supplier number with a valid Agreement ID and valid API key | HTTP 200 response with a 7-digit supplier number starting with `10` in the `SupplierNumber` field; `AgreementID` matches the request; `TransactionID` echoed or generated | Sample: `AgreementID=P00029015` → `SupplierNumber=1012695` |
| T2 | Request a new supplier number where the request supplies its own TransactionID | HTTP 200 response with the caller-supplied `TransactionID` echoed back unchanged | Verify pass-through of caller's correlation ID |
| T3 | Request a new supplier number without a TransactionID | HTTP 200 response with a system-generated TransactionID (non-empty unique value) | Verify auto-generation behaviour |
| T4 | Release a reserved supplier number with a valid Agreement ID and valid API key | HTTP 200 response with `SuccessString` populated with MDM result code; `AgreementID` matches request | Sample: `AgreementID=P00028593` → `SuccessString=01` |
| T5 | Submit a Get request with an invalid or missing API key | HTTP 401 response with message `"Authentication Failed: Please check Authorization Key"` | Verify no MDM call is made |
| T6 | Submit a Release request with an invalid or missing API key | HTTP 401 response with message `"Authentication Failed: Please check Authorization Key"` | Verify no MDM call is made |
| T7 | Submit a Get request when the MDM service returns a processing fault | HTTP 200 response with `Message: "Request for new supplier failed. Please contact Metcash."` and no `SupplierNumber` | Simulate MDM SOAP fault |
| T8 | Submit a Release request when the MDM service returns a processing fault | HTTP 200 response with `SuccessString: "FAILED"` | Simulate MDM SOAP fault |
| T9 | Submit a Get request when the MDM service is unavailable (timeout) | Error response returned to caller within configured timeout period; error event logged | Verify graceful timeout handling |
| T10 | Submit a request with all optional fields absent (TransactionID and SourceSystemID omitted) | HTTP 200 success response; TransactionID auto-generated; SourceSystemID absent from response | Verify optional field handling |

---



====================================================================================================
## DOC: FSD-EAII-301_517_516
====================================================================================================

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-301 - Supplier Contract to EIM - Supplier MDM to EIM](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519774730/Mapping+-+EAII-301+-+Supplier+Contract+to+EIM+-+Supplier+MDM+to+EIM) |
| TSD for the interface(s) | [Technical Specification - EAII-301 - Supplier MDM to EIM Data Platform](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035693057/Technical+Specification+-+EAII-301+EAII-517+EAII-516+-+Supplier+MDM+to+EIM+ALM+Sorted+Food+Sorted) |
| ADO link for the feature | [Task 263641](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/263641)`: EAII-301 - MDM Supplier - Supplier Information to EIM &#124; Supplier MDM to EIM Data Platform - Functional Specification` |
| Source file(s) | ![diagram](images/25.png)![diagram](images/14.png)<br> <br>![diagram](images/28.png) |
| Target file(s) | ![diagram](images/07.png)![diagram](images/13.png)<br> <br>![diagram](images/29.png) |

### 3.1.3 API Endpoint(s) information

This interface delivers data to Azure Blob Storage.

**Source queue:**

| **Parameter** | **Value** |
| --- | --- |
| Queue name | `Service.MDM.SupplierContractEIM.Q` |
| Bridged from topic | `Service.MDM.TradingAccount.T` |
| Bridge selector | `INTERFACECODE='MDMSUPCNT001'` |
| Acknowledgement | Client-mode (message acknowledged after successful processing) |
| Concurrency | 1 session (single-threaded) |

**Target (Azure Blob Storage):**

| **Parameter** | **Value** |
| --- | --- |
| Delivery mechanism | Azure Blob Storage upload (replacing legacy S3 bucket via shared Storage Service) |
| Blob container/path | Environment-specific, path prefix `MDMToEIM/` |
| File naming | Generated from MDM request ID and transaction context |
| File format | Pipe-delimited (pipe character separator), newline-terminated records |
| Encoding | UTF-8 |

**MDM REST API (data retrieval):**

| **Parameter** | **Value** |
| --- | --- |
| Endpoint | `<https://{mdm-host}:9443/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful`> |
| HTTP Method | PUT |
| Content-Type | application/json |
| Authentication | Certificate-based (keystore) + Basic Auth credentials |
| Purpose | Retrieve complete supplier contract data using reference from queue message |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume / Average volume | Event-driven - one message per supplier contract change. Average volume 10-15 messages per day. Volume driven by supplier onboarding/modification activity. |
| Y | Message Size | Average msg size | Source XML message is large (TCRMService schema is ~1.5MB definition). Individual messages vary based on contract complexity. |
| N | Performance Testing |  |  |
| N | Latency |  | Near-real-time (event-driven), no specific latency SLA identified. |
| N | Scalability |  | Single-threaded processing (max 1 concurrent session). |
| Y | Reliability | Reliability | At-least-once delivery via client-mode message acknowledgement. Message is acknowledged only on successful processing or explicit error handling. Retry with 3 attempts and 5-second intervals for blob storage upload failures. |
| Y | Auditability & Observability | Fields to be traced | Transaction ID (from MDM request or generated UUID), PartyId, RequestID. Refer to Corporate Global Auditability and Observability requirements. |
| Y | Logging | Key identifiers | Transaction ID, process start/end events, error details including PartyId or RequestID for correlation. |
| N | Sequencing or scheduling |  | Event-driven, no scheduling. Single-threaded ensures sequential processing. |
| N | Backup & Archiving |  | Managed by Azure Blob Storage lifecycle/retention policies. |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| MDM REST API retrieval failure | HTTP error or timeout from MDM REST endpoint | Log error with Transaction ID, PartyId/RequestID context. Acknowledge message (prevent redelivery loop). | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Blob storage upload failure | Error from Azure Blob Storage | Retry up to 3 times with 5-second intervals. On exhaustion, log error and acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Transformation error | Invalid/unexpected data in MDM message causing mapping failure | Log error with full exception details and correlation identifiers. Acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unexpected error (catch-all) | Any unhandled exception | Log error with stack trace and process context. Acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit a supplier contract change message with all 11 record types populated | File generated in Azure Blob Storage containing all 11 record type sections with correct pipe-delimited format | Happy path |
| T2 | Submit a message with duplicate reference data values (e.g., repeated category names) | Output file contains deduplicated reference values only | Tests dedup logic |
| T3 | MDM REST API unavailable during data retrieval | Error logged with correlation details, message acknowledged, notification sent | Data retrieval failure |
| T4 | Blob storage upload fails on first 2 attempts, succeeds on 3rd | File successfully uploaded after retry | Retry resilience |
| T5 | Blob storage upload fails after all 3 retry attempts | Error logged, message acknowledged, notification sent | Retry exhaustion |
| T6 | Submit a minimal supplier message (only parent company and legal entity) | File generated with only populated record types; empty record types omitted or contain zero rows | Sparse data handling |

---

### 3.2.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-517, EAII-516 - Supplier Contract to ALM Sorted, Food Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519381529/Mapping+-+EAII-517+EAII-516+-+Supplier+Contract+to+ALM+Sorted+Food+Sorted) |
| TSD for the interface(s) | [Technical Specification - EAII-301 - Supplier MDM to EIM Data Platform](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035693057/Technical+Specification+-+EAII-301+EAII-517+EAII-516+-+Supplier+MDM+to+EIM+ALM+Sorted+Food+Sorted) |
| ADO link for the feature | [Task 403288](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/403288)`: EAII-517 - MDM Supplier - Supplier Information to Sorted ALM &#124; Supplier MDM to Sorted (ALM) - Functional Specification` |
| Source file(s) | ![diagram](images/01.png)![diagram](images/08.png)<br> <br>![diagram](images/22.png) |
| Target file(s) | ![diagram](images/24.png)![diagram](images/19.png)<br> <br>![diagram](images/17.png) |

### 3.2.3 API Endpoint(s) information

**Source queue:**

| **Parameter** | **Value** |
| --- | --- |
| Queue name | `Service.MDM.SupplierContractALM.Q` |
| Bridged from topic | `Service.MDM.TradingAccount.T` |
| Bridge selector | `INTERFACECODE='MDMSUPCNT001'` |
| Queue options | `store=$sys.failsafe, redeliveryDelay=300` |
| Acknowledgement | Client-mode (message acknowledged after successful processing) |
| Concurrency | Up to 10 sessions |

**Target (ALM Sorted REST API):**

| **Parameter** | **Value** |
| --- | --- |
| Target endpoint | `<https://{host}/occ/v2/alm/mdm/supplier`> |
| HTTP Method | POST |
| Content-Type | application/json |
| Authentication | Certificate-based (TLS mutual auth via keystore) |
| Response | HTTP status code indicating success/failure |

**MDM REST API (data retrieval):** Same as EAII-301 (Section 3.1.3).

### 3.2.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume / Average volume | Event-driven - one message per supplier contract change. Average volume 10-15 messages per day. Up to 10 concurrent sessions. |
| Y | Message Size | Average msg size | Source XML varies with contract complexity. JSON output is a subset focused on supplier entity structure. |
| N | Performance Testing |  |  |
| N | Latency |  | Near-real-time (event-driven). |
| Y | Scalability |  | Supports up to 10 concurrent processing sessions. |
| Y | Reliability | Reliability | At-least-once delivery via client-mode acknowledgement. Retry with 3 attempts and 30-second intervals for transient failures. Redelivery cap of 3 to prevent poison message loops. |
| Y | Auditability & Observability | Fields to be traced | Transaction ID (generated UUID), Admin Contract ID, Agreement Name, Legal Entity ID. |
| Y | Logging | Key identifiers | Transaction ID, Admin Contract ID, Agreement Name, process events. Error details include Legal Entity ID when available. |
| N | Sequencing or scheduling |  | Event-driven, no ordering requirement. |
| N | Backup & Archiving |  |  |
| N | Other / Misc. |  |  |

### 3.2.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| ALM Sorted API failure | HTTP error response from target endpoint | Throw error, trigger message redelivery. After max redeliveries exhausted, acknowledge and log. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) (on retry exhaustion) |
| JSON rendering failure | Invalid data structure preventing JSON conversion | Log error with Admin Contract ID and Agreement Name context. Acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| MDM REST API retrieval failure | HTTP error or timeout | Log error. Acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Poison message (max redelivery exceeded) | Message redelivery count >= maximum (3) | Acknowledge message without processing. Log at reduced severity (no notification). | None (silent consume to prevent alert storm) |
| Unexpected error (catch-all) | Any unhandled exception | Log error with full context. Acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.2.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit a complete supplier contract change message | JSON payload delivered to ALM Sorted endpoint with HTTP 200 response | Happy path |
| T2 | ALM Sorted endpoint returns HTTP 500 on first delivery | Message redelivered; succeeds on retry | Transient failure |
| T3 | ALM Sorted endpoint consistently unavailable (all retries fail) | Message acknowledged after max redeliveries, error logged | Persistent failure |
| T4 | MDM REST API unavailable during data retrieval | Error logged with correlation details, message acknowledged | Data retrieval failure |
| T5 | Message with maximum redelivery count already reached | Message acknowledged without processing, logged without notification | Poison message handling |

---

### 3.3.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-517, EAII-516 - Supplier Contract to ALM Sorted, Food Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519381529/Mapping+-+EAII-517+EAII-516+-+Supplier+Contract+to+ALM+Sorted+Food+Sorted) |
| TSD for the interface(s) | [Technical Specification - EAII-301 - Supplier MDM to EIM Data Platform](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035693057/Technical+Specification+-+EAII-301+EAII-517+EAII-516+-+Supplier+MDM+to+EIM+ALM+Sorted+Food+Sorted) |
| ADO link for the feature | [Task 403252](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/403252)`: EAII-516 - MDM Supplier - Supplier Information to Sorted Food) &#124; Supplier MDM to Sorted (Food) - Functional Specification` |
| Source file(s) | ![diagram](images/08.png)![diagram](images/20.png)<br> <br>![diagram](images/22.png) |
| Target file(s) | ![diagram](images/19.png)![diagram](images/26.png)<br> <br>![diagram](images/17.png) |

### 3.3.3 API Endpoint(s) information

**Source queue:**

| **Parameter** | **Value** |
| --- | --- |
| Queue name | `Service.MDM.SupplierContractAutoCT.Q` |
| Bridged from topic | `Service.MDM.TradingAccount.T` |
| Bridge selector | `INTERFACECODE='MDMSUPCNT001'` |
| Queue options | `store=$sys.failsafe, redeliveryDelay=300` |
| Acknowledgement | Client-mode (message acknowledged after successful processing) |
| Concurrency | Up to 10 sessions |

**Target (Food Sorted REST API):**

| **Parameter** | **Value** |
| --- | --- |
| Target endpoint | `<https://{host}/metcashcommercewebservices/v2/mdm/supplier`> |
| HTTP Method | POST |
| Content-Type | application/json |
| Authentication | Certificate-based (TLS mutual auth via keystore) |
| Response | HTTP status code indicating success/failure |

**MDM REST API (data retrieval):** Same as EAII-301 (Section 3.1.3).

### 3.3.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume / Average volume | Event-driven. Average volume 10-15 messages per day. Up to 10 concurrent sessions. |
| Y | Message Size | Average msg size | Same as EAII-517. |
| N | Performance Testing |  |  |
| N | Latency |  | Near-real-time (event-driven). |
| Y | Scalability |  | Supports up to 10 concurrent processing sessions. |
| Y | Reliability | Reliability | Same as EAII-517: at-least-once delivery, 3 retries with 30-second intervals, redelivery cap of 3. |
| Y | Auditability & Observability | Fields to be traced | Transaction ID, Admin Contract ID, Agreement Name, Legal Entity ID. |
| Y | Logging | Key identifiers | Same as EAII-517. |
| N | Sequencing or scheduling |  |  |
| N | Backup & Archiving |  |  |
| N | Other / Misc. |  |  |

### 3.3.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Food Sorted API failure | HTTP error response from target endpoint | Throw error, trigger message redelivery. After max redeliveries, acknowledge and log. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) (on retry exhaustion) |
| JSON rendering failure | Invalid data structure | Log error with context. Acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| MDM REST API retrieval failure | HTTP error or timeout | Log error. Acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Poison message (max redelivery exceeded) | Message redelivery count >= maximum (3) | Acknowledge without processing. Log without notification. | None |
| Unexpected error (catch-all) | Any unhandled exception | Log error. Acknowledge message. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.3.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit a complete supplier contract change message | JSON payload delivered to Food Sorted endpoint with HTTP 200 response | Happy path |
| T2 | Food Sorted endpoint returns HTTP 500 on first delivery | Message redelivered; succeeds on retry | Transient failure |
| T3 | Food Sorted endpoint consistently unavailable | Message acknowledged after max redeliveries, error logged | Persistent failure |
| T4 | MDM REST API unavailable during data retrieval | Error logged, message acknowledged | Data retrieval failure |
| T5 | Poison message scenario | Acknowledged without processing | Max redelivery handling |

---



====================================================================================================
## DOC: FSD-EAII-302
====================================================================================================

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-302 - Supplier Contract (MDM) to PIM (STIBO)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3495985203/Mapping+-+EAII-302+-+Supplier+Contract+MDM+to+PIM+STIBO) |
| TSD for the interface(s) | [Technical Specification - EAII-302 - Supplier MDM to STIBO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035725825/Technical+Specification+-+EAII-302+-+Supplier+MDM+to+STIBO) |
| ADO link for the feature | [ADO 262920](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/262920) |
| Source file(s) (MDM Request) | ![diagram](images/08.png)<br> <br>![diagram](images/04.png)<br> <br>![diagram](images/02.png) |
| Target file(s) (PIM Transformed Sample) | ![diagram](images/10.png)<br> <br>![diagram](images/12.png)<br> <br>![diagram](images/11.png) |
| PIM Response | ![diagram](images/09.png) |
| JMS Properties | ![diagram](images/14.png) |

### 3.1.3 API Endpoint(s) information

**Target — STIBO STEP PIM Supplier Hierarchy endpoint**

| Attribute | Value |
| --- | --- |
| Protocol | HTTPS |
| HTTP method | `POST` |
| URL path | `/restapi/integrationendpoints/iiep_REST_SupplierHier/upload` |
| Query parameters | `context=Australian`, `workspace=Main` |
| Request content type | `application/xml` |
| Request body | STEP-ProductInformation XML (Classifications hierarchy) |
| Authentication | OAuth 2.0 bearer token in `Authorization` header |
| Success response | HTTP 202 (Accepted for processing) |

**Target — OAuth 2.0 Authorization Server**

| Attribute | Value |
| --- | --- |
| Protocol | HTTPS |
| Discovery endpoint | `/auth/.well-known/openid-configuration` (returns `token_endpoint` URL) |
| Grant type | `client_credentials` |
| Credentials | Service `client_id` and `client_secret` provisioned per environment (stored as secrets) |
| Token type | Bearer |

**Source — inbound message channel**

The source is an asynchronous message channel that delivers TCRMService XML messages published by IBM MDM. The channel provides at-least-once delivery and requires the integration to acknowledge each message only after downstream processing has succeeded. The specific broker/topic/queue names are Metcash infrastructure configuration and are captured in the traceability appendix rather than as part of the external contract.

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume<br> Average volume<br> Seasonal considerations<br> Expected growth | To be confirmed by MDM operations team based on the rate of supplier contract changes in production. |
| Y | Message Size | Average msg size<br> Max. msg size<br> Expected growth | Message size varies with the number of contract components per supplier. Typical payloads are within a few tens of kilobytes; exact figures to be confirmed from production samples. |
| N | Performance Testing | Performance<br> Load<br> Stress | No specific performance-test requirement beyond standard AIS platform testing. |
| Y | Latency | Any specific latency requirements | End-to-end latency (MDM publish → PIM 202) should be seconds under normal conditions. No hard real-time requirement — the interface is asynchronous and does not participate in an interactive flow. |
| Y | Scalability | Any specific scalability requirements | The interface must scale horizontally with the source message channel's parallelism to absorb bursts of supplier updates without backlog. |
| Y | Reliability | Reliability<br> Disaster Recovery | 99.9% (Gold SLA). No message loss: the inbound message must not be acknowledged until PIM has accepted the payload. Disaster recovery aligned with the Gold-tier target platform. |
| Y | Auditability & Observability | Fields to be traced | Correlation identifier, supplier identifier and contract identifier(s) must be traceable across the request, response and any error events published to Corporate Logging. Refer to the Corporate Global Auditability and Observability requirements. |
| Y | Logging | Fields or key message identifiers to be logged | Correlation identifier, service name, PIM endpoint, request outcome (HTTP status), retry count, error code and error message. Full request/response payloads are logged only to the audit/error channels, not to general operations logs. |
| N | Sequencing or scheduling | Msg/file schedule<br> Msg/file sequence | Event-driven; no schedule. Message ordering is not required — each supplier update is self-contained. |
| Y | Backup & Archiving | Backup<br> Archiving | Not applicable at the interface layer — supplier master data is retained in MDM and PIM. Audit events are retained per the Corporate Logging retention policy. |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Connectivity failure to PIM | Network error, DNS resolution failure or TLS handshake failure when calling the PIM endpoint | Retry the call up to a bounded number of attempts with a fixed backoff pause. If still failing, publish an error event to Corporate Logging and route the source message to the platform's poison-message handling. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Connectivity failure to OAuth authorization server | Network error obtaining an access token | Fail the current delivery attempt; the outer retry loop will re-attempt token acquisition on the next iteration. If still failing after retries, treat as a delivery failure (see above). | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| PIM authentication rejected | HTTP 401/403 from PIM or the token endpoint | Publish an error event and route the source message to poison-message handling. Do not silently retry indefinitely — an authentication rejection typically indicates a credential or configuration issue that requires human intervention. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| PIM business rejection | HTTP 4xx (other than 401/403) from the Supplier Hierarchy endpoint indicating the payload is not acceptable | Publish an error event with the response body and route to poison-message handling. Do not retry, as the payload will not become acceptable on re-submission. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| PIM temporarily unavailable | HTTP 5xx from PIM or connection reset | Retry as per the connectivity-failure scenario. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Transformation error | The inbound message does not contain the required fields to construct the STEP payload | Publish an error event with the correlation identifier and route to poison-message handling. Do not retry. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Retry budget exhausted | The bounded retry count for a message is reached without an accepted response | Publish a final error event, route the message to poison-message handling, and notify Integration Support. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Happy-path: MDM publishes a well-formed supplier contract message, PIM responds HTTP 202 | Message is transformed to STEP XML, POSTed to PIM, PIM returns 202, inbound message is acknowledged, success event is published to Corporate Logging | Cover both "new supplier" and "amended supplier" MDM payloads |
| T2 | Correlation identifier reuse: inbound message carries a `TRANSACTIONID` property | The value is used as the correlation identifier for all downstream log events; no new UUID is generated | Verify by checking Corporate Logging events for the correlation ID |
| T3 | Correlation identifier fallback: inbound message does not carry a `TRANSACTIONID` property | A new UUID is generated and used for all downstream log events |  |
| T4 | PIM transient failure recovery: PIM returns HTTP 5xx on the first attempt, HTTP 202 on the second | Message is retried after the backoff pause and ultimately accepted; inbound message is acknowledged |  |
| T5 | PIM persistent unavailability: PIM returns HTTP 5xx on every attempt | After the retry budget is exhausted, an error event is published and Integration Support is notified; the inbound message is routed to poison-message handling |  |
| T6 | PIM authentication rejection: PIM returns HTTP 401 | No further retries; error event is published and Integration Support is notified |  |
| T7 | Transformation error: inbound message is missing mandatory fields required to build the STEP payload | Interface publishes an error event and routes the message to poison-message handling without calling PIM |  |
| T8 | Token refresh: cached token is close to expiry | Interface acquires a new token from the authorization server and continues successfully |  |
| T9 | Concurrent supplier updates: multiple supplier contract messages arrive in a short window | All messages are processed independently, each with its own correlation identifier and acknowledgement |  |
| T10 | Known issue T-KI-01 (OAuth discovery bypass, if adopted): AIS uses a directly configured token endpoint without invoking the discovery URL | Token acquisition still succeeds and each supplier update is delivered to PIM | Cover both cold-start and cached-token scenarios |

---



====================================================================================================
## DOC: FSD-EAII-304
====================================================================================================

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3503849480&draftShareId=d527b0b5-81af-4e93-ae7f-0664b0596e36&atlOrigin=eyJpIjoiNzE3MGUwNjc3MDAzNDM2YzhkZWFmZGRlM2I1YWQ0NjgiLCJwIjoiYyJ9](https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3503849480&draftShareId=d527b0b5-81af-4e93-ae7f-0664b0596e36&atlOrigin=eyJpIjoiNzE3MGUwNjc3MDAzNDM2YzhkZWFmZGRlM2I1YWQ0NjgiLCJwIjoiYyJ9) |
| TSD for the interface(s) | [Technical Specification - EAII-304 - Liquor Suppliers to EIM](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3502997507/Technical+Specification+-+EAII-304+-+Liquor+Suppliers+to+EIM) |
| ADO link for the feature | [Task 263674](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/263674)`: EAII-304 - IBA Directs ALM Orders &#124; Supplier to EIM - Functional Specification` |
| Source file(s) | ![diagram](images/14.png)![diagram](images/18.png)<br> <br>![diagram](images/09.png)![diagram](images/22.png)<br> <br>![diagram](images/23.png) |
| Target file(s) | ![diagram](images/01.png)![diagram](images/13.png)<br> <br>![diagram](images/17.png)![diagram](images/25.png)<br> <br>![diagram](images/08.png) |

### 3.1.3 API Endpoint(s) information

**Inbound REST API (Supplier Upload):**

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/api/iba/directs/v1/upload` |
| Content-Type | `application/json` |
| Authentication | Bearer token (via `Authorization` HTTP header) |
| Request Body | JSON `DirectsFileDocument` (see schema below) |
| Response Body | JSON `DirectsResponse` with `Code` (integer) and `Description` (string) |

**Request Schema (**`DirectsFileDocument`):

```
{
  "DocumentHeader": {
    "Transaction": {
      "TransactionID": "string (optional)",
      "DocumentType": "string (optional)",
      "TransactionDateTime": "datetime (optional)"
    },
    "Supplier": {
      "SupplierID": "string (required)"
    }
  },
  "DirectsFile": {
    "FileContent": "string (base64-encoded ZIP, required)"
  }
}
```

**Response Schema (**`DirectsResponse`):

```
{
  "Code": 200,
  "Description": "Success"
}
```

**Cloud Storage Paths (Target Delivery):**

| Path | Purpose |
| --- | --- |
| `IBADirects/in` | Input staging - source files stored here on upload |
| `IBADirects/toeim` | Output delivery - PSV and trigger files placed here for EIM pickup |
| `IBADirects/archive` | Archive - processed source files moved here after successful translation |
| `IBADirects/error` | Error - files that fail validation stored here |

**Target File Delivery:**

The PSV output file and an accompanying trigger file are uploaded to the cloud storage output directory (`IBADirects/toeim`). **[Assumption]** GoAnywhere MFT is expected to mediate file delivery between cloud storage and the EIM staging directory (`eim-alm-int-files/IBA_DIRECTS/TIBCO_LANDING`). The exact trigger file naming convention and pickup mechanism require confirmation.

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume / Average volume / Seasonal considerations / Expected growth | Approximately 8 files per month across all suppliers (very low volume). Each submission contains a batch of direct delivery records for a single supplier. No significant seasonal variation expected. |
| Y | Message Size | Average msg size / Max. msg size / Expected growth | Maximum file size: 3 MB (configured as `MaxFileByteSize`) - applies to the decoded ZIP payload within the API request, not the unzipped content. Based on sample data: ZIP payloads range from ~20 KB (Coopers) to ~685 KB (CUB); unzipped source data ranges from ~318 KB to ~5.3 MB; target PSV output ranges from ~144 KB to ~2.4 MB. |
| N | Performance Testing | Performance / Load / Stress |  |
| N | Latency | Any specific latency requirements | Asynchronous processing; no real-time latency requirement. The synchronous upload response confirms receipt only. |
| N | Scalability | Any specific scalability requirements | Currently single-threaded (`MaxSessions=1`). May require scaling if submission volumes increase. |
| Y | Reliability | Reliability / Disaster Recovery | Retry on transient cloud storage communication errors up to configured maximum (10 retries). Failed messages remain on the queue for redelivery. 95% availability (Silver SLA). |
| Y | Auditability & Observability | Fields to be traced | Transaction ID, Supplier ID, Document Type, processing timestamps, error codes. Refer to the Corporate Global Auditability and Observability requirements. |
| Y | Logging | Fields or key message identifiers to be logged | Transaction ID, Supplier ID, processing status (start/success/error), error codes (IBADIRECTS-ERR-001 through IBADIRECTS-ERR-004), file names. |
| N | Sequencing or scheduling | Msg/file schedule / Msg/file sequence | Event-driven (on-demand supplier uploads). No scheduled processing. |
| Y | Backup & Archiving | Backup / Archiving | Processed source files are archived to cloud storage archive directory (`IBADirects/archive`). Output PSV files delivered to EIM output directory. |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Authentication failure | Invalid or missing bearer token in API request | Return HTTP 401 Unauthorized response. Log authentication failure. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| File size exceeded | Uploaded file exceeds 3 MB maximum | Return HTTP 400 Bad Request response. Store file to error directory. Log error with code IBADIRECTS-ERR-001. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Decompression failure | ZIP file is corrupted or cannot be extracted | Log error with code IBADIRECTS-ERR-003. Update transaction history with error status. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Transformation failure | Data cannot be parsed or transformed to PSV format | Log error with code IBADIRECTS-ERR-002. Update transaction history with error status. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Cloud storage communication error | Storage Service is unavailable or returns error | Retry up to configured maximum (10 attempts). If retries exhausted, log error with storage-specific code and update transaction history. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Archive failure | Source file cannot be moved to archive directory | Log error with code IBADIRECTS-ERR-004. Update transaction history with error status. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Unexpected error | Any unhandled exception during processing | Log full error details. Update transaction history with error status. Message remains on queue for potential redelivery. | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit valid directs file with correct bearer token | API returns HTTP 200 with success response. File stored to input directory. Translation triggered. PSV file and trigger file delivered to output directory. Source archived. | Happy path |
| T2 | Submit file with invalid bearer token | API returns HTTP 401 Unauthorized. File is not stored. Error logged. | Authentication test |
| T3 | Submit file exceeding 3 MB size limit | API returns HTTP 400 Bad Request. File stored to error directory. Error code IBADIRECTS-ERR-001 logged. | File size validation |
| T4 | Submit corrupted ZIP file (valid token, valid size) | API returns success (file accepted for processing). During translation, decompression fails. Error code IBADIRECTS-ERR-003 logged. Transaction history updated with error. | Error handling - decompression |
| T5 | Submit file with invalid data format (cannot transform to PSV) | Translation fails. Error code IBADIRECTS-ERR-002 logged. Transaction history updated with error. | Error handling - transformation |
| T6 | Cloud storage service unavailable during translation | Translation retries up to 10 times. If still unavailable, error logged with storage error code. | Retry logic test |
| T7 | Verify PSV output format contains all 20 fields with pipe delimiter | PSV file contains pipe-separated records with fields: SUPPID, PRODCODE, PRODDESC, SUPPPRODCODE, SUPPPRODDESC, PACKSIZE, PRODCATEGORY, GTIN, LICNUMBER, CUSTNUMBER, CUSTNAME, ADDRESS1, SUBURB, POSTCODE, STATE, INVNUMBER, INVDATE, INVCASES, INVLITRES, INVVALUE | Format verification |
| T8 | Verify source file is archived after successful processing | Source file moved from input directory to archive directory. Temporary files cleaned up. | Archive and cleanup |
| T9 | Submit valid file and verify trigger file is created alongside PSV | Both PSV file and trigger file present in output directory | Trigger file generation |
| T10 | Submit request with missing required fields (e.g., no SupplierID) | API returns HTTP 400 Bad Request with validation error | Input validation |

---



====================================================================================================
## DOC: FSD-EAII-333
====================================================================================================

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3452108805&draftShareId=b6cba10e-05e7-493e-85f1-d1f650c71ff6&atlOrigin=eyJpIjoiZWM4NDlkYzE1MDZjNDc1ZWE0ZDI3MWQ1NTY5YWZkZTIiLCJwIjoiYyJ9](https://metcash.atlassian.net/wiki/pages/resumedraft.action?draftId=3452108805&draftShareId=b6cba10e-05e7-493e-85f1-d1f650c71ff6&atlOrigin=eyJpIjoiZWM4NDlkYzE1MDZjNDc1ZWE0ZDI3MWQ1NTY5YWZkZTIiLCJwIjoiYyJ9) |
| TSD for the interface(s) | [Technical Specification - EAII-333 - Storeline to CCC](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3061514242/Technical+Specification+-+EAII-333+-+Storeline+to+CCC) |
| ADO link for the feature | [Task 263999](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/263999)`: EAII-333 - Campbells Payment - Storeline sending payment request to Sorted for a customer order &#124; Storeline to CCC - Functional Specification` |
| Source file(s) | Source_sample_request1.xml Source_sample_request2.xml Source_sample_request3.xml Source_sample_response1.xml Source_sample_response2.xml Source_sample_response3.xml |
| Target file(s) | Not available |

### 3.1.3 API Endpoint(s) information

**Source (Inbound) - Storeline:**

| Attribute | Value |
| --- | --- |
| Protocol | SOAP over HTTP/HTTPS |
| Endpoint Path | `/PaymentRequestService` |
| Operation | `paymentRequest` |
| WSDL Namespace | `<http://www.campbells.com.au/PaymentRequestService/`> |
| Authentication | None (network-level security assumed) |

**Target (Outbound) - Sorted (SAP Commerce Cloud):**

| Attribute | Value |
| --- | --- |
| Protocol | REST over HTTPS |
| HTTP Method | POST |
| Endpoint Path | `/occ/v2/campbellsretailersspa/orders/{orderId}/braintree/paymentcapture?captureAmount={captureAmount}` |
| Request Body | Empty (parameters passed via URL path and query string) |
| Response Format | JSON |
| Authentication | Mutual TLS (client certificate) |
| Port | 443 |

**Request Parameter Mapping:**

| Source Field | Target Parameter | Parameter Type | Format |
| --- | --- | --- | --- |
| orderId | `{orderId}` | URL Path | 10-digit zero-padded numeric string (e.g., `0040797969`) |
| paymentAmount | `{captureAmount}` | URL Query String | Numeric, may use scientific notation (e.g., `2.9674E4` = $296.74) |

**Response Schema (JSON):**

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| responseCode | integer | Yes | 1 = success, 2 = error with extended code, other = general failure |
| extendedErrorCode | string | No | Present when responseCode indicates an error; "0" on success |
| message | string | No | Descriptive text; "SUCCESFULL" on success (note: misspelling present in actual system); formatted as "Error {code} - {msg}" when responseCode = 2 |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume / Average volume | ~200 messages/day average (based on 3,021 messages observed over 15 days). Individual payment captures triggered by customer order completion. |
| Y | Message Size | Average msg size / Max. msg size | Small payloads. Request: ~350 bytes (SOAP XML envelope). Response: ~120 bytes (JSON). See sample payloads in Appendix 4.2. |
| N | Performance Testing | Performance / Load / Stress |  |
| Y | Latency | Any specific latency requirements | Synchronous - end-to-end response time dependent on SAP Commerce Cloud. Target: <5 seconds including network round trip. |
| N | Scalability | Any specific scalability requirements |  |
| Y | Reliability | Reliability / Disaster Recovery | 99.5% availability (Gold SLA). No built-in retry - caller is responsible for retry on failure. |
| Y | Auditability & Observability | Fields to be traced | Transaction ID, Order ID, Customer ID, Response Code. Refer to the Corporate Global Auditability and Observability requirements. |
| Y | Logging | Fields or key message identifiers to be logged | Transaction ID, Service Name, Order ID, Payment Amount, Response Code, Error details (on failure). |
| N | Sequencing or scheduling | Msg/file schedule / Msg/file sequence |  |
| N | Backup & Archiving | Backup / Archiving |  |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Target system connectivity failure | Unable to establish HTTPS connection to SAP Commerce Cloud | Log error event with exception details; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Target system timeout | SAP Commerce Cloud does not respond within configured timeout | Log error event with timeout details; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Target system HTTP 4xx error | Client error response from SAP Commerce Cloud (e.g., invalid order ID) | Log error event; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Target system HTTP 5xx error | Server error response from SAP Commerce Cloud | Log error event; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Payment capture declined | responseCode != 1 returned by target | Log warning event with response details; return response (not fault) to caller with formatted error message | No notification - caller handles business-level failures |
| Unexpected internal error | Any unhandled exception during processing | Log error event with full stack trace; return SOAP fault to caller | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit valid payment capture request with correct order ID and payment amount | Response code = 1 returned; payment successfully captured | Happy path |
| T2 | Submit payment capture request with invalid/non-existent order ID | Response code != 1 with appropriate error message returned | Verify error message formatting |
| T3 | Submit payment capture request with zero amount | Target system returns error response; formatted error returned to caller | Edge case validation |
| T4 | Submit payment capture when SAP Commerce Cloud is unavailable | SOAP fault returned to caller; error logged with connectivity details | Connectivity failure |
| T5 | Submit payment capture when SAP Commerce Cloud responds slowly (timeout) | SOAP fault returned to caller; timeout error logged | Timeout handling |
| T6 | Submit payment capture that returns responseCode = 2 | Error message formatted as "Error {extendedErrorCode} - {message}" | Error formatting logic |
| T7 | Verify audit logging records transaction ID, order ID, and response code for successful capture | Log entries contain expected fields at begin and end audit steps | Auditability |
| T8 | Verify audit logging captures error details for failed payment capture | Log entry contains error type, exception details, and transaction context | Error auditability |

---



====================================================================================================
## DOC: FSD-EAII-514
====================================================================================================

### 3.1.2 Interface requirements / Mapping details

| **Document** | **Link (URL)** |
| --- | --- |
| Mapping sheet for the interface(s) | [Mapping - EAII-514 - Realtime Pricing - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) |
| TSD for the interface(s) | [Technical Specification - - EAII-514 - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3487301633/Technical+Specification+-+EAII-514+-+Sorted+to+PE) |
| ADO link for the feature | [Task 396069](https://dev.azure.com/METCASHDevOps/Squad%2020/_workitems/edit/396069)`: EAII-514 - Realtime Pricing - Functional Specification` |
| Source file(s) | ![diagram](images/04.png)![diagram](images/08.png)<br> <br>![diagram](images/09.png)![diagram](images/03.png) |
| Target file(s) | N/A - target is AS/400 stored procedure (no file-based samples available) |

### 3.1.3 API Endpoint(s) information

**REST Endpoint:**

| Attribute | Value |
| --- | --- |
| Protocol | HTTPS |
| Method | POST |
| Path | `/api/pricing/api/rest/PricingServiceBW6/v3` |
| Content-Type (Request) | application/json |
| Content-Type (Response) | application/json |
| Authentication | TBD (to be defined in TSD) |

**SOAP Endpoint:**

| Attribute | Value |
| --- | --- |
| Protocol | HTTPS |
| Method | POST (SOAP) |
| Path | `/api/pricing/api/soap/PricingServiceBW6/v3` |
| SOAP Action | /GetPricingData |
| WSDL Operation | GetPricingData |
| Authentication | TBD (to be defined in TSD) |

**Target System (AS/400 Power Enterprise):**

| Attribute | Value |
| --- | --- |
| Protocol | JDBC |
| Driver | IBM AS/400 JDBC Driver |
| Stored Procedure | CX40K6B |
| Schema | IDSPNDUR1 |
| Query Timeout | 30 seconds |
| Max Connections | 1000 |
| Login Timeout | 30 seconds |

### 3.1.6 Non-functional requirements

| **Applicable (Y/N)** | **Category** | **Sub-category** | **Requirement** |
| --- | --- | --- | --- |
| Y | Volume | Peak volume | 10,784 calls/hour (378 calls/minute). Target capacity: 20,000 calls/hour (1,000 calls/minute) to accommodate Christmas peak and post-Horizon growth |
|  |  | Average volume | High - CLE logging disabled in production due to volume/performance impact. Traffic is combined across IGA, Campbells, and C-Store portals |
|  |  | Seasonal considerations | Christmas peak drives highest volumes. Planned capacity targets +50% above current peak |
|  |  | Expected growth | Significant increase expected post-Horizon go-live as legacy Enterprise Portal features migrate to Sorted, bringing more IGA customers placing warehouse orders (including Allocation orders) |
| Y | Message Size | Average msg size | Request: ~500 bytes (5 products). Response: ~2KB (5 products) |
|  |  | Max. msg size | Request: ~1.5KB (20 products). Response: ~8KB (20 products) |
|  |  | Expected growth | Stable - schema limits to 20 products max |
| Y | Performance Testing | Performance / Load / Stress | Load testing required. Target: sustain 1,000 calls/minute (20,000 calls/hour) with <2s response time at 20 products per request |
| Y | Latency | Any specific latency requirements | Response time proportional to product count. Single product: ~30-60ms (stored proc + overhead). 20 products: ~600ms-1.2s (sequential). Target: <2 seconds for max 20 products |
| N | Scalability | Any specific scalability requirements | Standard platform auto-scaling applies |
| Y | Reliability | Reliability | 99% (Gold SLA) |
|  |  | Disaster Recovery | Gold-tier DR: Active-Active, RTO <=1 Hr, RPO <=15 min |
| Y | Auditability & Observability | Fields to be traced | Transaction ID (UUID), Service Name, Start/End DateTime, Destination (Schema.StoredProc.User), Status (1=success, 0=failure) |
| Y | Logging | Fields or key message identifiers to be logged | Transaction UUID, Company, Pillar, Department, WarehouseId, CustomerId, Product list, Error details (on failure) |
| N | Sequencing or scheduling | Msg/file schedule | Not applicable - synchronous on-demand service |
| N | Backup & Archiving | Backup / Archiving | No integration-layer data persistence requiring backup |
| N | Other / Misc. |  |  |

### 3.1.7 Exception handling

| **Failure Scenario** | **Trigger** | **Action** | **Notification** |
| --- | --- | --- | --- |
| Database outage (planned) | Database outage flag is set to true | Return configured error message immediately without attempting database connection | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Database connectivity failure | JDBC connection timeout or SQL exception during stored procedure call | Log error event with fault details, log error to transaction history, return HTTP 500 / SOAP Fault with error message | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Query timeout | Stored procedure execution exceeds 30-second timeout | Log timeout error, return HTTP 500 / SOAP Fault indicating timeout | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Invalid request | Request fails schema validation (missing required fields, invalid format) | Return HTTP 4XX client error / SOAP Fault with validation details | None (client error) |
| Unexpected error | Any unhandled exception during processing | Catch-all fault handler logs error event and transaction history, returns HTTP 500 / SOAP Fault with error message | [IntegrationSupport@metcash.com](mailto:IntegrationSupport@metcash.com) |
| Product-level error | Stored procedure returns error for a specific product (e.g., product not found) | Include error message in the product's PriceData response element; do not fail entire request | None (included in response) |

### 3.1.11 Test scenarios

| **#** | **Test scenario** | **Expected results** | **Comments** |
| --- | --- | --- | --- |
| T1 | Submit pricing request with single valid product for IGA pillar | Response contains pricing breakdown for the product with all applicable pricing fields populated | Happy path - single product |
| T2 | Submit pricing request with 20 valid products | Response contains pricing data for all 20 products | Maximum products boundary test |
| T3 | Submit pricing request with invalid product number | Response contains the product entry with ErrorMsg field populated; other valid products still return pricing | Product-level error isolation |
| T4 | Submit pricing request with database outage flag active | Service returns configured error message without attempting database call | Planned outage behaviour |
| T5 | Submit pricing request with invalid company code (not MTT) | Request rejected with validation error | Schema validation |
| T6 | Submit pricing request with invalid pillar code | Request rejected with validation error | Schema validation |
| T7 | Submit pricing request with invalid date format | Request rejected with validation error | Date pattern validation |
| T8 | Submit pricing request when AS/400 is unreachable | Error response returned with timeout/connectivity error details; error logged to transaction history | Unplanned outage |
| T9 | Submit pricing request via SOAP endpoint | Response contains same pricing data as equivalent REST request | Protocol parity |
| T10 | Submit pricing request with 0 products | Response returns context fields (Company, Pillar etc.) with empty PriceData array | Edge case - no products |
| T11 | Submit pricing request for different pillars (ALM, CCC, CSD) | Correct pricing returned per pillar context | Multi-pillar validation |

---
