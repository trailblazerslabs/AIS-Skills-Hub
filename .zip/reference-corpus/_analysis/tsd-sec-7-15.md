

====================================================================================================
## DOC: TSD-EAII-284_283_282_385
====================================================================================================

# 7 Communication Overview

## 7.1 Communication Components

![Communication Diagram-20260723-110800.png](images/07.png)

| Component | Source | Destination | Protocol | Port | Authentication |
| --- | --- | --- | --- | --- | --- |
| STIBO → GoAnywhere | STIBO (SFTP) | GoAnywhere MFT | SFTP | 22 | SFTP key-based authentication |
| GoAnywhere → Blob Storage | GoAnywhere | Azure Blob Storage (`t3data{env}aesta01`) | HTTPS | 443 | Managed Identity (target state; GoAnywhere upgrade in progress) |
| Blob Storage → Event Grid | Azure Blob Storage | Event Grid System Topic | HTTPS (internal, platform-managed) | 443 | System Topic (implicit; Azure-managed) |
| Event Grid → Service Bus | Event Grid System Topic | Service Bus Topic (`data.metproducts.{env}.sbt`) | AMQP (Event Grid internal delivery) | 443/5671 | System-Assigned Managed Identity (Azure Service Bus Data Sender) |
| Function App → Service Bus | Function App (`t3-met-metproducts-{env}-ae-func`) | Service Bus Topic Subscription | AMQP (pull trigger — Function polls) | 5671 (AMQP) / 443 (fallback) | System-Assigned Managed Identity (Azure Service Bus Data Receiver) |
| Function App → Blob Storage | Function App | Azure Blob Storage | HTTPS | 443 | System-Assigned Managed Identity (Storage Blob Data Reader) |
| Function App → AIS Key Vault | Function App | Azure Key Vault (`t3data{env}ae1kv01`) | HTTPS | 443 | System-Assigned Managed Identity (Key Vault Secrets User) |
| Function App → SMC Key Vault | Function App | Azure Key Vault (`t3enabling{env}ae1kv01`) | HTTPS | 443 | System-Assigned Managed Identity (Key Vault Secrets User) |
| Function App → SMC (APIM) | Function App | SMC via APIM (`t3-met-core-{apim-env}-ae1-apim`) | HTTPS | 443 | APIM Subscription Key (`Ocp-Apim-Subscription-Key` header) |
| Function App → Application Insights | Function App | Azure Application Insights | HTTPS | 443 | Instrumentation key / connection string |
| Function App → IndiPIM (EAII-284) | Function App | IndiPIM REST API | HTTPS | 443 | OAuth 2.0 password grant + refresh_token grant (Basic auth for token acquisition; Bearer token for API calls) |
| Function App → Sorted (EAII-282, EAII-283) | Function App | Sorted Marketplace REST API | HTTPS | 443 | Mutual TLS (X.509 client certificate) |
| Function App → MetProms (EAII-385) | Function App | Retail Express (MetProms) REST API | HTTPS | 443 | OAuth 2.0 Client Credentials (Bearer token) |

---

# 8 Data Architecture

## 8.1 Data Model

NA — no relational/structured data model. All four interfaces pass XML/JSON payloads through without persisting a data model of their own (Blob Storage is a transient staging area, not a data store with a schema).

## 8.2 Stored Procedures

NA

## 8.3 Stored Procedure Triggers

NA

## 8.4 Database Technical Specification

NA — no database component in this solution.

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

| Data | Location | Retention |
| --- | --- | --- |
| Source STIBO XML | Blob Storage (`stibo/frompim/corporateitem/`, `stibo/frompim/supplieritem/`) | 90 days — supports SMC-based replay/reprocessing for all four interfaces |
| SMC observation records (`LogMessage` stage arrays, exception detail) | SMC platform | Per SMC platform retention policy (not owned by this interface) |
| Application Insights telemetry | Log Analytics Workspace | Per workspace retention policy (platform default, not overridden for this solution) |
| Outbound payloads to target systems | Not persisted by this solution — target systems (Sorted/IndiPIM/MetProms) own retention of what they receive | N/A |

### 8.5.2 Data Backup

Blob Storage account backup follows standard Azure Storage redundancy configuration (LRS non-prod, GRS prod — §6.5). No interface-specific backup process beyond the 90-day blob retention window.

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

Source XML blobs are not explicitly deleted by this solution — they age out per the 90-day retention/lifecycle policy on the storage account (§8.5.1.1). No interface-specific destruction job exists.

#### 8.5.3.2 State process for data/system destruction

NA — no additional state destruction process; covered by standard Azure Storage lifecycle management.

---

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

Deployment follows the Azure DevOps CI/CD pipeline (`pipelines/metproductsfnapp.yml`) through the stages: Build → DEV (dv1) → SIT (st1) → UAT (ut1) → PROD (prd), with approval gates at SIT, UAT, and PROD stages.

The following ordered sequence must be followed for the production cut-over of EAII-282/283/284 (TIBCO migrations) and EAII-385 (net-new):

## 9.2 Deployment Preference

N/A

## 9.3 Deployment Environment Migration

*All source code is managed under source control (currently Github or Azure Devops Repo).*

*Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure.*

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PROD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.

---

# 10 Disaster Recovery

*Capture any specific disaster recovery requirements for the solution here.*

---

# 11 Support Documentation

![diagram](images/06.png)

---

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | Azure function can accept the request data up to 100 MB. | The HTTP request length is limited to 100 MB (104,857,600 bytes), and the URL length is limited to 4 KB (4,096 bytes) | [https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits](https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits) |

# 13 Assumptions

NA

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

# 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/19.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |


====================================================================================================
## DOC: TSD-EAII-289
====================================================================================================

# 7 Communication Overview

## 7.1 Communication Components

All APIM endpoints use the consistent base URL pattern: `https://cloud-api-{env}-internal.metcash.com`

| **Environment** | **APIM Base URL** | **Operations** |
| --- | --- | --- |
| DEV | `https://cloud-api-dev-internal.metcash.com` | `/eis/abnlookup/v1/SearchByABN`, `/eis/abnlookup/v2/SearchByABN`, `/eis/abnlookup/v1/SearchByACN`, `/eis/abnlookup/v2/SearchByACN` |
| SIT | `https://cloud-api-sit-internal.metcash.com` | (same paths) |
| UAT | `https://cloud-api-uat-internal.metcash.com` | (same paths) |
| PREPROD | `https://cloud-api-preprod-internal.metcash.com` | (same paths) |
| PROD | `https://cloud-api-prd-internal.metcash.com` | (same paths) |

**ABR Backend Endpoints (per environment):**

| **Environment** | **ATO REST Endpoint** | **Notes** |
| --- | --- | --- |
| All | ATO ABN/ACN REST search endpoints<br> Base Url: `http://abr.business.gov.au:80/abrxmlsearch/AbrXmlSearch.asmx` | Per environment configuration via APIM named values |

# 8 Data Architecture

## 8.1 Data Model

*NA*

## 8.2 Stored Procedures

*NA*

## 8.3 Stored Procedure Triggers

*NA*

## 8.4 Database Technical Specification

*NA*

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

*NA*

### 8.5.2 Data Backup

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

*NA*

#### 8.5.3.2 State process for data/system destruction

*NA*

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

A parallel-run transition period may be required where both TIBCO BW6 and APIM endpoints are available. Consumer applications will be reconfigured to point to the new APIM endpoints. Rollback involves reverting endpoint configuration to the legacy TIBCO addresses.

## 9.2 Deployment Preference

APIM Standard/Premium tier provides 99.95% SLA with built-in regional redundancy. Given the low volume (ad-hoc lookups), no additional load balancing beyond platform defaults is required.

## 9.3 Deployment Environment Migration

All source code (APIM policies, XSLT transform templates, API definitions, Bicep/ARM templates) is managed under source control (Azure DevOps Repo).

Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure:

- DEV → SIT → UAT → PREPROD → PROD
- Environment-specific values (ATO endpoints, Key Vault references) managed via pipeline variables and APIM named values

# 10 Disaster Recovery

  - APIM Standard/Premium tier provides built-in regional redundancy
  - ATO (external) DR is managed by the Australian Taxation Office
  - No integration-level DR requirements beyond platform capabilities (Silver SLA — 95% availability during business hours)
  - Recovery: Redeploy APIM API definitions, policies, and transform templates from source control via CI/CD pipeline

# 11 Support Documentation

![diagram](images/03.png)![diagram](images/02.png)![diagram](images/07.png)

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | APIM policy execution timeout | APIM has a default forward request timeout of 300 seconds | Well within requirements (<5s target latency) |
| 2 | ATO REST endpoint uses HTTP (not HTTPS) | The ATO REST endpoint may operate on HTTP | This is the ATO's published endpoint; outside Metcash's control |
| 3 | ATO availability | The ATO REST API is externally managed by the ATO; its availability, throughput and contract changes are outside Metcash's control | Per FSD Section 2.3 |
| 4 | APIM transformation size limits | APIM policies have a body size limit for inline transformations (typically 256 KB for non-streaming) | ABR responses are small; not expected to be an issue |
| 5 | Key Vault secret rotation | ATO API credentials must be updated in Key Vault if the ATO issues new credentials | Manual rotation process unless auto-rotation is configured |
| 6 | XSLT version | APIM supports XSLT 1.0 only; complex transformations may require Liquid templates instead | Evaluate transform complexity during development |

# 13 Assumptions

  1. Consumer applications can be reconfigured to call the new APIM endpoints
  2. The `MetcashIdentifierBObj` canonical schema is defined and available in JSON Schema form
  3. The ATO REST API contract remains stable during and after migration
  4. The existing APIM infrastructure (shared instance) has sufficient capacity for low-volume ad-hoc lookups
  5. Network connectivity between the APIM VNet and the ATO REST endpoints is established or can be established
  6. SMC supports receiving audit events via HTTP calls from APIM `send-request` policy actions
  7. The ATO XML response structure is well-defined and can be reliably transformed to the canonical JSON format within APIM policies
  8. A data-specific Key Vault is available (or will be provisioned) for storing ATO API credentials
  9. Consumer applications always expect JSON responses; no XML response format is required

# 14 Reference Documents and Architecture

| **Document** | **Link** |
| --- | --- |
| Azure API Management policies reference | [Microsoft Learn — APIM policies](https://learn.microsoft.com/en-us/azure/api-management/api-management-policies) |
| Transform and protect APIs — Azure API Management | [Microsoft Learn — Transform API](https://learn.microsoft.com/en-us/azure/api-management/transform-api) |
| XSLT transformation in APIM policies | [Microsoft Learn — XSLT policy](https://learn.microsoft.com/en-us/azure/api-management/xslt-policy) |
| Azure API Management Named Values / Key Vault | [Microsoft Learn — Named Values](https://learn.microsoft.com/en-us/azure/api-management/api-management-howto-properties) |
| Functional Specification — EAII-289 — MDM Supplier to ATO | [FSD — EAII-289](https://metcash.sharepoint.com/sites/EAI/Shared%20Documents/EAII-289) |
| Mapping Manifest — EAII-289 — Metcash Internal to ATO | [Mapping Manifest — EAII-289](https://metcash.sharepoint.com/sites/EAI/Shared%20Documents/EAII-289) |
| Target canonical schema | `Schemas/MetcashIdentifierBObj.json` (JSON) |

![diagram](images/09.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |


====================================================================================================
## DOC: TSD-EAII-297
====================================================================================================

# 7 Communication Overview

## 7.1 Communication Components

![EAII-297-Communication-Diagram.drawio (1)-20260724-100336.png](images/04.png)

| **Component** | **Source** | **Destination** | **Protocol** | **Port** |
| --- | --- | --- | --- | --- |
| Salesforce → APIM | Salesforce | Azure API Management | HTTPS | 443 |
| APIM → Logic App | Azure API Management | Logic App HTTP Trigger | HTTPS | 443 |
| Logic App → IBM MDM | Logic App | IBM MDM SOAP Service | HTTPS | 9443 |
| Logic App → SMC | Logic App | SMC (via APIM) | HTTPS | 443 |
| Logic App → Application Insights | Logic App | Application Insights | HTTPS | 443 |

# 8 Data Architecture

## 8.1 Data Model

*NA*

## 8.2 Stored Procedures

*NA*

## 8.3 Stored Procedure Triggers

*NA*

## 8.4 Database Technical Specification

**Azure SQL Database:** Not required for this integration. No Azure SQL Server (`Microsoft.Sql/servers`) or Azure SQL Database (`Microsoft.Sql/databases`) resource is provisioned for EAII-297.

**SMC :** The SMC platform manages its own backend datastore independently of this integration. Transaction metadata written to SMC via `startObservation` and `observationPoint` APIs is governed by the SMC platform's own data retention policy.

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

*N/A*

### 8.5.2 Data Backup

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

*N/A*

#### 8.5.3.2 State process for data/system destruction

*N/A*

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

*N/A*

## 9.2 Deployment Preference

*N/A*

## 9.3 Deployment Environment Migration

*All source code is managed under source control (currently Github or Azure Devops Repo).*

*Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure.*

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PROD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.

# 10 Disaster Recovery

*N/A*

# 11 Support Documentation

![diagram](images/03.png)

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | Azure function can accept the request data up to 100 MB. | The HTTP request length is limited to 100 MB (104,857,600 bytes), and the URL length is limited to 4 KB (4,096 bytes) | [https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits](https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits) |

# 13 Assumptions

- any assumption while designing solution

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

# 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/09.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |


====================================================================================================
## DOC: TSD-EAII-301_302_516_517
====================================================================================================

## 7 Communication Overview

![Communication Diagram-20260825-093004.png](images/14.png)

### 7.1 Communication Components

The solution uses Azure Service Bus subscriptions for inbound event delivery, Blob Storage for the EAII-301 reference and output-file flow, HTTPS REST calls for MDM and the Sorted targets, and APIM for SMC observation calls.

## 8 Data Architecture

### 8.1 Data Model

No relational or persistent data model is introduced. XML, JSON, and flat-file payloads are transformed transiently. EAII-301 uses Blob Storage as transient file staging.

### 8.2 Stored Procedures

Not applicable.

### 8.3 Stored Procedure Triggers

Not applicable.

### 8.4 Database Technical Specification

Not applicable; no database is used.

### 8.5 Data Retention

| Data | Location | Retention |
| --- | --- | --- |
| Inbound JMS payload | Blob Storage, `t3data{env}aesta01` | Aligned to Service Bus message TTL via lifecycle policy |
| EIM output | Blob Storage `eim/toeim/supplierinfo` | Existing 30-day retention |
| SMC observations | SMC | Platform retention policy |
| Application Insights telemetry | Log Analytics | Workspace retention policy |
| ALM/Food outbound payloads | Target systems | Target-owned retention |
| PIM outbound payloads (EAII-302) | STIBO STEP PIM | Target-owned retention |
| MDM responses | Not persisted | Transient only |

## 9 Deployment and Monitoring Considerations

### 9.1 Transition Period

Deployment follows the standard AIS Azure DevOps CI/CD pipeline pattern (new pipeline, once the repo `Metcash.AIS.Data.MDMSupplierInfo` is created — §00-index open items) through the stages: Build → DEV (dv1) → SIT (st1) → UAT (ut1) → PROD (prd), with approval gates at SIT, UAT, and PROD stages.

### 9.2 Deployment Preference

Not applicable.

### 9.3 Environment Migration

- Pull Request → DV1 automated deployment.
- DV1 → ST1 → UT1 → PROD through gated approvals.
- Infrastructure is defined in Bicep templates in `metcash-ais-infrastructure`.

## 10 Disaster Recovery

Not applicable.

## 11 Support Documentation

![diagram](images/15.png)

## 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | Azure function can accept the request data up to 100 MB. | The HTTP request length is limited to 100 MB (104,857,600 bytes), and the URL length is limited to 4 KB (4,096 bytes) | [https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits](https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits) |

# 13 Assumptions

- NA

## 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

## 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/18.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |
## 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

## 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/18.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |


====================================================================================================
## DOC: TSD-EAII-304
====================================================================================================

# 7 Communication Overview

## 7.1 Communication Components

![Untitled Diagram-Communication-Diagram.drawio-20260810-053516.png](images/06.png)

# 8 Data Architecture

## 8.1 Data Model

*NA*

## 8.2 Stored Procedures

*NA*

## 8.3 Stored Procedure Triggers

*NA*

## 8.4 Database Technical Specification

*NA*

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

The IBA Directs interface uses **Azure Blob Storage** to store source, output, archived, and error files. The files are organized into structured folders based on the processing stage:

| Blob Path | Purpose |
| --- | --- |
| `IBADirects/in/` | **Input** – ZIP files received from liquor suppliers and stored for downstream processing. |
| `IBADirects/ToEIM/` | **Output** – PSV file generated after successful translation and placed here for EIM pickup. |
| `IBADirects/archive/` | **Archive** – Source ZIP files moved here after successful translation and processing. |
| `IBADirects/error/` | **Error** – Files that fail validation or processing are stored here for investigation and error handling. |

To comply with **Metcash data retention policies and audit requirements**, the following retention rules are applied:

- Files stored under the `IBADirects/archive/` folder are retained for a maximum of **90 days** and are automatically deleted after the retention period.
- Files stored under the `IBADirects/error/` folder are retained for **30 days** and are automatically deleted thereafter.
- Files under the `IBADirects/in/` folder are retained only for the duration required for successful downstream processing and are subsequently moved to the `IBADirects/archive/` folder.
- PSV and trigger files under `IBADirects/ToEIM/` are retained based on the EIM pickup and downstream processing requirements.

The retention and deletion policies are enforced using **automated Azure Storage Account Lifecycle Management rules**. The lifecycle rule for `IBADirects/archive/` is configured to automatically delete files that are older than **90 days based on their last modified date**.

### 8.5.2 Data Backup

No separate backup mechanism is implemented specifically for the IBA Directs interface. Azure Blob Storage provides the underlying storage resilience required for the interface. Files required for audit or operational purposes are retained according to the defined data retention policies.

### 8.5.3 Data Destruction Procedures

#### **8.5.3.1 Data Destruction Metrics and Timeframes**

Files stored under the `IBADirects/archive/` folder are retained for a maximum of **90 days** and are automatically deleted thereafter, based on the blob's **last modified date**.

#### **8.5.3.2 Standard Process for Data/System Destruction**

Data destruction for archived files is implemented using **Azure Storage Account Lifecycle Management**. A lifecycle management rule is configured to automatically delete files from the `IBADirects/archive/` folder once they reach the defined 90-day retention period.

The lifecycle management rule is configured as follows:

- Add a lifecycle management rule for data destruction.
- Select **Base blobs** as the target blob type.
- Configure the condition based on **Last Modified**.
- Set the retention period to **90 days**.
- Configure the action to **Delete the blob**.
- Configure the rule filter to target the archive path.
- Specify the prefix as `IBADirects/archive/`.

This automated lifecycle management rule ensures that archived source ZIP files are automatically removed after **90 days** in accordance with the defined data retention requirement.

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

*NA*

## 9.2 Deployment Preference

*NA*

## 9.3 Deployment Environment Migration

*All source code is managed under source control (currently Github or Azure Devops Repo).*

*Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure.*

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PROD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.

# 10 Disaster Recovery

*NA*

# 11 Support Documentation

![diagram](images/03.png)

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | Azure function can accept the request data up to 100 MB. | The HTTP request length is limited to 100 MB (104,857,600 bytes), and the URL length is limited to 4 KB (4,096 bytes) | [https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits](https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits) |

# 13 Assumptions

- any assumption while designing solution

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

# 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/08.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |


====================================================================================================
## DOC: TSD-EAII-333
====================================================================================================

# 7 Communication Overview

## 7.1 Communication Components

| **Environment** | **APIM Endpoint (Inbound)** | **Backend Host (Outbound)** | **Port** |
| --- | --- | --- | --- |
| DEV | `https://t3-met-core-(env}-ae1-apim.azure-api.net/eis/campbellspayment/v1` | (environment-specific SAP Commerce Cloud host) | 443 |
| SIT | `https://t3-met-core-(env}-ae1-apim.azure-api.net/eis/campbellspayment/v1` | (environment-specific SAP Commerce Cloud host) | 443 |
| UAT | `https://t3-met-core-(env}-ae1-apim.azure-api.net/eis/campbellspayment/v1` | (environment-specific SAP Commerce Cloud host) | 443 |
| PROD | `https://t3-met-core-(env}-ae1-apim.azure-api.net/eis/campbellspayment/v1` | (environment-specific SAP Commerce Cloud host) | 443 |

# 8 Data Architecture

## 8.1 Data Model

N/A - This integration is stateless. No data is persisted.

## 8.2 Stored Procedures

N/A

| **Stored Procedure Name** | **Purpose** | **Explanation** |
| --- | --- | --- |
|  |  |  |

## 8.3 Stored Procedure Triggers

N/A

| **Stored Procedure Name** | **Trigger Name** | **Trigger** |
| --- | --- | --- |
|  |  |  |

## 8.4 Database Technical Specification

N/A

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

- **Application Insights logs**: Retained per corporate standard (default 90 days)
- **APIM request logs**: Retained per corporate standard
- No message payloads are persisted by the integration

### 8.5.2 Data Backup

N/A - Stateless integration. APIM configuration backed up via source control (Infrastructure as Code).

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

Application Insights data follows corporate retention policy. Logs are automatically purged after retention period.

#### 8.5.3.2 State process for data/system destruction

Log data lifecycle managed by Azure Log Analytics workspace retention settings.

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

A parallel-run transition period may be required where both TIBCO BWC and APIM endpoints are available. Storeline will be reconfigured to point to the new APIM endpoint. Rollback involves reverting Storeline's endpoint configuration to the legacy TIBCO address.

## 9.2 Deployment Preference

APIM provides built-in high availability within a region (Standard tier: 99.95% SLA). No additional load balancing configuration is required for ~200 messages/day. This is a stateless synchronous service so message ordering is inherently preserved.

## 9.3 Deployment Environment Migration

All source code (APIM policies, API definitions, Bicep/ARM templates) is managed under source control (Azure DevOps Repo).

Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure:

- DEV → SIT → UAT → PREPROD → PROD
- Environment-specific values (backend hosts, certificate references) managed via pipeline variables

# 10 Disaster Recovery

- APIM Standard/Premium tier provides built-in regional redundancy
- Backend (SAP Commerce Cloud) DR is managed by the SAP Commerce Cloud platform team
- No integration-level DR requirements beyond platform capabilities
- Recovery: Redeploy APIM configuration from source control in the event of catastrophic failure

# 11 Support Documentation

![diagram](images/01.png)

# 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | APIM policy execution timeout | APIM has a maximum policy execution time of 3 minutes 50 seconds for forwarded requests | Well within requirements (<5s target latency) |
| 2 | SOAP namespace handling | APIM SOAP pass-through requires careful namespace mapping in policy XPath expressions | Requires thorough testing of namespace-qualified XPath |
| 3 | Scientific notation conversion | Policy expression must handle xs:double to decimal conversion correctly | Use `Convert.ToDecimal()` or `Math.Round()` in C# expression |
| 4 | Client certificate renewal | SAP Commerce Cloud mutual TLS certificate must be rotated before expiry | Key Vault certificate auto-rotation or manual rotation process required |

# 13 Assumptions

- Storeline can be reconfigured to call the new APIM endpoint without code changes (only endpoint URL change)
- The SOAP contract (WSDL namespace, operation name, message structure) remains unchanged from the legacy implementation
- SAP Commerce Cloud's REST API contract remains unchanged during migration
- The existing APIM infrastructure (shared instance) has sufficient capacity for ~200 additional messages/day
- Network connectivity between APIM VNet and SAP Commerce Cloud is already established or can be established via existing network infrastructure
- The `"SUCCESFULL"` misspelling in the SAP Commerce Cloud response is preserved as-is (not corrected by the integration)
- Application Insights is the approved replacement for the legacy Metcash ESB Logging Service

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

### 14.1 External Dependencies

The following non-Azure external systems are dependencies for this integration and must be available for end-to-end operation:

| System | Type | Owner | Protocol | Direction | Purpose |
| --- | --- | --- | --- | --- | --- |
| Storeline (Campbells Retailers) | On-Premises (AS/400) | Metcash / Campbells | SOAP/HTTPS | Inbound (Source) | Initiates payment capture requests after pick and pack |
| SAP Commerce Cloud (Sorted) | External SaaS | SAP / Sorted | REST/HTTPS (mTLS) | Outbound (Target) | Processes payment capture via Braintree gateway |
| Braintree | External SaaS (via SAP CC) | PayPal / Braintree | N/A (internal to SAP CC) | Indirect | Actual payment gateway — invoked by SAP Commerce Cloud, not directly by this integration |
| SMC (Service Management Console) | External SaaS | Metcash | REST/HTTPS | Outbound (Monitoring) | Receives audit events (Start/End/Warning/Error) via API call from APIM |

# 15 TSD Approval Checklist

![diagram](images/07.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |


====================================================================================================
## DOC: TSD-EAII-514
====================================================================================================

# 7 Communication Overview

## 7.1 Communication Components

![EAII-514-updated-1-Communication-Diagram.drawio-20260721-071336.png](images/06.png)

| Component | Source | Destination | Protocol | Port | Authentication |
| --- | --- | --- | --- | --- | --- |
| Sorted → APIM | Sorted consumer systems | Azure APIM | HTTPS | 443 | OAuth 2.0 Bearer token |
| APIM → Logic App | Azure APIM | Logic App HTTP trigger | HTTPS | 443 | SAS URL (shared access signature) |
| Logic App → App Configuration | Logic App | Azure App Configuration | HTTPS | 443 | System-Assigned Managed Identity |
| Logic App → Key Vault | Logic App | Azure Key Vault | HTTPS | 443 | System-Assigned Managed Identity |
| Logic App Gateway → AS/400 | Logic App | IBM AS/400 PE | JDBC | 446 | Username/Password (from Key Vault) |
| Logic App → SMC | Logic App | SMC (via APIM) | HTTPS | 443 | OAuth 2.0 |

# 8 Data Architecture

## 8.1 Data Model

*NA*

## 8.2 Stored Procedures

*NA*

## 8.3 Stored Procedure Triggers

*NA*

## 8.4 Database Technical Specification

**Azure SQL Database:** Not required for this integration. No Azure SQL Server (`Microsoft.Sql/servers`) or Azure SQL Database (`Microsoft.Sql/databases`) resource is provisioned for EAII-514. The sole external data source is the IBM AS/400 Power Enterprise system.

**SMC Datastore:** The SMC platform manages its own backend datastore independently of this integration. Transaction metadata written to SMC via `startObservation` and `observationPoint` APIs is governed by the SMC platform's own data retention policy.

**IBM AS/400 PE:** The source of truth for all pricing data. Connection details:

| Attribute | Value |
| --- | --- |
| Protocol | JDBC |
| Driver | `com.ibm.as400.access.AS400JDBCDriver` |
| Stored Procedure | `CX40K6B` |
| Schema | `IDSPNDUR1` |
| Query Timeout | 30 seconds |
| Login Timeout | 30 seconds |
| Max Connections (pool ceiling) | 1,000 |
| Username Secret | Key Vault: `as400-username` |
| Password Secret | Key Vault: `as400-password` |
| Environment Mapping | DV1 → AS/400 Dev LPAR;<br> <br>ST1 → AS/400 SIT LPAR;<br> <br>UT1 → AS/400 UAT LPAR;<br> <br>PRD → AS/400 Production LPAR |

## 8.5 Data Retention

### 8.5.1 Data Retention Procedures

#### 8.5.1.1 Data storage and retention

*NA*

### 8.5.2 Data Backup

### 8.5.3 Data Destruction Procedures

#### 8.5.3.1 Data destruction metrics and timeframes

*NA*

#### 8.5.3.2 State process for data/system destruction

*NA*

# 9 Deployment and Monitoring Considerations

## 9.1 Transition Period

NA

## 9.2 Deployment Preference

NA

## 9.3 Deployment Environment Migration

*All source code is managed under source control (currently Github or Azure Devops Repo).*

*Promotion from one environment to the other will be done using CI/CD pipelines based on standard procedure.*

- Pull Request → DV1 (automated deployment)
- DV1 → ST1 → UT1 → PRD (gated approvals per Environments Strategy)

Infrastructure is defined in Bicep IaC templates in repository `metcash-ais-infrastructure`.

Detailed deployment and rollback procedures for EAII-514 are maintained in the approved **Deployment Runsheets** for each environment.

The runsheets provide the step-by-step execution sequence required to deploy the integration components, validate the deployment, and restore the previous working state if deployment or post-deployment validation fails.

The deployment runsheets include, as applicable:

- Pre-deployment checks and prerequisites;
- Environment-specific configuration updates;
- Post-deployment tests and validation;
- Rollback procedures, including restoration of the previously deployed configuration/version.

# 10 Disaster Recovery

*Capture any specific disaster recovery requirements for the solution here.*

# 11 Support Documentation

![diagram](images/03.png)

# 12 Limitations and Constraints

NA

# 13 Assumptions

- The IBM AS/400 CX40K6B stored procedure will not be modified as part of this migration.
- The Sorted consumer teams are responsible for updating their client configuration to the new AIS endpoint paths (`eis/pricing/v1/getrealtimeprice`) before cutover.

# 14 Reference Documents and Architecture

- [Create Standard workflows with Visual Studio Code - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-single-tenant-workflows-visual-studio-code)
- [Create maps for data transformation - Azure Logic Apps | Microsoft Learn](https://learn.microsoft.com/en-us/azure/logic-apps/create-maps-data-transformation-visual-studio-code)
- [Exception Handling in Logic Apps - Microsoft Community Hub](https://techcommunity.microsoft.com/t5/azure-integration-services-blog/exception-handling-in-logic-apps/ba-p/3330288)
- [OData JSON Format Version 4.01 (oasis-open.org)](http://docs.oasis-open.org/odata/odata-json-format/v4.01/cs01/odata-json-format-v4.01-cs01.html)
- [SMC User Guide](https://metcash.atlassian.net/wiki/x/ZQBbfw?atlOrigin=eyJpIjoiMjYwNzUxMGM0MjdlNGU4ZWIwZDdmYzIwNGI5NDU2OGUiLCJwIjoiYyJ9)
- [Audit, Logging and Exception Management with SMC](https://metcash.atlassian.net/wiki/x/BQC_dg)

# 15 TSD Approval Checklist

*To approve the document, please leave a comment with the word “Approved” in the comments section at the bottom of the page. By approving the document, each approver agrees that the below checklist questions for the TSD have been answered to the approver’s satisfaction where applicable.*

*Click on the arrow (>) below to view the checklist.*

![diagram](images/10.png)

TSD Approval Checklist

| # | **Project Overview** |  |
| --- | --- | --- |
| 1 | Are the specific inclusions and exclusions in the project scope defined? | Y |
| 2 | Have any dependencies (technical or otherwise) been defined? | Y |
|  | **Business Process and Functional Requirements** |  |
| 3 | Have mapping documents for Source and Target systems been captured? | Y |
| 4 | Have lookup logic and handling of failed lookups been defined? | Y |
| 5 | Has an Import/Export Data Project been created in D365 (D365 interfaces only)? | Y |
| 6 | Have exception handling cases and assumptions been documented? | Y |
|  | **Technical Requirements** |  |
| 7 | Are the infrastructure and network requirements listed? | Y |
| 8 | Are the software requirements listed? | Y |
| 9 | Are any specific infrastructure support requirements defined? | Y |
| 10 | Have data handling requirements according to the information classification been defined? | Y |
| 11 | Are any specific encryption requirements defined? | Y |
| 12 | Have the audit requirements for data been defined? | Y |
| 13 | Are the logging, monitoring, and alerting requirements defined? | Y |
| 14 | Is logging free of any restricted data fields? | Y |
| 15 | Has the logging been designed to be asynchronous to not disrupt the business workflow? | Y |
| 16 | Are any integration component monitoring requirements defined? | Y |
| 17 | Are any specific reporting requirements defined? | Y |
| 18 | Are the batch scheduling requirements defined? | Y |
| 19 | Are the disaster recovery (DR) requirements defined? | Y |
| 20 | Are the storage and data retention requirements defined? | Y |
| 21 | Are the backup requirements defined? | Y |
|  | **Performance and Testing** |  |
| 22 | Are the exception test scenarios defined? | Y |
| 23 | Are the latency, scalability, and reliability requirements defined? | Y |
|  | **Operational Requirements** |  |
| 24 | Have onboarding requirements to SMC for each integration been defined? | Y |
| 25 | Have SMC load requirements been shared with the SMC core and support team? Are they ok with this load going into UAT/Production? | Y |
| 26 | Have notifications out of the solution (e.g., email to a group/shared inbox) been defined? | Y |
|  | **Final Review** |  |
| 27 | Has a walkthrough of the document been completed? | Y |
|  | **Approval** |  |
| 28 | Has/have the Interface ID entry/s been completed in the EAI Interface Catalogue? |  |
| 29 | Has the TSD been submitted for reviewed and approval by an Integration Platform Representative? | Y |
| 30 | Has the TSD been submitted for reviewed and approval by an Integration Platform Operations? | Y |
| 31 | Has the TSD been submitted for reviewed and approval by a Solution Architect? | Y |
| 32 | Has the TSD been submitted for reviewed and approval by a Test Manager? | Y |