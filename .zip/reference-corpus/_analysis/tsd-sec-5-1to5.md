

====================================================================================================
## DOC: TSD-EAII-284_283_282_385
====================================================================================================

## 5.1.1 As-is Process(es)

### 5.1.1.1 Description of Process(es)

EAII-284 is a pure pass-through interface. The source STIBO XML is delivered to IndiPIM unchanged (byte-for-byte equality). No mapping page exists by design because no transformation is required.

STIBO pushes the corporate item STEP XML to GoAnywhere MFT via SFTP. GoAnywhere stages the file in Azure Blob Storage and publishes a notification to the corporate item topic on Azure Service Bus. The integration consumes the notification, retrieves the staged STEP XML from Blob Storage, and forwards it to IndiPIM as-is — there is no transformation or field mapping. The source XML is serialised to text and delivered via an HTTP POST request to the IndiPIM REST API.

**Authentication:** OAuth 2.0 client credentials flow via Auth0. The integration obtains a bearer token from the Auth0 identity provider using client ID, client secret, audience, and grant type. Tokens are cached and refreshed 300 seconds before expiry to avoid authentication interruptions during processing.

**Retry:** On failure, AIS retries up to a configurable number of attempts (default: 3). If all retries are exhausted, the failed message is logged to SMC for monitoring and manual retry.

**Known Issues (carried from legacy TIBCO process):**

- Token caching without invalidation.
- Unnecessary update triggers — PIM broadcasts all attribute changes regardless of IndiPIM relevance.
- No out-of-sequence message protection — out-of-sequence scenarios are managed manually by liaising with the PIM team.

### 5.1.1.2 Process Flow Diagram

![image-20260511-061952.png](images/02.png)

## 5.1.2 Proposed Process(es)

### 5.1.2.1 Description of Process(es)

EAII-284 is a **pure pass-through** interface: the STIBO corporate item STEP XML is forwarded to IndiPIM byte-for-byte, with no field-level transformation and no mapping page. The Function downloads the raw XML from blob storage and POSTs it unchanged to the IndiPIM REST endpoint as `application/xml`.

### 5.1.2.2 Process Flow Diagram

![image-20260810-053959.png](images/17.png)

1. STIBO exports corporate item STEP XML to GoAnywhere via SFTP (out of scope — upstream).
2. GoAnywhere writes the XML file to Azure Blob Storage, container `stibo`, path `frompim/corporateitem/` (e.g. `stibo/frompim/corporateitem/10032775168-10032775168.xml`).
3. Azure Event Grid raises a `Microsoft.Storage.BlobCreated` event for every new blob written to the storage account, with the event's `subject` property set to the blob path (e.g. `/blobServices/default/containers/stibo/blobs/frompim/corporateitem/...`), and delivers it to the shared Service Bus topic `data.metproducts.{env}.sbt`.
4. The `toindipim.corporateitem` subscription applies a SQL filter on the `subject` property (`subject LIKE '%containers/stibo/blobs/frompim/corporateitem%'`) to route only matching corporate-item blob-created events to that subscription.
5. The `toindipim.corporateitem` subscription on that topic delivers the message to the `CorporateItemToIndiPIM` Function trigger (pull trigger — the Function polls the subscription).
6. `ServiceBusFunctionExecutor` resolves the correlation ID (native `CorrelationId` → `ApplicationProperties["CorrelationId"]` → new GUID fallback), emits a `CorporateItemToIndiPIM.Triggered` telemetry event (`CorrelationId`, `Interface`, `MessageId`), then extracts the blob URL from the message body (`data.url`) and invokes `CorporateItemToIndiPIMService.ProcessAsync`.
7. The XML is retrieved from blob storage.
8. An OAuth 2.0 bearer token is acquired from Auth0, or a cached token is reused if more than 300 seconds remain before its expiry.
9. The raw XML is posted to the IndiPIM REST endpoint (`application/xml`) with the bearer token attached.
10. On success, the executor emits a `CorporateItemToIndiPIM.Completed` telemetry event (`Status` = Success) and, in the `finally` block, `SmcService` logs an SMC "Observation Complete" record.
11. On failure, `TrackException` is logged (no `Completed` event is emitted), the exception propagates, Service Bus redelivers per its configured delivery count, and after exhaustion the message dead-letters. The `finally` block still runs, so SMC always records "Observation Failed" with the exception detail regardless of the DLQ outcome.

**Known Issues with the Current Implementation**

| # | Issue | Impact | Recommendation |
| --- | --- | --- | --- |
| 1 | Unnecessary update triggers — PIM broadcasts all field changes to all downstream queues without field-level filtering. A change relevant only to one target still triggers messages to all others. | Increased message volume and unnecessary processing on target systems. | Redesign candidate: field-level change detection or attribute-based routing in AIS to suppress irrelevant updates. |
| 2 | Token caching without invalidation — IndiPIM OAuth token is cached with a 300-second pre-refresh buffer. If the token is revoked or Auth0 configuration changes, the cached token continues to be used until expiry. | Failed authentication for up to 5 minutes after token revocation. | Consider implementing token invalidation on authentication failure. |
| 3 | No out-of-sequence message protection — the integration layer has no timestamp comparison, version checking, or deduplication logic. Managed manually by liaising with the PIM team. | Stale data may overwrite newer data at IndiPIM if messages arrive out of order. | Consider version-based ordering or idempotency controls for interfaces lacking target-side protection. |

### 5.1.2.3 Sequence Diagram

![image-20260722-082158.png](images/01.png)

### 5.1.2.4 PlantUML

```
@startuml EAII-284
title EAII-284 — STIBO to IndiPIM\nCorporate Item Pass-Through

actor "STIBO / GoAnywhere" as STIBO
participant "Azure Blob Storage\nt3data{env}aesta01\n/stibo/frompim/corporateitem" as Blob
participant "Azure Event Grid\n(metproducts: BlobCreated event)" as EG
participant "Service Bus Topic\ndata.metproducts.{env}.sbt\nSubscription: toindipim.corporateitem" as SB
participant "Function App\nt3-met-metproducts-{env}-ae-func\nFunction: CorporateItemToIndiPIM" as Func
participant "IndiPIMTokenService\n(password + refresh_token grant)" as Token
participant "IndiPIM API\n(REST, /api/rest/v1/products)" as IndiPIM
participant "SmcService\n(via APIM)" as SMC

STIBO -> Blob : Write STEP XML file\n(GoAnywhere HTTPS/Managed Identity)
Blob -> EG : Microsoft.Storage.BlobCreated event
EG -> SB : Publish event to topic

Func -> SB : Poll subscription (pull trigger)
SB --> Func : Deliver message (blob URL + metadata)

Func -> Func : ServiceBusFunctionExecutor\nExtract blob URL, generate correlationId

Func -> Blob : Download XML\n(SAMI — Storage Blob Data Reader)
Blob --> Func : STEP XML content

Func -> Token : GetAccessTokenAsync(correlationId, interfaceId)
alt Cached token valid
	Token --> Func : Cached access token (cache hit)
else Cached token near/at expiry, refresh_token available
	Token -> IndiPIM : POST /api/oauth/v1/token\n(Basic auth, grant_type=refresh_token)
	alt Refresh succeeds
		IndiPIM --> Token : New access_token + refresh_token
		Token --> Func : Fresh access token
	else Refresh fails
		Token -> IndiPIM : POST /api/oauth/v1/token\n(Basic auth, grant_type=password)
		IndiPIM --> Token : New access_token + refresh_token
		Token --> Func : Fresh access token
	end
else No cached token
	Token -> IndiPIM : POST /api/oauth/v1/token\n(Basic auth, grant_type=password)
	IndiPIM --> Token : access_token + refresh_token
	Token --> Func : Access token
end

Func -> IndiPIM : POST {IndiPIMBaseUrl}\nContent-Type: application/xml\nAuthorization: Bearer {token}

alt HTTP 2xx — Success
	IndiPIM --> Func : 200/201 OK
	Func -> SMC : LogObservation (Complete)\nvia APIM t3-met-core-{env}-ae1-apim
else HTTP 401 — Token expired
	IndiPIM --> Func : 401 Unauthorized
	Func -> Token : InvalidateToken()
	Func -> Token : GetAccessTokenAsync(correlationId, interfaceId)
	Func -> IndiPIM : Retry POST with fresh token
	IndiPIM --> Func : 200/201 OK
	Func -> SMC : LogObservation (Complete)
else HTTP 4xx (non-401) — Non-retryable
	IndiPIM --> Func : 4xx Error
	Func -> SMC : LogObservation (Failed)\nwith exception detail
	note over Func : Propagate exception\nSB redelivery → DLQ on exhaustion
else HTTP 5xx / Timeout — Retryable
	IndiPIM --> Func : 5xx Error
	note over Func : Retry up to 3×, 2s delay
	Func -> IndiPIM : Retry POST
	Func -> SMC : LogObservation (Failed on exhaustion)
end

note over Func,SMC
  SMC logging is always in finally block.
  SMC failure does NOT block message processing.
end note

note over Token
  IndiPIMTokenService caches access_token + refresh_token in-memory.
  Every acquisition path logs to App Insights (ILogger + TrackEvent)
  with CorrelationId and InterfaceId in customDimensions:
  CacheHit / CacheMiss / NearingExpiry / RefreshAttempt /
  RefreshSucceeded / RefreshFailed / PasswordGrantAttempt /
  PasswordGrantSucceeded / PasswordGrantFailed
end note
@enduml
```

## 5.1.3 Coordination

Fully asynchronous, event-driven, one-message-at-a-time processing per Service Bus trigger invocation. No batching.

### 5.1.3.1 Transaction Boundaries

Each Service Bus message (one corporate item XML file) is processed as a single, independent unit of work. There is no multi-message transaction; a failure processing one message has no effect on any other message on the same or a different subscription.

### 5.1.3.2 State Management

Stateless per invocation, with one exception: the OAuth token cache is held in-memory for the lifetime of the Function App instance, shared across invocations and across EAII-284/EAII-385 (both use the same token acquisition component). This is an optimisation, not a correctness requirement — a cold start or restart forces a fresh token fetch on the next invocation.

## 5.1.4 GoAnywhere Requirements

| Field | Value |
| --- | --- |
| Interface ID | EAII-284 |
| Interface Name | STIBO_to_IndiPIM_CorporateItem |
| Source System | STIBO (MetProducts PIM) |
| Source Encryption | sFTP |
| Target System | Azure Blob Storage (`stibo/frompim/corporateitem`) — shared with EAII-283 and EAII-385 (same corporate item file) |
| Source File Protocol | sFTP |
| Target File Protocol | Azure Blob (HTTPS) |
| File Delivery Routing Rules | Pass-through. STIBO XML (`<STEP-ProductInformation>` envelope, `FilterUserType=pph_msc_item`) is delivered to the Azure Blob target unchanged; no transformation, rename, split, or merge. Downstream Function App (EAII-284) reads the blob and POSTs it byte-identical to IndiPIM. |
| Target Connection Details — DV1 | `t3datadv1aesta01` → `/stibo/frompim/corporateitem` |
| Target Connection Details — ST1 | `t3datast1aesta01` → `/stibo/frompim/corporateitem` |
| Target Connection Details — UT1 | `t3dataut1aesta01` → `/stibo/frompim/corporateitem` |
| Target Connection Details — PRD | `t3dataprdaesta01` → `/stibo/frompim/corporateitem` |
| Destination Filename Convention | No rename. Source filename preserved (STIBO STEP-ProductInformation export filename). |
| Destination Filename Example | `1375178063872-1375178063872-40007694.xml` |

## 5.1.5 Design Considerations

- Pass-through design minimizes processing risk but also minimizes this Function's ability to validate payload correctness before forwarding — any malformed STIBO XML is forwarded as-is to IndiPIM.
- Lowest deployment risk of the four interfaces (GREEN Horizon, Silver SLA) — planned as the first interface enabled for live delivery in the cut-over sequence (§9.1, Step 5).
- Shares the corporate item blob path and Service Bus topic (`data.metproducts.{env}.sbt`) with EAII-283 and EAII-385; each has its own dedicated subscription so a slow or failing consumer on one subscription does not block the others.

## 5.2.1 As-is Process(es)

### 5.2.1.1 Description of Process(es)

[Functional Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311042576/Functional+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets#3.2-EAII-283---Distribute-Corporate-Item-Data---STIBO-to-Sorted)

STIBO pushes the corporate item CorporateItemMDM XML to GoAnywhere MFT via SFTP. GoAnywhere stages the file in Azure Blob Storage and publishes a notification to the Corporate Item topic on Azure Service Bus. The integration consumes the notification, retrieves the staged XML from Blob Storage, and delivers it as JSON to the Sorted Marketplace REST API.

The integration transforms the source XML into a JSON payload conforming to the Sorted corporate item API contract, and delivers it via HTTP POST to the Sorted corporate item endpoint. Field-level mapping is documented in the mapping specification.

**Authentication:** Mutual TLS (client certificate) via a dedicated keystore. The Sorted HTTP client is configured with a trust store containing the Sorted server's CA certificate and a client certificate for bilateral authentication.

**System Availability Gating:** The Sorted platform availability status is success then continue sending request to Sorted. If the Sorted system is reported as down, the Sorted interface applies a configurable sleep timer before retrying, and tracks the system state (up/down) for subsequent messages.

**Retry:** On failure, AIS retries up to a configurable number of attempts (default: 3). If all retries are exhausted, the failed message is logged to SMC for monitoring and manual retry.

See source (PIM.xsd) and target (CorporateItemMDM.xsd) schema references in the FSD.

**Known Issues (per FSD §3.2.1.3):**

- Unnecessary update triggers — PIM broadcasts all attribute changes regardless of Sorted relevance.
- No out-of-sequence message protection — out-of-sequence scenarios are managed manually by liaising with the PIM team.

### 5.2.1.2 Process Flow Diagram

![image-20260511-062021.png](images/13.png)

## 5.2.2 Proposed Process(es)

### 5.2.2.1 Description of Process(es)

EAII-283 is implemented as an Azure Function App interface: the STIBO corporate item STEP XML is retrieved from Blob Storage, transformed to the Sorted corporate item JSON contract (per the [Mapping - EAII-283 - Distribute Corporate Item Data - STIBO to Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311009815/Mapping+-+EAII-283+-+Distribute+Corporate+Item+Data+-+STIBO+to+Sorted)), and posted to the Sorted Marketplace corporate item REST endpoint via mTLS.

### 5.2.2.2 Process Flow Diagram

![EAII-283 Process Flow Diagram-20260723-110646.png](images/14.png)

1. STIBO exports corporate item STEP XML to GoAnywhere via SFTP (out of scope — upstream).
2. GoAnywhere writes the file to Blob Storage, container `stibo`, path `frompim/corporateitem/`.
3. Azure Event Grid raises a `Microsoft.Storage.BlobCreated` event for every new blob written to the storage account, with the event's `subject` property set to the blob path (e.g. `/blobServices/default/containers/stibo/blobs/frompim/corporateitem/...`), and delivers it to the shared Service Bus topic `data.metproducts.{env}.sbt`.
4. The `tosorted.corporateitem` subscription applies a SQL filter on the `subject` property (`subject LIKE '%containers/stibo/blobs/frompim/corporateitem%'`) to route only matching corporate-item blob-created events to that subscription.
5. The `tosorted.corporateitem` subscription delivers the message to the `CorporateItemToSorted` Function trigger (pull trigger).
6. `ServiceBusFunctionExecutor` resolves the correlation ID, emits a `CorporateItemToSorted.Triggered` telemetry event, extracts the blob URL, and invokes `CorporateItemToSortedService.ProcessAsync`.
7. If available, the XML is downloaded from Blob Storage.
8. The XML is transformed to the Sorted corporate item JSON contract.
9. The JSON payload is POSTed to the Sorted corporate item endpoint via the mTLS-secured `SortedHttpService` (client certificate loaded from the Function App certificate store by thumbprint).
10. On HTTP 2xx: success. On HTTP 400 specifically: immediate non-retryable failure. On any other non-success status (including 401/403/5xx) or a thrown exception: retried up to 3 attempts with a fixed 2-second delay before failing.
11. The executor logs completion telemetry and the SMC observation (Complete, Skipped, or Failed) regardless of outcome, via the `finally` block.
12. On unhandled failure, Messages are explicitly dead-lettered by the Function.

### 5.2.2.3 Sequence Diagram

![image-20260723-075357.png](images/11.png)

### 5.2.2.4 — PlantUML

```
@startuml EAII-283
title EAII-283 — STIBO to Sorted\nCorporate Item Distribution

actor "STIBO / GoAnywhere" as STIBO
participant "Azure Blob Storage\nt3data{env}aesta01\n/stibo/frompim/corporateitem" as Blob
participant "Azure Event Grid\n(metproducts: BlobCreated event)" as EG
participant "Service Bus Topic\ndata.metproducts.{env}.sbt\nSubscription: tosorted.corporateitem" as SB
participant "Function App\nt3-met-metproducts-{env}-ae-func\nFunction: CorporateItemToSorted" as Func
participant "SortedGatingService\n(stub — always available)" as Gating
participant "SortedHttpService\n(mTLS)" as SortedHTTP
participant "Sorted API\n(Corporate Item)" as Sorted
participant "SmcService\n(via APIM)" as SMC

STIBO -> Blob : Write STEP XML file
Blob -> EG : Microsoft.Storage.BlobCreated event
EG -> SB : Publish event to topic

Func -> SB : Poll subscription (pull trigger)
SB --> Func : Deliver message

Func -> Func : ServiceBusFunctionExecutor\nExtract blob URL, generate correlationId

Func -> Gating : IsAvailableAsync()
alt Sorted unavailable
	Gating --> Func : false
	Func -> SMC : LogObservation (Skipped)
	note over Func : No blob download, no outbound call
else Sorted available
	Gating --> Func : true

	Func -> Blob : Download XML (SAMI — Storage Blob Data Reader)
	Blob --> Func : STEP XML content

	Func -> Func : Transform XML → Sorted corporate item JSON\n(per Mapping - EAII-283)

	Func -> SortedHTTP : POST JSON payload\nmTLS client cert (SortedCertificateThumbprint from KV)
	SortedHTTP -> Sorted : HTTPS POST {SortedBaseUrl}{SortedCorporateItemUri}\nContent-Type: application/json

	alt HTTP 2xx — Success
		Sorted --> SortedHTTP : 200/201 OK
		SortedHTTP --> Func : Success
		Func -> SMC : LogObservation (Complete)
	else HTTP 400 — Non-retryable
		Sorted --> SortedHTTP : 400 Bad Request
		SortedHTTP --> Func : Non-retryable failure
		Func -> SMC : LogObservation (Failed)
		note over Func : No retry — propagate to SB redelivery → DLQ
	else HTTP 401/403/other 4xx / 5xx / Timeout — Retryable
		Sorted --> SortedHTTP : Non-2xx, non-400
		note over Func : Retry up to 3×, 2s delay
		Func -> SMC : LogObservation (Failed on exhaustion)
	end
end

note over Func,SMC
  SMC logging is always in finally block.
  SMC failure does NOT block message processing.
end note
@enduml
```

## 5.2.3 Coordination

Fully asynchronous, event-driven, one message per Service Bus trigger invocation. No batching.

### 5.2.3.1 Transaction Boundaries

Each Service Bus message (one corporate item XML file) is processed as a single, independent unit of work. A failure processing one message has no effect on any other message.

### 5.2.3.2 State Management

Stateless per invocation. The gating check calls `ISortedGatingService.IsAvailableAsync()` fresh on every invocation — no cached availability state is held in-process.

## 5.2.4 GoAnywhere Requirements

| Field | Value |
| --- | --- |
| Interface ID | EAII-283 |
| Interface Name | STIBO_to_Sorted_CorporateItem |
| Source System | STIBO (PIM) — sFTP |
| Target System | Gen 3 Blob Storage — `t3data{env}aesta01` / `stibo` (env: dv1/st1/ut1/prd) |
| Target Encryption | HTTPS (TLS 1.2+) to Azure Blob; storage account encryption at rest |
| Source File Protocol | sFTP |
| Target File Protocol | Azure Blob (HTTPS) |
| File Delivery Routing Rules | Pass-through to blob. STIBO XML (`<STEP-ProductInformation>` envelope, `FilterUserType=pph_msc_item` / `pph_msc_locn_item` / `pph_msc_locn_item_price` / `pph_msc_tmpt_item`) is delivered to the Azure Blob target unchanged. Downstream `CorporateItemToSorted` Function reads the blob, transforms it to Sorted corporate JSON, and POSTs to Sorted Marketplace. GoAnywhere has no involvement in the transformation. |
| Destination Filename Convention | No rename. Source filename preserved. |
| Destination Filename Example | `1360581885952-1360581885952-682179.xml` |

## 5.2.5 Design Considerations

NA

## 5.3.1 As-is Process(es)

### 5.3.1.1 Description of Process(es)

[Functional Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311042576/Functional+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets#3.3-EAII-282---Distribute-Supplier-Item-Data---STIBO-to-Sorted)

STIBO pushes the supplier item XML to GoAnywhere MFT via SFTP. GoAnywhere stages the file in Azure Blob Storage and publishes a notification to the Supplier Item topic on Azure Service Bus. The integration consumes the notification, retrieves the staged XML from Blob Storage, and delivers it as JSON to the Sorted Marketplace REST API.

The integration transforms the source XML into a JSON payload conforming to the Sorted supplier item API contract, and delivers it via HTTP POST to the Sorted supplier data endpoint. Field-level mapping is documented in the mapping specification.

**Authentication:** Mutual TLS (client certificate) — same as the corporate item Sorted interface (EAII-283).

**System Availability Gating:** Same Sorted status gating mechanism as EAII-283.

**Retry:** On failure, AIS retries up to a configurable number of attempts (default: 3). If all retries are exhausted, the failed message is logged to SMC for monitoring and manual retry.

See source (PIM.xsd) and target (SupplierItem.xsd) schema references in the FSD.

**Known Issues (per FSD §3.3.1.3):**

- Unnecessary update triggers — PIM broadcasts all attribute changes regardless of Sorted relevance.
- No out-of-sequence message protection — out-of-sequence scenarios are managed manually by liaising with the PIM team.

**Data classification (per FSD §3.3.5):** Internal. Supplier item data including product descriptions, dimensions, pricing indicators. No customer PII. **Supplier commercial terms are business-sensitive.** Data handling requirement: encrypt in transit (mTLS); **do not expose supplier pricing in logs.**

### 5.3.1.2 Process Flow Diagram

![image-20260511-062049.png](images/18.png)

## 5.3.2 Proposed Process(es)

### 5.3.2.1 Description of Process(es)

EAII-282 is functionally and structurally a byte-equivalent mirror of EAII-283 (§5.2.2.1), targeting the Sorted **supplier item** endpoint with supplier item data from the same shared Service Bus topic (`data.metproducts.{env}.sbt`), differentiated by blob path (`frompim/supplieritem/`) and Service Bus subscription (`tosorted.supplieritem`).

### 5.3.2.2 Process Flow Diagram

![EAII-282 Process Flow Diagram-20260723-110701.png](images/03.png)

1. STIBO exports supplier item STEP XML to GoAnywhere via SFTP (out of scope — upstream).
2. GoAnywhere writes the file to Blob Storage, container `stibo`, path `frompim/supplieritem/` (e.g. `stibo/frompim/supplieritem/1000005959680-1000005959680.xml`).
3. Azure Event Grid raises a `Microsoft.Storage.BlobCreated` event for every new blob written to the storage account, with the event's `subject` property set to the blob path (e.g. `/blobServices/default/containers/stibo/blobs/frompim/supplieritem/...`), and delivers it to the shared Service Bus topic `data.metproducts.{env}.sbt`.
4. The `tosorted.supplieritem` subscription applies a SQL filter on the `subject` property (`subject LIKE '%containers/stibo/blobs/frompim/supplieritem%'`) to route only matching supplier-item blob-created events to that subscription.
5. The `tosorted.supplieritem` subscription delivers the message to the `SupplierItemToSorted` Function trigger (pull trigger).
6. `ServiceBusFunctionExecutor` resolves the correlation ID, emits `SupplierItemToSorted.Triggered`, extracts the blob URL, and invokes `SupplierItemToSortedService.ProcessAsync`.
7. The XML is downloaded from blob storage.
8. The XML is transformed to the Sorted supplier item JSON contract via `SortedSupplierTransformService`. Pricing fields are included in the output (not redacted) per the code comment above.
9. The JSON payload is POSTed to the Sorted supplier item endpoint via mTLS.
10. On HTTP 2xx: success. On HTTP 400 specifically: immediate non-retryable failure. On any other non-success status (including 401/403/5xx) or thrown exception: retried up to 3 attempts with a fixed 2-second delay before failing — **identical retry taxonomy gap to EAII-283** (see §5.2.2.2).
11. The executor logs completion telemetry and SMC observation regardless of outcome, via the `finally` block.

### 5.3.2.3 Sequence Diagram

![image-20260723-065857.png](images/08.png)

### 5.3.2.4 PlantUML

```
@startuml EAII-282
title EAII-282 — STIBO to Sorted\nSupplier Item Distribution

actor "STIBO / GoAnywhere" as STIBO
participant "Azure Blob Storage\nt3data{env}aesta01\n/stibo/frompim/supplieritem" as Blob
participant "Azure Event Grid\n(metproducts: BlobCreated event)" as EG
participant "Service Bus Topic\ndata.metproducts.{env}.sbt\nSubscription: tosorted.supplieritem" as SB
participant "Function App\nt3-met-metproducts-{env}-ae-func\nFunction: SupplierItemToSorted" as Func
participant "SortedGatingService\n(stub — always available)" as Gating
participant "SortedHttpService\n(mTLS)" as SortedHTTP
participant "Sorted API\n(Supplier Item)" as Sorted
participant "SmcService\n(via APIM)" as SMC

STIBO -> Blob : Write STEP XML (supplier item file)
Blob -> EG : Microsoft.Storage.BlobCreated event
EG -> SB : Publish event to shared topic

Func -> SB : Poll subscription (pull trigger)
SB --> Func : Deliver message

Func -> Func : ServiceBusFunctionExecutor\nExtract blob URL, generate correlationId

Func -> Gating : IsAvailableAsync()
alt Sorted unavailable
	Gating --> Func : false
	Func -> SMC : LogObservation (Skipped)
else Sorted available
	Gating --> Func : true

	Func -> Blob : Download XML (SAMI)
	Blob --> Func : STEP XML content (supplier item)

	Func -> Func : Transform XML → Sorted supplier item JSON\n(pricing fields included, NOT redacted —\nper SortedSupplierTransformService.cs comment)

	Func -> SortedHTTP : POST JSON payload\n(mTLS — SortedCertificateThumbprint from KV)
	SortedHTTP -> Sorted : HTTPS POST {SortedBaseUrl}{SortedSupplierItemUri}

	alt HTTP 2xx
		Sorted --> Func : Success
		Func -> SMC : LogObservation (Complete)
	else HTTP 400 — Non-retryable
		Sorted --> Func : 400
		Func -> SMC : LogObservation (Failed)
	else HTTP 401/403/other / 5xx — Retryable
		Sorted --> Func : Non-2xx, non-400
		note over Func : Retry 3×/2s\n(same gap as EAII-283 — see 5.2.2.2)
		Func -> SMC : LogObservation (Failed on exhaustion)
	end
end

note over Func,SMC
  SMC failure does NOT block message processing.
  LogMessage stage entries carry status/HTTP code only —
  pricing values never appear in SMC log or App Insights traces.
end note
@enduml
```

## 5.3.3 Coordination

Same as EAII-283 (§5.2.3) — fully asynchronous, event-driven, one message per invocation, no batching.

### 5.3.3.1 Transaction Boundaries

Same as EAII-283 (§5.2.3.1).

### 5.3.3.2 State Management

Same as EAII-283 (§5.2.3.2) — stateless per invocation; gating checked fresh on every call.

## 5.3.4 GoAnywhere Requirements

| Field | Value |
| --- | --- |
| Interface ID | EAII-282 |
| Interface Name | STIBO_to_Sorted_SupplierItem |
| Source System | STIBO (PIM) — sFTP |
| Target System | Gen 3 Blob Storage — `t3data{env}aesta01` / `stibo/frompim/supplieritem` |
| Source File Protocol | sFTP |
| Target File Protocol | Azure Blob (HTTPS) |
| File Delivery Routing Rules | Pass-through to blob. STIBO XML (`<STEP-ProductInformation>` envelope, `FilterUserType=pph_msc_sitm` / `pph_msc_barcode_sitm` / `pph_msc_item_price*`) delivered unchanged. Downstream `SupplierItemToSorted` Function reads the blob, transforms it to Sorted supplier JSON, and POSTs to Sorted Marketplace. |
| Destination Filename Convention | No rename. Source filename preserved. |
| Destination Filename Example | `1066225631233-1066225631233_682179.xml` |

## 5.3.5 Design Considerations

- **Mirror of EAII-283:** `SupplierItemToSortedService` is structurally identical to `CorporateItemToSortedService` — same retry taxonomy (only HTTP 400 non-retryable), same SMC stage pattern. Differences are transformation target (`SortedSupplierTransformService` vs. `SortedCorporateTransformService`), blob path, and Service Bus subscription only.
- **Pricing field handling —**Pricing fields are intentionally included in the outbound Sorted payload (not redacted); the actual FSD requirement is that pricing must not appear in **logs** (SMC/App Insights), which is satisfied because `LogMessage` entries never include the payload body.
- **4xx retry taxonomy gap:** identical to EAII-283 — only HTTP 400 is special-cased as non-retryable; 401/403 fall through to the generic retry path.

## 5.4.1 As-is Process(es)

### 5.4.1.1 Description of Process(es)

[Functional Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311042576/Functional+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets#3.4-EAII-385---Product-Master-Data---STIBO-to-Retail-Express)

This is a **net-new build** with no TIBCO predecessor (per FSD §1.2 and §2.1).

## 5.4.2 Proposed Process(es)

![image-20260511-062117.png](images/15.png)

### 5.4.2.1 Description of Process(es)

[Functional Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311042576/Functional+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets#3.4-EAII-385---Product-Master-Data---STIBO-to-Retail-Express)

MetProducts (STIBO) pushes the product data XML to GoAnywhere MFT via SFTP. GoAnywhere stages the file in Azure Blob Storage and publishes a notification to Azure Service Bus. The integration consumes the notification, retrieves the staged XML from Blob Storage, and delivers it as JSON to the MetProms (Retail Express) REST API.

The integration transforms the relevant attributes from the source XML into a JSON payload conforming to the MetProms `item-attribute-records` schema, including both corporate-level and location-level attributes where applicable. Only the in-scope attributes (per the mapping spreadsheet) are extracted and mapped. Multi-value source fields (e.g., dietary claims, environmental claims) are deduplicated and sent as repeated attribute entries for the same attribute type. **Only IGA pillar location data is included** — an item with no IGA-pillar location is skipped entirely (not an error). For new items, a create (POST) request is used. For existing items, an update (PUT) request is used, identified by the Metcash item number. Field-level mapping is documented in the mapping specification.

**Authentication:** OAuth 2.0 Client Credentials flow.

**Version-based ordering:** Each message includes a last-modified timestamp generated by the integration layer at send time. MetProms compares this timestamp against its most recent update for the item. If the incoming message is older than the current data, MetProms rejects it with **HTTP 409**. This ensures out-of-sequence messages do not overwrite more recent data, and allows failed messages to be safely retried.

**Retry:** On failure, AIS retries up to a configurable number of attempts (default: 3). If all retries are exhausted, the failed message is logged to SMC for monitoring and manual retry.

**Initial full load:** A one-off full product load is required to seed MetProms with attributes not previously received from PE. This is triggered manually by the business via MetProducts and processed through the same integration pipeline. **Out of scope for this TSD** — covered by a separate addendum.

**Known Issues (per FSD §3.4.1.3):**

- Unnecessary update triggers — changes to non-consumed fields in the source message trigger processing that results in no meaningful update in MetProms.

### 5.4.2.2 Process Flow Diagram

![EAII-385 Process Flow Diagram-20260723-110717.png](images/09.png)

1. STIBO exports corporate/location item STEP XML to GoAnywhere via SFTP (out of scope). This is the **same source file** consumed by EAII-283 and EAII-284.
2. GoAnywhere writes the file to Blob Storage, container `stibo`, path `frompim/corporateitem/`.
3. Azure Event Grid raises a `Microsoft.Storage.BlobCreated` event for every new blob written to the storage account, with the event's `subject` property set to the blob path (e.g. `/blobServices/default/containers/stibo/blobs/frompim/corporateitem/...`), and delivers it to the shared Service Bus topic `data.metproducts.{env}.sbt`.
4. The `tometproms.corporateitem` subscription applies a SQL filter on the `subject` property (`subject LIKE '%containers/stibo/blobs/frompim/corporateitem%'`) to route only matching corporate-item blob-created events to that subscription.
5. The `tometproms.corporateitem` subscription delivers the message to the `CorporateItemToMetProms` Function trigger (pull trigger).
6. `ServiceBusFunctionExecutor` resolves the correlation ID, emits `CorporateItemToMetProms.Triggered`, extracts the blob URL, and invokes `CorporateItemToMetPromsService.ProcessAsync`.
7. The XML is downloaded from blob storage.
8. The item is transformed via `MetPromsTransformService.Transform(xml)`. **If the item has no IGA-pillar location, the transform returns**`null` and the message is skipped (`ProcessingResult.Skipped`, logged as `Status = Skipped`, no outbound call, no failure).
9. If eligible, an OAuth2 client-credentials token is acquired against the Retail Express identity endpoint.
10. The service attempts to **update** the item first: `PUT item-attribute-records/{id}`.
  - **HTTP 2xx** → success.
  - **HTTP 409** (stale timestamp / out-of-sequence) → **discard**, logged as `Status = Skipped`, no retry, treated as a successful outcome (`ProcessingResult.Skipped`).
  - **HTTP 404** (item does not exist yet) → fall back to `POST item-attribute-records` (create).
    - **HTTP 2xx** → success.
    - **HTTP 409** on the POST → discard, same as above.
    - **HTTP 4xx (other)** → non-retryable failure.
    - Other non-success → falls into the generic retry path.

  - **HTTP 4xx (other, non-404/409)** on the PUT → non-retryable failure.
  - Any other non-success status or thrown exception → retried up to 3 attempts with a fixed 2-second delay.

11. The executor logs completion telemetry and SMC observation regardless of outcome, via the `finally` block.

### 5.4.2.3 Sequence Diagram

![image-20260723-070136.png](images/10.png)

### 5.4.2.4 PlantUML

```
@startuml EAII-385
title EAII-385 — STIBO to Retail Express (MetProms)\nProduct Master Data Distribution

actor "STIBO / GoAnywhere" as STIBO
participant "Azure Blob Storage nt3data{env}aesta01\n(stibo/frompim/corporateitem)" as Blob
participant "Azure Event Grid\n(metproducts: BlobCreated event)" as EG
participant "Service Bus Topic\ndata.metproducts.{env}.sbt\nSubscription: tometproms.corporateitem" as SB
participant "Function App\nt3-met-metproducts-{env}-ae-func\nFunction: CorporateItemToMetProms" as Func
participant "MetPromsTransformService" as Transform
participant "TokenService\n(Retail Express identity)" as Token
participant "MetProms API\n(Retail Express)" as MetProms
participant "SmcService\n(via APIM)" as SMC

STIBO -> Blob : Write STEP XML (corporate/location item)
Blob -> EG : Microsoft.Storage.BlobCreated event
EG -> SB : Publish event to shared topic

Func -> SB : Poll subscription (pull trigger)
SB --> Func : Deliver message

Func -> Func : ServiceBusFunctionExecutor\nExtract blob URL, generate correlationId

Func -> Blob : Download XML (SAMI)
Blob --> Func : STEP XML content

Func -> Transform : Transform(xml)
alt No IGA-pillar location
	Transform --> Func : null
	Func -> SMC : LogObservation (Skipped)
	note over Func : No token acquired, no outbound call
else Eligible
	Transform --> Func : MetProms record (Id, attributes)

	Func -> Token : GetTokenAsync (OAuth2 client credentials)
	Token --> Func : Bearer token

	Func -> MetProms : PUT item-attribute-records/{id}\nAuthorization: Bearer {token}

	alt HTTP 2xx — Updated
		MetProms --> Func : 200 OK
		Func -> SMC : LogObservation (Complete)
	else HTTP 409 — Stale timestamp (out-of-sequence)
		MetProms --> Func : 409 Conflict
		note over Func : Discard — logged as Skipped\nNo retry, no DLQ
		Func -> SMC : LogObservation (Skipped)
	else HTTP 404 — Not found, create
		MetProms --> Func : 404 Not Found
		Func -> MetProms : POST item-attribute-records
		alt HTTP 2xx — Created
			MetProms --> Func : 201 Created
			Func -> SMC : LogObservation (Complete)
		else HTTP 409 on POST
			MetProms --> Func : 409 Conflict
			Func -> SMC : LogObservation (Skipped)
		else HTTP 4xx (other) — Non-retryable
			MetProms --> Func : 4xx Error
			Func -> SMC : LogObservation (Failed)
		else Other — Retryable
			note over Func : Falls into generic retry (3×/2s)
		end
	else HTTP 4xx (other, non-404/409) — Non-retryable
		MetProms --> Func : 4xx Error
		Func -> SMC : LogObservation (Failed)
	else HTTP 5xx / Timeout — Retryable
		note over Func : Retry up to 3×, 2s delay
		Func -> SMC : LogObservation (Failed on exhaustion)
	end
end

note over Func,SMC
  SMC failure does NOT block message processing.
end note
@enduml
```

## 5.4.3 Coordination

Fully asynchronous, event-driven, one message per invocation. Shares its trigger source (Service Bus topic, corporate item blob path) with EAII-283 and EAII-284, but has an independent subscription, so a failure or backlog on EAII-385 does not affect the other two.

### 5.4.3.1 Transaction Boundaries

Each message is a single, independent unit of work. The PUT-then-POST-on-404 sequence for one item is not atomic across the two calls — if the PUT returns 404 and the fallback POST then fails, the item remains not-created; the message is retried per the standard retry logic, and the next attempt will again try PUT then POST.

### 5.4.3.2 State Management

Stateless per invocation. The OAuth token cache is **not** shared with EAII-284 — MetProms uses `TokenService` (client_credentials grant), while EAII-284 uses the dedicated `IndiPIMTokenService` (password/refresh_token grant); the two are separate components with independent in-memory caches.

## 5.4.4 GoAnywhere Requirements

| Field | Value |
| --- | --- |
| Interface ID | EAII-385 |
| Interface Name | STIBO_to_RetailExpress_ProductMaster |
| Source System | STIBO (PIM) — sFTP |
| Target System | Gen 3 Blob Storage — `stibo/frompim/corporateitem` — **shared with EAII-283 and EAII-284** (same corporate item file) |
| Source File Protocol | sFTP |
| Target File Protocol | Azure Blob (HTTPS) |
| File Delivery Routing Rules | Pass-through to blob. STIBO XML (`<STEP-ProductInformation>` envelope, `FilterUserType=pph_msc_item` — corporate and location item types only; supplier items are out of scope for EAII-385) delivered unchanged. Downstream `CorporateItemToMetProms` Function reads the blob, transforms it to REX `item-attribute-records` JSON, and calls the REX REST API (PUT with POST-on-404 fallback). |
| Destination Filename Example | `12754962350080-12754962350080.xml` |

## 5.4.5 Design Considerations

NA



====================================================================================================
## DOC: TSD-EAII-289
====================================================================================================

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The legacy implementation runs on TIBCO BusinessWorks BWCE (`TibcoATOBusinessDetails` service) and exposes synchronous REST API operations. The legacy service calls ABR **SOAP** endpoints and transforms the SOAP XML response into JSON.

| **Operation** | **Legacy Process** | **Endpoint** | **ABR SOAP Operation** | **Response Format** |
| --- | --- | --- | --- | --- |
| ABN Lookup | `fetchDetailsREST.bwp` | `/fetchDetailsREST/apn/getabn/v1?abn={abn}` | SOAP `SearchByABNv201408` | XML → JSON |
| ACN Lookup | `fetchDetailsREST.bwp` | `/fetchDetailsREST/apn/gettbn/v1?acn={acn}` | SOAP `SearchByASICv201408` | XML → JSON |

All operations share:

- A hardcoded ATO authentication GUID
- Common Logging (CLE) for audit events
- Synchronous request-response pattern with no intermediate state

> **Note:** The legacy service uses ABR SOAP endpoints. The proposed APIM solution replaces these with ATO REST endpoints. No SOAP calls are made in the proposed architecture.
>

#### 5.1.1.2 Process Flow Diagram

![image-20260624-055756.png](images/01.png)

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

The proposed implementation uses **APIM as the sole processing layer**. APIM exposes four consumer-facing operations (`SearchByABN`, `SearchByABNv2`, `SearchByACN`, `SearchByACNv2`) that route to two ATO **REST** endpoints. Each transforms the ATO XML response to canonical `MetcashIdentifierBObj` JSON using a per-version XSLT template, and returns JSON to the consumer. ATO credentials are retrieved from a data-specific Key Vault via APIM named values. Success and failure events are logged to SMC.

**Process Steps (all operations):**

1. Consumer application sends a GET request to an APIM endpoint (e.g. `/eis/abnlookup/v1/SearchByABN?abn={11-digit}`)
2. APIM inbound policy validates the query parameter (ABN=11-digit or ACN=9-digit)
3. APIM generates a Transaction ID (`context.RequestId` or `Guid.NewGuid()`)
4. APIM retrieves ATO API credentials from the data-specific Key Vault (via named value with Key Vault reference)
5. APIM logs SMC Begin event via `send-request` policy (TransactionID, lookup key, operation)
6. APIM sets the backend URL based on the operation:
  - SearchByABN / SearchByABNv2 → ATO SearchByABN
  - SearchByACN / SearchByACNv2 → ATO SearchByACN

7. APIM forwards the request to ATO REST endpoint with credentials; ATO returns XML response
8. APIM outbound policy transforms the XML to canonical `MetcashIdentifierBObj` JSON:
  - v1 endpoints (SearchByABN, SearchByACN) use XSLT v1 template
  - v2 endpoints (SearchByABNv2, SearchByACNv2) use XSLT v2 template

9. APIM sets `Content-Type: application/json`
10. APIM logs SMC End event via `send-request` policy (TransactionID, StatusCode=200)
11. APIM returns HTTP 200 + JSON response to consumer
12. On failure: APIM on-error policy logs SMC Error event (TransactionID, fault detail) and returns structured JSON error response

#### 5.1.2.2 Process Flow Diagram

![image-20260820-102840.png](images/04.png)

#### 5.1.2.3 Sequence Diagram

![image-20260820-103611.png](images/06.png)

#### 5.1.2.4 PlantUML

```
@startuml
title EAII-289 - ATO Business Details Lookup - Metcash Internal to ATO\nProcess Flow (APIM-Only Architecture)

skinparam backgroundColor #FEFEFE
skinparam sequenceArrowThickness 2
skinparam participantPadding 20
skinparam boxPadding 10

skinparam participant {
  BackgroundColor #E8F4FD
  BorderColor #0066CC
  FontStyle bold
}

skinparam database {
  BackgroundColor #FFF3E0
  BorderColor #FF9800
}

skinparam note {
  BackgroundColor #FFFDE7
  BorderColor #FBC02D
}

box "Internal Consumers" #F5F5F5
participant "Metcash\nConsumer Apps\n(MDM, CRM, etc.)" as CA
end box

box "Azure Integration Services" #E3F2FD
participant "Azure APIM\n(API Gateway)\n4 Endpoints" as APIM
participant "SMC\n(send-request\nLogging)" as SMC
participant "Azure\nKey Vault\n(ATO Credentials)" as KV
participant "Application\nInsights" as AI
end box

box "External - Australian Taxation Office" #E8F5E9
participant "ATO\nREST API\n(XML Response)" as ATO
end box

== 1. Consumer Request ==

CA -> APIM : REST/HTTPS GET\n/{operation endpoint}?{abn|acn}={value}\n\nEndpoints:\n- SearchByABN?abn=\n- SearchByABNv2?abn=\n- SearchByACN?acn=\n- SearchByACNv2?acn=

== 2. APIM Inbound Policy - Validate & Setup ==

APIM -> APIM : Match APIM Operation:\n- SearchByABN / SearchByABNv2\n- SearchByACN / SearchByACNv2

APIM -> APIM : Validate input parameter:\n- ABN: 11-digit numeric\n- ACN: 9-digit numeric

alt Validation fails (invalid ABN/ACN)
    APIM --> CA : HTTP 400 Bad Request\n(Invalid ABN/ACN format)
else Validation passes
end

APIM -> APIM : Generate Transaction ID\n(context.RequestId / Guid.NewGuid())

APIM -> KV : Retrieve ATO API Credentials\n(Named Value / Key Vault reference)\n(Managed Identity)
KV --> APIM : ATO credentials

APIM -> SMC : **SMC Begin Event** (send-request)\n(TransactionID, LookupKey, Operation)

== 3. APIM Backend - Route to ATO ==

APIM -> APIM : Set backend URL:\n- SearchByABN/ABNv2 → ATO SearchByABN\n- SearchByACN/ACNv2 → ATO SearchByACN

APIM -> ATO : REST/HTTP GET\n(with ATO credentials)
ATO --> APIM : XML Response\n(ATO business details)

== 4. APIM Outbound Policy - Transform ==

APIM -> APIM : XSLT Transform:\nATO XML → MetcashIdentifierBObj JSON\n(v1 endpoints use XSLT v1 template)\n(v2 endpoints use XSLT v2 template)

APIM -> APIM : Set Content-Type: application/json

APIM -> SMC : **SMC End Event** (send-request)\n(TransactionID, StatusCode=200)

== 5. Response to Consumer ==

APIM --> CA : HTTP 200 + JSON Response\n(MetcashIdentifierBObj)

== Exception Handling ==

note over APIM, SMC
  **On-Error Policy (any failure):**
  - ATO connectivity failure → SMC Error + HTTP 500
  - ATO timeout → SMC Error + HTTP 504
  - ATO error response → SMC Error + HTTP 502
  - XSLT transform failure → SMC Error + HTTP 500
  - Key Vault access failure → SMC Error + HTTP 500
  - All errors: TransactionID, fault detail, structured JSON error
end note

== Monitoring ==

note over APIM, AI
  **SMC / Application Insights**
  - APIM send-request: Begin → End/Error events
  - Custom dimensions: TransactionID, Operation,
    EventType, StatusCode, LookupKey
  - Alert rules: Error rate >10%, Latency >5s, ATO failure
  - Dashboard: Standard APIM analytics
end note

note over CA
  **Consumer Applications**
  - Protocol: REST over HTTPS (GET)
  - Auth: OAuth2 / Subscription Key
  - Response: MetcashIdentifierBObj JSON
  - No retry at integration layer
    (caller manages retries)
end note

note over ATO
  **Target System - ATO**
  - REST: SearchByABN, SearchByACN
  - Auth: ATO API Credentials (Key Vault)
  - Port: 80 (HTTP)
  - Response: XML
  - Routing:
    APIM SearchByABN/v2 → ATO SearchByABN
    APIM SearchByACN/v2 → ATO SearchByACN
end note

@enduml
```

### 5.1.3 Coordination

This integration operates **synchronously**. The consumer sends an HTTP GET and blocks until a response is received. APIM processes the request entirely within its policy pipeline without persisting state.

#### 5.1.3.1 Transaction Boundaries

Single HTTP request-response cycle: Consumer -> APIM -> ATO -> APIM -> Consumer. No intermediate state is persisted. No message queuing or retry at the integration layer.

#### 5.1.3.2 State Management

N/A - Stateless. No state is maintained between requests.

### 5.1.4 GoAnywhere Requirements

N/A - GoAnywhere is not used in this interface.

### 5.1.5 Design Considerations

1. **APIM-only architecture**: Since ATO provides REST endpoints returning XML, APIM can natively proxy the request and transform the XML response in outbound policies. No separate compute backend is required, reducing infrastructure and operational overhead.
2. **XML-to-JSON transformation in APIM**: The outbound policy uses XSLT templates to transform the ATO XML response into the canonical `MetcashIdentifierBObj` JSON format. The transformation is executed inline within the APIM policy pipeline.
3. **Data-specific Key Vault for ATO secrets**: ATO API credentials (API keys, authentication tokens) are stored in a data-specific Azure Key Vault, separate from platform secrets. APIM accesses these via named values with Key Vault references using Managed Identity.
4. **SMC logging for success and failure**: APIM policies use `send-request` actions to emit audit events to SMC. Success events are logged in the outbound policy; failure events are logged in the on-error policy. Both include the Transaction ID for correlation.
5. **No response format negotiation**: The consumer always receives JSON. APIM performs the XML-to-JSON transformation transparently, simplifying the consumer contract.
6. **No retry at integration layer**: Retries are the consumer's responsibility. See [4.5.1 Retry Strategy](https://dev.azure.com/METCASHDevOps/Squad%2020/_wiki/wikis/Squad-20.wiki?wikiVersion=GBwikiMaster&pagePath=/%22e81f28e8cac04291b10323d5aebfe9ac%22%20retry%20strategy) for rationale and consumer guidance.



====================================================================================================
## DOC: TSD-EAII-297
====================================================================================================

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The legacy integration is implemented on the Tibco platform as a single BWP process (`mdmSupplierNumberInterface.bwp`) that handles both REST endpoints via two `bpws:onMessage` handlers. The process uses the following Tibco components:

- `mdmSupplierNumberInterface.bwp` — Main entry-point process. Handles HTTP listener on two paths (`/newsupplier/v1` and `/releasesupplier/v1`), performs Bearer token validation by calling the OAuth2 subprocess, invokes the IBM MDM SOAP service using TIBCO's SOAP Invoke activity with embedded XSLT 2.0 mappings, formats the supplier number using `tib:pad-front()`, and returns the response. All embedded transformations use XSLT 2.0 within `tibex:partBinding` mapper activities.
- `Oauth2Authentication.bwp` — Authentication subprocess. Validates the `Authorization: Bearer` header against a pre-loaded API key from configuration (`default.substvar`). In the legacy system this key is loaded at startup — rotating it requires a service restart.
- `invokeLogEvent.bwp` (CommonLogging shared process) — Asynchronous audit logging subprocess. Performs a fire-and-forget SOAP call to the centralised logging service. Called at request receipt and response points.
- `default.substvar` — Configuration file containing MDM endpoint URL, MDM credentials (username/password), supplier number format parameters (prefix=`10`, pad length=`5`, pad char=`0`), and the API key.

The legacy process is a synchronous request-response implementation: Tibco receives the REST request, validates the Bearer token, translates the request to MDM SOAP format, calls MDM, formats the response, and returns the JSON result to the caller. Error handling uses Tibco fault handlers that catch MDM SOAP faults and return structured error responses.

#### 5.1.1.2 Process Flow Diagram

![image-20260717-065355.png](images/08.png)

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

The proposed Azure Integration Services (AIS) solution replaces the existing TIBCO Process with **Azure API Management (APIM)** and **Azure Logic Apps Standard**.

**Get New Supplier Number**

**Endpoint**

`POST /api/mdm/newsupplier/v1`

**Processing Flow**

1. **Request Submission**
  - Salesforce MetConnect invokes the APIM endpoint over HTTPS.
  - The request contains:
    - AgreementID (mandatory)
    - TransactionID (optional)
    - SourceSystemID (optional)

  - Uses the supplied TransactionID or generates a GUID if not provided for SMC.
  - The request includes an OAuth2 Bearer token in the Authorization header.

2. **Authentication**
  - **APIM** validates the OAuth2 Bearer token. If the token is missing or invalid, APIM returns **HTTP 401 Unauthorized** with the message **"Authentication Failed"**. If validation succeeds, APIM forwards the request to the Logic App.

3. **Logic App Processing**
  - Receives the request through an HTTP trigger.
  - Records the start of processing using SMC audit logging.
  - Using its **Managed Identity**, the Logic App retrieves the required IBM MDM configuration from **Azure Key Vault**, including:
    - MDM WS-Security username
    - MDM WS-Security password

4. **SOAP Request Construction**
  - The Logic App constructs the **getNextSupplierNumber** SOAP request with the following values:
    - **RequestControl/requestID** = Current date and time formatted as **YYYYMMDDHHmmssSSS** (17 digits)
    - **RequestControl/DWLControl/requesterName** = Value retrieved from Key Vault
    - **RequestControl/DWLControl/requesterLanguage** = **100**
    - **MTTSupNumbersBObj/Parent** = AgreementID from the request
    - **MTTSupNumbersBObj/RefType** = **SUPPLIER NUMBER**
    - **MTTSupNumbersBObj/Prefix** = **10**
    - **WS-Security Header** = UsernameToken containing the MDM username and password retrieved from Key Vault

5. **MDM Invocation**
  - Calls the IBM MDM SOAP service over HTTPS using mutual TLS authentication.

6. **Response Processing**
  - Extracts the supplier reference number returned by MDM.
  - Formats the supplier number according to business rules (prefix followed by a zero-padded reference number).
  - Records successful completion using SMC.
  - Returns an HTTP 200 response containing:
    - TransactionID
    - AgreementID
    - SupplierNumber
    - SourceSystemID (when supplied in the request)

7. **Error Handling**
  - SOAP faults and unexpected exceptions are logged to Application Insights when logging enabled.
  - Failure is recorded in SMC.
  - Returns an HTTP 200 response containing the TransactionID, AgreementID, and a user-friendly failure message.

8. **Response Delivery**
  - APIM forwards the Logic App response to Salesforce MetConnect.

**Release Reserved Supplier Number**

**Endpoint**

`POST /api/mdm/releasesupplier/v1`

**Processing Flow**

1. **Request Submission**
  - Salesforce MetConnect invokes the APIM endpoint over HTTPS.
  - The request includes:
    - AgreementID (mandatory)
    - TransactionID (optional)
    - SourceSystemID (optional)
    - OAuth2 Bearer token.

2. **Authentication**
  - **APIM** validates the OAuth2 Bearer token against the API key stored in **Azure Key Vault**. If validation fails, APIM returns **HTTP 401 Unauthorized**. Otherwise, the request is forwarded to the Logic App.

3. **Logic App Processing**
  - Receives the HTTP request.
  - Uses the supplied TransactionID or generates one.
  - Initiates SMC audit logging.
  - Retrieves the required MDM credentials from Azure Key Vault.

4. **SOAP Request Construction**
  - The Logic App constructs the **clearReservedSupplierNumbers** SOAP request with the following values:
    - **RequestControl/requestID** = Current date and time formatted as **YYYYMMDDHHmmssSSS**
    - **RequestControl/DWLControl/requesterName** = Value retrieved from Key Vault
    - **RequestControl/DWLControl/requesterLanguage** = **100**
    - **MTTSupNumbersBObj/Parent** = AgreementID from the request
    - **MTTSupNumbersBObj/RefType** = **SUPPLIER NUMBER**
    - **Prefix** is **not included** in the Release Supplier SOAP request.
    - **WS-Security Header** = UsernameToken containing the MDM username and password retrieved from Key Vault.

5. **MDM Invocation**
  - Calls the IBM MDM SOAP service over HTTPS using mutual TLS authentication.

6. **Response Processing**
  - Extracts the ResultCode from the SOAP response.
  - Records successful completion using SMC.
  - Returns an HTTP 200 response containing:
    - TransactionID
    - AgreementID
    - SuccessString
    - SourceSystemID (when supplied)

7. **Error Handling**
  - Logs SOAP faults and unexpected exceptions to Application Insights.
  - Records failure in SMC.
  - Returns an HTTP 200 response with **SuccessString = "FAILED"**.

8. **Response Delivery**
  - APIM forwards the Logic App response to Salesforce MetConnect.

#### 5.1.2.2 Process Flow Diagram

![EAII-297-Process Flow Design.drawio (2)-20260727-033023.png](images/01.png)

#### 5.1.2.3 Sequence Diagram

![image-20260724-014143.png](images/02.png)

#### 5.1.2.4 PlantUML

```
@startuml EAII-297-SupplierNumberManagement-Sequence

title EAII-297 - Supplier Number Management

actor "Salesforce" as SF
participant "Azure API Management\nt3-met-{env}-ae-apim" as APIM
participant "Logic App\nt3-met-data-suppliercontract-{env}-ae-logic" as LA
participant "IBM MDM" as MDM
participant "SMC" as OBS

== API Request ==

SF -> APIM : Supplier Number API\n(Get New / Release Reserved)\nAuthorization: Bearer <token>

alt Authentication Successful

    APIM -> LA : Forward Request

else Authentication Failed

    APIM -> OBS : Start Observation\n(TransactionId?, AgreementID?)
    APIM -> OBS : End Observation\n(Status=Authentication Failed,\nReason=Invalid/Missing Token)
    APIM --> SF : HTTP 401 Unauthorized

end

== Request Processing ==

LA -> OBS : Start Observation\n(TransactionId, AgreementID)

LA -> LA : Validate Request
LA -> LA : Generate TransactionId\n(if not provided)

alt Get New Supplier Number

    LA -> LA : Build getNextSupplierNumber\nSOAP Request

    loop Retry (Maximum 3 Attempts)
        LA -> MDM : getNextSupplierNumber\n(SOAP + WS-Security)
        MDM --> LA : Supplier Number Response
    end

    LA -> LA : Format Supplier Number

    alt MDM Success
        LA -> OBS : End Observation\n(Status=Success)
        LA --> APIM : HTTP 200\nSupplierNumber Response
    else MDM Fault / Timeout
        LA -> OBS : End Observation\n(Status=Failed)
        LA --> APIM : HTTP 200\nFailure Response
    end

else Release Reserved Supplier Number

    LA -> LA : Build clearReservedSupplierNumbers\nSOAP Request

    loop Retry (Maximum 3 Attempts)
        LA -> MDM : clearReservedSupplierNumbers\n(SOAP + WS-Security)
        MDM --> LA : Release Response
    end

    alt MDM Success
        LA -> OBS : End Observation\n(Status=Success)
        LA --> APIM : HTTP 200\nSuccess Response
    else MDM Fault / Timeout
        LA -> OBS : End Observation\n(Status=Failed)
        LA --> APIM : HTTP 200\nFailure Response
    end

end

== Monitoring ==

LA -> OBS : Log TransactionId,\nAgreementID,\nStatus & Exceptions

APIM --> SF : HTTP 200 Response

@enduml
```

### 5.1.3 Coordination

This integration operates synchronously. Salesforce MetConnect sends a request to either the **Get New Supplier Number** or **Release Reserved Supplier Number** API and waits for the response. The Azure Logic App validates the request, invokes the appropriate **IBM MDM SOAP service**, processes the response, and returns the result to the caller within the lifetime of the synchronous HTTP request.

#### 5.1.3.1 Transaction Boundaries

**Transaction Unit:** A single **Get New Supplier Number** or **Release Reserved Supplier Number** API request constitutes one transaction. Each request processes a single **Agreement ID** and results in a single IBM MDM SOAP service invocation.

**Atomicity:** Each request is processed as a single atomic transaction. If the IBM MDM service successfully completes the requested operation, the response is returned to Salesforce MetConnect. If the IBM MDM service returns a SOAP fault or the request times out after all retry attempts are exhausted, the transaction is considered failed, and an appropriate failure response is returned.

**Retry Policy:** Transient failures during IBM MDM SOAP service invocation are retried up to **three attempts** before the transaction is marked as failed.

**Timeout:** The Azure Logic App executes the complete request within the lifetime of the synchronous HTTP call. IBM MDM SOAP service invocations are subject to configured HTTP/SOAP timeout settings, and the overall request must complete within the Logic App execution timeout.

#### 5.1.3.2 State Management

**Stateless per Request:** The integration is stateless. No application state is persisted between requests within the Azure integration layer. Each **Get New Supplier Number** or **Release Reserved Supplier Number** request is processed independently based on the request payload and the corresponding IBM MDM SOAP service response.

### 5.1.4 GoAnywhere Requirements

*N/A*

### 5.1.5 Design Considerations



====================================================================================================
## DOC: TSD-EAII-301_302_516_517
====================================================================================================

#### 5.1.1 As-is Process

#### 5.1.2 Proposed Process

#### 5.1.3 Coordination

Fully asynchronous, event-driven. One message per invocation, no batching. Standard default Azure Function App / Service Bus trigger concurrency applies; no artificial concurrency limit is applied in the proposed design (applies identically to EAII-517, EAII-516, and EAII-302).

##### 5.1.3.1 Transaction Boundaries

One Service Bus message = one MDM retrieval call = one output (flat file for EAII-301; target HTTP POST for EAII-517/516/302). No cross-message transaction; deduplication (where applicable) is scoped to the single message being processed (§5.1.5).

##### 5.1.3.2 State Management

Stateless per invocation — no state is persisted between messages. This is a direct implication of the in-message-only dedup scope (§5.1.5): there is nothing to look up or update in a prior-state store.

#### 5.1.4 GoAnywhere Requirements

| Field | Value |
| --- | --- |
| Interface ID | EAII-301 |
| Interface | `MDM_to_EIM_SupplierContract` |
| Source | Supplier MDM via Function App |
| Target | EIM via GoAnywhere |
| Source/target protocol | Azure Blob over HTTPS |
| Container/path | `eim/toeim/supplierinfo` |
| Filename | `MDS_{SUPPLIER_PAY_TO_NUMBER}_{TIMESTAMP}.{CorrelationId}.txt` |

#### 5.1.5 Design Considerations

Duplicate detection is replicated exactly within a single message. Repeated reference-data values such as category names, department names, status descriptions, and payment methods are deduplicated before file assembly, via a keyed lookup against the Reference Message's own `MetcashReferenceDataBObj/ReferenceCodeTypeBObj` entries. Cross-message deduplication is not included.

#### 5.2.1 As-is Process

#### 5.2.2 Proposed Process

The flow begins identically to the other three interfaces: a supplier contract change in IBM MDM is published as a `TCRMService` XML message, picked up by the JMS publisher (config-driven timer poll), written as the Reference Message payload to Blob Storage (`t3data{env}aesta01`), and announced as a blob-created pointer event onto the shared Service Bus topic (`data.SupplierInfoFromMDM.{env}.sbt`). The `topim.supplierinfo` subscription — new for EAII-302, added on the existing shared topic — filters and delivers this pointer to the `MDMSupplierInfoToPIM` Function. Dead-lettering on the subscription is configured identically to EAII-517/516.

`MDMSupplierInfoToPIM` downloads the Reference Message XML from Blob Storage using the pointer, then transforms it into a STEP-ProductInformation XML supplier hierarchy. This transform builds a Pay-To Classification carrying the supplier's core attributes plus 5 fixed sub-classifications, nested Buy-From Classifications (each correlated to its own contract component, carrying its own status/name data rather than inheriting the Pay-To component's), pillar cross-references, and a Products section populated only for Agreement Terms that satisfy the qualifying filter (a payment-method or discount-type condition, combined with a matching Contract Component Party Role).

Before delivery, the Function acquires an OAuth 2.0 bearer token via client_credentials grant. Token acquisition performs real two-step discovery — GET the OIDC discovery document at the configured discovery path, parse out the actual `token_endpoint`, then POST the client_credentials grant there — rather than skipping discovery and hitting a hardcoded token endpoint directly. Tokens are cached in memory with a 60-second pre-expiry refresh buffer, so this two-call sequence only runs on cold start or near expiry, not on every message.

With a valid bearer token, the Function POSTs the STEP XML to the PIM Supplier Hierarchy REST endpoint (`https://{PIMHost}:443/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main`), Content-Type `application/xml`. A successful call returns HTTP 202 (Accepted), at which point the Service Bus message is completed.

Delivery failures are handled with the same in-process retry/dead-letter model used by EAII-517/516: up to 3 attempts with a fixed 2-second delay. Any 4xx response other than 401/403 is treated as non-retryable and fails immediately (matching EAII-517/516's HTTP 400 handling); connectivity failures, PIM 5xx responses, and 401/403 authentication rejections are retried within that same 3-attempt budget. On exhaustion — or on an upstream transformation failure that prevents the call from being attempted at all — the message is dead-lettered immediately, with no reliance on Service Bus's own redelivery mechanism, matching the guaranteed-delivery pattern shared by all four interfaces.

Processing is fully asynchronous, event-driven, and stateless: one Service Bus message produces exactly one transform and one PIM delivery attempt, with no cross-message state retained.

#### 5.2.3 Coordination

Fully asynchronous, event-driven. One message per invocation, no batching. Standard default Azure Function App / Service Bus trigger concurrency applies; no artificial concurrency limit is applied in the proposed design (shared with EAII-301, EAII-517, and EAII-516).

##### 5.2.3.1 Transaction Boundaries

One Service Bus message = one MDM-sourced transform = one PIM delivery attempt (single POST to the STIBO STEP PIM Supplier Hierarchy endpoint). No cross-message transaction.

**5.2.3.2 State Management**

Stateless per invocation — no state is persisted between messages, apart from the in-memory OAuth token cache (60-second pre-expiry refresh buffer), which is a performance optimization, not application state tied to any individual message.

---

**5.2.4 API Endpoint Information**

*(already documented at §5.2.4 in the current TSD — reproduced here for completeness in this section grouping)*

| Field | Value |
| --- | --- |
| Target endpoint | `https://{PIMHost}:443/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main` |
| Method | `POST` |
| Content type | `application/xml` |
| Success response | HTTP 202 (Accepted) |
| Authentication | OAuth 2.0 bearer token (client_credentials grant) in the `Authorization` header only. |

#### 5.2.5 Design Considerations

- OAuth token acquisition uses real two-step discovery (GET the OIDC discovery document, resolve `token_endpoint`, then POST the client_credentials grant), not a hardcoded direct token endpoint. In-memory cache with a 60-second pre-expiry refresh buffer limits how often this sequence runs.
- Duplicate `attr_paytosupplierName` emission is de-duplicated to one occurrence in the AIS build (confirmed legacy defect).
- Buy-From attributes (status date, status, supplier name) read the Buy-From component's own `MTTSupCoreBObj`, correlated by that component's own `ContrComponentId` — not inherited from the Pay-To component (confirmed as-is/intentional).
- `attr_suptermsdiscounttp` is resolved via the same `MetcashReferenceDataBObj/ReferenceCodeTypeBObj` keyed-lookup pattern used elsewhere (EAII-301 §5.1.5), keyed by `CodeType='XCDDISCOUNTTP'` and `DiscountValue`.
- A Product is emitted only when (`PaymentMethodDesc = 'Off Invoice'` OR `DiscountType = '2000008'`) AND a matching Contract Component Party Role (`RoleType = '2000012'`) exists.
- `attr_ImportSupplier`/`attr_DefaultCurrencycode` (new attributes, no legacy precedent) use a first-Agreement-encountered selection rule when a supplier has multiple `MTTAgreementBObj` entries — provisional, pending business confirmation.

**5.2.6 Service High-Level Design**

**5.2.6.1 Component List**

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts `MDMSupplierInfoToPIM` (shared host with EAII-301/517/516). |
| Azure Service Bus Subscription (`topim.supplierinfo`, on shared topic) | `Microsoft.ServiceBus/topics` | Delivers the reference message. |
| STIBO STEP PIM REST API | N/A | Accepts the STEP-ProductInformation supplier hierarchy upload. |
| OAuth 2.0 Authorization Server (PIM) | N/A | Issues client_credentials bearer tokens via OIDC discovery. |
| Azure Key Vault (AIS) | `Microsoft.KeyVault/vaults` | PIM OAuth `client_id`/`client_secret`, SMC subscription key — existing vault, reused. |
| Application Insights / SMC (via APIM) | N/A | Observability — see §3.2 Error Handling and Monitoring. |

**5.2.6.2 Services**

- `MDMSupplierInfoToPIM` (Function trigger) — Service Bus pull-triggered entry point using standard default trigger concurrency.
- `MdmSupplierInfoToPimService` (business logic) — downloads the Reference Message, transforms to STEP XML, acquires an OAuth token, POSTs to PIM, applies retry/dead-letter policy.
- `SupplierContractToPimTransformService` — MDM XML → STEP-ProductInformation XML (Pay-To/Buy-From classifications, Products section), per the mapping document.
- `PimOAuthTokenService` — performs OIDC discovery, acquires and caches the client_credentials bearer token.

**5.2.6.3 Audit, Logging & Exceptions**

**5.2.6.3.1 Logging**

As per the SMC specification, the following information is logged.

Interface ID = EAII-302 (Supplier MDM → STIBO STEP PIM)

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and completes the observation for a single Function invocation in one call — `IsObservationComplete = true` is always set, since this interface makes exactly one transform + one PIM delivery attempt per message. `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), linking this interface's observation with EAII-301/517/516's for the same source event. | `{SmcBaseUrl}/{SmcStartObservationApiName}` → `https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1/start-observation` | POST |

**5.2.6.3.2 Audit**

All critical events and exceptions are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for the Function App. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique correlation ID is generated for each Service Bus message and propagated throughout the entire processing pipeline (transform → OAuth token acquisition → PIM delivery). SMC records the lifecycle of each transaction via a single completed observation per Function invocation.

**5.2.6.3.3 Exceptions**

| Observation Stage | Failure Scenario | Trigger | Action | Notification |
| --- | --- | --- | --- | --- |
| Transformation | Transformation error | Invalid/unexpected data in Reference Message causing mapping failure | Log error with full exception details and correlation identifiers. Dead-letter the message immediately (no PIM call made). | Standard DLQ-accumulation alerting. |
| OAuth token acquisition | Discovery or token request failure | Discovery document unreachable, malformed, or client_credentials rejected | Log error with correlation identifiers. Dead-letter the message immediately (PIM call not attempted). | Standard DLQ-accumulation alerting, at the same or higher priority given the Gold SLA. |
| PIM delivery — authentication rejection | HTTP 401/403 | PIM rejects the bearer token | Retry up to 3 times with a 2-second fixed delay; dead-letter on exhaustion. | Standard DLQ-accumulation alerting, at the same or higher priority given the Gold SLA. |
| PIM delivery — business rejection | HTTP 4xx other than 401/403 | PIM rejects the payload as invalid | Log error, dead-letter immediately (non-retryable). | Standard DLQ-accumulation alerting. |
| PIM delivery — transient failure | Connectivity failure or HTTP 5xx | Network error, timeout, or PIM server error | Retry up to 3 times with a 2-second fixed delay; dead-letter on exhaustion. | Standard DLQ-accumulation alerting, at the same or higher priority given the Gold SLA. |

**5.2.7 SMC Onboarding and Load**

**5.2.7.1 Integration Onboarding**

| Field | Value |
| --- | --- |
| Interface ID | EAII-302 |
| Interface Name | `MDMSupplierInfoToPIM` |
| Source Application | Supplier MDM |
| Destination Application | STIBO STEP PIM |
| Interface Type | Async, event-driven, single-threaded |
| Interface DataStore | N/A (no persistent output store — PIM delivery only) |
| Reference Keys | CorrelationId, PartyId, Contract Component ID |

**5.2.7.2 SMC Load**

| Field | Value |
| --- | --- |
| Interface ID | EAII-302 |
| Interface name | `MDMSupplierInfoToPIM` |
| Source | Supplier MDM |
| Destination | STIBO STEP PIM |
| Type | Async, event-driven |
| SLA | Gold (99.9%) |
| Reference keys | CorrelationId, PartyId, Contract Component ID |
| Average volume | Same source (Supplier MDM) as EAII-301/517/516 — 10–15 messages/day |
| Observations | 1 complete observation per message |

#### 5.3.1 As-is Process

When a supplier contract change occurs, a lightweight reference message is placed on a dedicated queue for the ALM Sorted target (`Service.MDM.SupplierContractALM.Q`, bridged from topic `Service.MDM.TradingAccount.T`, selector `INTERFACECODE='MDMSUPCNT001'`, queue options `store=$sys.failsafe, redeliveryDelay=300`). The legacy integration: receives the message with client-mode acknowledgement and **redelivery-count tracking** (max 3 — see poison-message handling below) → calls the MDM REST API (same as EAII-301, HTTP `PUT`) → transforms the response into a JSON supplier entity structure → delivers via HTTPS POST to the ALM Sorted supplier endpoint → on success, acknowledges the source message.

**Authentication (ALM Sorted delivery):** Certificate-based (TLS mutual auth via keystore) — per FSD; **not yet confirmed against real target credentials** (see §5.2.5 open item — this states the legacy mechanism, not necessarily what our build will use without verification).

**Concurrency:** Up to 10 sessions.

**Retry:** 3 attempts, 30-second intervals for transient failures (per FSD §3.2.6 NFR — note this differs from EAII-301's 5-second interval, see §5.1.2.1 callout).

**Poison-message handling (per FSD §3.2.1.2):** redelivery count tracked; if it exceeds 3, the message is acknowledged **without processing** and an error is logged **without notification** — deliberate, to prevent alert storms from poison messages.

**Known Issues (per FSD §3.2.1.3):**

- Shared schema with Food Sorted — both targets use the same intermediate schema and similar transformation logic; potential for a single shared transformation with multi-target routing.
- Redelivery count handling — messages silently consumed past the redelivery cap; persistent failures may go unnoticed if monitoring doesn't specifically track consumed-without-processing events (see §5.2.8 Monitoring).

**Data classification (per FSD §3.2.5):** Internal. Supplier contract data including business identifiers and agreement details — internal to Metcash operations. Standard internal data handling; encrypt in transit (TLS/HTTPS).

#### 5.3.2 Proposed Process

**5.3.2.1 Description of Process(es)**

1. A blob-created pointer message arrives on our Service Bus subscription (`toalmsorted.supplierinfo`, on the shared topic — see §3.2). The reference message payload itself is written to Blob Storage by the upstream JMS publisher; only the pointer arrives on the subscription. `MDMSupplierInfoToALMSorted` (Function trigger / Service Bus executor) receives the pointer message with `autoComplete=false`. The executor downloads the Reference Message XML from Blob Storage using the pointer, then invokes the ALM Sorted service exactly once; all target-delivery retries occur inside that single service call. The service calls the MDM REST API once only (same client/request shape as EAII-301 — see §5.1.2.1) to retrieve the complete supplier contract data. The response is transformed into the ALM Sorted JSON supplier entity structure, including:
  - Legal entity details (ID, name, ABN, ACN, TABN, contact email)
  - Request type indicator (`getSupplierDetailsByContractId`, confirmed from real payload samples — `inbox/additional_payload_sample/SupplierInfoRequestToALMSorted_Sample*.json`)
  - Supplier contract details: agreement information, contract components (Pay To + Buy From parties with roles, one Buy From component per state/territory: NSW/VIC/QLD/SA/WA/NT), administrative native keys, supplier group, core supplier data, extended data

2. The service delivers the JSON payload via HTTPS POST to the ALM Sorted supplier endpoint (no authentication required) using the shared EAII-517/516 retry/dead-letter design:
  - **Tier 1 — service/business logic**: retry the ALM Sorted HTTP POST only, up to 3 attempts with a 2-second fixed delay. HTTP 2xx returns Success immediately. HTTP 400 is non-retryable and returns Failure immediately. Any other non-2xx status or thrown exception is retryable until the attempt limit is reached. Transformation failures throw immediately and skip the HTTP retry loop.
  - **Tier 2 — Service Bus executor**: on Success, call `CompleteMessageAsync`. On Failure or any unhandled exception, call `DeadLetterMessageAsync` immediately with the HTTP status or exception detail as the dead-letter reason.

3. Every message is settled on its first and only delivery. There is no abandon-and-redeliver step and no DeliveryCount check in the EAII-517 design. SMC observation is logged at each key stage (including a Blob Downloaded stage once the Reference Message XML is retrieved) and once finally per message in a finally block, regardless of success, business failure, or unhandled exception.

#### **5.3.3 Coordination**

Fully asynchronous, event-driven. One message per invocation, no batching. Standard default Azure Function App / Service Bus trigger concurrency applies; no artificial concurrency limit is applied in the proposed design (shared with EAII-301, EAII-516, and EAII-302).

**5.3.3.1 Transaction Boundaries**

One Service Bus message = one MDM retrieval call = one ALM Sorted POST operation = one settlement outcome. No cross-message transaction.

**5.3.3.2 State Management**

Stateless per invocation — no state is persisted between messages.

#### 5.3.4 API Endpoint Information

| Parameter | Value |
| --- | --- |
| FSD endpoint | `https://{host}/occ/v2/alm/mdm/supplier` |
| Legacy-config endpoint | `https://{host}/occ/v2/almretailersspa/mdm/supplier` |
| Method | `POST` |
| Content type | `application/json` |
| Authentication | No authentication required (confirmed). |

#### 5.3.5 Design Considerations

Target-delivery retry is kept inside the service so the MDM call and SMC observation occur once per logical message. The ALM Sorted and Food Sorted transformations are structurally similar but remain separate classes to preserve decoupling.

#### 5.4.1 As-is Process

Functionally identical to EAII-517 (§5.2.1.1): reference message on a dedicated queue (`Service.MDM.SupplierContractAutoCT.Q`, bridged from topic `Service.MDM.TradingAccount.T`, selector `INTERFACECODE='MDMSUPCNT001'`, queue options `store=$sys.failsafe, redeliveryDelay=300`) → client-mode acknowledgement with redelivery-count tracking (max 3) → MDM REST API retrieval (same as EAII-301/517) → transformation into the same JSON supplier entity structure as EAII-517 → HTTPS POST delivery to the Food Sorted endpoint (different host/path from ALM Sorted).

**Authentication (Food Sorted delivery):** Certificate-based (TLS mutual auth via keystore) — per FSD; same open-item caveat as EAII-517 (§5.3.5) applies — not yet confirmed against real target credentials.

**Concurrency:** Up to 10 sessions.

**Retry:** Same as EAII-517 — 3 attempts, 30-second intervals for transient failures.

**Poison-message handling:** Identical to EAII-517 — redelivery count > 3 results in silent acknowledge-without-processing, logged without notification.

**Known Issues (per FSD §3.3.1.3):** Same as EAII-517 — shared schema presents a consolidation opportunity; redelivery count handling may mask persistent failures.

**Data classification (per FSD §3.3.5):** Internal — same as EAII-517. Standard internal data handling; encrypt in transit (TLS/HTTPS).

![image-20260714-010819.png](images/07.png)

Functionally similar to EAII-517, using the Food Sorted target endpoint and legacy queue `Service.MDM.SupplierContractAutoCT.Q`. The proposed design does not use Service Bus redelivery; target delivery is retried in-process and failures are dead-lettered.

#### 5.4.2 Proposed Process

#### 5.4.3 Coordination

Fully asynchronous, event-driven. One message per invocation, no batching. Standard default Azure Function App / Service Bus trigger concurrency applies; no artificial concurrency limit is applied in the proposed design (shared with EAII-301, EAII-517, and EAII-302). Manual Service Bus message settlement is used, same as EAII-517.

##### 5.4.3.1 Transaction Boundaries

One Service Bus message = one MDM retrieval call = one Food Sorted POST operation = one settlement outcome. No cross-message transaction.

##### 5.4.3.2 State Management

Stateless per invocation — no state is persisted between messages.

#### 5.4.4 API Endpoint Information

| Parameter | Value |
| --- | --- |
| FSD endpoint | `https://{host}/metcashcommercewebservices/v2/mdm/supplier` |
| Legacy-config endpoint | `https://{host}/occ/v2/sorted/mdm/supplier` |
| Method | `POST` |
| Content type | `application/json` |
| Authentication | mTLS client certificate (leaf + intermediate CA cert, loaded via the platform trust store configuration). |

#### 5.4.5 Design Considerations

Food Sorted uses a different backend from ALM Sorted. Its host pattern matches the existing Sorted Marketplace integration. The transformation is structurally identical to ALM Sorted (both derive from the same shared MDM response, same supplier JSON shape) but remains a separate class to prevent silent drift between the two targets. Unlike ALM Sorted, delivery requires mTLS client-certificate authentication — the leaf and intermediate CA certificates are loaded via the platform's trust store configuration rather than a dedicated Key Vault secret.



====================================================================================================
## DOC: TSD-EAII-304
====================================================================================================

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The legacy integration is implemented on TIBCO BusinessWorks and consists of two phases:

**Upload Phase (Legacy TIBCO):** The TIBCO `IBADirectsService.bwp` process exposes a REST API endpoint (`POST eis/ibadirects/v1/submitOrder`). A supplier submits a JSON request containing a `DocumentHeader` (Transaction ID, Document Type, Timestamp, Supplier ID) and the directs file content as a base64-encoded ZIP archive. The integration authenticates the request by validating the bearer token against a static set of pre-provisioned API keys loaded at startup from S3 cloud storage and cached in memory (`Activator.bwp`). If authentication succeeds, the `JMSUploadDirectsFile.bwp` subprocess (via `UploadAPI.bwp`) validates the payload, stores the ZIP to the S3 input directory, and places a message on a JMS queue. The API returns a synchronous success/error response.

**Translation Phase (Legacy TIBCO):** The `JMSTranslateToPSV.bwp` JMS listener picks up the queued message and invokes the `XlateToPSV.bwp` subprocess, which: downloads the source ZIP from S3, writes it to a temporary directory, decompresses it using the `UnzipFile.java` utility, parses the extracted JSON source file, transforms each record to PSV format using the `EIMFile.dataFormatResource` DataFormat configuration, uploads the PSV file to the S3 output directory, moves the source ZIP to the S3 archive directory, and deletes temporary files.

**Known Issues in Legacy Platform:**

1. Static token management — tokens loaded at startup, no dynamic rotation; requires service restart to update tokens.
2. Single-threaded translation (`MaxSessions=1`) — files processed sequentially.
3. File size validation only at API entry point; no secondary check in translation phase.

#### 5.1.1.2 Process Flow Diagram

![image-20260703-052306.png](images/02.png)

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

The proposed Azure Integration Services (AIS) solution retains the existing two-phase processing model while addressing the limitations of the legacy implementation. Authentication is performed using an OAuth2 Bearer token validated by Azure API Management (APIM), while Azure Service Bus decouples the upload and translation processes to improve reliability, scalability, and resilience.

**Upload Phase (AIS):**

1. **API Request Received** — A liquor supplier submits a `POST` request to APIM endpoint `eis/ibadirects/v1/submitOrder` with bearer token and a JSON `DirectsFileDocument` body containing a `SupplierID` and base64-encoded ZIP file content.
2. **Authentication** — APIM validates the bearer token. If invalid or missing, APIM returns `HTTP 401 Unauthorized`
3. **Payload Validation** — APIM validates: the request payload to ensure that the `SupplierID` is provided. If the `SupplierID` is missing, APIM returns an **HTTP 400 Bad Request** response.
4. **File Size Validation** — APIM validates the file size of **3 MB**. Based on the validation result, APIM generates the target Blob Storage path:
  - **Valid file:** `IBADirects/in/{SupplierId}_{yyyyMMddHHmmss}.zip`
  - **File exceeding 3 MB:** `IBADirects/error/{SupplierId}_{yyyyMMddHHmmss}.zip`

5. **Upload backend API call**— APIM forwards the request to the backend and uploads the ZIP file to the specified blob path using EAII-367 blob management upload API.
6. **Return Synchronous Response** — After successful upload response from backend If the file exceeds the 3 MB limit, returns the bad request. Otherwise, APIM receives the response from the backend and returns the same response to the consumers.
7. **Log Transaction** — The transaction outcome, including success or error status, is logged to SMC with Transaction ID, Supplier ID, Document Type, and status.

**Translation Phase (AIS):**

1. **Publish Blob Created Event** — After the ZIP file is successfully stored in `IBADirects/in`, Azure Blob Storage publishes a **Blob Created** event to **Azure Event Grid**.
2. **Route Event to Service Bus** — Azure Event Grid publishes a message to the `b2b.ibadirectstoeim.sbq-{env}` Azure Service Bus queue. The message contains the blob path and filename, along with the **Supplier ID, timestamp, and Transaction ID** required for downstream processing.
3. **Translation Logic App Triggered** — The **Translation Orchestrator Logic App** is triggered when a message is received from the `b2b.ibadirectstoeim.sbq-{env}` Azure Service Bus queue.
4. **Download Source File** — The Logic App retrieves the source ZIP file from `IBADirects/in` in Azure Blob Storage using the blob path provided in the Service Bus message.
5. **Decompress ZIP File** — The Logic App decompresses the ZIP archive and extracts the source JSON file to temporary storage.
  - **On failure:** Log and update the SMC transaction history with an error status.

6. **Transform to PSV** — The Translation Logic App reads the extracted JSON file from temporary storage and passes its content to the **Inline Azure Function**. The function iterates through all `DirectsData` records, transforms each record into a **20-field pipe-separated (PSV) row**, and returns the generated PSV content to the Logic App.
  - **On failure:** Log and update the SMC transaction history with an error status.

7. **Generate Output Files** — The Logic App generates the following output files:
  - **PSV file:** `{SourceFileNameWithoutExtension}.PSV`
  - **Deliver Output Files** — The Logic App uploads both the PSV file to `IBADirects/ToEIM` in Azure Blob Storage for pickup by **GoAnywhere/EIM**.
  - **On storage failure:** Retry the operation up to **3 times**. If all retries are exhausted, log the applicable storage error code and update the SMC transaction history with an error status.

8. **Archive Source File** — After successful transformation and output file delivery, the Logic App moves the original source ZIP file from `IBADirects/in` to `IBADirects/archive`.
  - **On failure:** Log and update the SMC transaction history with an error status.

9. **Cleanup Temporary Files** — The Logic App deletes any temporary files created during the processing from temporary storage.
10. **Log Transaction** — The translation outcome is logged to SMC with the **Transaction ID, Supplier ID, processing timestamps, and final transaction status**.

#### 5.1.2.2 Process Flow Diagram

![EAII-304-Process Flow Design.drawio (2)-20260805-155826.png](images/07.png)

#### 5.1.2.3 Sequence Diagram

![image-20260810-051801.png](images/01.png)

#### 5.1.2.4 PlantUML

```
@startuml EAII-304 IBADirects Upload Sequence

title EAII-304 - IBA Directs Upload & Processing\nProposed AIS Sequence

participant "Microsoft Entra ID" as AAD
actor "Liquor Supplier" as Supplier
participant "Azure APIM\nt3-met-core-{apim-env}-ae1-apim" as APIM
participant "UploadBlob\nAzure Function" as UploadBlob
database "Azure Blob Storage\nt3b2b{env}aesta01\nALM container" as Blob
participant "Azure Event Grid\nevt-t3b2b{env}aesta01-alm-ibadirects-in-create-sbq-{env}-ae" as EG
queue "Azure Service Bus\nt2-met-{npr/prd}-ae-sb001\nQueue: b2b.ibadirectstoeim.sbq-{env}" as SB
participant "Translation Logic App\nt3-met-b2b-ibadirects-{env}-ae-logic" as ProcessLA
participant "PSV Converter\nInline Azure Function" as PSV
participant "GoAnywhere Managed File Transfer" as MFT
participant "SMC" as SMC

== Upload Phase ==

Supplier -> AAD : Request OAuth Access Token
AAD --> Supplier : Access Token

Supplier -> APIM : POST eis/ibadirects/v1/submitOrder\nBearer Token + JSON Payload

APIM -> APIM : Validate Bearer Token
APIM -> APIM : Validate Request Payload

alt Authentication Failed

    APIM -> SMC : Log Authentication Failure
    APIM --> Supplier : HTTP 401 Unauthorized

else Payload Validation Failed

    APIM -> SMC : Log Validation Failure
    APIM --> Supplier : HTTP 400 Bad Request

else File Size > 3 MB

    APIM -> UploadBlob : Upload ZIP\nIBADirects/error/{SupplierId}_{Timestamp}.zip
    UploadBlob -> Blob : Store ZIP\nIBADirects/error
    Blob --> UploadBlob : Upload Result
    UploadBlob --> APIM : Upload Result

    APIM -> SMC : Log IBADIRECTS-ERR-001\nFile Size Exceeded
    APIM --> Supplier : Error Response

else Valid Request

    APIM -> UploadBlob : Upload ZIP\nIBADirects/in/{SupplierId}_{Timestamp}.zip
    UploadBlob -> Blob : Store ZIP\nIBADirects/in
    Blob --> UploadBlob : Upload Result
    UploadBlob --> APIM : Upload Success

    APIM -> SMC : Log Upload Success\nTransaction ID + Supplier ID
    APIM --> Supplier : Return Backend Response

end

== Asynchronous Translation Phase ==

Blob -> EG : Blob Created Event\nIBADirects/in

EG -> SB : Publish Event\nBlob Path + Metadata

SB -> ProcessLA : Service Bus Trigger

ProcessLA -> Blob : Download Source ZIP\nIBADirects/in
Blob --> ProcessLA : ZIP File

ProcessLA -> ProcessLA : Decompress ZIP
ProcessLA -> ProcessLA : Read Extracted JSON

ProcessLA -> PSV : Pass JSON Content
PSV --> ProcessLA : PSV Content

ProcessLA -> ProcessLA : Generate PSV File
ProcessLA -> ProcessLA : Generate Trigger File

ProcessLA -> Blob : Upload PSV\nIBADirects/ToEIM
Blob --> ProcessLA : Upload Successful

ProcessLA -> Blob : Upload PSV.trg\nIBADirects/ToEIM
Blob --> ProcessLA : Upload Successful

ProcessLA -> Blob : Move ZIP\nIBADirects/archive
Blob --> ProcessLA : Archive Complete

ProcessLA -> ProcessLA : Delete Temporary Files

ProcessLA -> SMC : Log Translation Success\nTransaction ID + Supplier ID

ProcessLA -> SB : Complete Message

MFT -> Blob : Pickup Files\nIBADirects/ToEIM
Blob --> MFT : PSV and Trigger Files

== Translation Error Handling ==

alt ZIP Decompression Failed

    ProcessLA -> SMC : Log IBADIRECTS-ERR-003
    ProcessLA -> SB : Abandon Message

else PSV Transformation Failed

    ProcessLA -> SMC : Log IBADIRECTS-ERR-002
    ProcessLA -> SB : Abandon Message

else Output Upload Failed

    ProcessLA -> SMC : Log Storage Failure
    ProcessLA -> SB : Abandon Message

else Archive Failed

    ProcessLA -> SMC : Log IBADIRECTS-ERR-004
    ProcessLA -> SB : Abandon Message

end

@enduml
```

### 5.1.3 Coordination

This integration operates in two modes:

  - **Synchronous (Upload Phase):** The supplier request is processed synchronously through **Azure APIM**. APIM authenticates and validates the request, determines the target Azure Blob Storage path, and invokes the **UploadBlob Function** to store the ZIP file. Once the upload is completed successfully, APIM returns the backend response to the supplier confirming receipt.
  - **Asynchronous (Translation Phase):** The translation process operates asynchronously and is decoupled from the supplier's upload request. Once the ZIP file is successfully stored in Azure Blob Storage, a **Blob Created** event is published to **Azure Event Grid**, which routes the event to the **Azure Service Bus** queue. The **Translation Logic App** is triggered by the Service Bus message and independently retrieves, decompresses, transforms, and delivers the output files to the `IBADirects/ToEIM` location. This decoupled approach enables reliable, scalable, and resilient background processing without impacting the synchronous upload response.

#### 5.1.3.1 Transaction Boundaries

  - **Upload Transaction Boundary:** The upload transaction begins when the supplier request is received by **Azure APIM** and includes request authentication, payload validation, ZIP file upload to Azure Blob Storage (`IBADirects/in` or `IBADirects/error`), and return of the backend response to the supplier. The successful upload is subsequently processed through the **Blob Created** event, **Azure Event Grid**, and **Azure Service Bus** for downstream translation. Any failure during authentication, validation, or file upload is treated as an upload transaction failure, logged to SMC, and returned to the supplier through the appropriate response. Event Grid and Service Bus processing are asynchronous and form part of the downstream processing flow rather than the synchronous APIM transaction boundary.
  - **Translation Transaction Boundary:** The translation transaction begins when the **Translation Logic App** receives the Azure Service Bus message and includes downloading the source ZIP file, decompression, JSON-to-PSV transformation, generation of the PSV file, upload of the output files to `IBADirects/ToEIM`, archival of the source ZIP file to `IBADirects/archive`, cleanup of temporary resources, completion of the Service Bus message, and logging of the final transaction outcome to SMC. If any processing step fails, the failure is logged to SMC and the Service Bus message is retried or abandoned according to the configured retry policy. If the configured delivery attempts are exhausted, the message is moved to the dead-letter queue for further investigation.

#### 5.1.3.2 State Management

State is maintained through **Azure Blob Storage** and **Azure Service Bus** to support reliable, event-driven asynchronous processing:

- `IBADirects/in` — Stores source ZIP files that have been successfully uploaded and are awaiting translation. A **Blob Created** event is generated when a new file is stored and published to Azure Event Grid.
- **Azure Event Grid** — Receives the Blob Created event for files in `IBADirects/in` and routes the event to the configured Azure Service Bus queue, enabling event-driven downstream processing.
- **Azure Service Bus (**`b2b.ibadirectstoeim.sbq-{env}`**)** — Maintains the translation processing state by queuing incoming processing requests. It provides reliable message delivery, retry handling, and dead-lettering until the Translation Logic App successfully processes the message.
- `IBADirects/ToEIM` — Stores the generated PSV file awaiting pickup by GoAnywhere MFT/EIM.
- `IBADirects/archive` — Stores source ZIP files that have been successfully translated and processed, providing a temporary archive for operational tracking and audit purposes.
- `IBADirects/error` — Stores source ZIP files that fail upload validation or processing-related validation, such as files exceeding the configured maximum size, allowing them to be retained for troubleshooting and audit purposes.

### 5.1.4 GoAnywhere Requirements

*NA*

### 5.1.5 Design Considerations

1. **Authentication Redesign (Known Issue Addressed):** The legacy static token mechanism, where tokens were loaded from a file at application startup, cached in memory, and required a service restart for updates, is replaced with **Azure APIM-based bearer token authentication**. Suppliers continue to use the `Authorization: Bearer {token}` header, maintaining the existing API authentication contract while removing the dependency on locally maintained static token files.



====================================================================================================
## DOC: TSD-EAII-333
====================================================================================================

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The legacy implementation runs on TIBCO BW6. The entry point is `RequestPayment.bwp` which exposes a SOAP endpoint (`/PaymentRequestService`) on port 7505. It receives payment capture requests from Storeline, generates a transaction ID, logs the start event, then calls the `InvokeHybrisPaymentService.bwp` subprocess which performs the REST POST to SAP Commerce Cloud's Braintree payment capture API. The JSON response is parsed, the response code is evaluated, and the result is returned synchronously as a SOAP response.

Key artifacts:

- `RequestPayment.bwp` - Main entry point (SOAP service)
- `InvokeHybrisPaymentService.bwp` - Active subprocess (REST call to SAP Commerce Cloud)
- `InvokeHybrisPaymentRequestService.bwp` - Legacy subprocess (inactive SOAP-to-SOAP, not migrated)
- `HybrisPaymentRequestWSDL.wsdl` - Inbound SOAP contract
- `interface.PaymentRequestService-PaymentRequest.xsd` - Intermediate JSON/XML schema
- `HybrisPaymentServiceParameterSchema.xsd` - REST URL parameters schema

### 5.1.2 Proposed Process(es)

#### 5.1.2.1 Description of Process(es)

**Process Steps:**

1. Storeline sends the SOAP payment capture request to the APIM endpoint using the APIM internal URL, as it does not support OAuth authentication.
2. APIM `inbound` policy extracts fields from SOAP XML body using XPath (customerId, orderId, paymentAmount, requestTimeout)
3. APIM generates a unique transaction ID (`Guid.NewGuid()`)
4. APIM converts `paymentAmount` from scientific notation to decimal (e.g., `2.9674E4` → `29674`)
5. APIM rewrites the URL to: `/occ/v2/campbellsretailersspa/orders/{orderId}/braintree/paymentcapture?captureAmount={captureAmount}`
6. APIM sends HTTP POST with empty body to SAP Commerce Cloud backend (mutual TLS)
7. APIM `outbound` policy parses JSON response
8. APIM evaluates `responseCode`:

- If `responseCode = 1` (success): Logs "End" event, constructs SOAP response
- If `responseCode = 2` (error): Formats message as `"Error {extendedErrorCode} - {message}"`, logs "Warning" event, constructs SOAP response
- If other `responseCode`: Logs "Warning" event, passes message through as-is, constructs SOAP response

1. APIM `on-error` policy: Logs "Error" event with exception details, returns SOAP fault to caller, similarly logs success.

#### 5.1.2.2 Process Flow Diagram

![image-20260708-093644.png](images/05.png)

#### 5.1.2.3 Sequence Diagram

![image-20260722-080112.png](images/03.png)

#### 5.1.2.4 PlantUML

```
@startuml
title EAII-333 - Campbells Payment Capture - Storeline to Sorted\nProposed AIS Architecture

skinparam backgroundColor #FEFEFE
skinparam sequenceArrowThickness 2
skinparam participantPadding 20
skinparam boxPadding 10

skinparam participant {
  BackgroundColor #E8F4FD
  BorderColor #0066CC
  FontStyle bold
}

skinparam note {
  BackgroundColor #FFFDE7
  BorderColor #FBC02D
}

box "Source (On-Premises)" #F5F5F5
participant "Storeline\n(Warehouse/POS)" as SL
end box

box "Azure Integration Services" #E3F2FD
participant "Azure APIM" as APIM
participant "SMC\n(Monitoring)" as SMC
end box

box "External SaaS" #FFF8E1
participant "SAP Commerce Cloud\n(Sorted / Braintree)" as SCC
end box

== Request Received ==

SL -> APIM : SOAP/HTTPS Request\n(paymentRequest operation)\n- customerId, orderId\n- paymentAmount, requestTimeout
activate APIM

APIM -> APIM : Validate SOAP request\nagainst WSDL schema

alt Validation fails
    APIM --> SL : SOAP Fault\n(Schema validation error)
else Validation passes
end

APIM -> APIM : Parse SOAP XML (XPath)\nExtract fields\nGenerate Transaction ID\nConvert paymentAmount\n(2.9674E4 → 29674)

== Backend Call ==

APIM -> APIM : Construct REST URL:\nPOST /occ/v2/campbellsretailersspa\n/orders/{orderId}/braintree\n/paymentcapture?captureAmount={amount}

APIM -> SCC : HTTP POST\nMutual TLS, Port 443
activate SCC
SCC -> SCC : Process payment capture\nvia Braintree gateway
SCC --> APIM : JSON Response\n{responseCode, extendedErrorCode, message}
deactivate SCC

== Response Evaluation ==

alt responseCode = 1 (Success)
    APIM -> APIM : Build SOAP response\n(pass-through fields)
else responseCode = 2 (Error with code)
    APIM -> APIM : Format message:\n"Error {extendedErrorCode} - {message}"
    APIM -> APIM : Build SOAP response
else responseCode = other (General failure)
    APIM -> APIM : Build SOAP response\n(message as-is)
end

== Response ==

alt responseCode = 1
    APIM -> SMC : Log **Success**
else responseCode != 1
    APIM -> SMC : Log **Failure**
end

APIM --> SL : SOAP/HTTPS Response\n<paymentResponse>\n  responseCode, extendedErrorCode, message\n</paymentResponse>
deactivate APIM

== Error Handling ==

note over APIM, SMC
  **SMC (Custom Monitoring Tool)**
  - APIM posts success or failure after response evaluation
  - Exception alerts on failure
  - Notification: IntegrationSupport@metcash.com
end note

@endum
```

### 5.1.3 Coordination

This integration operates **synchronously**. Storeline sends a SOAP request and blocks until it receives a response. APIM processes the request in a single policy execution pipeline (inbound → backend → outbound) without any asynchronous handoff.

#### 5.1.3.1 Transaction Boundaries

The transaction boundary is a single HTTP request-response cycle:

- Storeline → APIM → SAP Commerce Cloud → APIM → Storeline
- No intermediate state is persisted
- No message queuing or retry at the integration layer
- If any step fails, a SOAP fault is returned immediately to Storeline

#### 5.1.3.2 State Management

N/A - This is a stateless synchronous proxy. No state is maintained between requests.

### 5.1.4 GoAnywhere Requirements

*Leave blank if GoAnywhere is not used in this interface*

### 5.1.5 Design Considerations

1. **APIM-only implementation**: Given the simplicity of this integration (synchronous proxy with field mapping and conditional response formatting), APIM policies alone are sufficient. No Logic Apps or Function Apps are required, reducing operational complexity and cost.
2. **SOAP endpoint compatibility**: APIM will expose the same SOAP endpoint path (`/PaymentRequestService`) and operation (`paymentRequest`) to maintain backward compatibility with Storeline. No changes required on the source system.
3. **Scientific notation handling**: The `paymentAmount` field arrives in scientific notation (e.g., `2.9674E4`). APIM policy will cast this to a decimal value (`29674`) before passing as the `captureAmount` query parameter, matching the legacy TIBCO behaviour.
4. **Mutual TLS**: The client certificate for SAP Commerce Cloud authentication will be stored in Certificate store and referenced by the APIM backend entity configuration.
5. **Error message formatting**: The conditional logic for `responseCode = 2` (format as "Error {extendedErrorCode} - {message}") will be implemented in the outbound policy using C# expressions within a `choose`/`when` block.
6. **Customer ID not forwarded**: The `customerId` is extracted for logging purposes only and is NOT sent to the target system. The `orderId` alone is sufficient for SAP Commerce Cloud to identify the transaction.
7. **requestTimeout not used dynamically**: The `requestTimeout` value from the SOAP request is not used to dynamically control APIM's backend timeout. Timeout is configured statically on the APIM backend entity (aligned with legacy behaviour).



====================================================================================================
## DOC: TSD-EAII-514
====================================================================================================

### 5.1.1 As-is Process(es)

#### 5.1.1.1 Description of Process(es)

The current integration is implemented using **TIBCO BusinessWorks 6 (BW6)**. The service exposes both REST, which share a common business process for pricing retrieval.

### Technical Process

1. **Consumer invokes the service**

The Sorted consumer application (IGA, Campbells, or C-Store) sends a pricing request using either the REST interface.

- **REST Binding (**`RestPricingService.bwp`**)**
  - Accepts a JSON `PriceDataRequest` through an HTTP POST endpoint.
  - Converts the JSON payload into the internal XML request format using an inline XSLT transformation.
  - Invokes the common pricing subprocess.

1. **Common pricing subprocess**

Both service bindings invoke the shared process `QueryPriceData-CX40K6B.bwp`, which performs the core business logic.

1. **Database outage validation**

The subprocess checks the `dbOutageFlag` module property.

- If the flag is enabled, processing terminates immediately and a predefined error response is returned.
- Otherwise, the request proceeds to product processing.

1. **Product processing**

The subprocess iterates through each product contained in the request using a **For Each Group** activity.

For every product, the required stored procedure input parameters are prepared using TIBCO XSLT extension functions, including:

- `tib:trim`
- `tib:right`
- `tib:pad-front`

These functions perform field formatting such as trimming, substring extraction, and left-padding to satisfy the AS/400 stored procedure requirements.

1. **Stored procedure execution**

For each product, the process executes the **CX40K6B** stored procedure on the IBM AS/400 through a JDBC connection.

Each product is processed sequentially, with the next stored procedure call beginning only after the previous call completes.

1. **Response construction**

The stored procedure responses are accumulated and transformed into the `PriceDataResponsev2` XML schema using an **End** activity with an inline XSLT transformation.

1. **Logging**

The implementation includes two logging mechanisms:

- **CommonLogging.invokeLogEvent (CLE)**
  - Records start, completion, and error events.
  - Logging is controlled through the `CLELogOn` configuration flag.

- **CommonInterfaceLib.LogtoTransactionHistory**
  - Records transaction history for auditing and operational tracking.

Although CLE logging is implemented, it is currently disabled in the production environment due to performance considerations.

**Known Issues with the Current Implementation**

| Known Issue | Description |
| --- | --- |
| Sequential stored procedure execution | Products are processed one at a time. With up to 20 products per request, response time increases linearly with the number of products, resulting in approximately **30–60 ms per product** and an overall processing time of approximately **600 ms to 1.2 seconds** for a full request. |
| Static database outage configuration | The `dbOutageFlag` is maintained as a static module property. Planned maintenance requires manual configuration changes, and no automated database health-check mechanism is available. |
| Production logging disabled | Due to the high transaction volume (approximately **10,784 calls per hour**), CLE logging has been disabled in production to minimize performance impact. As a result, detailed operational logging and end-to-end observability are limited, while only transaction history continues to be recorded. |

#### 5.1.1.2 Process Flow Diagram

![image-20260628-234851.png](images/04.png)

#### 5.1.2 Proposed Process(es)

***Note:** This section may be revised as the project progresses, at this stage,*For the initial phase, **only the specified REST endpoint is in scope**:

- **Protocol:** HTTPS
- **Method:** POST
- **Endpoint:** `/eis/pricing/v1/getrealtimeprice`
- **Request:** `application/json`
- **Response:** `application/json`

#### 5.1.2.1 Description of Process(es)

**Proposed Azure Integration Services (AIS) Implementation**

The proposed AIS solution re-implements **EAII-514** using Azure Integration Services (AIS) components and the following processing flow.

1. **Consumer invokes the APIM endpoint**

The Sorted consumer application (IGA, Campbells, or C-Store) sends an HTTPS POST request to Azure API Management (APIM).

`POST /eis/pricing/v1/getrealtimeprice` with `Content-Type: application/json`

1. **APIM validates and routes the request**

Azure API Management (APIM) performs the following gateway validations before forwarding the request to the Logic App:

- Authenticates the request using OAuth 2.0.
- Validates the request payload against the REST JSON schema.
- Validates business rules to ensure:
  - Company equals **MTT**
  - Pillar is one of **IGA, ALM, CCC, or CSD**
  - PriceDate follows the **YYYY-MM-DD** format
  - A maximum of **20 products** is included in a single request.

- Checks the **dbOutageFlag** configuration.

If any validation fails, APIM immediately returns:

- **HTTP 400** for validation failures.
- **HTTP 401** for authentication failures.
- **HTTP 503** when the database outage flag is enabled.

Requests that fail validation or maintenance checks are not forwarded to the Logic App.

Upon successful validation, APIM forwards the request to the Azure Logic App Standard workflow over an internal HTTPS endpoint.

1. **Logic App receives the request**

The Logic App is triggered through an HTTP endpoint.

- REST requests are processed using the JSON payload received from APIM.

1. **Transaction start logging**

When enabled through the SMC logging configuration flag, the Logic App records a structured start event containing:

- Transaction ID
- Service name
- Company
- Pillar
- Department
- WarehouseId
- CustomerId
- PriceDate
- Product count

1. **Product processing**

The Logic App iterates through each product contained in the **Product[]** collection using a **For Each** loop configured with **Concurrency = 1**, ensuring products are processed sequentially.

1. **Field transformation**

The map action transforms request fields into the format required by the AS/400 stored procedure.

| AS/400 Field | Transformation |
| --- | --- |
| XPCMPN | Trim Company and left-pad to 3 characters |
| XPDIVN | Trim Pillar and left-pad to 3 characters |
| XPDPTN | Trim Department and left-pad to 3 characters |
| XPWHSN | Left-pad WarehouseId to 3 characters |
| XPCUSN | Take the rightmost 8 char of CustomerId, trim, and left-pad with zeros to 10 characters |
| XPITMN | Trim Product, convert to Long, convert back to String, and left-pad with zeros to 10 char |
| XPDTES | Convert `YYYY-MM-DD` to numeric `YYYYMMDD` |
| XPSFLG | Constant value `"0"` |

1. **Stored procedure execution**

For each product, the Logic App invokes the AS/400 stored procedure:

`CALL IDSPNDUR1.CX40K6B`

using the IBM AS/400 JDBC driver (`com.ibm.as400.access.AS400JDBCDriver`) with a 30-second query timeout.

The Logic App processes products using a **For Each** loop with the following behavior:

- **First Product:** Processed sequentially to verify the database/JDBC connection before initiating parallel processing. If a connectivity failure occurs, it is treated as a **circuit-breaker condition**, and an appropriate response is returned without proceeding with parallel processing.
- **Remaining Products:** Processed in parallel after the initial database/JDBC connection is successfully verified.
- **Retry Handling:** Transient JDBC/database connectivity failures and timeout errors are retried according to the configured retry policy. If the retry attempts are exhausted without success, the error is propagated to the Logic App for centralized error handling.
- **Stored Procedure Errors:** If the stored procedure returns `XOERROR = "Y"`, the corresponding `XOEMSG` is returned for that product, while processing continues for the remaining products.
- **Exception Handling:** Non-retryable JDBC exceptions, or errors that persist after the configured retry attempts, are propagated to the Logic App for centralized error handling.

**10. Result aggregation**

The Logic App aggregates all product responses into the `PriceData[]` collection.

- Responses from parallel processing are aggregated to accurately identify successful, failed scenario’s.

Any output fields returned as `xsi:nil` by the stored procedure are omitted from the final response.

**11. Response construction**

The aggregated stored procedure output is mapped to the `PriceDataResponsev2` response model.

The following request fields are echoed in the response:

- Company
- Pillar
- Department
- WarehouseId
- CustomerId
- PriceDate

Each product includes:

- Product
- ProductPrice (`XOTTLP`)
- Allowance (`XOTAWP`)
- UnitProductPrice (`XOLUCA`)
- ErrorMsg (`XOEMSG`, when `XOERROR = "Y"`)
- OriginalProductPrice (`XZPRCG`)
- OriginalUnitProductPrice (`XZLUCA`)
- RRPorSRP (`XOPRCE`)
- RetailMarginPercent (`XOPRFP`)
- CartonExcludingGST (`XZPGST`)
- SingleUnitPriceExcGST (`XZPEXG`)

The following schema fields are defined but are not populated by the stored procedure:

- PromotionalWholesaleCost
- WholesaleCost
- UnitPromotionalSale

**12. Transaction completion logging**

On completion, the Logic App records a structured end event to SMC when SMC logging is enabled.

- Transaction UUID
- Processing duration
- Product count
- Overall processing status (Success or Failure)

**13. Response returned to the consumer**

The Logic App returns:

- `PriceDataResponsev2` serialized as JSON for REST consumers,

with an **HTTP 200** status code.

**14. Centralized error handling**

Any unhandled exception is processed by the Logic App error handler, which:

- Logs exception details to SMC
- Records the failed transaction in SMC when SMC logging is enabled.
- Returns either:
  - **HTTP 500**

to the consumer.

**Resolution of Known Issues**

| Known Issue | Proposed Solution |
| --- | --- |
| Sequential product processing increases response time | Configure the Logic App **For Each** loop for parallel execution with a concurrency limit, subject to confirmation that concurrent execution of the AS/400 stored procedure. |
| Logging disabled in the current implementation | Enable comprehensive transaction logging by recording request start, completion, and error events in SMC based on configuration |

#### 5.1.2.2 Process Flow Diagram

![EAII-514-updated-1-Process Flow Design.drawio (1)-20260721-070842.png](images/09.png)

#### 5.1.2.3 Sequence Diagram

![image-20260724-062848.png](images/01.png)

#### 5.1.2.4 PlantUML

```
@startuml EAII-514 Realtime Pricing Sequence

title EAII-514 — Realtime Pricing — Sorted to PE\nProposed AIS Sequence

actor "Sorted Consumer\n(IGA/Campbells/C-Store)" as Consumer
participant "Azure APIM" as APIM
participant "Logic App\nt3-met-b2b-realtimepricing-{env}-ae-logic" as LA
participant "Inline Function" as FA
database "IBM AS/400 PE" as AS400
participant "SMC" as SMC

Consumer -> APIM : HTTPS POST PriceDataRequest\n(REST JSON)

group APIM Validation

note over APIM
- OAuth 2.0 Authentication
- Schema Validation
- Business Validation
  • Company = MTT
  • Pillar enumeration
  • Date format
  • Maximum 20 products
- Check dbOutageFlag
end note

APIM -> APIM : Authenticate Request
APIM -> APIM : Validate Schema
APIM -> APIM : Validate Business Rules
APIM -> APIM : Check dbOutageFlag

alt Authentication / Validation Failed

    alt smcLoggingEnabled = true
        APIM -> SMC : Log validation/authentication failure
    end

    APIM --> Consumer : HTTP 400 / 401\nSOAP Fault

else dbOutageFlag = true

    alt smcLoggingEnabled = true
        APIM -> SMC : Log maintenance outage
    end

    APIM --> Consumer : HTTP 503\nSOAP Fault\nService unavailable

else Request Accepted

    APIM -> LA : Forward validated request

    alt smcLoggingEnabled = true
        LA -> SMC : Log START\n(UUID,\nTransactionId,\nConsumer,\nTimestamp)
    end

    loop For each Product (up to 20)\n[Parallel if supported]

        LA -> FA : Invoke Transform\n(Current Product)

        FA -> FA : Transform request\nfields to AS/400 format\n(XPCUSN, XPITMN,\nXPDTES, XPCMPN,\nXPDIVN, XPDPTN,\nXPWHSN)

        LA -> AS400 : JDBC CALL\nIDSPNDUR1.CX40K6B

        AS400 --> LA : Stored Procedure Result

        alt XOERROR = "Y"

            LA -> LA : Build Product Error Result

        else Pricing Returned

            LA -> LA : Map Pricing Response

        end

    end

    LA -> LA : Aggregate Product Results
    LA -> LA : Build PriceDataResponsev2
    LA -> LA : Remove Nil Fields

    alt smcLoggingEnabled = true
        LA -> SMC : Log END\n(Duration,\nStatus=Success)
    end

    LA --> APIM : PriceDataResponse

    APIM --> Consumer : HTTP 200 OK\nPriceDataResponse

end

group Unhandled Exception

    alt smcLoggingEnabled = true
        LA -> SMC : Log ERROR\n(Exception,\nStack Trace,\nTransactionId)
    end

    LA --> APIM : HTTP 500 / SOAP Fault

    APIM --> Consumer : HTTP 500 / SOAP Fault

end

note over APIM
APIM Responsibilities
• OAuth Authentication
• Schema Validation
• Business Validation
• Maintenance (dbOutageFlag)
• Request Routing
end note

note over LA
Logic App Responsibilities
• Orchestrate Processing
• Transform Request
• Invoke AS/400 Stored Procedure
• Aggregate Product Responses
• Build Final Response
• Optional SMC Logging
end note

@enduml
```

#### 5.1.2 Proposed Process(es)

***Note:** This section may be revised as the project progresses, at this stage,*For the initial phase, **only the specified REST endpoint is in scope**:

- **Protocol:** HTTPS
- **Method:** POST
- **Endpoint:** `/eis/pricing/v1/getrealtimeprice`
- **Request:** `application/json`
- **Response:** `application/json`

### 5.1.3 Coordination

This integration operates **synchronously**. The Sorted consumer sends a request and blocks waiting for the pricing response. The Logic App executes the full per-product SP iteration within the lifetime of the synchronous HTTP call.

#### 5.1.3.1 Transaction Boundaries

- **Transaction unit:** A single `PriceDataRequest` call (containing 1–20 products) constitutes one transaction.
- **Atomicity:** The request is not atomic at the product level. A product-level SP error (XOERROR = "Y") is reported in the response without aborting the remaining products. A hard JDBC failure during any product call causes the entire request to fail (HTTP 500).
- **Timeout:** The Logic App HTTP trigger has a maximum run duration. Individual SP calls have a 30-second JDBC timeout. For 20 products with sequential calls, the theoretical maximum processing time is 20 × 30s = 600s.

#### 5.1.3.2 State Management

- **Stateless per request:** No state is persisted within the integration layer between calls.
- **In-flight state:** The Logic App maintains the accumulated `PriceData[]` array in memory during execution of the for-each loop.

### 5.1.4 GoAnywhere Requirements

*NA*

### 5.1.5 Design Considerations

1. **Response v2 Schema** — The current response contract is `PriceDataResponsev2`, which includes additional fields (RRPorSRP, RetailMarginPercent, CartonExcludingGST, SingleUnitPriceExcGST) not in the original v1 schema. The AIS implementation targets v2 as the current contract.
2. **DB Outage Flag Management** — The flag is migrated from a TIBCO module property to an **APIM Named Value** (`dbOutageFlag`).
3. **Performance at Scale** — The target capacity is 20,000 calls/hour (1,000/min). Logic Apps Standard supports horizontal scaling.
