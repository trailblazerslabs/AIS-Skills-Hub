

====================================================================================================
## DOC: TSD-EAII-284_283_282_385
====================================================================================================

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![Architecture Diagram-20260723-110730.png](images/04.png)

The table below lists all Azure resources per environment, following the naming convention `{company-prefix}-{workload}-{environment}-{region}-{resource-type}`.

### 6.1.1 Azure Resource Inventory

| Resource Type | DV1 | ST1 | UT1 | PRD | Resource Group | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| Function App | `t3-met-metproducts-dv1-ae-func` | `t3-met-metproducts-st1-ae-func` | `t3-met-metproducts-ut1-ae-func` | `t3-met-metproducts-prd-ae-func` | `t3-met-ais-{env}-ae1-rsg-data` | Hosts all 4 interface functions |
| App Service Plan | `t3-data-dv1-ae-asp01` | `t3-data-st1-ae-asp01` | `t3-data-ut1-ae-asp01` | `t3-data-prd-ae-asp01` | `t3-met-ais-{env}-ae1-rsg-data` | Confirm Consumption vs EP1 with DevOps |
| Application Insights | `t3-met-metproducts-dv1-ae-func-ai` | `t3-met-metproducts-st1-ae-func-ai` | `t3-met-metproducts-ut1-ae-func-ai` | `t3-met-metproducts-prd-ae-func-ai` | `t3-met-ais-{env}-ae1-rsg-data` | Linked to Log Analytics workspace |
| Log Analytics Workspace | Existing shared per env | Existing shared per env | Existing shared per env | Existing shared per env | — | Existing |
| Service Bus Namespace | `t1-met-npr-ae-sb-001` (shared) | `t1-met-npr-ae-sb-001` (shared) | `t1-met-npr-ae-sb-001` (shared) | `t1-met-prd-ae-sb-001` | `t1-met-core-npr-ae1-rsg-sbus`/ `t1-met-core-prd-ae1-rsg-sbus` | Non-prod namespace shared across DV1/ST1/UT1; lives in a **different subscription** (`COREIT-SERVICES-HUB-NPR` for non-prod) than every other resource in this table (`COREIT-SERVICES-AIS-{env}`) |
| **Service Bus Topic** | `data.metproducts.dv1.sbt` | `data.metproducts.st1.sbt` | `data.metproducts.ut1.sbt` | `data.metproducts.prd.sbt` | Inside namespace | **One shared topic** — all 4 interfaces (EAII-282/283/284/385) |
| SB Subscription | `tosorted.corporateitem` | same | same | same | On the shared topic | EAII-283 trigger |
| SB Subscription | `toindipim.corporateitem` | same | same | same | On the shared topic | EAII-284 trigger |
| SB Subscription | `tometproms.corporateitem` | same | same | same | On the shared topic | EAII-385 trigger |
| SB Subscription | `tosorted.supplieritem` | same | same | same | On the shared topic | EAII-282 trigger |
| Storage Account | `t3datadv1aesta01` *(existing)* | `t3datast1aesta01` | `t3dataut1aesta01` | `t3dataprdaesta01` | `t3-met-ais-{env}-ae1-rsg-data` | Container `stibo`, paths `frompim/corporateitem/`, `frompim/supplieritem/` |
| Event Grid System Topic | `metproducts` on `t3datadv1aesta01` | same, on ST1 storage | same, on UT1 storage | same, on PRD storage | Inside storage account RG | Raises `BlobCreated` events |
| Key Vault (AIS-owned) | `t3datadv1ae1kv01` | `t3datast1ae1kv01` | `t3dataut1ae1kv01` | `t3dataprdae1kv01` | `t3-met-ais-{env}-ae1-rsg-data` | Stores interface credentials (§6.3.2) |
| Key Vault (SMC-owned) | `t3enablingdv1ae1kv01` | `t3enablingst1ae1kv01` | `t3enablingut1ae1kv01` | `t3enablingprdae1kv01` | `t3-met-ais-{env}-ae1-rsg-smc` | Existing; SMC team manages; SAMI granted Secrets User |
| APIM (SMC gateway) | `t3-met-core-dev-ae1-apim` | `t3-met-core-sit-ae1-apim` | `t3-met-core-uat-ae1-apim` | `t3-met-core-prd-ae1-apim` | Shared / existing | SMC `StartObservation` gateway only |

---

## 6.2 Network Connectivity

![Network Diagram-20260723-110747.png](images/05.png)

All intra-Azure communication uses private endpoints where available. Public internet egress is limited to external API calls (Sorted, IndiPIM, MetProms). All AIS integration-tier resources sit in the **EdSense (SENS)** application subnet; private endpoints for backend services sit in the **HeadSense (HSENS)** subnet.

### 6.2.1 VNet and Subnet Reference

**AIS Spoke Virtual Network Details**

| Environment | VNet | VNet Address Space | SENS (Application Subnet) | HSENS (Private Endpoint Subnet) |
| --- | --- | --- | --- | --- |
| DV1 | `t2-met-ais-dv1-ae1-net-01` | 10.247.80.0/21 | 10.247.86.0/24 | 10.247.80.0/23 |
| ST1 | `t2-met-ais-st1-ae1-net-01` | 10.247.88.0/21 | 10.247.92.0/24 | 10.247.88.0/23 |
| UT1 | `t2-met-ais-ut1-ae1-net-01` | 10.247.96.0/21 | 10.247.98.0/24 | 10.247.100.0/23 |
| PRD | `t2-met-ais-prd-ae1-net-01` | 10.249.32.0/21 | 10.249.38.0/23 | 10.249.32.0/23 |

### 6.2.2 Component Network Table

| Component | Resource Name (DV1) | Resource Type | VNet | Subnet / Classification | Private Endpoint | Public Access |
| --- | --- | --- | --- | --- | --- | --- |
| Function App | `t3-met-metproducts-dv1-ae-func` | `Microsoft.Web/sites` | `t2-met-ais-dv1-ae1-net-01` | SENS — VNet Integration | N/A (outbound VNet Integration) | Disabled — Service Bus pull trigger only, no inbound HTTP surface |
| Service Bus Namespace | `t1-met-npr-ae-sb-001` | `Microsoft.ServiceBus/namespaces` | Hub VNet (shared) | HSENS — private endpoint | Yes | Disabled (firewall: VNet rules only) |
| Storage Account | `t3datadv1aesta01` | `Microsoft.Storage/storageAccounts` | `t2-met-ais-dv1-ae1-net-01` | HSENS — private endpoint | Yes — Blob private endpoint | Disabled — deny public access |
| Key Vault (AIS) | `t3datadv1ae1kv01` | `Microsoft.KeyVault/vaults` | `t2-met-ais-dv1-ae1-net-01` | HSENS — private endpoint | Yes | Disabled |
| Key Vault (SMC) | `t3enablingdv1ae1kv01` | `Microsoft.KeyVault/vaults` | Hub VNet (shared) | HSENS | Yes | Disabled |
| APIM (SMC) | `t3-met-core-dev-ae1-apim` | `Microsoft.ApiManagement/service` | Hub VNet (shared) | SENS (internal mode) | N/A | Internal VNet only |
| Event Grid System Topic | `metproducts`, on `t3datadv1aesta01` | `Microsoft.EventGrid/systemTopics` | N/A (platform-managed) | N/A | N/A | Platform-managed |
| IndiPIM | External (AWS API Gateway) | External | Internet egress | N/A | N/A | HTTPS/TLS — OAuth 2.0 |
| Sorted Marketplace | External | External | Internet egress | N/A | N/A | HTTPS — mTLS client certificate |
| MetProms (Retail Express) | External (`retailexp.com`) | External | Internet egress | N/A | N/A | HTTPS/TLS — OAuth 2.0; IP whitelisting required |

---

## 6.3 Security

- Function App uses **Managed Identity** (SAMI) to communicate with Azure Storage accounts, Azure Service Bus, and Azure Key Vaults — no connection strings or access keys.
- Public access to storage accounts is **denied**; access is restricted to specific virtual networks.
- Azure Key Vault stores all secrets and credentials — no secrets in application configuration or source code.
- Access to all Azure services/resources is controlled via **RBAC**, least-privilege.
- All communication between endpoints uses **HTTPS** (TLS 1.2+).
- The Function App's Service Bus trigger is a **pull** mechanism — there is no publicly reachable inbound HTTP endpoint for any of the four interfaces (unlike EAII-514, which is exposed via APIM as a synchronous API). APIM is used in this design only as the SMC gateway for outbound `StartObservation` calls.

### 6.3.1 Component Connection Authentication

| Connection | Source | Target | Authentication Method | Key Vault Secret | KV Instance |
| --- | --- | --- | --- | --- | --- |
| STIBO → GoAnywhere | STIBO | GoAnywhere MFT | SFTP key-based authentication | N/A (GoAnywhere-managed) | N/A |
| GoAnywhere → Blob Storage | GoAnywhere | Azure Blob Storage | Azure Access Key (HTTPS) — target state; GoAnywhere upgrade in progress | N/A | N/A |
| Blob Storage → Event Grid | Azure Blob Storage | Event Grid System Topic `metproducts` | System Topic (implicit; Azure-managed) | N/A | N/A |
| Event Grid → Service Bus | Event Grid | Service Bus Topic | Managed Identity (Event Grid → Service Bus Data Sender) | N/A | N/A |
| Service Bus → Function App | Service Bus Subscription | Function App **(pull trigger — Function polls)** | Managed Identity SAMI (Azure Service Bus Data Receiver) | N/A | N/A |
| Function App → Blob Storage | Function App | Azure Blob Storage | Managed Identity SAMI (Storage Blob Data Reader) | N/A | N/A |
| Function App → AIS Key Vault | Function App | `t3datadv1ae1kv01` etc. | Managed Identity SAMI (Key Vault Secrets User) | N/A | AIS KV |
| Function App → SMC Key Vault | Function App | `t3enablingdv1ae1kv01` etc. | Managed Identity SAMI (Key Vault Secrets User) — **SMC team to grant** | N/A | SMC KV |
| Function App → SMC (APIM) | Function App | `t3-met-core-{env}-ae1-apim` | HTTPS + APIM Subscription Key | `SMC-API-Subscription-Key` | SMC KV |
| Function App → IndiPIM (EAII-284) | Function App | IndiPIM (AWS API Gateway) | OAuth 2.0 Bearer Token (Auth0 client credentials) | `IndiPIMClientId`, `IndiPIMClientSecret` | AIS KV |
| Function App → Sorted (EAII-282, EAII-283) | Function App | Sorted Marketplace REST API | Mutual TLS (mTLS) — X.509 client certificate | `SortedCertificateThumbprint` | AIS KV |
| Function App → MetProms (EAII-385) | Function App | Retail Express (MetProms) REST API | OAuth 2.0 Client Credentials | `MetPromsClientId`, `MetPromsClientSecret` | AIS KV |
| Function App → Application Insights | Function App | `t3-met-metproducts-{env}-ae-func-ai` | Instrumentation key / connection string (appsettings) | N/A | N/A |

### 6.3.2 Key Vault Secrets Inventory

| Secret Name | Key Vault | Environments | Consuming Interface | Description |
| --- | --- | --- | --- | --- |
| `SMC-API-Subscription-Key` | SMC KV | ALL | All (EAII-282/283/284/385) | APIM subscription key for SMC `StartObservation` API |
| `SortedCertificateThumbprint` | AIS KV | ALL | EAII-282, EAII-283 | mTLS client certificate thumbprint for Sorted Marketplace API — **not yet provisioned (§5.2.5, §5.3.5)** |
| `IndiPIMClientId` | AIS KV | ALL | EAII-284 | Auth0 OAuth 2.0 client ID for IndiPIM |
| `IndiPIMClientSecret` | AIS KV | ALL | EAII-284 | Auth0 OAuth 2.0 client secret for IndiPIM |
| `MetPromsClientId` | AIS KV | ALL | EAII-385 | OAuth 2.0 client ID for Retail Express (MetProms) |
| `MetPromsClientSecret` | AIS KV | ALL | EAII-385 | OAuth 2.0 client secret for Retail Express — **value TBD; awaiting Retail Express team (§5.4.5)** |
| `MetPromsScope` | AIS KV | ALL | EAII-385 | OAuth 2.0 scope for Retail Express — **value TBD; awaiting Retail Express team (§5.4.5)** |

### 6.3.3 Identity Inventory — Managed Identity RBAC Assignments

The Function App uses a System-Assigned Managed Identity (SAMI). All assignments are least-privilege.

| Managed Identity | Target Resource | RBAC Role | Scope | Assigned By |
| --- | --- | --- | --- | --- |
| `t3-met-metproducts-{env}-ae-func` SAMI | Service Bus Namespace (`t1-met-{ns}-ae-sb-001`) | **Azure Service Bus Data Receiver** | Namespace scope | DevOps |
| `t3-met-metproducts-{env}-ae-func` SAMI | Storage Account (per env) | **Storage Blob Data Reader** | Storage account scope | DevOps |
| `t3-met-metproducts-{env}-ae-func` SAMI | AIS Key Vault | **Key Vault Secrets User** | Key Vault scope | DevOps |
| `t3-met-metproducts-{env}-ae-func` SAMI | SMC Key Vault | **Key Vault Secrets User** | Key Vault scope | **SMC team to grant — pending** |
| Event Grid System Topic (`metproducts`) | Service Bus Topic `data.metproducts.{env}.sbt` | **Azure Service Bus Data Sender** | Topic scope | DevOps |

### 6.3.4 External Dependency Ownership and SLA

| Service / Component | Provider | Responsibility |
| --- | --- | --- |
| IndiPIM REST API | IndiPIM (AWS API Gateway) | Receives corporate item XML; owns availability, uptime, and API contract for EAII-284 |
| Sorted Marketplace REST API | Sorted / internal Metcash platform team | Receives corporate and supplier item JSON via mTLS; owns availability signalling (via EAII-506) |
| MetProms (Retail Express) REST API | Retail Express | Receives `item-attribute-records` JSON; owns 409 conflict-detection logic and base URL/credential provisioning |
| Auth0 (IndiPIM identity provider) | Auth0 / IndiPIM | Issues OAuth 2.0 bearer tokens for EAII-284 |
| Retail Express identity (`id.{test.}retailexp.com`) | Retail Express | Issues OAuth 2.0 tokens for EAII-385 |
| GoAnywhere MFT | Metcash Infrastructure / MFT team | SFTP ingestion from STIBO, blob staging, Event Grid notification configuration |

### 6.3.1a Data Handling and Encryption

| Category | Detail |
| --- | --- |
| Data Classification | Internal — product master data, no customer PII (per FSD §3.1.5/3.2.5/3.3.5/3.4.5 across all four interfaces) |
| Supplier commercial sensitivity | EAII-282 carries supplier pricing/commercial terms — see the correction in §5.3.2.1: pricing values are sent to Sorted (intentional) but must not appear in SMC logs or Application Insights traces |
| In transit | All data encrypted in transit via TLS 1.2+ (HTTPS for all API calls; mTLS for Sorted) |
| At rest | Blob Storage and Key Vault encryption at rest (Azure platform default); SMC persists only stage metadata (`LogMessage` entries), not full payloads, for EAII-282 in particular |
| Logging restriction | Supplier pricing fields must not be logged (EAII-282); no other field-level logging restrictions identified across the four interfaces |
| Retention | Blob retention window of 30 days supports SMC-based reprocessing/replay across all four interfaces (§5.1.7.1 etc.) |

---

## 6.4 Infrastructure Support

NA

## 6.5 Infrastructure Requirements

| Component | Resource Name (pattern) | Non-Prod Specification | Prod Specification | New / Existing |
| --- | --- | --- | --- | --- |
| Function App | `t3-met-metproducts-{env}-ae-func` | Consumption or EP1 — confirm with DevOps | EP1 (Premium — VNet integration, no cold start) | New |
| App Service Plan | `t3-data-{env}-ae-asp01` | Consumption or EP1 — confirm with DevOps | EP1 | New |
| Application Insights | `t3-met-metproducts-{env}-ae-func-ai` | Standard | Standard | New |
| Log Analytics Workspace | Existing shared per env | Existing shared workspace | Existing shared workspace | Existing |
| Service Bus Namespace | `t1-met-npr-ae-sb-001` (non-prod) / `t1-met-prd-ae-sb-001` (prod) | Standard tier | Premium tier (private endpoint) | Existing |
| **Service Bus Topic** | `data.metproducts.{env}.sbt` | Standard — **4 subscriptions on one topic** | Standard — 4 subscriptions on one topic | New |
| Storage Account | `t3datadv1aesta01` (DV1 — confirmed existing) | Standard LRS | Standard GRS | DV1 existing; ST1/UT1/PRD new |
| Blob Container | `stibo` (paths `frompim/corporateitem/`, `frompim/supplieritem/`) | N/A (inside storage account) | N/A | New |
| Key Vault (AIS) | `t3datadv1ae1kv01` / `t3datast1ae1kv01` / `t3dataut1ae1kv01` / `t3dataprdae1kv01` | Standard | Premium (HSM) | New (ST1/UT1/PRD); DV1 verify existing |
| Key Vault (SMC) | `t3enabling{env}ae1kv01` etc. | — | — | Existing (SMC-managed) |
| APIM | `t3-met-core-{env}-ae1-apim` | — | — | Existing (SMC-managed) |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **Azure Function App** | `t3-met-metproducts-{env}-ae-func` | New |
| **Azure Key Vault** | `t3data{env}ae1kv01`<br> <br>**t3enabling{env}ae1kv01** | New<br> Existing |
| **Resource Group** | **t3-met-ais-{env}-ae1-rsg-data** | Existing |
| **Subscription** | **COREIT-SERVICES-AIS-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / SENS** | Existing |
| **Azure Application Insights** | `t3-met-metproducts-{env}-ae-func-ai` | New |

**{env} -** dv1, st1, ut1 and prd

**AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Function App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway, providing Layer 7 load balancing and secure ingress routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**SENS (Function App Application Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Function App** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | `t3-met-metproducts-dv1-ae-func` |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | `t3-met-metproducts-st1-ae-func` |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | `t3-met-metproducts-ut1-ae-func` |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | `t3-met-metproducts-prd-ae-func` |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Logic App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`



====================================================================================================
## DOC: TSD-EAII-289
====================================================================================================

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![image-20260813-083248.png](images/08.png)

## 6.2 Network Connectivity

![image-20260813-083707.png](images/05.png)

| **Connection** | **Source** | **Destination** | **Protocol** | **Port** | **Authentication** |
| --- | --- | --- | --- | --- | --- |
| Inbound | Consumer Apps (internal) | APIM Gateway | REST over HTTPS | 443 | OAuth2 / Subscription Key |
| Outbound | APIM | ATO REST endpoints | REST over HTTP | 80 | ATO API credentials (from Key Vault) |
| Internal | APIM | Key Vault — Data (`t3datadv1ae1kv01`) | HTTPS | 443 | Managed Identity |
| Internal | APIM | Key Vault — Enabling (`t3enablingdevae1kv01`) | HTTPS | 443 | Managed Identity |
| Internal | APIM | Application Insights | HTTPS | 443 | Instrumentation Key |
| Internal | APIM | SMC | HTTPS | 443 | send-request policy |

## 6.3 Security

  - API Management and OAuth2 to be implemented for all APIs for Authentication/Authorisation.
  - APIM will use Managed Identity to access both Key Vaults.
  - Deny public access to Key Vaults and allow access from specific virtual networks.
  - Azure Key Vault — Data (`t3datadv1ae1kv01` in `COREIT-SERVICES-AIS-DV1`) will be used to store ATO REST API authentication credentials.
  - Azure Key Vault — Enabling (`t3enablingdevae1kv01` in `COREIT-SERVICES-AIS-NPR`) will be used to store platform secrets.
  - Control access to all Azure services/resources using RBAC.
  - All communication between internal endpoints will be through HTTPS.

### 6.3.1 Data Handling and Encryption

  - **Data classification**: Public
  - The data returned by the ATO/ABR is publicly available through the official Australian Business Register public search
  - ABN, ACN identifiers and the associated business name, status and address details are not classified as confidential
  - Standard logging and retention apply. No additional masking or encryption requirements above platform defaults
  - All internal data in transit is encrypted via TLS 1.2+

## 6.4 Infrastructure Support

Standard AIS platform infrastructure support applies. No special requirements beyond:

  - Key Vault secret rotation support (ATO API credential renewal)
  - APIM policy and transform template deployment via CI/CD

## 6.5 Infrastructure Requirements

| **Component** | **Non-Prod Specifications** | **Prod Specifications** | **New / Existing** |
| --- | --- | --- | --- |
| Azure API Management | Standard tier (shared instance) | Standard/Premium tier | Existing (shared) |
| Azure Key Vault - Data (`t3datadv1ae1kv01`) | Standard | Standard | Existing |
| Azure Key Vault - Enabling (`t3enablingdevae1kv01`) | Standard | Standard | Existing |
| Azure Application Insights | Standard | Standard | Existing (shared) |
| Azure Log Analytics Workspace | Standard | Standard | Existing (shared) |
| Virtual Network | Standard (existing subnets) | Standard (existing subnets) | Existing |

## 6.6 Infrastructure Resource Details

The following table captures the specific Azure resource names, subscription placement, and network configuration for this integration. `{env}` = `dev` | `sit` | `uat` | `prd`.

| **Resource Name** | **Type** | **Azure Resource Provider** | **Resource Group** | **Subscription** | **VNet** | **Subnet** | **IP Address** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `t1-met-core-{env}-ae1-apg-01` | Application Gateway | `Microsoft.Network/applicationGateways` | `t1-met-core-{env}-ae1-rsg-net` | `COREIT-SERVICES-HUB-{env}` | App GW VNet | App GW Subnet | Public: 20.42.203.106, Private: 10.247.1.71 |
| `t3-met-core-{env}-ae1-apim` | API Management | `Microsoft.ApiManagement/service` | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | APIM VNet | ECCS2 | Public VIP: 4.254.116.233, Private VIP: 10.247.1.4 |
| `t3-met-core-{env}-ae1-appi-apim` | Application Insights | `Microsoft.Insights/components` | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | N/A | N/A | N/A |
| (Log Analytics Workspace) | Log Analytics | `Microsoft.OperationalInsights/workspaces` | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | N/A | N/A | N/A |
| `t3datadv1ae1kv01` | Key Vault (data-specific) | `Microsoft.KeyVault/vaults` | `t3-met-ais-dv1-ae1-rsg-data` | `COREIT-SERVICES-AIS-DV1` | `t2-met-ais-dv1-ae1-net-01` | HSENS (10.247.85.0) | PE: `t3datadv1ae1kv01-pe` |
| `t3datadv1ae1kv01-pe` | Private Endpoint (Data KV) | `Microsoft.Network/privateEndpoints` | `t3-met-ais-dv1-ae1-rsg-data` | `COREIT-SERVICES-AIS-DV1` | `t2-met-ais-dv1-ae1-net-01` | HSENS (10.247.85.0) | N/A |
| `t3enablingdevae1kv01` | Key Vault (enabling) | `Microsoft.KeyVault/vaults` | `t3-met-ais-dev-ae1-rsg-enabling` | `COREIT-SERVICES-AIS-NPR` | `t2-met-ais-dev-ae1-net-01` | HSENS (10.247.85.0) | PE: `t3enablingdevae1kv01-pe` |
| `t3enablingdevae1kv01-pe` | Private Endpoint (Enabling KV) | `Microsoft.Network/privateEndpoints` | `t3-met-ais-dev-ae1-rsg-enabling` | `COREIT-SERVICES-AIS-NPR` | `t2-met-ais-dev-ae1-net-01` | HSENS (10.247.85.0) | N/A |
| APIM System-Assigned MI | Managed Identity | `Microsoft.ManagedIdentity` (system-assigned) | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | N/A | N/A | N/A |
| (RBAC Role Assignments) | Role Assignment | `Microsoft.Authorization/roleAssignments` | (both KV resource groups) | (both AIS subscriptions) | N/A | N/A | N/A |
| SMC | Service Management Console | N/A (External SaaS) | N/A (External) | N/A | N/A | N/A | N/A |

**Notes:**

  - **APIM Gateway URL**: `https://cloud-api-{env}-internal.metcash.com`
  - **Managed Identity**: APIM uses a **system-assigned managed identity** to authenticate to both Key Vaults. The identity is granted `Key Vault Secrets User` RBAC role on both `t3datadv1ae1kv01` and `t3enablingdevae1kv01`.
  - **Key Vault (Data)**: `t3datadv1ae1kv01` in `COREIT-SERVICES-AIS-DV1` / `t3-met-ais-dv1-ae1-rsg-data` — stores ATO API credentials.
  - **Key Vault (Enabling)**: `t3enablingdevae1kv01` in `COREIT-SERVICES-AIS-NPR` / `t3-met-ais-dev-ae1-rsg-enabling` — stores platform secrets.
  - **Log Analytics Workspace** is linked to Application Insights for log query and retention.
  - **Private Endpoints**: Both Key Vaults are accessed via private endpoints within their respective HSENS subnets.
  - APIM interacts with SMC via `send-request` policy actions for success and failure audit logging.

### **6.6.1 Azure API Management Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure API Management | Microsoft.ApiManagement/service | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | Microsoft.ApiManagement/service | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

### **6.6.2 AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**App Gateway:-**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.



====================================================================================================
## DOC: TSD-EAII-297
====================================================================================================

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![EAII-297-Architecture Diagram.drawio (2)-20260727-034142.png](images/05.png)

## 6.2 Network Connectivity

![EAII-297-Network Diagram.drawio (2)-20260727-034225.png](images/06.png)

## 6.3 Security

- API management and OAuth2 to be implemented for all APIs for Authentication/Authorisation.
- Incoming traffic for LogicApps are secured by creating private endpoints.
- LogicApps will be using managed identities to communicate with Azure Key Vaults.
- Azure key vault will be used to store all secrets.
- Control access to all Azure services/resources using RBAC.
- All communication between endpoints will be through https.

**Key Vault Secret**

The solution stores all sensitive configuration and credentials in Azure Key Vault. The Azure Logic App accesses the required secrets using its Managed Identity with the **Key Vault Secrets User** role. No secrets are stored in application configuration or source code.

| **Key Vault** | **Purpose** |
| --- | --- |
| **t3data{env}ae1kv01** | Stores integration-specific secrets required by the Supplier Number Management solution, including IBM MDM credentials and other application-specific configuration. |
| **t3enabling{env}ae1kv01** | Shared platform Key Vault managed by the Enabling Platform team, containing shared platform configuration, certificates, and platform-managed secrets where applicable. |

### 6.3.1 Data Handling and Encryption

**Data Classification:** Internal commercially sensitive supplier master data (Agreement ID, Supplier Number, transaction status), but no Personally Identifiable Information (PII).

**In Transit:** All communication is encrypted using **TLS 1.2+**. HTTPS is used for communication between **Salesforce , Azure API Management, Azure Logic Apps, SMC, and Azure Application Insights**. Communication between the Logic App and **IBM MDM** uses **SOAP over HTTPS** secured with **WS-Security UsernameToken** and **Mutual TLS (mTLS)**.

**At Rest:** The integration layer does not persist request or response payloads. Only transaction metadata (for example, Transaction ID, Agreement ID, timestamps, processing status, and error details) is recorded for operational monitoring and auditing.

**Business Identifiers:** **Agreement ID** and **Supplier Number** are treated as internal business identifiers (not PII). These values may be included in operational logs at the metadata level for traceability and auditing but are not logged as part of the complete request or response payload.

## 6.4 Infrastructure Support

*Capture any specific infrastructure support requirements for the solution here.*

## 6.5 Infrastructure Requirements

**Logic App Infrastructure**

| **Resource** | **SKU / Tier** | **Workflow Type** | **Hosting** | **Purpose** |
| --- | --- | --- | --- | --- |
| Azure Logic App | Standard | Stateless | Azure Logic Apps Standard | Hosts the Supplier Number Management workflow responsible for request validation, transaction ID generation, supplier number request/release processing, IBM MDM SOAP service invocation, response transformation, auditing, and exception handling. |
| App Service Plan | Standard | N/A | Dedicated | Provides the compute hosting environment for the Logic App Standard runtime. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **Azure Logic App** | **t3-met-data-suppliercontract-{env}-ae-logic** | New |
| **Azure Key Vault** | **t3data{env}ae1kv01**<br> <br>**t3enabling{env}ae1kv01** | Existing |
| **Resource Group** | **t3-met-ais-{env}-ae1-rsg-b2b** | Existing |
| **Subscription** | **COREIT-SERVICES-AIS-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / SENS** | Existing |
| **Azure Application Insights** | **t3-met-data-suppliercontract-{env}-ae-logic-ai** | New |

**{env} -** dv1, st1, ut1 and prd

**Workflow Details**

| **Workflow** | **Get New Supplier Number** | **Release Reserved Supplier Number** |
| --- | --- | --- |
| **Workflow Name** | `GetNewSupplierNumber` | `ReleaseReservedSupplierNumber` |
| **Workflow Type** | Stateless | Stateless |
| **Runtime** | Azure Logic Apps Standard | Azure Logic Apps Standard |
| **Hosting Model** | Dedicated App Service Plan | Dedicated App Service Plan |
| **Trigger Type** | HTTP Request Trigger | HTTP Request Trigger |
| **Logic App** | Processes supplier number requests by validating the request, invoking the IBM MDM `getNextSupplierNumber` SOAP service and returning the response to Salesforce. | Processes supplier number release requests by validating the request, invoking the IBM MDM `clearReservedSupplierNumbers` SOAP service, and returning the operation status to Salesforce. |
| **Outbound Service** | IBM MDM – `getNextSupplierNumber` | IBM MDM – `clearReservedSupplierNumbers` |
| **Retry Policy** | Maximum 3 retry attempts for transient SOAP service failures | Maximum 3 retry attempts for transient SOAP service failures |
| **Response** | Returns the formatted Supplier Number or a failure response. | Returns the release status or a failure response. |

**Azure API Management Infrastructure**

Azure API Management (APIM) serves as the secure gateway for the **Supplier Number Management API**, exposing the **Get New Supplier Number** and **Release Reserved Supplier Number** REST endpoints to Salesforce MetConnect. APIM is responsible for enforcing OAuth 2.0 Bearer token authentication, executing inbound and outbound policies, routing requests to the appropriate Azure Logic App workflow, handling error responses, and providing centralized monitoring and observability.

| Resource | Azure Resource Provider | SKU | Purpose |
| --- | --- | --- | --- |
| Azure API Management | `Microsoft.ApiManagement/service` | Standard | Exposes the **Supplier Number Management APIs** (**Get New Supplier Number** and **Release Reserved Supplier Number**), performs OAuth 2.0 Bearer token authentication, executes API policies, routes requests to the appropriate Azure Logic App workflow, handles request and response processing, and provides centralized monitoring and observability. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **APIM** | **t3-met-core-{env}-ae-apim** | Existing |
| **Resource Group** | **t3-met-core-{env}-ae1-rsg-apim** | Existing |
| **Subscription** | **COREIT-SERVICES-HUB-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / HSENS** | Existing |
| **Azure Application Insights** | **t3-met-core-{env}-ae-apim-ai** | New |

**API Endpoints**

| **API** | **Endpoint** |
| --- | --- |
| Get supplier data | `/newsupplier/v1` |
| Release supplier data | `/releasesupplier/v1` |

**APIM Policies**

Azure API Management policies are used to implement:

- OAuth 2.0 authentication and authorization
- Request validation
- SOAP-to-JSON and JSON-to-SOAP transformation
- Backend routing to the Azure Logic App
- Error handling and standardized fault responses
- Logging and telemetry integration with Azure Application Insights and SMC

**Virtual Network Architecture**

The **Supplier Number Management** integration is deployed within the enterprise **Hub-and-Spoke** network architecture. Azure API Management is deployed in the **Hub Virtual Network**, while the Azure Logic Apps and supporting integration resources are deployed in the **AIS Spoke Virtual Network**. Secure communication between Azure resources and **IBM MDM** is established over HTTPS using enterprise networking controls, including **Virtual Network Integration, Private Endpoints**and**Network Security Groups (NSGs)** for secure SOAP service communication.

**App Gateway Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure Application Gateway | Microsoft.Network/applicationGateways | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | Microsoft.Network/applicationGateways | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure API Management | Microsoft.ApiManagement | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | Microsoft.ApiManagement | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | Microsoft.ApiManagement | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | Microsoft.ApiManagement | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Logic App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway, providing Layer 7 load balancing and secure ingress routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**SENS (Logic App Application Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Logic Apps** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | **t3-met-data-suppliercontract-dv1-ae-logic** |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | **t3-met-data-suppliercontract-st1-ae-logic** |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | **t3-met-data-suppliercontract-ut1-ae-logic** |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | **t3-met-data-suppliercontract-prd-ae-logic** |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**App Gateway:-**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Managed Identity**

The Azure Logic App uses a System-Assigned Managed Identity. The identity is
 automatically created and managed by Azure, and its lifecycle is tied
 exclusively to the Logic App resource. When the Logic App is deleted, the
 identity is automatically deleted with it.

A User-Assigned Managed Identity (Microsoft.ManagedIdentity/userAssignedIdentities)
 was considered but was not selected for this integration. The System-Assigned
 model is preferred here because:

- The identity is used solely by this Logic App and no other resource.
- There is no requirement to share the same identity across multiple Azure resources.

No credentials, client secrets, or certificates are stored within the
 application. All Azure service authentication is performed at runtime via the
 System-Assigned Managed Identity token.

**Identity and Access Control (RBAC)**

The Logic App authenticates to Azure services using Microsoft Entra ID and its Managed Identity. The following Azure RBAC roles are assigned based on the principle of least privilege.

**Complete RBAC Assignments (**`Microsoft.Authorization/roleAssignments`**):**

| Source | Target | Identity | RBAC Role |
| --- | --- | --- | --- |
| `t3-met-data-suppliercontract-{env}-ae-logic` | `t3data{env}ae1kv01` | System-Assigned Managed Identity | Key Vault Secrets User |
| `t3-met-data-suppliercontract-{env}-ae-logic` | `t3-met-data-suppliercontract-{env}-ae-ai` | System-Assigned Managed Identity | Monitoring Metrics Publisher |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

| Private Endpoint Name | Target Resource | Sub-resource | Private Zone | New / Existing |
| --- | --- | --- | --- | --- |
| `t3-met-data-suppliercontract-{env}-ae-pe-kv` | `t3data{env}ae1kv01` (Azure Key Vault) | `vault` | `privatelink.vaultcore.azure.net`<br> <br>`t3data{env}ae1kv01.vault.azure.net` | Existing |
| `t3-met-data-suppliercontract-{env}-ae-pe-ai` | `t3-met-data-suppliercontract-{env}-ae-logic-ai` (Application Insights) | - | `privatelink.monitor.azure.com` | New |

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Logic App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`



====================================================================================================
## DOC: TSD-EAII-301_302_516_517
====================================================================================================

## 6 Architecture Overview

![Architecture Diagram-20260825-092924.png](images/12.png)

### 6.1 Azure Resource Inventory

| Resource Type | DV1 | ST1 | UT1 | PRD | Resource Group | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| Function App | `t3-met-mdmsupplierinfo-dv1-ae-func` | `t3-met-mdmsupplierinfo-st1-ae-func` | `t3-met-mdmsupplierinfo-ut1-ae-func` | `t3-met-mdmsupplierinfo-prd-ae-func` | `t3-met-ais-{env}-ae1-rsg-data` (same as existing) | Hosts all 3 interface functions |
| App Service Plan | `t3-met-mdmsupplierinfo-dv1-ae-asp` | `t3-met-mdmsupplierinfo-st1-ae-asp` | `t3-met-mdmsupplierinfo-ut1-ae-asp` | `t3-met-mdmsupplierinfo-prd-ae-asp` | `t3-met-ais-{env}-ae1-rsg-data` |  |
| Application Insights | `t3-met-mdmsupplierinfo-dv1-ae-func-ai` | same pattern | same pattern | same pattern | `t3-met-ais-{env}-ae1-rsg-data` | Linked to Log Analytics workspace |
| Log Analytics Workspace | Existing shared per env | Existing shared per env | Existing shared per env | Existing shared per env | — | Existing, reused |
| Service Bus Namespace | `t1-met-npr-ae-sb-001` (shared) | `t1-met-npr-ae-sb-001` (shared) | `t1-met-npr-ae-sb-001` (shared) | `t1-met-prd-ae-sb-001` | Shared / existing | Same namespace as MetProductsV2 — non-prod shared across DV1/ST1/UT1 |
| **Service Bus Topic** | `data.SupplierInfoFromMDM.dv1.sbt` | same pattern | same pattern | same pattern | Inside namespace |  |
| SB Subscription | `toeaim.supplierinfo` | same | same | same | On the shared topic | EAII-301 trigger |
| SB Subscription | `toalmsorted.supplierinfo` | same | same | same | On the shared topic | EAII-517 trigger |
| SB Subscription | `tosorted.supplierinfo` | same | same | same | On the shared topic | EAII-516 trigger |
| Storage Account | `t3datadv1aesta01` (existing) | `t3datast1aesta01` | `t3dataut1aesta01` | `t3dataprdaesta01` | `t3-met-ais-{env}-ae1-rsg-data` | Reused existing account (same as MetProductsV2). Container `eim`, path `toeim/supplierinfo` |
| Key Vault (AIS-owned) | Existing, same as MetProductsV2 (`t3data{env}ae1kv01` pattern) | same pattern | same pattern | same pattern | `t3-met-ais-{env}-ae1-rsg-data` | Stores MDM credentials/cert (§6.3.2) — **no new vault**, existing vault reused |
| Key Vault (Enabling/SMC-owned) | Existing, same as MetProductsV2 (`t3enabling{env}ae1kv01`) | same pattern | same pattern | same pattern | `t3-met-ais-{env}-ae1-rsg-smc` | Existing; SMC team manages; SAMI granted Secrets User — **no new vault** |
| APIM (SMC gateway) | Existing shared instance | same | same | same | Shared / existing | SMC `StartObservation` gateway only |

### 6.2 Network Connectivity

![Network Diagram-20260825-092943.png](images/09.png)

All AIS integration-tier resources sit in the **EdSense (SENS)** application subnet; private endpoints for backend services sit in the **HeadSense (HSENS)** subnet.

### 6.2.1 VNet and Subnet Reference

| Environment | VNet | Address space | SENS | HSENS |
| --- | --- | --- | --- | --- |
| DV1 | `t2-met-ais-dv1-ae1-net-01` | `10.247.80.0/21` | `10.247.86.0/24` | `10.247.80.0/23` |
| ST1 | `t2-met-ais-st1-ae1-net-01` | `10.247.88.0/21` | `10.247.92.0/24` | `10.247.88.0/23` |
| UT1 | `t2-met-ais-ut1-ae1-net-01` | `10.247.96.0/21` | `10.247.98.0/24` | `10.247.100.0/23` |
| PROD | `t2-met-ais-prd-ae1-net-01` | `10.249.32.0/21` | `10.249.38.0/23` | `10.249.32.0/23` |

Integration resources use the SENS application subnet and private endpoints in HSENS. Public access is disabled for Service Bus, Storage, and Key Vault resources.

### 6.2.2 Component Network Table

| Component | Resource Name (DV1) | Resource Type | VNet | Subnet / Classification | Private Endpoint | Public Access |
| --- | --- | --- | --- | --- | --- | --- |
| Function App | `t3-met-mdmsupplierinfo-dv1-ae-func` | `Microsoft.Web/sites` | `t2-met-ais-dv1-ae1-net-01` | SENS — VNet Integration | N/A (outbound VNet Integration) | Disabled — Service Bus pull trigger only, no inbound HTTP surface |
| Service Bus Namespace | `t1-met-npr-ae-sb-001` | `Microsoft.ServiceBus/namespaces` | Hub VNet (shared) | HSENS — private endpoint | Yes | Disabled (firewall: VNet rules only) |
| Storage Account | `t3datadv1aesta01` | `Microsoft.Storage/storageAccounts` | `t2-met-ais-dv1-ae1-net-01` | HSENS — private endpoint | Yes — Blob private endpoint | Disabled — deny public access |
| Key Vault (AIS) | Existing | `Microsoft.KeyVault/vaults` | `t2-met-ais-dv1-ae1-net-01` | HSENS — private endpoint | Yes | Disabled |
| Key Vault (Enabling/SMC) | Existing | `Microsoft.KeyVault/vaults` | Hub VNet (shared) | HSENS | Yes | Disabled |
| APIM (SMC) | Existing shared instance | `Microsoft.ApiManagement/service` | Hub VNet (shared) | SENS (internal mode) | N/A | Internal VNet only |
| MDM REST API | External (`172.18.16.4` ST1/DV1, `172.18.6.1` UT1, `mdm.metcash.com` PRD) | External |  | N/A | N/A | Non-prod hosts are internal IPs (172.18.x.x), implying VNet/private routing required — see §6.2.2 note below |
| ALM Sorted | External (SAP Commerce Cloud) | External | Internet egress | N/A | N/A | HTTPS — auth mechanism open item (§5.2.5) |
| Food Sorted | External (matches existing Sorted Marketplace host pattern) | External | Internet egress | N/A | N/A | HTTPS — auth mechanism open item (§5.3.5) |



====================================================================================================
## DOC: TSD-EAII-304
====================================================================================================

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![EAII-304-Architecture Diagram.drawio (2)-20260806-072449.png](images/05.png)

## 6.2 Network Connectivity

![EAII-304-Network Diagram.drawio (1)-20260806-072559.png](images/04.png)

## 6.3 Security

**Azure API Management (APIM)** enforces **OAuth 2.0 Bearer Token authentication** for all inbound supplier requests. Each request to the IBADirects upload endpoint must include a valid `Authorization: Bearer {token}` header. APIM validates the bearer token before forwarding the request to the backend service.

The **UploadBlob Azure Function** and **Translation Logic App** use **Managed Identities** to authenticate with Azure Storage, Azure Service Bus, Azure Key Vault, and other supported Azure services. No credentials or secrets are stored in application configuration or source code.

The **UploadBlob Azure Function** and **Translation Logic App** are not directly exposed to the public internet. Backend services are accessed through the controlled integration path via **APIM** or **Azure Service Bus**, while Azure resources use **Private Endpoints** where supported to restrict direct public access.

**Azure Key Vault** is used to securely store sensitive configuration and integration credentials, including SMC credentials and other required secrets. Secrets are retrieved at runtime using Managed Identity.

Public network access to the **Azure Storage Account** is disabled. Access is restricted to approved virtual networks and private endpoints in accordance with Metcash security standards.

Access to Azure resources is controlled through **Azure Role-Based Access Control (RBAC)** following the principle of least privilege. Each Managed Identity is granted only the permissions required to perform its respective functions.

All communication between suppliers, Azure services, and downstream components is secured using **HTTPS/TLS 1.2 or later**. Communication between Azure services uses Azure-managed authentication and encrypted transport.

### **Key Vault Secret**

The solution stores all sensitive configuration and credentials in Azure Key Vault. The Azure Logic App accesses the required secrets using its Managed Identity with the **Key Vault Secrets User** role. No secrets are stored in application configuration or source code.

| Key Vault | Purpose |
| --- | --- |
| **t3b2b{env}ae1kv01** | Application Key Vault containing integration-specific secrets required by the IBADirects solution. |
| **t3enabling{env}aekv01** | Shared platform Key Vault managed by the Enabling Platform team, containing shared platform configuration and platform-managed secrets where applicable. |

**6.3.1 Data Handling and Encryption**

**Data Retention:** Source ZIP files are stored in the appropriate Azure Blob Storage paths (`IBADirects/in`, `IBADirects/archive`, or `IBADirects/error`) based on their processing status and are retained in accordance with the defined operational and data retention requirements. Generated PSV file are stored in `IBADirects/ToEIM` until they are picked up by GoAnywhere MFT/EIM.

## 6.4 Infrastructure Support

*NA*

## 6.5 Infrastructure Requirements

**Logic/Function App Infrastructure**

| Resource | Azure Resource Provider | SKU / Tier | Workflow Type | Hosting |
| --- | --- | --- | --- | --- |
| **Azure Logic App** | `Microsoft.Logic/workflows` | Standard | Stateless | Azure Logic Apps Standard (App Service Plan) |
| **Azure Function App** | `Microsoft.Web/sites` | Standard | HTTP Trigger | Azure Functions (App Service Plan) |
| **App Service Plan** | `Microsoft.Web/serverfarms` | Standard | N/A | Dedicated |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **Azure Logic App** | **t3-met-b2b-ibadirects-{env}-ae-logic** | New |
| **Azure Function App** | **t3-met-enabling-blobmgnt-{env}-ae-logic** | Existing |
| **Azure Key Vault** | **t3b2b{env}ae1kv01**<br> <br>**t3enabling{env}ae1kv01** | Existing |
| **Resource Group** | **t3-met-ais-{env}-ae1-rsg-b2b** | Existing |
| **Subscription** | **COREIT-SERVICES-AIS-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / SENS** | Existing |
| **Azure Application Insights** | **t3-met-b2b-ibadirects-{env}-ae-logic-ai** | New |

**{env} -** dv1, st1, ut1 and prd

**Azure API Management Infrastructure**

Azure API Management (APIM) serves as the secure API gateway for the IBA Directs interface, exposing the upload endpoint to liquor suppliers while enforcing authentication, request validation, policy execution, backend routing, error handling, and observability.

**Azure API Management (APIM) Named Values** are used to externalize runtime configuration values required by the API gateway. APIM reads these values during policy execution to control request processing without requiring policy changes or redeployment.

| Resource | Azure Resource Provider | SKU | Purpose |
| --- | --- | --- | --- |
| Azure API Management | `Microsoft.ApiManagement/service` | Standard | Exposes the IBADirects Upload API, performs OAuth 2.0 authentication, request validation, policy execution, backend routing, retry handling, and telemetry logging. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **APIM** | **t3-met-core-{env}-ae-apim**<br> <br>[cloud-api-{env}.metcash.com](https://cloud-api-dev.metcash.com) | Existing |
| **Resource Group** | **t3-met-core-{env}-ae1-rsg-apim** | Existing |
| **Subscription** | **COREIT-SERVICES-HUB-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / HSENS** | Existing |
| **Azure Application Insights** | **t3-met-core-{env}-ae-apim-ai** | New |

**API Endpoints**

|  | **API** |
| --- | --- |
| Upload API | `eis/ibadirects/v1/submitOrder` |

| **Environment** | **URL** |
| --- | --- |
| Dev | [https://cloud-api-dev.metcash.com/eis/ibadirects/v1/submitOrder](https://cloud-api-dev.metcash.com/eis/azureblobmgmt/v1) |
| SIT | [https://cloud-api-sit.metcash.com/](https://cloud-api-sit.metcash.com/eis/azureblobmgmt/v1)[eis/ibadirects/v1/submitOrder](https://cloud-api-dev.metcash.com/eis/azureblobmgmt/v1) |
| UAT | [https://cloud-api-uat.metcash.com/](https://cloud-api-uat.metcash.com/eis/azureblobmgmt/v1)[eis/ibadirects/v1/submitOrder](https://cloud-api-dev.metcash.com/eis/azureblobmgmt/v1) |
| Prod | [https://cloud-api.metcash.com/](https://cloud-api-uat.metcash.com/eis/azureblobmgmt/v1)[eis/ibadirects/v1/submitOrder](https://cloud-api-dev.metcash.com/eis/azureblobmgmt/v1) |

**APIM Policies**

Azure API Management (APIM) policies are used to implement the following controls and processing logic:

- **OAuth 2.0 Bearer Token Authentication and Authorization** — Validates the bearer token provided by the supplier before processing the request.
- **Request Validation** — Validates mandatory request fields, including `SupplierID`, and performs JSON payload/schema validation.
- **Base64 and File Size Validation** — Validates the Base64-encoded payload and ensures that the decoded ZIP file does not exceed the maximum allowed size of **3 MB**.
- **Blob Destination Determination** — Determines the appropriate Azure Blob Storage path based on the validation outcome:
  - Valid files → `IBADirects/in`
  - Files exceeding the size limit → `IBADirects/error`

- **Backend Routing** — Routes valid upload requests to the **UploadBlob Azure Function** for storage in Azure Blob Storage.
- **Retry Handling** — Applies retry policies for transient failures when invoking the UploadBlob Azure Function.
- **Standardized Error Handling** — Provides consistent error responses for authentication, payload validation, file size, and backend processing failures.

**Virtual Network Architecture**

The **IBADirects** integration is deployed within the enterprise **Hub-and-Spoke** network architecture. **Azure API Management (APIM)** is deployed in the **Hub Virtual Network**, while the **Translation Logic App**, **UploadBlob Azure Function**, **Azure Storage Account**, **Azure Event Grid**, **Azure Service Bus**, **Azure Key Vault**, and supporting integration resources are deployed within the **AIS Spoke Virtual Network**.

Secure communication between Azure resources is achieved through **Virtual Network Integration**, **Private Endpoints**, **Network Security Groups (NSGs)**, **Route Tables**, and enterprise networking controls. Public network access is disabled where supported, and Azure services communicate using **Managed Identity**, **Azure RBAC**, and **HTTPS/TLS 1.2 or later**. Event-driven communication between Azure Blob Storage, Azure Event Grid, and Azure Service Bus occurs over Azure-managed secure channels, ensuring reliable and secure asynchronous processing.

**App Gateway Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure Application Gateway | Microsoft.Network/applicationGateways | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | Microsoft.Network/applicationGateways | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure API Management | Microsoft.ApiManagement/service | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | Microsoft.ApiManagement/service | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Logic App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway, providing Layer 7 load balancing and secure ingress routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**SENS (Logic App Application Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Logic Apps** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | **t3-met-ibadirects-dv1-ae-logic** |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | **t3-met-ibadirects-st1-ae-logic** |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | **t3-met-ibadirects-ut1-ae-logic** |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | **t3-met-ibadirects-prd-ae-logic** |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**App Gateway:-**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Managed Identity**

The Azure Logic App uses a System-Assigned Managed Identity. The identity is
 automatically created and managed by Azure, and its lifecycle is tied
 exclusively to the Logic App resource. When the Logic App is deleted, the
 identity is automatically deleted with it.

A User-Assigned Managed Identity (Microsoft.ManagedIdentity/userAssignedIdentities)
 was considered but was not selected for this integration. The System-Assigned
 model is preferred here because:

- The identity is used solely by this Logic App and no other resource.
- There is no requirement to share the same identity across multiple Azure resources.

No credentials, client secrets, or certificates are stored within the
 application. All Azure service authentication is performed at runtime via the
 System-Assigned Managed Identity token.

**Identity and Access Control (RBAC)**

The Logic App authenticates to Azure services using Microsoft Entra ID and its Managed Identity. The following Azure RBAC roles are assigned based on the principle of least privilege.

**Complete RBAC Assignments (**`Microsoft.Authorization/roleAssignments`**):**

| Source | Target | Identity | RBAC Role |
| --- | --- | --- | --- |
| **t3-met-b2b-ibadirects-{env}-ae-logic** | **t3enabling{env}aekv01** | System-Assigned Managed Identity | Key Vault Secrets User |
| **t3-met-b2b-ibadirects-{env}-ae-logic** | **t3b2b{env}aesta01** | System-Assigned Managed Identity | Storage Blob Data Contributor |
| **t3-met-b2b-ibadirects-{env}-ae-logic** | **t2-met-{npr/prd}-ae-sb001** | System-Assigned Managed Identity | Azure Service Bus Data Receiver |
| **t3-met-b2b-ibadirects-{env}-ae-logic** | **t3-met-b2b-ibadirects-{env}-ae-logic-ai** | System-Assigned Managed Identity | Monitoring Metrics Publisher |
| **t3-met-enabling-blobmgmt-{env}-ae-func** | **t3enabling{env}aekv01** | System-Assigned Managed Identity | Key Vault Secrets User |
| **t3-met-enabling-blobmgmt-{env}-ae-func** | **t3b2b{env}aesta01** | System-Assigned Managed Identity | Storage Blob Data Contributor |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

| Private Endpoint Name | Target Resource | Sub-resource | Private DNS Zone | New / Existing |
| --- | --- | --- | --- | --- |
| **t3-met-b2b-ibadirects-{env}-ae-pe-kv** | **t3enabling{env}aekv01** (Azure Key Vault) | vault | [privatelink.vaultcore.azure.net](http://privatelink.vaultcore.azure.net) | Existing |
| **t3-met-b2b-ibadirects-{env}-ae-pe-storage** | **t3b2b{env}aesta01** (Azure Storage Account) | blob | [privatelink.blob.core.windows.net](http://privatelink.blob.core.windows.net) | Existing |
| **t3-met-b2b-ibadirects-{env}-ae-pe-sb** | **t2-met-{npr/prd}-ae-sb001** (Azure Service Bus Namespace) | namespace | [privatelink.servicebus.windows.net](http://privatelink.servicebus.windows.net) | Existing |

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Logic App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`



====================================================================================================
## DOC: TSD-EAII-333
====================================================================================================

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![image-20260806-101005.png](images/04.png)

## 6.2 Network Connectivity

![image-20260806-100927.png](images/02.png)

| **Connection** | **Source** | **Destination** | **Protocol** | **Port** | **Authentication** |
| --- | --- | --- | --- | --- | --- |
| Inbound | Storeline (on-premises) | APIM Gateway | SOAP over HTTPS | 443 | Network-level security (existing) |
| Outbound | APIM Backend | SAP Commerce Cloud | REST over HTTPS | 443 | Mutual TLS (client certificate) |
| Internal | APIM | Key Vault | HTTPS | 443 | Managed Identity |
| Internal | APIM | Application Insights | HTTPS | 443 | Instrumentation Key |

## 6.3 Security

- Control access to all Azure services/resources using RBAC.
- All communication between endpoints will be through https.

### 6.3.1 Data Handling and Encryption

- **Data classification**: Internal
- The integration handles order identifiers, customer identifiers, and payment amounts only
- No credit card numbers, CVVs, or sensitive payment instrument details pass through the integration
- Audit logs must NOT capture full request/response payloads in production to avoid exposure of customer identifiers at scale
- All data in transit is encrypted via TLS 1.2+
- Client certificate for mutual TLS stored in Azure Key Vault (FIPS 140-2 Level 2 compliant)

## 6.4 Infrastructure Support

Standard AIS platform infrastructure support applies. No special requirements beyond:

- Key Vault certificate rotation support (SAP Commerce Cloud client certificate renewal)
- APIM policy deployment via CI/CD

## 6.5 Infrastructure Requirements

| **Component** | **Non-Prod Specifications** | **Prod Specifications** | **New / Existing** |
| --- | --- | --- | --- |
| Azure API Management | Standard tier (shared instance) | Standard/Premium tier | Existing (shared) |
| Azure Key Vault | Standard | Standard | Existing (shared) |
| Azure Application Insights | Standard | Standard | Existing (shared) |
| Azure Log Analytics Workspace | Standard | Standard | Existing (shared) |
| Virtual Network | Standard (existing APIM subnet) | Standard (existing APIM subnet) | Existing |
| Azure App Gateway | Standard_v2 | Standard_v2 | Existing (shared) |

## 6.6 Infrastructure Resource Details

The following table captures the specific Azure resource names, subscription placement, and network configuration for this integration.

| **Resource Name** | **Type** | **Resource Group** | **Subscription** | **VNet** | **Subnet** | **IP Address** |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `t1-met-core-{env}-ae1-apg-01` | Application Gateway | `t1-met-core-{env}-ae1-rsg-net` | `COREIT-SERVICES-HUB-{env}` | App GW VNet | App GW Subnet | Public: 20.42.203.106, Private: 10.247.1.71 |  |
| `t3-met-core-{env}-ae1-apim` | API Management | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | APIM VNet | ECCS2 | Public VIP: 4.254.116.233, Private VIP: 10.247.1.4 |  |
| `t3-met-core-{env}-ae1-appi-apim` | Application Insights | `t3-met-core-{env}-ae1-rsg-apim` | `COREIT-SERVICES-HUB-{env}` | N/A | N/A | N/A |  |
| `t3enabling{env}ae1kv01` | Key Vault | `t3-met-ais-{env}-ae1-rsg-enabling` | `COREIT-SERVICES-AIS-{env}` | `t2-met-ais-{env}-ae1-net-01` | HSENS (10.247.85.0) | PE: `t3enabling{env}ae1kv01-pe` |  |
| `t3enabling{env}ae1kv01` | Private Endpoint (Key Vault) | `t3-met-ais-{env}-ae1-rsg-enabling` | `COREIT-SERVICES-AIS-{env}` | `t2-met-ais-{env}-ae1-net-01` | HSENS (10.247.85.0) | N/A |  |
| APIM System-Assigned MI | Managed Identity | Microsoft.ManagedIdentity (system-assigned) | t3-met-core-{env}-ae1-rsg-apim | COREIT-SERVICES-HUB-{env} | N/A | N/A | N/A |
| SMC | Service Management Console | N/A (External SaaS) | N/A (External) | N/A | N/A | N/A | N/A |

**App Gateway Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure Application Gateway | Microsoft.Network/applicationGateways | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | Microsoft.Network/applicationGateways | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Azure Resource Provider | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- | --- |
| Azure API Management | Microsoft.ApiManagement/service | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | Microsoft.ApiManagement/service | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | Microsoft.ApiManagement/service | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway, providing Layer 7 load balancing and secure ingress routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Notes:**

- APIM Gateway URL: `https://cloud-api-{env}-internal.metcash.com`
- Managed Identity: APIM uses a system-assigned managed identity (Microsoft.ManagedIdentity) to authenticate to Key Vault cross-subscription for mTLS client certificate retrieval. The identity is granted Key Vault Secrets User and Key Vault Certificates Officer RBAC roles (Microsoft.Authorization/roleAssignments) on `t3enabling{env}ae1kv01`.
- Log Analytics Workspace (Microsoft.OperationalInsights/workspaces) is linked to Application Insights for log query and retention. Exact resource name follows platform naming convention.
- Private Endpoint (Microsoft.Network/privateEndpoints): Key Vault is accessed via private endpoint within the HSENS subnet.
- Key Vault is accessed cross-subscription via Managed Identity (APIM → Key Vault) to retrieve the mTLS client certificate for SAP Commerce Cloud
- APIM interacts with SMC through REST API call for audit logging (Start/End/Warning/Error observations)

| **Variable** | **Values** |
| --- | --- |
| `{env}` | `dev` &#124; `sit` &#124; `uat` &#124; `prd` |



====================================================================================================
## DOC: TSD-EAII-514
====================================================================================================

# 6 Architecture Overview

## 6.1 Physical Architecture Diagram

![EAII-514-updated-1-Architecture Diagram.drawio (1)-20260721-070940.png](images/07.png)

## 6.2 Network Connectivity

![EAII-514-updated-1-Network Diagram.drawio (1)-20260721-071007.png](images/02.png)

## 6.3 Security

- Azure API Management enforces authentication OAuth2 for all inbound requests to the pricing endpoints.The current design already specifies OAuth 2.0 Bearer-token authentication for Sorted-to-APIM communication.

**OAuth 2.0 Configuration**

| Setting | Value |
| --- | --- |
| Grant Type | `Client Credentials` |
| Identity Provider | Microsoft Entra ID |
| Tenant ID | `{tenantId}` |
| Token Endpoint | `https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token` |
| OAuth Version | OAuth 2.0 / Microsoft Identity Platform v2.0 |
| Client ID | `{clientId}` |
| Client Authentication | Client ID and Client Secret |
| Client Secret | Secure credential; not documented in the TSD |
| Scope | `https://{clientId}.metcash.onmicrosoft.com/.default` |
| Token Type | Bearer access token |
| Token Lifetime | Approximately 1 hour |
| RequesterSiteId | `This will be defined based on the consumers` |
| Authentication Enforcement Point | Azure API Management |

**Authentication Flow**

The authentication flow is as follows:

1. The Sorted consumer application requests an access token from Microsoft Entra ID using the OAuth 2.0 Client Credentials grant.
2. The token request is sent to: `https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token`
3. The request includes the configured Client ID, client credential, and the following scope: `https://{clientId}.metcash.onmicrosoft.com/.default`
4. Microsoft Entra ID authenticates the application and issues an OAuth 2.0 Bearer access token.
5. The access token has an approximate validity period of one hour.
6. The consumer invokes: `POST /eis/pricing/v1/getrealtimeprice` and supplies the token using the HTTP Authorization header: `Authorization: Bearer <access-token>`
7. APIM validates the access token before performing request schema and business validation.
8. Only successfully authenticated requests are forwarded for subsequent processing.

**Token Validation**

APIM shall validate the OAuth access token for every inbound request.

The following validations shall be applied:

| Validation | Requirement |
| --- | --- |
| Token signature | Must be cryptographically valid and issued by Microsoft Entra ID |
| Issuer | Must correspond to the approved Metcash Microsoft Entra tenant |
| Tenant | `{tenantId}` |
| Audience | Must match the audience configured for the approved API application registration |
| Expiry (`exp`) | Token must not be expired |
| Client identity | Token must represent an authorised application |
| Scope/Application permission | Must correspond to the configured API access using the `.default` scope |

The final accepted `aud` value shall be configured in the APIM token-validation policy using the value present in an approved access token issued for the API.

An access token that is missing, malformed, expired, issued by an untrusted issuer, or intended for an invalid audience shall be rejected with:

**HTTP 401 – Unauthorized**

Where authentication succeeds but the application does not have the required API permission, APIM shall return:

**HTTP 403 – Forbidden**

The TSD already distinguishes missing/invalid tokens as `401` and insufficient OAuth permissions as `403`.

**Token Lifetime**

The issued OAuth access token is valid for approximately **one hour**.

APIM validates the token expiry for every API request. An expired access token shall not be accepted.

The consumer is responsible for obtaining a new valid access token from Microsoft Entra ID when the existing token expires.

**RequesterSiteId Validation**

`RequesterSiteId` validation is performed by APIM before the request is forwarded to the Logic App.

The current test specification already contains scenarios for missing and invalid `RequesterSiteId` values.

The following behaviour applies:

| Scenario | Expected Behaviour |
| --- | --- |
| `RequesterSiteId` missing | HTTP 400 Bad Request |
| Valid `RequesterSiteId` | Continue request processing |
| Invalid `RequesterSiteId` | Request rejected according to APIM validation policy |
| Invalid/expired OAuth token | HTTP 401 Unauthorized |
| Valid token without required API permission | HTTP 403 Forbidden |

`RequesterSiteId` does not replace OAuth authentication. The authenticated caller identity is derived from the successfully validated OAuth access token.

### Pillar Validation

The `Pillar` field is part of the API request payload and represents the business context for the realtime pricing enquiry.

Pillar validation is performed using the **REST JSON schema specification** enforced by Azure API Management.

The supported Pillar values are:

- `IGA`
- `ALM`
- `CCC`
- `CSD`

The schema shall restrict the `Pillar` field to these approved enumeration values.

Example schema definition:

```
{
  "Pillar": {
    "type": "string",
    "enum": [
      "IGA",
      "ALM",
      "CCC",
      "CSD"
    ]
  }
}
```

If a request contains a Pillar value outside the approved enumeration, APIM shall reject the request with:

**HTTP 400 – Bad Request**

The request shall not be forwarded to the Logic App or IBM AS/400.

**APIM-to-Logic-App Authentication**

Azure API Management invokes the EAII-514 Logic App HTTP trigger using **Logic App SAS (Shared Access Signature) authentication**.

The Logic App is configured as an **APIM Backend**, with the Logic App base URL maintained separately from the SAS authentication parameters.

The Logic App callback parameters `api-version`, `sp`, `sv`, and `sig` are configured as **backend query credentials**. The security-sensitive `sig` value is referenced through an APIM Named Value backed by **Azure Key Vault**.

The actual SAS signature is therefore not hardcoded in the APIM policy, backend definition, source code, application configuration, or TSD.

This approach centralises management of the SAS credential in Azure Key Vault while allowing APIM Backend configuration to automatically apply the required Logic App authentication parameters when forwarding requests.

**Authentication Configuration**

| Attribute | Configuration |
| --- | --- |
| Source | Azure API Management |
| Destination | EAII-514 Logic App HTTP Trigger |
| Protocol | HTTPS |
| Port | 443 |
| Authentication | Logic App SAS / Shared Access Signature |
| Backend Configuration | APIM Backend |
| SAS Parameters | `api-version`, `sp`, `sv`, `sig` |
| SAS Signature Storage | Azure Key Vault |
| SAS Reference | Key Vault-backed APIM Named Value |
| SAS Hardcoded in Source Code | No |
| Transport Encryption | TLS 1.2+ |
| Backend Access | Through APIM |

**APIM Backend Configuration**

The Logic App is registered as an APIM Backend. The backend configuration defines the Logic App base endpoint and the required SAS query credentials.

Conceptually, the backend configuration follows the pattern below:

```
- name: t3-met-b2b-realtimepricing-logic-app
  properties:
    description: "B2B RealTimePricing Logic App GetPricingData Workflow"
    displayName: B2B-RealTimePricing-Logic-App-GetPricingData-Workflow
    url: "https://t3-met-b2b-realtimepricing-{env}-ae-logic.<ase-domain>:443/api"
    protocol: http
  credentials:
    query:
      api-version:
      - "{{LogicApp-Workflow-API-Version}}"
      sp:
      - "{{LogicApp-Workflow-SP}}"
      sv:
      - "{{LogicApp-Workflow-SV}}"
      sig:
      - "{{b2b-realtimepricing-logic-app-getpricingdata-workflow-sig}}"
```

The backend URL contains only the Logic App base endpoint. The SAS parameters required to authenticate the Logic App invocation are maintained separately under the APIM Backend `credentials.query` configuration.

The `sig` parameter references:

```
{{b2b-realtimepricing-logic-app-getpricingdata-workflow-sig}}
```

This APIM Named Value is backed by the corresponding Azure Key Vault secret.

**Authentication Flow**

The APIM-to-Logic-App authentication flow is as follows:

1. The Sorted consumer submits the realtime pricing request to Azure API Management.
2. APIM performs inbound OAuth authentication, schema validation, business validation, and the configured API policy checks.
3. APIM resolves the configured `t3-met-b2b-realtimepricing-logic-app` backend.
4. The APIM Backend configuration automatically applies the required Logic App query credentials:
  - `api-version`
  - `sp`
  - `sv`
  - `sig`

5. The `sig` backend credential is resolved through the configured Key Vault-backed APIM Named Value.
6. APIM forwards the validated request to the Logic App over HTTPS.
7. The Logic App runtime validates the supplied SAS parameters and signature.
8. When SAS validation succeeds, the `GetPricingData` workflow is executed.
9. Requests with missing or invalid SAS credentials are rejected by the Logic App runtime.

The application/API policy does **not explicitly construct the SAS URL or retrieve the SAS signature**. SAS authentication is handled as part of the APIM Backend configuration..

- Logic App uses **Managed Identities** to authenticate to Azure Key Vault, Azure App Configuration - no stored credentials in application configuration.
- Public access to the Logic App HTTP trigger is denied; access is via APIM only.
- Azure Key Vault stores all secrets (AS/400 JDBC connection string, AS/400 username/password).
- RBAC controls access to all Azure resources; principle of least privilege applied.
- All communication between Azure components and to/from Sorted consumers is via HTTPS/TLS 1.2+.

**Key Vault Secret**

The solution stores all sensitive configuration and credentials in Azure Key Vault. The Azure Logic App accesses the required secrets using its Managed Identity with the **Key Vault Secrets User** role. No secrets are stored in application configuration or source code.

| Key Vault | Purpose |
| --- | --- |
| `t3b2b{env}ae1kv01` | Application Key Vault containing integration-specific secrets required by the Pricing solution. |
| `t3enabling{env}ae1kv01` | Shared platform Key Vault managed by the Enabling Platform team, containing shared platform configuration and platform-managed secrets where applicable. |

### 6.3.1 Data Handling and Encryption

- **Data Classification:** Internal — commercially sensitive pricing data (wholesale costs, margins, promotional pricing), but no PII.
- **In transit:** All data encrypted in transit via TLS 1.2+ (HTTPS for all API calls; JDBC over encrypted channel to AS/400 where supported by the on-premises gateway).
- **At rest:** No pricing response payload data is persisted in the integration layer. Only transaction metadata (UUID, timestamps, status) is stored in SMC.
- **Logging restriction:** Full pricing response payloads (product prices, margins, allowances) are **not** logged in SMC in production. Only metadata fields are logged.
- **Customer IDs:** Treated as internal account references (not PII). Customer IDs appear in structured logs at metadata level only (not full payloads).

## 6.4 Infrastructure Support

*NA*

## 6.5 Infrastructure Requirements

**Logic App Infrastructure**

| Resource | Azure Resource Provider | SKU / Tier | Workflow Type | Hosting | Purpose |
| --- | --- | --- | --- | --- | --- |
| Azure Logic App | `Microsoft.Logic/workflows` | Standard | Stateless | Azure Logic Apps Standard (App Service Plan) | Hosts the pricing orchestration workflow responsible for request validation, product iteration, AS/400 invocation, response transformation, and error handling. |
| App Service Plan | `Microsoft.Web/serverfarms` | Standard | N/A | Dedicated | Provides the compute hosting environment for the Logic App Standard runtime. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **Azure Logic App** | **t3-met-b2b-realtimepricing-{env}-ae-logic** | New |
| **Azure Key Vault** | **t3b2b{env}ae1kv01**<br> <br>**t3enabling{env}ae1kv01** | Existing |
| **Resource Group** | **t3-met-ais-{env}-ae1-rsg-b2b** | Existing |
| **Subscription** | **COREIT-SERVICES-AIS-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / SENS** | Existing |

**{env} -** dv1, st1, ut1 and prd

**Workflow Details**

- **Workflow Name:** `PricingFromPE`
- **Workflow Type:** Stateless.
- **Runtime:** Azure Logic Apps Standard.
- **Hosting Model:** Dedicated App Service Plan.
- **Number of Workflows:** One orchestration workflow

**Azure API Management Infrastructure**

Azure API Management (APIM) serves as the secure gateway for the Pricing API, exposing REST endpoint to Sorted consumers while enforcing authentication, policy execution, request validation, routing, and observability.

**Azure API Management (APIM) Named Values** are used to externalize runtime configuration values required by the API gateway. APIM reads these values during policy execution to control request processing without requiring policy changes or redeployment.

Configuration includes, but is not limited to:

- `dbOutageFlag`

The `dbOutageFlag` is evaluated by APIM during request processing. When the flag is enabled, APIM immediately returns an **HTTP 503 Service Unavailable** response (REST) without forwarding the request to the Logic App.

| Resource | Azure Resource Provider | SKU | Purpose |
| --- | --- | --- | --- |
| Azure API Management | `Microsoft.ApiManagement/service` | Standard | Exposes the Pricing API, performs request validation, authentication, policy enforcement, request/response transformation and forwards requests to the Azure Logic App. |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **APIM** | **t3-met-core-{env}-ae-apim** | Existing |
| **Resource Group** | **t3-met-core-{env}-ae1-rsg-apim** | Existing |
| **Subscription** | **COREIT-SERVICES-HUB-{env}** | Existing |
| **Virtual Network / Subnet** | **t2-met-ais-{env}-ae1-net-01 / HSENS** | Existing |

**API Endpoints**

| **API** | **Endpoint** |
| --- | --- |
| REST Pricing API | `eis/pricing/v1/getrealtimeprice` |

**APIM Policies**

Azure API Management policies are used to implement:

- OAuth 2.0 authentication and authorization
- Request validation
- Backend routing to the Azure Logic App
- Error handling and standardized fault responses
- Logging with SMC

**Virtual Network Architecture**

The Pricing integration is deployed within the enterprise **Hub-and-Spoke** network architecture. Azure API Management is deployed in the **Hub Virtual Network**, while the Azure Logic App and supporting integration resources are deployed in the **AIS Spoke Virtual Network**. Secure communication between Azure resources and IBM AS/400 is achieved through Virtual Network Integration, Private Endpoints, Network Security Groups (NSGs), Route Tables, and enterprise networking controls.

**App Gateway Details**

| Resource | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| Azure Application Gateway | DEV / SIT / UAT | t1-met-core-npr-ae1-apg-01 | t1-met-core-npr-ae1-net-hub | 10.247.0.0/20 |
| Azure Application Gateway | PRD | t3-met-core-prd-ae1-apg-01 | t1-met-core-prd-ae1-net-hub | 10.249.0.0/20 |

**Azure API Management Details**

| Resource | Environment | Azure Resource Name | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| Azure API Management | DEV | t3-met-core-dev-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.1.0/26 |
| Azure API Management | SIT | t3-met-core-sit-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.0/26 |
| Azure API Management | UAT | t3-met-core-uat-ae1-apim | t1-met-core-npr-ae1-net-hub | 10.247.3.64/26 |
| Azure API Management | PRD | t3-met-core-prd-ae1-apim | t1-met-core-prd-ae1-net-hub | 10.249.1.0/26 |

**AIS Spoke Virtual Network Details**

| Resource | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- |
| AIS Spoke Virtual Network | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | PRD | t2-met-ais-prd-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Logic App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway and secure routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**SENS (Logic App Application Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Logic Apps** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | **t3-met-b2b-realtimepricing-dv1-ae-logic** |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | **t3-met-b2b-realtimepricing-st1-ae-logic** |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | **t3-met-b2b-realtimepricing-ut1-ae-logic** |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | **t3-met-b2b-realtimepricing-prd-ae-logic** |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**App Gateway:-**

| **Environment** | **VNet** | **Subnet** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- |
| Dev / SIT / UAT | t1-met-core-npr-ae1-net-hub | ECIS1 | 20.42.203.106 | 10.247.1.71 |
| Prd | t1-met-core-prd-ae1-net-hub | ECIS1 | 4.200.110.27 | 10.249.1.72 |

**Network Security Controls**

- Access to Azure resources is controlled using **Managed Identity** and **Azure RBAC**.
- All network communication follows the enterprise Hub-and-Spoke networking architecture.
- Public network access is disabled.
- Access is restricted through Private Endpoints.
- Authentication is performed using Microsoft Entra ID and Managed Identity.
- Access is governed through Azure RBAC following the principle of least privilege.
- Secrets are retrieved at runtime and are never persisted within the application.

**Managed Identity**

The Azure Logic App uses a System-Assigned Managed Identity. The identity is
 automatically created and managed by Azure, and its lifecycle is tied
 exclusively to the Logic App resource. When the Logic App is deleted, the
 identity is automatically deleted with it.

A User-Assigned Managed Identity (Microsoft.ManagedIdentity/userAssignedIdentities)
 was considered but was not selected for this integration. The System-Assigned
 model is preferred here because:

- The identity is used solely by this Logic App and no other resource.
- There is no requirement to share the same identity across multiple Azure resources.

No credentials, client secrets, or certificates are stored within the
 application. All Azure service authentication is performed at runtime via the
 System-Assigned Managed Identity token.

**Identity and Access Control (RBAC)**

The Logic App authenticates to Azure services using Microsoft Entra ID and its Managed Identity. The following Azure RBAC roles are assigned based on the principle of least privilege.

**Complete RBAC Assignments (**`Microsoft.Authorization/roleAssignments`**):**

| Source | Target | Identity | RBAC Role |
| --- | --- | --- | --- |
| `t3-met-b2b-realtimepricing-{env}-ae-logic` | `t3b2b{env}ae1kv01` | System-Assigned Managed Identity | Key Vault Secrets User |
| `t3-met-b2b-realtimepricing-{env}-ae-logic` | `t3-met-b2b-realtimepricing-{env}-ae-ai` | System-Assigned Managed Identity | Monitoring Metrics Publisher |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

| Private Endpoint Name | Target Resource | Sub-resource | Private Zone | New / Existing |
| --- | --- | --- | --- | --- |
| `t3-met-b2b-realtimepricing-{env}-ae-pe-kv` | `t3b2b{env}ae1kv01` (Azure Key Vault) | `vault` | `privatelink.vaultcore.azure.net`<br> <br>`t3b2b{env}ae1kv01.vault.azure.net` | Existing |

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Logic App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`
