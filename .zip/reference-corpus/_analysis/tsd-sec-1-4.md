

====================================================================================================
## DOC: TSD-EAII-284_283_282_385
====================================================================================================

# 1 Document Overview

## 1.1 Background

This document provides the Technical Specification for four integration interfaces — EAII-282, EAII-283, EAII-284, and EAII-385 — that distribute product, supplier item, corporate item, and product master data from STIBO (MetProducts PIM) to multiple downstream systems: Sorted Marketplace, IndiPIM, and Retail Express (MetProms).

All four interfaces are implemented on **Azure Function App (isolated worker, .NET 10)** for per-interface message processing, transformation, and delivery. No Logic Apps are used in this design.

All four interfaces share a common upstream pipeline (STIBO → GoAnywhere → Blob Storage → Event Grid → Service Bus). They diverge at the processing layer, where each interface's dedicated Service Bus subscription triggers an independent Azure Function that applies interface-specific transformation and delivers to its target system.

EAII-282, EAII-283, and EAII-284 are migrations from the legacy TIBCO BusinessWorks integration platform to Azure Integration Services. EAII-385 is a net-new interface.

## 1.2 Document Purpose

The primary purpose of this document is to outline the technical specifications, requirements, design considerations, and implementation steps for the integration of product, supplier, corporate, and product master data between STIBO (MetProducts PIM) and the downstream target systems: Sorted Marketplace (EAII-282, EAII-283), IndiPIM (EAII-284), and Retail Express / MetProms (EAII-385).df

## 1.3 Glossary

| Term | Description |
| --- | --- |
| STIBO | Product Information Management (PIM) system. Source of truth for all product, supplier, corporate, and master data published downstream. |
| PIM | Product Information Management. Refers to the STIBO PIM system used by Metcash. |
| MetProducts | Metcash branding for the STIBO PIM system. |
| IndiPIM | Independent retailer Product Information Management system, hosted on AWS API Gateway. |
| Sorted | Internal Metcash retail platform. Receives corporate item data (EAII-283) and supplier item data (EAII-282). |
| Retail Express | External retail platform integrated via the MetProms API. Receives product master data (EAII-385). |
| MetProms | The REST API gateway for Retail Express product master data. |
| GoAnywhere | Managed File Transfer (MFT) solution. Picks up files from STIBO SFTP and delivers them to Azure Blob Storage. |
| Azure Service Bus | Azure Service Bus. Topic-based pub/sub used to fan out blob-created events to per-interface Function App subscriptions. |
| Azure Function App | Azure Function App (isolated worker, .NET 10) — the integration runtime for all four interfaces. |
| SAMI | System-Assigned Managed Identity. Enabled on the Function App and used for all service-to-service authentication within Azure. |
| SMC | System Monitoring & Control (Gen 3). Centralised audit, logging, and exception management platform for Metcash integrations, accessed via APIM. |
| AIS | Azure Integration Services. The Metcash standard set of Azure-native integration components. |
| EAII | Enterprise Application Integration Interface. Naming prefix used for Metcash integration interface IDs. |
| Blob Storage | Azure Storage Account blob container used as the staging area for inbound XML files. |
| Event Grid | Azure Event Grid. Raises `Microsoft.Storage.BlobCreated` events when GoAnywhere drops a new file into the blob container. |
| APIM | Azure API Management. Existing shared instance used as the SMC gateway. |
| mTLS | Mutual TLS. Client certificate–based authentication used by EAII-282 and EAII-283 to authenticate with Sorted Marketplace. |
| OAuth 2.0 | Client credentials flow used by EAII-284 (Auth0) and EAII-385 (Retail Express identity) for bearer token acquisition. |
| DLQ | Dead Letter Queue. Service Bus mechanism for retaining unprocessable messages for investigation and manual replay. |
| Polly | .NET resilience library used for retry policies within the Function App. |

---

# 2 Scope

*The scope of the integration should be clearly defined to ensure all stakeholders have a comprehensive understanding of its objectives and boundaries. This includes identifying the systems involved, the specific functionalities to be integrated, and the expected outcomes. By establishing a well-defined scope, we can facilitate smoother collaboration and ensure that all parties are aligned on the project goals.*

![image-20260810-052046.png](images/16.png)

## 2.1 In Scope

- **EAII-282** — Migration of supplier item data distribution from TIBCO to AIS: STIBO → GoAnywhere → AIS → Sorted Marketplace (supplier item JSON via mTLS).
- **EAII-283** — Migration of corporate item data distribution from TIBCO to AIS: STIBO → GoAnywhere → AIS → Sorted Marketplace (corporate item JSON via mTLS).
- **EAII-284** — Migration of corporate item data pass-through from TIBCO to AIS: STIBO → GoAnywhere → AIS → IndiPIM (STEP XML pass-through via OAuth 2.0 Client Credentials).
- **EAII-385** — New build: product master data distribution: STIBO → GoAnywhere → AIS → Retail Express / MetProms (item-attribute-records JSON via OAuth 2.0 Client Credentials).
- Shared upstream pipeline: GoAnywhere MFT → Azure Blob Storage → Azure Event Grid → Azure Service Bus (one topic, four subscriptions).
- Azure Function App (isolated worker, .NET 10) — shared host `t3-met-metproducts-{env}-ae-func` running per-interface triggered functions.
- SMC Gen 3 onboarding for audit, logging, and exception management across all four interfaces.
- Azure Key Vault integration for all secrets and credentials; Azure enabling Key Vault for SMC integration.
- Azure Managed Identity (SAMI) for all service-to-service authentication within Azure.

## 2.2 Out of Scope

- The upstream process by which PIM publishes XML to GoAnywhere and GoAnywhere stages files to Azure Blob Storage
- Any changes to the target system APIs (Sorted, IndiPIM, MetProms).
- **Sorted availability health-check gating** — handled by **EAII-506** (separate interface, own FSD). During known Sorted downtime, operations manually disables the EAII-282/EAII-283 Function triggers. The current gating check in code is an always-available stub.
- Supplier item data for EAII-385 (corporate and location item types only are in scope).

---

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

| Code | Principle | Why It Applies to This Requirement |
| --- | --- | --- |
| IDP-001 | Generic and Reusable | A shared `Metcash.AIS.Data.Metproducts.Common` library provides a common XML deserialisation component, SMC observation wrapper, retry policy, and Key Vault access. Each interface function references this shared library and implements only interface-specific transformation and delivery logic. Onboarding a new target system requires only a new triggered function and mapping module — the shared infrastructure is untouched. |
| IDP-002 | Decoupled Integrations | Azure Service Bus (one topic, four subscriptions) and Blob Storage decouple the upstream GoAnywhere/Event Grid pipeline from the downstream Function App processing layer. Each interface operates on an independent subscription; a failure in one interface has no effect on the others. Interfaces can be independently deployed, scaled, and versioned. |
| IDP-004 | Resilient and Recoverable | The Function App uses Polly-based retry policies for transient failures (3 attempts, fixed 2-second delay). Non-retryable errors result in Service Bus dead-lettering. All failures are logged to SMC and Application Insights, enabling root-cause analysis and controlled SMC-based reprocessing. |
| IDP-005 | Observability | Full end-to-end observability is delivered via SMC Gen 3 (single-call `StartObservation` with `IsObservationComplete = true` per invocation) and Azure Application Insights (`TrackEvent`, `TrackException`, dependency telemetry). SMC provides per-interface dashboards, payload search, and manual reprocessing. Application Insights provides real-time telemetry, failure alerting, and Live Metrics. |

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

| Pattern Name | Implementation Description |
| --- | --- |
| Azure Function App | All four interfaces are implemented as Service Bus–triggered Azure Functions (isolated worker, .NET 10), hosted on a single shared Function App per environment. Each function is stateless, modular, and focused on a single business capability. |
| API Management Service | Azure API Management (APIM) is used only as the SMC gateway for `StartObservation` calls — it does not front the Function App's inbound trigger (Service Bus is a pull trigger, not an HTTP-exposed endpoint). |
| Retry and Resilience | Polly-based in-process retry policy: up to 3 attempts, fixed 2-second delay, for outbound calls to target systems. Service Bus subscription-level redelivery and dead-lettering provide the outer resilience layer once in-process retries are exhausted. |
| Logging and Observability | Logging and telemetry are captured using Application Insights (`TrackEvent`/`TrackException`/dependency calls) and SMC (single complete observation per invocation), providing visibility into execution, response status, correlation IDs, and exception details. |
| Security Abstraction | Secrets and credentials are stored in Azure Key Vault and accessed via the Function App's System-Assigned Managed Identity. Authentication mechanisms vary by target: mTLS (Sorted), OAuth 2.0 client credentials (IndiPIM via Auth0, MetProms via Retail Express identity). No hardcoded credentials anywhere in source, pipeline variables, or committed appsettings. |
| Standardization and Governance | All interfaces comply with Metcash integration standards: consistent Azure resource naming (`{company-prefix}-{workload}-{environment}-{region}-{resource-type}`), standardised error handling, and structured JSON/XML payloads per target contract. |

**Naming Standards — Azure Function App**

| Standard | Detail |
| --- | --- |
| Function App name | `t3-met-metproducts-{env}-ae-func` (env: dv1 / st1 / ut1 / prd) |
| Per-interface function names | `SupplierItemToSorted`(EAII-282), `CorporateItemToSorted`(EAII-283), `CorporateItemToIndiPIM`(EAII-284), `CorporateItemToMetProms`(EAII-385) |

**Service Bus — One Topic, Four Subscriptions**

| Standard | Detail |
| --- | --- |
| Topic naming | `data.metproducts.{env}.sbt` — a single shared topic consumed by all four interfaces |
| Subscription naming | `to{target}.{itemtype}` pattern: `tosorted.corporateitem` (EAII-283), `toindipim.corporateitem` (EAII-284), `tometproms.corporateitem` (EAII-385), `tosorted.supplieritem` (EAII-282) |
| Item-type differentiation | By blob path / Event Grid subject filter and Service Bus subscription — **not** by separate topics |

**Security Controls**

| Control | Implementation |
| --- | --- |
| Managed Identity | System-Assigned Managed Identity (SAMI) enabled on the Function App in all environments |
| Key Vault | All secrets and credentials in Azure Key Vault; referenced via Key Vault reference syntax in appsettings |
| RBAC | Least-privilege RBAC; Function App SAMI granted only required roles per resource (see §6.3) |
| External API auth | mTLS for Sorted (EAII-282/283); OAuth 2.0 Bearer via Auth0 for IndiPIM (EAII-284); OAuth 2.0 Client Credentials for MetProms (EAII-385) |
| Secret hygiene | No secrets in source code, pipeline variables, or committed appsettings files; all secrets via Key Vault references |

**Environment Segregation**

| Standard | Detail |
| --- | --- |
| Environment identifiers | `dv1` (DEV), `st1` (SIT), `ut1` (UAT), `prd` (PRD) |
| Resource groups | `t3-met-ais-{env}-ae1-rsg-data` per environment |
| Service Bus namespaces | Non-production (DV1/ST1/UT1): `t1-met-npr-ae-sb-001` · Production: `t1-met-prd-ae-sb-001` |
| Function App instances | One per environment (`t3-met-metproducts-{env}-ae-func`); all four interface functions deployed to the same host |

**Error Handling and Monitoring**

| Standard | Detail |
| --- | --- |
| Retry | Polly retry policy: up to 3 attempts, fixed 2-second delay, for transient HTTP 5xx / network errors; no retry on non-retriable 4xx |
| Dead-letter | Messages are explicitly dead-lettered by the Function (via `ServiceBusMessageActions.DeadLetterMessageAsync`) after the in-process retry loop (3 attempts, 2s delay) is exhausted or a non-retriable error occurs |
| SMC observations | One complete `StartObservation` call (`IsObservationComplete = true`) per Function invocation, always executed in a `finally` block regardless of outcome |
| Application Insights | `TrackEvent` at trigger and completion; `TrackException` on all caught errors; dependency tracking for outbound HTTP calls |
| Alerts | SMC failure-rate alerts per interface; Azure Monitor alerts on DLQ accumulation and Function error rate |

Information related to all Standards, Guidelines and Patterns refer

- [Guidelines](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1668874252/Guidelines)
- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

---

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

The proposed solution enables automated, event-driven distribution of product master data from STIBO (MetProducts PIM) to four downstream systems. STIBO is the single authoritative source for all product attribute changes. Any update to a corporate item, supplier item, or location item triggers a complete product XML export that is propagated to each relevant downstream consumer.

The architecture leverages Azure Service Bus subscriptions to fan out a single STIBO publish event to multiple independent processing functions simultaneously. Each function operates independently — a failure in delivery to one target has no effect on the others.

The solution is designed for near-real-time, event-driven delivery with full audit trail, structured error handling, and operational observability through SMC Gen 3.

### 4.1.1 Process Diagram from FSD

The end-to-end process diagram is documented in the Functional Specification Document (FSD) for these four interfaces.

[Functional Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311042576/Functional+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets)

![image-20260721-132424.png](images/12.png)

### 4.1.2 Functional Specification Document

| Title | Link |
| --- | --- |
| Functional Specification - EAII-284, EAII-283, EAII-282, EAII-385 - STIBO to Multiple Targets | [https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311042576/Functional+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets?atl_f=PAGETREE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311042576/Functional+Specification+-+EAII-284+EAII-283+EAII-282+EAII-385+-+STIBO+to+Multiple+Targets?atl_f=PAGETREE) |
| Mapping - EAII-282 - Distribute Supplier Item Data - STIBO to Sorted | [Mapping - EAII-282 - Distribute Supplier Item Data - STIBO to Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311271942/Mapping+-+EAII-282+-+Distribute+Supplier+Item+Data+-+STIBO+to+Sorted) |
| Mapping - EAII-283 - Distribute Corporate Item Data - STIBO to Sorted | [Mapping - EAII-283 - Distribute Corporate Item Data - STIBO to Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3311009815/Mapping+-+EAII-283+-+Distribute+Corporate+Item+Data+-+STIBO+to+Sorted) |
| Mapping - EAII-385 - Product Master Data - STIBO to Retail Express | [Mapping - EAII-385 - Product Master Data - STIBO to Retail Express](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3310321687/Mapping+-+EAII-385+-+Product+Master+Data+-+STIBO+to+Retail+Express) |

## 4.2 Technical Standard and Requirements

- **XML** — STIBO source payloads delivered as STEP-ProductInformation XML over SFTP and Azure Blob Storage.
- **JSON** — Target API payloads (Sorted, MetProms); SMC observation payloads.
- **SFTP** — Secure file transfer between STIBO and GoAnywhere MFT.
- **HTTPS (TLS 1.2+)** — All outbound API calls; all Azure service-to-service communication.
- **OAuth 2.0 Client Credentials** — Token acquisition for IndiPIM (Auth0) and MetProms (Retail Express identity).
- **mTLS (X.509 client certificate)** — Bilateral authentication for Sorted Marketplace API (EAII-282, EAII-283).
- **Azure Managed Identity** — Service-to-service authentication within Azure (Function App → Service Bus, Blob Storage, Key Vault).
- **Azure Service Bus (Topic + Subscriptions)** — Asynchronous, event-driven pull trigger for per-interface processing.
- **Azure Function App** — .NET 10 isolated worker; Service Bus pull-triggered functions per interface.
- **Azure API Management (APIM)** — Outbound HTTPS gateway for SMC `StartObservation` only.
- **Azure Key Vault** — Secret storage for all credentials and sensitive configuration.
- **SMC Gen 3** — Centralised audit, logging, and exception management.

## 4.3 Required Components

- Azure Function App (Isolated Worker, .NET 10)
- Azure App Service Plan
- Azure Service Bus (one Topic, four Subscriptions)
- Azure Event Grid (System Topic on Blob Storage)
- Azure Virtual Network
- Azure Key Vault (AIS-owned, per environment)
- Azure Key Vault (SMC-owned — existing; SAMI granted Secrets User access)
- Azure Application Insights
- Azure Log Analytics Workspace
- Azure Storage Account (Blob container: `stibo`, paths `frompim/corporateitem/`, `frompim/supplieritem/`)
- Azure API Management (existing shared instance — SMC gateway)
- GoAnywhere MFT (Managed File Transfer — existing)

## 4.4 Environmental Requirement

| Label (Pipeline) | Resource Suffix | Purpose |
| --- | --- | --- |
| DEV | `dv1` | Development and initial integration testing |
| SIT | `st1` | System Integration Testing |
| UAT | `ut1` | User Acceptance Testing |
| PROD | `prd` | Production |

Aligns with the AIS Governance Environments Strategy . [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy)



====================================================================================================
## DOC: TSD-EAII-289
====================================================================================================

# 1 Document Overview

## 1.1 Background

Metcash operates several internal business applications that need to verify the legitimacy and registration status of Australian businesses they trade with — suppliers, retailers, customers and other commercial counterparties. A centralised lookup capability is provided that allows any authorised Metcash application to query the official Australian Business Register (ABR) using either an Australian Business Number (ABN) or an Australian Company Number (ACN) and receive standardised business details in response.

**Legacy (As-is):** The integration was originally implemented as a TIBCO BusinessWorks BWCE service calling the ABR SOAP endpoints (`SearchByABNv201408` and `SearchByASICv201408`). The legacy service transforms the SOAP XML response into JSON and returns it to the consumer.

**Proposed (To-be):** The service is being migrated to Azure Integration Services (AIS). The new implementation is **APIM-only** — Azure API Management calls the ATO **REST** endpoints (which return XML), transforms the XML response into canonical `MetcashIdentifierBObj` JSON using XSLT templates, and returns JSON to the consumer. No SOAP calls are made in the proposed architecture.

The service exposes four synchronous REST API operations organised as two versions:

| **#** | **Operation** | **ATO Backend** | **Protocol** | **Transform** | **Response** |
| --- | --- | --- | --- | --- | --- |
| 1 | SearchByABN (v1) | ATO REST SearchByABN | REST (XML response) | XSLT v1 | JSON |
| 2 | SearchByABNv2 | ATO REST SearchByABN | REST (XML response) | XSLT v2 | JSON |
| 3 | SearchByACN (v1) | ATO REST SearchByACN | REST (XML response) | XSLT v1 | JSON |
| 4 | SearchByACNv2 | ATO REST SearchByACN | REST (XML response) | XSLT v2 | JSON |

All processing — routing, validation, backend call, transformation, and audit logging — is handled within APIM policies.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the **Business Details Lookup** service between **Metcash Internal Consumer Applications** (source) and the **Australian Business Register (ATO)** (target), implemented entirely on **Azure API Management (APIM)**.

## 1.3 Glossary

| **Term** | **Description** |
| --- | --- |
| ABN | Australian Business Number — the 11-digit unique identifier assigned to every entity registered in the Australian Business Register |
| ABR | Australian Business Register — the official register of all businesses and other entities operating in Australia, operated by the Australian Taxation Office |
| ACN | Australian Company Number — the 9-digit unique identifier assigned to Australian companies by ASIC |
| AIS | Azure Integration Services — the target integration platform |
| APIM | Azure API Management — the API gateway handling routing, validation, transformation, backend calls, and security |
| ASIC | Australian Securities and Investments Commission — the national corporate regulator that issues ACNs |
| ATO | Australian Taxation Office — operator of the Australian Business Register and provider of the REST API endpoints |
| MetcashIdentifierBObj | The canonical Metcash business object used to return business identification data in a standardised JSON format |
| SMC | Service Management Console — Metcash's custom monitoring and observability platform |
| Transaction ID | A correlation identifier generated for every lookup request and propagated through audit log events |

# 2 Scope

## 2.1 In Scope

  - `EAII-289 Business Details Lookup service providing four operations against the Australian Business Register:`
    - `SearchByABN — calls ATO REST SearchByABN endpoint, transforms XML response to JSON via XSLT v1`
    - `SearchByABNv2 — calls ATO REST SearchByABN endpoint, transforms XML response to JSON via XSLT v2`
    - `SearchByACN — calls ATO REST SearchByACN endpoint, transforms XML response to JSON via XSLT v1`
    - `SearchByACNv2 — calls ATO REST SearchByACN endpoint, transforms XML response to JSON via XSLT v2`

  - `APIM-only architecture: all routing, validation, backend proxying, XML-to-JSON transformation, and audit logging handled within APIM policies`
  - `Outbound connectivity to the ATO REST endpoints (XML responses)`
  - `Request/response correlation using a per-request Transaction ID`
  - `Audit logging of success and failure events through SMC tracked properties`
  - `Error handling for ATO connectivity failures, invalid input parameters, and unexpected responses`
  - `Input validation (ABN = 11 digits, ACN = 9 digits) at the APIM policy layer`
  - `ATO secrets (API keys/credentials) stored in data-specific Azure Key Vaults`

## 2.2 Out of Scope

- Caching of ATO/ABR responses (every lookup goes through to ATO)
- Changes to consumer application logic
- Changes to the upstream ATO REST service contract
- Bulk or batch lookup capability (the service is per-request only)

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

Refer to FSD Sections [3.1.1.1](https://media-cdn.atlassian.com/file/5b7cddcf-42f8-4bd6-b2e0-9dbb452cd2eb/image/cdn?allowAnimated=true&client=b2a0fec9-0c18-4ece-84e2-1fdd8532a29b&collection=contentId-3476422657&height=125&max-age=2592000&mode=full-fit&source=mediaCard&token=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJiMmEwZmVjOS0wYzE4LTRlY2UtODRlMi0xZmRkODUzMmEyOWIiLCJhY2Nlc3MiOnsidXJuOmZpbGVzdG9yZTpjb2xsZWN0aW9uOmNvbnRlbnRJZC0zNDc2NDIyNjU3IjpbInJlYWQiXX0sImV4cCI6MTc4NDUyMDQyMiwibmJmIjoxNzg0NTE3NTQyLCJhYUlkIjoiNzEyMDIwOjMwYjViYmVhLWI3N2ItNDk5Zi04ZTY2LTcwMzE4MmFkZmZkZSIsImh0dHBzOi8vaWQuYXRsYXNzaWFuLmNvbS9hcHBBY2NyZWRpdGVkIjpmYWxzZSwiYXV0aFR5cGUiOiJzZXNzaW9uIn0.JO-wkswPxWIZJcU7SJnLRxgknfZxwLmMRVEHIAkTlAk&width=1022#media-blob-url=true&id=5b7cddcf-42f8-4bd6-b2e0-9dbb452cd2eb&clientId=b2a0fec9-0c18-4ece-84e2-1fdd8532a29b&contextId=contentId-3476422657&collection=contentId-3476422657), [3.2.1.1](https://media-cdn.atlassian.com/file/afc7c3c2-547b-41e5-8c0e-9606b2514ef5/image/cdn?allowAnimated=true&client=b2a0fec9-0c18-4ece-84e2-1fdd8532a29b&collection=contentId-3476422657&height=125&max-age=2592000&mode=full-fit&source=mediaCard&token=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJiMmEwZmVjOS0wYzE4LTRlY2UtODRlMi0xZmRkODUzMmEyOWIiLCJhY2Nlc3MiOnsidXJuOmZpbGVzdG9yZTpjb2xsZWN0aW9uOmNvbnRlbnRJZC0zNDc2NDIyNjU3IjpbInJlYWQiXX0sImV4cCI6MTc4NDUyMDQyMiwibmJmIjoxNzg0NTE3NTQyLCJhYUlkIjoiNzEyMDIwOjMwYjViYmVhLWI3N2ItNDk5Zi04ZTY2LTcwMzE4MmFkZmZkZSIsImh0dHBzOi8vaWQuYXRsYXNzaWFuLmNvbS9hcHBBY2NyZWRpdGVkIjpmYWxzZSwiYXV0aFR5cGUiOiJzZXNzaW9uIn0.JO-wkswPxWIZJcU7SJnLRxgknfZxwLmMRVEHIAkTlAk&width=1036#media-blob-url=true&id=afc7c3c2-547b-41e5-8c0e-9606b2514ef5&clientId=b2a0fec9-0c18-4ece-84e2-1fdd8532a29b&contextId=contentId-3476422657&collection=contentId-3476422657), 3.3.1.1, and 3.4.1.1 Process Diagrams.

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-289 - MDM to ATO | [Functional Specification - EAII-289 - MDM Supplier to ATO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3476422657/Functional+Specification+-+EAII-289+-+MDM+Supplier+to+ATO) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

  - JSON for REST web service response format (consumer-facing)
  - XML for ATO backend response format (ATO REST endpoints return XML)
  - REST for both inbound (consumer to APIM) and outbound (APIM to ATO) communication protocols
  - XSLT for XML-to-canonical-JSON transformation within APIM policies

**Adoption of Industry standard security best practice:**

  - OAuth2 for API authentication and authorization (inbound - consumer applications to APIM)
  - Azure Managed Identity for APIM to Key Vault authentication
  - ATO API credentials stored in data-specific Azure Key Vaults

## 4.3 Required Components

The following components are required for this integration:

  - Azure API Management service (APIM) — API gateway handling routing, input validation, backend proxying, XML-to-JSON transformation, security, and audit logging
  - Azure Key Vault (data-specific) — for storing ATO REST API authentication credentials
  - Azure Application Insights — for platform-level logging and monitoring
  - Azure Log Analytics workspace — for operational monitoring
  - Azure Virtual Network — for network isolation
  - SMC — Custom Monitoring Tool (observability via APIM diagnostics and tracked properties for success/failure logging)

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DEV)
- System Integration Testing (SIT)
- User Acceptance Test (UAT)
- Production (PROD)

### 4.5 Non-Functional Requirements

| **NFR Category** | **Requirement** | **Target** |
| --- | --- | --- |
| Availability | Service uptime during business hours | 95% (Silver SLA) |
| Availability | APIM platform SLA | 99.95% (Standard/Premium tier) |
| Response Time | P95 end-to-end latency (consumer to consumer) | < 5 seconds |
| Response Time | Maximum acceptable response time | 10 seconds |
| Throughput | Expected transactions per second (TPS) | < 1 TPS (ad-hoc lookups) |
| Throughput | Peak TPS | < 5 TPS |
| Concurrency | Maximum concurrent requests | 10 |
| Error Rate | Acceptable error rate (excluding ATO faults) | < 1% |
| Monitoring | Alert threshold — error rate | > 10% over 5-minute window |
| Monitoring | Alert threshold — latency | P95 > 5 seconds |
| Data Classification | Response data classification | Public |

#### 4.5.1 Retry Strategy

Retries are **not implemented at the APIM integration layer**. Rationale:

1. **Synchronous request-reply pattern**: The consumer blocks on the HTTP GET call. Retrying within APIM would increase latency for the consumer without visibility into whether the retry is progressing.
2. **Idempotent read operation**: All four operations are GET lookups with no side effects. Retrying at the consumer layer is safe and preferred.
3. **Consumer-managed retries**: Consumer applications are responsible for implementing their own retry logic (e.g. exponential backoff) based on the HTTP status code returned by APIM.
4. **APIM**`forward-request`**timeout**: The default APIM forward-request timeout of 300 seconds applies. If the ATO does not respond within this window, APIM returns an HTTP 504 to the consumer.

**Consumer retry guidance:**

| **HTTP Status** | **Consumer Action** |
| --- | --- |
| 200 | Success — no retry needed |
| 400 | Client error — do not retry (fix input) |
| 500 | Server error — retry with backoff |
| 502 | ATO backend error — retry with backoff |
| 504 | ATO timeout — retry with backoff |



====================================================================================================
## DOC: TSD-EAII-297
====================================================================================================

# 1 Document Overview

## 1.1 Background

Metcash's supplier onboarding process requires each new supplier to be assigned a unique supplier number before they can be registered in Metcash's supplier agreement systems. The **MDM Supplier Number** integration enables Metcash's Salesforce-based supplier portal (MetConnect) to request a new, unique supplier number from the IBM Master Data Management (MDM) system at the point of agreement creation. If an agreement does not proceed, the reserved supplier number can be released back to MDM to prevent exhaustion of the number range.

This integration is being migrated from the legacy Tibco BusinessWorks platform to Azure Integration Services (AIS). The purpose of this document is to describe the technical implementation of the integration on AIS, achieving equivalent behaviour to the legacy Tibco process while addressing the known issue of API key rotation requiring a service restart.

The integration is classified as **RED** in the Metcash Horizon Impact Assessment, as it connects directly to IBM MDM, which is a HIGH-risk Master Data structure. Any deployment requires review and approval by the Horizon Platform Owner and Business Process Owner.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of **EAII-297 — Get/Release MDM Supplier Number** between **Salesforce** and **IBM MDM**.

## 1.3 Glossary

| **Item** | **Description** |
| --- | --- |
| AgreementID | Identifier for a supplier trading agreement, formatted as a Salesforce Record ID or a Metcash-assigned alphanumeric code |
| AIS | Azure Integration Services — the target integration platform for this migration. |
| IBM MDM | IBM Master Data Management system. Metcash's system of record for supplier and trading term master data, including the generation and management of supplier reference numbers. |
| MetConnect | Metcash's supplier portal, built on the Salesforce platform, used by staff to onboard suppliers and manage supplier agreements. |
| Salesforce | The CRM and portal platform underpinning MetConnect. The `SourceSystemID` value in all API requests from MetConnect is `Salesforce`. |
| Supplier Number | A unique 7-digit number assigned by IBM MDM to identify a supplier within Metcash's systems. The format is a 2-digit prefix (`10`) followed by a 5-digit zero-padded sequence number. |
| SuccessString | The result code returned by IBM MDM for the Release operation, derived from MDM's transaction result code |
| TransactionID | A unique identifier for the API call, passed by the caller or generated by the integration layer. Format observed in samples: `{SalesforceRecordID}_{YYYYMMDDHHmmss}` |
| WS-Security | A SOAP security standard used for authenticating calls to IBM MDM via a UsernameToken header. |

# 2 Scope

## 2.1 In Scope

- Reception of REST API requests (JSON) from the Salesforce-based MetConnect supplier portal via Azure API Management.
- OAuth2 Bearer token authentication for all inbound requests, enforced by APIM.
- Translation of Salesforce REST requests into the IBM MDM SOAP service format (JSON to SOAP/XML) within an Azure Logic App.
- Retrieval of a new, unique supplier number from the IBM MDM `getNextSupplierNumber` SOAP operation.
- Formatting of the final supplier number by prepending the configured prefix (`10`) and zero-padding the MDM sequence number to 5 digits.
- Release of a previously reserved supplier number via the IBM MDM `clearReservedSupplierNumbers` SOAP operation.
- Translation of IBM MDM SOAP responses back to the Salesforce REST JSON format.
- Audit logging of all request and response events to the Metcash SMC audit service.
- Return of structured error responses on authentication failure (HTTP 401) or MDM processing errors (Return MDM error codes).

## 2.2 Out of Scope

- Maintenance of supplier contracts, agreements, or trading terms in IBM MDM (the MDM service exposes these operations, but they are not invoked by this integration).
- Searching for supplier contracts or agreements in IBM MDM.
- Retrieval of agreement numbers.
- Any downstream processing once the supplier number is returned to the calling portal (e.g., Salesforce-side storage or further provisioning).
- Bulk or batch supplier number operations.
- Migration of historical audit or transaction data from the Tibco platform.

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

The following principles will apply:

| **Code** | **Principle** | **Why It Applies** |
| --- | --- | --- |
| **IDP-001** | **Generic and Reusable** | The APIM layer exposes a standardized REST interface that is independent of the underlying backend implementation. The Logic App implements a reusable request–response orchestration pattern. |
| **IDP-002** | **Decoupled Integrations** | APIM separates consumer applications from the integration implementation, while the Logic App isolates the external REST/JSON contract from the backend service contract. Backend interface or payload changes can be accommodated within the integration layer without impacting consuming applications. |
| **IDP-003** | **Integrated Security** | Authentication and authorization are enforced at APIM using OAuth 2.0 bearer tokens. Sensitive credentials are securely stored in Azure Key Vault and accessed through Managed Identity, ensuring they are never hardcoded or exposed in logs. All communication between integration components is secured using HTTPS/TLS. |
| **IDP-004** | **Standardization** | The solution follows Metcash Azure Integration Services standards by using REST/JSON over HTTPS for external interfaces, adhering to established Azure resource naming conventions, and implementing consistent logging, monitoring, and deployment practices across the platform. |
| **IDP-005** | **Resilient and Recoverable** | The solution incorporates built-in resiliency features, including fault handling, retry mechanisms where appropriate, and graceful error responses for downstream failures. Azure platform services provide high availability, while integration workflows are designed to recover from transient failures without affecting consumers. |
| **IDP-006** | **Observability** | End-to-end monitoring is provided through Application Insights and SMC, capturing request and response details, correlation identifiers, execution metrics, and exception information. This enables proactive monitoring, efficient troubleshooting, and operational support across the integration lifecycle. |

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

| **Pattern Name** | **Implementation Description** |
| --- | --- |
| **Azure Logic Apps** | Azure Logic Apps are used to implement integration workflows is designed to be stateless, modular, and focused on a single business capability, enabling easier maintenance and extensibility. |
| **API Management Service** | Azure API Management (APIM) acts as the API gateway, securely exposing Logic App endpoints to Salesforce To MDM. APIM abstracts the backend implementation, enabling versioning, and policy enforcement without impacting consumers. |
| **Retry and Resilience** | Azure API Management (APIM) retry policies and timeout controls to handle transient failures when interacting with logic apps. |
| **Logging and Observability** | Logging and telemetry are captured using **Application Insights** and **SMC**, providing visibility into request execution, response status, correlation IDs, and exception details. This enables effective monitoring, troubleshooting, and operational support. |
| **Security Abstraction** | Security is enforced at the API layer using APIM policies. Secrets and credentials required for backend access are stored securely in **Azure Key Vault** and accessed via Managed Identity. The solution is designed to support OAuth-based authentication, aligning with Gen-3 security standards and eliminating hardcoded credentials. |
| **Standard and Governance** | All interfaces comply with Metcash integration standards, including consistent API naming conventions, standardized error handling, and structured JSON responses. |

- Information related to all Standards, Guidelines and Patterns refer
  - [Guidelines](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1668874252/Guidelines)
  - [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

![image-20260715-010227.png](images/07.png)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-297 - **EAII-297 - Metconnect To Supplier MDM - Get/Release Supplier Number** | [Functional Specification - EAII-297 - Metconnect to Supplier MDM - Get/Clear Supplier Number](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3533865218/Functional+Specification+-+EAII-297+-+Metconnect+to+Supplier+MDM+-+Get+Clear+Supplier+Number) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol
- WSDL 1.1 for SOAP web service contract
- SOAP 1.2 for SOAP web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization

## 4.3 Required Components

| **Component** | **Purpose / Description** |
| --- | --- |
| **Azure App Service Plan** | Hosts the Azure Logic Apps Standard workflows that implement the integration services. |
| **Azure Virtual Network (VNet)** | Provides network isolation for the integration platform. Private endpoints ensure secure access to Azure resources such as Logic Apps and Azure Key Vault, preventing public network exposure. |
| **Azure Key Vault** | Securely stores application secrets, certificates, and configuration values, including OAuth2 credentials, backend service credentials, TLS certificates, and other sensitive parameters. All secrets are accessed using Managed Identity. |
| **Azure Application Insights** | Collects application telemetry, execution metrics, dependency tracking, and exception details from Logic App workflows. Supports operational monitoring, diagnostics, and alerting. |
| **Azure Log Analytics Workspace** | Centralizes logs from Application Insights and Azure resources, enabling advanced querying, monitoring, and alert generation for operational support. |
| **Azure Logic Apps (Standard)** | Implements the integration workflows, including request validation, data transformation, backend service orchestration, response mapping, exception handling, and audit logging. |
| **Azure API Management (APIM)** | Provides the external API gateway, exposing REST endpoints to consumers. APIM performs authentication and authorization, request validation, rate limiting, routing, and policy enforcement before forwarding requests to the Logic Apps. |

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DV1)
- System Integration Testing (ST1)
- User Acceptance Test (UT1)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).



====================================================================================================
## DOC: TSD-EAII-301_302_516_517
====================================================================================================

# 1 Document Overview

## 1.1 Background

This document provides the Technical Specification for four integration interfaces—EAII-301, EAII-517, EAII-516, and EAII-302—that distribute supplier contract data from Supplier MDM (IBM MDM) to EIM, ALM Sorted, Food Sorted, and STIBO STEP PIM.

All four interfaces are implemented on **Azure Function App (isolated worker, .NET 10)** for per-interface message processing, transformation, and delivery, hosted in the same Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`). No Logic Apps are used.

A reference/identifier arrives on a dedicated Azure Service Bus subscription. The integration calls the MDM REST API to retrieve the full supplier contract data, transforms it, and delivers it to the target system. The Service Bus message carries the identifier or blob pointer; the full payload is fetched live from MDM per message. EAII-302 is a distinct legacy TIBCO service consuming its own dedicated JMS queue, but follows the identical blob-pointer/Service Bus pattern established for EAII-301/517/516 and is built into the same repo/Function App.

## 1.2 Document Purpose

The purpose of this document is to define the technical specifications, requirements, design considerations, and implementation steps for distributing supplier contract data from Supplier MDM to EIM (EAII-301), STIBO STEP PIM (EAII-302), Food Sorted (EAII-516), and ALM Sorted (EAII-517).

## 1.3 Glossary

| Term | Description |
| --- | --- |
| Supplier MDM | IBM Master Data Management platform and source of truth for supplier legal entity and contract data. |
| MDM REST API | HTTP interface exposed by Supplier MDM. |
| EIM | Enterprise Information Management platform receiving pipe-delimited flat files. |
| ALM Sorted | Sorted Marketplace liquor platform receiving JSON supplier data. |
| Food Sorted | Sorted Marketplace food platform receiving JSON supplier data. |
| STIBO STEP PIM | Product Information Management platform receiving a STEP-ProductInformation XML supplier hierarchy (EAII-302). |
| OAuth 2.0 | Authorisation protocol (client_credentials grant) used to obtain a bearer token for the STIBO STEP PIM API (EAII-302 only). |
| Azure Service Bus | Topic-based pub/sub service with a dedicated subscription per interface. |
| Azure Function App | Isolated-worker .NET 10 integration runtime. |
| SAMI | System-Assigned Managed Identity. |
| SMC | System Monitoring & Control Gen 3 for audit, logging, and exception management. |
| AIS | Azure Integration Services. |
| EAII | Enterprise Application Integration Interface. |
| mTLS | Mutual TLS using a client certificate. |
| DLQ | Dead Letter Queue. |
| GoAnywhere | Managed File Transfer solution used for onward EIM delivery. |
| Poison message | A message that cannot be processed successfully and is dead-lettered according to the interface's failure policy. |

## 2 Scope

![Interface Scope Overview-20260825-092754.png](images/02.png)

### 2.1 In Scope

- **EAII-301:** Supplier MDM to EIM as a pipe-delimited flat file via Azure Blob Storage.
- **EAII-302:** Supplier MDM to STIBO STEP PIM as a STEP-ProductInformation XML supplier
- **EAII-516:** Supplier MDM to Food Sorted via REST/JSON.
- **EAII-517:** Supplier MDM to ALM Sorted via REST/JSON.
- Service Bus subscription consumption, MDM retrieval, transformation, and target delivery.
- SMC Gen 3 onboarding for audit, logging, and exception management.
- Azure Key Vault integration for secrets and credentials.
- Azure Managed Identity for Azure service-to-service authentication.
- In-message EIM deduplication of repeated reference-data values.

### 2.2 Out of Scope

- Changes to the MDM, ALM Sorted, or Food Sorted APIs.
- Upstream JMS-to-Service Bus bridging.
- Cross-message EIM deduplication.

## 3 Compliance

### 3.1 Architecture Principles

| Code | Principle | Application |
| --- | --- | --- |
| IDP-001 | Generic and Reusable | Shared `Metcash.AIS.Data.MDMSupplierInfo.Common` library provides the MDM client, SMC wrapper, retry policy, and Key Vault access. |
| IDP-002 | Decoupled Integrations | A shared Service Bus topic with independent subscriptions isolates the four interfaces. |
| IDP-004 | Resilient and Recoverable | All four interfaces retry target delivery in-process and dead-letter failures immediately on exhaustion or unhandled exception, guaranteeing no silent message loss. EAII-302 additionally carries a Gold SLA / RED-RED Horizon classification requiring no message loss end-to-end. |
| IDP-005 | Observability | Full end-to-end observability is delivered via SMC Gen 3 (single-call `StartObservation` with `IsObservationComplete = true` per invocation) and Azure Application Insights (`TrackEvent`, `TrackException`, dependency telemetry). |

*Reference:*[Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

## 3.2 Standards, Guidelines and Patterns

| Pattern Name | Implementation Description |
| --- | --- |
| Azure Function App | All three interfaces are implemented as Service Bus–triggered Azure Functions (isolated worker, .NET 10), hosted on a single shared Function App per environment. Each function is stateless, modular, and focused on a single business capability. |
| API Management Service | Azure API Management (APIM) is used only as the SMC gateway for `StartObservation` calls — it does not front the Function App's inbound trigger. |
| Retry and Resilience | Retry and resilience are interface-specific in mechanics, but uniform in outcome: all four interfaces dead-letter on failure, with no reliance on Service Bus redelivery. **EAII-301** dead-letters immediately on PartyId-not-found, MDM retrieval failure, or transformation failure; its Blob upload step is additionally retried in-process up to 3 attempts with a fixed 2-second delay before dead-lettering on exhaustion. **EAII-517, EAII-516, and EAII-302** use a shared two-tier model: the target HTTP POST (ALM Sorted / Food Sorted / STIBO STEP PIM respectively) is retried in-process up to 3 attempts with a fixed 2-second delay, and the Service Bus executor then completes the message on success or dead-letters it immediately on failure during the first delivery attempt. Service Bus redelivery is not used for EAII-517/516/302. |
| Logging and Observability | Application Insights (`TrackEvent`/`TrackException`/dependency calls) and SMC (single complete observation per invocation), providing visibility into execution, response status, correlation IDs, and exception details. |
| Security Abstraction | Secrets and credentials are stored in Azure Key Vault and accessed via the Function App's System-Assigned Managed Identity. MDM requires no authentication — a plain, unauthenticated REST PUT. ALM Sorted requires no client certificate or authentication. Food Sorted uses mTLS certificate-based authentication, with the client certificate loaded via the platform's trusted root certificate configuration. STIBO STEP PIM (EAII-302) uses OAuth 2.0 bearer token authentication (client_credentials grant), with the client ID/secret stored in Key Vault. |
| Standardization and Governance | All interfaces comply with Metcash integration standards: consistent Azure resource naming, standardized error handling, and structured JSON/flat-file payloads per target contract. |

**Naming Standards — Azure Function App**

| Standard | Detail |
| --- | --- |
| Function App name | `t3-met-mdmsupplierinfo-{env}-ae-func` (env: dv1 / st1 / ut1 / prd) |
| Per-interface function names | `MDMSupplierInfoToEIM` (EAII-301), `MDMSupplierInfoToALMSorted` (EAII-517), `MDMSupplierInfoToSorted` (EAII-516, Food Sorted), `MDMSupplierInfoToPIM` (EAII-302, STIBO STEP PIM) |

**Service Bus — Shared Topic, Per-Interface Subscriptions**

| Standard | Detail |
| --- | --- |
| Topic naming | `data.SupplierInfoFromMDM.{env}.sbt` |
| Subscription naming | `to{target}.{itemtype}` pattern:<br>`toeaim.supplierinfo` (EAII-301), `toalmsorted.supplierinfo` (EAII-517), `tosorted.supplierinfo` (EAII-516), `topim.supplierinfo` (EAII-302) |
| Item-type differentiation | By subscription only — one shared topic across all three interfaces |

**Security Controls**

| Control | Implementation |
| --- | --- |
| Managed Identity | System-Assigned Managed Identity (SAMI) enabled on the Function App in all environments |
| Key Vault | All secrets and credentials in Azure Key Vault; referenced via Key Vault reference syntax in appsettings. Reuses existing AIS and Enabling/SMC vaults |
| RBAC | Least-privilege RBAC; Function App SAMI granted only required roles per resource |
| External API auth | No authentication (plain, unauthenticated REST PUT) for MDM; no authentication for ALM Sorted; mTLS certificate-based authentication for Food Sorted; OAuth 2.0 bearer token (client_credentials grant) for STIBO STEP PIM (EAII-302). |
| Secret hygiene | No secrets in source code, pipeline variables, or committed appsettings files; all secrets via Key Vault references |

**Environment Segregation**

| Standard | Detail |
| --- | --- |
| Environment identifiers | `dv1` (DEV), `st1` (SIT), `ut1` (UAT), `prd` (PROD) |
| Resource groups | Same as existing (`t3-met-ais-{env}-ae1-rsg-data`) |
| Service Bus namespaces | Non-production: `t1-met-npr-ae-sb-001` · Production: `t1-met-prd-ae-sb-001` — same as existing |
| Function App instances | One per environment (`t3-met-mdmsupplierinfo-{env}-ae-func`); all three interface functions deployed to the same host |

**Error Handling and Monitoring**

| Standard | Detail |
| --- | --- |
| **Retry** | In-process retry policy: up to 3 attempts, fixed 2-second delay, for transient HTTP 5xx / network / timeout errors (or, for EAII-301, transient Blob upload failures); no retry on non-retryable 4xx (e.g. 400, or any 4xx other than 401/403 for EAII-302). |
| **Dead-letter** | All four interfaces dead-letter on failure, on their first and only delivery attempt, with no reliance on Service Bus's own redelivery mechanism. **EAII-517 / EAII-516 / EAII-302**: on the target HTTP POST failing — either the service returning a Failure result or an unhandled exception — the Function executor explicitly dead-letters the message (`ServiceBusMessageActions.DeadLetterMessageAsync`) immediately. **EAII-301**: dead-letters immediately on PartyId-not-found, MDM retrieval failure, or transformation failure; the Blob upload step is retried in-process (as above) before dead-lettering on exhaustion. |
| **SMC observations** | One complete `StartObservation` call (`IsObservationComplete = true`) per Function invocation, always executed in a `finally` block regardless of outcome. `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), grouping each interface's observation for the same source event. |
| **Application Insights** | `TrackEvent` at trigger and completion; `TrackException` on all caught errors; dependency tracking for outbound HTTP calls (MDM, target system, and OAuth token acquisition for EAII-302). |
| **Alerts** | SMC failure-rate alerts per interface; Azure Monitor alerts on DLQ accumulation and Function error rate. EAII-302's Gold SLA / RED-RED Horizon classification warrants DLQ-accumulation alerting at the same or higher priority than EAII-517/516. |

Information related to all Standards, Guidelines and Patterns refer

- [Guidelines](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1668874252/Guidelines)
- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

## 4 Requirements Overview

### 4.1 Business Process Requirement and Integration

Supplier MDM is the source of truth for supplier legal entities, pay-to and buy-from relationships, agreements, terms, rebates, and category splits. When data changes, independent channels distribute the updated contract data to downstream consumers.

- **EIM:** receives 11 pipe-delimited record types for warehousing and reporting.
- **ALM Sorted:** receives a JSON supplier entity through a REST API.
- **Food Sorted:** receives a JSON supplier entity through a REST API.
- **STIBO STEP PIM:** receives a STEP-ProductInformation XML supplier hierarchy through a REST API, OAuth 2.0 authenticated (EAII-302).

Each message contains a lightweight reference or blob pointer. The Function retrieves the full Reference Message XML where required, calls MDM, transforms the response, and delivers the target-specific output.

Relevant documents:

| **Title** | **Link** |
| --- | --- |
| Relevant document 1 | [Functional Specification - EAII-301, EAII-517, EAII-516 - Supplier MDM to EIM, ALM Sorted, Food Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035496449/Functional+Specification+-+EAII-301+EAII-517+EAII-516+-+Supplier+MDM+to+EIM+ALM+Sorted+Food+Sorted) |
| Relevant document 2 | [Mapping Manifest - EAII-301, EAII-517, EAII-516 - Supplier MDM to EIM, ALM Sorted, Food Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519447059/Mapping+Manifest+-+EAII-301+EAII-517+EAII-516+-+Supplier+MDM+to+EIM+ALM+Sorted+Food+Sorted) |
| Relevant document 3 | [Mapping - EAII-301 - Supplier Contract to EIM - Supplier MDM to EIM](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519774730/Mapping+-+EAII-301+-+Supplier+Contract+to+EIM+-+Supplier+MDM+to+EIM) |
| Relevant document 4 | [Mapping - EAII-517, EAII-516 - Supplier Contract to ALM Sorted, Food Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519381529/Mapping+-+EAII-517+EAII-516+-+Supplier+Contract+to+ALM+Sorted+Food+Sorted) |
| Relevant document 5 | [Functional Specification - EAII-302 - Supplier MDM to STIBO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035529217/Functional+Specification+-+EAII-302+-+Supplier+MDM+to+STIBO) |
| Relevant document 6 | [Mapping - EAII-302 - Supplier Contract (MDM) to PIM (STIBO)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3495985203/Mapping+-+EAII-302+-+Supplier+Contract+MDM+to+PIM+STIBO) |

### 4.2 Technical Standards and Requirements

- XML for MDM request/response envelopes.
- JSON for ALM Sorted, Food Sorted, and SMC payloads.
- Pipe-delimited flat files for EIM.
- HTTPS/TLS 1.2+ for outbound communication.
- Azure Service Bus topic and subscriptions.
- Azure Function App isolated worker on .NET 10.
- Azure Key Vault for secrets.
- SMC Gen 3 for centralized monitoring.

### 4.3 Required Components

- Azure Function App and App Service Plan.
- Azure Service Bus topic with three subscriptions.
- Azure Virtual Network and private endpoints.
- Existing AIS and Enabling/SMC Key Vaults.
- Application Insights and Log Analytics.
- Existing Storage Account (`t3data{env}aesta01`), container `eim`, path `toeim/supplierinfo`.
- Existing Storage Account (`t3data{env}aesta01`) for the inbound JMS publisher payload.
- Existing APIM instance for SMC.
- GoAnywhere MFT for EAII-301 onward delivery.
- OAuth 2.0 client credentials and token endpoint for STIBO STEP PIM (EAII-302 only).

### 4.4 Environmental Requirement

| Environment | Suffix | Purpose |
| --- | --- | --- |
| DEV | `dv1` | Development and integration testing |
| SIT | `st1` | System Integration Testing |
| UAT | `ut1` | User Acceptance Testing |
| PROD | `prd` | Production |

Aligns with the AIS Governance Environments Strategy . [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy)

## 5 Integration Overview and Implementation

### 5.1 EAII-301 — Supplier MDM to EIM

#### 5.1.1 As-is Process

#### 5.1.1.1 Description of Process(es)

When a supplier contract change occurs in Supplier MDM, a lightweight reference message (not the full payload) is placed on a dedicated message queue (`Service.MDM.SupplierContractEIM.Q`, bridged from topic `Service.MDM.TradingAccount.T`, selector `INTERFACECODE='MDMSUPCNT001'`). The legacy integration processes it through: message receipt with client-mode acknowledgement → MDM REST API retrieval (full supplier contract data, XML namespaces stripped from the request) → duplicate record detection (dedup of repeated reference-data values within the message) → data transformation into 11 pipe-delimited flat-file record types → file assembly and upload to Azure Blob Storage, from where GoAnywhere delivers to EIM.

**Authentication (MDM retrieval):** Certificate-based (keystore) + Basic Auth credentials.

**Concurrency:** 1 session (single-threaded) — file sequencing requirement.

**Retry:** Blob storage upload failures retried 3 times at 5-second intervals; on exhaustion, error logged and message acknowledged (not redelivered).

**Known Issue (per FSD §3.1.1.3):** Duplicate record detection operates within a single message only — cross-message deduplication is not handled by this design (see §5.1.5).

**Data classification (per FSD §3.1.5):** Internal. Supplier contract data including business names, ABNs, addresses, and agreement details — not customer-facing PII. Standard internal data handling; encrypt in transit (TLS); no special masking beyond standard credential protection.

#### 5.1.1.2 Process Flow Diagram

![image-20260714-010653.png](images/05.png)

#### 5.1.2 Proposed Process

#### 5.1.2.1 Description of Process(es)

A supplier contract change produces a lightweight reference message. The legacy process retrieves the full MDM contract, performs in-message duplicate detection, transforms it into 11 pipe-delimited record types, assembles a file, and uploads it for GoAnywhere delivery to EIM.

The 11 record types are:

1. `REF_MDM_PARENT_COMPANY`
2. `REF_MDM_LEGAL_ENTITY`
3. `REF_MDM_LEGAL_IDENTIFIER`
4. `REF_MDM_INDIVIDUAL`
5. `REF_MDM_SUPPLIER_PAY_TO`
6. `REF_MDM_SUPPLIER_BUY_FROM`
7. `REF_MDM_AGREEMENT`
8. `REF_MDM_AGREEMENT_GROUP`
9. `REF_MDM_CATEGORY_SPLIT`
10. `REF_MDM_REBATE`
11. `REF_MDM_TERM`

A blob-created pointer message arrives on our Service Bus subscription (`toeaim.supplierinfo`, on the shared topic — see §3.2). The message body references a blob in Azure Blob Storage containing the full Reference Message XML — the JMS publisher writes the payload to blob and publishes only the pointer to Service Bus (adopted after the inbound reference-message payload size began exceeding what Service Bus carries inline).

`MDMSupplierInfoToEIM` (Function trigger) receives the pointer message, downloads the Reference Message XML from Blob Storage, then calls the MDM REST API to retrieve the complete supplier contract data.

Duplicate record detection — reference-data fields that may repeat across contract components (category names, department names, status descriptions, payment methods, etc.) are extracted and deduplicated within the message before transformation.

The deduplicated MDM data is transformed into 11 pipe-delimited flat-file record types (same set as legacy — see §5.1.1.1's list, reproduced in full in the mapping document): REF_MDM_PARENT_COMPANY, REF_MDM_LEGAL_ENTITY, REF_MDM_LEGAL_IDENTIFIER, REF_MDM_INDIVIDUAL, REF_MDM_SUPPLIER_PAY_TO, REF_MDM_SUPPLIER_BUY_FROM, REF_MDM_AGREEMENT, REF_MDM_AGREEMENT_GROUP, REF_MDM_CATEGORY_SPLIT, REF_MDM_REBATE, REF_MDM_TERM.

The assembled flat file is uploaded to Azure Blob Storage — container `eim`, path `toeim/supplierinfo` (see §6.1.1 for full storage detail) — from where GoAnywhere picks it up for onward delivery to EIM.

Output filename convention: `MDS_{SUPPLIER_PAY_TO_NUMBER}_{TIMESTAMP}.{CorrelationId}.txt` — adapts the legacy pattern (`ProcessInstanceId` → `CorrelationId` in the same position).

On success: message completed (removed from subscription).

#### 5.1.2.2 Process Flow Diagram

![EAII-301 Process Flow-20260825-092814.png](images/10.png)

1. Upstream JMS→Service Bus bridging delivers a blob-created pointer message to subscription `toeaim.supplierinfo` (out of scope for this build — see §2.2). The Reference Message payload itself is written to Blob Storage by the publisher; only the pointer arrives on the subscription.
2. `MDMSupplierInfoToEIM` Function is triggered (pull trigger).
3. The Function downloads the Reference Message XML from Blob Storage using the blob pointer, then calls the MDM REST API (PUT, no authentication) with the PartyId/reference extracted from that message.
4. MDM returns the full supplier contract XML.
5. The MDM response is deduplicated within the current message only. The MDM response often repeats the same coded reference values (category names, department names, status descriptions, payment methods) across multiple line items — these are resolved once per unique code and reused, rather than resolved separately each time. This only cleans up repeats inside one response for one message; it does not detect or prevent the same supplier change arriving twice across separate messages.
6. Data is transformed into the 11 pipe-delimited record types.
7. The assembled flat file is uploaded to Blob Storage (`eim/toeim/supplierinfo`). Filename convention: `MDS_{SUPPLIER_PAY_TO_NUMBER}_{TIMESTAMP}.{CorrelationId}.txt`.
8. On success, the Service Bus message is completed.
9. On MDM retrieval failure, transformation failure, or blob upload failure (after retry exhaustion), the message is dead-lettered immediately — matching the guaranteed-delivery pattern used by EAII-517/EAII-516/EAII-302.
10. Blob upload is retried up to three times with a two-second delay before the message is dead-lettered on exhaustion.

#### 5.1.2.3 Sequence Diagram

![image-20260826-191335.png](images/04.png)

#### 5.1.2.4 PlantUML

```
@startuml EAII-301-Supplier-MDM-to-EIM
title EAII-301 — Supplier MDM to EIM (Proposed Process)

actor "Supplier MDM\n(IBM MDM)" as MDM
queue "TIBCO EMS Queue\nService.MDM.SupplierContractEIM.Q" as JMSQ
participant "JMS Publisher\nFunction App:\nt3-met-sharedservicescommon-{env}-ae-func\n(config-driven timer poll)" as Publisher
participant "Storage Account:\nt3data{env}aesta01\n(inbound JMS payload)" as BlobIn
participant "Service Bus Namespace:\nt1-met-{npr|prd}-ae-sb-001\nTopic: data.SupplierInfoFromMDM.{env}.sbt" as SB
participant "Function App:\nt3-met-mdmsupplierinfo-{env}-ae-func\nFunction: MDMSupplierInfoToEIM" as Func
participant "MDM REST API" as MdmApi
participant "Storage Account:\nt3data{env}aesta01\nContainer: eim\nPath: toeim/supplierinfo" as BlobOut
participant "SMC" as SMC

MDM -> JMSQ : publishes TCRMService XML\n(supplier contract change)
Publisher -> JMSQ : polls (timer interval per config)
Publisher -> BlobIn : writes Reference Message payload\n(blob-pointer route, TargetType=Both)
Publisher -> SB : publishes Event Grid-shaped pointer\n{data.url, eventType, ...}\nApplicationProperties: INTERFACECODE=MDMSUPCNT001

SB -> Func : deliver to subscription\ntoeaim.supplierinfo\n(SQL filter: INTERFACECODE='MDMSUPCNT001')
Func -> BlobIn : download Reference Message XML\n(via pointer's data.url)
Func -> MdmApi : call MDM REST API (PartyId/reference)
MdmApi --> Func : supplier contract response

Func -> Func : deduplicate within message\n(MetcashReferenceDataBObj keyed lookup)
Func -> Func : transform to 11 pipe-delimited\nrecord types

alt MDM retrieval OR transform fails
    Func -> SMC : log observation (Failed)
    Func -> SB : dead-letter message (toeaim.supplierinfo/$DeadLetterQueue)
else success
    loop up to 3 attempts, 2s delay
        Func -> BlobOut : upload output file\nMDS_{SUPPLIER_PAY_TO_NUMBER}_{TIMESTAMP}.{CorrelationId}.txt
        alt upload succeeds
            Func -> SMC : log observation (Success)
            Func -> SB : complete message
        else upload fails
            note right: retry, else dead-letter\nafter 3 attempts exhausted
        end
    end
end

@enduml
```

#### 5.1.3 Coordination

Fully asynchronous, event-driven. One message per invocation, no batching. Standard default Azure Function App / Service Bus trigger concurrency applies; no artificial concurrency limit is applied in the proposed design (applies identically to EAII-517, EAII-516, and EAII-302).

##### 5.1.3.1 Transaction Boundaries

One Service Bus message = one MDM retrieval call = one output (flat file for EAII-301; target HTTP POST for EAII-517/516/302). No cross-message transaction; deduplication (where applicable) is scoped to the single message being processed (§5.1.5).

##### 5.1.3.2 State Management

Stateless per invocation — no state is persisted between messages. This is a direct implication of the in-message-only dedup scope (§5.1.5): there is nothing to look up or update in a prior-state store.

#### 5.1.4 GoAnywhere Requirements

| Field | Value |
| --- | --- |
| Interface ID | EAII-301 |
| Interface | `MDM_to_EIM_SupplierContract` |
| Source | Supplier MDM via Function App |
| Target | EIM via GoAnywhere |
| Source/target protocol | Azure Blob over HTTPS |
| Container/path | `eim/toeim/supplierinfo` |
| Filename | `MDS_{SUPPLIER_PAY_TO_NUMBER}_{TIMESTAMP}.{CorrelationId}.txt` |

#### 5.1.5 Design Considerations

Duplicate detection is replicated exactly within a single message. Repeated reference-data values such as category names, department names, status descriptions, and payment methods are deduplicated before file assembly, via a keyed lookup against the Reference Message's own `MetcashReferenceDataBObj/ReferenceCodeTypeBObj` entries. Cross-message deduplication is not included.

#### 5.1.6 Service High-Level Design

##### 5.1.6.1 Component List

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts `MDMSupplierInfoToEIM` (and the other three interfaces' functions — shared host: EAII-517, EAII-516, EAII-302). |
| Azure Service Bus Subscription (`toeaim.supplierinfo`, on shared topic) | `Microsoft.ServiceBus/topics` | Delivers the reference message. |
| MDM REST API | N/A | Supplier contract data retrieval — no authentication (plain REST PUT). |
| Azure Blob Storage (`eim/toeim/supplierinfo`) | `Microsoft.Storage/storageAccounts` | Output flat-file location, monitored by GoAnywhere. Reuses existing `t3data{env}aesta01` account. |
| Azure Key Vault (AIS + Enabling) | `Microsoft.KeyVault/vaults` | SMC subscription key, PIM OAuth client credentials (EAII-302) — existing vaults, reused. |
| Application Insights / SMC (via APIM) | N/A | Observability — see §3.2 Error Handling and Monitoring. |

##### 5.1.6.2 Services

- `MDMSupplierInfoToEIM` (Function trigger) — Service Bus pull-triggered entry point using standard default trigger concurrency.
- `MDMSupplierInfoToEIM` service (business logic) — Calls the MDM REST client, runs dedup, transforms to the 11 record types, assembles the flat file, uploads to Blob.
- Shared `MdmService` (library, shared with EAII-517/516/302) — Builds the MDM request, sends the unauthenticated REST PUT, parses the response.
- In-message dedup logic — deduplicates repeated reference-data values, scoped per invocation (no persisted state — see §5.1.3.2).
- `SupplierContractToEimTransformService` — MDM XML → 11 pipe-delimited record types, per the mapping document.

##### 5.1.6.3 Audit, Logging & Exceptions

###### 5.1.6.3.1 Logging

As per the SMC specification, the following information is logged.

Interface IDs = EAII-301 (Supplier MDM → EIM), EAII-517 (Supplier MDM → ALM Sorted), EAII-516 (Supplier MDM → Food Sorted), EAII-302 (Supplier MDM → STIBO STEP PIM)

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and completes the observation for a single Function invocation in one call — `IsObservationComplete = true` is always set, since each of our four interfaces makes exactly one MDM retrieval + one delivery attempt per message (no multi-stage pipeline to report incremental progress on). `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), linking each interface's observation for the same source event. | `{SmcBaseUrl}/{SmcStartObservationApiName}` → `https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1/start-observation` | POST |

###### 5.1.6.3.2 Audit

All critical events and exceptions within the integration interfaces (EAII-301/517/516/302) are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for the Function App (`TrackEvent`/`TrackException`/dependency tracking — see §6.3 Security). |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique correlation ID is generated for each Service Bus message and propagated throughout the entire processing pipeline (MDM retrieval → transformation → delivery). SMC records the lifecycle of each transaction via a single completed observation per Function invocation, enabling end-to-end traceability from the inbound Service Bus trigger through the MDM REST call and delivery to the downstream target (EIM blob, ALM Sorted, Food Sorted, or STIBO STEP PIM).

###### 5.1.6.3.3 Exceptions

| Observation Stage | Failure Scenario | Trigger | Action | Notification |
| --- | --- | --- | --- | --- |
| MDM retrieval | MDM REST API retrieval failure | HTTP error or timeout from MDM REST endpoint | Log error with Transaction ID, PartyId/RequestID context. Dead-letter the message immediately. | Standard DLQ-accumulation alerting (§9.2/monitoring), not a separate email notification. |
| Blob upload | Blob storage upload failure | Error from Azure Blob Storage | Retry up to 3 times with a 2-second fixed delay. On exhaustion, log error and dead-letter the message. | Standard DLQ-accumulation alerting. |
| Transformation | Transformation error | Invalid/unexpected data in MDM message causing mapping failure | Log error with full exception details and correlation identifiers. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |

#### 5.1.7 SMC Onboarding and Load

#### 5.1.7.1 Integration Onboarding

| Field | Value |
| --- | --- |
| Interface ID | EAII-301 |
| Interface Name | `MDMSupplierInfoToEIM` |
| Source Application | Supplier MDM |
| Destination Application | EIM |
| Interface Type | Async, event-driven, single-threaded |
| Interface DataStore | Azure Blob Storage (`eim/toeim/supplierinfo`) |
| Reference Keys | CorrelationId, PartyId, RequestID |

| Interface ID | EAII-301 |
| --- | --- |
| Interface name | `MDMSupplierInfoToEIM` |
| Source | Supplier MDM |
| Destination | EIM |
| Type | Async, event-driven |
| Data store | Azure Blob Storage |
| Reference keys | CorrelationId, PartyId, RequestID |
| Average volume | 10–15 messages/day |
| Observations | 1 complete observation per message |

#### 5.1.8 Monitoring

Application Insights telemetry and one SMC Gen 3 observation per invocation.

#### 5.1.9 Reporting

No bespoke reporting required.

#### 5.1.10 Integration and Testing Requirements

#### 5.1.10.1 Development and Integration Strategy

Standard Function App development lifecycle: local development against sample MDM request/response payloads (`inbox/MDM_Request_Response_Sample/`), deployed per-environment via the existing AIS pipeline pattern.

#### 5.1.10.2 Unit Testing

| ADO Test Case ID | Description |
| --- | --- |
| EAII-301-UT-01 | Happy path — successful MDM retrieval, correct 11-record transformation, successful blob upload |
| EAII-301-UT-02 | MDM retrieval failure (timeout/HTTP error) — error logged with Transaction ID/PartyId/RequestID, message acknowledged (not redelivered) |
| EAII-301-UT-03 | Blob upload failure — retried 3×/5s, then acknowledge-and-log on exhaustion |
| EAII-301-UT-04 | Transformation error (malformed/unexpected MDM data) — logged with full exception + correlation IDs, message acknowledged |
| EAII-301-UT-05 | **In-message deduplication** — source MDM data contains repeated reference values (e.g. duplicate category/department names); verify output flat file contains only unique values within that message |
| EAII-301-UT-07 | SMC `StartObservation` failure — flow continues unblocked |
| EAII-301-UT-08 | Output filename convention — verify `MDS_{PayToNumber}_{Timestamp}.{CorrelationId}.txt` pattern is produced correctly |

### 5.2 EAII-302 — Supplier MDM to STIBO STEP PIM

#### 5.2.1 As-is Process

#### 5.2.1.1 Process Description

The interface is event-driven. When a supplier contract is created or amended in IBM MDM, MDM publishes an XML message to Metcash's message-broker infrastructure. A dedicated inbound channel (Supplier Contract message channel) delivers the message to the integration platform.

On receipt, the integration platform assigns a correlation identifier — reusing any transaction identifier carried on the inbound message so that events can be tied back to the originating MDM change, or generating a new identifier when none is supplied. It then transforms the MDM payload from its native TCRMService representation into the STEP-ProductInformation XML that PIM expects, mapping the supplier and its contract components into a classification hierarchy under the Australian context and Main workspace.

Before calling PIM, the integration platform acquires an OAuth 2.0 access token from the PIM authorization server using the client_credentials grant. Access tokens are held in memory and reused until they are close to expiry, so that a token request is only made when strictly necessary. The STEP payload is then sent to the PIM Supplier Hierarchy REST endpoint by HTTPS POST, carrying the token as a Bearer authorisation header.

PIM signals successful acceptance with an HTTP 202 response. On acceptance, the interface publishes a success event to the Corporate Logging channel and acknowledges the inbound MDM message so it will not be redelivered. If PIM returns any other response or the call fails, the interface retries a bounded number of times with a fixed pause between attempts. If the retry budget is exhausted without acceptance, the interface publishes an error event to the Corporate Logging channel, notifies Integration Support, and returns the source message to the platform's poison-message handling.

Every request, response and error is logged to the Corporate Logging Event channel with the correlation identifier so that operations staff can trace an individual supplier update end-to-end.

#### 5.2.1.2 Known Issues

- **OAuth discovery on every token refresh.** The legacy integration derives the OAuth token endpoint URL by calling the OpenID Connect discovery endpoint (`.well-known/openid-configuration`) each time the cached token is close to expiry, then posts the client credentials to the discovered token endpoint. This adds a network round-trip to every token refresh even though the token endpoint does not change between refreshes.
  - **Legacy mechanism:** Two sequential HTTP calls per token refresh (discovery + token grant), driven by a shared-variable cache with a 60-second expiry buffer.
  - **Alternative approach for AIS:** Configure the token endpoint URL directly, or use the platform's built-in OAuth 2.0 client which handles discovery, caching and refresh natively.
  - **Impact on source/target systems:** None. The change is entirely internal to the integration platform. STIBO STEP continues to expose the same OpenID Connect discovery document; the integration simply chooses to bypass it once the token endpoint is known.

#### 5.2.1.3 **Process Flow Diagram**

![image-20260703-000007.png](images/16.png)

A supplier contract change in IBM MDM publishes a `TCRMService` XML message onto a dedicated legacy queue (`Service.MDM.SupplierContractPIM.Q`, distinct from the EIM/ALM/Food Sorted queues). The legacy TIBCO process assigns a correlation identifier, transforms the message into a STEP-ProductInformation XML supplier hierarchy, acquires an OAuth 2.0 bearer token, and POSTs the payload to the STIBO STEP PIM Supplier Hierarchy REST endpoint. PIM signals acceptance with HTTP 202. On transient failure the legacy process retries up to 3 times with a fixed 30-second backoff; on persistent failure the inbound message is routed to poison-message handling and Integration Support is notified.

Both IBM MDM and STIBO STEP PIM are classified **RED** under the Horizon Impact Assessment. The interface carries a **Gold SLA (99.9%)** — no message loss is permitted.

#### 5.2.2 Proposed Process

The flow begins identically to the other three interfaces: a supplier contract change in IBM MDM is published as a `TCRMService` XML message, picked up by the JMS publisher (config-driven timer poll), written as the Reference Message payload to Blob Storage (`t3data{env}aesta01`), and announced as a blob-created pointer event onto the shared Service Bus topic (`data.SupplierInfoFromMDM.{env}.sbt`). The `topim.supplierinfo` subscription — new for EAII-302, added on the existing shared topic — filters and delivers this pointer to the `MDMSupplierInfoToPIM` Function. Dead-lettering on the subscription is configured identically to EAII-517/516.

`MDMSupplierInfoToPIM` downloads the Reference Message XML from Blob Storage using the pointer, then transforms it into a STEP-ProductInformation XML supplier hierarchy. This transform builds a Pay-To Classification carrying the supplier's core attributes plus 5 fixed sub-classifications, nested Buy-From Classifications (each correlated to its own contract component, carrying its own status/name data rather than inheriting the Pay-To component's), pillar cross-references, and a Products section populated only for Agreement Terms that satisfy the qualifying filter (a payment-method or discount-type condition, combined with a matching Contract Component Party Role).

Before delivery, the Function acquires an OAuth 2.0 bearer token via client_credentials grant. Token acquisition performs real two-step discovery — GET the OIDC discovery document at the configured discovery path, parse out the actual `token_endpoint`, then POST the client_credentials grant there — rather than skipping discovery and hitting a hardcoded token endpoint directly. Tokens are cached in memory with a 60-second pre-expiry refresh buffer, so this two-call sequence only runs on cold start or near expiry, not on every message.

With a valid bearer token, the Function POSTs the STEP XML to the PIM Supplier Hierarchy REST endpoint (`https://{PIMHost}:443/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main`), Content-Type `application/xml`. A successful call returns HTTP 202 (Accepted), at which point the Service Bus message is completed.

Delivery failures are handled with the same in-process retry/dead-letter model used by EAII-517/516: up to 3 attempts with a fixed 2-second delay. Any 4xx response other than 401/403 is treated as non-retryable and fails immediately (matching EAII-517/516's HTTP 400 handling); connectivity failures, PIM 5xx responses, and 401/403 authentication rejections are retried within that same 3-attempt budget. On exhaustion — or on an upstream transformation failure that prevents the call from being attempted at all — the message is dead-lettered immediately, with no reliance on Service Bus's own redelivery mechanism, matching the guaranteed-delivery pattern shared by all four interfaces.

Processing is fully asynchronous, event-driven, and stateless: one Service Bus message produces exactly one transform and one PIM delivery attempt, with no cross-message state retained.

#### 5.2.2.2 Process Flow Diagram

![EAII-302 Process Flow-20260825-092829.png](images/17.png)

1. A blob-created pointer arrives on `topim.supplierinfo`.
2. `MDMSupplierInfoToPIM` reads the JMS route config.
3. The publisher writes the payload to Blob Storage (`t3data{env}aesta01`).
4. A blob-created event is raised on the shared Service Bus topic.
5. The event is delivered to the `topim.supplierinfo` subscription.
6. `MDMSupplierInfoToPIM` downloads the Reference Message XML from Blob Storage.
7. The Function transforms the message into the STEP-ProductInformation XML supplier hierarchy.
8. The Function acquires an OAuth 2.0 bearer token and POSTs the STEP XML to the PIM Supplier Hierarchy endpoint.
9. On HTTP 202, the message is completed. On connectivity failure, PIM 5xx, authentication rejection (401/403), business rejection, or transformation failure, the message is dead-lettered.
10. The PIM POST is retried in-process up to three times with a two-second fixed delay before dead-lettering on exhaustion.

#### 5.2.2.3 Sequence Diagram

![image-20260826-191508.png](images/13.png)

#### 5.2.2.4 PlantUML

```
@startuml EAII-302-Supplier-MDM-to-PIM
title EAII-302 — Supplier MDM to STIBO STEP PIM (Proposed Process)

actor "Supplier MDM\n(IBM MDM)" as MDM
queue "TIBCO EMS Queue\nService.MDM.SupplierContractEIM.Q" as JMSQ
participant "JMS Publisher\nFunction App:\nt3-met-sharedservicescommon-{env}-ae-func\n(config-driven timer poll)" as Publisher
participant "Storage Account:\nt3data{env}aesta01\n(inbound JMS payload)" as BlobIn
participant "Service Bus Namespace:\nt1-met-{npr|prd}-ae-sb-001\nTopic: data.SupplierInfoFromMDM.{env}.sbt" as SB
participant "Function App:\nt3-met-mdmsupplierinfo-{env}-ae-func\nFunction: MDMSupplierInfoToPIM" as Func
participant "OAuth Token Service\n(cached, 60s pre-expiry buffer)" as OAuth
participant "PIM OAuth Host\n{PIMHost}\n/auth/.well-known/openid-configuration" as OAuthHost
participant "STIBO STEP PIM\n{PIMHost}\n/restapi/integrationendpoints/\niiep_REST_SupplierHier/upload" as PIM
participant "Key Vault\n(OAuth client_id/client_secret)" as KV
participant "SMC" as SMC

MDM -> JMSQ : publishes TCRMService XML\n(supplier contract change)
Publisher -> JMSQ : polls (timer interval per config)
Publisher -> BlobIn : writes Reference Message payload\n(blob-pointer route, TargetType=Both)
Publisher -> SB : publishes Event Grid-shaped pointer\n{data.url, eventType, ...}\nApplicationProperties: INTERFACECODE=MDMSUPCNT001

SB -> Func : deliver to subscription\ntopim.supplierinfo\n(SQL filter: INTERFACECODE='MDMSUPCNT001')
Func -> BlobIn : download Reference Message XML\n(via pointer's data.url)

Func -> Func : transform to STEP-ProductInformation XML\n(Pay-To Classification + 5 fixed sub-classifications,\nnested Buy-From Classifications with pillar\ncross-references, Products section)

alt cached token valid
    Func -> OAuth : GetAccessTokenAsync(correlationId)
    OAuth --> Func : cached bearer token
else cache expired / cold start
    Func -> OAuth : GetAccessTokenAsync(correlationId)
    OAuth -> KV : read client_id / client_secret
    OAuth -> OAuthHost : GET discovery document\n(/auth/.well-known/openid-configuration)
    OAuthHost --> OAuth : token_endpoint
    OAuth -> OAuthHost : POST client_credentials grant\n(to resolved token_endpoint)
    OAuthHost --> OAuth : bearer token
    OAuth --> Func : bearer token (cached)
end

loop up to 3 attempts, 2s fixed delay
    Func -> PIM : POST STEP-ProductInformation XML\nAuthorization: Bearer {token}\ncontext=Australian&workspace=Main
    alt HTTP 202 Accepted
        Func -> SMC : log observation (Success)
        Func -> SB : complete message
    else HTTP 4xx other than 401/403
        note right: non-retryable — fails immediately
        Func -> SMC : log observation (Failed)
        Func -> SB : dead-letter message
    else HTTP 401/403, 5xx, or connectivity failure
        note right: retryable — retry up to 3 attempts
    end
end

alt all 3 attempts exhausted
    Func -> SMC : log observation (Failed)
    Func -> SB : dead-letter message (topim.supplierinfo/$DeadLetterQueue)
end

@enduml
```

#### 5.2.3 Coordination

Fully asynchronous, event-driven. One message per invocation, no batching. Standard default Azure Function App / Service Bus trigger concurrency applies; no artificial concurrency limit is applied in the proposed design (shared with EAII-301, EAII-517, and EAII-516).

##### 5.2.3.1 Transaction Boundaries

One Service Bus message = one MDM-sourced transform = one PIM delivery attempt (single POST to the STIBO STEP PIM Supplier Hierarchy endpoint). No cross-message transaction.

**5.2.3.2 State Management**

Stateless per invocation — no state is persisted between messages, apart from the in-memory OAuth token cache (60-second pre-expiry refresh buffer), which is a performance optimization, not application state tied to any individual message.

---

**5.2.4 API Endpoint Information**

*(already documented at §5.2.4 in the current TSD — reproduced here for completeness in this section grouping)*

| Field | Value |
| --- | --- |
| Target endpoint | `https://{PIMHost}:443/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main` |
| Method | `POST` |
| Content type | `application/xml` |
| Success response | HTTP 202 (Accepted) |
| Authentication | OAuth 2.0 bearer token (client_credentials grant) in the `Authorization` header only. |

#### 5.2.5 Design Considerations

- OAuth token acquisition uses real two-step discovery (GET the OIDC discovery document, resolve `token_endpoint`, then POST the client_credentials grant), not a hardcoded direct token endpoint. In-memory cache with a 60-second pre-expiry refresh buffer limits how often this sequence runs.
- Duplicate `attr_paytosupplierName` emission is de-duplicated to one occurrence in the AIS build (confirmed legacy defect).
- Buy-From attributes (status date, status, supplier name) read the Buy-From component's own `MTTSupCoreBObj`, correlated by that component's own `ContrComponentId` — not inherited from the Pay-To component (confirmed as-is/intentional).
- `attr_suptermsdiscounttp` is resolved via the same `MetcashReferenceDataBObj/ReferenceCodeTypeBObj` keyed-lookup pattern used elsewhere (EAII-301 §5.1.5), keyed by `CodeType='XCDDISCOUNTTP'` and `DiscountValue`.
- A Product is emitted only when (`PaymentMethodDesc = 'Off Invoice'` OR `DiscountType = '2000008'`) AND a matching Contract Component Party Role (`RoleType = '2000012'`) exists.
- `attr_ImportSupplier`/`attr_DefaultCurrencycode` (new attributes, no legacy precedent) use a first-Agreement-encountered selection rule when a supplier has multiple `MTTAgreementBObj` entries — provisional, pending business confirmation.

**5.2.6 Service High-Level Design**

**5.2.6.1 Component List**

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts `MDMSupplierInfoToPIM` (shared host with EAII-301/517/516). |
| Azure Service Bus Subscription (`topim.supplierinfo`, on shared topic) | `Microsoft.ServiceBus/topics` | Delivers the reference message. |
| STIBO STEP PIM REST API | N/A | Accepts the STEP-ProductInformation supplier hierarchy upload. |
| OAuth 2.0 Authorization Server (PIM) | N/A | Issues client_credentials bearer tokens via OIDC discovery. |
| Azure Key Vault (AIS) | `Microsoft.KeyVault/vaults` | PIM OAuth `client_id`/`client_secret`, SMC subscription key — existing vault, reused. |
| Application Insights / SMC (via APIM) | N/A | Observability — see §3.2 Error Handling and Monitoring. |

**5.2.6.2 Services**

- `MDMSupplierInfoToPIM` (Function trigger) — Service Bus pull-triggered entry point using standard default trigger concurrency.
- `MdmSupplierInfoToPimService` (business logic) — downloads the Reference Message, transforms to STEP XML, acquires an OAuth token, POSTs to PIM, applies retry/dead-letter policy.
- `SupplierContractToPimTransformService` — MDM XML → STEP-ProductInformation XML (Pay-To/Buy-From classifications, Products section), per the mapping document.
- `PimOAuthTokenService` — performs OIDC discovery, acquires and caches the client_credentials bearer token.

**5.2.6.3 Audit, Logging & Exceptions**

**5.2.6.3.1 Logging**

As per the SMC specification, the following information is logged.

Interface ID = EAII-302 (Supplier MDM → STIBO STEP PIM)

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and completes the observation for a single Function invocation in one call — `IsObservationComplete = true` is always set, since this interface makes exactly one transform + one PIM delivery attempt per message. `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), linking this interface's observation with EAII-301/517/516's for the same source event. | `{SmcBaseUrl}/{SmcStartObservationApiName}` → `https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1/start-observation` | POST |

**5.2.6.3.2 Audit**

All critical events and exceptions are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for the Function App. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique correlation ID is generated for each Service Bus message and propagated throughout the entire processing pipeline (transform → OAuth token acquisition → PIM delivery). SMC records the lifecycle of each transaction via a single completed observation per Function invocation.

**5.2.6.3.3 Exceptions**

| Observation Stage | Failure Scenario | Trigger | Action | Notification |
| --- | --- | --- | --- | --- |
| Transformation | Transformation error | Invalid/unexpected data in Reference Message causing mapping failure | Log error with full exception details and correlation identifiers. Dead-letter the message immediately (no PIM call made). | Standard DLQ-accumulation alerting. |
| OAuth token acquisition | Discovery or token request failure | Discovery document unreachable, malformed, or client_credentials rejected | Log error with correlation identifiers. Dead-letter the message immediately (PIM call not attempted). | Standard DLQ-accumulation alerting, at the same or higher priority given the Gold SLA. |
| PIM delivery — authentication rejection | HTTP 401/403 | PIM rejects the bearer token | Retry up to 3 times with a 2-second fixed delay; dead-letter on exhaustion. | Standard DLQ-accumulation alerting, at the same or higher priority given the Gold SLA. |
| PIM delivery — business rejection | HTTP 4xx other than 401/403 | PIM rejects the payload as invalid | Log error, dead-letter immediately (non-retryable). | Standard DLQ-accumulation alerting. |
| PIM delivery — transient failure | Connectivity failure or HTTP 5xx | Network error, timeout, or PIM server error | Retry up to 3 times with a 2-second fixed delay; dead-letter on exhaustion. | Standard DLQ-accumulation alerting, at the same or higher priority given the Gold SLA. |

**5.2.7 SMC Onboarding and Load**

**5.2.7.1 Integration Onboarding**

| Field | Value |
| --- | --- |
| Interface ID | EAII-302 |
| Interface Name | `MDMSupplierInfoToPIM` |
| Source Application | Supplier MDM |
| Destination Application | STIBO STEP PIM |
| Interface Type | Async, event-driven, single-threaded |
| Interface DataStore | N/A (no persistent output store — PIM delivery only) |
| Reference Keys | CorrelationId, PartyId, Contract Component ID |

**5.2.7.2 SMC Load**

| Field | Value |
| --- | --- |
| Interface ID | EAII-302 |
| Interface name | `MDMSupplierInfoToPIM` |
| Source | Supplier MDM |
| Destination | STIBO STEP PIM |
| Type | Async, event-driven |
| SLA | Gold (99.9%) |
| Reference keys | CorrelationId, PartyId, Contract Component ID |
| Average volume | Same source (Supplier MDM) as EAII-301/517/516 — 10–15 messages/day |
| Observations | 1 complete observation per message |

#### 5.2.8 Monitoring

Application Insights telemetry and one SMC Gen 3 observation per invocation. Given the Gold SLA and RED-RED Horizon classification, DLQ accumulation on `topim.supplierinfo` warrants alerting at the same or higher priority than EAII-517/516.

#### 5.2.9 Reporting

No bespoke reporting required.

**5.2.10 Integration and Testing Requirements**

**5.2.10.1 Development and Integration Strategy**

Standard Function App development lifecycle: local development against real sample MDM request/response and STEP-PIM output payloads (`inbox/EAII-302/Attachments/`), deployed per-environment via the existing AIS pipeline pattern.

**5.2.10.2 Unit Testing**

| ADO Test Case ID | Description |
| --- | --- |
| EAII-302-UT-01 | Happy path — successful transform, PIM returns HTTP 202, message completed |
| EAII-302-UT-02 | OAuth discovery failure — discovery document unreachable/malformed, message dead-lettered, no PIM call attempted |
| EAII-302-UT-03 | OAuth token request failure — client_credentials grant rejected, message dead-lettered |
| EAII-302-UT-04 | PIM authentication rejection (401/403) — retried up to 3 times, then dead-lettered on exhaustion |
| EAII-302-UT-05 | PIM business rejection (other 4xx) — non-retryable, message dead-lettered immediately |
| EAII-302-UT-06 | PIM transient failure (5xx/timeout) — retried up to 3 times, then dead-lettered on exhaustion |
| EAII-302-UT-07 | Transformation error (malformed/unexpected MDM data) — message dead-lettered, no PIM call made |
| EAII-302-UT-08 | Multi-Buy-From-component payload — verify each Buy-From classification reads its own status/name data, not Pay-To's |
| EAII-302-UT-09 | No duplicate `attr_paytosupplierName` in output — single occurrence per Pay-To classification |
| EAII-302-UT-10 | Products/Agreement-Terms qualifying filter — verify both OR-branches (`PaymentMethodDesc='Off Invoice'`, `DiscountType='2000008'`) produce a Product when the matching Party Role exists |
| EAII-302-UT-11 | `attr_ImportSupplier` Yes/No branches — `IntendedMarketValue='I'` → `"Yes"`, else `"No"` |
| EAII-302-UT-12 | SMC observation logging — `ParentObservationID` populated from `TRANSACTIONID` (or fallback), one complete observation per invocation |
| EAII-302-UT-13 | OAuth token cache — cold-start (discovery + token) vs. cached-token (no discovery call) scenarios |
| EAII-302-UT-14 | Blob/pointer-extraction failure — malformed or missing blob pointer, message dead-lettered |

### 5.3 EAII-517 — Supplier MDM to ALM Sorted

#### 5.3.1 As-is Process

When a supplier contract change occurs, a lightweight reference message is placed on a dedicated queue for the ALM Sorted target (`Service.MDM.SupplierContractALM.Q`, bridged from topic `Service.MDM.TradingAccount.T`, selector `INTERFACECODE='MDMSUPCNT001'`, queue options `store=$sys.failsafe, redeliveryDelay=300`). The legacy integration: receives the message with client-mode acknowledgement and **redelivery-count tracking** (max 3 — see poison-message handling below) → calls the MDM REST API (same as EAII-301, HTTP `PUT`) → transforms the response into a JSON supplier entity structure → delivers via HTTPS POST to the ALM Sorted supplier endpoint → on success, acknowledges the source message.

**Authentication (ALM Sorted delivery):** Certificate-based (TLS mutual auth via keystore) — per FSD; **not yet confirmed against real target credentials** (see §5.2.5 open item — this states the legacy mechanism, not necessarily what our build will use without verification).

**Concurrency:** Up to 10 sessions.

**Retry:** 3 attempts, 30-second intervals for transient failures (per FSD §3.2.6 NFR — note this differs from EAII-301's 5-second interval, see §5.1.2.1 callout).

**Poison-message handling (per FSD §3.2.1.2):** redelivery count tracked; if it exceeds 3, the message is acknowledged **without processing** and an error is logged **without notification** — deliberate, to prevent alert storms from poison messages.

**Known Issues (per FSD §3.2.1.3):**

- Shared schema with Food Sorted — both targets use the same intermediate schema and similar transformation logic; potential for a single shared transformation with multi-target routing.
- Redelivery count handling — messages silently consumed past the redelivery cap; persistent failures may go unnoticed if monitoring doesn't specifically track consumed-without-processing events (see §5.2.8 Monitoring).

**Data classification (per FSD §3.2.5):** Internal. Supplier contract data including business identifiers and agreement details — internal to Metcash operations. Standard internal data handling; encrypt in transit (TLS/HTTPS).

#### 5.3.1.2 Process Flow Diagram

![image-20260714-010737.png](images/08.png)

#### 5.3.2 Proposed Process

**5.3.2.1 Description of Process(es)**

1. A blob-created pointer message arrives on our Service Bus subscription (`toalmsorted.supplierinfo`, on the shared topic — see §3.2). The reference message payload itself is written to Blob Storage by the upstream JMS publisher; only the pointer arrives on the subscription. `MDMSupplierInfoToALMSorted` (Function trigger / Service Bus executor) receives the pointer message with `autoComplete=false`. The executor downloads the Reference Message XML from Blob Storage using the pointer, then invokes the ALM Sorted service exactly once; all target-delivery retries occur inside that single service call. The service calls the MDM REST API once only (same client/request shape as EAII-301 — see §5.1.2.1) to retrieve the complete supplier contract data. The response is transformed into the ALM Sorted JSON supplier entity structure, including:
  - Legal entity details (ID, name, ABN, ACN, TABN, contact email)
  - Request type indicator (`getSupplierDetailsByContractId`, confirmed from real payload samples — `inbox/additional_payload_sample/SupplierInfoRequestToALMSorted_Sample*.json`)
  - Supplier contract details: agreement information, contract components (Pay To + Buy From parties with roles, one Buy From component per state/territory: NSW/VIC/QLD/SA/WA/NT), administrative native keys, supplier group, core supplier data, extended data

2. The service delivers the JSON payload via HTTPS POST to the ALM Sorted supplier endpoint (no authentication required) using the shared EAII-517/516 retry/dead-letter design:
  - **Tier 1 — service/business logic**: retry the ALM Sorted HTTP POST only, up to 3 attempts with a 2-second fixed delay. HTTP 2xx returns Success immediately. HTTP 400 is non-retryable and returns Failure immediately. Any other non-2xx status or thrown exception is retryable until the attempt limit is reached. Transformation failures throw immediately and skip the HTTP retry loop.
  - **Tier 2 — Service Bus executor**: on Success, call `CompleteMessageAsync`. On Failure or any unhandled exception, call `DeadLetterMessageAsync` immediately with the HTTP status or exception detail as the dead-letter reason.

3. Every message is settled on its first and only delivery. There is no abandon-and-redeliver step and no DeliveryCount check in the EAII-517 design. SMC observation is logged at each key stage (including a Blob Downloaded stage once the Reference Message XML is retrieved) and once finally per message in a finally block, regardless of success, business failure, or unhandled exception.

#### 5.3.2.2 Process Flow Diagram

![EAII-517 Process Flow-20260825-092906.png](images/01.png)

1. A blob-created pointer arrives on `toalmsorted.supplierinfo`.
2. `MDMSupplierInfoToALMSorted` uses manual Service Bus settlement.
3. The executor downloads the Reference Message XML and invokes the service once.
4. The service calls MDM once and transforms the response.
5. The ALM Sorted POST is retried in-process up to three times with a two-second fixed delay.
6. HTTP 2xx completes successfully.
7. HTTP 400 is non-retryable and causes immediate failure.
8. Other non-2xx responses and exceptions are retried until the attempt limit.
9. On success, the message is completed. On failure or unhandled exception, it is dead-lettered immediately.
10. No Service Bus redelivery or `DeliveryCount` check is used in the proposed design.

The payload includes legal entity details, request type `getSupplierDetailsByContractId`, agreement information, Pay To and per-state Buy From components, supplier group, core supplier data, and extended data.

#### 5.3.2.3 Sequence Diagram

![image-20260826-191645.png](images/06.png)

#### 5.3.2.4 PlantUML

```
@startuml EAII-517-Supplier-MDM-to-ALM-Sorted
title EAII-517 — Supplier MDM to ALM Sorted (Proposed Process)

actor "Supplier MDM\n(IBM MDM)" as MDM
queue "TIBCO EMS Queue\nService.MDM.SupplierContractEIM.Q" as JMSQ
participant "JMS Publisher\nFunction App:\nt3-met-sharedservicescommon-{env}-ae-func\n(config-driven timer poll)" as Publisher
participant "Storage Account:\nt3data{env}aesta01\n(inbound JMS payload)" as BlobIn
participant "Service Bus Namespace:\nt1-met-{npr|prd}-ae-sb-001\nTopic: data.SupplierInfoFromMDM.{env}.sbt" as SB
participant "Function App:\nt3-met-mdmsupplierinfo-{env}-ae-func\nFunction: MDMSupplierInfoToALMSorted" as Func
participant "MDM REST API" as MdmApi
participant "ALM Sorted\n{host}/occ/v2/alm/mdm/supplier" as ALM
participant "SMC" as SMC

MDM -> JMSQ : publishes TCRMService XML\n(supplier contract change)
Publisher -> JMSQ : polls (timer interval per config)
Publisher -> BlobIn : writes Reference Message payload\n(blob-pointer route, TargetType=Both)
Publisher -> SB : publishes Event Grid-shaped pointer\n{data.url, eventType, ...}\nApplicationProperties: INTERFACECODE=MDMSUPCNT001

SB -> Func : deliver to subscription\ntoalmsorted.supplierinfo\n(SQL filter: INTERFACECODE='MDMSUPCNT001')
note right of Func : manual Service Bus settlement\n(no auto-complete, no DeliveryCount reliance)

Func -> BlobIn : download Reference Message XML\n(via pointer's data.url)
Func -> MdmApi : call MDM REST API once\n(shared MdmRestClient)
MdmApi --> Func : supplier contract response

Func -> Func : transform to supplier JSON\n(legal entity, Pay To / per-state Buy From\ncomponents, supplier group, core + extended data)

loop up to 3 attempts, 2s fixed delay
    Func -> ALM : POST supplier JSON\n(no authentication required)
    alt HTTP 2xx
        Func -> SMC : log observation (Success)
        Func -> SB : complete message
    else HTTP 400
        note right: non-retryable — fails immediately
        Func -> SMC : log observation (Failed)
        Func -> SB : dead-letter message
    else other non-2xx or exception
        note right: retryable — retry up to 3 attempts
    end
end

alt all 3 attempts exhausted
    Func -> SMC : log observation (Failed)
    Func -> SB : dead-letter message (toalmsorted.supplierinfo/$DeadLetterQueue)
end

@enduml
```

#### **5.3.3 Coordination**

Fully asynchronous, event-driven. One message per invocation, no batching. Standard default Azure Function App / Service Bus trigger concurrency applies; no artificial concurrency limit is applied in the proposed design (shared with EAII-301, EAII-516, and EAII-302).

**5.3.3.1 Transaction Boundaries**

One Service Bus message = one MDM retrieval call = one ALM Sorted POST operation = one settlement outcome. No cross-message transaction.

**5.3.3.2 State Management**

Stateless per invocation — no state is persisted between messages.

#### 5.3.4 API Endpoint Information

| Parameter | Value |
| --- | --- |
| FSD endpoint | `https://{host}/occ/v2/alm/mdm/supplier` |
| Legacy-config endpoint | `https://{host}/occ/v2/almretailersspa/mdm/supplier` |
| Method | `POST` |
| Content type | `application/json` |
| Authentication | No authentication required (confirmed). |

#### 5.3.5 Design Considerations

Target-delivery retry is kept inside the service so the MDM call and SMC observation occur once per logical message. The ALM Sorted and Food Sorted transformations are structurally similar but remain separate classes to preserve decoupling.

#### 5.3.6 Service High-Level Design

**5.3.6.1 Component List**

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts `MDMSupplierInfoToALMSorted` (shared host with EAII-301/516/302). |
| Azure Service Bus Subscription (`toalmsorted.supplierinfo`, on shared topic) | `Microsoft.ServiceBus/topics` | Delivers the reference message. |
| MDM REST API | N/A | Supplier contract data retrieval — no authentication (plain REST PUT). |
| ALM Sorted API | N/A | Accepts the supplier JSON payload. No authentication required. |
| Azure Key Vault (AIS) | `Microsoft.KeyVault/vaults` | SMC subscription key — existing vault, reused. |
| Application Insights / SMC (via APIM) | N/A | Observability — see §3.2 Error Handling and Monitoring. |

**5.3.6.2 Services**

- `MDMSupplierInfoToALMSorted` (Function trigger) — Service Bus pull-triggered entry point, manual Service Bus settlement.
- `MdmSupplierInfoToAlmSortedService` (business logic) — downloads the Reference Message, calls MDM once, transforms the response, POSTs to ALM Sorted, applies retry/dead-letter policy.
- Shared `MdmService` (library, shared with EAII-301/516/302) — builds the MDM request, sends the unauthenticated REST PUT, parses the response.
- `AlmSortedTransformService` — MDM XML → supplier JSON structure (legal entity, Pay To/per-state Buy From components, supplier group, core + extended data).
- `AlmSortedHttpService` — POSTs the transformed JSON to ALM Sorted, no authentication.

Representative output:

```
{
  "legalEntityBObj": {
    "legalEntityId": "193452435834868302",
    "legalEntityName": "CORDINA",
    "abn": "29003058428",
    "acn": "003058428"
  },
  "requestType": "getSupplierDetailsByContractId",
  "mTTSupplierDetailsBObj": {
    "mTTSupplierContractBObj": {
      "tCRMContractBObj": {
        "agreementName": "CORDINA CHICKEN FARMS XD",
        "tCRMContractComponentBObj": [
          { "contractComponentValue": "Pay To" },
          { "contractComponentValue": "Buy From", "contractComponentServiceArrangementValue": "NSW" }
        ]
      }
    }
  }
}
```

**5.3.6.3 Audit, Logging & Exceptions**

**5.3.6.3.1 Logging**

As per the SMC specification, the following information is logged.

Interface ID = EAII-517 (Supplier MDM → ALM Sorted)

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and completes the observation for a single Function invocation in one call — `IsObservationComplete = true` is always set, since this interface makes exactly one MDM retrieval + one ALM Sorted delivery attempt per message. `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), linking this interface's observation with EAII-301/516/302's for the same source event. | `{SmcBaseUrl}/{SmcStartObservationApiName}` → `https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1/start-observation` | POST |

**5.3.6.3.2 Audit**

All critical events and exceptions are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for the Function App. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique correlation ID is generated for each Service Bus message and propagated throughout the entire processing pipeline (MDM retrieval → transformation → ALM Sorted delivery). SMC records the lifecycle of each transaction via a single completed observation per Function invocation.

**5.3.6.3.3 Exceptions**

| Observation Stage | Failure Scenario | Trigger | Action | Notification |
| --- | --- | --- | --- | --- |
| MDM retrieval | MDM REST API retrieval failure | HTTP error or timeout from MDM REST endpoint | Log error with Transaction ID/PartyId context. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |
| Transformation | Transformation error | Invalid/unexpected data in MDM response causing mapping failure | Log error with full exception details and correlation identifiers. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |
| ALM Sorted delivery — non-retryable | HTTP 400 | ALM Sorted rejects the payload as invalid | Log error, dead-letter immediately (non-retryable). | Standard DLQ-accumulation alerting. |
| ALM Sorted delivery — transient failure | Other non-2xx response, connectivity failure, or exception | Network error, timeout, or ALM Sorted server error | Retry up to 3 times with a 2-second fixed delay; dead-letter on exhaustion. | Standard DLQ-accumulation alerting. |

**5.3.7 SMC Onboarding and Load**

**5.3.7.1 Integration Onboarding**

| Field | Value |
| --- | --- |
| Interface ID | EAII-517 |
| Interface Name | `MDMSupplierInfoToALMSorted` |
| Source Application | Supplier MDM |
| Destination Application | ALM Sorted |
| Interface Type | Async, event-driven, single-threaded |
| Interface DataStore | N/A (no persistent output store — ALM Sorted delivery only) |
| Reference Keys | CorrelationId, PartyId, Contract Component ID |

**5.3.7.1**Load

| Field | Value |
| --- | --- |
| Interface ID | EAII-517 |
| Interface name | `MDMSupplierInfoToALMSorted` |
| Source | Supplier MDM |
| Destination | ALM Sorted |
| Type | Async, event-driven |
| Data store | N/A |
| Reference keys | CorrelationId, PartyId, Contract Component ID |
| Average volume | 10–15 messages/day |
| Observations | 1 complete observation per message |

**5.3.8 Monitoring**

Application Insights telemetry and one SMC Gen 3 observation per invocation. Monitoring includes Function errors, DLQ accumulation, and target delivery failures.

---

**5.3.9 Reporting**

No bespoke reporting required.

---

**5.3.10 Integration and Testing Requirements**

**5.3.10.1 Development and Integration Strategy**

Standard Function App development lifecycle: local development against sample MDM request/response payloads, deployed per-environment via the existing AIS pipeline pattern.

**5.3.10.2 Unit Testing**

| ADO Test Case ID | Description |
| --- | --- |
| EAII-517-UT-01 | Happy path — successful MDM retrieval, correct transform, ALM Sorted returns HTTP 2xx, message completed |
| EAII-517-UT-02 | MDM retrieval failure (timeout/HTTP error) — message dead-lettered immediately |
| EAII-517-UT-03 | Transformation error (malformed/unexpected MDM data) — message dead-lettered, no ALM Sorted call made |
| EAII-517-UT-04 | ALM Sorted HTTP 400 — non-retryable, message dead-lettered immediately |
| EAII-517-UT-05 | ALM Sorted other non-2xx / connectivity failure — retried up to 3 times, then dead-lettered on exhaustion |
| EAII-517-UT-06 | Multi-component payload — verify Pay To and multiple per-state Buy From components all transform correctly in one message |
| EAII-517-UT-07 | SMC StartObservation failure — flow continues unblocked |
| EAII-517-UT-08 | Endpoint-path confirmation — verify the FSD-documented path (`/occ/v2/alm/mdm/supplier`), not the legacy-config path, is used |

### 5.4 EAII-516 — Supplier MDM to Food Sorted

#### 5.4.1 As-is Process

Functionally identical to EAII-517 (§5.2.1.1): reference message on a dedicated queue (`Service.MDM.SupplierContractAutoCT.Q`, bridged from topic `Service.MDM.TradingAccount.T`, selector `INTERFACECODE='MDMSUPCNT001'`, queue options `store=$sys.failsafe, redeliveryDelay=300`) → client-mode acknowledgement with redelivery-count tracking (max 3) → MDM REST API retrieval (same as EAII-301/517) → transformation into the same JSON supplier entity structure as EAII-517 → HTTPS POST delivery to the Food Sorted endpoint (different host/path from ALM Sorted).

**Authentication (Food Sorted delivery):** Certificate-based (TLS mutual auth via keystore) — per FSD; same open-item caveat as EAII-517 (§5.3.5) applies — not yet confirmed against real target credentials.

**Concurrency:** Up to 10 sessions.

**Retry:** Same as EAII-517 — 3 attempts, 30-second intervals for transient failures.

**Poison-message handling:** Identical to EAII-517 — redelivery count > 3 results in silent acknowledge-without-processing, logged without notification.

**Known Issues (per FSD §3.3.1.3):** Same as EAII-517 — shared schema presents a consolidation opportunity; redelivery count handling may mask persistent failures.

**Data classification (per FSD §3.3.5):** Internal — same as EAII-517. Standard internal data handling; encrypt in transit (TLS/HTTPS).

![image-20260714-010819.png](images/07.png)

Functionally similar to EAII-517, using the Food Sorted target endpoint and legacy queue `Service.MDM.SupplierContractAutoCT.Q`. The proposed design does not use Service Bus redelivery; target delivery is retried in-process and failures are dead-lettered.

#### 5.4.2 Proposed Process

#### 5.4.2.1 Description of Process(es)

The proposed EAII-516 flow follows the same pattern as EAII-517, using the Food Sorted target endpoint and mTLS authentication. A blob-created pointer message arrives on the `tosorted.supplierinfo` subscription, the Function downloads the Reference Message XML, retrieves the complete supplier contract from MDM, transforms it to the shared supplier JSON structure, and posts it to Food Sorted. Target delivery is retried in-process up to three times with a two-second fixed delay; successful processing completes the Service Bus message, while failures are dead-lettered immediately.

#### 5.4.2.2 Process Flow Diagram

![EAII-516 Process Flow-20260825-092847.png](images/03.png)

1. A blob-created pointer arrives on `tosorted.supplierinfo`.
2. `MDMSupplierInfoToSorted` downloads the Reference Message XML.
3. The shared MDM client retrieves the full supplier contract once.
4. The response is transformed into the same supplier JSON shape as EAII-517.
5. The JSON is posted to Food Sorted using mTLS client-certificate authentication.
6. The POST is retried up to three times with a two-second fixed delay.
7. On success, the message is completed.
8. On failure or exception, the message is immediately dead-lettered.

#### 5.4.2.3 Sequence Diagram

![image-20260826-191747.png](images/11.png)

#### 5.4.2.4 PlantUML

```
@startuml EAII-516-Supplier-MDM-to-Food-Sorted
title EAII-516 — Supplier MDM to Food Sorted (Proposed Process)

actor "Supplier MDM\n(IBM MDM)" as MDM
queue "TIBCO EMS Queue\nService.MDM.SupplierContractEIM.Q" as JMSQ
participant "JMS Publisher\nFunction App:\nt3-met-sharedservicescommon-{env}-ae-func\n(config-driven timer poll)" as Publisher
participant "Storage Account:\nt3data{env}aesta01\n(inbound JMS payload)" as BlobIn
participant "Service Bus Namespace:\nt1-met-{npr|prd}-ae-sb-001\nTopic: data.SupplierInfoFromMDM.{env}.sbt" as SB
participant "Function App:\nt3-met-mdmsupplierinfo-{env}-ae-func\nFunction: MDMSupplierInfoToSorted" as Func
participant "MDM REST API" as MdmApi
participant "Key Vault\n(mTLS leaf + intermediate CA cert)" as KV
participant "Food Sorted\n{host}/metcashcommercewebservices/\nv2/mdm/supplier" as Food
participant "SMC" as SMC

MDM -> JMSQ : publishes TCRMService XML\n(supplier contract change)
Publisher -> JMSQ : polls (timer interval per config)
Publisher -> BlobIn : writes Reference Message payload\n(blob-pointer route, TargetType=Both)
Publisher -> SB : publishes Event Grid-shaped pointer\n{data.url, eventType, ...}\nApplicationProperties: INTERFACECODE=MDMSUPCNT001

SB -> Func : deliver to subscription\ntosorted.supplierinfo\n(SQL filter: INTERFACECODE='MDMSUPCNT001')
note right of Func : manual Service Bus settlement\n(no auto-complete, no DeliveryCount reliance)

Func -> BlobIn : download Reference Message XML\n(via pointer's data.url)
Func -> MdmApi : call MDM REST API once\n(shared MdmRestClient)
MdmApi --> Func : supplier contract response

Func -> Func : transform to supplier JSON\n(same shape as EAII-517,\nseparate FoodSortedTransformService class)

Func -> KV : load mTLS client certificate\n(leaf + intermediate CA)

loop up to 3 attempts, 2s fixed delay
    Func -> Food : POST supplier JSON\n(mTLS client-certificate authentication)
    alt HTTP 2xx
        Func -> SMC : log observation (Success)
        Func -> SB : complete message
    else failure or exception
        note right: retryable — retry up to 3 attempts
    end
end

alt all 3 attempts exhausted
    Func -> SMC : log observation (Failed)
    Func -> SB : dead-letter message (tosorted.supplierinfo/$DeadLetterQueue)
end

@enduml
```

#### 5.4.3 Coordination

Fully asynchronous, event-driven. One message per invocation, no batching. Standard default Azure Function App / Service Bus trigger concurrency applies; no artificial concurrency limit is applied in the proposed design (shared with EAII-301, EAII-517, and EAII-302). Manual Service Bus message settlement is used, same as EAII-517.

##### 5.4.3.1 Transaction Boundaries

One Service Bus message = one MDM retrieval call = one Food Sorted POST operation = one settlement outcome. No cross-message transaction.

##### 5.4.3.2 State Management

Stateless per invocation — no state is persisted between messages.

#### 5.4.4 API Endpoint Information

| Parameter | Value |
| --- | --- |
| FSD endpoint | `https://{host}/metcashcommercewebservices/v2/mdm/supplier` |
| Legacy-config endpoint | `https://{host}/occ/v2/sorted/mdm/supplier` |
| Method | `POST` |
| Content type | `application/json` |
| Authentication | mTLS client certificate (leaf + intermediate CA cert, loaded via the platform trust store configuration). |

#### 5.4.5 Design Considerations

Food Sorted uses a different backend from ALM Sorted. Its host pattern matches the existing Sorted Marketplace integration. The transformation is structurally identical to ALM Sorted (both derive from the same shared MDM response, same supplier JSON shape) but remains a separate class to prevent silent drift between the two targets. Unlike ALM Sorted, delivery requires mTLS client-certificate authentication — the leaf and intermediate CA certificates are loaded via the platform's trust store configuration rather than a dedicated Key Vault secret.

#### 5.4.6 Service High-Level Design

##### 5.4.6.1 Component List

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| Azure Function App (`t3-met-mdmsupplierinfo-{env}-ae-func`) | `Microsoft.Web/sites` | Hosts `MDMSupplierInfoToSorted` (shared host with EAII-301/517/302). |
| Azure Service Bus Subscription (`tosorted.supplierinfo`, on shared topic) | `Microsoft.ServiceBus/topics` | Delivers the reference message. |
| MDM REST API | N/A | Supplier contract data retrieval — no authentication (plain REST PUT). |
| Food Sorted API | N/A | Accepts the supplier JSON payload. mTLS client-certificate authentication. |
| Platform trust store | N/A | Supplies the leaf + intermediate CA certificate for mTLS. |
| Azure Key Vault (AIS) | `Microsoft.KeyVault/vaults` | SMC subscription key — existing vault, reused. |
| Application Insights / SMC (via APIM) | N/A | Observability — see §3.2 Error Handling and Monitoring. |

##### 5.4.6.2 Services

- `MDMSupplierInfoToSorted` (Function trigger) — Service Bus pull-triggered entry point, manual Service Bus settlement.
- `MdmSupplierInfoToFoodSortedService` (business logic) — downloads the Reference Message, calls MDM once, transforms the response, POSTs to Food Sorted with mTLS, applies retry/dead-letter policy.
- Shared `MdmService` (library, shared with EAII-301/517/302) — builds the MDM request, sends the unauthenticated REST PUT, parses the response.
- `FoodSortedTransformService` — MDM XML → supplier JSON structure, structurally identical shape to `AlmSortedTransformService` but a separate class.
- `FoodSortedHttpService` — POSTs the transformed JSON to Food Sorted using mTLS client-certificate authentication.

##### 5.4.6.3 Audit, Logging & Exceptions

###### 5.4.6.3.1 Logging

As per the SMC specification, the following information is logged.

Interface ID = EAII-516 (Supplier MDM → Food Sorted)

All significant events, including successful completions and errors, are logged in SMC for monitoring and debugging purposes.

| Sr. No. | API Name | Description | API URL | Method |
| --- | --- | --- | --- | --- |
| 1 | Start Observation | Initiates and completes the observation for a single Function invocation in one call — `IsObservationComplete = true` is always set, since this interface makes exactly one MDM retrieval + one Food Sorted delivery attempt per message. `ParentObservationID` is set from the inbound `TRANSACTIONID` (falling back to the generated CorrelationId when absent), linking this interface's observation with EAII-301/517/302's for the same source event. | `{SmcBaseUrl}/{SmcStartObservationApiName}` → `https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1/start-observation` | POST |

**5.4.6.3.2 Audit**

All critical events and exceptions are logged and managed using the SMC tool's audit APIs, ensuring comprehensive traceability, support capabilities, and effective error handling. For further information, refer to *Audit, Logging and Exception Management with SMC*.

It uses SMC (Service Monitoring Console) for end-to-end transaction observability across the integration flow and Azure Application Insights for Azure resource telemetry, diagnostics, and performance monitoring.

| Component | Azure Resource Provider | Purpose |
| --- | --- | --- |
| SMC | External Enterprise Monitoring Platform | Provides end-to-end transaction tracking, business transaction visibility, and correlation across Azure services and external systems. |
| Application Insights | `Microsoft.Insights/components` | Captures application telemetry, request traces, dependency calls, exceptions, and performance metrics for the Function App. |
| Azure Monitor | `Microsoft.Insights/*` | Collects platform metrics, supports alerting, dashboards, and integrates with Application Insights. |

SMC is the primary observability platform for the integration. A unique correlation ID is generated for each Service Bus message and propagated throughout the entire processing pipeline (MDM retrieval → transformation → Food Sorted delivery). SMC records the lifecycle of each transaction via a single completed observation per Function invocation.

**5.4.6.3.3 Exceptions**

| Observation Stage | Failure Scenario | Trigger | Action | Notification |
| --- | --- | --- | --- | --- |
| MDM retrieval | MDM REST API retrieval failure | HTTP error or timeout from MDM REST endpoint | Log error with Transaction ID/PartyId context. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |
| Transformation | Transformation error | Invalid/unexpected data in MDM response causing mapping failure | Log error with full exception details and correlation identifiers. Dead-letter the message immediately. | Standard DLQ-accumulation alerting. |
| mTLS authentication | Certificate rejected or expired | Food Sorted rejects the mTLS handshake | Log error, dead-letter immediately (non-retryable — a bad certificate will not succeed on retry). | Standard DLQ-accumulation alerting; certificate expiry should also be tracked separately for proactive renewal. |
| Food Sorted delivery — transient failure | Non-2xx response, connectivity failure, or exception | Network error, timeout, or Food Sorted server error | Retry up to 3 times with a 2-second fixed delay; dead-letter on exhaustion. | Standard DLQ-accumulation alerting. |

**5.4.7 SMC Onboarding and Load**

**5.4.7.1 Integration Onboarding**

| Field | Value |
| --- | --- |
| Interface ID | EAII-516 |
| Interface Name | `MDMSupplierInfoToSorted` |
| Source Application | Supplier MDM |
| Destination Application | Food Sorted |
| Interface Type | Async, event-driven, single-threaded |
| Interface DataStore | N/A (no persistent output store — Food Sorted delivery only) |
| Reference Keys | CorrelationId, PartyId, Contract Component ID |

**5.4.7.1** Load

| Field | Value |
| --- | --- |
| Interface ID | EAII-516 |
| Interface name | `MDMSupplierInfoToSorted` |
| Source | Supplier MDM |
| Destination | Food Sorted |
| Type | Async, event-driven |
| Data store | N/A |
| Reference keys | CorrelationId, PartyId, Contract Component ID |
| Average volume | 10–15 messages/day |
| Observations | 1 complete observation per message |

---

**5.4.8 Monitoring**

Application Insights telemetry and one SMC Gen 3 observation per invocation. Monitoring covers Function failures, SMC observations, DLQ accumulation, and mTLS certificate expiry.

---

**5.4.9 Reporting**

No bespoke reporting required.

---

**5.4.10 Integration and Testing Requirements**

**5.4.10.1 Development and Integration Strategy**

Standard Function App development lifecycle: local development against sample MDM request/response payloads, deployed per-environment via the existing AIS pipeline pattern.

**5.4.10.2 Unit Testing**

| ADO Test Case ID | Description |
| --- | --- |
| EAII-516-UT-01 | Happy path — successful MDM retrieval, correct transform, Food Sorted returns HTTP 2xx, message completed |
| EAII-516-UT-02 | MDM retrieval failure (timeout/HTTP error) — message dead-lettered immediately |
| EAII-516-UT-03 | Transformation error (malformed/unexpected MDM data) — message dead-lettered, no Food Sorted call made |
| EAII-516-UT-04 | mTLS certificate rejected/expired — non-retryable, message dead-lettered immediately |
| EAII-516-UT-05 | Food Sorted non-2xx / connectivity failure — retried up to 3 times, then dead-lettered on exhaustion |
| EAII-516-UT-06 | Transform-output equivalence — verify `FoodSortedTransformService` produces the same JSON shape as `AlmSortedTransformService` for equivalent input |
| EAII-516-UT-07 | SMC StartObservation failure — flow continues unblocked |
| EAII-516-UT-08 | Endpoint-path confirmation — verify the FSD-documented path (`/metcashcommercewebservices/v2/mdm/supplier`), not the legacy-config path, is used |

## 6 Architecture Overview

![Architecture Diagram-20260825-092924.png](images/12.png)

### 6.1 Azure Resource Inventory

| Resource Type | DV1 | ST1 | UT1 | PRD | Resource Group | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| Function App | `t3-met-mdmsupplierinfo-dv1-ae-func` | `t3-met-mdmsupplierinfo-st1-ae-func` | `t3-met-mdmsupplierinfo-ut1-ae-func` | `t3-met-mdmsupplierinfo-prd-ae-func` | `t3-met-ais-{env}-ae1-rsg-data` (same as existing) | Hosts all 3 interface functions |
| App Service Plan | `t3-met-mdmsupplierinfo-dv1-ae-asp` | `t3-met-mdmsupplierinfo-st1-ae-asp` | `t3-met-mdmsupplierinfo-ut1-ae-asp` | `t3-met-mdmsupplierinfo-prd-ae-asp` | `t3-met-ais-{env}-ae1-rsg-data` |  |
| Application Insights | `t3-met-mdmsupplierinfo-dv1-ae-func-ai` | same pattern | same pattern | same pattern | `t3-met-ais-{env}-ae1-rsg-data` | Linked to Log Analytics workspace |
| Log Analytics Workspace | Existing shared per env | Existing shared per env | Existing shared per env | Existing shared per env | — | Existing, reused |
| Service Bus Namespace | `t1-met-npr-ae-sb-001` (shared) | `t1-met-npr-ae-sb-001` (shared) | `t1-met-npr-ae-sb-001` (shared) | `t1-met-prd-ae-sb-001` | Shared / existing | Same namespace as MetProductsV2 — non-prod shared across DV1/ST1/UT1 |
| **Service Bus Topic** | `data.SupplierInfoFromMDM.dv1.sbt` | same pattern | same pattern | same pattern | Inside namespace |  |
| SB Subscription | `toeaim.supplierinfo` | same | same | same | On the shared topic | EAII-301 trigger |
| SB Subscription | `toalmsorted.supplierinfo` | same | same | same | On the shared topic | EAII-517 trigger |
| SB Subscription | `tosorted.supplierinfo` | same | same | same | On the shared topic | EAII-516 trigger |
| Storage Account | `t3datadv1aesta01` (existing) | `t3datast1aesta01` | `t3dataut1aesta01` | `t3dataprdaesta01` | `t3-met-ais-{env}-ae1-rsg-data` | Reused existing account (same as MetProductsV2). Container `eim`, path `toeim/supplierinfo` |
| Key Vault (AIS-owned) | Existing, same as MetProductsV2 (`t3data{env}ae1kv01` pattern) | same pattern | same pattern | same pattern | `t3-met-ais-{env}-ae1-rsg-data` | Stores MDM credentials/cert (§6.3.2) — **no new vault**, existing vault reused |
| Key Vault (Enabling/SMC-owned) | Existing, same as MetProductsV2 (`t3enabling{env}ae1kv01`) | same pattern | same pattern | same pattern | `t3-met-ais-{env}-ae1-rsg-smc` | Existing; SMC team manages; SAMI granted Secrets User — **no new vault** |
| APIM (SMC gateway) | Existing shared instance | same | same | same | Shared / existing | SMC `StartObservation` gateway only |

### 6.2 Network Connectivity

![Network Diagram-20260825-092943.png](images/09.png)

All AIS integration-tier resources sit in the **EdSense (SENS)** application subnet; private endpoints for backend services sit in the **HeadSense (HSENS)** subnet.

### 6.2.1 VNet and Subnet Reference

| Environment | VNet | Address space | SENS | HSENS |
| --- | --- | --- | --- | --- |
| DV1 | `t2-met-ais-dv1-ae1-net-01` | `10.247.80.0/21` | `10.247.86.0/24` | `10.247.80.0/23` |
| ST1 | `t2-met-ais-st1-ae1-net-01` | `10.247.88.0/21` | `10.247.92.0/24` | `10.247.88.0/23` |
| UT1 | `t2-met-ais-ut1-ae1-net-01` | `10.247.96.0/21` | `10.247.98.0/24` | `10.247.100.0/23` |
| PROD | `t2-met-ais-prd-ae1-net-01` | `10.249.32.0/21` | `10.249.38.0/23` | `10.249.32.0/23` |

Integration resources use the SENS application subnet and private endpoints in HSENS. Public access is disabled for Service Bus, Storage, and Key Vault resources.

### 6.2.2 Component Network Table

| Component | Resource Name (DV1) | Resource Type | VNet | Subnet / Classification | Private Endpoint | Public Access |
| --- | --- | --- | --- | --- | --- | --- |
| Function App | `t3-met-mdmsupplierinfo-dv1-ae-func` | `Microsoft.Web/sites` | `t2-met-ais-dv1-ae1-net-01` | SENS — VNet Integration | N/A (outbound VNet Integration) | Disabled — Service Bus pull trigger only, no inbound HTTP surface |
| Service Bus Namespace | `t1-met-npr-ae-sb-001` | `Microsoft.ServiceBus/namespaces` | Hub VNet (shared) | HSENS — private endpoint | Yes | Disabled (firewall: VNet rules only) |
| Storage Account | `t3datadv1aesta01` | `Microsoft.Storage/storageAccounts` | `t2-met-ais-dv1-ae1-net-01` | HSENS — private endpoint | Yes — Blob private endpoint | Disabled — deny public access |
| Key Vault (AIS) | Existing | `Microsoft.KeyVault/vaults` | `t2-met-ais-dv1-ae1-net-01` | HSENS — private endpoint | Yes | Disabled |
| Key Vault (Enabling/SMC) | Existing | `Microsoft.KeyVault/vaults` | Hub VNet (shared) | HSENS | Yes | Disabled |
| APIM (SMC) | Existing shared instance | `Microsoft.ApiManagement/service` | Hub VNet (shared) | SENS (internal mode) | N/A | Internal VNet only |
| MDM REST API | External (`172.18.16.4` ST1/DV1, `172.18.6.1` UT1, `mdm.metcash.com` PRD) | External |  | N/A | N/A | Non-prod hosts are internal IPs (172.18.x.x), implying VNet/private routing required — see §6.2.2 note below |
| ALM Sorted | External (SAP Commerce Cloud) | External | Internet egress | N/A | N/A | HTTPS — auth mechanism open item (§5.2.5) |
| Food Sorted | External (matches existing Sorted Marketplace host pattern) | External | Internet egress | N/A | N/A | HTTPS — auth mechanism open item (§5.3.5) |

## 6.4 External Endpoint Reference

The following table lists environment-specific host and port details for Supplier MDM, ALM Sorted, and Food Sorted. Refer to this table for endpoint host values used by the MDM retrieval and target REST delivery connections described in sections 5.1, 5.2, 5.3, and 6.3.

| Env | Target | Endpoint | Resource Path |
| --- | --- | --- | --- |
| DV1 | MDM | `https://mdmtst2a-mdm.metcash.com:9443` | `/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful` |
| DV1 | ALM Sorted | `https://api.clcpyq-manualmet1-d1-public.model-t.cc.commerce.ondemand.com:443` | `/occ/v2/alm/mdm/supplier` |
| DV1 | Food Sorted | `https://devbackground.marketplace.metcash.com:443` | `/metcashcommercewebservices/v2/mdm/supplier` |
| ST1 | MDM | `https://mdmtsta-mdm.metcash.com:9443` | `/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful` |
| ST1 | ALM Sorted | `https://api.clcpyq-manualmet1-d1-public.model-t.cc.commerce.ondemand.com:443` | `/occ/v2/alm/mdm/supplier` |
| ST1 | Food Sorted | `https://devbackground.marketplace.metcash.com:443` | `/metcashcommercewebservices/v2/mdm/supplier` |
| UT1 | MDM | `https://mdmuata-mdm.metcash.com:9443` | `/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful` |
| UT1 | ALM Sorted | `https://api.clcpyq-manualmet1-s1-public.model-t.cc.commerce.ondemand.com:443` | `/occ/v2/alm/mdm/supplier` |
| UT1 | Food Sorted | `https://stgbackground.marketplace.metcash.com:443` | `/metcashcommercewebservices/v2/mdm/supplier` |
| PRD | MDM | `https://mdm.metcash.com:443` | `/com.ibm.mdm.server.ws.restful/resources/MDMWSRESTful` |
| PRD | ALM Sorted | `https://prodplbackground.almliquor.metcash.com:443` | `/occ/v2/alm/mdm/supplier` |
| PRD | Food Sorted | `https://prdbackground.marketplace.metcash.com:443` | `/metcashcommercewebservices/v2/mdm/supplier` |
| DV1 | STIBO STEP PIM (EAII-302) | `https://metcash-test.mdm.stibosystems.com` | `/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main` |
| ST! | STIBO STEP PIM (EAII-302) | `https://metcash-test.mdm.stibosystems.com` | `/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main` |
| UT1 | STIBO STEP PIM (EAII-302) | `https://metcash-uat.mdm.stibosystems.com` | `/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main` |
| PRD | STIBO STEP PIM (EAII-302) | `https://metcash-prod.mdm.stibosystems.com` | `/restapi/integrationendpoints/iiep_REST_SupplierHier/upload?context=Australian&workspace=Main` |

### 6.3 Security

- Function App uses **Managed Identity** (SAMI) to communicate with Azure Storage accounts, Azure Service Bus, and Azure Key Vaults — no connection strings or access keys.
- Public access to storage accounts is **denied**; access is restricted to specific virtual networks.
- Azure Key Vault stores all secrets and credentials — no secrets in application configuration or source code.
- Access to all Azure services/resources is controlled via **RBAC**, least-privilege.
- All communication between endpoints uses **HTTPS** (TLS 1.2+); MDM additionally requires **mTLS** (client certificate).
- The Function App's Service Bus trigger is a **pull** mechanism — there is no publicly reachable inbound HTTP endpoint for any of the three interfaces.

#### 6.3.1 Authentication and Secrets

| Connection | Source | Target | Authentication Method | Key Vault Secret | KV Instance |
| --- | --- | --- | --- | --- | --- |
| Service Bus → Function App | Service Bus Subscription | Function App | Managed Identity SAMI (Azure Service Bus Data Receiver) | N/A | N/A |
| Function App → MDM REST API | Function App | MDM REST API | None — plain unauthenticated REST `PUT` | `N/A` | AIS KV |
| Function App → ALM Sorted | Function App | ALM Sorted REST API | None | `NA` | AIS KV |
| Function App → Food Sorted | Function App | Food Sorted REST API | mTLS (client certificate, JKS→PFX) + Basic Auth | NA | AIS KV |
| Function App → PIM | Function App | PIM REST API | OAuth 2.0 | NA |  |
| Function App → Blob Storage | Function App | Azure Blob Storage (`eim` container) | Managed Identity SAMI | N/A | N/A |
| Function App → AIS Key Vault | Function App | Existing AIS KV | Managed Identity SAMI (Key Vault Secrets User) | N/A | AIS KV |
| Function App → Enabling/SMC Key Vault | Function App | Existing Enabling KV | Managed Identity SAMI (Key Vault Secrets User) | N/A | Enabling KV |
| Function App → SMC (APIM) | Function App | Existing APIM instance | HTTPS + APIM Subscription Key | `SMC-API-Subscription-Key` (shared, existing) | Enabling KV |
| Function App → Application Insights | Function App | `t3-met-mdmsupplierinfo-{env}-ae-func-ai` | Instrumentation key | N/A | N/A |

#### 6.3.2 External Dependencies

| Service | Owner/responsibility |
| --- | --- |
| MDM REST API | Supplier MDM/IBM MDM platform team |
| ALM Sorted API | ALM Liquor platform team |
| Food Sorted API | Food e-commerce platform team |
| STIBO STEP PIM API (EAII-302) | STIBO/PIM platform team |
| JMS-to-Service Bus bridge | Separate enabling workstream |
| GoAnywhere | Infrastructure/MFT team; Blob pickup reconfiguration required |

## 6.4 Infrastructure Support

NA

## 6.5 Infrastructure Requirements

| Component | Resource Name (pattern) | Non-Prod Specification | Prod Specification | New / Existing |
| --- | --- | --- | --- | --- |
| Function App | `t3-met-mdmsupplierinfo-{env}-ae-func` | Consumption or EP1 | Same | New |
| App Service Plan | `t3-met-mdmsupplierinfo-{env}-ae-asp` | Consumption or EP1 — open item | Same | New |
| Application Insights | `t3-met-mdmsupplierinfo-{env}-ae-func-ai` | Standard | Standard | New |
| Log Analytics Workspace | Existing shared per env | Existing shared workspace | Existing shared workspace | Existing |
| Service Bus Namespace | `t1-met-npr-ae-sb-001` (non-prod) / `t1-met-prd-ae-sb-001` (prod) | Standard tier | Premium tier (private endpoint) | Existing |
| **Service Bus Topic** | `data.SupplierInfoFromMDM.{env}.sbt` | Standard — 3 subscriptions on one topic | Standard — 3 subscriptions on one topic | New |
| Storage Account | `t3data{env}aesta01` | Standard LRS/GRS — whatever the existing account is already configured as | Same | Existing |
| Blob Container | `eim` (path `toeim/supplierinfo`) | N/A (inside storage account) | N/A | ExistingExisting |
| Key Vault (AIS) | `t3datadv1ae1kv01` / `t3datast1ae1kv01` / `t3dataut1ae1kv01` / `t3dataprdae1kv01` | Standard/Premium — whatever is already configured | Same |  |
| Key Vault (Enabling/SMC) | `t3enabling{env}ae1kv01` etc. | — | — | Existing |
| APIM | `t3-met-core-{env}-ae1-apim` | — | — | Existing (SMC-managed) |

| **Component** | **Name** | **New / Existing** |
| --- | --- | --- |
| **Azure Function App** | `t3-met-mdmsupplierinfo-{env}-ae-func` | New |
| **Azure Key Vault** | `t3data{env}ae1kv01`<br> <br>`t3enabling{env}ae1kv01` | Existing<br> <br>Existing |
| **Resource Group** | `t3-met-ais-{env}-ae1-rsg-data` | Existing |
| **Subscription** | `COREIT-SERVICES-AIS-{env}` | Existing |
| **Virtual Network / Subnet** | `t2-met-ais-{env}-ae1-net-01 / SENS` | Existing |
| **Azure Application Insights** | `t3-met-mdmsupplierinfo-{env}-ae-func-ai` | New |

**{env} -** dv1, st1, ut1 and prd

**AIS Spoke Virtual Network Details**

| Resource | Azure Resource Provider | Environment | Virtual Network | Address Space |
| --- | --- | --- | --- | --- |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | DV1 | t2-met-ais-dv1-ae1-net-01 | 10.247.80.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | ST1 | t2-met-ais-st1-ae1-net-01 | 10.247.88.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | UT1 | t2-met-ais-ut1-ae1-net-01 | 10.247.96.0/21 |
| AIS Spoke Virtual Network | Microsoft.Network/virtualNetworks | PR1 | t2-met-ais-pr1-ae1-net-01 | 10.249.32.0/21 |

**Subnet Security and Private Connectivity**

The solution is deployed within dedicated subnets in the enterprise Virtual Network. Each subnet is governed by enterprise networking standards and is associated with the appropriate Network Security Group (NSG) managed by the Enterprise Networking team.

| Subnet | Purpose |
| --- | --- |
| **SENS** | Application subnet hosting Azure Function App integration resources. |
| **HSENS** | Private Endpoint subnet hosting Azure Private Endpoints for integration services. |
| **ECCS2** | Hosts Azure API Management (APIM) instances for the DEV and PRD environments. |
| **ECCS3** | Hosts the Azure API Management (APIM) instance for the SIT environment. |
| **ECCS4** | Hosts the Azure API Management (APIM) instance for the UAT environment. |
| **ECIS1** | Hosts Azure Application Gateway, providing Layer 7 load balancing and secure ingress routing to Azure API Management (APIM) and backend integration services. |

**Spoke Subnets:-**

**SENS (Function App Application Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Application Subnet (SENS)** | **Function App** |
| --- | --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.86.0/24 | `t3-met-metproducts-dv1-ae-func` |
| **ST1** | 10.247.88.0/21 | 10.247.92.0/24 | `t3-met-metproducts-st1-ae-func` |
| **UT1** | 10.247.96.0/21 | 10.247.98.0/24 | `t3-met-metproducts-ut1-ae-func` |
| **PRD** | 10.249.32.0/21 | 10.249.38.0/23 | `t3-met-metproducts-prd-ae-func` |

**HSENS (Private Endpoint Subnet):-**

| **Environment** | **Virtual Network Address Space** | **Private Endpoint Subnet (HSENS)** |
| --- | --- | --- |
| **DV1** | 10.247.80.0/21 | 10.247.80.0/23 |
| **UT1** | 10.247.88.0/21 | 10.247.88.0/23 |
| **ST1** | 10.247.96.0/21 | 10.247.100.0/23 |
| **PRD** | 10.249.32.0/21 | 10.249.32.0/23 |

**Hub Subnets:-**

| **Env** | **VNet** | **Subnet** | **Subnet CIDR** | **Public IP** | **Private IP** |
| --- | --- | --- | --- | --- | --- |
| **Dev** | t1-met-core-npr-ae1-net-hub | ECCS2 | 10.247.1.0/26 | 4.254.116.233 | 10.247.1.4 |
| **Sit** | t1-met-core-npr-ae1-net-hub | ECCS3 | 10.247.3.0/26 | 4.254.35.128 | 10.247.3.4 |
| **Uat** | t1-met-core-npr-ae1-net-hub | ECCS4 | 10.247.3.64/26 | 4.195.115.66 | 10.247.3.68 |
| **Prd** | t1-met-core-prd-ae1-net-hub | ECCS2 | 10.249.1.0/26 | 4.254.21.194 | 10.249.1.12 |

**Private Endpoints and Private DNS Zones**

Private Endpoints (`Microsoft.Network/privateEndpoints`) are deployed in the **HSENS** subnet to provide secure, private connectivity to Azure Platform-as-a-Service (PaaS) resources. All services listed below are accessible only through their private IP addresses within the Virtual Network, with **Public Network Access disabled** on each target resource.

Private Endpoints are used in preference to public endpoints to ensure Azure services remain accessible only from the AIS Virtual Network, reducing the attack surface and eliminating exposure to the public Internet. This approach aligns with the enterprise network security standard for Azure Integration Services deployments.

Private DNS Zone integration is configured to ensure DNS queries resolve to the private IP address associated with each Private Endpoint rather than the corresponding public endpoint.

**Azure Resource Provider:** `Microsoft.Network/privateEndpoints`

**Private DNS Zone Resource Provider:** `Microsoft.Network/privateDnsZones`

All Private DNS Zones are linked to both the **Hub Virtual Network** and the **AIS Spoke Virtual Network** to ensure private name resolution for outbound connections originating from the Function App.

**Environment :** `{env}` = `dv1`, `st1`, `ut1`, `prd`

## 7 Communication Overview

![Communication Diagram-20260825-093004.png](images/14.png)

### 7.1 Communication Components

The solution uses Azure Service Bus subscriptions for inbound event delivery, Blob Storage for the EAII-301 reference and output-file flow, HTTPS REST calls for MDM and the Sorted targets, and APIM for SMC observation calls.

## 8 Data Architecture

### 8.1 Data Model

No relational or persistent data model is introduced. XML, JSON, and flat-file payloads are transformed transiently. EAII-301 uses Blob Storage as transient file staging.

### 8.2 Stored Procedures

Not applicable.

### 8.3 Stored Procedure Triggers

Not applicable.

### 8.4 Database Technical Specification

Not applicable; no database is used.

### 8.5 Data Retention

| Data | Location | Retention |
| --- | --- | --- |
| Inbound JMS payload | Blob Storage, `t3data{env}aesta01` | Aligned to Service Bus message TTL via lifecycle policy |
| EIM output | Blob Storage `eim/toeim/supplierinfo` | Existing 30-day retention |
| SMC observations | SMC | Platform retention policy |
| Application Insights telemetry | Log Analytics | Workspace retention policy |
| ALM/Food outbound payloads | Target systems | Target-owned retention |
| PIM outbound payloads (EAII-302) | STIBO STEP PIM | Target-owned retention |
| MDM responses | Not persisted | Transient only |

## 9 Deployment and Monitoring Considerations

### 9.1 Transition Period

Deployment follows the standard AIS Azure DevOps CI/CD pipeline pattern (new pipeline, once the repo `Metcash.AIS.Data.MDMSupplierInfo` is created — §00-index open items) through the stages: Build → DEV (dv1) → SIT (st1) → UAT (ut1) → PROD (prd), with approval gates at SIT, UAT, and PROD stages.

### 9.2 Deployment Preference

Not applicable.

### 9.3 Environment Migration

- Pull Request → DV1 automated deployment.
- DV1 → ST1 → UT1 → PROD through gated approvals.
- Infrastructure is defined in Bicep templates in `metcash-ais-infrastructure`.

## 10 Disaster Recovery

Not applicable.

## 11 Support Documentation

![diagram](images/15.png)

## 12 Limitations and Constraints

| **Sr. No** | **Description** | **Limitation/Constraint** | **Remarks** |
| --- | --- | --- | --- |
| 1 | Azure function can accept the request data up to 100 MB. | The HTTP request length is limited to 100 MB (104,857,600 bytes), and the URL length is limited to 4 KB (4,096 bytes) | [https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits](https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cisolated-process%2Cnodejs-v4%2Cfunctionsv2&pivots=programming-language-csharp#limits) |

## 2 Scope

![Interface Scope Overview-20260825-092754.png](images/02.png)

### 2.1 In Scope

- **EAII-301:** Supplier MDM to EIM as a pipe-delimited flat file via Azure Blob Storage.
- **EAII-302:** Supplier MDM to STIBO STEP PIM as a STEP-ProductInformation XML supplier
- **EAII-516:** Supplier MDM to Food Sorted via REST/JSON.
- **EAII-517:** Supplier MDM to ALM Sorted via REST/JSON.
- Service Bus subscription consumption, MDM retrieval, transformation, and target delivery.
- SMC Gen 3 onboarding for audit, logging, and exception management.
- Azure Key Vault integration for secrets and credentials.
- Azure Managed Identity for Azure service-to-service authentication.
- In-message EIM deduplication of repeated reference-data values.

### 2.2 Out of Scope

- Changes to the MDM, ALM Sorted, or Food Sorted APIs.
- Upstream JMS-to-Service Bus bridging.
- Cross-message EIM deduplication.

## 3 Compliance

### 3.1 Architecture Principles

| Code | Principle | Application |
| --- | --- | --- |
| IDP-001 | Generic and Reusable | Shared `Metcash.AIS.Data.MDMSupplierInfo.Common` library provides the MDM client, SMC wrapper, retry policy, and Key Vault access. |
| IDP-002 | Decoupled Integrations | A shared Service Bus topic with independent subscriptions isolates the four interfaces. |
| IDP-004 | Resilient and Recoverable | All four interfaces retry target delivery in-process and dead-letter failures immediately on exhaustion or unhandled exception, guaranteeing no silent message loss. EAII-302 additionally carries a Gold SLA / RED-RED Horizon classification requiring no message loss end-to-end. |
| IDP-005 | Observability | Full end-to-end observability is delivered via SMC Gen 3 (single-call `StartObservation` with `IsObservationComplete = true` per invocation) and Azure Application Insights (`TrackEvent`, `TrackException`, dependency telemetry). |

*Reference:*[Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

## 4 Requirements Overview

### 4.1 Business Process Requirement and Integration

Supplier MDM is the source of truth for supplier legal entities, pay-to and buy-from relationships, agreements, terms, rebates, and category splits. When data changes, independent channels distribute the updated contract data to downstream consumers.

- **EIM:** receives 11 pipe-delimited record types for warehousing and reporting.
- **ALM Sorted:** receives a JSON supplier entity through a REST API.
- **Food Sorted:** receives a JSON supplier entity through a REST API.
- **STIBO STEP PIM:** receives a STEP-ProductInformation XML supplier hierarchy through a REST API, OAuth 2.0 authenticated (EAII-302).

Each message contains a lightweight reference or blob pointer. The Function retrieves the full Reference Message XML where required, calls MDM, transforms the response, and delivers the target-specific output.

Relevant documents:

| **Title** | **Link** |
| --- | --- |
| Relevant document 1 | [Functional Specification - EAII-301, EAII-517, EAII-516 - Supplier MDM to EIM, ALM Sorted, Food Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035496449/Functional+Specification+-+EAII-301+EAII-517+EAII-516+-+Supplier+MDM+to+EIM+ALM+Sorted+Food+Sorted) |
| Relevant document 2 | [Mapping Manifest - EAII-301, EAII-517, EAII-516 - Supplier MDM to EIM, ALM Sorted, Food Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519447059/Mapping+Manifest+-+EAII-301+EAII-517+EAII-516+-+Supplier+MDM+to+EIM+ALM+Sorted+Food+Sorted) |
| Relevant document 3 | [Mapping - EAII-301 - Supplier Contract to EIM - Supplier MDM to EIM](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519774730/Mapping+-+EAII-301+-+Supplier+Contract+to+EIM+-+Supplier+MDM+to+EIM) |
| Relevant document 4 | [Mapping - EAII-517, EAII-516 - Supplier Contract to ALM Sorted, Food Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3519381529/Mapping+-+EAII-517+EAII-516+-+Supplier+Contract+to+ALM+Sorted+Food+Sorted) |
| Relevant document 5 | [Functional Specification - EAII-302 - Supplier MDM to STIBO](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3035529217/Functional+Specification+-+EAII-302+-+Supplier+MDM+to+STIBO) |
| Relevant document 6 | [Mapping - EAII-302 - Supplier Contract (MDM) to PIM (STIBO)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3495985203/Mapping+-+EAII-302+-+Supplier+Contract+MDM+to+PIM+STIBO) |

### 4.2 Technical Standards and Requirements

- XML for MDM request/response envelopes.
- JSON for ALM Sorted, Food Sorted, and SMC payloads.
- Pipe-delimited flat files for EIM.
- HTTPS/TLS 1.2+ for outbound communication.
- Azure Service Bus topic and subscriptions.
- Azure Function App isolated worker on .NET 10.
- Azure Key Vault for secrets.
- SMC Gen 3 for centralized monitoring.

### 4.3 Required Components

- Azure Function App and App Service Plan.
- Azure Service Bus topic with three subscriptions.
- Azure Virtual Network and private endpoints.
- Existing AIS and Enabling/SMC Key Vaults.
- Application Insights and Log Analytics.
- Existing Storage Account (`t3data{env}aesta01`), container `eim`, path `toeim/supplierinfo`.
- Existing Storage Account (`t3data{env}aesta01`) for the inbound JMS publisher payload.
- Existing APIM instance for SMC.
- GoAnywhere MFT for EAII-301 onward delivery.
- OAuth 2.0 client credentials and token endpoint for STIBO STEP PIM (EAII-302 only).

### 4.4 Environmental Requirement

| Environment | Suffix | Purpose |
| --- | --- | --- |
| DEV | `dv1` | Development and integration testing |
| SIT | `st1` | System Integration Testing |
| UAT | `ut1` | User Acceptance Testing |
| PROD | `prd` | Production |

Aligns with the AIS Governance Environments Strategy . [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy)



====================================================================================================
## DOC: TSD-EAII-304
====================================================================================================

# 1 Document Overview

## 1.1 Background

Independent Brands Australia (IBA), a division of Australian Liquor Marketers (ALM) within Metcash, manages several liquor retail brands, including **The Bottle-O**, **Cellarbrations**, and **Porters**. IBA operates the **Directs** service, which enables liquor suppliers, such as **CUB** and **Coopers**, to electronically submit direct delivery order data to Metcash. These transactions represent supplier-to-retailer deliveries that bypass the traditional Metcash warehouse distribution network.

The IBA Directs integration allows suppliers to upload direct delivery transaction data through a secure REST API. Each submission contains supplier information, product details (including item codes, descriptions, GTINs, and pack sizes), customer and retailer information (including account numbers, names, and addresses), and invoice details such as invoice numbers, dates, quantities, and monetary values.

Upon successful upload, the submitted source file is securely stored in Azure Blob Storage and processed asynchronously. The integration extracts and transforms the source JSON data into a pipe-separated values (PSV) file that conforms to the format required by the **Enterprise Information Management (EIM)** platform. The generated PSV file is then delivered to the ALM landing location for downstream processing and reporting.

This document describes the functional requirements and technical design for re-implementing the existing IBA Directs integration on **Azure Integration Services (AIS)** as part of the migration from the legacy **TIBCO BusinessWorks** platform. The solution leverages Azure API Management, Logic Apps, Azure Functions, Azure Blob Storage, Event Grid, Service Bus, and other Azure platform services to provide a secure, scalable, and event-driven integration architecture.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the *IBA Directs ALM Orders* (EAII-304) between *Liquor Suppliers* and *EIM*.

## 1.3 Glossary

| **Item** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| ALM | Australian Liquor Marketers - Metcash's liquor distribution division |
| EIM | Enterprise Information Management - downstream data processing platform |
| GTIN | Global Trade Item Number - international barcode standard for products |
| IBA | Independent Brands Australia - a division of ALM managing retail brands |
| PSV | Pipe-Separated Values - a flat file format using the pipe character as a delimiter |

# 2 Scope

*The scope of the integration should be clearly defined to ensure all stakeholders have a comprehensive understanding of its objectives and boundaries. This includes identifying the systems involved, the specific functionalities to be integrated, and the expected outcomes. By establishing a well-defined scope, we can facilitate smoother collaboration and ensure that all parties are aligned on the project goals.*

## 2.1 In Scope

The following capabilities are included in the scope of this integration:

- Receipt of direct delivery order data from liquor suppliers via a REST API.
- Authentication of API requests using OAuth 2.0 Bearer Tokens.
- Validation of incoming requests, including payload structure and file size.
- Storage of uploaded source files in Azure Blob Storage.
- Event-driven asynchronous processing of uploaded files.
- Decompression of uploaded ZIP files.
- Transformation of source data into the required Pipe-Separated Values (PSV) format.
- Delivery of generated PSV files to the designated output location.
- Archival of successfully processed source files.
- Error handling with retry mechanisms for transient failures.
- Transaction logging and auditability.
- Cleanup of temporary processing artifacts.

## 2.2 Out of Scope

The following items are outside the scope of this integration:

- Downstream processing of PSV files by the Enterprise Information Management (EIM) platform.
- File transfer from the Azure Blob Storage output location to downstream systems, which is performed by GoAnywhere Managed File Transfer (MFT).
- Business validation of direct delivery order data, such as supplier, product, or customer master data validation.
- Migration or reprocessing of historical direct delivery order data.

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

| **Code** | **Principle** | **Why It Applies** |
| --- | --- | --- |
| **IDP-001** | **Generic and Reusable** | The integration is implemented using reusable Azure components, including Azure API Management, Logic Apps, Azure Functions, and the shared Blob Management Function. The upload, transformation, and storage components are designed for reuse across integrations where applicable. |
| **IDP-002** | **Decoupled Integrations** | The consumer-facing REST API is decoupled from downstream processing through Azure Blob Storage, Event Grid, and Azure Service Bus. This event-driven architecture enables independent scaling, asynchronous processing, and loose coupling between file upload, transformation, and downstream delivery. |
| **IDP-003** | **Integrated Security** | Consumer-facing APIs are secured using OAuth 2.0 Bearer Token authentication through Azure API Management. Secrets, certificates, and connection information are stored in Azure Key Vault and accessed using Managed Identity. All communication between Azure services is secured using Azure-native authentication and HTTPS. |
| **IDP-004** | **Standardization** | The solution follows Metcash Azure Integration Services standards by exposing REST APIs through Azure API Management, implementing orchestration with Logic Apps, using inline functions for transformation, and following the Azure resource naming conventions and deployment standards. |
| **IDP-005** | **Resilient and Recoverable** | The solution uses Azure-native resiliency features, including Event Grid retry policies, Azure Service Bus durable messaging and dead-letter queues, and configurable retry policies in Logic Apps and Azure Functions to recover from transient failures and ensure reliable message processing. |
| **IDP-006** | **Observability** | End-to-end transaction monitoring is provided through SMC, while Azure Application Insights captures request telemetry, dependency tracking, exceptions, and performance metrics. Logic App run history, Azure Function logs, and Azure Monitor diagnostics support operational monitoring and troubleshooting. |

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

| **Pattern Name** | **Implementation Description** |
| --- | --- |
| **Azure Logic Apps** | Azure Logic Apps are used to orchestrate the upload and asynchronous processing workflows. The workflows are stateless, modular, and designed around discrete business capabilities, improving maintainability and scalability. |
| **API Management Service** | Azure API Management (APIM) acts as the secure API gateway, exposing the upload REST endpoint to liquor suppliers. APIM provides request authentication, payload validation, policy enforcement, and abstracts the backend implementation from consumers. |
| **Event-Driven Processing** | Azure Event Grid is used to trigger downstream processing when a source file is successfully uploaded to Azure Blob Storage. This enables an event-driven architecture and decouples file upload from transformation processing. |
| **Asynchronous Messaging** | Azure Service Bus is used to decouple file transformation from downstream processing. Queue-based messaging provides reliable, asynchronous processing and supports retry and dead-letter handling for failed messages. |
| **Azure Functions** | Azure Functions implement reusable processing components for blob management, ZIP file decompression, and transformation of source data into the required PSV format. |
| **Retry and Resilience** | Azure-native retry mechanisms are implemented across Logic Apps, Azure Functions, Event Grid, and Service Bus to handle transient failures. Dead-letter queues are used for messages that cannot be successfully processed after the configured retry attempts. |
| **Logging and Observability** | Application Insights and SMC provide end-to-end monitoring, including request telemetry, dependency tracking, exception logging, transaction tracing, and operational diagnostics. |
| **Security Abstraction** | Security is enforced through Azure API Management using OAuth 2.0 Bearer Token authentication. Secrets, certificates, and application configuration are securely stored in Azure Key Vault and accessed using Managed Identity. |
| **Standardization and Governance** | The solution adheres to Metcash Azure Integration Services standards, including standardized API design, Azure resource naming conventions, consistent error handling, monitoring, and deployment practices. |

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

![image-20260703-052306.png](images/02.png)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| FSD EAII-304 - Liquor Suppliers to EIM | [Functional Specification - EAII-304 - Liquor Suppliers to EIM](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3504013319/Functional+Specification+-+EAII-304+-+Liquor+Suppliers+to+EIM) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization
- Managed Identities for Azure service-to-service authentication (Logic Apps, Function Apps accessing Key Vault, Service Bus, Blob Storage)

## 4.3 Required Components

The following components are required for this integration:

| **Component** | **Purpose / Description** |
| --- | --- |
| **Azure API Management (APIM)** | Exposes the inbound REST API endpoint (**POST eis/ibadirects/v1/submitOrder**) to liquor suppliers. Performs OAuth 2.0 Bearer Token authentication, request validation, payload schema validation, and file size validation before forwarding requests to the backend. |
| **Azure Logic Apps** | The **Translation Logic App** is triggered by messages received from Azure Service Bus and orchestrates the end-to-end asynchronous processing workflow, including source ZIP retrieval, decompression, data transformation, PSV file generation, source file archival, and error handling. |
| **Azure Function Apps** | Provides reusable processing components, including Blob Management (UploadBlob), ZIP file decompression, and transformation of the extracted source data into the required PSV format. |
| **Azure Event Grid** | Monitors Azure Blob Storage for newly uploaded files and publishes Blob Created events to trigger asynchronous processing by the Processing Logic App. |
| **Azure Service Bus** | Provides reliable asynchronous messaging between the transformation process and downstream processing. Supports durable message delivery, retries, and dead-letter queues for failed processing. |
| **Azure Blob Storage** | Serves as the durable storage layer for uploaded source files, processed PSV files, archived files, and error files throughout the integration lifecycle. |
| **Azure Key Vault** | Securely stores application secrets, certificates, and configuration required by the integration. Secrets are accessed using Managed Identity. |
| **Azure Application Insights** | Provides application telemetry, request tracking, dependency monitoring, exception logging, and performance metrics for Logic Apps and Azure Functions. |
| **Azure Log Analytics Workspace** | Centralizes diagnostic logs and monitoring data from Azure resources, enabling cross-component log analysis, dashboards, and alerting. |
| **Azure Virtual Network (VNet)** | Provides secure network connectivity for Azure resources and supports private communication between integration components where required. |

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DV1)
- System Integration Testing (ST1)
- User Acceptance Test (UT1)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).



====================================================================================================
## DOC: TSD-EAII-333
====================================================================================================

# 1 Document Overview

## 1.1 Background

This Technical Specification documents the re-implementation of the EAII-333 Campbells Payment integration on Azure Integration Services (AIS). The integration is being migrated from TIBCO BusinessWorks Container Edition (BWC) to Azure API Management (APIM) as part of the enterprise integration platform modernisation.

The Campbells Payment integration supports the payment capture process for the Campbells Retailers division. After warehouse pick and pack is complete, Storeline (the legacy warehouse/POS system) sends a payment capture request which is forwarded to Sorted (SAP Commerce Cloud / Braintree payment gateway) for payment processing. The result is returned synchronously to Storeline.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the **Campbells Payment Capture** service between **Storeline** (source) and **Sorted / SAP Commerce Cloud** (target) via **Azure API Management**.

## 1.3 Glossary

| **Term** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| APIM | Azure API Management - the specific AIS component used for this integration |
| Braintree | Payment gateway provider used by SAP Commerce Cloud for payment processing |
| BW6 | BusinessWorks Container Edition - legacy TIBCO deployment model for this service |
| Campbells Portal | Customer-facing web storefront where Campbells retailers place orders |
| EAII | Enterprise Application Integration Interface - Metcash interface catalogue identifier |
| PE | Platform Engine - order management system that routes orders from the Campbells portal to Storeline |
| SAP Commerce Cloud | E-commerce platform (formerly Hybris) - the technology underpinning Sorted |
| SOAP | Simple Object Access Protocol - XML-based messaging protocol |
| Sorted | SaaS platform running SAP Commerce Cloud that processes payments for the Campbells division |
| Storeline | Legacy warehouse and point-of-sale system that initiates payment capture after order pick and pack |
| SMC | Service Management Console - monitoring and audit platform |

# 2 Scope

## 2.1 In Scope

- Payment capture request processing from Storeline to Sorted (SAP Commerce Cloud) via APIM
- Protocol translation from SOAP/XML to REST/JSON
- Request field mapping (orderId → URL path parameter, paymentAmount → captureAmount query parameter)
- Scientific notation to decimal conversion for paymentAmount (e.g., `2.9674E4` → `29674`)
- Response interpretation and error message formatting (responseCode evaluation)
- Synchronous request-reply pattern
- Audit logging (begin, end, warning, error events) via Application Insights
- TLS/SSL secured communication with the target system (mutual TLS with client certificate)
- Error handling with structured SOAP fault responses

## 2.2 Out of Scope

- Payment authorization (pre-capture step handled elsewhere)
- Payment refund processing
- Order management or order status updates
- Customer account management
- Batch payment processing
- The legacy SOAP-to-SOAP path (no longer active - not migrated)
- **Known Issue NOT addressed:** The `requestTimeout` field behavior - timeouts will continue to be managed at the HTTP client configuration level, not dynamically from the request payload

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

- *<Enterprise Pattern Catalogue>*
- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

Refer to FSD Section 3.1.1.1 Process Diagram.

![image-20260615-233229.png](images/06.png)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-333 - Storeline to CCC | [Functional Specification - EAII-333 - Campbells Retailers to Sorted](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3061612545/Functional+Specification+-+EAII-333+-+Campbells+Retailers+to+Sorted) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol
- WSDL 1.1 for SOAP web service contract
- SOAP 1.2 for SOAP web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization
- X509 digital certificate based for authentication, authorization as well as message encryption

## 4.3 Required Components

The following components are required for this integration:

- Azure App Service Plan Azure API Management service (APIM)
- Azure Key Vault (for client certificates and secrets)
- Azure Application Insights (for logging and monitoring)
- Azure Log Analytics workspace
- Azure Virtual Network (for network isolation)

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DEV)
- System Integration Testing (SIT)
- User Acceptance Test (UAT)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).



====================================================================================================
## DOC: TSD-EAII-514
====================================================================================================

# 1 Document Overview

## 1.1 Background

Metcash operates a pricing enquiry service that enables downstream ordering and e-commerce systems collectively referred to as "Sorted" (encompassing the IGA, Campbells, and C-Store portals) to retrieve real-time product pricing information from Power Enterprise (PE), the legacy ERP system hosted on an IBM AS/400 platform. This service is invoked on-demand during the order placement workflow to ensure that pricing presented to retailers reflects the correct current wholesale cost, promotional pricing, allowances, and related pricing components for a given product, customer, warehouse, and date combination.

The integration currently runs on the TIBCO BusinessWorks 6 (BW6) platform and is being migrated to Azure Integration Services (AIS) as part of the enterprise integration modernization programmed. The service is highly utilized with a peak volume of 10,784 calls/hour (378 calls/minute) and migration to AIS is expected to reduce load on the existing BW Container (BWC) infrastructure. Both Sorted and PE are classified as RED systems under the Horizon Impact Assessment, meaning only business-critical changes are permitted after review.

The integration exposes one REST/JSON API at initial phase serving the business function via calling the AS/400 stored procedure (CX40K6B). The core pricing logic remains entirely within the AS/400 system; the integration layer is responsible solely for protocol translation, field transformation, and orchestration of per-product stored procedure calls.

## 1.2 Document Purpose

The primary purpose of this document is to outline the specifics, requirements, and steps pertaining to the integration of the *EAII-514 Realtime Pricing* service between *Sorted* and *PE - Power Enterprise on IBM AS/400*.

## 1.3 Glossary

| **Term** | **Description** |
| --- | --- |
| AIS | Azure Integration Services - the target integration platform |
| AS/400 | IBM midrange server hosting Power Enterprise |
| CLE | Common Logging Events - the Metcash centralized logging framework |
| GSB | Gold/Silver/Bronze service classification |
| PE | Power Enterprise - legacy ERP system hosted on IBM AS/400, managing pricing among other business functions |
| Pillar | Metcash business division (IGA, ALM, CCC, CSD) |
| Sorted | Customer-facing ordering/e-commerce portal (encompasses IGA, Campbells, and C-Store portals) that invokes the pricing service |

# 2 Scope

## 2.1 In Scope

- Synchronous real-time pricing enquiry for up to 20 products per request
- REST/JSON API endpoint (POST)
- Stored procedure invocation against the AS/400 Power Enterprise system for price calculation
- Database outage mode with configurable error response
- Audit logging of service invocations (transaction history)
- Error handling with structured fault responses (HTTP 500)
- On-Premises Data Gateway connectivity from Azure VNet to IBM AS/400 JDBC endpoint

## 2.2 Out of Scope

- Changes to the AS/400 stored procedure (CX40K6B) or its calculation logic
- Changes to the consuming Sorted platform's integration client
- Batch pricing operations or scheduled pricing extracts
- Price data persistence or caching within the integration layer

# 3 Compliance

## 3.1 Architecture Principles

The following Metcash principles will apply:

- [Integration Design Principles - v1.0](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1656913947/Integration+Design+Principles+-+v1.0)

| Code | Principle | Why It Applies |
| --- | --- | --- |
| **IDP-001** | Generic and Reusable | The pricing query Logic App is designed as a protocol-agnostic orchestrator. The AS/400 connector and field-transformation utilities are implemented as reusable inline functions. |
| **IDP-002** | Decoupled Integrations | The consumer-facing endpoints are decoupled from the AS/400 backend via Azure API Management and a Logic App orchestration layer. The AS/400 stored procedure interface is accessed only through the Logic App, not directly by consumers. |
| **IDP-003** | Integrated Security | All credentials (AS/400 JDBC connection string, AS/400 username/password) are<br> stored in Azure Key Vault and accessed exclusively via the Logic App's<br> System-Assigned Managed Identity at runtime. No secrets are stored in application<br> configuration or source code. Consumer-facing API security is enforced via OAuth<br> 2.0 Bearer token validation in Azure API Management. APIM subscription keys are<br> not used for this integration; authentication is token-based only, aligned with<br> the Gen-3 security standard. |
| **IDP-004** | Standardization | The integration implements the Metcash standard API patterns. Azure resource names follow the Azure Abbreviation Recommendations naming convention. |
| **IDP-005** | Resilient and Recoverable | The database outage flag provides a controlled degradation path for planned AS/400 maintenance windows. The AS/400 connection pool is configured with a 30-second query timeout per product call. |
| **IDP-006** | Observability | Every invocation logs a start event, end event, and error event to SMC. Transaction history is persisted with UUID, service name, timestamps, destination, and status fields. |

## 3.2 Standards, Guidelines and Patterns

The following standards, guidelines and patterns will apply:

| **Pattern Name** | **Implementation Description** |
| --- | --- |
| **Azure Logic Apps** | Azure Logic Apps are used to implement integration workflows is designed to be stateless, modular, and focused on a single business capability, enabling easier maintenance and extensibility. |
| **API Management Service** | Azure API Management (APIM) acts as the API gateway, securely exposing Logic App endpoints to Sorted To PE. APIM abstracts the backend implementation, enabling versioning, and policy enforcement without impacting consumers. |
| **Retry and Resilience** | Azure API Management (APIM) retry policies and timeout controls to handle transient failures when interacting with logic apps. |
| **Logging and Observability** | Logging and telemetry are captured using **SMC**, providing visibility into request execution, response status, correlation IDs, and exception details. This enables effective monitoring, troubleshooting, and operational support. |
| **Security Abstraction** | Security is enforced at the API layer using APIM policies. Secrets and credentials required for backend access are stored securely in **Azure Key Vault** and accessed via Managed Identity. The solution is designed to support OAuth-based authentication, aligning with Gen-3 security standards and eliminating hardcoded credentials. |
| **Standardization and Governance** | All interfaces comply with Metcash integration standards, including consistent API naming conventions, standardized error handling, and structured JSON responses. |

Information related to all Standards, Guidelines and Patterns refer

- [Guidelines](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1668874252/Guidelines)
- [AIS (Azure Integration Services)](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1638498308/AIS+Azure+Integration+Services)

# 4 Requirements Overview

## 4.1 Business Process Requirement and Integration

### 4.1.1 Process Diagram from FSD

[Functional Specification - EAII-514 - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3486121993/Functional+Specification+-+EAII-514+-+Sorted+to+PE#3.1.1.1-Process-Diagram)

![image-20260628-234851.png](images/04.png)

### 4.1.2 Functional Specification Document

| **Title** | **Link to the FSD** |
| --- | --- |
| Functional Specification - EAII-514 - Sorted to PE | [Functional Specification - EAII-514 - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3486121993/Functional+Specification+-+EAII-514+-+Sorted+to+PE) |
| Mapping - EAII-514 - Realtime Pricing - Sorted to PE | [Mapping - EAII-514 - Realtime Pricing - Sorted to PE](https://metcash.atlassian.net/wiki/spaces/MAP/pages/3485794308/Mapping+-+EAII-514+-+Realtime+Pricing+-+Sorted+to+PE) |

## 4.2 Technical standard and requirements

**The application of the industry standard Service Architecture which includes but not limited to the following adoption of :**

- JSON 2.2.0 for REST web service contract
- REST for REST web service communication protocol

**Adoption of Industry standard security best practice:**

- oAuth2 for API authentication and authorization

## 4.3 Required Components

The following components are required for this integration:

| **Azure Resource** | **Purpose** |
| --- | --- |
| **Azure Virtual Network** | Provides secure network isolation for integration resources. Logic Apps use VNet Integration for outbound connectivity to the on-premises gateway and IBM AS/400, while Private Endpoints restrict inbound access to Azure services. |
| **Azure Key Vault** | Securely stores and manages sensitive configuration, including the AS/400 connection string, credentials, and other application secrets. |
| **Azure Logic Apps (Standard)** | Implements the core orchestration workflow by receiving requests from Azure API Management, validating inputs, processing product requests, invoking the IBM AS/400 backend, and returning the consolidated response. |
| **Azure API Management** | Publishes the REST (`/eis/pricing/v1/getrealtimeprice`) endpoint for Sorted consumers, while enforcing authentication, authorization, request validation, and API policies. |

## 4.4 Environmental Requirement

The following environments will be used for this interface:

- Development (DV1)
- System Integration Testing (ST1)
- User Acceptance Test (UT1)
- Production (PROD)

The above also aligns to the AIS Governance [Environments Strategy](https://metcash.atlassian.net/wiki/spaces/MAP/pages/1637548092/Environments+Strategy).
