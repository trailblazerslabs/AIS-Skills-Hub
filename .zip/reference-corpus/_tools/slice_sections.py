#!/usr/bin/env python3
"""Slice matching sections out of every converted document for cross-corpus comparison.

Usage:
    python slice_sections.py --docs reference-corpus/converted/tsd \
        --sections "^6(\\.|$)" --out reference-corpus/_analysis/sec6.md
"""

import argparse
import re
from pathlib import Path

HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
NUMBERED = re.compile(r"^\**\s*([0-9]+(?:\.[0-9]+)*)\s*[-–—]?\s*(.*)$")


def sections(md_text):
    """Yield (number, title, level, [lines]) for every numbered heading."""
    lines = md_text.splitlines()
    marks = []
    for i, line in enumerate(lines):
        m = HEADING.match(line)
        if not m:
            continue
        num = NUMBERED.match(m.group(2).replace("**", "").strip())
        if num:
            marks.append((i, len(m.group(1)), num.group(1), num.group(2).strip()))

    for idx, (start, level, num, title) in enumerate(marks):
        end = len(lines)
        for nstart, nlevel, _, _ in marks[idx + 1:]:
            if nlevel <= level:
                end = nstart
                break
        yield num, title, level, lines[start:end]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", required=True)
    ap.add_argument("--sections", required=True, help="regex matched against section number")
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-lines", type=int, default=0, help="truncate each slice")
    args = ap.parse_args()

    pattern = re.compile(args.sections)
    out = []
    for d in sorted(Path(args.docs).iterdir()):
        if not d.is_dir():
            continue
        md = next(d.glob("*.md"), None)
        if not md:
            continue
        text = md.read_text(encoding="utf-8")
        hits = [s for s in sections(text) if pattern.match(s[0])]
        # keep only outermost matches
        kept, seen_ranges = [], []
        for num, title, level, body in hits:
            if any(num.startswith(k + ".") for k in seen_ranges):
                continue
            seen_ranges.append(num)
            kept.append((num, title, level, body))
        if not kept:
            continue
        out.append(f"\n\n{'=' * 100}\n## DOC: {d.name}\n{'=' * 100}\n")
        for num, title, level, body in kept:
            if args.max_lines:
                body = body[: args.max_lines] + (["...[truncated]"] if len(body) > args.max_lines else [])
            out.append("\n".join(body))

    target = Path(args.out)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\n".join(out), encoding="utf-8")
    print(f"{target}  ({len(''.join(out)):,} chars, {sum(1 for l in ''.join(out).splitlines()):,} lines)")


if __name__ == "__main__":
    main()
