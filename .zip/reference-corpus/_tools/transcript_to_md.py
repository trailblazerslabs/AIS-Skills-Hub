#!/usr/bin/env python3
"""Convert a Teams/Confluence meeting-recording transcript (.docx) to speaker-turn Markdown.

Teams exports transcripts as a .docx with no paragraph styles, in the repeating pattern:

    {Speaker Name}   {mm:ss or h:mm:ss}
    {utterance text, possibly spanning several paragraphs}

This script groups consecutive paragraphs into speaker turns and numbers them, so the
result can be cited precisely (e.g. "Turn 42, Magesh Parthasarathy, 15:29") when the
generator extracts a design decision from the transcript.

Usage:
    python transcript_to_md.py <file.docx> --outdir <dir>
"""

import argparse
import re
import sys
from pathlib import Path

import docx

SPEAKER_LINE = re.compile(r"^(?P<name>[A-Za-z][A-Za-z .'\-]*?)\s{2,}(?P<ts>\d{1,2}:\d{2}(?::\d{2})?)\s*$")
META_TITLE = re.compile(r"Meeting Recording$")
META_DURATION = re.compile(r"^\d+[hm].*\d+[sm]$|^\d+m\s*\d+s$")


def load_paragraphs(path):
    """Flatten python-docx paragraphs into plain lines.

    python-docx renders explicit soft line-breaks (<w:br/>) as "\\n" inside a single
    paragraph's .text, so a whole speaker turn (name+timestamp line, then utterance
    lines) commonly arrives as ONE paragraph. Split on "\\n" to recover individual lines.
    """
    d = docx.Document(str(path))
    lines = []
    for p in d.paragraphs:
        for raw in p.text.split("\n"):
            lines.append(raw.strip())
    return lines


def parse_turns(paragraphs):
    """Return (title, date, duration, [(turn_no, speaker, timestamp, [lines])])."""
    title = date = duration = None
    turns = []
    current = None

    for line in paragraphs:
        if not line:
            continue
        if title is None and META_TITLE.search(line):
            title = line
            continue
        if date is None and re.match(r"^\d{1,2} \w+ \d{4},", line):
            date = line
            continue
        if duration is None and META_DURATION.match(line):
            duration = line
            continue
        if line.endswith("started transcription") or line.endswith("stopped transcription"):
            if current:
                turns.append(current)
                current = None
            turns.append((None, "(system)", None, [line]))
            continue

        m = SPEAKER_LINE.match(line)
        if m:
            if current:
                turns.append(current)
            current = (None, m.group("name").strip(), m.group("ts"), [])
        elif current:
            current[3].append(line)
        # else: stray line before any speaker turn is established — drop it (usually blank/meta)

    if current:
        turns.append(current)

    numbered = []
    n = 0
    for _, speaker, ts, lines in turns:
        if speaker != "(system)":
            n += 1
            numbered.append((n, speaker, ts, lines))
        else:
            numbered.append((None, speaker, ts, lines))
    return title, date, duration, numbered


def to_markdown(path, title, date, duration, turns):
    out = [f"<!-- Source: {path.name} (Teams meeting recording transcript, converted) -->", ""]
    out.append(f"# {title or path.stem}")
    out.append("")
    if date:
        out.append(f"**Date:** {date}  ")
    if duration:
        out.append(f"**Duration:** {duration}")
    out.append("")
    out.append("---")
    out.append("")
    for n, speaker, ts, lines in turns:
        text = " ".join(l for l in lines if l).strip()
        if speaker == "(system)":
            out.append(f"*{text}*")
            out.append("")
            continue
        header = f"**Turn {n} — {speaker}**" + (f" *({ts})*" if ts else "")
        out.append(header)
        out.append("")
        out.append(text if text else "*(no speech captured)*")
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def convert(path, outdir):
    paragraphs = load_paragraphs(path)
    title, date, duration, turns = parse_turns(paragraphs)
    md = to_markdown(path, title, date, duration, turns)

    outdir.mkdir(parents=True, exist_ok=True)
    name = re.sub(r"[^\w.-]+", "-", path.stem).strip("-")
    out_path = outdir / f"{name}.md"
    out_path.write_text(md, encoding="utf-8")

    speaker_turns = sum(1 for n, s, ts, l in turns if s != "(system)")
    speakers = sorted({s for _, s, _, _ in turns if s != "(system)"})
    print(f"  {path.name}\n    -> {out_path}  ({speaker_turns} turns, {len(speakers)} speakers: {', '.join(speakers)})")
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    src = Path(args.input)
    outdir = Path(args.outdir)
    files = sorted(src.glob("*.docx")) if src.is_dir() else [src]
    if not files:
        print("No .docx files found", file=sys.stderr)
        return 1

    print(f"Converting {len(files)} transcript(s) -> {outdir}")
    for f in files:
        try:
            convert(f, outdir)
        except Exception as exc:
            print(f"  !! FAILED {f.name}: {exc}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
