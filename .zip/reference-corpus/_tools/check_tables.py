#!/usr/bin/env python3
"""Verify every markdown table has a consistent column count across header, separator and rows.

Usage:
    python check_tables.py <file.md> [<file.md> ...]

Exits non-zero if any table is malformed.
"""

import re
import sys
from pathlib import Path

SEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")
CODE_SPAN = re.compile(r"`[^`]*`")


def cells(line):
    # Pipes inside inline code, escaped pipes, and HTML entities are not column separators.
    line = CODE_SPAN.sub(lambda m: m.group(0).replace("|", "\x00"), line.strip())
    line = line.replace(r"\|", "\x00")
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip().replace("\x00", "|") for c in line.split("|")]


def check(path):
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    problems = []
    i = 0
    while i < len(lines):
        if "|" in lines[i] and i + 1 < len(lines) and SEP.match(lines[i + 1]):
            header_n = len(cells(lines[i]))
            sep_n = len(cells(lines[i + 1]))
            start = i + 1
            if sep_n != header_n:
                problems.append((start, f"separator has {sep_n} cells, header has {header_n}"))
            j = i + 2
            while j < len(lines) and lines[j].strip().startswith("|"):
                n = len(cells(lines[j]))
                if n != header_n:
                    problems.append((j + 1, f"row has {n} cells, header has {header_n}"))
                j += 1
            i = j
        else:
            i += 1
    return problems


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    failed = False
    for arg in sys.argv[1:]:
        problems = check(arg)
        if problems:
            failed = True
            print(f"{arg}: {len(problems)} malformed table row(s)")
            for line_no, msg in problems:
                print(f"  line {line_no}: {msg}")
        else:
            print(f"{arg}: OK")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
