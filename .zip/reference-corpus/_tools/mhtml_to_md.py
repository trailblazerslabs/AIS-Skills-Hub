#!/usr/bin/env python3
"""Convert Confluence 'Export to Word' MHTML files (.doc extension) to Markdown.

Each source document becomes:
    <outdir>/<DocName>/<DocName>.md
    <outdir>/<DocName>/images/<n>-<name>.<ext>

Usage:
    python mhtml_to_md.py <input-file-or-dir> --outdir <dir>
"""

import argparse
import email
import email.policy
import re
import sys
from pathlib import Path

from bs4 import BeautifulSoup, NavigableString, Tag

MIME_EXT = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/gif": ".gif",
    "image/svg+xml": ".svg",
    "image/bmp": ".bmp",
    "image/webp": ".webp",
    "image/x-emf": ".emf",
    "image/x-wmf": ".wmf",
    "image/tiff": ".tif",
}

BLOCK_TAGS = {
    "html", "body", "div", "section", "article", "main", "header", "footer",
    "p", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li", "table",
    "thead", "tbody", "tfoot", "tr", "td", "th", "pre", "blockquote", "hr",
    "figure", "figcaption", "dl", "dt", "dd", "center",
}

SKIP_TAGS = {"script", "style", "meta", "link", "head", "title", "col", "colgroup"}


def slugify(text, maxlen=80):
    text = re.sub(r"[^\w\s.-]", "", text, flags=re.UNICODE).strip()
    text = re.sub(r"[\s_]+", "-", text)
    return text[:maxlen].strip("-") or "untitled"


DOC_PREFIX = [
    ("Technical", "TSD"),
    ("Functional", "FSD"),
    ("Mapping Manifest", "MANIFEST"),
    ("Mapping", "MAP"),
]


def short_name(stem):
    """Compact, MAX_PATH-safe folder name derived from doc type + EAII ids."""
    title = stem.replace("+", " ")
    prefix = next((p for k, p in DOC_PREFIX if title.strip().startswith(k)), "DOC")
    ids = re.findall(r"EAII-(\d+)", title)
    if ids:
        return f"{prefix}-EAII-" + "_".join(dict.fromkeys(ids))
    return f"{prefix}-" + slugify(title, 40)


MAGIC = [
    (b"\x89PNG\r\n\x1a\n", ".png"),
    (b"\xff\xd8\xff", ".jpg"),
    (b"GIF87a", ".gif"),
    (b"GIF89a", ".gif"),
    (b"BM", ".bmp"),
    (b"%PDF", ".pdf"),
    (b"\x01\x00\x00\x00", ".emf"),
    (b"\xd7\xcd\xc6\x9a", ".wmf"),
    (b"PK\x03\x04", ".zip"),
]


def sniff_ext(data, ctype):
    for sig, ext in MAGIC:
        if data.startswith(sig):
            return ext
    head = data[:400].lstrip()
    if head.startswith(b"<?xml") or head.startswith(b"<svg"):
        low = head.lower()
        if b"<svg" in low:
            return ".svg"
        if b"mxfile" in low or b"mxgraphmodel" in low:
            return ".drawio"
        return ".xml"
    if head.startswith(b"<mxfile") or head.startswith(b"<mxGraphModel"):
        return ".drawio"
    return MIME_EXT.get(ctype, ".bin")


def parse_mhtml(path):
    """Return (html_string, [binary_parts]). Confluence exports binaries as octet-stream."""
    with open(path, "rb") as fh:
        msg = email.message_from_binary_file(fh, policy=email.policy.default)

    html = None
    images = []
    for part in msg.walk():
        ctype = (part.get_content_type() or "").lower()
        if ctype == "multipart/related":
            continue
        if ctype == "text/html" and html is None:
            try:
                html = part.get_content()
            except Exception:
                payload = part.get_payload(decode=True) or b""
                html = payload.decode("utf-8", errors="replace")
        elif ctype.startswith("image/") or ctype == "application/octet-stream":
            images.append(part)
    return html, images


def save_images(images, img_dir):
    """Write image parts to disk. Return {lookup_key: relative_path}."""
    img_dir.mkdir(parents=True, exist_ok=True)
    mapping = {}
    for idx, part in enumerate(images, start=1):
        data = part.get_payload(decode=True)
        if not data:
            continue
        ctype = (part.get_content_type() or "").lower()
        loc = part.get("Content-Location") or ""
        cid = (part.get("Content-ID") or "").strip("<>")

        ext = sniff_ext(data, ctype)
        filename = f"{idx:02d}{ext}"
        (img_dir / filename).write_bytes(data)
        rel = f"images/{filename}"

        for key in filter(None, [loc, cid, f"cid:{cid}" if cid else None]):
            mapping[key] = rel
        if loc:
            mapping[Path(loc.split("?")[0]).name] = rel
    return mapping


def resolve_img(src, mapping):
    if not src:
        return None
    for key in (src, src.split("?")[0], Path(src.split("?")[0]).name,
                src[4:] if src.startswith("cid:") else None):
        if key and key in mapping:
            return mapping[key]
    return None


def render_inline(node, mapping):
    if isinstance(node, NavigableString):
        return re.sub(r"[ \t\r\f\v]+", " ", str(node)).replace("\n", " ")
    if not isinstance(node, Tag) or node.name in SKIP_TAGS:
        return ""

    name = node.name
    inner = "".join(render_inline(c, mapping) for c in node.children)

    if name == "br":
        return "\n"
    if name in ("strong", "b"):
        return f"**{inner.strip()}**" if inner.strip() else ""
    if name in ("em", "i"):
        return f"*{inner.strip()}*" if inner.strip() else ""
    if name in ("code", "tt", "kbd", "samp"):
        return f"`{inner.strip()}`" if inner.strip() else ""
    if name in ("del", "s", "strike"):
        return f"~~{inner.strip()}~~" if inner.strip() else ""
    if name == "img":
        rel = resolve_img(node.get("src"), mapping)
        alt = (node.get("alt") or "").strip() or "diagram"
        return f"![{alt}]({rel})" if rel else f"*[image not embedded: {node.get('src','')}]*"
    if name == "a":
        href = (node.get("href") or "").strip()
        text = inner.strip()
        if not text:
            return ""
        if not href or href.startswith("#"):
            return text
        return f"[{text}]({href})"
    return inner


def cell_text(node, mapping):
    parts = []
    for child in node.children:
        if isinstance(child, Tag) and child.name in ("p", "div", "li", "br", "ul", "ol", "table"):
            txt = render_block_as_text(child, mapping)
        else:
            txt = render_inline(child, mapping)
        if txt:
            parts.append(txt)
    text = "\n".join(p for p in parts if p is not None)
    text = re.sub(r"\n{2,}", "\n", text).strip()
    text = text.replace("|", "&#124;")
    return text.replace("\n", "<br>")


def render_block_as_text(node, mapping):
    if isinstance(node, NavigableString):
        return re.sub(r"\s+", " ", str(node)).strip()
    if node.name in ("ul", "ol"):
        return "\n".join(
            "- " + render_inline(li, mapping).strip()
            for li in node.find_all("li", recursive=False)
        )
    if node.name == "table":
        return " / ".join(
            cell_text(td, mapping) for td in node.find_all(["td", "th"])
        )
    return render_inline(node, mapping).strip()


def render_table(table, mapping):
    rows = []
    for tr in table.find_all("tr"):
        cells = tr.find_all(["td", "th"], recursive=False) or tr.find_all(["td", "th"])
        if not cells:
            continue
        row = []
        for c in cells:
            row.append(cell_text(c, mapping))
            span = int(c.get("colspan", 1) or 1)
            row.extend([""] * (span - 1))
        rows.append(row)
    if not rows:
        return []

    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]

    out = ["| " + " | ".join(rows[0]) + " |",
           "|" + "|".join([" --- "] * width) + "|"]
    for r in rows[1:]:
        out.append("| " + " | ".join(r) + " |")
    out.append("")
    return out


def render_list(node, mapping, depth=0):
    lines = []
    ordered = node.name == "ol"
    for i, li in enumerate(node.find_all("li", recursive=False), start=1):
        marker = f"{i}." if ordered else "-"
        pad = "  " * depth
        sublists = [c for c in li.find_all(["ul", "ol"], recursive=False)]
        for sl in sublists:
            sl.extract()
        text = render_inline(li, mapping).strip()
        text = re.sub(r"\s+", " ", text)
        if text:
            lines.append(f"{pad}{marker} {text}")
        for sl in sublists:
            lines.extend(render_list(sl, mapping, depth + 1))
    lines.append("")
    return lines


def render_block(node, mapping, out):
    if isinstance(node, NavigableString):
        text = re.sub(r"\s+", " ", str(node)).strip()
        if text:
            out.append(text)
            out.append("")
        return
    if not isinstance(node, Tag) or node.name in SKIP_TAGS:
        return

    name = node.name

    if name in ("h1", "h2", "h3", "h4", "h5", "h6"):
        text = render_inline(node, mapping).strip()
        text = re.sub(r"\s+", " ", text)
        if text:
            out.append("#" * int(name[1]) + " " + text)
            out.append("")
        return
    if name == "p":
        text = render_inline(node, mapping).strip()
        text = re.sub(r"[ \t]+", " ", text)
        if text:
            out.append(text)
            out.append("")
        return
    if name in ("ul", "ol"):
        out.extend(render_list(node, mapping))
        return
    if name == "table":
        out.extend(render_table(node, mapping))
        return
    if name == "pre":
        out.append("```")
        out.append(node.get_text().rstrip())
        out.append("```")
        out.append("")
        return
    if name == "blockquote":
        sub = []
        for c in node.children:
            render_block(c, mapping, sub)
        out.extend("> " + line if line else ">" for line in sub)
        out.append("")
        return
    if name == "hr":
        out.append("---")
        out.append("")
        return
    if name == "img":
        text = render_inline(node, mapping)
        if text:
            out.append(text)
            out.append("")
        return

    if name in BLOCK_TAGS:
        for c in node.children:
            render_block(c, mapping, out)
        return

    text = render_inline(node, mapping).strip()
    if text:
        out.append(text)
        out.append("")


def html_to_markdown(html, mapping):
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup.find_all(list(SKIP_TAGS)):
        tag.decompose()
    body = soup.body or soup
    out = []
    for child in body.children:
        render_block(child, mapping, out)

    text = "\n".join(out)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip() + "\n"


def convert(path, outdir):
    html, images = parse_mhtml(path)
    if html is None:
        print(f"  !! no HTML part found in {path.name}", file=sys.stderr)
        return None

    name = short_name(path.stem)
    doc_dir = outdir / name
    doc_dir.mkdir(parents=True, exist_ok=True)

    mapping = save_images(images, doc_dir / "images") if images else {}
    md = html_to_markdown(html, mapping)

    header = (
        f"<!-- Source: {path.name} -->\n"
        f"<!-- Title: {path.stem.replace('+', ' ')} -->\n\n"
    )
    md_path = doc_dir / f"{name}.md"
    md_path.write_text(header + md, encoding="utf-8")

    img_count = len(list((doc_dir / "images").glob("*"))) if (doc_dir / "images").exists() else 0
    print(f"  {path.name}\n    -> {md_path.relative_to(outdir)}  ({len(md):,} chars, {img_count} images)")
    return md_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    src = Path(args.input)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    files = sorted(src.glob("*.doc")) if src.is_dir() else [src]
    if not files:
        print("No .doc files found", file=sys.stderr)
        return 1

    print(f"Converting {len(files)} file(s) -> {outdir}")
    for f in files:
        try:
            convert(f, outdir)
        except Exception as exc:
            print(f"  !! FAILED {f.name}: {exc}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
