#!/usr/bin/env python3
"""Inspect .drawio files: list pages, decompress content, and summarise style vocabulary.

Usage:
    python inspect_drawio.py <file-or-dir> [--dump <outdir>]

--dump writes one decompressed .xml per page so the raw mxGraphModel can be read.
"""

import argparse
import base64
import re
import sys
import urllib.parse
import zlib
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET


def decompress(payload):
    """drawio stores pages as base64(raw-deflate(url-encoded xml)) unless saved uncompressed."""
    try:
        raw = base64.b64decode(payload)
        inflated = zlib.decompress(raw, -zlib.MAX_WBITS)
        return urllib.parse.unquote(inflated.decode("utf-8"))
    except Exception:
        return None


def pages(path):
    tree = ET.parse(path)
    root = tree.getroot()
    out = []
    for diagram in root.iter("diagram"):
        name = diagram.get("name") or "(unnamed)"
        inner = list(diagram)
        if inner and inner[0].tag == "mxGraphModel":
            xml = ET.tostring(inner[0], encoding="unicode")
        else:
            xml = decompress((diagram.text or "").strip())
        out.append((name, xml or ""))
    return out


STYLE_KEYS = (
    "shape", "fillColor", "strokeColor", "swimlane", "edgeStyle", "rounded",
    "dashed", "image", "sketch", "html", "verticalLabelPosition",
)


def summarise(xml):
    if not xml:
        return {}
    styles = re.findall(r'style="([^"]*)"', xml)
    vertices = xml.count('vertex="1"')
    edges = xml.count('edge="1"')

    shapes = Counter()
    fills = Counter()
    azure_icons = Counter()
    for s in styles:
        for part in s.split(";"):
            if part.startswith("shape="):
                shapes[part[6:]] += 1
            elif part.startswith("fillColor="):
                fills[part[10:]] += 1
            elif part.startswith("mxgraph."):
                azure_icons[part.split("=")[0]] += 1
        if "swimlane" in s:
            shapes["swimlane"] += 1
        if "mxgraph.azure" in s:
            m = re.search(r"(mxgraph\.azure[0-9a-z_]*\.[A-Za-z0-9_]+)", s)
            if m:
                azure_icons[m.group(1)] += 1
    return {
        "vertices": vertices,
        "edges": edges,
        "shapes": shapes.most_common(12),
        "fills": fills.most_common(12),
        "azure": azure_icons.most_common(15),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--dump")
    args = ap.parse_args()

    src = Path(args.input)
    files = sorted(src.glob("*.drawio")) if src.is_dir() else [src]

    for f in files:
        print(f"\n{'=' * 100}\nFILE: {f.name}  ({f.stat().st_size / 1024:.0f} KB)")
        try:
            ps = pages(f)
        except Exception as exc:
            print(f"  !! parse failed: {exc}")
            continue
        print(f"  pages: {len(ps)}")
        for i, (name, xml) in enumerate(ps, 1):
            info = summarise(xml)
            print(f"\n  [{i}] {name}")
            if not xml:
                print("      (could not decode)")
                continue
            print(f"      vertices={info['vertices']} edges={info['edges']} chars={len(xml):,}")
            if info["shapes"]:
                print(f"      shapes: {info['shapes']}")
            if info["fills"]:
                print(f"      fills:  {info['fills']}")
            if info["azure"]:
                print(f"      azure:  {info['azure']}")
            if args.dump:
                d = Path(args.dump) / f.stem
                d.mkdir(parents=True, exist_ok=True)
                safe = re.sub(r"[^\w.-]", "_", name)[:60]
                (d / f"{i:02d}-{safe}.xml").write_text(xml, encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main())
