#!/usr/bin/env python3
"""Summarise a dumped drawio page: one line per cell with label and style.

Usage:
    python summarise_page.py <page.xml> [--max 200] [--styles-only]
"""

import argparse
import html
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def clean(v):
    v = html.unescape(v or "")
    v = re.sub(r"<[^>]*>", " ", v)
    return re.sub(r"\s+", " ", v).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("page")
    ap.add_argument("--max", type=int, default=250)
    ap.add_argument("--styles-only", action="store_true")
    args = ap.parse_args()

    text = Path(args.page).read_text(encoding="utf-8")
    cells = re.findall(r"<mxCell\b([^>]*?)/?>", text, re.S)

    seen = set()
    count = 0
    for attrs in cells:
        style = (re.search(r'style="(.*?)"', attrs, re.S) or [None, ""])[1]
        value = clean((re.search(r'value="(.*?)"(?=\s+\w+=|\s*/?$)', attrs, re.S) or [None, ""])[1])
        cid = (re.search(r'id="(.*?)"', attrs) or [None, ""])[1]
        # Drop enormous embedded data URIs
        style = re.sub(r"image=data:[^;\"]*", "image=data:<embedded>", style)
        if args.styles_only:
            key = re.sub(r"image=[^;]*", "image=…", style)
            if key in seen:
                continue
            seen.add(key)
            print(style[:220])
        else:
            print(f"{cid[:26]:28s} | {value[:55]:55s} | {style[:170]}")
        count += 1
        if count >= args.max:
            print("…truncated")
            break


if __name__ == "__main__":
    main()
