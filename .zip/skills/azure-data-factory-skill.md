# Azure Data Factory Skill — Squad 20

> Status: Observed — derived from `Metcash.AIS.B2B.Datafactory`, `Metcash.AIS.B2C.Datafactory`, `Metcash.AIS.RMN.01.Datafactory`, `Metcash.AIS.RMN.02.Datafactory`.

---

## ADF Repository Structure

```
{RepoRoot}/
├── factory/                    ← ADF factory JSON files (one per ADF instance)
│   └── t3-met-ais-{env}-{region}-adf-{platform}-{instance}.json
├── dataset/                    ← Dataset definitions
│   └── {dataset_name}.json
├── integrationRuntime/         ← IR definitions (Azure IR or SHIR)
│   └── {ir_name}.json
├── linkedService/              ← Linked service definitions
│   └── ls_{domain}_{type}_{instance}_{ir}.json
├── managedVirtualNetwork/      ← (Optional) Managed VNet config
├── pipeline/                   ← Pipeline definitions
│   └── pl_{domain}_{action}_{src}_{tgt}_{type}.json
├── trigger/                    ← Trigger definitions
│   └── {trigger_name}.json
└── publish_config.json         ← ADF publish branch config
```

**Evidence:** `Metcash.AIS.B2B.Datafactory` (main), `Metcash.AIS.B2C.Datafactory` (main)

---

## Factory Naming

```
t3-met-ais-{env}-{region}-adf-{platform}-{instance}
```

| Resource | Name |
|---|---|
| Main ADF | `t3-met-ais-dev-ae-adf-01` |
| B2B ADF | `t3-met-ais-dev-ae-adf-b2b-01` |
| RMN ADF | `t3-met-ais-dev-ae-adf-rmn-01` |

---

## Pipeline Naming Convention

```
pl_{domain}_{action}_{source}_{target}_{loadtype}
```

All lowercase with underscores.

| Token | Observed Values |
|---|---|
| `{domain}` | `ubereats`, `b2b`, `sku`, `sm`, `rmn` |
| `{action}` | `ingest`, `load`, `transform`, `copy`, `extract` |
| `{source}` | `sql`, `blob`, `adls`, `sftp` |
| `{target}` | `adls`, `sql`, `blob` |
| `{loadtype}` | `fullload`, `delta`, `parent`, `child`, `incremental` |

### Observed Pipeline Names (B2C.Datafactory)

| Pipeline | Description |
|---|---|
| `pl_ubereats_ingest_inventory_excluded` | UberEats excluded inventory |
| `pl_ubereats_ingest_inventory_sql_adls_delta_child` | Delta child pipeline |
| `pl_ubereats_ingest_inventory_sql_adls_delta_parent` | Delta parent pipeline |
| `pl_ubereats_ingest_inventory_sql_adls_fullload` | Full load pipeline |
| `pl_ubereats_ingest_product_sql_adls` | Product data load |

---

## Linked Service Naming Convention

```
ls_{domain}_{service_type}_{instance}_{ir_type}
```

| Token | Values |
|---|---|
| `{ir_type}` | `air` (Azure Integration Runtime), `shir` (Self-Hosted IR) |
| `{service_type}` | `adls` (ADLS Gen2), `sqlserver` (SQL Server), `blob` |
| `{instance}` | `st01`, `st02`, etc. |

### Observed Linked Service Names (B2B.Datafactory)

| Name | Service Type | IR |
|---|---|---|
| `ls_sku_adls_st01_air` | Azure Blob Storage | Azure IR |
| `ls_sm_adls_st01_air` | Azure Blob Storage | Azure IR |
| `ls_sm_adls_st01_shir` | Azure Blob Storage | Self-Hosted IR |

### Linked Service — Standard Structure

```json
{
  "name": "ls_{domain}_{type}_{instance}_{ir}",
  "type": "Microsoft.DataFactory/factories/linkedservices",
  "properties": {
    "annotations": [],
    "type": "AzureBlobStorage",
    "typeProperties": {
      "connectionString": "..."
    }
  }
}
```

**Authentication note:** The B2B Datafactory repo showed a `connectionString` with `encryptedCredential`. New pipelines should use **Managed Identity** instead of connection strings where supported. Label as **[Recommended]** — not consistently observed yet.

---

## Dataset Naming

**[Inferred]** Follow same lowercase underscore pattern as pipelines:

```
ds_{domain}_{datatype}_{format}
```

---

## Integration Runtime

Two IR types observed:

| Type | Abbreviation | Use Case |
|---|---|---|
| Azure Integration Runtime | `air` | Cloud-to-cloud data movement |
| Self-Hosted IR | `shir` | On-premises or private network data sources |

---

## publish_config.json

```json
{
  "repoConfiguration": {
    "type": "FactoryGitHubConfiguration",
    "hostName": "",
    "accountName": "...",
    "repositoryName": "...",
    "collaborationBranch": "main",
    "rootFolder": "/",
    "lastCommitId": ""
  },
  "excludedObjects": []
}
```

---

## ADF Repository Domains (Observed)

| Domain | Repo | Description |
|---|---|---|
| B2B | `Metcash.AIS.B2B.Datafactory`, `Metcash.AIS.B2B.01.Datafactory` | B2B data pipelines |
| B2C | `Metcash.AIS.B2C.Datafactory` | B2C data pipelines (UberEats, etc.) |
| RMN | `Metcash.AIS.RMN.01.Datafactory`, `Metcash.AIS.RMN.02.Datafactory` | Retail Media Network ADF |
| AIS DevOps | `Metcash.AIS.ADF.DevOps` | Shared ADF pipeline templates |

---

## Key Rules

1. All pipeline and linked service names must be lowercase with underscores.
2. Use the `pl_` prefix for pipelines, `ls_` for linked services, `ds_` for datasets.
3. Use Azure IR (`air`) for cloud-to-cloud; use SHIR (`shir`) for on-premises sources.
4. **[Recommended]** New linked services should use Managed Identity authentication, not connection strings.
5. Factory JSON files are in `factory/` and named after the ADF resource.
6. Use `publish_config.json` to set the collaboration branch to `main`.
7. Parent/child pipeline patterns use `_parent` and `_child` suffixes.

---

## Observed Evidence

| Repository | File Path | Pattern Observed |
|---|---|---|
| `Metcash.AIS.B2B.Datafactory` | `/factory/t3-met-ais-dev-ae-adf-b2b-01.json` | Factory naming convention |
| `Metcash.AIS.B2B.Datafactory` | `/linkedService/ls_sku_adls_st01_air.json` | Linked service naming |
| `Metcash.AIS.B2C.Datafactory` | `/pipeline/pl_ubereats_ingest_inventory_sql_adls_delta_parent.json` | Pipeline naming |
| `Metcash.AIS.B2C.Datafactory` | `/dataset/`, `/trigger/` | Standard ADF folder structure |
