# Squad 20 Platform Domain Patterns

> Status: Observed — derived from repository structure, APIOps API names, and integration patterns across Squad 20 repositories.

---

## Platform Domains

### B2B — Business to Business

**Repositories:**
- `Metcash.AIS.B2B.Datafactory` — ADF pipelines for B2B data movement
- `Metcash.AIS.B2B.01.Datafactory` — Additional B2B ADF (large repo, 1.8GB)
- `Metcash.AIS.B2B.Cloudinary` — Cloudinary image management Function App
- `Metcash.AIS.B2B.CreditApplication` — Credit application Function App
- `Metcash.AIS.B2B.Sorted` — Sorted delivery integration
- `Metcash.AIS.B2B.ExtendedProductInfo` — Extended product info integration
- `Metcash.AIS.B2B.SQLDB` — SQL database integrations
- `Metcash.B2B.ProductData` — Product data integrations

**Known APIs (APIM gen-3):**
- `b2b-almconnect-to-almretailer-v1`
- `b2b-almretailer-to-almconnect-v1`
- `b2b-almkeyretail`
- `b2b-cloudinary-v1`
- `b2b-creditapplication-v1`
- `b2b-externalsupplier-to-sorted-v1`

**Typical Patterns:**
- Function App (Pattern A: standalone) — Cloudinary, CreditApplication, Sorted
- Service Bus topic → Logic App → APIM → External system
- ADF bulk data pipelines

---

### B2C — Business to Consumer

**Repositories:**
- `Metcash.AIS.B2C.Datafactory` — B2C ADF pipelines (UberEats, etc.)
- `Metcash.AIS.B2C.Delivery` — Delivery integrations
- `Metcash.AIS.B2C.Finance` — Finance integrations
- `Metcash.AIS.B2C.IndiPIM` — IndiPIM product data
- `Metcash.AIS.B2C.Marketing` — Marketing integrations
- `Metcash.AIS.B2C.Pricing` — Pricing integrations
- `Metcash.AIS.B2C.SQLDB` — SQL database
- `Metcash.AIS.B2C.Store` — Store operations (inventory, invoices)
- `Metcash.AIS.B2C.Wynshop` — Wynshop marketplace Logic App

**Known APIs (APIM gen-3):**
- `b2c-marketplace-api-v6`
- `b2c-marketplace-api-v7`
- `b2c-orderstatus-to-fauxpos-v1`
- `b2c-products-to-fauxpos-v1`

**Known Backends:**
- `t3-met-b2c-wynshop-ae-logic-backend` (Logic App)
- `t3-met-b2c-indipim-ae-logic-backend` (Logic App)
- `b2c-store-func` (Function App)

**Known Named Values (store integrations):**
- `b2c-store-inventory-bulk-delete-interfaceid`
- `b2c-store-inventory-delete-interfaceid`
- `b2c-store-inventory-update-interfaceid`
- `b2c-store-invoice-detail-interfaceid`
- `b2c-store-invoice-list-interfaceid`
- `b2c-store-func-key`

**Typical Patterns:**
- Logic App Standard with APIM → downstream store / marketplace
- ADF pipeline: SQL → ADLS delta load (UberEats, product data)

---

### Enabling Platform

**Repositories:**
- `Metcash.AIS.Enabling.AzureBlobManagement` — Blob Management Function App
- `Metcash.AIS.Enabling.Common` — Shared enabling platform code
- `Metcash.AIS.Enabling.Notifications` — Notifications service (Logic App + email)
- `Metcash.AIS.Enabling.R2W` — Read-to-Write integrations

**Known APIs (APIM gen-3):**
- `enabling-azure-blob-management-v1`
- `enabling-notifications-v1`

**Known Backends:**
- `enabling-azure-blob-management-function-app`
- `enabling-notification-logicapp`

**Known Policy Fragments (enabling-specific):**
- `enabling-azure-blob-management-backend-retry-handler`
- `enabling-azure-blob-management-response-handler`
- `enabling-azure-blob-management-in-bound-request-validator`

**Tags:** `Enabling`, `Notifications`

**Typical Patterns:**
- Standalone Function App (Pattern A): BlobManagement, Notifications
- HTTP (APIM) → Function App (delegated execution)
- Logic App for orchestration-heavy flows

---

### Corporate Platform

**Repositories:**
- `Metcash.AIS.Corp.Giftcard` — Gift card activation
- `Metcash.AIS.Corp.RPA.DocMgmt` — RPA document management

**Known APIs (APIM gen-3):**
- `fin-giftcardactivation-rpa-v1`
- `finance-giftcardservices-v1`
- `corporate-mumbatochris21-v1`
- `rpa-uipathwebapi-v1`

**Typical Patterns:**
- HTTP (APIM) → RPA (UIPath) / Finance system
- Logic App orchestrating multi-step approval/activation flows

---

### RMN — Retail Media Network

**Repositories:**
- `Metcash.AIS.RMN` — Logic App + Function App workspace (consent subscribers, FTI sync)
- `Metcash.AIS.RMN.01.Datafactory` — RMN ADF pipelines
- `Metcash.AIS.RMN.02.Datafactory` — RMN ADF pipelines (second repo)
- `Metcash.AIS.B2B.Datafactory.RMN` — B2B-side RMN ADF

**Workflows (EAII IDs observed in RMN Logic App):**
- `EAII-432-consentsubscriber-braze-tt` — Consent → Braze (TT banner)
- `EAII-433-consentsubscriber-braze-ihg` — Consent → Braze (IHG)
- `EAII-434-consentsubscriber-braze-food` — Consent → Braze (Food)
- `EAII-435-consentsubscriber-braze-alm` — Consent → Braze (ALM)
- `EAII-438-ftisync-salesforce-sharepoint` — FTI Sync → Salesforce + SharePoint
- `EAII-480-consentsubscriber-braze-unknown` — Consent → Braze (Unknown)
- `EAII-481-tijsync-salesforce-sharepoint` — TIJ Sync → Salesforce + SharePoint

**Inline Assemblies:**
- `lib/custom/TransformAndValidateInvoice/`
- `lib/custom/TransformAndValidateTaxInvoiceJournal/`

**Typical Patterns:**
- Logic App (Pattern B): multiple workflows in one workspace
- Service Bus → Logic App → Braze (marketing platform)
- Logic App → Salesforce / SharePoint via connectors

---

### ALMNZ — New Zealand ALM

**Repositories:**
- `Metcash.AIS.ALMNZ.Consignments`
- `Metcash.AIS.ALMNZ.SupplyChainOps`
- `Metcash.AIS.ALMNZ.WMS` — Warehouse Management System

**Status:** Limited code on main branch. Active on feature branches.

---

### Data

**Repositories:**
- `Metcash.AIS.Data.Metproducts` — PIM to PE product changes (Logic App Standard + Function App)

**Workflows:**
- `PIMToPEProductChanges` (EAII-254)
- Service Bus topic: `data.metproducts.{env}.sbt`

---

### Shared Services

**Repositories:**
- `Metcash.AIS.Shared.ClientApps` — Shared client application code
- `Metcash.AIS.Shared.Copilot` — AI coding agent tooling
- `Metcash.AIS.Shared.Copilot.Prompts` — Prompt templates for AI agents

**Function App (Shared):**
- `t3-met-sharedservicescommon-dev-ae-func` — Hosts `JMSPublisher` function used by Metproducts Logic App

---

### IBA / Loyalty

**Repositories:**
- `Metcash.RetailTech.Loyalty` — Loyalty program integrations

**Known APIs (APIM gen-3):**
- `iba-loyalty-app`

---

### SMC / Platform Monitoring

**APIs:**
- `smc-v1` — SMC observability endpoint (path: `monitoring/smc/v1`)
- Backend: `SMC-FunctionApp`
- Named value: `smc` (subscription key), `SMC-FunctionApp-Key`
- Every integration must call `smc-v1` for start/end observation

---

## Cross-Platform Integration Patterns

| Pattern | Platforms | Description |
|---|---|---|
| PIM → PE | Data → B2C | Product changes from PIM to PE (EAII-254) |
| Consent → Braze | RMN | Customer consent to marketing platform |
| FTI/TIJ Sync | RMN | Financial/transaction sync to Salesforce |
| ALM Connect ↔ ALM Retailer | B2B | Two-way ALM integration via APIM |
| Blob Management | Enabling | Shared blob CRUD via Function App + APIM |
| Notifications | Enabling | Email/notification dispatch via Logic App + APIM |
| Gift Card Activation | Corporate | RPA-driven gift card activation via APIM |
