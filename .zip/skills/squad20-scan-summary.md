# Squad 20 Repository Scan Summary

> Generated from: METCASHDevOps / Squad 20 project
> Scan date: Session summary (see session memory for details)
> Methodology: ADO repo listing + recursive directory scans + key file reads

---

## Repositories Scanned (Evidence Collected)

| Repository | Branch(es) Examined | Depth | Key Finding |
|---|---|---|---|
| `Metcash.AIS.Data.Metproducts` | `main`, `release_200617`, `feature/pim-to-pe-ai-code` | Deep | **Reference Logic App Standard workspace** (Pattern A) |
| `Metcash.AIS.RMN` | `main` | Deep | Logic App Pattern B, EAII workflow naming, lib/custom assemblies |
| `Metcash.AIS.APIOps` | `main` | Deep | **APIOps gen-3** full artifact structure, all API/backend/named-value names |
| `Metcash.AIS.B2B.Datafactory` | `main` | Medium | ADF factory/linkedService naming patterns |
| `Metcash.AIS.B2C.Datafactory` | `main` | Medium | ADF pipeline naming patterns (UberEats ingestion) |
| `Metcash.AIS.DevOps` | `main` | Medium | Shared pipeline templates, Bicep app settings module |
| `Metcash.AIS.B2B.Cloudinary` | `main` | Medium | Standalone Function App structure, `ISmcLogger` interface |
| `Metcash.AIS.Enabling.AzureBlobManagement` | `main` | Deep | **Program.cs** DI pattern, function trigger pattern, pipeline/appsettings |
| `Metcash.AIS.ALMNZ.SupplyChainOps` | `main` | Shallow | README only on main |
| `Metcash.AIS.Enabling.Common` | `main` | Shallow | README only on main |
| `Metcash.AIS.B2C.Wynshop` | `main` | Shallow | README only on main (code on feature branches) |

---

## Repository List — Full Inventory (Squad 20)

Total: ~48 repositories scanned from ADO project listing.

```
AIS-JMETER-SCANAPI.git
EAII-370-API-Test.git
Katalon-POC
Metcash.AIS.ADF.DevOps
Metcash.AIS.ALMNZ.Consignments
Metcash.AIS.ALMNZ.SupplyChainOps
Metcash.AIS.ALMNZ.WMS
Metcash.AIS.APIOps
Metcash.AIS.APIOpsArchive
Metcash.AIS.B2B.01.Datafactory
Metcash.AIS.B2B.Cloudinary
Metcash.AIS.B2B.CreditApplication
Metcash.AIS.B2B.Datafactory
Metcash.AIS.B2B.Datafactory.RMN
Metcash.AIS.B2B.ExtendedProductInfo
Metcash.AIS.B2B.Sorted
Metcash.AIS.B2B.SQLDB
Metcash.AIS.B2C.Datafactory
Metcash.AIS.B2C.Delivery
Metcash.AIS.B2C.Finance
Metcash.AIS.B2C.IndiPIM
Metcash.AIS.B2C.Marketing
Metcash.AIS.B2C.Pricing
Metcash.AIS.B2C.SQLDB
Metcash.AIS.B2C.Store
Metcash.AIS.B2C.Wynshop
Metcash.AIS.Common
Metcash.AIS.Corp.Giftcard
Metcash.AIS.Corp.RPA.DocMgmt
Metcash.AIS.Data.Metproducts
Metcash.AIS.DevOps
Metcash.AIS.Enabling.AzureBlobManagement
Metcash.AIS.Enabling.Common
Metcash.AIS.Enabling.Notifications
Metcash.AIS.Enabling.R2W
Metcash.AIS.RMN
Metcash.AIS.RMN.01.Datafactory
Metcash.AIS.RMN.02.Datafactory
Metcash.AIS.Shared.ClientApps
Metcash.AIS.Shared.Copilot
Metcash.AIS.Shared.Copilot.Prompts
Metcash.AIS.SQLDB
Metcash.B2B.ProductData
Metcash.Corp.Metrisk
Metcash.RetailTech.Common
Metcash.RetailTech.DigitalReceipts
Metcash.RetailTech.Loyalty
Metcash.RetailTech.ScanV2.5
PostmantoJmeter
Scan2.5
```

---

## Gaps and Repos Not Deeply Scanned

The following repos were identified but not deeply examined. These may contain additional patterns.

| Repository | Why Not Scanned | Priority |
|---|---|---|
| `Metcash.AIS.B2B.01.Datafactory` | 1.8GB — largest ADF repo | Medium |
| `Metcash.AIS.B2B.CreditApplication` | Not scanned | Medium |
| `Metcash.AIS.B2B.Sorted` | Not scanned | Medium |
| `Metcash.AIS.B2B.ExtendedProductInfo` | Not scanned | Low |
| `Metcash.AIS.B2C.Delivery` | Not scanned | Medium |
| `Metcash.AIS.B2C.Finance` | Not scanned | Low |
| `Metcash.AIS.B2C.IndiPIM` | Not scanned | Medium |
| `Metcash.AIS.B2C.Store` | Not scanned — likely Function App | High |
| `Metcash.AIS.Enabling.Notifications` | Not scanned — likely Logic App | High |
| `Metcash.AIS.Enabling.R2W` | Not scanned | Medium |
| `Metcash.AIS.RMN.01.Datafactory` | Not scanned | Medium |
| `Metcash.AIS.RMN.02.Datafactory` | Not scanned | Medium |
| `Metcash.AIS.Shared.Copilot` | Not scanned | Low |
| `Metcash.AIS.Shared.Copilot.Prompts` | Not scanned | Low |
| `Metcash.RetailTech.Loyalty` | Not scanned | Low |
| `Metcash.RetailTech.ScanV2.5` | Not scanned | Low |
| `Metcash.AIS.ADF.DevOps` | Not scanned | Medium (shared ADF templates) |
| `Metcash.AIS.Common` | Not scanned | Medium (shared types?) |

---

## Key Patterns Discovered

### Confirmed
1. **Two Logic App Standard workspace patterns** — per-env files (Metproducts) vs single files (RMN)
2. **EAII ID in workflow folder names** (RMN pattern): `EAII-{number}-{kebab-description}/`
3. **Two Function App patterns** — standalone two-project vs co-located in Logic App workspace
4. **Program.cs DI pattern** — .NET 8 Isolated + Key Vault + SMC Logger + App Insights
5. **All Azure connections via Managed Identity** — no SAS keys or connection strings (with one exception: older B2B ADF linked service)
6. **APIOps gen-3 structure** — full artifact hierarchy discovered
7. **Service Bus naming** — `{domain}.{service}.{env}.sbt` and `.sbq`
8. **SMC queue environment mapping** — sit/uat/ppd all map to `uat` in SMC queue name
9. **Shared pipeline templates** in `Metcash.AIS.DevOps`
10. **SonarQube** used in all CI/PR pipelines

### Inconsistencies
1. **Logic App workspace naming** — Some use full descriptive name, some use Azure resource name
2. **Workflow naming** — Some use PascalCase functional name (Metproducts), others use EAII-ID kebab (RMN)
3. **ADF B2B linked service** — Has `encryptedCredential` (older pattern); new should use Managed Identity
4. **APIM region suffix** — Uses `ae1` not `ae` (inconsistent with other resource naming)
5. **Per-env vs single connections.json** — Two patterns exist, no single enforced standard yet

---

## Skill Files Created (This Session)

| File | Status |
|---|---|
| `skills/squad20-engineering-overview.md` | Created |
| `skills/squad20-naming-conventions.md` | Created |
| `skills/logic-app-skill.md` | Created |
| `skills/azure-function-skill.md` | Created |
| `skills/azure-data-factory-skill.md` | Created |
| `skills/azure-service-bus-skill.md` | Created |
| `skills/api-management-apiops-skill.md` | Created |
| `skills/azure-devops-work-items-skill.md` | Created (since moved to `.github/skills/azure-devops-work-items/SKILL.md`) |
| `skills/azure-devops-repository-pr-skill.md` | Created (since moved to `.github/skills/azure-devops-repository-pr/SKILL.md`) |
| `skills/squad20-platform-domain-patterns.md` | Created |
| `skills/squad20-scan-summary.md` | This file |

---

## Recommended Next Steps

1. **Scan `Metcash.AIS.B2C.Store`** — likely has a well-formed Function App with APIM integration (multiple named values observed for it in APIOps)
2. **Scan `Metcash.AIS.Enabling.Notifications`** — has known APIM API and Logic App backend, high-priority pattern
3. **Scan `Metcash.AIS.ADF.DevOps`** — may contain shared ADF templates equivalent to `Metcash.AIS.DevOps` for Logic Apps
4. **Validate ADF Managed Identity pattern** — confirm newer ADF repos use MI not connection strings
5. **Update skill files** as new repos are scanned and inconsistencies are resolved
6. **Register all new skills** in `.github/copilot-instructions.md` and `AGENTS.md` for auto-loading
