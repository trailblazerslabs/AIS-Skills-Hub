# Squad 20 Naming Conventions

> Status: Observed — derived from scanning Squad 20 repositories (METCASHDevOps/Squad 20).
> Where inferred, entries are labelled **[Inferred]**. Where recommended due to inconsistency, entries are labelled **[Recommended]**.

---

## Azure Resource Naming Pattern

### Base Pattern
```
t3-met-{domain}-{env}-{region}-{service}-{instance}
```

| Token | Values | Notes |
|---|---|---|
| `t3` | `t3` | Fixed Metcash tenant generation prefix |
| `met` | `met` | Fixed Metcash organisation |
| `{domain}` | `ais`, `b2b`, `b2c`, `rmn`, `core`, `enabling`, etc. | Lowercase |
| `{env}` | `dev`, `sit`, `uat`, `ppd`, `prd` | Environment token (omitted in some resource names) |
| `{region}` | `ae` (australiaeast), `ase` (australiasoutheast) | Region abbreviation |
| `{service}` | `logic`, `func`, `adf`, `apim`, `kv`, `sta`, `sb` | Azure service abbreviation |
| `{instance}` | `01`, `02`, `b2b-01` | Instance number, sometimes includes platform |

### Observed Examples

| Resource | Name | Repo/Source |
|---|---|---|
| Logic App Standard | `t3-met-rmn-ae-logic` | `Metcash.AIS.RMN` |
| Function App | `t3-met-rmn-ae-func` | `Metcash.AIS.RMN` |
| ADF (B2B) | `t3-met-ais-dev-ae-adf-b2b-01` | `Metcash.AIS.B2B.Datafactory` |
| ADF (main) | `t3-met-ais-dev-ae-adf-01` | `Metcash.AIS.B2B.Datafactory` |
| APIM | `t3-met-core-dev-ae1-apim` | `Metcash.AIS.APIOps` / `connections.dev.json` |
| Key Vault | `coresys-dev-ae-kv01` | `Metcash.AIS.DevOps/deploy/main.bicep` |
| Storage Account | `coresys{env}{region}sta01` | `Metcash.AIS.DevOps/deploy/main.bicep` [Inferred suffix] |
| Service Bus Namespace | `met-nonprod-ae-sb01` / `met-prod-ae-sb01` | `Metcash.AIS.DevOps/deploy/main.bicep` |
| Function (Shared Services) | `t3-met-sharedservicescommon-dev-ae-func` | `connections.dev.json` |

**Note on APIM:** Uses `ae1` not `ae` for region token. Pattern: `t3-met-core-{env}-ae1-apim`.

---

## Resource Group Naming

```
t3-met-{domain}-{env}-ae1-rsg-{service}
```

### Observed Examples

| Resource Group | Source |
|---|---|
| `t3-met-core-dev-ae1-rsg-apim` | `connections.dev.json` (APIM subscription ID ref) |
| `t3-met-ais-dev-ae1-rsg-enabling` | `connections.dev.json` (function resource group ref) |

---

## Logic App Workflow Folder Naming

Two patterns observed:

| Pattern | Example | Source |
|---|---|---|
| PascalCase functional description | `PIMToPEProductChanges/` | `Metcash.AIS.Data.Metproducts` |
| EAII ID + kebab-case description | `EAII-432-consentsubscriber-braze-tt/` | `Metcash.AIS.RMN` |

**[Recommended]** Prefer `EAII-{number}-{kebab-description}` for new workflows (clearly traces to work item).

---

## Logic App Workspace (Repo) Naming

Two patterns observed:

| Pattern | Example | Source |
|---|---|---|
| Full kebab-case descriptive name | `Metcash-AIS-Data-Metproducts-Workspace/` | `Metcash.AIS.Data.Metproducts` |
| Azure resource name | `t3-met-rmn-ae-logic/` | `Metcash.AIS.RMN` |

---

## Service Bus Naming

| Resource | Pattern | Example | Source |
|---|---|---|---|
| Namespace (non-prod) | `met-nonprod-{region}-sb01` | `met-nonprod-ae-sb01` | `main.bicep` |
| Namespace (prod) | `met-prod-{region}-sb01` | `met-prod-ae-sb01` | `main.bicep` |
| Topic | `{domain}.{service}.{env}.sbt` | `data.metproducts.dev.sbt` | `parameters.dev.json` |
| Queue | `{domain}.{service}.{env}.sbq` | `smc.endobservation.dev.sbq` | `main.bicep` |
| Subscription | PascalCase | `PEChanges` | `parameters.dev.json` |

### SMC Queue Name Mapping

| Environment | SMC queue `{env}` token |
|---|---|
| dev | `dev` |
| sit | `uat` |
| uat | `uat` |
| ppd | `uat` |
| prd | `prd` |

---

## Azure Data Factory Naming

### Pipelines
```
pl_{domain}_{action}_{source}_{target}_{loadtype}
```
**Example:** `pl_ubereats_ingest_inventory_sql_adls_delta_child`

| Token | Examples |
|---|---|
| `{domain}` | `ubereats`, `b2b`, `sku`, `sm` |
| `{action}` | `ingest`, `load`, `transform` |
| `{source}` | `sql`, `blob`, `adls` |
| `{target}` | `adls`, `sql`, `blob` |
| `{loadtype}` | `fullload`, `delta`, `parent`, `child` |

### Linked Services
```
ls_{domain}_{service_type}_{instance}_{ir_type}
```
**Examples:** `ls_sku_adls_st01_air`, `ls_sm_adls_st01_shir`

| Token | Values |
|---|---|
| `{ir_type}` | `air` (Azure Integration Runtime), `shir` (Self-Hosted IR) |

### Datasets
**[Inferred]** Follow same lowercase underscore pattern as pipelines and linked services.

---

## API Management (APIOps gen-3)

### API Internal Name
```
{platform}-{service-description}-v{version}
```
**Examples:** `b2b-cloudinary-v1`, `b2c-marketplace-api-v6`, `enabling-notifications-v1`, `smc-v1`

### API Display Name
```
{Platform}-{Service}
```
**Examples:** `B2B-Cloudinary`, `Enabling-Notifications`

### API Path in APIM
```
{domain_abbr}/{service}
```
**Example:** `eis/cloudinary`

### Version Set
```
{platform}-{service}
```
**Example:** `b2b-cloudinary`

### Backend Names
| Pattern | Example |
|---|---|
| Function App backends | `{service}-func`, `{service}-function-app` |
| Logic App backends | `t3-met-{domain}-{region}-logic-backend` (e.g., `t3-met-b2c-wynshop-ae-logic-backend`) |
| Named external backends | `{HybrisALM...BaseUrl}`, `equifax-backend` |

### Named Values
| Pattern | Purpose |
|---|---|
| `{service}-interfaceid` | SMC interface ID reference |
| `{service}-func-key` | Function App authentication key |
| `{workflow}-wf-sig` | Logic App workflow signature |
| `{service}-{type}url` | Endpoint URI overrides |

---

## Function App C# Namespaces

```
Metcash.AIS.{Domain}.{Service}
```
**Examples:** `Metcash.AIS.Enabling.AzureBlobManagement`, `Metcash.AIS.B2B.Cloudinary`

---

## Azure DevOps Variables and Service Connections

| Asset | Pattern | Example |
|---|---|---|
| Variable Group | `t3-ais_{interface}_{env}` | `t3-ais_pim2pe_dev` |
| Service Connection (SPN) | `SPN-t3-met-ais-{env}` | `SPN-t3-met-ais-dev` |
| Agent Pool (non-prod) | `Metcash-ALZ-VMSS-Windows-NON-PROD` | — |
| Build name | `$(Build.DefinitionName)_$(Build.SourceBranchName)_RunID$(Build.BuildId)_Date$(Year:yyyy).$(Month).$(DayOfMonth)$(Rev:.rr)` | — |

---

## Logic App Standard App Settings Keys

Standard app settings provisioned via `main.bicep` for all Logic App deployments:

| Key | Value Pattern |
|---|---|
| `WORKFLOWS_SUBSCRIPTION_ID` | Azure subscription GUID |
| `WORKFLOWS_LOCATION_NAME` | `australiaeast` |
| `WORKFLOWS_RESOURCE_GROUP` | `t3-met-{domain}-{env}-ae1-rsg-{service}` |
| `WORKFLOWS_ENVIRONMENT` | `{env}` |
| `SMC_QueueName` | `smc.endobservation.{smc-env}.sbq` |
| `ServiceBus_FullyQualifiedNamespace` | `met-{nonprod\|prod}-ae-sb01.servicebus.windows.net` |

### Connection-specific App Settings (from `connections.dev.json`)

| Key | Value |
|---|---|
| `SMC_SubscriptionKey` | Via Key Vault |
| `gen2_serviceBus_fullyQualifiedNamespace` | `@appsetting('...')` |
| `shared_serviceBus_fullyQualifiedNamespace` | `@appsetting('...')` |
| `AzureBlob_blobStorageEndpoint` | `@appsetting('...')` |
| `azureFunctionOperation_functionAppKey` | `@appsetting('...')` |
