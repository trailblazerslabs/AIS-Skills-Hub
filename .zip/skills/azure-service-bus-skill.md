# Azure Service Bus Skill — Squad 20

> Status: Observed — derived from `Metcash.AIS.Data.Metproducts` (parameters, connections), `Metcash.AIS.DevOps` (main.bicep), and Logic App workspace files.

---

## Service Bus Namespaces

| Environment Group | Namespace FQDN |
|---|---|
| Non-Production (dev, sit, uat, ppd) | `met-nonprod-ae-sb01.servicebus.windows.net` |
| Production (prd) | `met-prod-ae-sb01.servicebus.windows.net` |

**Observed Source:** `Metcash.AIS.DevOps/deploy/main.bicep`

---

## Topic Naming Convention

```
{domain}.{service}.{env}.sbt
```

| Token | Description | Example |
|---|---|---|
| `{domain}` | Platform domain (lowercase) | `data` |
| `{service}` | Service/product (lowercase) | `metproducts` |
| `{env}` | Environment | `dev`, `sit`, `uat`, `prd` |
| `.sbt` | Service Bus Topic suffix | fixed |

**Example:** `data.metproducts.dev.sbt`

**Observed Source:** `Metcash-AIS-Data-Metproducts-Workspace/LogicApp/Parameters/parameters.dev.json`

---

## Queue Naming Convention

```
{domain}.{service}.{env}.sbq
```

| Token | Description | Example |
|---|---|---|
| `{domain}` | Platform domain (lowercase) | `smc` |
| `{service}` | Service name | `endobservation` |
| `{env}` | SMC-mapped environment (see table below) | `dev`, `uat`, `prd` |
| `.sbq` | Service Bus Queue suffix | fixed |

**Example:** `smc.endobservation.dev.sbq`

**Observed Source:** `Metcash.AIS.DevOps/deploy/main.bicep`

---

## SMC Queue — Environment Mapping

The SMC observation queue uses a mapped environment token (not the deploy environment directly):

| Deploy Environment | SMC Queue `{env}` token |
|---|---|
| `dev` | `dev` |
| `sit` | `uat` |
| `uat` | `uat` |
| `ppd` | `uat` |
| `prd` | `prd` |

---

## Subscription Naming

Subscriptions are PascalCase descriptive names:

**Example:** `PEChanges` (for PIM to PE product changes topic subscription)

**Observed Source:** `parameters.dev.json` (`topicSubscription: "PEChanges"`)

---

## Logic App — Service Bus Connection

Connections always use **Managed Identity** (never SAS keys or connection strings):

```json
"serviceProviderConnections": {
  "serviceBus": {
    "displayName": "servicebus-shared-conn",
    "parameterSetName": "ManagedServiceIdentity",
    "parameterValues": {
      "authProvider": { "Type": "ManagedServiceIdentity" },
      "fullyQualifiedNamespace": "@appsetting('shared_serviceBus_fullyQualifiedNamespace')"
    },
    "serviceProvider": { "id": "/serviceProviders/serviceBus" }
  }
}
```

Multiple Service Bus connections observed:
- `serviceBus` → `shared_serviceBus_fullyQualifiedNamespace` (gen-3 namespace)
- `serviceBus1` → `gen2_serviceBus_fullyQualifiedNamespace` (gen-2 namespace, legacy)

**Observed Source:** `connections.dev.json` (`Metcash.AIS.Data.Metproducts`)

---

## App Settings Keys

| Key | Value |
|---|---|
| `ServiceBus_FullyQualifiedNamespace` | `met-{nonprod\|prod}-ae-sb01.servicebus.windows.net` |
| `shared_serviceBus_fullyQualifiedNamespace` | `met-{nonprod\|prod}-ae-sb01.servicebus.windows.net` |
| `gen2_serviceBus_fullyQualifiedNamespace` | Legacy gen-2 namespace |
| `SMC_QueueName` | `smc.endobservation.{smc-env}.sbq` |

---

## Common Service Bus Trigger Pattern (Logic App)

Workflow trigger for Service Bus topic subscription:

```json
{
  "definition": {
    "triggers": {
      "When_messages_are_available_in_a_topic_subscription_(peek-lock)": {
        "type": "ServiceProvider",
        "inputs": {
          "parameters": {
            "topicName": "@parameters('param{InterfaceName}').sbTopic",
            "subscriptionName": "@parameters('param{InterfaceName}').topicSubscription",
            "isSessionsEnabled": false
          },
          "serviceProviderConfiguration": {
            "connectionName": "serviceBus",
            "operationId": "receiveTopicMessages",
            "serviceProviderId": "/serviceProviders/serviceBus"
          }
        },
        "splitOn": "@triggerOutputs()?['body']"
      }
    }
  }
}
```

---

## Service Bus Integration Patterns (Observed)

| Pattern | Description | Used In |
|---|---|---|
| Publish to topic | Logic App produces events to a topic for downstream consumption | `Metcash.AIS.Data.Metproducts` |
| Subscribe to topic | Logic App subscribes to a topic subscription (peek-lock) | `Metcash.AIS.RMN` consent subscribers |
| SMC observation queue | Every interface sends start/end events to SMC queue | All integrations |
| Dead letter handling | **[Recommended]** — not yet confirmed with evidence |

---

## Key Rules

1. Always use Managed Identity (`ManagedServiceIdentity`) for Service Bus connections — never SAS keys.
2. Topic names must follow `{domain}.{service}.{env}.sbt` pattern.
3. Queue names must follow `{domain}.{service}.{env}.sbq` pattern.
4. Use peek-lock for Logic App topic triggers (provides at-least-once delivery).
5. SMC queue must be provisioned for every environment using the SMC env mapping table.
6. Store the FQDN namespace in app settings — never hardcode.
7. Use `@parameters(...)` to reference topic/subscription names in workflows — never hardcode.

---

## Observed Evidence

| Repository | File Path | Pattern Observed |
|---|---|---|
| `Metcash.AIS.Data.Metproducts` | `/LogicApp/Connections/connections.dev.json` | Managed Identity SB connection |
| `Metcash.AIS.Data.Metproducts` | `/LogicApp/Parameters/parameters.dev.json` | `sbTopic: "data.metproducts.dev.sbt"`, subscription name |
| `Metcash.AIS.DevOps` | `/deploy/main.bicep` | Namespace FQDN per env, SMC queue naming |
| `Metcash.AIS.RMN` | `/logic-app/.../EAII-432-consentsubscriber-braze-tt/workflow.json` | SB-triggered workflow |
