# API Management and APIOps Skill — Squad 20

> Status: Observed — derived from `Metcash.AIS.APIOps` (gen-3 folder, branch: main).

---

## APIM Generation

Squad 20 uses **APIOps gen-3** (Azure APIOps Toolkit v2). The gen-2 structure exists in the `gen-2/` folder but is superseded.

---

## Repository Structure (APIOps gen-3)

```
gen-3/
├── artifacts/
│   ├── apis/
│   │   └── {api-name}/
│   │       ├── apiInformation.json
│   │       ├── specification.yaml      ← OpenAPI spec
│   │       ├── policy.xml              ← API-level policy
│   │       └── operations/
│   │           └── {operation-name}/
│   │               └── policy.xml      ← Operation-level policy
│   ├── backends/
│   │   └── {backend-name}/
│   │       └── backendInformation.json
│   ├── named values/
│   │   └── {named-value-name}/
│   │       └── namedValueInformation.json
│   ├── policy fragments/
│   │   └── {fragment-name}/
│   │       └── policyFragmentInformation.json
│   ├── products/
│   │   └── {product-name}/
│   │       └── productInformation.json
│   ├── subscriptions/
│   ├── tags/
│   │   └── {tag-name}/
│   └── version sets/
│       └── {versionset-name}/
│           └── versionSetInformation.json
└── tools/
    ├── configuration.extractor.yaml    ← APIOps extractor config
    ├── parameters/
    │   ├── parameters.dev.yaml
    │   ├── parameters.sit.yaml
    │   ├── parameters.uat.yaml
    │   ├── parameters.ppd.yaml
    │   └── parameters.prd.yaml
    └── pipelines/                      ← APIOps ADO pipeline definitions
```

---

## API Naming Conventions

### API Internal Name (ID)
```
{platform}-{service-description}-v{version}
```

All lowercase, kebab-case.

### Observed API Names

| Internal Name | Display Name | APIM Path | Platform |
|---|---|---|---|
| `b2b-almconnect-to-almretailer-v1` | — | — | B2B |
| `b2b-cloudinary-v1` | `B2B-Cloudinary` | `eis/cloudinary` | B2B |
| `b2b-creditapplication-v1` | — | — | B2B |
| `b2b-almkeyretail` | — | — | B2B |
| `b2b-externalsupplier-to-sorted-v1` | — | — | B2B |
| `b2c-marketplace-api-v6` | — | — | B2C |
| `b2c-marketplace-api-v7` | — | — | B2C |
| `enabling-azure-blob-management-v1` | — | — | Enabling |
| `enabling-notifications-v1` | — | — | Enabling |
| `corporate-mumbatochris21-v1` | — | — | Corporate |
| `fin-giftcardactivation-rpa-v1` | — | — | Finance |
| `finance-giftcardservices-v1` | — | — | Finance |
| `iba-loyalty-app` | — | — | IBA |
| `rpa-uipathwebapi-v1` | — | — | RPA |
| `smc-v1` | — | `monitoring/smc/v1` | SMC/Platform |
| `b2c-orderstatus-to-fauxpos-v1` | — | — | B2C |
| `b2c-products-to-fauxpos-v1` | — | — | B2C |

### API Display Name
```
{Platform}-{Service}
```
PascalCase with hyphen separator. Example: `B2B-Cloudinary`, `Enabling-Notifications`.

### API Path in APIM
```
{domain_abbr}/{service}
```
Example: `eis/cloudinary`, `monitoring/smc/v1`

### Version Set ID
```
{platform}-{service}
```
Example: `b2b-cloudinary`

---

## APIM Service Naming

```
t3-met-core-{env}-ae1-apim
```

Note: Uses `ae1` (not `ae`) for region in APIM resource names.

| Environment | APIM Service Name |
|---|---|
| dev | `t3-met-core-dev-ae1-apim` |
| sit | `t3-met-core-sit-ae1-apim` |
| uat | `t3-met-core-uat-ae1-apim` |
| ppd | `t3-met-core-ppd-ae1-apim` |
| prd | `t3-met-core-prd-ae1-apim` |

Resource group: `t3-met-core-{env}-ae1-rsg-apim`

---

## Backend Naming

| Pattern | Example | Description |
|---|---|---|
| Function App backend | `{service}-func` | `b2c-store-func` |
| Function App backend (long) | `{service}-function-app` | `enabling-azure-blob-management-function-app` |
| Logic App backend | `t3-met-{domain}-{region}-logic-backend` | `t3-met-b2c-wynshop-ae-logic-backend` |
| External/named URL | `{descriptive-name}-backend` | `equifax-backend`, `HybrisALMRetailerBaseUrl` |

---

## Named Value Naming

| Pattern | Example | Purpose |
|---|---|---|
| `{service}-interfaceid` | `b2c-store-inventory-bulk-delete-interfaceid` | SMC interface ID |
| `{service}-func-key` | `b2c-store-func-key` | Function App auth key |
| `{workflow}-wf-sig` | `b2c-processordereventsalm-wf-sig` | Logic App workflow signature |
| `{service}-{type}uri` | `generic-email-endpointuri` | Endpoint URI |
| `{platform}-{service}-{attr}` | `HybrisALMRetailerB2bUnitsEndpointuri` | Hybris endpoint URLs |
| `smc` | `smc` | SMC subscription key |

---

## Policy Fragments (Observed)

| Fragment Name | Purpose |
|---|---|
| `set-common-inbound-variables` | Sets correlation IDs and context variables |
| `inbound-headers-validator` | Validates required HTTP headers |
| `on-error-handler` | Standard error response handling |
| `{service}-backend-retry-handler` | Service-specific retry logic |
| `{service}-response-handler` | Service-specific response transformation |
| `{service}-in-bound-request-validator` | Service-specific request validation |

---

## Tags

| Tag | APIs |
|---|---|
| `AIS` | All AIS-platform APIs |
| `Enabling` | Enabling platform APIs |
| `Notifications` | Notification-related APIs |

---

## Products

| Product | Purpose |
|---|---|
| `AIS` | Main AIS product subscription |

---

## Parameters Files (APIOps per-environment)

```yaml
# parameters.dev.yaml
apimServiceName: t3-met-core-dev-ae1-apim
namedValues:
loggers:
diagnostics:
backends:
apis:
subscriptions:
```

Minimal structure — only `apimServiceName` is set per environment. Environment-specific overrides are defined per-section.

---

## API Information File (apiInformation.json)

Example structure from `b2b-cloudinary-v1`:

```json
{
  "properties": {
    "description": "{API description}",
    "subscriptionRequired": true,
    "path": "{domain_abbr}/{service}",
    "protocols": ["https"],
    "isCurrent": true,
    "apiVersion": "v1",
    "apiVersionSetId": "/subscriptions/.../apis/{platform}-{service}",
    "displayName": "{Platform}-{Service}"
  }
}
```

---

## Adding a New API — Checklist

1. Create folder at `gen-3/artifacts/apis/{platform}-{service}-v{version}/`
2. Add `apiInformation.json` (path, protocols, version, display name)
3. Add `specification.yaml` (OpenAPI 3.0 spec)
4. Add `policy.xml` (at minimum include `set-common-inbound-variables`, `inbound-headers-validator`, `on-error-handler` fragments)
5. Add `operations/` subfolder with per-operation `policy.xml` if needed
6. Add backend in `gen-3/artifacts/backends/{backend-name}/backendInformation.json`
7. Add named values for interface ID and any auth keys
8. Add version set in `gen-3/artifacts/version sets/`
9. Add tag assignment (typically `AIS`)
10. Add product association (`AIS`)
11. Run APIOps publisher pipeline to push to target APIM environment

---

## Key Rules

1. All API names must be lowercase kebab-case: `{platform}-{service}-v{version}`.
2. All new APIs must include `set-common-inbound-variables`, `inbound-headers-validator`, and `on-error-handler` policy fragments.
3. APIM resource name uses `ae1` region suffix (not `ae`).
4. Use APIOps Toolkit v2 flows — do not manually push policies via portal without committing to the APIOps repo.
5. Per-environment overrides go in `tools/parameters/parameters.{env}.yaml`.
6. Named values for interface IDs follow `{service}-interfaceid` pattern.

---

## Observed Evidence

| Repository | File Path | Pattern Observed |
|---|---|---|
| `Metcash.AIS.APIOps` | `/gen-3/artifacts/apis/b2b-cloudinary-v1/apiInformation.json` | API naming, path, APIM service names |
| `Metcash.AIS.APIOps` | `/gen-3/tools/configuration.extractor.yaml` | Full list of API/backend/named-value names |
| `Metcash.AIS.APIOps` | `/gen-3/tools/parameters/parameters.dev.yaml` | Per-env parameter structure |
| `Metcash.AIS.Data.Metproducts` | `/LogicApp/Connections/connections.dev.json` | SMC APIM connection (`t3-met-core-dev-ae1-apim`) |
