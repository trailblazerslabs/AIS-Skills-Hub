# Azure Function App Skill — Squad 20

> Status: Observed — derived from `Metcash.AIS.Enabling.AzureBlobManagement`, `Metcash.AIS.B2B.Cloudinary`, `Metcash.AIS.RMN`, and `Metcash.AIS.Data.Metproducts`.

---

## Two Function App Patterns

### Pattern A — Standalone Function App (Two-project structure)

Used for dedicated function services (not inside a Logic App workspace).

```
{RepoRoot}/
├── FunctionApp/
│   ├── {Namespace}.Common/          ← Shared library project
│   │   ├── AppSetting.cs
│   │   ├── CommonHelper.cs
│   │   ├── Constants.cs
│   │   ├── LogMessageHelper.cs
│   │   ├── MessageHeaderHelper.cs
│   │   ├── keyVaultHelper.cs
│   │   ├── Data/
│   │   │   └── AppDbContext.cs
│   │   ├── Interfaces/
│   │   │   ├── ISmcLogger.cs
│   │   │   └── I{Service}Service.cs
│   │   └── Model/
│   │       └── {Dto}.cs
│   └── {Namespace}/                 ← Main function project
│       ├── {FunctionName}.cs        ← One file per function trigger
│       ├── FunctionExecutor.cs      ← (Optional) dispatcher
│       ├── Program.cs               ← DI host setup
│       ├── host.json
│       └── {Namespace}.csproj
├── pipelines/
│   ├── {Name}.yml
│   └── appsettings/
│       ├── dev.local.settings.json
│       ├── sit.local.settings.json
│       ├── uat.local.settings.json
│       └── prod.local.settings.json
└── NuGet.config
```

**Evidence:** `Metcash.AIS.Enabling.AzureBlobManagement`, `Metcash.AIS.B2B.Cloudinary`

---

### Pattern B — Local Function inside Logic App Workspace

Used when transformation logic is co-located with a Logic App workflow.

```
{WorkspaceName}/
└── Function/
    ├── {Namespace}.csproj
    ├── {FunctionName}.cs
    ├── Helpers/
    ├── Model/
    └── tests/
```

**Evidence:** `Metcash.AIS.Data.Metproducts`, `Metcash.AIS.RMN`

---

## Program.cs — .NET 8 Isolated Worker (Observed Pattern)

```csharp
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Azure.Identity;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Metcash.AIS.Enabling.AzureBlobManagement.Common;
using Metcash.AIS.Enabling.AzureBlobManagement.Common.Interfaces;

var builder = FunctionsApplication.CreateBuilder(args);

builder.ConfigureFunctionsWebApplication();

// Application Insights telemetry
builder.Services
    .AddApplicationInsightsTelemetryWorkerService()
    .ConfigureFunctionsApplicationInsights();

// Key Vault integration via Managed Identity
builder.Configuration.AddAzureKeyVault(
    new Uri(AppSetting.KeyVaultUrl),
    new DefaultAzureCredential(),
    new KeyVaultSecretManager()  // or AzureKeyVaultConfigurationOptions with ReloadInterval
);

// SMC observability (required)
var logger = builder.Services.BuildServiceProvider().GetService<ILogger<SmcLoggerService>>();
builder.Services.AddScoped<ISmcLogger>(s => new SmcLoggerService(logger));

// Domain-specific services (Transient preferred)
builder.Services.AddTransient<IBlobStorageService, BlobStorageService>();

builder.Build().Run();
```

**Evidence:** `Metcash.AIS.Enabling.AzureBlobManagement/FunctionApp/.../Program.cs`

---

## SMC Logger Interface

```csharp
public interface ISmcLogger
{
    string EnableObservation { get; set; }
    Task StartObservationLogAsync(ReqStartObservation request);
}
```

Implementation class: `SmcLoggerService`

**Evidence:** `Metcash.AIS.B2B.Cloudinary/FunctionApp/.../Interfaces/ISmcLogger.cs`

---

## AppSetting.cs Pattern

Central static class that reads from configuration (Key Vault + app settings):

```csharp
public static class AppSetting
{
    public static string KeyVaultUrl => Environment.GetEnvironmentVariable("KeyVaultUrl");
    public static string ServiceBusConnectionString => Environment.GetEnvironmentVariable("ServiceBus_FullyQualifiedNamespace");
    // ... other settings
}
```

---

## Constants.cs Pattern

All magic strings in a static class:

```csharp
public static class Constants
{
    public static class Settings
    {
        public const string InterfaceId = "EAII-{number}";
        public const string ServiceName = "{service-name}";
    }
    public static class Headers
    {
        public const string InterfaceId = "X-Interface-Id";
        public const string CorrelationId = "X-Correlation-Id";
    }
}
```

---

## Individual Function File Pattern

Standalone functions use one file per HTTP trigger or Service Bus trigger:

```csharp
[Function("UploadBlob")]
public async Task<HttpResponseData> UploadBlob(
    [HttpTrigger(AuthorizationLevel.Function, "post", Route = "blobs/upload")] HttpRequestData req,
    FunctionContext context)
{
    // 1. Start SMC observation
    await _smcLogger.StartObservationLogAsync(new ReqStartObservation { ... });

    // 2. Execute business logic
    var result = await _blobService.UploadAsync(...);

    // 3. Return response
    var response = req.CreateResponse(HttpStatusCode.OK);
    return response;
}
```

**Evidence:** `Metcash.AIS.Enabling.AzureBlobManagement/FunctionApp/.../UploadBlob.cs`

---

## Pipeline for Standalone Function App

```yaml
# {Domain}.FunctionApp.Pipelines.yml
trigger:
  - main

variables:
  - group: t3-ais_{interface}_dev
  - name: buildConfiguration
    value: Release

pool:
  name: Metcash-ALZ-VMSS-Windows-NON-PROD

stages:
  - template: pipelines/templates/functionapp_build_template.yml@Metcash.AIS.DevOps
  - stage: DeployDEV
    ...
```

App settings are merged via separate scripts:
- `pipelines/merge-app-settings.yml`
- `pipelines/merge-app-settings-dev.yml`
- `pipelines/merge-app-settings-uatprd.yml`

**Evidence:** `Metcash.AIS.Enabling.AzureBlobManagement/pipelines/gen3enableblobmgmtfnapp.yml`

---

## host.json (Standard)

```json
{
  "version": "2.0",
  "logging": {
    "applicationInsights": {
      "samplingSettings": {
        "isEnabled": true,
        "excludedTypes": "Request"
      },
      "enableLiveDashboardFilters": true
    }
  }
}
```

---

## NuGet.config

Private feed from Metcash ADO artifacts. Always present at repo root for Function App projects.

---

## Key Rules

1. Always use `.NET 8 Isolated Worker` model (`FunctionsApplication.CreateBuilder`).
2. Always use `DefaultAzureCredential` for Key Vault and Azure service connections — never connection strings with keys.
3. Always inject `ISmcLogger` via DI and call `StartObservationLogAsync` in every function.
4. Common/shared project receives all interfaces, models, and helper classes.
5. Main function project contains only trigger handlers and `Program.cs`.
6. One function trigger = one `.cs` file.
7. All app settings accessed via `AppSetting` static class or `IConfiguration`.
8. Namespace: `Metcash.AIS.{Domain}.{Service}` (e.g., `Metcash.AIS.Enabling.AzureBlobManagement`).

---

## Observed Evidence

| Repository | File Path | Pattern Observed |
|---|---|---|
| `Metcash.AIS.Enabling.AzureBlobManagement` | `/FunctionApp/.../Program.cs` | Full .NET 8 DI host setup with Key Vault, SMC, App Insights |
| `Metcash.AIS.Enabling.AzureBlobManagement` | `/FunctionApp/.../UploadBlob.cs` | Individual function trigger per file |
| `Metcash.AIS.B2B.Cloudinary` | `/FunctionApp/.../Interfaces/ISmcLogger.cs` | SMC Logger interface |
| `Metcash.AIS.B2B.Cloudinary` | `/FunctionApp/.../Common/` | Shared library project layout |
| `Metcash.AIS.RMN` | `/function-app/t3-met-rmn-ae-func/` | Function inside Logic App workspace repo |
| `Metcash.AIS.Data.Metproducts` | `/Metcash-AIS-Data-Metproducts-Workspace/Function/` | Local function co-located in Logic App workspace |
