# Logic App Standard Skill — Squad 20

> Status: Observed — derived from `Metcash.AIS.Data.Metproducts` (branch: `release_200617`) and `Metcash.AIS.RMN` (branch: `main`).

---

## Two Workspace Layout Patterns

### Pattern A — Multi-environment files (Metproducts style)

Used when a Logic App workspace has per-environment connections and parameters.

```
{WorkspaceName}/
├── LogicApp/
│   ├── AppSettings/
│   │   ├── appsettings.dev.json
│   │   ├── appsettings.sit.json
│   │   ├── appsettings.uat.json
│   │   └── appsettings.prd.json
│   ├── Connections/
│   │   ├── connections.dev.json
│   │   ├── connections.sit.json
│   │   ├── connections.uat.json
│   │   └── connections.prd.json
│   ├── Parameters/
│   │   ├── parameters.dev.json
│   │   ├── parameters.sit.json
│   │   ├── parameters.uat.json
│   │   └── parameters.prd.json
│   ├── {WorkflowName}/
│   │   └── workflow.json
│   ├── host.json
│   ├── .funcignore
│   └── .gitignore
├── Function/
│   ├── {ProjectName}.csproj
│   ├── {FunctionName}.cs
│   ├── Helpers/
│   ├── Model/
│   └── tests/
├── pipelines/
│   ├── {interface}.yml
│   └── templates/
│       ├── logicapp-prepare-package.yml
│       └── update-app-settings.yml
└── {Workspace}.code-workspace
```

**Evidence:** `Metcash.AIS.Data.Metproducts`, branch `release_200617`.

---

### Pattern B — Single connection/parameter files (RMN style)

Used when all environments share a single connections and parameters file (values injected via app settings).

```
{repoRoot}/
├── logic-app/
│   └── t3-met-{domain}-ae-logic/
│       └── t3-met-{domain}-ae-logic/   ← inner folder matches resource name
│           ├── {EAII-ID-kebab-name}/
│           │   └── workflow.json
│           ├── connections.json
│           ├── parameters.json
│           ├── host.json
│           └── lib/
│               └── custom/
│                   └── {LibName}/      ← inline .NET assemblies
├── function-app/
│   └── t3-met-{domain}-ae-func/
│       ├── {Project}.sln
│       └── {FunctionName}.cs
├── pipelines/
│   ├── {Domain}.LogicApp.Pipelines.yml
│   ├── {Domain}.FunctionApp.Pipelines.yml
│   └── update-la-appsettings.yml
└── NuGet.config
```

**Evidence:** `Metcash.AIS.RMN`, branch `main`.

---

## Workflow Naming

| Pattern | Example | Source |
|---|---|---|
| PascalCase functional name | `PIMToPEProductChanges` | `Metcash.AIS.Data.Metproducts` |
| EAII ID + kebab description | `EAII-432-consentsubscriber-braze-tt` | `Metcash.AIS.RMN` |

**[Recommended]** Use `EAII-{number}-{kebab-description}` for new workflows to trace directly to ADO work items.

---

## connections.json Structure

Authentication is always **Managed Identity** (`ManagedServiceIdentity`) for Azure service connections.

```json
{
  "apiManagementConnections": {
    "apiManagementOperation": {
      "apiId": "/subscriptions/{sub}/resourceGroups/t3-met-core-{env}-ae1-rsg-apim/providers/Microsoft.ApiManagement/service/t3-met-core-{env}-ae1-apim/apis/smc-v1",
      "baseUrl": "https://t3-met-core-{env}-ae1-apim.azure-api.net/monitoring/smc/v1",
      "displayName": "smc-api-connection-gen3",
      "subscriptionKey": "@appsetting('SMC_SubscriptionKey')"
    }
  },
  "functionConnections": {
    "azureFunctionOperation": {
      "authentication": {
        "name": "Code",
        "type": "QueryString",
        "value": "@appsetting('azureFunctionOperation_functionAppKey')"
      },
      "displayName": "{display-name}",
      "function": {
        "id": "/subscriptions/{sub}/resourceGroups/{rsg}/providers/Microsoft.Web/sites/{funcName}/functions/{FunctionName}"
      },
      "triggerUrl": "https://{funcName}.{ase}.appserviceenvironment.net/api/{functionname}"
    }
  },
  "managedApiConnections": {},
  "serviceProviderConnections": {
    "serviceBus": {
      "displayName": "servicebus-shared-conn",
      "parameterSetName": "ManagedServiceIdentity",
      "parameterValues": {
        "authProvider": { "Type": "ManagedServiceIdentity" },
        "fullyQualifiedNamespace": "@appsetting('shared_serviceBus_fullyQualifiedNamespace')"
      },
      "serviceProvider": { "id": "/serviceProviders/serviceBus" }
    },
    "AzureBlob": {
      "displayName": "azure-blob-connection",
      "parameterSetName": "ManagedServiceIdentity",
      "parameterValues": {
        "authProvider": { "Type": "ManagedServiceIdentity" },
        "blobStorageEndpoint": "@appsetting('AzureBlob_blobStorageEndpoint')"
      },
      "serviceProvider": { "id": "/serviceProviders/AzureBlob" }
    }
  }
}
```

**Observed Source:** `Metcash-AIS-Data-Metproducts-Workspace/LogicApp/Connections/connections.dev.json`

---

## parameters.json Structure

```json
{
  "paramSMCEnableObservation": {
    "type": "String",
    "value": "Yes"
  },
  "paramSMCQueue": {
    "type": "String",
    "value": "@appsetting('SMC_QueueName')"
  },
  "param{InterfaceName}": {
    "type": "object",
    "value": {
      "param{InterfaceName}InterfaceId": "EAII-{number}",
      "sbTopic": "{domain}.{service}.{env}.sbt",
      "topicSubscription": "{SubscriptionName}",
      "container": "{blobContainer}",
      "enablePEFileBlobStoreCommunication": "Yes"
    }
  }
}
```

**Observed Source:** `Metcash-AIS-Data-Metproducts-Workspace/LogicApp/Parameters/parameters.dev.json`

---

## App Settings Keys

Always inject via `@appsetting('KeyName')` — never hardcode values. Standard keys:

| Key | Notes |
|---|---|
| `WORKFLOWS_SUBSCRIPTION_ID` | Azure subscription |
| `WORKFLOWS_LOCATION_NAME` | `australiaeast` |
| `WORKFLOWS_RESOURCE_GROUP` | Resource group of this Logic App |
| `WORKFLOWS_ENVIRONMENT` | `dev`, `sit`, `uat`, `prd` |
| `SMC_QueueName` | `smc.endobservation.{smc-env}.sbq` |
| `SMC_SubscriptionKey` | APIM subscription key for SMC API |
| `ServiceBus_FullyQualifiedNamespace` | Service Bus namespace FQDN |
| `shared_serviceBus_fullyQualifiedNamespace` | If using shared Service Bus |
| `gen2_serviceBus_fullyQualifiedNamespace` | If using gen2 Service Bus |
| `AzureBlob_blobStorageEndpoint` | Blob storage endpoint URL |
| `{connName}_functionAppKey` | Function App authentication key |

---

## Inline Assemblies (lib/custom/)

Logic App Standard supports inline .NET assemblies under `lib/custom/{LibName}/`. Used in `Metcash.AIS.RMN` for invoice transform and validation (`TransformAndValidateInvoice/`, `TransformAndValidateTaxInvoiceJournal/`).

---

## Pipeline Pattern

```yaml
# Standard Logic App CI/CD pipeline
# References shared templates from Metcash.AIS.DevOps

trigger:
  - main

variables:
  - group: t3-ais_{interface}_{env}

pool:
  name: Metcash-ALZ-VMSS-Windows-NON-PROD

stages:
  - template: pipelines/templates/logicapp-ci-template.yml@Metcash.AIS.DevOps
  - stage: DeployDEV
    condition: ${{ if eq(parameters.deployDEV, true) }}
  - stage: DeploySIT
    condition: ${{ if eq(parameters.deploySIT, true) }}
  - stage: DeployUAT
    condition: ${{ if eq(parameters.deployUAT, true) }}
  - stage: DeployPRD
    condition: ${{ if eq(parameters.deployPRD, true) }}
```

Shared pipeline templates are in `Metcash.AIS.DevOps/pipelines/templates/`:
- `logicapp-ci-template.yml`
- `logicapp-pr-template.yml`
- `logicapp-ci-sonarqube-template.yml`
- `logicapp-pr-sonarqube-template.yml`
- `logicapp_build_template.yml`

---

## SMC Observability in Workflows

Every workflow must include an SMC start/end observation call:
- Use `apiManagementConnections` to call `smc-v1` API via APIM
- Pass `paramSMCEnableObservation` to control whether observation is sent
- `paramSMCQueue` holds the queue name from app settings

---

## Observed Evidence

| Repository | File Path | Pattern Observed |
|---|---|---|
| `Metcash.AIS.Data.Metproducts` | `/Metcash-AIS-Data-Metproducts-Workspace/LogicApp/Connections/connections.dev.json` | Per-env connections structure with Managed Identity |
| `Metcash.AIS.Data.Metproducts` | `/Metcash-AIS-Data-Metproducts-Workspace/LogicApp/Parameters/parameters.dev.json` | SMC params, interface ID, Service Bus topic params |
| `Metcash.AIS.RMN` | `/logic-app/t3-met-rmn-ae-logic/t3-met-rmn-ae-logic/` | EAII-ID workflow naming, lib/custom assemblies, single connections.json |
| `Metcash.AIS.DevOps` | `/pipelines/templates/logicapp-ci-template.yml` | Shared CI template reference |
| `Metcash.AIS.DevOps` | `/deploy/main.bicep` | Standard app settings provisioning via Bicep |
