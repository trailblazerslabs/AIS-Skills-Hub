# Squad 20 Engineering Overview

> Status: Observed — derived from scanning all repositories in the Squad 20 Azure DevOps project (METCASHDevOps).

---

## What Squad 20 Builds

Squad 20 owns the **Azure Integration Services (AIS)** platform. Its mission is to migrate legacy TIBCO middleware integrations and build new capabilities using Azure Integration Services, targeting Metcash's Azure Gen3 Landing Zone.

---

## Core Technologies

| Technology | Role |
|---|---|
| **Logic App Standard** | Event-driven and HTTP-triggered integration workflows |
| **Azure Function App (.NET 8 Isolated)** | Transformation, enrichment, helper services |
| **Azure Data Factory** | Bulk data movement, batch pipelines |
| **Azure Service Bus** | Async message brokering (topics and queues) |
| **Azure API Management (APIM gen-3)** | API gateway with APIOps lifecycle management |
| **Azure Blob Storage / ADLS Gen2** | File landing, archiving, staging |
| **Azure Key Vault** | Secrets and configuration (DefaultAzureCredential) |
| **Application Insights** | Telemetry and logging |
| **SMC (System Management Console)** | Metcash observability platform — required for all integrations |
| **Bicep** | Infrastructure as Code for project-level app settings and Logic App provisioning |
| **SonarQube** | Code quality in PR and CI pipelines |

---

## Common Repository Types

| Repo Pattern | Example | Contents |
|---|---|---|
| `Metcash.AIS.{Platform}.{Service}` | `Metcash.AIS.B2B.Cloudinary` | FunctionApp + pipelines |
| `Metcash.AIS.{Platform}.{Service}` (Logic App workspace) | `Metcash.AIS.RMN` | logic-app/ + function-app/ + pipelines/ |
| `Metcash.AIS.{Platform}.Datafactory` | `Metcash.AIS.B2B.Datafactory` | ADF JSON: pipeline/, linkedService/, dataset/, trigger/ |
| `Metcash.AIS.APIOps` | `Metcash.AIS.APIOps` | gen-3/artifacts/ (APIOps Toolkit pattern) |
| `Metcash.AIS.DevOps` | `Metcash.AIS.DevOps` | Shared pipeline YAML templates + Bicep modules |
| `Metcash.AIS.Data.{Product}` | `Metcash.AIS.Data.Metproducts` | Logic App Standard workspace (release branch) |

---

## Platform Domains

| Domain | Prefix | Description |
|---|---|---|
| B2B | `b2b-` | Business-to-business integrations (ALM, Cloudinary, Sorted, etc.) |
| B2C | `b2c-` | Business-to-consumer (Marketplace, Wynshop, IndiPIM, etc.) |
| Enabling | `enabling-` | Platform enablement services (BlobManagement, Notifications, R2W) |
| Corporate | `corporate-` | Corporate integrations (MetRisk, RPA, Giftcard) |
| RMN | `rmn-` | Retail Media Network integrations |
| ALMNZ | `almnz-` | ALM New Zealand (WMS, SupplyChainOps, Consignments) |
| Data | `data-` | Product data integrations (Metproducts, PIM) |

---

## Environments

| Shortcode | Full Name | Notes |
|---|---|---|
| `dev` | Development | First deploy target, ALZ non-prod |
| `sit` | System Integration Test | ALZ non-prod |
| `uat` | User Acceptance Test | ALZ non-prod |
| `ppd` | Pre-Production | ALZ non-prod (some projects) |
| `prd` | Production | ALZ prod pool |

---

## Common Integration Patterns

1. **Service Bus → Logic App → Function App → Service Bus** — Event-driven transformation
2. **Service Bus → Logic App → APIM → External System** — Outbound API integration
3. **HTTP (APIM) → Logic App → Function App / Service Bus** — Inbound API to async queue
4. **ADF Pipeline → ADLS → Logic App** — Bulk batch-to-event handoff
5. **Timer → Logic App → APIM / Blob** — Scheduled polling integrations

---

## SMC Observability (Required for All Integrations)

Every Logic App and Function App must send observability events to SMC:
- Queue: `smc.endobservation.{env-mapped}.sbq` (via `SMC_QueueName` app setting)
- Interface IDs stored as APIM named values: `{service}-interfaceid`
- SMC logger abstracted via `ISmcLogger` / `SmcLoggerService` in Function Apps
- Parameters: `paramSMCEnableObservation` (`Yes`/`No`) and `paramSMCQueue`

---

## How Future Agents Should Use the Skill Files

1. Read `squad20-naming-conventions.md` first — always apply Squad 20 naming.
2. Read the technology-specific skill file for the pattern being implemented.
3. Read `squad20-platform-domain-patterns.md` to understand which platform the work belongs to.
4. Check `Metcash.AIS.DevOps` for shared pipeline templates before writing new YAML.
5. Check `Metcash.AIS.APIOps` gen-3 structure when adding or modifying APIs.
6. Always include SMC observability in generated code.
7. Use `DefaultAzureCredential` (Managed Identity) for all Azure service connections — never connection strings with keys.
