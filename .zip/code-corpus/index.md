# Code Corpus Index

Real, currently-deployed code for the same interfaces used as the TSD reference corpus
(`reference-corpus/`) — built the same way: not invented, confirmed by evidence. Where the TSD
corpus's evidence is Confluence exports, this corpus's evidence is Azure DevOps itself: every
repo mapping below was confirmed via the ADO code-search REST API
(`https://almsearch.dev.azure.com/METCASHDevOps/_apis/search/codesearchresults`), searching for
each interface's literal `EAII-<number>` string across every repo in the `Squad 20` project —
not guessed from repo names.

**Raw checkouts live as sibling folders under `C:\Users\jagae\source\repos\`** — the same place
every other local clone in this environment already lives (e.g. the pre-existing
`Metcash.AIS.Data.Metproducts` clone) — not nested inside this project. Only this distilled
corpus is committed to `Metcash.AIS.Shared.Copilot.Prompts`, matching how `reference-corpus/`
separates `source/` (kept) from `_analysis/` (derived); the difference here is the raw source is
full git repos, not documents, so it stays out of this repo's history entirely rather than
being gitignored-but-present.

| Repo | Local path |
|---|---|
| `Metcash.AIS.Data.Metproducts` (existing clone, branch `feature/eai254`) | `C:\Users\jagae\source\repos\Metcash.AIS.Data.Metproducts` |
| `Metcash.AIS.Data.Metproducts` (fresh clone, branch `main` — used for this corpus) | `C:\Users\jagae\source\repos\Metcash.AIS.Data.Metproducts-main` |
| `Metcash.AIS.Data.MDMSupplierInfo` | `C:\Users\jagae\source\repos\Metcash.AIS.Data.MDMSupplierInfo` |
| `Metcash.AIS.B2B.RealTimePricing` | `C:\Users\jagae\source\repos\Metcash.AIS.B2B.RealTimePricing` |
| `Metcash.AIS.APIOps` | `C:\Users\jagae\source\repos\Metcash.AIS.APIOps` |
| `Metcah.AIS.B2B.IBADirects` (EAII-304 — README-only, no code yet) | `C:\Users\jagae\source\repos\Metcah.AIS.B2B.IBADirects` |
| `Metcash.AIS.B2B.01.Datafactory` (shallow clone, `--depth 1` — full history is 1.8GB, current tree is under 1MB) | `C:\Users\jagae\source\repos\Metcash.AIS.B2B.01.Datafactory` |
| `Metcash.AIS.B2C.Datafactory` (existing clone, branch `feature/EAII-429-Inventory`) | `C:\Users\jagae\source\repos\Metcash.AIS.B2C.Datafactory` |
| `Metcash.AIS.B2C.Datafactory` (fresh clone, branch `main` — used for this corpus) | `C:\Users\jagae\source\repos\Metcash.AIS.B2C.Datafactory-main` |

The `-main` suffix on the Metproducts clone avoids clobbering your existing `feature/eai254`
working checkout — same repo, same remote, just a separate local folder on `main` so the two
branches don't collide in one working tree.

**This same clone convention is now also the real codegen output destination, not just a
reference-reading location.** `ais-codegen-readiness` resolves a target repo and clones/reuses
it exactly this way (same `git clone https://METCASHDevOps@dev.azure.com/...` command, same
sibling-folder-under-`C:\Users\jagae\source\repos\` location, same `-main`-suffix pattern to
avoid clobbering an existing personal checkout), then creates a `feature/EAII-<number>-...`
branch there. `ais-*-codegen` skills write generated files directly into that clone — `outputs/
<EAII-ID>/` holds documents only (questionnaires, test results, review reports), never code.

## Methodology

1. `az login --tenant metcash.onmicrosoft.com` (see `azure-local-auth`), subscription doesn't
   matter for ADO — `az repos`/`az boards`/`az rest` calls authenticate against
   `dev.azure.com` using the same Azure AD session.
2. For each corpus EAII ID, POST to the code-search API with `searchText: "EAII-<number>"` and
   `filters: {"Project": ["Squad 20"]}` (`--resource 499b84ac-1321-427f-aa17-267ca6975798` is
   required for `az rest` to acquire the right token; write output to a file rather than
   stdout — the CLI's console encoder crashes on some Unicode bytes in large JSON responses).
3. Group results by `repository.name` to find which repo(s) actually contain each interface.
4. `git clone` each distinct repo found into `repo/<RepoName>/` on its default branch (`main`).
5. Read representative files per archetype (entry point, service/transform logic, DI
   composition root, a Function-level test, a Service-level test) and distil the pattern into
   `patterns/*.md` and `unit-tests/index.md` below — never copy whole files verbatim into the
   corpus; extract the shape and the *why*, cite the source path for traceability.

## Interface → Repo Mapping (confirmed by code search)

| TSD corpus doc | Interfaces | Archetype | Real repo | Evidence |
|---|---|---|---|---|
| `TSD-EAII-333` | 333 | A — APIM-only | `Metcash.AIS.APIOps` | `gen-3/artifacts/apis/b2b-storelinetosorted-campbellspayment-v1/` |
| `TSD-EAII-289` | 289 | A — APIM-only | `Metcash.AIS.APIOps` | `gen-3/artifacts/named values/abnlookup-interfaceid/` |
| `TSD-EAII-297` | 297 | B — APIM + Logic App | `Metcash.AIS.Data.MDMSupplierInfo` | test fixture reference; see note below |
| `TSD-EAII-304` | 304 | D — file/MFT batch | `Metcah.AIS.B2B.IBADirects` (exists, README-only) | Repo matches the work item's original title ("IBA Directs ALM Orders"); 41 real ADO test cases already exist (Test Plan 224095, Suite 416879) but **code has not been built yet** — a genuine test-first case, not a gap in this search |
| `TSD-EAII-514` | 514 | A/B — sync API | `Metcash.AIS.B2B.RealTimePricing` + `Metcash.AIS.APIOps` | `LogicApp/GetPricingData/workflow.json`; APIM named value |
| `TSD-EAII-301_302_516_517` | 301, 302, 516, 517 | C — Function App (pointer msg) | `Metcash.AIS.Data.MDMSupplierInfo` | `FunctionApp/Metcash.AIS.Data.MDMSupplierInfo.Common/Services/MdmSupplierInfoTo{Eim,Pim,Sorted,AlmSorted}Service.cs` |
| `TSD-EAII-284_283_282_385` | 284, 283, 282, 385 | C — Function App (blob event) | `Metcash.AIS.Data.Metproducts` | `FunctionApp/Metcash.AIS.Data.Metproducts.Common/Services/CorporateItemTo{IndiPIM,Sorted,MetProms}Service.cs`, `SupplierItemToSortedService.cs` |
| — | 529 (PE to Stibo, TSD only so far) | C — Function App (blob event) | none yet — code not generated | 0 hits confirms Stage 2 (codegen) hasn't run for EAII-529 yet |

**EAII-297 note:** code search only turned up a shared test fixture
(`Tests/.../Fixtures/ReferenceMessage_SystemNotes_Internal.xml`) in `MDMSupplierInfo`, not a
dedicated EAII-297 service class — its actual Logic App implementation may live elsewhere or
under different naming; treat the archetype-B pattern doc as based on the TSD's own description
plus the general Logic App shape from `RealTimePricing`, not a confirmed EAII-297 source file.

## Corpus Contents

- [`production-snapshot.md`](production-snapshot.md) — **start here**: what is live in production (`main` of the Squad 20 repos, 2026-10-04), SHAs, CHG numbers, which repo to read for which archetype, what is *not* live, and the calibrated checkers.
- [`codegen-eval/2026-10-04-logicapp-holdout.md`](codegen-eval/2026-10-04-logicapp-holdout.md) — held-out test: Logic App code generated from the EAII-514 and EAII-304 TSDs with production hidden, compared with production; what the skill got right, what it missed, what was fixed.
- [`codegen-eval/2026-10-05-eaii529-functionapp.md`](codegen-eval/2026-10-05-eaii529-functionapp.md) — EAII-529 (PE to Stibo) generated from its TSD, built and tested (461/462), checked against the production Function App conventions; shared-file changes, deviations, the host.json finding.

- [`patterns/01-function-app-pattern.md`](patterns/01-function-app-pattern.md) — real Function
  App architecture from `Metcash.AIS.Data.Metproducts` (main) and
  `Metcash.AIS.Data.MDMSupplierInfo`, both **archetype C**.
- [`patterns/02-logic-app-pattern.md`](patterns/02-logic-app-pattern.md) — real Logic App
  Standard SMC-observability pattern from `Metcash.AIS.B2B.RealTimePricing`.
- [`patterns/03-apim-apiops-pattern.md`](patterns/03-apim-apiops-pattern.md) — real APIOps
  gen-3 artifact shape from `Metcash.AIS.APIOps`.
- [`unit-tests/index.md`](unit-tests/index.md) — real xUnit/Moq/FluentAssertions test patterns
  from both Function App repos' `Tests/` projects, plus the real ADO Test Plan structure.
- [`patterns/04-adf-pattern.md`](patterns/04-adf-pattern.md) — real ADF pipeline pattern from
  `Metcash.AIS.B2B.01.Datafactory` and `Metcash.AIS.B2C.Datafactory` (both **archetype D**):
  the SMC variable-accumulator model, Key-Vault-via-REST, the retry-log-to-Table-Storage
  pattern, and lowercase `pl_`/`ds_`/`ls_`/`tr_` naming (corrects the previous uppercase claim).

## Known gap vs. the existing skills

`ais-functionapp-codegen`'s documented pattern (flat `<Name>Function.cs` +
`TransformationOutput<T>` envelope) is **simpler than what's actually in production**. The real
pattern (confirmed identically in both `Metproducts` and `MDMSupplierInfo`) is a 3-project split
with a shared `IServiceBusFunctionExecutor` cross-cutting layer and a `ProcessingResult` model —
see `patterns/01-function-app-pattern.md` for the corrected shape. `ais-functionapp-codegen`
has been rewritten to match this real pattern.
