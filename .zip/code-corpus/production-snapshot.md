# Production snapshot: what is live in Squad 20 (taken 2026-10-04)

This is the evidence base for the codegen skills (`ais-logicapp-codegen`, `ais-functionapp-codegen`, APIOps / `ais-code-review`).
It replaces "whatever is on a feature branch" with **the code that is deployed to production**, and says which repo to read for each
archetype. Source: git on local clones of the `METCASHDevOps/Squad 20` repositories, `origin/main` after `git fetch` on 2026-10-04.

## How "production" was decided

Every Squad 20 deployment pipeline gates its PRD stage on the source branch:

```yaml
- stage: Prd
  condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))     # RealTimePricing, ShipmentManagement, IBADirects
  # Function Apps: condition: eq(variables['Build.SourceBranch'], 'refs/heads/main')  and  targetEnv == 'prd'
```

`release/*` and `feature/*` deploy to dev / sit / uat only. So **production = `main`**, and a change reaches `main` through a merged PR that carries
a change request number (`CHG00xxxxx`) in the title. A branch that is ahead of `main` (a `release/*` branch, an open feature branch) is **not live** and
is not training material. Verify a candidate with `git log origin/main -5` and the PR titles before relying on it.

## Production repositories (all `origin/main`)

| Repo | Kind | Interfaces | `main` SHA | Last production merge | Change request |
|---|---|---|---|---|---|
| `Metcah.AIS.B2B.IBADirects` (sic, the repo name is misspelled in ADO) | Logic App Standard + .NET function inside the workspace | EAII-304 | `20ef9a5` | 2026-09-23 | CHG0065195 |
| `Metcash.AIS.DATA.MetconnectSuppOnboarding` (the **supplier-contract** Logic App behind `data-mdmsupplier-v1`) | Logic App Standard (synchronous HTTP, SOAP to MDM) | EAII-297 | `b594b93` | 2026-09-23 | CHG0065195 |
| `Metcash.AIS.B2B.RealTimePricing` | Logic App Standard (synchronous HTTP, DB2) | EAII-514 | `bff1728` | 2026-09-11 | CHG0064987 |
| `Metcash.AIS.Data.Metproducts` | Function App (.NET 10 isolated) | EAII-254, 282, 283, 284, 385 (529 pending) | `4b0e8d7` | 2026-09-09 | PR 27995 / 28026 / 28027 |
| `Metcash.AIS.Data.MDMSupplierInfo` | Function App (.NET 10 isolated) | EAII-301, 302, 516, 517 | `ad805a4` | 2026-09-22 | PR 27911 and earlier (Aug-Sep) |
| `Metcash.AIS.B2B.Cloudinary` | Function App (.NET 8, older style) | EAII-392, 221 | `3367cbb` | 2026-07-16 | PR 25606 |
| `Metcash.AIS.APIOps` | APIM gen-3 (APIOps) | all APIs | `2681559` | 2026-09-23 | CHG0065195, CHG0065089 |
| `Metcash.AIS.B2B.01.Datafactory` | ADF | B2B | `4755f27` | 2026-07-20 | n/a |
| `Metcash.AIS.B2C.Datafactory` | ADF | B2C | `1240080` | 2026-08-31 | n/a |

## What is NOT live (do not learn from it as if it were)

| Branch | Why it is not production |
|---|---|
| `Metcash.AIS.Logistics.ShipmentManagement` `release/EAII-504-505` (2026-07-27) | `main` is README-only (26 May); the PRD stage needs `main`. Its workflows also drift from the standard (no `SMCGuid` variable, no SMC end message in `Finally`) |
| `Metcash.AIS.Data.Metproducts` `release/pim-to-multiple-targets` (2026-09-30) | ahead of `main` |
| `Metcash.AIS.Data.MDMSupplierInfo` `release/mdm-to-multiple-targets` (2026-10-01) | ahead of `main` |
| `Metcah.AIS.B2B.IBADirects` `release/trg-file-changes` (2026-09-28) | ahead of `main` |
| `feature/EAII-530-address-validation-kleber`, `feature/EAII-533-...`, `feature/EAII-542-...` | local or feature branches, no origin or not merged |

## Which repo to read for which archetype

| Archetype (see `ais-codegen-readiness`) | Read | Notes |
|---|---|---|
| A / B synchronous API, Logic App behind APIM | RealTimePricing `LogicApp/GetPricingData` and MetconnectSuppOnboarding `GetNewSupplierNumber` (two live examples) + APIOps `b2b-pricing-v1` / `data-mdmsupplier-v1` | HTTP trigger, `Response` with `X-Workflow-Executed`, APIM retry keyed on that header |
| B / D queue-, blob- or file-driven batch | IBADirects `LogicApp/LiquorSuppliersToEIM` + `Function/PSVTransformer.cs` + APIOps `b2b-iba-directs-upload-v1` | Service Bus trigger, extract / transform / archive / error folders, local function via `InvokeFunction` |
| C pointer or blob-event Function App | Metproducts and MDMSupplierInfo (identical composition) | 3-project layout, `IServiceBusFunctionExecutor`, per-interface Function + Service |
| APIM API | APIOps `data-mdmsupplier-v1` and `b2b-iba-directs-upload-v1` (23 Sep, the newest standard) | `validate-jwt_v1`, `set-common-inbound-variables_v1`, `on-error_v2`, interface-id named value, backend per operation |
| ADF | B2B.01 and B2C Datafactory | unchanged: see `patterns/04-adf-pattern.md` |

## Other Squad 20 repos on `main` (surveyed 2026-10-04 with the REST repository list, 62 repos, shallow clones of `main`)

Repos with Logic Apps or Function Apps that are **not** the reference standard. Most were written before the Gen3 SMC wiring or use another shape; the Logic App checker flags them, which is the intended result.

| Repo | Contents on `main` | Last commit | Notes |
|---|---|---|---|
| `Metcash.AIS.RMN` | 10 workflows | 2026-10-01 | no `StartObservation` through the APIM connection, no `100` stage, no SMC end send: older SMC wiring |
| `Metcash.Corp.Metrisk` | 6 workflows | 2026-09-30 | different SMC parameter names; one workflow has `Try` + `Finally` only |
| `Metcash.AIS.B2C.Wynshop` | 8 workflows + 73 `.cs` | 2026-09-29 | different folder layout (JSON not readable by the checker as-is) |
| `Metcash.AIS.B2B.Sorted`, `B2C.IndiPIM`, `B2B.ExtendedProductInfo`, `B2B.CreditApplication`, `Metcash.B2B.ProductData`, `ALMNZ.WMS`, `Enabling.Notifications` | Logic Apps | Jan to Sep 2026 | managed-API connections, no SMC end message, or no `Finally`: legacy style |
| `Metcash.AIS.Enabling.R2W`, `B2C.Store`, `Enabling.Common`, `B2C.Finance`, `Enabling.AzureBlobManagement` | Function Apps (110, 81, 23, 40, 42 `.cs`) | Jul to Sep 2026 | not yet compared with the Metproducts shape; candidates for the next calibration round |
| `Metcash.AIS.Logistics.Xdock`, `DATA.ABNLookup`, `Data.MDMSupplierToPIM`, `B2C.Marketing`, `Corp.*` | empty (0 KB) | | placeholders |

Counting `MetconnectSuppOnboarding`, **three** production Logic App repos now pass `check_logicapp.py` with 0 errors (IBADirects, RealTimePricing, MetconnectSuppOnboarding).

## Known gaps in this snapshot

* `Metcash.CoreSys.Storeline` (SMC XREF `getXrefData`) is not in the Squad 20 project (checked against the full repository list).
* Whether a given `main` commit was actually *deployed* (a pipeline run to `prd`) was not checked: the ADO Pipelines API was not queried. A merge to `main` with a CHG number is the evidence used.
* The Function App repos listed above (R2W, Store, Common, Finance, AzureBlobManagement) have not been put through `check_functionapp.py` yet.

## Calibrated checkers (run these on generated code)

| Tool | Calibrated on (must stay at 0 errors) |
|---|---|
| `.github/skills/ais-logicapp-codegen/tools/check_logicapp.py` | IBADirects `main`, RealTimePricing `main`, MetconnectSuppOnboarding `main` (0 errors each; the older-style repos above are expected to fail) |
| `.github/skills/ais-logicapp-codegen/tools/compare_logicapp.py` | not a gate: diffs a generated workspace against production (see `codegen-eval/`) |
| `.github/skills/ais-functionapp-codegen/tools/check_functionapp.py` | Metproducts `main`, MDMSupplierInfo `main` (Cloudinary is the older style and is expected to fail) |
| `.github/skills/ais-code-review/tools/check_apiops.py` | the 23 Sep APIs and the recent b2b-/data- APIs; the older `b2b-creditapplication-v1` and `enabling-notifications-v1` are expected to fail |

Re-run the calibration after every refresh of this snapshot; if a production repo no longer passes, the rule is wrong, not the production code.
