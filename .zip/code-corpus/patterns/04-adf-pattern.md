# Azure Data Factory Pattern — from real production pipelines

Source: `Metcash.AIS.B2B.01.Datafactory` (`main`, shallow clone — repo history is 1.8GB, current
tree is under 1MB) and `Metcash.AIS.B2C.Datafactory` (`main`, fresh clone `-main` suffix to avoid
the existing `feature/EAII-429-Inventory` checkout) — `pl_sku_ingest_product_rest_adls.json` and
`pl_ubereats_ingest_inventory_sql_adls_delta_parent.json` respectively. Confirms and
significantly extends `ais-datafactory-codegen`'s existing pipeline pattern.

## SMC observability — variable-accumulator pattern, not a single WebActivity per stage

The existing skill's "`Log_Pipeline_Start`/`Log_Pipeline_End`" WebActivity pair is a real
simplification of a materially richer pattern, confirmed identically (down to variable names) in
both independent repos:

**Pipeline-scoped variables**, set up before any business logic:
- `var_smc_guid` — a freshly generated correlation GUID for this run
- `var_smc_observation_id` — set from the Start-Observation call's response (or falls back to
  `var_smc_guid` if that call didn't succeed)
- `var_smc_stages` — a **static** JSON array, set **once** via `SetVariable`, listing every
  stage this pipeline will report through, e.g.
  `[{"Description":"Inject stage","StageID":"1.00","StageName":"Inject"}, ..., {"Description":"Observation Completed","StageID":"100.00","StageName":"Observation Completed"}]`
  — always ends in StageID `"100.00"` / `"Observation Completed"`. This is the ADF equivalent of
  the Logic App `SMCStages` variable (see `02-logic-app-pattern.md`) — same concept, same
  terminal stage, different host.
- `var_smc_stages_status` — an **accumulator** array; every activity (success or failure branch)
  appends one JSON object to it via `AppendVariable`, e.g.
  `{"StageName":"Inject","Description":"Step 1.1 - REST authentication completed","Status":"Success","StageID":"1.1"}`
- `var_smc_errors` — an accumulator for error messages, appended via `AppendVariable` from
  `@activity('<name>').error.message` whenever a step fails

**Start Observation** (once, near the top of the pipeline) — `WebActivity` POST to
`pipeline().globalParameters.gp_smc_start_observation_url` (name varies slightly per repo —
`gp_startObservationUrl` in B2C), body:
```json
{
  "InterfaceID": "@{variables('var_interface_id')}",
  "Environment": "@{pipeline().globalParameters.gp_environment}",
  "StageName": "Start Observation",
  "StageStatus": "Success",
  "ObservationID": "@{variables('var_smc_guid')}",
  "ParentObservationID": "@{pipeline().parameters.p_parent_observation_id}",
  "ResourceName": "@{variables('var_pipeline_run_id')}.@{variables('var_data_factory_name')}.@{variables('var_pipeline_name')}",
  "ResourceTriggerName": "@{variables('var_trigger_name')}",
  "ResourceType": "@{variables('var_data_factory_name')}",
  "ResourceRunID": "@{variables('var_pipeline_run_id')}"
}
```
Authentication: `{"type": "MSI", "resource": "https://management.azure.com/"}` — **not**
`vault.azure.net` (that resource is only for the separate Key Vault GET calls below).
`ParentObservationID` is how a child pipeline correlates back to its parent's observation —
always pass it through on `ExecutePipeline` calls (see chaining pattern below).

**End Observation** (one branch per outcome — success, and one per distinct failure point) —
`WebActivity` POST to `gp_smc_observation_point_url`, body includes `ObservationID`,
`StageName`, `StageStatus` (`"Success"`/`"Failure"`), `SMCMessageHeaders` (PipelineName, RunId),
`SMCStages` (the static `var_smc_stages`, stringified), `ExceptionMessage` (on failure only,
built from `var_smc_errors`), `IsObservationComplete: true`, and `LogMessage` — a string
containing the **entire accumulated `var_smc_stages_status` array**, JSON-escaped, wrapped as
`{ "SMC": <status array> }`. This single `LogMessage` field is what carries the full stage
timeline, not separate log calls per stage. `continueOnError: true` on every one of these
logging activities — a logging failure must never fail the actual pipeline.

**Action item for `ais-datafactory-codegen`:** replace the "Log_Pipeline_Start/Log_Pipeline_End"
two-activity pattern with this variable-accumulator model. Applied below.

## Key Vault secret retrieval — direct REST call, not a Key Vault linked service/dataset

Secrets (REST auth username/password, SMC subscription key) are fetched via a plain
`WebActivity` GET, not ADF's native Key Vault dataset/linked-service integration:

```json
{
  "type": "WebActivity",
  "typeProperties": {
    "method": "GET",
    "url": { "value": "@concat(pipeline().globalParameters.gp_key_vault_base_url, 'secrets/', pipeline().parameters.p_auth_username_secret_name, '?api-version=7.4')", "type": "Expression" },
    "connectVia": { "referenceName": "t3aisadfshir", "type": "IntegrationRuntimeReference" },
    "authentication": { "type": "MSI", "resource": "https://vault.azure.net" }
  }
}
```

Note the secret **name** is parameterized (`p_auth_username_secret_name`), not the secret value
— matches the corpus-wide rule of never hardcoding a secret value. `connectVia` the shared
self-hosted integration runtime `t3aisadfshir` on every WebActivity, not just Copy activities.

## REST-to-ADLS ingest pipeline shape (`pl_sku_ingest_product_rest_adls`)

1. Start Observation + fetch SMC subscription key from Key Vault (parallel-ish, both gated behind `act_setvar_smc_stages`)
2. Fetch REST auth username + password secrets from Key Vault (two parallel WebActivity GETs)
3. POST to the auth URL with those credentials to get a bearer token (`act_web_sku_get_token`)
4. `Copy` activity: `RestSource` (with the bearer token in `additionalHeaders.Authorization`,
   pagination via `paginationRules.supportRFC5988`, and `additionalColumns` capturing the raw
   JSON payload as its own column) → `JsonSink` to ADLS (`AzureBlobStorageWriteSettings`,
   `copyBehavior: FlattenHierarchy`)
5. `ExecutePipeline` into a separate transform pipeline, passing computed `p_smc_observation_id`
   that — **on a retry** — reuses the *original* run's observation ID from
   `pipeline().parameters.p_parent_observation_id` rather than generating a new one:
   `@if(pipeline().parameters.p_is_retry, trim(coalesce(pipeline().parameters.p_parent_observation_id, '')), variables('var_smc_observation_id'))`
6. `IfCondition` checking the transform pipeline's own status and raising an explicit `Fail`
   activity (`errorCode: "TRANSFORM_FAILED"`) if it didn't succeed — ADF's own "did the child
   pipeline succeed" isn't trusted implicitly; it's checked and force-failed with a clear code.
7. End Observation (success or failure branch, per the pattern above)

## Retry-log pattern — a real Azure Table Storage retry mechanism

On specific failure branches (Key Vault secret fetch, auth token fetch), **and only when this
run is not itself a retry** (`@not(pipeline().parameters.p_is_retry)`), the pipeline writes a
full snapshot of every one of its own parameters to an Azure Table Storage row via a raw REST
`WebActivity` (not a Copy/dataset):

```json
{
  "method": "POST",
  "headers": { "Accept": "application/json;odata=nometadata", "Content-Type": "application/json",
    "x-ms-date": { "value": "@formatDateTime(utcNow(), 'R')", "type": "Expression" },
    "x-ms-version": "2019-02-02" },
  "url": { "value": "@concat('https://', pipeline().globalParameters.gp_storage_account_name, '.table.core.windows.net/', pipeline().globalParameters.gp_retry_log_table_name)", "type": "Expression" },
  "authentication": { "type": "MSI", "resource": "https://storage.azure.com/" }
}
```
Body is a `PartitionKey`/`RowKey` (new `guid()`) row capturing `FailedActivity`, `FailedPipeline`,
`PipelineRunId`, `ObservationId`, and **every pipeline parameter value** so a separate retry
mechanism (a scheduled pipeline reading this table — matches `reference-templates`'s
`cfgAdfPipelineRetryPolicy`/`logAdfPipelineRetry` tables convention) can replay the exact same
run later. Guarding with `p_is_retry` prevents a retry attempt from re-logging itself into the
same table on its own failure.

## Parent/child pipeline orchestration + DB-side status ledger (`pl_ubereats_ingest_inventory_sql_adls_delta_parent`)

In addition to the SMC accumulator pattern, this pipeline shows a **second, complementary**
observability mechanism: a SQL stored-procedure status ledger, called at each phase:

```json
{
  "type": "SqlServerStoredProcedure",
  "typeProperties": {
    "storedProcedureName": "[dbo].[sp_UpdateUberEatsPipelineStatus]",
    "storedProcedureParameters": {
      "ExecutionPhase": { "value": "START", "type": "String" },
      "PipelineName": { "value": { "value": "@variables('var_pipeline_name')", "type": "Expression" }, "type": "String" },
      "PipelineStatus": { "value": "INPROGRESS", "type": "String" }
    }
  }
}
```
Called with `ExecutionPhase`/`PipelineStatus` of `START`/`INPROGRESS`, `END`/`SUCCESS`, and
`FAILED`/`FAILED` at the appropriate points — a durable, queryable status record independent of
SMC, useful when the interface's own database is the natural place to check "did today's load
run" (rather than only through SMC). Use this pattern when the FSD/TSD calls for DB-visible
pipeline status, not as a universal requirement.

Also demonstrates: a `Lookup` activity calling a stored procedure to fetch a driving list (store
IDs), an `IfCondition` branching on whether that list is empty, and `ExecutePipeline` fan-out to
child pipelines with `waitOnCompletion: true` and `p_parent_observation_id` passed through for
correlation — the standard shape for a "fetch driving list → per-item/batch child pipeline"
parent orchestrator.

## Linked service — confirms Managed Identity, extends the naming

```json
{
  "name": "ls_sku_sql_azure_shir",
  "properties": {
    "parameters": { "sqlServerName": { "type": "string", "defaultValue": "t3-met-b2b-dv1-ae-sql.database.windows.net" },
                     "databaseName": { "type": "string", "defaultValue": "b2b-integration-dv1-sqldb" } },
    "type": "AzureSqlDatabase",
    "typeProperties": { "server": "@{linkedService().sqlServerName}", "database": "@{linkedService().databaseName}",
                          "encrypt": "mandatory", "trustServerCertificate": false,
                          "authenticationType": "SystemAssignedManagedIdentity" },
    "connectVia": { "referenceName": "t3aisadfshir", "type": "IntegrationRuntimeReference" }
  }
}
```
Confirms the existing skill's Managed Identity claim exactly, and adds: server/database are
**linked service parameters** with per-environment `defaultValue`s (not hardcoded, and not
pulled from a dataset parameter) — `encrypt: "mandatory"` — every SQL-touching activity
(`connectVia`) goes through the shared self-hosted IR `t3aisadfshir`.

## Corpus → `ais-datafactory-codegen` action items

- Replace the two-WebActivity SMC log pattern with the variable-accumulator pattern above. Applied.
- Document the Key-Vault-via-WebActivity-GET pattern (not a Key Vault linked service). Applied.
- Document the retry-log-to-Table-Storage pattern, gated by `p_is_retry`. Applied.
- Document `ParentObservationID` propagation on `ExecutePipeline` calls for correlation across
  parent/child pipelines. Applied.
- Note the SQL stored-procedure status ledger as an optional complementary pattern, not a
  universal requirement. Applied.
