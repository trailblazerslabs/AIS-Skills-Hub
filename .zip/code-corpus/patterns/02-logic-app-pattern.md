# Logic App Standard Pattern (Archetype A/B — synchronous API) — from real production code

Source: `Metcash.AIS.B2B.RealTimePricing` (`main`, EAII-514), workflow
`LogicApp/GetPricingData/workflow.json`.

## Folder shape (matches what `ais-logicapp-codegen` already documents)

```
LogicApp/
├── AppSettings/appsettings.{dev,sit,uat,prd}.json
├── Connections/connections.{dev,sit,uat,prd}.json
├── GetPricingData/workflow.json        ← one folder per workflow, folder name = workflow name
├── Parameters/parameters.{dev,sit,uat,prd}.json
├── connections.json                    ← base/shared
├── parameters.json                     ← base/shared
└── host.json
```

This part of the existing skill is accurate — the per-environment file split
(`AppSettings/`, `Connections/`, `Parameters/` each with `.dev/.sit/.uat/.prd.json`) is real and
confirmed.

## SMC observability — the real variable-initialization pattern

The existing skill's "3 SMC logging actions" (`Log_Interface_Start`/`End`/`Error`) is a
simplification. The real pattern initializes a set of **workflow-scoped variables at the very
start of the trigger**, before any business logic, then builds up to them throughout the run:

```json
"Initialize_SMCGuid": {
  "type": "InitializeVariable",
  "inputs": { "variables": [{
    "name": "SMCGuid", "type": "string",
    "value": "@{coalesce(triggerOutputs()?['headers']?['ParentObservationID'], guid())}"
  }]}
},
"Initialize_SMCErrors":  { "...": "type: array, no initial value" },
"Initialize_SMCStagesStatus": { "...": "type: array, no initial value" },
"Initialize_SMCStages": {
  "type": "InitializeVariable",
  "inputs": { "variables": [{
    "name": "SMCStages", "type": "array",
    "value": [
      { "Description": "<what this stage does>", "StageID": "1.0", "StageName": "Data Retrieval" },
      { "Description": "<what this stage does>", "StageID": "1.1", "StageName": "AS/400 call" },
      { "Description": "All observation points complete", "StageID": "100", "StageName": "Observation Complete" }
    ]
  }]}
},
"Initialize_SMCCorrelationProperties": { "...": "type: array, no initial value" }
```

Key points, confirmed from the real workflow:
- **`SMCGuid` is sourced from an inbound `ParentObservationID` header when present**, falling
  back to a fresh `guid()` — this is how correlation chains across a caller → this workflow →
  downstream call, rather than each hop generating its own unrelated ID. Reuse this exact
  `coalesce(triggerOutputs()?['headers']?['ParentObservationID'], guid())` expression.
- **`SMCStages` is a static array declared once, up front**, listing every stage this workflow
  will report through — including the terminal `"100" / "Observation Complete"` stage that
  every workflow in the corpus uses identically. This is effectively the workflow's own table of
  contents for SMC, and should be written before the rest of the actions are built, not
  retrofitted afterward.
- `SMCErrors` and `SMCStagesStatus` start empty and are appended to as actions run — the actual
  SMC log call at the end serializes these accumulated arrays, rather than the 3-fixed-action
  model the skill previously described.

**Applied:** `ais-logicapp-codegen`'s SMC section now documents this variable-accumulation
pattern (including the exact `SMCGuid` correlation expression) instead of the old "3 logging
actions" description.

## What's still accurate in the existing skill

- HTTP trigger shape (`"type": "Request", "kind": "Http"`) — matches
  `When_a_HTTP_request_is_received` in the real workflow exactly.
- Managed Identity on connections — no contradicting evidence found; not re-verified in this
  pass (would need to read the workflow's outbound HTTP/AS400 actions in full).

---

## UPDATE 2026-10-04: second production Logic App, and the complete pattern

The first version of this document came from one workflow (`RealTimePricing`). Production now has two Logic App repos on `main`
(see [`../production-snapshot.md`](../production-snapshot.md)): `Metcash.AIS.B2B.RealTimePricing` (EAII-514, synchronous HTTP, DB2) and
`Metcah.AIS.B2B.IBADirects` (EAII-304, Service Bus + blob, with a .NET function). What they share is the pattern the skill now encodes;
`tools/check_logicapp.py` in `ais-logicapp-codegen` enforces it and prints 0 errors / 0 warnings on both.

### Shared by both production workflows

* `kind: Stateful`; one trigger; variable initialisers are the only top-level actions with no `runAfter`.
* SMC variables: `SMCGuid`, `SMCErrors`, `SMCStagesStatus`, `SMCStages` (ends with StageID `100`), `SMCCorrelationProperties`, `SMCMessageHeaders`.
* `Try` (gated on all initialisers) / `Catch` (after `Try` on FAILED, TIMEDOUT) / `Finally` (after `Catch`, all four states).
* `Start_Observation` is an `ApiManagement` action through connection `apiManagementOperationSMC`, operation `post-startobservation`, path `/startObservation`,
  with `EnableObservation` taken from `paramSMCEnableObservation`.
* `Finally` ends the observation by sending one message to the SMC queue through `serviceBusSMC` (`sendMessage`, entity `paramSMCQueue`) carrying
  `SMCGuid, SMCStages, SMCStagesStatus, SMCError, SMCCorrelationProperties, SMCMessageHeaders, SMCEnableObservation, MessageBody, StageName`.
* Connections are **built-in service providers with Managed Identity**, defined per environment (`Connections/connections.<env>.json`); the SMC APIM connection
  uses `subscriptionKey = @appsetting('SMC_API_Subscription_Key')`, a Key Vault reference (`@Microsoft.KeyVault(SecretUri=...)`) in `AppSettings/`.
* Workflow parameters are `param*` (`paramSMCEnableObservation`, `paramSMCQueue`, `paramEAII<n>InterfaceId`, folder parameters), set per environment.
* Pipeline `pipelines/gen3<name>ladep.yml` + two templates; the PRD stage runs only from `refs/heads/main`.

### Seen only in the queue / file workflow (IBADirects, 150 actions)

* **A failure branch for every action that can fail** (`Set_HasErrors_true_on_X_failure` → `Set_ErrorMessage_from_X_failure` → `Append_to_SMCErrors_X_failure` →
  `Append_SMC_Stage_Status_<Stage>_Failed`), so the SMC record says exactly which step failed.
* `retryPolicy` fixed, count 3, interval `PT5S`, on built-in connector calls.
* File handling: `extractArchiveFromBlobPath` (zip), read blob content and metadata, `InvokeFunction` for the .NET transform, upload to the output folder,
  **copy to archive then delete the source on success; copy to the error folder then delete on failure**.
* `Terminate` (`runStatus: Failed`, code 500) only when `HasErrors` is true **and** the file was not already moved to the error folder.
* The Service Bus trigger is `type: ServiceProvider` with `operationId: receiveQueueMessages` and `splitOn`, queue name from `appsetting('ServiceBus_InputQueue')`.
* Folder paths are parameters per stage (`IBADirects/extract`, `/toeim`, `/archive`, `/error`), the container is an app setting.

### Seen only in the synchronous workflow (RealTimePricing)

* `Request`/`Http` trigger; the `Response` action returns a `StatusCode` variable and the header **`X-Workflow-Executed: Completed`**. APIM's backend retry
  policy treats a response *without* that header as "workflow never ran" and retries once, so the header is part of the contract.
* `Finally` appends correlation and header values, returns the response, and sends the SMC message only when logging is enabled (`Check_SMC_Logging_Enabled_`).
* DB2 connection is the one non-Managed-Identity connector: every value is `@appsetting('DB2_*')`, the password is a Key Vault reference.

### Differences from the old reference template / earlier skill text (all corrected in the skill)

| Old skill / template | Production |
|---|---|
| `connections.json` entries with `connectionId` / `managedApis` | `serviceProviderConnections` + `apiManagementConnections`, per environment |
| parameters named `<Interface>_<Key>` | `param<Name>` camelCase, per environment |
| trigger `"type": "ServiceBusTrigger"` | `"type": "ServiceProvider"`, `receiveQueueMessages` |
| single `connections.json` / `parameters.json` / `local.settings.json` | `AppSettings/`, `Connections/`, `Parameters/` each with dev, sit, uat, prd |
| error handling: "terminal path calls SMC logging" | Try / Catch / Finally, per-action failure branches, SMC end message in `Finally` |
| references to `references/workflow-patterns.md` (did not exist) | removed; evidence is this file and `production-snapshot.md` |

### Outliers (do not copy)

* A stray `workflow.json` at the root of the IBADirects repo (a leftover; the real workflow is under `LogicApp/LiquorSuppliersToEIM`).
* `Metcash.AIS.Logistics.ShipmentManagement` `release/EAII-504-505` (not on `main`, not live): no `SMCGuid` variable, no SMC end message.
