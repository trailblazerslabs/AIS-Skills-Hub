# Function App Pattern (Archetype C — event-driven) — from real production code

Source: `Metcash.AIS.Data.Metproducts` (`main`, EAII-284/283/282/385) and
`Metcash.AIS.Data.MDMSupplierInfo` (`main`, EAII-301/302/516/517). Both repos independently
converged on the **identical** shape — that convergence, not any single file, is the evidence
this is the real, current standard (not one team's local habit).

## Project split (3 projects per repo, not 1)

```
FunctionApp/
├── <RepoName>/                      ← the Azure Function host project
│   ├── Functions/                   ← one class per interface = one Function trigger
│   ├── Program.cs                   ← composition root (DI registration)
│   └── <RepoName>.csproj
├── <RepoName>.Common/                ← everything the host project doesn't need to know about
│   ├── Configuration/AppSettings.cs  ← one flat class, ALL settings for every interface in the repo
│   ├── Executor/                     ← IServiceBusFunctionExecutor + impl — see below
│   ├── Models/                       ← per-target-system namespaces (Models/Sorted, Models/Smc, ...)
│   ├── Services/                     ← one *Service per interface + shared infra services
│   │   └── Interfaces/
│   └── Utilities/
└── <RepoName>.sln

Tests/
└── <RepoName>.Tests/
    ├── Executor/       ← tests for the executor itself
    ├── Functions/      ← one test class per Function (mocks the Service + Executor)
    └── Services/       ← one test class per Service (mocks Blob/Http/Gating, real Transform)
```

This is a **materially different (and more mature) shape** than what `ais-functionapp-codegen`
previously documented (flat `<Name>Function.cs` + `Models/` + `Services/` in one project). The
skill has been corrected to match this.

## The Function class — thin, no logic

```csharp
namespace Metcash.AIS.Data.Metproducts.Functions;

/// <summary>
/// EAII-283 - Distribute Corporate Item Data from STIBO to Sorted.
/// Trigger: Service Bus topic %SortedCorporateTopicName% / %SortedCorporateSubscriptionName%
/// </summary>
public class CorporateItemToSorted
{
    private readonly ICorporateItemToSortedService _service;
    private readonly IServiceBusFunctionExecutor _executor;
    private readonly string _smcInterfaceId;

    public CorporateItemToSorted(
        ICorporateItemToSortedService service,
        IServiceBusFunctionExecutor executor,
        IOptions<AppSettings> settings)
    {
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _executor = executor ?? throw new ArgumentNullException(nameof(executor));
        _smcInterfaceId = settings.Value.SmcInterfaceIdEAII283;   // one settings key PER interface
    }

    [Function("CorporateItemToSorted")]
    public Task RunAsync(
        [ServiceBusTrigger("%SortedCorporateTopicName%", "%SortedCorporateSubscriptionName%",
            Connection = "ServiceBusConnection")]
        ServiceBusReceivedMessage message,
        ServiceBusMessageActions actions,
        FunctionContext context)
        => _executor.ExecuteAsync(message, actions, context, _smcInterfaceId,
            nameof(CorporateItemToSorted), _service.ProcessAsync);
}
```

Rules this demonstrates:
- **The Function class has zero business logic.** It wires the trigger to
  `_executor.ExecuteAsync(...)`, passing its own Service's `ProcessAsync` method as a delegate.
  Every cross-cutting concern (telemetry, SMC logging, message completion/dead-lettering) lives
  in the shared executor, not duplicated per Function.
- Trigger topic/subscription names are **app-setting placeholders** (`%Name%`), never hardcoded.
- The interface ID passed to the executor comes from `AppSettings`
  (`SmcInterfaceIdEAII283 = "EAII-283"`), not a string literal in the Function.

## The shared executor — the actual cross-cutting layer

```csharp
public interface IServiceBusFunctionExecutor
{
    Task ExecuteAsync(
        ServiceBusReceivedMessage message,
        ServiceBusMessageActions actions,
        FunctionContext context,
        string interfaceId,
        string functionName,
        Func<string, string, List<LogMessage>, Task<ProcessingResult>> processAsync);
}
```

`ServiceBusFunctionExecutor.ExecuteAsync` does, in order, for every Service Bus trigger in the
repo:
1. Resolve a correlation ID (from `message.CorrelationId`, falling back to an
   `ApplicationProperties["CorrelationId"]`, falling back to a new GUID).
2. Log start + `TelemetryClient.TrackEvent($"{functionName}.Triggered", ...)`.
3. Extract the blob URL from the message body and call the Service's `processAsync` delegate.
4. On success: `TrackEvent($"{functionName}.Completed", ...)`.
5. On exception: `_logger.LogError` + `TrackException`.
6. **Always** (`finally`): call `ISmcService.LogObservationAsync(...)` — SMC gets an observation
   record regardless of outcome.
7. Settle the message explicitly: `CompleteMessageAsync` on success/skip,
   `DeadLetterMessageAsync` on any failure — **`host.json` disables `autoComplete`** specifically
   so this executor is the single place that ever settles a message. A failure dead-letters on
   the *first* delivery rather than being silently redelivered up to `MaxDeliveryCount`.

This is the single most important pattern to replicate: **one executor per trigger type, shared
across every interface in the repo** — not reimplemented per Function.

## The Service class — the actual business logic

Signature: `Task<ProcessingResult> ProcessAsync(string blobUrl, string correlationId, List<LogMessage> logMessages)`
— this exact signature is what `Func<string, string, List<LogMessage>, Task<ProcessingResult>>`
in the executor expects.

Observed shape (`CorporateItemToSortedService`, EAII-283):
1. **Gating check first** — an `IXxxGatingService.IsAvailableAsync()` call before doing any
   work; if the downstream system is known-unavailable, return `ProcessingResult.Skipped(...)`
   immediately (not a failure — a deliberate skip) and complete the message rather than
   dead-lettering it.
2. Download the source payload from blob (`IBlobService.DownloadXmlAsync`), append a
   `LogMessage` with a `StageID` (e.g. `"1.00"`) for every meaningful step — these `StageID`s are
   what SMC displays as the interface's stage timeline.
3. Transform (`ITransformService.Transform(xml)`), wrapped in try/catch that logs a `LogMessage`
   and **rethrows** on failure — the Service doesn't swallow transform errors, the executor's own
   catch handles final settlement.
4. Retry loop (`MaxRetries = 3`, `RetryDelay = 2s`) around the outbound POST:
   - `HttpStatusCode.BadRequest` → **non-retryable**, return `ProcessingResult.Failure(...)`
     immediately (don't burn retries on a request the target will never accept).
   - Any other non-success or a thrown exception → log `"Retrying"` and loop.
   - Exhausted retries → `ProcessingResult.Failure($"... failed after {MaxRetries} attempts...")`.
5. An opt-in, off-by-default diagnostic event
   (`AppSettings.EnablePayloadDiagnosticLogging`) that tracks blob URL, endpoint, request/response
   bodies as one `TelemetryClient.TrackEvent` — kept off in PRD, and **redacted per-interface**
   when the FSD's data classification says so (EAII-282's supplier commercial terms, per the
   `AppSettings.cs` comment) — don't assume diagnostic logging is always safe to enable.

`ProcessingResult` is a small result model with `IsSuccess`, `Status` (`"Success"`/`"Skipped"`/
`"Failed"`), `ItemNumber`, `OutputBlobUrl`, `ErrorMessage`, `ErrorCode`, and static factories
(`.Success(...)`, `.Skipped(...)`, `.Failure(...)`) — this is the shared envelope every Service
returns, replacing what the old skill called `TransformationOutput<T>` (that type does not
actually exist in either real repo).

## Composition root (`Program.cs`)

- `HostBuilder().ConfigureFunctionsWorkerDefaults()`, `AddApplicationInsightsTelemetryWorkerService()`.
- Strongly-typed settings binding **handles the Azure-vs-local settings shape difference**:
  Azure app settings are flat; `local.settings.json` wraps them under `"Values"`. The real
  pattern checks whether a `"Values"` section has children and binds to whichever is present —
  copy this exactly, it's a real, previously-hit bug class, not a stylistic choice.
- `BlobServiceClient` registered as a singleton using `DefaultAzureCredential()` — **never** a
  connection string.
- HTTP-calling services registered via `AddHttpClient<TService>(...)` (typed clients), not a
  bare `HttpClient` field.
- Every per-interface Service registered `AddScoped`; shared infrastructure services
  (`SmcService`, `BlobService`, the executor) registered `AddSingleton`.
- Registrations are **grouped by interface with a `// EAII-NNN — <short name>` comment** above
  each block — copy this convention exactly, it's how a shared repo stays navigable as more
  interfaces are added to it.

## `AppSettings.cs` — one class, every interface's config, clearly sectioned

Confirmed real structure: a single flat `AppSettings` class per repo (not one per interface),
sectioned with comment headers per interface/target system
(`// Sorted (EAII-282 / EAII-283)`, `// IndiPIM (EAII-284)`, ...). Every property defaults to
`string.Empty` (never `null`), and non-obvious fields carry a comment explaining *why* (e.g. why
`SmcEnvironment` and `AppEnvironment` are two different values, or why a JMS field is "TBC —
ported from the reference Logic App's parameters.{env}.json"). Follow this pattern for any new
interface added to a shared repo — extend the one `AppSettings` class, don't create a second one.

---

## UPDATE 2026-10-04: verified against production `main`

Re-read `Metcash.AIS.Data.Metproducts` (`4b0e8d7`, 2026-09-09) and `Metcash.AIS.Data.MDMSupplierInfo` (`ad805a4`, 2026-09-22), the Function Apps live in production
(PRD stage runs only from `main`; see [`../production-snapshot.md`](../production-snapshot.md)). The composition below is identical in both and is what
`ais-functionapp-codegen/tools/check_functionapp.py` checks (0 errors on both):

* `net10.0`, `AzureFunctionsVersion v4`, isolated worker (`OutputType Exe`), packages `Microsoft.Azure.Functions.Worker 1.23.0`, `Worker.Sdk 2.0.7`,
  `Worker.Extensions.ServiceBus 5.16.0`, `Extensions.Http 3.2.0`, `ApplicationInsights.WorkerService 2.22.0`, `Microsoft.Extensions.Azure`, `Azure.Identity`.
* Layout `FunctionApp/<Name>` (Program.cs, host.json, `Functions/`), `FunctionApp/<Name>.Common` (`Configuration/AppSettings.cs`, `Services/` + `Services/Interfaces/`,
  `Models/Smc/`, `Executor/`), `Tests/<Name>.Tests`, `pipelines/g3<name>fnapp.yml`, `pipelines/appsettings/{dev,sit,uat,prod}.local.settings.json` + `merge-app-settings.yml`.
* `Program.cs`: `new HostBuilder().ConfigureFunctionsWorkerDefaults()`, `Configure<AppSettings>` reading flat settings with a `Values:` fallback for local runs,
  `AddApplicationInsightsTelemetryWorkerService()`, `BlobServiceClient(new Uri(BlobStorageEndpoint), new DefaultAzureCredential())`, typed `AddHttpClient<T>()`,
  singleton `ISmcService` and `IServiceBusFunctionExecutor`, scoped per-interface services, named HTTP clients with an mTLS handler where the target needs a client certificate.
* One function class per interface; Service Bus functions take `ServiceBusMessageActions` and delegate to `IServiceBusFunctionExecutor.ExecuteAsync`, which owns try/catch,
  telemetry, SMC observation and **explicit settlement** (success completes, failure dead-letters on first delivery; in-process retry only). **Correction 2026-10-05:** production `host.json` sets `messageHandlerOptions.autoComplete=false`, which is the Service Bus extension **4.x** schema; the app runs extension 5.x, whose key is `extensions.serviceBus.autoCompleteMessages` (Microsoft Learn, host.json settings, extension 5.x). The setting is therefore probably a no-op and the executor's explicit settlement is what works; Microsoft's guidance is `AutoCompleteMessages = false` on the trigger attribute (needs a newer `Worker.Extensions.ServiceBus` than the pinned 5.16.0). A platform-level fix, not an interface change.
* Secrets in `*.local.settings.json` are `@Microsoft.KeyVault(VaultName=...;SecretName=...)` references (the Logic App `appsettings` files use `SecretUri=` instead).
* Recent production behaviour changes worth knowing (Metproducts / MDM, Aug-Sep 2026): raw response bodies and exception text are kept out of SMC log messages; SMC observation naming
  and date format aligned with Cloudinary; Sorted POSTs serialised per item number to avoid concurrent-write conflicts; DLQ reversal for EAII-301; one consolidated `HealthCheck`
  that probes every dependency without posting payloads; MDM authentication moved to HTTP Basic.
* `Metcash.AIS.B2B.Cloudinary` (production, 16 Jul) is the **older** style (net8, `FunctionsApplication.CreateBuilder`, Key Vault configuration provider, no executor, no Common/Tests
  split). New code follows Metproducts / MDMSupplierInfo, not Cloudinary.

### EAII-529 (2026-10-05): the third outcome and the file-staged shape

Generated from the TSD and checked against this production shape: a flat-file, six-payload, three-endpoint interface added `ProcessingResult.DataError` (completes the message although SMC records Failed), a blob lifecycle service
(download with metadata, move to `archive/` or `error/`, resume markers), a per-run Stibo token service, an explicit retry loop with settings-driven count and delay, and a session-enabled trigger. The shared executor changed by three lines,
backwards compatible (default `false`), and all 317 baseline tests still pass. Details and the full deviation list: `code-corpus/codegen-eval/2026-10-05-eaii529-functionapp.md`.
