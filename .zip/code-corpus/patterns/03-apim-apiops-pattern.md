# APIM / APIOps gen-3 Pattern (Archetype A — APIM-only) — from real production code

Source: `Metcash.AIS.APIOps` (`main`), API `gen-3/artifacts/apis/b2b-storelinetosorted-campbellspayment-v1/`
(EAII-333 — confirmed by code search, matches `TSD-EAII-333`'s "Storeline to CCC / Campbells
Payment" title exactly).

## Folder shape per API

```
gen-3/artifacts/apis/<api-name>/
├── apiInformation.json     ← API-level metadata (see below)
├── policy.xml              ← APIM inbound/outbound/backend policy
├── operations/             ← one subfolder or file per operation
└── <ExternalContractName>.wsdl   ← present when the backend is SOAP (kept verbatim, not converted)
```

Matches `skills/api-management-apiops-skill.md`'s documented gen-3 structure — confirmed
accurate, no correction needed here.

## `apiInformation.json` — real shape

```json
{
  "properties": {
    "path": "eis/campbellspayment",
    "apiRevision": "1",
    "apiVersion": "v1",
    "apiVersionSetId": "/subscriptions/<sub>/resourceGroups/t3-met-core-dev-ae1-rsg-apim/providers/Microsoft.ApiManagement/service/t3-met-core-dev-ae1-apim/apiVersionSets/b2b-storelinetosorted-campbellspayment",
    "authenticationSettings": {},
    "description": "This API provides endpoint to create Campbell's payment request.",
    "isCurrent": true,
    "displayName": "B2B-StorelineToSorted-CampbellsPayment",
    "protocols": ["https"],
    "serviceUrl": "https://t3-met-core-dev-ae1-apim.azure-api.net/eis/campbellspayment/v1",
    "subscriptionKeyParameterNames": {
      "header": "Ocp-Apim-Subscription-Key",
      "query": "subscription-key"
    },
    "subscriptionRequired": false
  }
}
```

Points confirmed real, worth copying exactly for any new API artifact:
- `path` uses a short domain-style prefix (`eis/campbellspayment`), not the full API name.
- `apiVersionSetId` is a full ARM resource ID referencing the **dev** resource group/APIM
  instance (`t3-met-core-dev-ae1-rsg-apim` / `t3-met-core-dev-ae1-apim`) even though this file is
  environment-agnostic source — APIOps substitutes the environment at deploy time; don't
  hand-edit this to a different env's RG/APIM name.
- `displayName` is PascalCase-with-hyphens matching the folder name capitalized
  (`b2b-storelinetosorted-campbellspayment-v1` → `B2B-StorelineToSorted-CampbellsPayment`).
- `subscriptionRequired: false` on this API — confirms subscription-key enforcement is a
  per-API choice, not a blanket default; check the FSD/TSD for whether the specific interface
  requires a subscription key before assuming either way.

## Naming corpus cross-check

`b2b-storelinetosorted-campbellspayment-v1` matches the `platform-service-v1` naming rule in
`skills/api-management-apiops-skill.md` exactly (`b2b` platform, `storelinetosorted-
campbellspayment` service, `v1` version) — this real example is a good canonical reference to
point to from that skill going forward.

---

## UPDATE 2026-10-04: conventions of the newest production APIs

Taken from `Metcash.AIS.APIOps` `origin/main` (`2681559`, 2026-09-23, CHG0065195), mainly `data-mdmsupplier-v1` and `b2b-iba-directs-upload-v1`, checked against the
other recent b2b-/data- APIs. `ais-code-review/tools/check_apiops.py` enforces what they all share.

* **Folder:** `gen-3/artifacts/apis/<domain>-<name>-v<n>/` with `apiInformation.json`, `policy.xml`, `specification.yaml`, `operations/<op>/policy.xml`.
  `<domain>` is `b2b`, `b2c`, `data`, `enabling`, `corporate`, `fin`...; kebab-case lower case.
* **apiInformation.json:** `path` (e.g. `eis/mdm`), `apiVersion` `v1`, `apiVersionSetId` pointing at a folder in `version sets/` (`versioningScheme: Segment`),
  `protocols: ["https"]`, `subscriptionRequired` set explicitly, `serviceUrl` on the APIM host.
* **API-level policy (inbound), in this order:** `set-variable interfaceId` from the named value `{{<Name>-Interface-Id}}` (value `EAII-nnn`); `operationName` / `stageName`
  variables; `include-fragment set-common-inbound-variables_v1`; `include-fragment validate-json-payload_v1` (or `validate-xml-payload_v1`); body parse and
  `parentObservationId` from the payload `TransactionID`; the `smcMessageHeader` array (CorrelationId); `include-fragment validate-jwt_v1`; business validation that
  fills `exceptionCode`, `statusCode`, `reason`, `exceptionMessage`, `additionalInfo` and calls `return-response response-variable-name="errorMessage"`; then delete the
  inbound `Authorization` header and set `OperationName` and `ParentObservationID` headers for the backend.
* **Operation policy:** `set-backend-service backend-id="..."`, `rewrite-uri` built from a named value (`{{LogicApp-BaseUrlPart}}`), and for a Logic App backend a
  `<retry>` in `<backend>` that retries once when the response lacks `X-Workflow-Executed` (the workflow sets it, see `02-logic-app-pattern.md`), logs with `trace`, and
  turns a final failure into `APIM-REQUEST-BACKEND-FAILURE` with the backend body in `exceptionMessage`.
* **`<on-error>`:** `include-fragment on-error_v2` after setting `smcLogMessage` (v1 is still used by older APIs; new APIs use v2). Fragments are versioned with `_v1`, `_v2` suffixes.
* **Backends:** `backends/<resource>-logic-backend/backendInformation.json`, credentials as query values from named values (`LogicApp-Workflow-API-Version`, `-SP`, `-SV`,
  and a per-workflow `...-wf-sig` secret), `type: Single`, TLS validation on. Dev URLs are committed; **per-environment URLs, interface ids and secrets live in
  `gen-3/tools/parameters/parameters.<env>.yaml`** (`namedValues`, `backends`, `apis`, `versionSets`), published by the `run-publisher-npr` / `run-publisher-prd` pipelines.
* **Named values:** one `<name>-interface-id` per API (`secret: false`), URIs and queue names as named values, secrets referenced from Key Vault. `{{...}}` matches the
  display name, case-insensitively; a referenced name that exists only in the parameters file is fine.
* **Never in a policy:** hard-coded hosts, subscription keys or bearer tokens.
* **Older APIs that do not follow this** (`b2b-creditapplication-v1`, `enabling-notifications-v1`, `data-abnlookup-v1` partly) predate the common fragments; do not copy them.
