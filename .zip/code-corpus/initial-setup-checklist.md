# Initial Setup Checklist — Metcash AIS Skills Hub

One-time setup for a developer's first day (or a new machine). Run through this once; after
that, use the **Daily Start** portal tab / `/daily-start` for the day-to-day check.

---

## 1. Code — clone the repos you'll actually touch

Reuses the real repo mapping already built and verified in
[`code-corpus/index.md`](index.md) — don't maintain a second copy of this list here, it will
drift. Open that file, find the repo(s) for the interface(s) you're working on, and clone with:

```powershell
git clone https://METCASHDevOps@dev.azure.com/METCASHDevOps/Squad%2020/_git/<RepoName> "C:\Users\<you>\source\repos\<RepoName>"
```

If you already have a personal/feature-branch checkout of a repo and don't want to disturb it,
clone a second copy on `main` as `<RepoName>-main` instead (the convention already used for
`Metcash.AIS.Data.Metproducts-main`, `Metcash.AIS.B2C.Datafactory-main` — see
`code-corpus/index.md` for why).

You don't need to clone every repo in that table on day one — just the ones for the
interface(s) you're assigned. `ais-codegen-readiness` will clone/reuse whichever repo a new
interface needs, the first time you run it for that interface.

## 2. Reference documents — already staged, nothing to fetch

The approved TSD corpus (7 interfaces, the design authority `metcash-tsd-generator` reads from)
is already converted and sitting in the repo — no Confluence fetch needed to *read* them:

| What | Where |
|---|---|
| Approved TSDs | `reference-corpus/converted/tsd/` |
| FSDs | `reference-corpus/converted/fsd/` |
| Mapping Manifests | `reference-corpus/converted/manifests/` |
| Real diagram sources | `reference-corpus/source/diagrams/` |

**Known gap, stated explicitly rather than silently missing:** the raw **field-level Mapping**
sheets (distinct from the Mapping *Manifest*) for these 7 original corpus interfaces were never
archived — the corpus only needed the *approved TSD's own text* as the design authority, not a
from-scratch re-derivation, so the raw Mapping was never pulled for them. If you need one for a
specific interface (e.g. to double-check a field-level claim), fetch it on demand via the
Atlassian MCP rather than assuming it's already local. This is only a gap for the original 7 —
every interface generated *after* this point (starting with EAII-529) has its raw Mapping staged
in `tsd-inputs/<EAII-ID>/source/` as part of `metcash-tsd-generator`'s own Step 0.

## 3. Azure / MCP auth — once per machine (or after a long break)

Run `azure-local-auth`'s steps once: `az login --tenant metcash.onmicrosoft.com`, confirm with
`az account show`, then restart the Azure DevOps/Azure MCP servers in VS Code
(`Ctrl+Shift+P` → `MCP: List Servers` → restart). See that skill for the exact commands and for
the "Connected but zero tools" gotcha if a server doesn't actually work afterward.

## 4. From here on — use Daily Start

Once repos are cloned and auth is done, `/daily-start` (or the portal's **Daily Start** tab)
gives you the day-to-day digest: auth status + git status for every repo you already have
cloned under `source/repos/`. It doesn't re-clone anything — that's this checklist's job, done
once.

---

## Growing this list

Every time `ais-codegen-readiness` resolves a **new** repo for an interface not already in
`code-corpus/index.md`'s table, add a row there (not here) — this checklist just points at that
table so the two never disagree with each other.
