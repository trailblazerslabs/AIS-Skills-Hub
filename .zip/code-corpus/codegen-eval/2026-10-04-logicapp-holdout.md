# Logic App codegen: held-out evaluation (2026-10-04)

Question: can `ais-logicapp-codegen` (after it was rewritten from production code, see [`../production-snapshot.md`](../production-snapshot.md)) produce a workspace close to
what is live in production, starting only from the approved TSD?

## Method

| | EAII-514 (Sorted to PE, synchronous HTTP, DB2) | EAII-304 (Liquor Suppliers to EIM, queue + ZIP blob + .NET transform) |
|---|---|---|
| Input | `reference-corpus/converted/tsd/TSD-EAII-514` (+ FSD) | `reference-corpus/converted/tsd/TSD-EAII-304` (+ FSD, mapping) |
| Production answer (held out) | `Metcash.AIS.B2B.RealTimePricing` `main` | `Metcah.AIS.B2B.IBADirects` `main` |
| Shape reference the agent could read | IBADirects (the other archetype) | RealTimePricing (the other archetype) |
| Generator | sub-agent on `claude-fable-5-1`, following the skill steps 1 to 4b | same |

Each agent was told not to read the production repo of its own interface (clone, `git show`, copies). It ran the checker once on its first draft, then fixed what it reported.
Output was then diffed against production with `tools/compare_logicapp.py`. Agent notes are in `e514/` and `e304/` (`skill-feedback.md`, `assumptions.md`, lint output).

**Limit of the test:** the skill text itself was written from these same two production repos, so a good score shows the skill reproduces production from a TSD; it is not proof that it
generalises to an interface the skill has never seen. Only three production Logic App repos pass the standard, so a truly unseen case is not available yet. Re-run this test whenever a new
production Logic App merges to `main`: it becomes the next held-out case.

## Results

| Measure (share of production items the generated code also has) | EAII-514 | EAII-304 |
|---|---|---|
| workflow folders / kind / Try-Catch-Finally scopes | match | match |
| connector operations (trigger, send, blob, function ...) | 80 % | 100 % |
| `connections.<env>.json` connection set | 50 % (no `keyVault`, DB2 named `db2`) | 100 % |
| `appsettings.<env>.json` keys | 47 % (DB2 key casing, no `keyVault_VaultUri`, no concurrency setting) | 100 % |
| parameters | 75 % (procedure parameter named differently) | 100 % |
| SMC variables | 37 % | 81 % |
| SMC stage names | 33 % | 14 % |
| first-pass checker result (the checker as it was) | 0 errors, 0 warnings | 0 errors, 0 warnings |
| checker after this round (stronger rules) on the same output | 2 errors, 9 warnings | 0 errors, 0 warnings |

Reading the numbers: the **skeleton and configuration layout are reproduced** (EAII-304 matches production on every configuration item). Stage names and business variable names differ because they are design
choices; they are not defects. EAII-514, the synchronous flow, is clearly weaker: the skill gave only three lines for HTTP workflows, and the agent had to invent the error and response handling.
Real value differences: the Service Bus namespace (`t1` in production, `t2` in the TSD), the input queue pattern, a trailing slash on the blob endpoint, and in EAII-514 the workflow name and kind
(TSD: `PricingFromPE`, Stateless; production: `GetPricingData`, Stateful).

## Defects the checker missed (found by the agents reading their own output)

* inline `JavaScriptCode` for mapping (production has none), `HasErrors` in an HTTP flow, placeholders (`REPLACE-WITH-...`) in `prd` settings;
* `SetVariable` inside a parallel `Foreach` (a race), a pipeline that still builds a `Function/` project that does not exist;
* runtime defects in the .NET transform (JSON returned base64-wrapped), fixed by the agent after its manual review: **a checker cannot find these; build and unit test the custom code**.

## Fixes made

Skill (`ais-logicapp-codegen/SKILL.md`):
1. **Precedence table** for TSD vs skill vs production (names, Stateful, namespaces `t1`/`t2`, SMC queue per environment, workflow-name tie-break, no placeholders).
2. **Complete synchronous-HTTP skeleton** from two live examples (RealTimePricing, EAII-297 `GetNewSupplierNumber`): variables, Try / Catch / Finally, status handling, `Response` placement and headers, fault body.
3. Queue/file vs HTTP variables and failure handling separated; `HasErrors` is not used in HTTP flows; `SMCGuid` vs `TransactionId` defined.
4. Loops (concurrency, no `SetVariable` in parallel), transformations (expressions or `InvokeFunction`, no inline JavaScript), DB2 connection and stored-procedure action verbatim,
   custom .NET code and the pipeline steps, SMC payload restrictions.
5. App settings and connections split into "always (SMC)" and "only when used"; Terminate wording corrected.

Checker (`tools/check_logicapp.py`): lower-case `kind`, XML namespace URLs and `WEBSITE_*` no longer false positives (found on the other production repos); new rules `LA-02` (warn on Stateless),
`LA-19` (HTTP `Response` header and `StatusCode`), `LA-20` (inline JavaScript), `LA-21` (`SetVariable` in parallel loop), `LA-22` (placeholders; unresolved settings in connections files),
`LA-18` (pipeline workspace name; dotnet steps without `Function/`). Three production repos still pass with 0 errors.

## Still open (not fixed by this round)

* Built-in Blob operation names and parameter keys, and the exact shapes of SMC stage-status and error entries, are inferred from IBADirects only.
* Queue trigger settlement: how the built-in Service Bus trigger completes or abandons a message when the run fails is not documented from production; the TSD for EAII-304 expects retry then dead-letter.
* The paired APIM API and backend for a new Logic App are generated by a different skill; the two should be generated together (see `check_apiops.py`).
* The next run should use EAII-297 (now in the corpus) or a new interface as the held-out case, and the Function App checker should be run over the other production Function Apps (R2W, Store).

## Repeat it

```powershell
# 1. generate with the production repo of the target interface held out (see the prompts in the sub-agent runs)
# 2. gate
python .github\skills\ais-logicapp-codegen\tools\check_logicapp.py <generated>\LogicApp --repo-root <generated>
# 3. diagnose against production
python .github\skills\ais-logicapp-codegen\tools\compare_logicapp.py <generated>\LogicApp <production clone>\<Repo>.Workspace\LogicApp
```
