# Feedback on `ais-logicapp-codegen` (SKILL.md) from generating EAII-304 out of its TSD

Ordered by impact. Line numbers refer to `.github/skills/ais-logicapp-codegen/SKILL.md` as read on 2026-10-04.

## 1. The trigger rule contradicts the TSD's retry / dead-letter design, and the skill's own wording assumes peek-lock

* Skill, Trigger Patterns: `"operationId": "receiveQueueMessages"` and Step 2.7: "end with `Terminate` ... when `HasErrors` is true **and the source file
  was not already moved to the error folder** ... so a handled failure does not redeliver the message".
* `receiveQueueMessages` settles the message when the run starts, so nothing is ever redelivered, abandoned or dead-lettered, whatever the run does.
  The sentence only makes sense for a peek-lock trigger (`peekLockQueueMessages` + `completeMessage` / `abandonMessage`).
* The EAII-304 TSD requires peek-lock behaviour in five places (PlantUML "Complete Message" / "Abandon Message", 5.1.3.1, every row of 5.1.6.3.3,
  5.1.7.1 "failed translation messages can be replayed from Service Bus dead-letter queue").
* Missing rule: when a TSD asks for abandon / DLQ / replay, should the generator use the peek-lock trigger, or keep `receiveQueueMessages` and record
  a deviation? I kept the skill's trigger and recorded the conflict (assumption 7). The skill should say which, and explain the real redelivery semantics.

## 2. No precedence rule between the TSD and the skill's fixed values, and some fixed values are wrong for this TSD

The skill hard-codes values that the TSD also specifies, without saying which one wins:

* Step 4: "`ServiceBus_FullyQualifiedNamespace` (`t1-met-<env>-ae-sb-001...`)": the TSD says `t2-met-{npr/prd}-ae-sb001`.
* Step 4: "`ServiceBus_FullyQualifiedNamespace_SMC` (`t2-met-<env>-ae-sb-001...`)": production (RealTimePricing) uses `t2-met-npr-ae-sb-001`
  for dev/sit/uat and `t2-met-prd-ae-sb-001` for prd, i.e. the namespace tier (`npr`/`prd`), not `<env>`. Read literally, `<env>` = `dev` gives a namespace that does not exist.
* Step 2.1: `"kind": "Stateful"`; the TSD says the workflows are Stateless (3.2, 6.5).
* Step 2.5: retry count 3; the FSD says 10 (the TSD says 3, so no conflict here, but the skill does not say whether TSD/FSD retry counts override it).
* Step 4: `SMC_QueueName` (`smc.endobservation.<env>.sbq`); RealTimePricing production SIT uses `smc.endobservation.uat.sbq`.

Suggested rule: "Resource names, queue names, folders and retry counts come from the TSD; the skill's values are the default when the TSD is
silent; a TSD value that breaks a production rule (e.g. Stateless) is a recorded deviation." Also fix the `<env>` vs tier wording.

## 3. Custom code (InvokeFunction) is mentioned but not specified, and the description says to use another skill for it

* Description: "DO NOT USE FOR: ... Function App transformation code (use ais-functionapp-codegen)". Step 2 tree: "`lib/custom/<FunctionName>/` and
  `../Function/` ← only when the workflow calls InvokeFunction (custom .NET code)". `ais-functionapp-codegen` is for standalone isolated Function Apps
  (3-project layout), not Logic Apps custom code, so the two instructions point in different directions for exactly this TSD ("Inline Azure Function").
* Nothing in the skill gives: the `InvokeFunction` action JSON (`functionName`, `parameters`), how outputs are read (`body('<action>')?['<Property>']`),
  the csproj (`LogicAppFolderToPublish` with `Microsoft.Azure.Workflows.Webjobs.Sdk` 1.2.0, `TriggerPublishOnBuild`), the target framework, or the
  `[WorkflowActionTrigger]` signature.
* It also does not say how `lib/custom` reaches the deployment package: the production `LogicApp/.gitignore` (which Step 2 says to copy) ignores `lib`,
  and the production pipeline (RealTimePricing, the one available) has no build step. Following the skill literally deploys a workflow whose
  `InvokeFunction` cannot find its function. I added a `UseDotNet@2` + `dotnet build` step and a guard; the skill should state this.
* "`lib/custom/<FunctionName>/`" reads as something to write by hand; it is build output and should not be committed.

## 4. The failure-branch pattern is described as a naming convention, not as control flow

Step 2.4: "the action, then on `FAILED` `Set_HasErrors_true_on_<Action>_failure` → ... → `Append_SMC_Stage_Status_<Stage>_Failed`" and
"File flows also copy the source blob to the error folder and delete it on failure". Unanswered when building it:

* Is the copy-to-error / delete inside every failure branch (with its own failure branch), or once, after all branches? I did it once, in an `If`
  at the end of `Try` gated on `HasErrors`; that `If` has to `runAfter` every top-level failure branch on all four states, or it can read
  `HasErrors` before a parallel branch sets it. The skill should say this.
* Logical failures (no JSON in the ZIP, the function returning `Status = Failed`) have no failed action to hang a branch on. Logic Apps has no
  "throw" action, so the success path must be nested in `If` actions. One sentence and an example would save a lot of guessing.
* It does not explain that a scope whose failures are all handled ends **Succeeded**, so `Catch` does not run and the only signal is
  `HasErrors`. That is why the `Terminate` rule in `Finally` exists; without it the rule looks arbitrary.
* Only `FAILED` is mentioned; the TSD test list expects `TIMEDOUT` too ("fails or times out and HasErrors is set to true"). I used both.
* When two actions in one stage fail, `Append_SMC_Stage_Status_<Stage>_Failed` is no longer a unique name. Give the suffix rule
  (I used `..._<Stage>_Failed_on_<Action>`).

## 5. Variables the skill uses but never defines

* Step 2.1 lists "`triggerBody`" as an initialiser with no type or value. Is it a variable called `triggerBody`, a copy of the trigger body, or the
  decoded `contentData`? I used a string variable `triggerBody` = `@{triggerBody()?['contentData']}`.
* Step 2.3 uses `"ParentObservationID": "@variables('TransactionId')"` and Step 2.7 uses `variables('TransactionId')`, but `TransactionId` is not in the
  initialiser list and there is no rule for where it comes from in a Service Bus / Event Grid flow (messageId? blob metadata? the upload's Transaction ID?).
* The `SMCGuid` expression in `02-logic-app-pattern.md` reads an HTTP header (`triggerOutputs()?['headers']?['ParentObservationID']`), which does
  not exist on a Service Bus message. The skill should give the queue-flow expression.
* No shape is given for the `SMCStagesStatus` entries (only action names) or the `SMCErrors` entries. I copied `{StageID, Status}` from
  RealTimePricing and used an object for errors because the TSD test "Verify SMC error payload integrity" expects action name, message, status and code.

## 6. Built-in Blob connector operations are not documented

The file-flow rules ("extract", "read blob content and metadata", "copy to archive then delete") name no `operationId`s or parameter keys. I took
them from Microsoft Learn: `readBlob` (`containerName`, `blobName`, `inferContentType`; returns `content`, `properties`, `metadata`),
`extractArchiveFromBlobPath` (`sourceContainerName`, `sourceBlobName`, `destinationContainerName`, `destinationFolderPath`; returns `extractedBlobs`),
`copyBlob` (`sourceContainerName`, `sourceBlobName`, `destinationContainerName`, `destinationBlobName`, `overrideIfExists`), `deleteBlob`, `uploadBlob`.
Note: `getBlobMetadata` does **not** return custom metadata, which is what this TSD needs; `readBlob` (or `blobExists`) does. A short table in the skill would prevent this.
Also Step 3 writes the service provider id as `/serviceProviders/azureBlob`; the designer writes `/serviceProviders/AzureBlob` (the checker accepts both).

## 7. TSD content the skill gave no rule for

* Parsing an **Event Grid BlobCreated** message on the queue (blob path from `subject`, container check, single event vs array).
* **Blob-metadata enrichment** (SupplierID / DocumentType / TransactionID set by the upload API) and where those values go in SMC (headers? correlation?).
* **Temporary storage** for decompression ("extract to temporary storage", 5.1.2.1 step 5) and **cleanup of temporary files** (step 9): where, and
  whether cleanup also runs after a failure.
* **Trigger file** (`.PSV.trg`) generation, and output-file encoding / line separator (MAP: carriage return).
* **Folder case-sensitivity**: the TSD writes both `IBADirects/ToEIM` and `IBADirects/toeim`. Step 4 says folders are "`<Interface>/<stage>`" but not
  where the stage names come from or that blob paths are case-sensitive. There is no `paramInputFolderPath` although the input folder is part of the design.
* **Container name**: Step 4 requires `BlobStorage_Container` but gives no rule; the TSD only says "ALM container" in a diagram.
* **Error-code catalogue** (IBADIRECTS-ERR-00x) and how codes map into `SMCErrors` / `ErrorMessage`.
* **Trigger concurrency** (the FSD's legacy `MaxSessions=1`): keep it, or remove it?
* **RBAC** needed by the generated connections (the TSD's table omits Service Bus Data Sender for the SMC send).
* Things that belong to other repos (APIM policies, Event Grid subscription, lifecycle rules, GoAnywhere). A line saying "out of scope for this skill, hand to X" would help.

## 8. Smaller points

* Line 16: "check `outputs/<InterfaceID>/status.md` ... See `ais-interface-status`": that skill is not in the AGENTS.md catalogue.
* Line 47 (Required Inputs) and the Step 1 table name EAII-304's own production workflow as the reference for every queue/file flow, and line 78 uses its
  name (`LiquorSuppliersToEIM`) as the example. For a new interface that is fine, but there is no rule for deriving the workflow name from a TSD, and the
  TSD diagram here labels the workflow `IBADirectsQueueTrigger`.
* `code-corpus/index.md` still says IBADirects is "README-only, no code yet", contradicting `production-snapshot.md`.
* Step 2.3's JSON omits `EventType` (RealTimePricing sends `"EventType": "StandardLogicApp Http Trigger"`); say whether it is required and what a queue flow sends.
* Step 2.3 places `Start_Observation` first in `Try` but does not say whether a failed start must stop the business processing (RealTimePricing continues; I continued).
* Step 4b: "fix warnings or justify them in `assumptions.md`", while Step 5 says to write `outputs/<InterfaceID>/assumptions.md` (fine). Step 2 says "never into `outputs/`" for code; consistent but easy to misread.

## 9. Checker (`tools/check_logicapp.py`) gaps noticed while reading it

* The first pass scored 0 errors / 0 warnings although a manual review then found four runtime defects (base64 content passed to the transform,
  an `if()` whose untaken branch would throw, conditions reading actions that may never have run). Step 4b's "0 errors required" can read as
  "done"; the skill should say the check only covers the production shape.

* It does not check that `runAfter` targets exist in the same scope, that referenced variables are initialised, or that `InvokeFunction` targets an
  existing function. I ran my own structural check for these.
* App-setting coverage (LA-14) only looks at `appsetting()` in `workflow.json`. Connection files also reference app settings
  (`ServiceBus_FullyQualifiedNamespace`, `AzureBlob_Endpoint`, `keyVault_VaultUri`); a missing one would pass.
* LA-09 (retry) is only a warning, although Step 2.5 says "Retry on every built-in connector call". It also skips `ApiManagement` actions.
* `check_repo` checks only the PRD gating. It cannot see a missing custom-code build step (point 3), which would break the deployment.
