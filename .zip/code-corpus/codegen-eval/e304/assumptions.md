# EAII-304 Logic App codegen: assumptions and TSD gaps

Interface: EAII-304 IBA Directs ALM Orders, Liquor Suppliers to EIM (translation phase).
Design source: `reference-corpus/converted/tsd/TSD-EAII-304/TSD-EAII-304.md` (treated as approved; no codegen-readiness
questionnaire exists for this test), with FSD-EAII-304 and MAP-EAII-304 for the mapping detail.
Shape reference: production `Metcash.AIS.B2B.RealTimePricing` `origin/main` (bff1728) plus the rules in `ais-logicapp-codegen`.
The IBADirects production repo was not read.

## What was generated

| Path | What |
|---|---|
| `Metcash.AIS.B2B.IBADirects.Workspace/LogicApp/LiquorSuppliersToEIM/workflow.json` | The Translation Orchestrator workflow (Service Bus trigger, 133 actions) |
| `.../LogicApp/AppSettings/appsettings.{dev,sit,uat,prd}.json` | Every environment value |
| `.../LogicApp/Connections/connections.{dev,sit,uat,prd}.json`, `connections.json` | `apiManagementOperationSMC`, `serviceBus`, `serviceBusSMC`, `azureBlob`, `keyVault` (Managed Identity) |
| `.../LogicApp/Parameters/parameters.{dev,sit,uat,prd}.json`, `parameters.json` | `param*` values |
| `.../LogicApp/host.json`, `workflow-designtime/host.json`, `.funcignore`, `.gitignore` | Copied unchanged from RealTimePricing production |
| `.../Function/` (`PSVTransformer.cs`, `PsvTransformService.cs`, `PsvTransformResult.cs`, `.csproj`) | Logic Apps custom code (.NET 8) for the "PSV Converter (Inline Azure Function)", function name `TransformToPSV` |
| `.../Metcash.AIS.B2B.IBADirects.Workspace.sln`, `.code-workspace` | Same layout as RealTimePricing |
| `pipelines/gen3ibadirectsladep.yml`, `pipelines/templates/*.yml` | Adapted from RealTimePricing; adds a .NET build of the custom code |

Verified locally: the custom-code project builds (`dotnet build -c Release`, scratch copy) and generates
`lib/custom/TransformToPSV/function.json` whose input schema (`sourceJson`, `sourceFileName`, `lineSeparator`) and output schema
(`Status`, `PsvContent`, `PsvFileName`, `RecordCount`, `ErrorCode`, `ErrorMessage`) match the workflow. The mapping logic was run
against the MAP-EAII-304 Coopers sample record and reproduces the target row exactly
(`1046145|507361|COOPERS STOUT BTL 375ML|...|2026/06/09|4.0|36.0|234.8`), plus CUB-style string decimals (`16.00` -> `16.0`,
`144.000` -> `144.0`) and the failure cases from the TSD test list (missing / empty DirectsData, non-object record, malformed JSON).

## Process assumptions

1. **No codegen-readiness questionnaire.** The skill's pre-condition ("Stop. Ask the user to run `ais-codegen-readiness`") was waived by the
   test instructions. `outputs/EAII-304/status.md` was neither read nor updated (output restricted to `gen_eval/e304`).
2. **Repo / workspace name** `Metcash.AIS.B2B.IBADirects` / `Metcash.AIS.B2B.IBADirects.Workspace`: the TSD names no repository (component
   list says only "AIS Repository"); the name follows the B2B repo convention and the TSD component names (`t3-met-b2b-ibadirects-*`).
3. **Workflow name `LiquorSuppliersToEIM`**: PascalCase of the TSD/interface title "Liquor Suppliers to EIM". The TSD process-flow diagram
   (images/07.png) labels the workflow icon `IBADirectsQueueTrigger`; that is the alternative if the team prefers the diagram label.
4. **One workflow only.** The TSD's upload phase is APIM + the existing EAII-367 `UploadBlob` function (not in this repo). TSD 5.1.6.3.6
   lists an "Upload Orchestrator Logic App", which contradicts 5.1.2.1 / 5.1.3 / the sequence diagram (APIM calls UploadBlob directly); it was not generated.
5. **`kind: Stateful`** although TSD 3.2 and 6.5 say "Stateless": the skill requires Stateful (both production workflows are Stateful, and a run
   history is needed for the per-action failure audit).
6. **Logic App resource name** `t3-met-b2b-ibadirects-{env}-ae-logic` (TSD 5.1.6.1, 6.5, RBAC table). TSD 6.5's SENS subnet table says
   `t3-met-ibadirects-{env}-ae-logic`. The name is not in code: the pipeline variable group supplies `logicAppName`.

## Trigger and messaging

7. **Trigger = built-in `receiveQueueMessages` with `splitOn`** (skill rule). The TSD (5.1.3.1, 5.1.6.3.3, PlantUML) expects peek-lock
   semantics: "Complete Message" on success, "Abandon Message" on failure, retries, then dead-letter, and 5.1.7.1 says failed messages
   "can be replayed from Service Bus dead-letter queue". With `receiveQueueMessages` the message is settled when the run starts, so there is
   no abandon / redelivery / DLQ path. Replacement behaviour: a handled failure moves the source ZIP to `IBADirects/error` (reprocess by copying it
   back to `IBADirects/in`, which raises a new BlobCreated event); an unhandled failure ends the run Failed (Terminate 500) with the details in SMC.
   **This is a TSD deviation to confirm with the Solution Architect.**
8. **Message content** is an Event Grid `BlobCreated` event (Event Grid schema, one event per Service Bus message, which is how Event Grid delivers
   to a queue); the built-in trigger's `contentData` is assumed to be the event JSON text or object (verify on the first dev run). The blob path is taken from `subject` (`/blobServices/default/containers/<c>/blobs/<path>`). The TSD says the message carries
   "Supplier ID, timestamp, and Transaction ID": Event Grid cannot add those, so they are read from the **blob metadata** written by UploadBlob
   (keys `SupplierID`, `DocumentType`, `TransactionID`, case variants handled; TSD test "Verify metadata enrichment during processing").
   `SupplierID` falls back to the file-name prefix (`{SupplierId}_{yyyyMMddHHmmss}.zip`).
9. **Service Bus namespace** `t2-met-{npr|prd}-ae-sb-001.servicebus.windows.net` for both the input queue and SMC. The TSD writes
   `t2-met-{npr/prd}-ae-sb001` (no hyphen); the hyphenated FQDN is the one production uses for SMC (RealTimePricing appsettings), so the TSD
   spelling was taken as a typo. The skill's rule (`ServiceBus_FullyQualifiedNamespace` = `t1-met-<env>-ae-sb-001...`) was **not** followed because the TSD names the namespace.
10. **Input queue** `b2b.ibadirectstoeim.sbq-{dv1|st1|ut1|prd}` (TSD: "{env} - dv1, st1, ut1 and prd").
11. **Event Grid subscription** `evt-t3b2b{env}aesta01-alm-ibadirects-in-create-sbq-{env}-ae` is infrastructure (not in this repo). It must filter
    `Microsoft.Storage.BlobCreated` and `subjectBeginsWith /blobServices/default/containers/alm/blobs/IBADirects/in/`; otherwise the workflow's own
    writes to `extract/`, `toeim/`, `archive/` and `error/` would re-trigger it.
12. **Concurrency**: no trigger concurrency limit was set (the TSD treats the legacy `MaxSessions=1` as a known issue to remove; volume is ~8 files/month).

## Storage

13. **Container `alm`** (`BlobStorage_Container`): from the PlantUML ("t3b2b{env}aesta01 ALM container") and the Event Grid subscription name
    (`-alm-ibadirects-in-`). The GoAnywhere table (5.1.4.1) shows `resource:azureblob://t3b2but1aesta01-ibadirects/...`, which could mean a container
    named `ibadirects`. Confirm before deployment.
14. **Storage account** `t3b2b{dv1|st1|ut1|prd}aesta01`, endpoint `https://<account>.blob.core.windows.net` (`AzureBlob_Endpoint`).
15. **Output folder `IBADirects/toeim` (lower case).** TSD 5.1.2.1, 5.1.3.2 and 8.5 write `IBADirects/ToEIM`; TSD 5.1.4.1 (GoAnywhere source connection,
    the actual consumer) and the FSD write `IBADirects/toeim`. Blob paths are case-sensitive; the consumer's spelling was used. It is a parameter
    (`paramOutputFolderPath`), so it can be changed per environment without a code change.
16. **Temporary storage** (TSD: "extracts the source JSON file to temporary storage", location not given): blob folder
    `IBADirects/extract/<workflow run id>/` (`paramExtractFolderPath` + run id), written by the built-in `extractArchiveFromBlobPath`. Stage 1.7 deletes
    every extracted file, also after a failure.
17. **ZIP content**: one JSON source file at the root of the ZIP is expected; the first `*.json` entry is used, other entries are ignored (and deleted in
    cleanup). A ZIP with no JSON entry is a decompression failure (IBADIRECTS-ERR-003). The extracted file is read with `inferContentType = true` so the
    connector returns it as JSON text rather than base64. Entries in sub-folders of the ZIP are not supported (their names are reduced to the last path segment).
18. **"Move" = copy then delete** (skill rule) for archive and error. Archive and error copies keep the source ZIP name and overwrite an existing blob of the same name.
19. If the archive copy succeeded but deleting the source from `in/` failed, the file is **not** also copied to `error/` (it is already archived); the run
    ends Failed so the leftover is visible.
20. Retention (archive 90 days, error 30 days) is a storage lifecycle rule, not workspace code; not generated.

## Output and mapping (custom code)

21. **"Inline Azure Function"** = Logic Apps Standard custom code (.NET 8, `InvokeFunction`), project in `Workspace/Function`, class `PSVTransformer`,
    function `TransformToPSV` (the TSD test cases name `TransformToPSV` and expect it to "return a failed status"). Pure logic is in
    `PsvTransformService` so it can be unit tested without the host. No separate Function App is created.
22. **Business failure vs exception**: invalid/empty JSON, missing or empty `DirectsData`, non-object record, non-integer `PACKSIZE`, non-decimal
    amount -> `Status = "Failed"`, `ErrorCode = IBADIRECTS-ERR-002`; the workflow routes the ZIP to `error/` (TSD test "Verify transformation business failure handling").
    A runtime failure of the action itself takes the same failure branch.
23. **PSV file name** `{ExtractedJsonNameWithoutExtension}.PSV` (mapping: derived from the extracted file, not the ZIP).
24. **Trigger file** `{...}.PSV.trg` with content `This is a Trigger File` is always written after the PSV. Sources: TSD PlantUML ("Upload PSV.trg"),
    TSD 8.5.1.1 ("PSV and trigger files"), MAP-EAII-304. TSD 5.1.2.1 step 7 lists only the PSV, and GoAnywhere polls `*.psv`, so the trigger file may be
    unnecessary; remove `Upload_trigger_file_to_output` if confirmed.
25. **Line separator**: carriage return (MAP: "each row is terminated by a carriage return"), header and every data row terminated. Configurable
    (`paramPSVLineSeparator` = `CR` | `LF` | `CRLF`) because CR-only is unusual and the FSD lists "exact PSV format" as open.
26. **Decimals** (`INVCASES`, `INVLITRES`, `INVVALUE`): trailing zeros stripped, at least one decimal place kept (`16.00` -> `16.0`, `234.80` -> `234.8`);
    an integer input such as `5` is written `5.0` (the mapping shows no integer example).
27. **PACKSIZE** cast to integer; a fractional value fails the transform (the legacy `xsd:int` cast would also fail).
28. String fields are passed through unchanged (no trim, no case change, no escaping). A `|` inside a value would shift columns; legacy behaviour unknown.
    A missing field gives an empty column; a field that is an object or array fails the record.
29. JSON root: `DirectsData` at the root or under `DirectsElement` (property names case-insensitive); a single record serialised as an object is accepted.
30. No range validation (e.g. the INVLITRES source/target range discrepancy noted in the mapping): business validation is out of scope (TSD 2.2).
31. PSV is uploaded as text (UTF-8, the built-in upload default); the legacy encoding is not documented.

## Error handling and SMC

32. **Error codes**: IBADIRECTS-ERR-003 decompression / no JSON in ZIP, IBADIRECTS-ERR-002 transformation, IBADIRECTS-ERR-004 archive, `500` for
    source read, extracted-file read, PSV/trigger upload and error-folder moves (the TSD Exceptions table's code column), IBADIRECTS-ERR-UNHANDLED
    for an invalid trigger message and for the Catch scope. IBADIRECTS-ERR-001 (size) belongs to APIM.
33. **Retry**: `fixed`, 3 times, `PT5S` on every built-in connector call (TSD: "Retry the operation up to 3 times"; the FSD's 10 retries describe the legacy
    platform). `InvokeFunction` has no retry policy (the transform is deterministic).
34. **Run outcome**: handled failure with the file in `error/` -> run Succeeded, details in SMC (skill rule). Not moved to `error/`, unhandled error
    (Catch), or the SMC end message not sent -> `Terminate` Failed, code 500 (TSD test "Verify SMC message send failure handling").
35. `Start_Observation` failing does not stop the file processing (next action runs after it in any end state), so an SMC outage does not leave files unprocessed.
36. **IDs**: `SMCGuid = guid()` (a Service Bus message has no `ParentObservationID` header). `TransactionId` = Service Bus `messageId` (the Event Grid
    event id), else `guid()`; it is the `ParentObservationID` and the `CorrelationId`. The upload-phase Transaction ID (blob metadata) is sent as header
    `UploadTransactionID`. Whether SMC should chain the translation observation to the upload observation through `ParentObservationID` instead needs the SMC team.
37. **SMCStagesStatus entry** `{ StageID, Status: "LiquorSuppliersToEIM_<Stage>_<STARTED|COMPLETED|FAILED> <utc>" }`, the shape RealTimePricing production
    uses (the skill does not give one). **SMCErrors entry** `{ ActionName, Status, ErrorCode, StatusCode, ErrorMessage }`, per TSD test "Verify SMC error
    payload integrity" (failed action name, message, status, code).
38. **Message headers**: TransactionId, UploadTransactionID, SupplierID, DocumentType, SourceFileName, PSVFileName, RecordCount, WorkflowRunId (TSD
    reference keys / correlation properties: Transaction ID, Supplier ID).
39. `paramSMCEnableObservation` = `Yes` in every environment.

## Configuration

40. SMC values (`APIM_*_SMC` = `t3-met-core-<env>-ae1-apim`, `WORKFLOWS_SUBSCRIPTION_ID_SMC`, SMC Key Vault `t3enabling<code>ae1kv01`) are the
    shared-platform values from RealTimePricing production. TSD 6.5 spells APIM `t3-met-core-{env}-ae-apim`; production `ae1` was used.
41. `SMC_QueueName` for SIT = `smc.endobservation.sit.sbq` (skill rule `smc.endobservation.<env>.sbq`); RealTimePricing production SIT points at
    `smc.endobservation.uat.sbq`. Confirm which queue SIT SMC listens on.
42. `keyVault_VaultUri` = `t3b2b<code>ae1kv01` (TSD 6.3; TSD 5.1.6.1 writes `t3b2b{env}aekv01`). The `keyVault` connection is declared because
    the skill lists it, but the workflow uses no Key Vault action; the TSD RBAC table grants the Logic App access only to `t3enabling{env}aekv01`.
43. **RBAC gap in the TSD**: the Logic App also needs *Azure Service Bus Data Sender* on the SMC namespace (it sends the end observation) and the
    storage role must cover `extract/`, `toeim/`, `archive/` and `error/` writes and deletes (Storage Blob Data Contributor does).
44. No `ppd` environment (the skill: only if the repo already has it).
45. Built-in blob connector id written as `/serviceProviders/AzureBlob` (the id the designer writes); the skill text shows `azureBlob`.
46. No app setting was added for .NET 8 custom code; verify on the first dev deployment that the Logic App host loads `lib/custom/net8`.

## Pipeline

47. `gen3ibadirectsladep.yml` is RealTimePricing's pipeline with the workspace folder and variable groups renamed
    (`t3-ais_b2b_ibadirects_{dv1,st1,ut1,prd}`, assumed to hold `subscriptionId`, `resourceGroupName` = `t3-met-ais-{env}-ae1-rsg-b2b`, `logicAppName`),
    the same SPN service connections, the PRD stage gated on `refs/heads/main` and `deployPRD`.
48. Added to the Build stage: `UseDotNet@2` (8.x) and `dotnet build` of the custom-code project (publishes to `LogicApp/lib/custom`, which `.gitignore`
    excludes from source control), a guard that `lib/custom/TransformToPSV/function.json` exists, and removal of `Function/` from the package.
49. The two templates are copied unchanged.

## TSD content outside this workspace (not generated)

APIM API `eis/ibadirects/v1/submitOrder` and its policies (APIOps repo), Event Grid subscription, Service Bus queue, storage account and lifecycle
rules (`metcash-ais-infrastructure` Bicep), GoAnywhere jobs, App Insights, unit test cases (`ais-unit-test-cases`).

## Checker results

* `lint-first-pass.txt`: 0 errors, 0 warnings. `lint-final.txt`: 0 errors, 0 warnings (also 0/0 with `--strict`). No warnings to justify.
* The checker does not check runtime semantics, so after the first pass the workflow was reviewed by hand and with a small structural script
  (runAfter targets in the same scope, unique action names, declared variables, defined parameters, referenced actions exist). Four runtime
  robustness changes were made between the first and the final run (none was reported by the checker):
  1. `Read_extracted_JSON` uses `inferContentType = true` (with `false` the JSON could come back as base64 content and break the transform).
  2. `Parse_Event_Grid_message` is a plain `json()`; the earlier `if(startsWith(...,'['), first(json(...)), json(...))` would fail if both branches were evaluated.
  3. The move-to-error condition reads a `SourceArchived` variable instead of `actions('Copy_source_to_archive')`, an action nested in an `If` branch that may never run.
  4. Cleanup and the JSON filter read an `ExtractedBlobs` variable instead of the body of an action that is skipped when an earlier step fails.
