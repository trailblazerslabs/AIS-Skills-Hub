# EAII-514 Realtime Pricing (Sorted to PE): Logic App codegen assumptions

Design source: `reference-corpus/converted/tsd/TSD-EAII-514/TSD-EAII-514.md` (approved TSD, treated as the approved design because no
codegen-readiness questionnaire exists for this test). The FSD was used for business rules only. The production reference for shapes was
`Metcah.AIS.B2B.IBADirects` `origin/main` (20ef9a5, EAII-304), read with git. The held-out repo `Metcash.AIS.B2B.RealTimePricing` was not read.

Checker: `check_logicapp.py`: first pass 0 errors / 0 warnings; final 0 / 0 (`--strict` also 0 / 0).

## A. Naming and identity

| # | Item | Value used | Source / reasoning |
|---|---|---|---|
| A1 | Repo / workspace folder | `Metcash.AIS.B2B.RealTimePricing` / `Metcash.AIS.B2B.RealTimePricing.Workspace` | **The TSD does not name a repository.** I inferred it from the Logic App name `t3-met-b2b-realtimepricing-{env}-ae-logic` (TSD 5.1.6.1, 6.5) and the IBADirects convention `Metcash.AIS.B2B.<Name>.Workspace`. The test brief named the same repo. |
| A2 | Workflow name | `GetPricingData` | **The TSD contradicts itself.** §6.5 "Workflow Details" says `Workflow Name: PricingFromPE`. The APIM backend section (§6.3) says `GetPricingData` four times: the displayName `B2B-RealTimePricing-Logic-App-GetPricingData-Workflow`, the description, the per-workflow SAS named value `b2b-realtimepricing-logic-app-getpricingdata-workflow-sig`, and "the `GetPricingData` workflow is executed". The SAS `sig` is tied to the workflow name, so a workflow called anything else would break the APIM backend as designed. I chose `GetPricingData`. **Raise this with the TSD author.** |
| A3 | Logic App resource per env | `t3-met-b2b-realtimepricing-{dv1,st1,ut1,prd}-ae-logic` | TSD §6.5 SENS subnet table |
| A4 | Pipeline file | `pipelines/gen3realtimepricingladep.yml` | Skill pattern `gen3<name>ladep.yml`; `<name>` = `realtimepricing` |
| A5 | ADO variable groups | `t3-ais_b2b_realtimepricing_{dv1,st1,ut1,prd}` | **The TSD is silent.** I followed the IBADirects pattern `t3-ais_b2b_<name>_<env>`. These groups must provide `subscriptionId` and `resourceGroupName` (TSD: `t3-met-ais-{env}-ae1-rsg-b2b`). |
| A6 | Service connections / agent pools | `SPN-t3-met-ais-{env}`, `Metcash-ALZ-VMSS-Windows-NON-PROD` / `-PROD` | Copied unchanged from IBADirects (same AIS subscription per the TSD) |
| A7 | Interface parameter | `paramEAII514InterfaceId` = `EAII-514` | Skill Step 4 |

## B. Workflow behaviour

| # | Decision | Reasoning |
|---|---|---|
| B1 | `"kind": "Stateful"` | **Conflicts with the TSD.** §6.5 says "Workflow Type: Stateless" twice. The skill (rule 1) and `02-logic-app-pattern.md` say every production workflow is Stateful, so I applied the skill. Stateless would lower latency and storage cost at 1,000 calls/min. **This needs a decision from the architect.** |
| B2 | HTTP `Request` trigger (POST) with a JSON schema for `PriceDataRequest` | TSD 5.1.2.1 step 3; FSD §4.3 field list. Logic Apps does not enforce the schema at runtime: validation stays in APIM, as the TSD says. |
| B3 | No validation, outage-flag or auth logic in the workflow | TSD: APIM does OAuth, schema and business validation and the `dbOutageFlag` check (503) before forwarding. §6.2 component text says the Logic App "validates input", but 5.1.2.1 puts all validation in APIM, so I followed 5.1.2.1. |
| B4 | Field transformation is an **inline JavaScript action** (`Transform_Request_Fields`, `JavaScriptCode`), run once per request for all products | TSD: "Inline Function", "map action", exception EAII514-010 "Azure Inline Function". There is no `InvokeFunction` and no .NET project, so no `lib/custom` or `Function/` folder. Tested locally with Node (padding, date, zero products, bad date). |
| B5 | Pad character for XPCMPN, XPDIVN, XPDPTN, XPWHSN is a **space**; XPCUSN and XPITMN pad with **zeros** | **The TSD is silent** on the pad character for the first four ("left-pad to 3 characters"); it says "with zeros" only for XPCUSN and XPITMN. **Confirm against the TIBCO `tib:pad-front` calls / mapping sheet.** |
| B6 | XPITMN: trim, then if numeric, go through BigInt and back to string (drops leading zeros), then zero-pad to 10. A non-numeric product is passed padded so the SP can return a product-level error | **The TSD is silent** on non-numeric product numbers. TIBCO's `long` conversion would probably have faulted (HTTP 500). |
| B7 | XPSFLG constant `"0"`; the request field `StateFlag` is ignored | TSD 5.1.2.1 says constant `"0"`; the FSD lists `StateFlag` as a request field. |
| B8 | XPDTES sent as a number (`20261004`) | TSD: "numeric YYYYMMDD"; FSD: DECIMAL |
| B9 | **First product called on its own (circuit breaker), the rest in a `Foreach` with concurrency 10** | **The TSD contradicts itself.** Step 5 says "Concurrency = 1, sequential"; step 7 says the first product is sequential and the rest run in parallel; Known Issues says parallel "subject to confirmation". I implemented step 7 (the most specific). **Concurrency 10 is my choice** (the limit must be a literal). It must be confirmed with the AS/400 team (connection pool ceiling 1,000; target 1,000 calls/min × up to 20 products). Results are re-ordered by `Index`, so `PriceData[]` keeps the request order. |
| B10 | Failure of the first product call is reported as **EAII514-011** (connectivity), a later product call as **EAII514-016** (JDBC/SQL); transform as -010, response build as -019, unhandled as -099 | TSD 5.1.6.3.3. The DB2 connector error cannot reliably tell -011, -012, -013, -014, -015 and -017 apart, so the two codes are approximations. |
| B11 | No `SetVariable` inside the parallel loop: failed products go to `FailedProducts` (append) and are promoted to `HasErrors`/`ErrorMessage`/`ErrorCode` after the loop | Avoids race conditions on shared variables in a parallel `Foreach`. **This deviates from the skill's 4-step failure branch** inside the loop only. |
| B12 | Product-level SP error (`XOERROR = "Y"`) → `ErrorMsg` = trimmed `XOEMSG`; the request still succeeds | TSD EAII514-018 |
| B13 | Null or `xsi:nil` SP outputs are omitted; `PromotionalWholesaleCost`, `WholesaleCost` and `UnitPromotionalSale` are never emitted; values are emitted as trimmed strings | TSD 5.1.2.1 steps 10 and 11; FSD types the response fields as String |
| B14 | **The DB2 stored-procedure output shape is unknown**, so `Build_PriceDataResponse` searches the output for an object containing `XOERROR`/`XOTTLP` (any key case), or a `[{name,value}]` list | No production evidence for this interface could be read (held out) and the Microsoft reference only says "Output: array". **Verify against a real dev run** and simplify once the shape is known. |
| B15 | Zero products → no DB2 call, HTTP 200 with the echoed context and `PriceData: []` | TC-015 / FSD T10 |
| B16 | Echoed request fields are returned as received; `Product` is echoed trimmed | TSD step 11. The trim was changed after the first lint pass (it was a behaviour fix, not a lint fix). |
| B17 | Error response: HTTP 500 with `{exceptionCode, statusCode, reason, exceptionMessage, transactionId}` | **The TSD does not define the fault body** ("structured fault responses"). I used the field names of the APIM error convention in `03-apim-apiops-pattern.md` so APIM can pass it through or map it. |
| B18 | `Response` is always sent from `Finally` with `X-Workflow-Executed: Completed`; status from the `StatusCode` variable (initialised 500, set 200 only on success) | Skill rule 7 / HTTP rules. There is no `Terminate`, so a handled failure shows as a Succeeded run that returned 500 (the skill says HTTP workflows end with `Response`). |
| B19 | `Finally` order: build fault (if `HasErrors`) → correlation and headers → stage 100 → `Response` → SMC end message | The Response goes before the Service Bus send to keep caller latency low (`02-logic-app-pattern.md`: "returns the response, and sends the SMC message"). |
| B20 | `Finally` runs after `Catch` only, on all four states | RealTimePricing shape described in the skill / checker ("chained after Catch") |
| B21 | Inline-code limits: Standard Node 16 runtime, 5 s duration; both snippets are well inside | MS Learn "Run JavaScript in workflows" |

## C. SMC

| # | Decision | Reasoning |
|---|---|---|
| C1 | `SMCGuid` = `coalesce(headers.ParentObservationID, guid())` (the exact expression in `02-logic-app-pattern.md`); `TransactionId` = `SMCGuid` | TSD: one UUID per request, propagated. **The skill is ambiguous** here (see feedback): the result is that `ParentObservationID` equals `ObservationID` in the StartObservation call. |
| C2 | StartObservation is always called and passes `EnableObservation`; the end-of-observation Service Bus message is sent **only when `paramSMCEnableObservation` = `Yes`** (`Check_SMC_Logging_Enabled`) | TSD: "when SMC logging is enabled" for the end and error events; `02-logic-app-pattern.md` says RealTimePricing gates the send. The skill's rule 3 shows the start call without a gate, so I kept it ungated. |
| C3 | `paramSMCEnableObservation` = `Yes` in every environment | IBADirects production value. The TSD says logging is "on demand"; the FSD says AIS "should always log". |
| C4 | SMC stages: 1.0 Request Received, 1.1 Request Transformation, 1.2 AS400 Connection Check, 1.3 AS400 Pricing, 1.4 Response Construction, 100 Observation Complete | Derived from TSD 5.1.2.1; **the TSD has no SMC stage table** |
| C5 | Message headers: Company, Pillar, CustomerId, PriceDate, ProductCount (initialised from the request) plus TransactionId, WorkflowRunId, ProcessingStatus, DurationMs (appended in `Finally`); correlation property `CorrelationId` = TransactionId | TSD 5.1.7.1 Reference Keys; 5.1.2.1 steps 4 and 12 (duration, product count, status) |
| C6 | `MessageBody` is the **request** only; the pricing response is never sent to SMC | TSD 6.3.1: no full pricing payloads in SMC in production |
| C7 | Email to IntegrationSupport@metcash.com is not in the workflow | TSD 5.1.7.1: SMC notification type "Email on error" (SMC onboarding config) |

## D. Configuration values

| # | Setting | Value | Source |
|---|---|---|---|
| D1 | `APIM_BaseUrl_SMC`, `APIM_ResourceGroup_SMC`, `APIM_ServiceName_SMC` | `t3-met-core-{dev,sit,uat,prd}-ae1-apim` / `-ae1-rsg-apim` | TSD §6.5 APIM table (`-ae1-`). TSD §5.1.6.1 writes `t3-met-core-{env}-ae-apim` (no `1`); I followed the detailed table and production. |
| D2 | `ServiceBus_FullyQualifiedNamespace_SMC` | `t2-met-npr-ae-sb-001...` for dev/sit/uat, `t2-met-prd-ae-sb-001...` for prd | **Production IBADirects value.** The skill text says `t2-met-<env>-ae-sb-001`, but there is no per-env namespace in production. |
| D3 | `SMC_QueueName` | `smc.endobservation.{dev,sit,uat,prd}.sbq` | Skill Step 4. **Production IBADirects SIT points at `...uat.sbq`**, which looks like a defect there; I did not copy it. Confirm the `sit` queue exists. |
| D4 | `SMC_API_Subscription_Key` | Key Vault reference to `t3enabling{dv1,st1,ut1,prd}ae1kv01/secrets/SMC-API-Subscription-Key` | Skill and TSD platform KV. The stray space after `SecretUri=` in production was removed. |
| D5 | `WORKFLOWS_SUBSCRIPTION_ID_SMC` | IBADirects production values (non-prod `3b30bdee-...`, prd `acacb233-...`) | Same shared APIM; these are subscription IDs, not secrets. **The TSD is silent.** |
| D6 | `DB2_ServerName`, `DB2_Database` | **Placeholders** `REPLACE-WITH-AS400-<ENV>-LPAR-HOST` / `-RDB-NAME` | **The TSD only says "DV1 → AS/400 Dev LPAR" etc.** and gives no host or RDB names. These must be filled in before deployment. |
| D7 | `DB2_PortNumber` | `446` | TSD §7.1 (port 446, the DRDA port) |
| D8 | `DB2_DefaultSchema` | `IDSPNDUR1` | TSD §8.4 |
| D9 | `DB2_UserName`, `DB2_Password` | Key Vault references to `t3b2b{env}ae1kv01/secrets/as400-username` and `as400-password` | TSD §8.4 (secret names) and §6.3 (application KV) |
| D10 | Not generated: `ServiceBus_FullyQualifiedNamespace`, `ServiceBus_InputQueue`, `keyVault_VaultUri`, `AzureBlob_Endpoint`, `BlobStorage_Container`; no `serviceBus`, `azureBlob` or `keyVault` connections | The workflow has no input queue, blob or Key Vault action; secrets come in as app-setting KV references. The skill lists these settings as "always", but they would be unused here. |
| D11 | Stored procedure | `paramCX40K6BProcedureName` = `IDSPNDUR1.CX40K6B` (a parameter, same in all envs) | TSD §8.4. Kept out of the workflow as a literal (skill rule 8). |

## E. Connector and runtime points to verify in dev

1. **DB2 built-in connection keys.** I used `serverName`, `portNumber`, `database`, `userName`, `password` and `defaultSchema`, with no
   `parameterSetName`, under service provider `/serviceProviders/db2`. MS Learn lists the fields but not their JSON keys. Create the connection once in the VS Code designer and align the keys.
   I did not use the connector's `connectionString` option, even though the TSD says the "JDBC connection string" is in Key Vault, because the skill and checker forbid connection strings in connection files.
2. **Stored procedure action.** I used `operationId: storedProcedure` with `procedureName` and `procedureParameters` (an object of the eight XP* inputs). MS Learn types `procedureParameters` as a string; confirm whether it must be serialised and whether OUT parameters have to be declared.
3. **Built-in DB2 vs gateway.** The TSD mentions an "On-Premises Data Gateway"; the built-in connector does not use one (direct TCP over VNet integration). I chose the built-in connector, which matches the skill ("DB2 in RealTimePricing") and TSD §6.2 ("VNet Integration for outbound connectivity").
4. **30-second query timeout.** Not configured. The skill says to copy `host.json` unchanged, and the DB2 action has no documented timeout input. Decide whether to add a host setting or an action `limit`.
5. **Retry policy vs synchronous timeout.** The skill requires `fixed / 3 / PT5S` on every built-in connector call, which I applied to both DB2 calls. Worst case per call: 4 × 30 s query timeout + 15 s. Twenty products can therefore exceed the synchronous Request timeout of a Standard Logic App and APIM's backend timeout. The TSD's own maximum is already 600 s. **This needs an NFR decision** (shorter retry or timeout for this interface).
6. **Inline JavaScript** adds a Node worker hop (twice per request). If load testing at 1,000 calls/min does not meet the < 2 s target, the transform could be rewritten as WDL expressions.
7. **TSD gaps with no workflow impact:** Azure App Configuration (TSD §7.1) has no stated use; App Insights RBAC is infrastructure; the APIM API and backend (`t3-met-b2b-realtimepricing-logic-app`, `dbOutageFlag` named value) belong in APIOps and were not generated here.

## F. Pipeline

`gen3realtimepricingladep.yml` is the IBADirects pipeline with the workspace folder, variable groups and Logic App names changed, and the
`UseDotNet` / `dotnet build` steps removed (no `Function/` folder; that step would fail on the missing path). The PRD stage keeps
`condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))` and the `deployPRD` parameter. Both templates are copied unchanged.
