# Feedback on `ais-logicapp-codegen` SKILL.md (from generating EAII-514 from its TSD)

The test generated a synchronous HTTP to DB2 workflow with the RealTimePricing reference held out, using IBADirects (queue/blob) as the only readable reference.
The checker printed 0/0 on the first pass. That says more about how much the checker misses (section 3) than about the quality of the generated code.

## 1. Most important

1. **The skill leaks the held-out answer and depends on a reference the user may not have.** Step 1 names the exact production answer for this interface
   ("`Metcash.AIS.B2B.RealTimePricing` → `.../LogicApp/GetPricingData/workflow.json` (EAII-514...)"). `02-logic-app-pattern.md`, which the skill links, then describes RealTimePricing's
   `Finally` (`Check_SMC_Logging_Enabled_`), its DB2 `@appsetting('DB2_*')` settings and the `SMCGuid` expression. For a genuinely new synchronous interface
   (or an evaluation like this one), the HTTP rules in the skill are only a few lines: "Return a `Response` on success and failure with the header
   `X-Workflow-Executed: Completed`" and "HTTP flows return the real status code from a `StatusCode` variable". Nothing describes the full shape of an HTTP workflow
   (where `Response` sits, how `HasErrors` and `StatusCode` interact, what the fault body looks like, whether `Catch` sets the status). **Add a complete
   synchronous-HTTP skeleton to the skill itself**, in the same detail as the queue/file rules 4, 6 and 7.

2. **Rules 4 to 7 are written for queue/file flows, and the HTTP exceptions are scattered or missing.** Examples:
   - Rule 1: "(queue/file workflows also `HasErrors`, `ErrorMessage`)". But rule 4's failure branch (`Set_HasErrors_true_on_<Action>_failure` →
     `Set_ErrorMessage_from_<Action>_failure` → ...) needs both variables in every workflow, and an HTTP flow needs them to choose a 500. Is `HasErrors` required for HTTP or not?
   - Rule 6 (`Catch`): "`Set_HasErrors_true_on_unhandled_error` (`HasErrors` = true)" assumes `HasErrors` exists. It says nothing about setting `StatusCode` = 500 for HTTP.
   - Rule 7: "Finally (runAfter `Catch`, plus `Try` for queue/file flows ...)". This is the only place the HTTP `Finally` dependency is stated, and only by implication.
   - With a per-action failure branch, the failure is *handled*, so `Try` succeeds and `Catch` never runs. For HTTP that means the workflow must turn
     `HasErrors` into a 500 itself. The skill never says so; I had to design `Check_HasErrors_Build_Fault_Response` myself.

3. **The skill gives no rule for loops, and in particular parallel `Foreach`.** The TSD asks for "first product sequential (circuit breaker), remaining in parallel".
   Rule 4's mandatory failure branch uses `SetVariable` (`Set_HasErrors_true...`, `Set_ErrorMessage_from...`), which races inside a parallel `Foreach`. Nothing
   says what to do there (I appended to an array and promoted it after the loop), what concurrency to use, or how to keep result order. Add a "per-item calls
   in a loop" rule.

4. **The DB2 connector is mentioned but never specified.** "Connectors with no managed identity (DB2 in RealTimePricing) still take **every** value from `@appsetting()`,
   with the password a Key Vault reference." There is no connection JSON (service provider id, parameter keys, `parameterSetName` or not), no stored-procedure
   action shape (`operationId`, `procedureName`/`procedureParameters`), and no output shape. I had to guess the keys from MS Learn, which lists only display names.
   The checker also rejects any `connectionString`, while the TSD says the "AS/400 JDBC connection string" lives in Key Vault. Give the DB2 connection and action JSON verbatim, as the skill already does for Service Bus and APIM.

5. **"Always" app settings and connections do not fit an HTTP flow.** Step 4: "`AppSettings/appsettings.<env>.json` — always: ... `ServiceBus_FullyQualifiedNamespace`,
   `ServiceBus_InputQueue` ..., `keyVault_VaultUri`, `AzureBlob_Endpoint`, `BlobStorage_Container`". Step 3 lists `serviceBus`, `azureBlob` and `keyVault` connections the same way.
   An HTTP to DB2 flow has no input queue or blob. "Always" pushes the generator to invent unused queue and container names; I left them out. Split the settings
   into "always (SMC)" and "only when the workflow uses X". The same applies to "Always: ... then the folder parameters (`paramExtractFolderPath`...)".

## 2. Unclear or wrong statements

- **`"kind": "Stateful"` vs a TSD that says Stateless.** Rule 1 states Stateful as fact; the checker accepts both (`if d.get("kind") not in ("Stateful", "Stateless")`).
  The EAII-514 TSD says "Workflow Type: Stateless" twice. The skill should say which one wins when an approved TSD disagrees (TSD, skill, or ask), and why production chose Stateful.
- **Workflow name source.** Step 2: "folder name = workflow name"; the pre-condition says the workflow name "must come from the approved questionnaire/summary, never invented".
  When the TSD names two different workflows (`PricingFromPE` in §6.5, `GetPricingData` in the APIM backend and SAS named value), the skill gives no tie-break.
  Suggested rule: the APIM backend / SAS named value wins, because the SAS signature is bound to the workflow name.
- **SMC namespace.** "`ServiceBus_FullyQualifiedNamespace_SMC` (`t2-met-<env>-ae-sb-001...`)": production IBADirects uses `t2-met-npr-ae-sb-001` for dev, sit and uat.
  `<env>` reads as dev/sit/uat. Write `t2-met-{npr|prd}-ae-sb-001.servicebus.windows.net`.
- **SMC queue in SIT.** The skill says `smc.endobservation.<env>.sbq`, but production IBADirects SIT uses `smc.endobservation.uat.sbq`, and its SIT `keyVault_VaultUri` and
  `AzureBlob_Endpoint` point at `ut1`. Either the skill or production is wrong; the skill should say which, so generators don't copy a defect.
- **The `SMCGuid` / `ParentObservationID` guidance contradicts itself.** Rule 3's body uses `"ParentObservationID": "@variables('TransactionId')"` and `"ObservationID": "@variables('SMCGuid')"`.
  `02-logic-app-pattern.md` says to source `SMCGuid` from the inbound `ParentObservationID` header ("Reuse this exact ... expression"). For HTTP flows APIM sends that header from the
  payload `TransactionID` (`03-apim-apiops-pattern.md`). Followed literally, `ObservationID` == `ParentObservationID`. Define `TransactionId` and `SMCGuid` explicitly for HTTP.
- **SMC flag gating.** Rule 3 calls StartObservation unconditionally (passing `EnableObservation`). `02-logic-app-pattern.md` says RealTimePricing sends the end message only
  "when logging is enabled (`Check_SMC_Logging_Enabled_`)". The skill does not say whether to gate the start, the end, or both.
- **Retry policy for synchronous flows.** Rule 5: "Retry on every built-in connector call: fixed, 3, PT5S". For a synchronous API with a 30 s query timeout and up to 20 calls,
  this can exceed the HTTP/APIM timeout (the TSD target is < 2 s). There should be an HTTP-specific retry or timeout rule.
- **Rule 7 order for HTTP.** It says "HTTP workflows end with `Response`", but the pattern doc says RealTimePricing returns the response *before* sending the SMC message. "End with" is ambiguous.
- **Pre-condition table and paths.** "A TSD (`tsd/<InterfaceID>/*.md` exists)": the TSD actually lives at `reference-corpus/converted/tsd/TSD-EAII-514/TSD-EAII-514.md`. The path pattern
  does not match the repo layout (`TSD-` prefix, `reference-corpus/converted/`).
- **Step 5 vs Step 2 output location.** Step 5: "Write `outputs/<InterfaceID>/assumptions.md`"; Step 4b: "fix warnings or justify them in `assumptions.md`" (no path). The status-file banner at the top
  (`outputs/<InterfaceID>/status.md`, skill `ais-interface-status`) refers to a skill not listed in AGENTS.md.
- **Required Inputs say "Sourced from the Design Intake Questionnaire"** even when the TSD path applies (codegen-readiness questionnaire). The "Stop and ask if any input is missing"
  rule does not help an unattended run; give an assume-and-log fallback.
- **The `host.json` rule** ("copy host.json from production unchanged") leaves nowhere to put interface needs such as a DB2 query timeout or HTTP run limits.
- **The pipeline is "copy the production ones",** but the IBADirects pipeline builds a `Function/` .NET project (`Get-ChildItem "$(workspaceFolder)/Function"`). Copied unchanged
  to a workspace without `Function/`, that step fails. The skill should say to remove the dotnet steps when there is no custom code. It also doesn't say how to name the variable groups (`t3-ais_b2b_<name>_<env>`)
  or that `logicAppName` must change.
- **The production repo name is misspelled** (`Metcah.AIS.B2B.IBADirects`). The skill relies on the reader noticing the "(sic)" in the snapshot; put the exact clone path in the table.

## 3. What the checker does not catch (it passed my first draft at 0/0)

- **`Response` placement and headers.** Any `Response` anywhere passes; there is no check for `X-Workflow-Executed`, for `statusCode` coming from a variable, or for `Response` being reached on the `Catch` path.
- **SetVariable inside a parallel `Foreach`.** Not detected.
- **Failure branches.** It does not check that every ServiceProvider or JavaScriptCode action has one (rule 4's "production signature" is not enforced).
- **Unknown connection keys.** It accepts any key in the DB2 connection, and accepts placeholder values in app settings (`REPLACE-WITH-...`), including in `prd`.
- **App setting coverage.** It only checks that appsettings used in workflow.json exist; it does not check that `@appsetting()` references inside `connections.json` are defined (e.g. `DB2_*`).
- **SMC stage names.** It does not check that `Append_SMC_Stage_Status_<id>_*` ids match the declared `SMCStages`.
- **`kind`.** Stateless passes, contradicting rule 1.
- **Pipeline contents.** Only `refs/heads/main` and `deployPRD` are checked; a pipeline still pointing at the IBADirects workspace or Logic App names would pass.

## 4. TSD content the skill gave me no rule for

| TSD content | Gap in the skill |
|---|---|
| "Inline Function" for field transformation (exception EAII514-010) | No rule for inline JavaScript (`JavaScriptCode`) vs WDL expressions vs `InvokeFunction`; only `InvokeFunction` (.NET) is mentioned |
| Field padding / trimming rules (`tib:pad-front`, `tib:right`) | No guidance on reproducing TIBCO XPath functions, or on pad characters when the TSD omits them |
| First call sequential (circuit breaker), rest parallel; result aggregation in order | No loop, concurrency or aggregation rule |
| Interface exception codes (EAII514-001 to -099) | No rule on where exception codes go (SMC error text? response body? both?) |
| Structured fault response (HTTP 500) | No fault-body contract for Logic App responses |
| `xsi:nil` outputs omitted from the response | No rule for null handling in response mapping |
| SMC Reference Keys / Correlation Properties table (TSD 5.1.7.1) | The skill says "one message header per key ... (business keys, file name, workflow run id)" but does not map them from the TSD's SMC onboarding table |
| "Do not log full pricing payloads in SMC in production" (TSD 6.3.1) | Rule 3 / 7 always send `MessageBody = string(triggerBody())`; no rule for payload-restricted interfaces (here the request is allowed, the response is not) |
| APIM `dbOutageFlag`, OAuth, SAS backend | Out of scope for this skill, but the skill should point to the APIOps skill for the paired API/backend so the two are generated together |
| Query timeout 30 s, connection pool 1,000, environment → LPAR mapping without host names | No rule for where DB connection tuning lives, or for how to mark unresolved host values (I used `REPLACE-WITH-...` placeholders) |
| Azure App Configuration listed as a dependency | The skill never mentions App Configuration |
| Stateless workflow type requested for performance | See section 2 |
