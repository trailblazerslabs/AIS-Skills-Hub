# EAII-529 (PE to Stibo): end-to-end Function App generation and production check (2026-10-05)

Question: from a TSD with no production code behind it, can `ais-functionapp-codegen` produce a Function that builds, passes its tests and follows the shape of the Function Apps that are live in production?

## Method

| | |
|---|---|
| Input | the Copilot-generated test-run TSD `tsd/EAII-529` (clone `Metcash.AIS.Shared.Copilot.Prompts-EAII-529`, branch `feature/EAII-529-tsd`, read-only), plus its FSD, mapping, gap register and questionnaire |
| Target | `Metcash.AIS.Data.Metproducts` clone on `feature/EAII-529-pe-to-stibo`, at production `main` (`4b0e8d7`); code left as **uncommitted local edits** (not pushed) |
| Generator | sub-agent on `claude-fable-5-1` following the skill, with the production Function Apps as the style reference |
| Production check | the code that already runs in production is the reference: Metproducts and MDMSupplierInfo `main` |

There is no production code for EAII-529, so the comparison is against production **conventions and behaviour**, not against an answer. The agent's report was **re-verified independently** (build, tests, checker, git diff, TSD traceability); one of its claims was refined by that check (see "host.json").

## Results (independently re-run)

| Check | Result |
|---|---|
| Build `dotnet build` (.NET 10) | succeeds, 0 errors; no warning from any new file (the existing nullable warnings are production's) |
| Tests | **461 passed, 1 failed** of 462. Baseline on production `main` is 317 passed, 1 failed; the failure is the same live-network `IndiPIMTokenServiceLiveApiTests`. All 317 baseline tests still pass, 144 new tests added |
| Checker `check_functionapp.py` | 0 errors on the first pass and at the end (the stricter rules added after the run also give 0 errors) |
| TSD exception codes | **15 of 15** implemented, none invented. `EAII529-008` (telemetry write failed, a warning) has no test |
| TSD test cases | **29 of 29** referenced by a test (`TC001_...`) |
| Change footprint | 12 modified existing files, 34 new files; additive |
| Secrets and endpoints | none hard-coded; secrets are Key Vault references; open Stibo values are empty settings; the function ships `AzureWebJobs.PEProductDataToStibo.Disabled = true` |
| Production function shape (new rules `FN-10..12`) | matches both production Function Apps: thin class, `%Topic%` / `%Subscription%` placeholders defined in AppSettings and all four settings files, `Connection = "ServiceBusConnection"`, `SmcInterfaceIdEAII529`, executor delegation, `nameof(<Class>)` |

## The part that needs a human review: three shared production files changed

| File | Change | Risk |
|---|---|---|
| `Models/ProcessingResult.cs` | new `CompleteMessageOnFailure` flag (default `false`) and `DataError(...)` factory | none for existing callers |
| `Executor/ServiceBusFunctionExecutor.cs` | the message is completed when the success flag or the new flag is set | the executor is used by every interface; the default keeps today's dead-lettering; a test asserts it |
| `Services/SmcService.cs` | one display-name entry | none |

The reason is real: TSD step 12 needs "SMC Failed but message completed" for a data error (the file already moved to `error/`), and nothing in the repo could do that. It should still go through the team's normal review of shared code.

## Deviations from the TSD (all recorded in `e529/assumptions.md`)

SMC cannot record "Non-Success" (duplicates are Success with a warning stage); only `TransactionID` and one item key reach SMC; retry is an explicit loop, not Polly (no shared Polly component exists); other 4xx than 400/422 are technical failures;
the unexpected-exception code is `EAII529-099` rather than the executor's `500`; the shared library was changed (above) although the TSD said "reused unchanged".

## Findings and what changed in the skill

From the agent's `skill-feedback.md` and my review (full text in `e529/`):

1. **No "data error" outcome**, and an "additive only" rule that contradicted the skill's own steps: reworded with the list of extension points; the `DataError` pattern is documented.
2. **No shape for a file-staged, multi-call interface:** parser and renderer placement, blob lifecycle, duplicate delivery, resume markers, per-run token, outcome mapping, settings-driven retry with `TimeProvider`, session-enabled triggers, SMC limits, stage numbering: new "Step 3b".
3. **Retry template wrong for TSDs that override it** (3 x 2 s hard-coded, and "other failure: retry" would retry a 404): replaced by a status matrix.
4. **Settings files, open items, disabled-until-cut-over** and the test fixture glob: added to Step 4.
5. **Broken links** to `references/function-patterns.md` and `shared-types.md` removed.
6. **Checker:** new rules `FN-10` (trigger placeholders, connection name, interface-id source, `nameof`), `FN-11` and `FN-12` (settings coverage in every environment and in AppSettings), `FN-08` test pairing, and `FN-07` accepting the 5.x host.json key. Calibrated: Metproducts 0 errors.

### host.json: a production finding, verified against Microsoft Learn

Production `host.json` sets `extensions.serviceBus.messageHandlerOptions.autoComplete = false`. That is the Service Bus extension **4.x** schema. The apps run extension 5.x (`Worker.Extensions.ServiceBus` 5.16.0), whose key is `extensions.serviceBus.autoCompleteMessages` (default `true`).
Microsoft's guidance for `ServiceBusMessageActions` is `AutoCompleteMessages = false` on the trigger attribute. I tried that attribute on the new function: **it does not compile on 5.16.0** (it needs a newer package), so I reverted it. Consequence: the production setting is most likely ignored, and the executor's explicit settlement is what works.
This is an existing platform condition, not caused by EAII-529. It needs a platform decision (upgrade the package, set the attribute and the 5.x key), not an edit inside an interface change. The pattern doc and the skill now say so.

## Open items that block deployment (owners from the gap register)

G14 Stibo base URL, token URL, client id, secret name and timeout (Stibo platform owner); G7 firewall path to Stibo (network team); G16 cut-over order so the TIBCO poller and GoAnywhere do not both deliver (MFT team / Integration Platform); G5 which fields the legacy flow sent (Vladimir Gurieff / Stibo team).
Also: the session-enabled subscription, the Event Grid filter on `in/`, the container and permissions, the Key Vault secret, and the TSD is unsigned. Integration tests against a real Stibo test endpoint cannot run until G14 is resolved.

## Not covered by this run

No deployment, no runtime test against Service Bus or Stibo, no ADO PR. TC-021 (session ordering) and TC-022 (the event filter) are infrastructure behaviours that unit tests can only assert by design. The next evaluation should run the same skill on a second interface and re-run this checker on the other production Function Apps (R2W, Store, Finance).
