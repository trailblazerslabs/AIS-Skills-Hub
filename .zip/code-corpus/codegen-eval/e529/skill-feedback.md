# Feedback on `ais-functionapp-codegen` (SKILL.md), `code-corpus/patterns/01-function-app-pattern.md` and `code-corpus/unit-tests/index.md`

Context: EAII-529 (PE product flat file -> six STEP XML payloads -> three Stibo endpoints), generated into
Metproducts `main`. The skill and pattern doc were accurate about the composition (3-project layout, thin
function, shared executor, typed clients, Key Vault references) and the checker passed first time. The gaps
below are where the TSD needed something the skill has no rule for, or where the skill's wording contradicted
what had to be done. Ordered by impact.

## 1. The settlement rule has no "data error" outcome (highest impact)

> "Settle the message explicitly: `CompleteMessageAsync` on success/skip, `DeadLetterMessageAsync` on any failure" (pattern doc)
> "Never put try/catch, telemetry, SMC logging, or message completion/dead-lettering logic in the Function class itself" / "Reuse the existing executor; do not write a new one." (SKILL.md Step 3)

The TSD (5.1.2.1 step 12, decision 7) needs a third outcome: **SMC Failed but message completed** (the service has
already moved the file to `error/`; a replay can never succeed). With the executor as-is that is impossible
without changing shared code, and the skill forbids both a new executor and settlement logic in the function.
I added `ProcessingResult.CompleteMessageOnFailure` + `ProcessingResult.DataError(...)` and a 3-line branch in the
executor. Suggest: document this pattern in the skill (and in the pattern doc's executor section) so the next
file-based interface does not have to invent it, and add an executor test for it in the baseline.

## 2. "Additive overlays - never modify existing code" contradicts what the skill itself asks for

> "Functions are **additive overlays** - never modify existing code, only add new classes and methods" (SKILL.md intro)

versus Step 4 "Append to the *existing* `Program.cs`", the AppSettings rule "add properties to it", and what
EAII-529 actually required: the ProcessingResult/executor change above, one entry in SmcService's
`FunctionDisplayNames` map (otherwise SMC shows "PEProduct Data To Stibo Completed"), the test csproj (see 9) and
the per-environment settings files. Suggest rewording to "extend shared files additively, without changing the
behaviour of existing interfaces, and prove it with the baseline test count", and list the known extension points
(AppSettings, Program.cs, settings files, SmcService display names, ProcessingResult, test csproj fixture globs).

## 3. The service shape assumes one XML blob -> one POST

> "2. Download source payload from blob; ... 3. Transform ... 4. Retry loop ... around the outbound call ... 5. Success path -> ProcessingResult.Success(itemNumber, outputBlobUrl)" (SKILL.md Step 3)
> "Input payload schema or sample XML/JSON" (Required Inputs)

No rule for: a flat-file (pipe-delimited) source and where its parser/renderers go; several ordered calls per
message; partial failure and resume (blob metadata marker); file lifecycle (`in/` -> `archive/` / `error/`);
duplicate delivery (blob no longer in `in/`). `IBlobService` has only `DownloadXmlAsync` and `UploadOutputAsync` -
no exists/metadata/move - so a new `IBlobFileLifecycleService` had to be designed from scratch. Suggest a second
service template for the "file-staged, multi-call" shape (it is also the B/D archetype's Function part).

## 4. Retry constants are hard-coded and the status matrix is too thin

> "Retry loop (`MaxRetries = 3`, `RetryDelay = 2s`) ... `HttpStatusCode.BadRequest` (or other known non-retryable status) -> return `ProcessingResult.Failure(...)` immediately ... other failure -> log "Retrying" and loop" (SKILL.md)

The TSD overrides to 3 x 5 s (FSD contract) and makes them configurable; the skill gives no rule for a per-interface
override or for configuring them. The matrix the TSD needed is richer: 401/403 -> discard token, retry once,
not counted as an attempt; 408 and 5xx transient; network vs timeout exhausted -> different codes; 400/422 data error
vs other 4xx (404/415/429) technical. Note also that "other failure -> retry" in the skill would retry a 404/415,
which TSD 4.5.1 forbids. The sibling tests wait the real 2 s delays; the skill gives no guidance on testing delays
(`TimeProvider` + `Task.Delay(delay, timeProvider)` made the 3 x 5 s assertable in milliseconds).

## 5. Token handling: the shared `TokenService` is the wrong default for a per-run token

The skill says nothing about tokens. The repo's shared `TokenService` is a singleton with a cross-invocation cache
and a 300 s pre-refresh buffer; TSD 5.1.3.2 requires "the token is not shared with other invocations". Also,
in production `Program.cs` `AddHttpClient<TokenService>()` + `AddSingleton<ITokenService, TokenService>()` means
the singleton is not built by the typed-client factory (captive dependency) - worth a warning in the skill's
"register it as a typed client" rule (Step 4). Also missing: how to detect an unresolved Key Vault reference
(the literal `@Microsoft.KeyVault(...)` stays in the setting when the identity lost access - TSD TC-027).

## 6. No guidance for session-enabled triggers, and the `autoComplete` claim needs re-checking

> "**`host.json` disables `autoComplete`** specifically so this executor is the single place that ever settles a message." (pattern doc)
> checker FN-07: `'"autoComplete"' not in t ... messageHandlerOptions.autoComplete=false`

The function template has no `IsSessionsEnabled`, and nothing covers sessions (ordering, `maxConcurrentSessions`,
session settlement, lock renewal vs long retry chains - TSD limitation 9). Separately: `messageHandlerOptions.autoComplete`
is the Service Bus extension **4.x** host.json schema; extension 5.x (the host side here is 5.13.5) reads
`extensions.serviceBus.autoCompleteMessages`. Production may only work because explicit settlement happens before
the host's auto-complete. Please verify, and if confirmed fix the pattern doc, the checker rule (accept or require
`autoCompleteMessages: false`), and consider the trigger-level `AutoCompleteMessages = false` available in newer
worker extensions.

## 7. Exception codes and the "rethrow" rule conflict with TSD exception tables

> "3. Transform; on failure, log a `LogMessage` and rethrow (let the executor's catch handle it)" (SKILL.md)
> `ProcessingResult.Failure(string message, string code = "500", ...)`; executor catch sets `exceptionCode = "500"`

TSDs define `EAIInnn-nnn` codes, including a catch-all (EAII529-099). Rethrowing gives SMC the code "500" and the
full `ex.ToString()` as ExceptionMessage (also against the "raw exception text kept out of SMC" production change the
pattern doc mentions). Suggest: a rule that the service maps every outcome to the TSD code (data error via the
transform exception, unexpected via a catch-all returning `Failure(code-099)` + `TrackException`).

## 8. SMC has only Success/Failure and one business key

TSD 5.1.6.3.1 needs a "Non-Success" (warning) observation for duplicates and HDR/TRL warnings, and reference keys
TransactionID, FileName, RecordType. `SmcService` derives the status from "is errorMessage empty" and only carries
CorrelationId + ItemNumber. The skill should say so, so the TSD author and the developer know what is achievable
without a shared-contract change (I recorded it as deviation D2/D4 and put the file name in ItemNumber).

## 9. Unit-test guidance misses non-XML fixtures and the TSD test-case naming

> "Sample payloads are realistic, inline C# 11 raw string literals ... fixture *folders* ... are reserved for larger/parameterized cases." (unit-tests/index.md)

The test csproj only copies `Fixtures\**\*.xml`, so flat-file fixtures are silently absent at run time until a
`*.txt` include is added - not mentioned anywhere. The unit-test doc also asks for "two test classes per interface";
a TSD with 29 test cases plus parser/renderer/token/HTTP/blob units needed ten. Suggest: "name tests after the TSD
5.x.10 test cases (TC-nnn) and split by component", and list which TSD cases are infrastructure-only (TC-021 session
ordering, TC-022 event filter) and need an integration test rather than a unit test.

## 10. Settings files and open items are not covered by Step 4

The skill's Step 4 covers `Program.cs` only. Nothing on: the four `pipelines/appsettings/{env}.local.settings.json`
files; `AzureWebJobs.<Function>.Disabled` for a function that must ship disabled until cut-over (TSD 9.2); how to
represent an open item (key present, value empty - and making numeric settings `int?` so an empty value binds instead
of throwing); that `SmcInterfaceIdEAIInnn` appears only in `dev` in production; that `merge-app-settings.yml` only
adds/updates and never removes keys. The skill's checker FN-06 accepts empty values, which is right - say so.

## 11. Pre-condition and output-location instructions did not fit this run

> "**Stop.** Ask the user to run `ais-codegen-readiness` and approve it first" / "check `outputs/<InterfaceID>/status.md` first" / "Step 5 - Write `outputs/<InterfaceID>/assumptions.md`"

No codegen-readiness questionnaire existed; the TSD + approved intake questionnaire carried the same facts (repo,
branch, resource names). The skill should accept "approved TSD with resolved repo/resource names" as satisfying the
pre-condition, and let the caller choose where assumptions are written.

## 12. Smaller points

- The References section links `references/function-patterns.md` and `references/shared-types.md`; neither file exists in the skill folder.
- Checker FN-05 inspects only top-level `Services/*.cs`; helper classes must go in a sub-folder (or be static) to avoid a false "no interface" error. Documenting this avoids interface-for-everything noise.
- The skill's `HealthCheck` pattern ("one consolidated HealthCheck that probes every dependency") gives no rule for a dependency whose URL is still open (adding it would flip the whole app to "Degraded").
- "Log a `LogMessage` with a `StageID` for every meaningful processing stage" - good, but no numbering convention for multi-call runs (I used `4.{type}{call}`); a convention would make SMC timelines comparable across interfaces.

## What the TSD needed that the skill gave no rule for (checklist)

Session-enabled trigger and ordering; data error vs technical disposition; file lifecycle (archive/error moves);
resume after partial failure (blob metadata); duplicate delivery; ordered multi-endpoint delivery; per-interface
retry override and configurable retry; 401/403 one-time token refresh; per-run token lifetime; Key Vault reference
failure; per-call HTTP timeout configuration; TSD exception-code taxonomy incl. catch-all; flat-file parsing and
XML rendering placement; SMC warning status and extra reference keys; function disabled until cut-over;
representing open items in settings; lock-renewal risk for long retry chains; payload-logging prohibition
overriding `EnablePayloadDiagnosticLogging`.
