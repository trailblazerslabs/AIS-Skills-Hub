# EAII-529 PE Product Data (PE to Stibo) - assumptions, decisions, deviations, open items

Generated code: `C:\Users\jagae\source\repos\Metcash.AIS.Data.Metproducts-main`, branch `feature/EAII-529-pe-to-stibo`,
uncommitted local edits. Design source: TSD `Technical Specification - EAII-529 - PE to Stibo.md` (test-run TSD, approval
checklist not signed), FSD, Mapping MAP-EAII-529, Manifest, walkthrough, gap register, intake questionnaire.

## 1. What was built

| Layer | File | Purpose |
|---|---|---|
| Function | `FunctionApp/Metcash.AIS.Data.Metproducts/Functions/PEProductDataToStibo.cs` | Thin Service Bus trigger, **session-enabled** (`IsSessionsEnabled = true`), delegates to `IServiceBusFunctionExecutor.ExecuteAsync` with `SmcInterfaceIdEAII529` |
| Service | `Common/Services/PEProductDataToStiboService.cs` (+ `Interfaces/IPEProductDataToStiboService.cs`) | Orchestration: duplicate check, download, resume marker, parse/render, one token, ordered delivery with retry, archive/error, SMC stage log |
| Transform | `Common/Services/PeProductDataTransformService.cs` (+ interface), `Common/Services/PeProductData/PeProductFileParser.cs`, `StepXmlRenderer.cs` | Pipe-delimited parser with HDR/TRL validation; one STEP-ProductInformation renderer per record type |
| Stibo | `Common/Services/StiboTokenService.cs`, `StiboHttpService.cs` (+ interfaces) | Per-run OAuth client-credentials token; typed HttpClient for the three integration endpoints |
| Blob | `Common/Services/BlobFileLifecycleService.cs` (+ interface), `Common/Models/StagedBlobFile.cs` | Download with metadata (404 = null), metadata write, move (in/ to archive/ or error/) with the managed identity `BlobServiceClient` |
| Models | `Common/Models/PeProductData/*`, `Common/Models/Stibo/StiboModels.cs` | Record classes, `PeProductFileException`, `Eaii529ExceptionCodes` (EAII529-001..014, 099), endpoint/payload/token-exception types |
| Tests | 10 new test classes (144 tests) + 6 synthetic fixtures under `Tests/.../Fixtures/EAII-529 - PE to Stibo/` | See build-test.txt |

Modified existing files (all additive; existing interfaces keep their behaviour - all 317 baseline tests still pass):

| File | Change | Why |
|---|---|---|
| `Common/Configuration/AppSettings.cs` | `SmcInterfaceIdEAII529` + an `// EAII-529` section (topic/subscription, folders, two feature switches, Stibo settings, retry, timeout, token margin) | One AppSettings class per repo |
| `Common/Models/ProcessingResult.cs` | `CompleteMessageOnFailure` property (default false) + `DataError(...)` factory | TSD 5.1.2.1 step 12: a data error is SMC Failed **but the message is completed**; the existing envelope could only dead-letter a failure |
| `Common/Executor/ServiceBusFunctionExecutor.cs` | Completes the message when `!IsSuccess && CompleteMessageOnFailure` (3 lines) | Same reason. Every existing `Failure(...)` still dead-letters (flag defaults to false; asserted by a test) |
| `Common/Executor/IServiceBusFunctionExecutor.cs` | Doc comment only | Keep the contract description accurate |
| `Common/Services/SmcService.cs` | `["PEProductDataToStibo"] = "PE Product Data To Stibo"` in the display-name map | Without it the SMC stage name is "PEProduct Data To Stibo Completed" (regex fallback) |
| `FunctionApp/Metcash.AIS.Data.Metproducts/Program.cs` | `// EAII-529` block: `TimeProvider`, two typed Stibo clients with a timeout, blob lifecycle + transform singletons, scoped service; `using ...DependencyInjection.Extensions` | DI composition root |
| `pipelines/appsettings/{dev,sit,uat,prod}.local.settings.json` | EAII-529 keys, `AzureWebJobs.PEProductDataToStibo.Disabled = "true"`, dev also `SmcInterfaceIdEAII529` | Per-environment settings |
| `Tests/.../Metcash.AIS.Data.Metproducts.Tests.csproj` | `Fixtures\**\*.txt` copied to output | The project only copied `*.xml` fixtures; PRD_JRN files are flat text |
| `README.md` | EAII-529 rows in "Interfaces at a glance", "Configuration reference", "Open items" | Keep the repo README current |

`host.json` was **not** changed (see A32).

## 2. Assumptions and decisions where the TSD was silent or ambiguous

**Settlement and SMC**
- A1. Data error vs technical failure (TSD 5.1.2.1 step 12, decision 7) is carried to the executor through `ProcessingResult.DataError` (complete) vs `ProcessingResult.Failure` (dead-letter). Data errors: EAII529-009/-010/-011 and Stibo 400/422 (-004). Technical: -001, -002, -003, -005, -006, -012, -099 and "other 4xx" (A5).
- A2. Duplicate delivery (EAII529-014) returns `ProcessingResult.Skipped` (message completed, no Stibo call). The SMC observation's top-level `StageStatus` is therefore "Success"; the "Non-Success" the TSD asks for appears as the status of the `1.00 Duplicate Delivery` and `100 Observation Complete` stage entries. The shared `SmcService` only knows Success/Failure (see D2).
- A3. Duplicate = event for a blob outside `{container}/{PEProductDataInFolder}/` **or** a blob no longer present (404). A blob that is in `in/` is processed even if a file of the same name was processed before (a corrected re-drop).
- A4. The TransactionID (correlation id) is the GUID the shared executor generates (Event Grid sets no `CorrelationId` on the message), as TSD 5.1.4.1 says ("generated by the Function per file run").
- A5. The file name (`PRD_JRN.<job>`) is returned as `ProcessingResult.ItemNumber`, so it reaches SMC (`MessageHeader`/`CorrelationProperties` "ItemNumber"), App Insights `Completed` events and the dead-letter properties. The shared SmcService has no FileName/RecordType property (see D4).
- A6. SMC stage IDs: `1.00` download or duplicate, `1.10` resume marker found, `2.00` parse (description = counts by type and line count; on error the code and message), `2.10` HDR/TRL warning, `3.00` token / Stibo configuration, `4.{n}{call}` delivery (n: STS 1, CST 2, TMP 3, AMD 4, SUP 5, PCK 6; status Success/Retrying/Failed/Skipped), `4.90` resume-marker warning, `5.00` archived / moved to error, `9.00` unexpected, `100` Observation Complete. Descriptions never contain payload, file content, token or secret (TSD 6.3.1); 4xx response bodies go to `ILogger` (truncated to 2,000 chars), never to SMC.
- A7. Unexpected exceptions are caught in the service and returned as `Failure(EAII529-099)` with `TrackException`, instead of rethrowing to the executor (which would record code "500"). The TSD requires the EAII529-099 code.
- A8. `EnablePayloadDiagnosticLogging` (dev/sit/uat = true) is deliberately **not** honoured by EAII-529: TSD 6.3.1 forbids logging the full file or XML payload (same idea as the EAII-282 redaction).

**Retry and HTTP status handling (TSD 4.5.1)**
- A9. Attempts and delay come from `StiboRetryCount` (3) and `StiboRetryDelaySeconds` (5); FSD 3.1.6/4.3 call them configurable. Delay uses the injected `TimeProvider` (tests assert 5 s without waiting).
- A10. Classification: 2xx success; 400 and 422 data error (-004, error/, completed, not retried); 401/403: discard the token, request one new token, retry that call once (no delay, not counted as an attempt), then -003 technical; 5xx and 408 transient; `HttpRequestException` transient, -006 when exhausted; `TaskCanceledException` (HttpClient timeout) transient, -005 when exhausted (TSD lists "timeout" under -005 and "network or connection exception" under -006).
- A11. Any other status (404, 405, 409, 413, 415, **429**, 1xx/3xx) is not retried (TSD: "no retry on other 4xx") and is treated as a **technical** failure with code -004 (blob stays in `in/`, dead-letter): such statuses point at configuration, not data, so moving the file to `error/` would lose a replayable file. The TSD row for -004 says "another non-retryable 4xx (400, 422)" with data-error handling; I narrowed data-error handling to 400/422 exactly as step 12 states.
- A12. The token request is not retried in-process (TC-011: "processing stops before any payload call"); a replay retries it.
- A13. Per-call timeout: `StiboHttpTimeoutSeconds` (empty, G14) falls back to `AppSettings.DefaultStiboHttpTimeoutSeconds` = 30 s (the value SmcService uses).

**Token (decision 9)**
- A14. A dedicated `StiboTokenService` holds one token per invocation (typed client, transient, injected into the scoped service). The existing shared `TokenService` was not reused: it is a singleton whose cache spans invocations with a 300 s buffer, which TSD 5.1.3.2 rules out.
- A15. Token request: `POST StiboTokenUrl`, form body `grant_type=client_credentials&client_id&client_secret`, no scope (FSD 3.1.3: scope N/A). The legacy `getOpenidToken.bwp` request format (form body vs HTTP Basic) is unknown (G11).
- A16. Refresh margin 60 s (`StiboTokenRefreshMarginSeconds`, TSD "proposed - to be confirmed from the platform team"). A response without `expires_in` keeps the token for the run (a 401 still forces one refresh).
- A17. `StiboTokenUrl` is a full URL setting (empty, G14) rather than "base + /token": G14 lists the token URL itself as open.
- A18. Key Vault failure detection: if App Service could not resolve the Key Vault reference, the setting still holds the literal `@Microsoft.KeyVault(...)` text; that, or an empty secret, is reported as EAII529-002 without calling the token endpoint (TC-027).

**Parsing (TSD 8.1, FSD 4.4)**
- A19. Lines split on LF, trailing CR removed; blank lines are skipped and not counted; every field is trimmed (a space-only field such as `STS|385675-055|O|A| |` position 5 is blank).
- A20. Record type = first field, exact match on HDR/STS/CST/SUP/PCK/TMP/AMD/TRL (legacy used `starts-with`). A line without `|`, an unknown type, a second HDR, a record before HDR or after TRL, a missing HDR/TRL, a blank ITEMLOCATION, a SUP without BUYFROMSUP, a non-`yyyyMMdd` STS date, a non-numeric TRL count, or a non-blank field beyond the layout length -> EAII529-010. Blank fields beyond the layout (trailing `|`) are tolerated. Short lines are tolerated (PCK with 2 fields, G12).
- A21. TRL RECORDCOUNT = number of non-blank lines including HDR and TRL (sample: 50 = 46 STS + 2 CST + HDR + TRL). Mismatch -> EAII529-011. Switchable with `PEProductDataValidateTrailerCount` (default true) while G17 is open.
- A22. HDR/TRL date or time disagreement, or a non-`yyyyMMdd`/`HHmmss` value, is a **warning** (stage `2.10`), not an error (TSD 5.1.6.3.1 lists "HDR/TRL warning"; step 6 only names the trailer count as an error).
- A23. A file with only HDR and TRL is valid: nothing is sent, the file is archived, SMC Success.
- A24. Blob content is decoded as UTF-8 (AS/400 output assumed ASCII-compatible).

**Rendering (Mapping 1-6, TSD 8.1)**
- A25. One payload per record type present, all records of the type as `<Product>` elements in file order; delivery order STS, CST, TMP, AMD (Item Status/Price), SUP (Supplier Change), PCK (Pack Change) - decision 5.
- A26. Legacy field parity (G5): `PEProductDataMapLegacyUnreadFields` = false (default and in every settings file). STS `attr_itemmarkfordelete_dt` and AMD `attr_brokencaseflag`, `attr_brokencaseordermultiple`, `attr_tradeshowonlyitem` are emitted **as empty Value elements** (the attribute set of the Mapping, the values the legacy parser never read). Setting it to true maps them from the file (FSD alternative (a)). See O-G5: the Mapping's target samples (BROKENCASE `N`, multiple `6`, TRADESHOWONLYITEM `ID=""`) suggest the legacy output may in fact have carried positions 5-7.
- A27. Conditional `@ID`: present only when the field has a non-blank value (TSD 8.1, TC-018). The Mapping notes the legacy produced `ID=""` for an empty TRADESHOWONLYITEM; the TSD rule was followed.
- A28. Numeric values are copied as text (".2500" stays ".2500"); a blank cost produces an empty `<Value>` (would not validate as `xs:float`; Stibo behaviour unknown).
- A29. Dates `yyyyMMdd` -> `yyyy-MM-dd`; blank stays blank.
- A30. PCK root carries `ExportContext` = context id, `UseContextLocale="false"`, `ExportTime` = run time in Australian Eastern local time, `yyyy-MM-dd HH:mm:ss` (legacy `current-dateTime()` on the TIBMIP server, assumed AEST/AEDT).
- A31. TMP root omits `WorkspaceID`, adds `ExportContext`; `ProductCrossReference Type="prf_lcitm_2_tmpitm"` has no product id/key for the temporary item because the Mapping maps none (the Manifest mentions `uk_temp_item_number`; TMPITEMPACKCHANGE is unmapped). Unverified (G10).
- A32. XML: `<?xml version="1.0" encoding="UTF-8"?>`, no indentation, empty elements self-closed (`<Value AttributeID="x" />`), standard escaping. `Content-Type: application/xml` on all three endpoints (decision 10); query `?context=&workspace=` from `StiboContextId`/`StiboWorkspaceId` (also used for the XML attributes).

**File lifecycle and resume**
- A33. Move = download + upload to `{folder}/{name relative to in/}` (overwrite, metadata and content type carried) + delete source. Same file name (TSD 5.1.4.1 "name preserved"); a later file with the same name overwrites the archived/error copy. Server-side copy was avoided (source-authorisation rules with managed identity; files < 10 KB).
- A34. Resume marker: blob metadata key `completed`, comma list in delivery order, written (merged with existing metadata) after each delivered type; unknown tokens ignored; write failure -> EAII529-013 warning and continue. Archive-move failure -> EAII529-012, dead-letter; the replay finds every type in the marker, requests no token, sends nothing, retries the move only (TC-028).
- A35. If the move to `error/` fails after a data error, the run becomes technical EAII529-012 (dead-letter) so the replay retries the move.
- A36. Missing Stibo endpoint configuration (`StiboBaseUrl` or a path empty) fails the run before the token request, code EAII529-099 (the TSD has no specific code). **With G14 open this is what every run would do**, hence the function ships disabled.

**Configuration**
- A37. Setting names are proposals following the sibling convention (target prefix): `StiboPEProductDataTopicName`/`SubscriptionName`, `PEProductData*`, `Stibo*`. Only `StiboClientId` and the secret name `METPRODUCTS-Stibo-Client-Secret` come from the TSD (both "proposed - confirm", G14).
- A38. Values known from the TSD/FSD are filled in (topic `data.metproducts.{env}.sbt`, subscription `tostibo.peproductdata`, container `pe`, folders, endpoint paths, `Australian`/`Main`, 3/5, 60). Open values are present and empty: `StiboBaseUrl`, `StiboTokenUrl`, `StiboClientId`, `StiboHttpTimeoutSeconds`. The secret is a Key Vault reference to `t3data{env}ae1kv01`.
- A39. `AzureWebJobs.PEProductDataToStibo.Disabled = "true"` in all four environments (TSD 9.2: disabled until cut-over).
- A40. `SmcInterfaceIdEAII529` added to `dev.local.settings.json` only, mirroring the existing files (sit/uat/prod rely on the class default "EAII-529").
- A41. `HealthCheck` was not extended with a Stibo probe: with the base URL empty it would report "Degraded" for the whole app in every environment. Add it once G14 is answered.

**Runtime / platform (verify in DV1)**
- A42. Settlement of session messages through `ServiceBusMessageActions` (Complete/DeadLetter) is assumed to work with Worker.Extensions.ServiceBus 5.16 (host extension 5.13.5); no session-specific actions are used.
- A43. `host.json` unchanged. One static SessionId means one active receiver, so `maxConcurrentSessions` (default 8) has no effect. **Risk:** worst case one run = 6 calls x (3 x 30 s timeout + 2 x 5 s) = 10 min, beyond the default 5 min lock auto-renewal (TSD limitation 9). Once the real Stibo timeout is known (G14), either lower `StiboHttpTimeoutSeconds` or raise `maxAutoLockRenewalDuration` (an app-wide setting, so agree it with the other interfaces' owners).
- A44. Infrastructure is outside this repo (TSD 5.1.6.1: `metcash-ais-infrastructure`): Event Grid subscription with the `in/` subject filter and static `SessionId = pe-productdata`, session-enabled subscription `tostibo.peproductdata` (maxDeliveryCount 10), container `pe` and lifecycle rules (archive 90 d, error 30 d), RBAC (Storage Blob Data **Contributor** on `pe` - needed for metadata writes and deletes; Key Vault Secrets User on `t3data{env}ae1kv01`; Service Bus Data Receiver on the new subscription), the Key Vault secret.
- A45. TC-021 (one file at a time) and TC-022 (moves do not re-trigger) are infrastructure behaviours; unit tests only pin the trigger attribute and the folder layout. They need a DV1 integration test.
- A46. Test fixtures are synthetic (the production samples exist only as images): built from the record layouts and the sample lines/values quoted in the FSD and Mapping. TC-016/TC-017 therefore prove the parity rule, not byte-equality with the legacy output.

## 3. Deviations from the TSD

| # | TSD says | Implemented | Why |
|---|---|---|---|
| D1 | 5.1.6.1: shared library `Metcash.AIS.Data.Metproducts.Common` "reused unchanged" | Three small additive changes (ProcessingResult flag + factory, executor settlement branch, SmcService display name) | The unchanged executor dead-letters every failure, which contradicts TSD step 12 (data error -> message completed). Behaviour of existing interfaces unchanged (baseline tests pass). |
| D2 | Duplicate delivery / HDR-TRL warning -> SMC "Non-Success" | SMC observation status Success with "Non-Success"/"Warning" stage entries | `ISmcService`/`SmcService` only produce Success or Failure; adding a third status changes a shared contract used by five interfaces. Follow-up: extend SmcService with a warning status. |
| D3 | 3.2 / decision 8: "the in-process retry is Polly in the shared library" | Explicit retry loop in the service, values from settings | The shared library has no Polly retry component (only SmcService uses Polly privately); all five production services use the explicit loop, which also produces the per-attempt SMC stage entries. |
| D4 | 5.1.7.1 Reference keys TransactionID, FileName, RecordType | TransactionID = ObservationID; FileName via the `ItemNumber` header; RecordType only in stage names/descriptions | Shared SmcService exposes CorrelationId and ItemNumber only. |
| D5 | 5.1.6.3.3 EAII529-004 "another non-retryable 4xx (400, 422)" -> error/ | Only 400/422 go to error/; other 4xx are technical (in/, dead-letter), still code -004 | See A11. |
| D6 | 5.1.6.3.3 EAII529-099 via the executor's catch | Caught in the service so the SMC code is EAII529-099, not "500" | See A7. |
| D7 | 5.1.4.1 / FSD: the retired codes `ERR_PE_TIBCO_MDM_*` | Not used anywhere | Replaced by EAII529-nnn as the TSD states. |

## 4. Open items (owner from the gap register)

| Gap | Item | Owner | Effect on the code | Blocks deployment? |
|---|---|---|---|---|
| G14 | Stibo base URL, token URL, client id per env, secret name (proposed `METPRODUCTS-Stibo-Client-Secret`), per-call timeout | Stibo / platform owner | `StiboBaseUrl`, `StiboTokenUrl`, `StiboClientId`, `StiboHttpTimeoutSeconds` empty in all four files; secret name proposed | **Yes** - every run fails (EAII529-099 / -002) until filled |
| G7 | Firewall path Function App -> Stibo proxy, every env | Network team | none | **Yes** |
| G16 | Cut-over order: TIBCO poller vs GoAnywhere on the same TIBMIP folder (double delivery to Stibo) | MFT team / Integration Platform | function ships disabled | **Yes** (before enabling) |
| G5 | Legacy parity for STS#6 and AMD#5-7; exact legacy attribute set; `ID=""` vs no ID for empty LOVs | Vladimir Gurieff / Stibo platform team | `PEProductDataMapLegacyUnreadFields` (false) | **Yes** for PRD (wrong attribute set at Stibo) |
| G2 | Is re-sending an accepted payload harmless (Stibo idempotency)? Resume-by-metadata is a proposal | Magesh Parthasarathy / Stibo platform owner | resume marker implemented | No (mitigated) |
| G4 | Failure disposition (walkthrough rule vs FSD 3.1.7/T7/T8) - FSD to be updated | Vladimir Gurieff | implemented per TSD/walkthrough | No, but the FSD must be aligned before test sign-off |
| G17 | Did the legacy flow check the TRL count? | Vladimir Gurieff | `PEProductDataValidateTrailerCount` (true) | No |
| G10 | No TMP production sample; TMP XML unverified (incl. missing temp-item key) | Integration Support | renderer per Mapping | No (volume < 1/month), but TMP stays unverified |
| G11 | TIBCO repository not identified - legacy XSLT/token call could not be cross-checked | Vladimir Gurieff / Magesh Parthasarathy | A15, A26, A27 unverified | No |
| G6 | Notification channel: SMC alert vs direct email | Magesh Parthasarathy | none (SMC observation only) | No |
| G1 | Logic App vs Function App not settled in the walkthrough | Magesh Parthasarathy | built as Function App per TSD | Confirm before merge |
| G15 | SMC queue namespace t1 vs t2 | Enabling / SMC team | none (code calls APIM `smc-v1` via existing `SmcBaseUrl`) | No |
| G18 | SMC onboarding tags | SMC core team | none | No (onboarding) |
| G8 | FSD diagram shows a trigger file | Vladimir Gurieff | none | No |
| - | Token refresh margin 60 s | Platform team (TSD decision 9) | `StiboTokenRefreshMarginSeconds` = 60 | No |
| - | Infra: Event Grid + session subscription, container + lifecycle rules, RBAC, Key Vault secret (A44) | Integration Platform (Bicep) / Enabling team for the enabling-vault grant | none | **Yes** |
| - | TSD is a test-run document; approval checklist unsigned | TSD approvers | - | **Yes** (process) |
