# Unit Test Corpus — from real production test projects and the real ADO Test Suite

Two distinct, real sources, both confirmed by evidence, both feeding `ais-unit-test-cases`:
1. **Source-code tests** — `Tests/Metcash.AIS.Data.Metproducts.Tests/` and
   `Tests/Metcash.AIS.Data.MDMSupplierInfo.Tests/` (both `main`) — xUnit/Moq/FluentAssertions.
2. **The real ADO Test Suite itself** — Test Plan `AIS Migration` (id `224095`), confirmed via
   `https://dev.azure.com/METCASHDevOps/Squad%2020/_testPlans/execute?planId=224095&suiteId=416879`
   and the `testplan` REST API. This is where actual test *cases and results* for an interface
   are meant to live — not just as `.cs` files — matching what `ais-unit-test-cases` and
   `ais-test-results-to-ado` already push to.

## Real ADO Test Plan hierarchy (confirmed, corrects the skill)

**Updated 2026-09-19**: the tree actually has one more layer than first recorded here — a
`Phase 2` suite sits between the plan and the shared "Unit Testing" suite (found by walking the
full suite list via REST when creating EAII-529's suite; `Phase 1` (id 416100) is a sibling
holding the same three sub-suites for older/legacy interfaces):

```
Test Plan: "AIS Migration" (id 224095, area "Squad 20", iteration "Squad 20\PI 17")
└── Suite: "Phase 2" (id 416101)                          ← current phase (sibling "Phase 1" id 416100 is legacy)
    └── Suite: "Unit Testing" (id 416102)                 ← ONE parent suite for ALL interfaces
        ├── Suite: "UT_EAII-304 - Liquor Suppliers to EIM" (id 416879)   ← ONE suite PER INTERFACE
        │   ├── Test Case 417322: "Verify Upload Blob without authentication token"
        │   ├── Test Case 417323: "Verify Upload Blob with invalid or expired authentication token"
        │   ├── ... (41 test cases total in this one suite)
        │   └── Test Case 417362: "Verify SMC error payload integrity"
        ├── Suite: "UT_EAII-529 - PE Product Data - PE to Stibo" (id 427006, created 2026-09-19)
        └── Suite: "UT_EAII-<other>..."                   ← same pattern, one suite per interface
```

**This corrects `ais-unit-test-cases`'s current instructions**, which say to create **four**
suites per interface (Happy Path / Error Path / Boundary / Business Logic). The real, confirmed
pattern is **one flat suite per interface**, named `UT_EAII-<number> - <InterfaceName>`, nested
under a single shared `Unit Testing` parent suite in one long-lived `AIS Migration` plan — not a
new plan per interface, and not sub-suites per category. Category is expressed through the test
case *title* and grouping in the CSV, not a separate ADO suite.

## Real test case granularity — much finer than the skill's 8-case minimum

EAII-304's real suite has **41** test cases, not the skill's "minimum 8". Real categories
observed, richer than the skill's four:
- **Auth/header validation** (missing/invalid/expired token, missing/invalid custom header)
- **Payload validation** (missing body, invalid JSON, missing/empty required fields)
- **File-format validation** (invalid Base64, non-ZIP content, corrupted ZIP, size limit — both
  under and over the 3 MB boundary, tested as separate cases)
- **Business logic** (multiple records, PSV schema format, metadata enrichment)
- **Error handling** (business-rule transform failure, transient storage retry, corrupted ZIP
  decompression, missing/empty/invalid data array)
- **Cross-cutting/observability** (`Finally` block runs on both success AND failure paths as two
  *separate* test cases, SMC send failure must not block the workflow, SMC error payload
  integrity, a `HasErrors` termination gate)

**Applied:** `ais-unit-test-cases` now documents "8 minimum across 4 categories" as a floor, not
a target, citing this real 41-case example and the richer category set (auth/header validation,
file-format/size validation, cross-cutting checks like finally-block and termination gates).

## Real ADO test case format (`Microsoft.VSTS.TCM.Steps` field)

Each test case work item stores its steps as an XML fragment — an ordered list of
(Action, Expected Result) pairs, not a single free-text description:

```xml
<steps id="0" last="6">
  <step id="2" type="ValidateStep">
    <parameterizedString isformatted="true">Submit a valid request containing a valid Bearer token, SupplierID and ZIP file within the 3 MB limit</parameterizedString>
    <parameterizedString isformatted="true">API accepts the request and stores the source file in the input location.</parameterizedString>
  </step>
  <step id="3" type="ValidateStep">
    <parameterizedString isformatted="true">Allow the uploaded file event to trigger downstream processing</parameterizedString>
    <parameterizedString isformatted="true">Queue message is created and consumed successfully.</parameterizedString>
  </step>
  <!-- ... one step per stage of the pipeline, ending in the final observable outcome ... -->
</steps>
```

(`Verify end-to-end successful Upload Blob processing`, work item 417341 — a happy-path test
case whose steps trace the entire pipeline: API upload → queue trigger → ZIP/PSV transform →
upload+archive → SMC logging — each step pairing one action with one concrete, checkable
expected result.) `ais-unit-test-cases`'s CSV `InputDescription`/`ExpectedOutput`/
`ValidationPoints` columns should map onto this same one-action-per-step shape when the ADO test
case is created from a CSV row, rather than collapsing everything into one long description.

**A genuinely interesting real finding:** EAII-304's Test Case work items exist and are fully
detailed (`State: Design`) while its actual code repo (`Metcah.AIS.B2B.IBADirects`) is still
README-only — proof that this org sometimes authors ADO test cases *before* code exists. Don't
assume "no code found" means "no real test-case corpus to learn from."

Source: `Tests/Metcash.AIS.Data.Metproducts.Tests/` and
`Tests/Metcash.AIS.Data.MDMSupplierInfo.Tests/` (both `main`). Confirms the real toolchain and
test shape for Function App interfaces — this replaces guesswork in `ais-unit-test-cases`'s
"Unit Test Pattern" section for anything targeting a Function App.

## Real toolchain (confirmed, not assumed)

- **xUnit** (`[Fact]`, not NUnit/MSTest)
- **Moq** for mocking interfaces (`Mock<IBlobService>`, `.Setup(...)`, `.Verify(...)`)
- **FluentAssertions** for asserts (`result.IsSuccess.Should().BeTrue()`, not `Assert.True(...)`)

`ais-functionapp-codegen`'s previous "Unit Test Pattern" used bare `Assert.*` — corrected
alongside the rest of that skill's update to use FluentAssertions, matching real code.

## Two test classes per interface, not one

For each interface there are always **two** test files, one per layer:

### 1. Function-level test (`Tests/.../Functions/<Name>FunctionTests.cs`)

Tests that the Function correctly wires its trigger to the executor — **not** the business
logic (that's the Service test's job). Mocks both the Service and the Executor:

```csharp
public class CorporateItemToSortedFunctionTests
{
    private readonly Mock<ICorporateItemToSortedService> _service = new();
    private readonly Mock<IServiceBusFunctionExecutor> _executor = new();
    private readonly IOptions<AppSettings> _options = Options.Create(new AppSettings
    {
        SmcInterfaceIdEAII283 = "EAII-283"
    });

    private CorporateItemToSorted CreateSut() => new(_service.Object, _executor.Object, _options);

    [Fact]
    public async Task RunAsync_ValidMessage_ShouldCallExecutorWithCorrectInterfaceId()
    {
        var body = BinaryData.FromString("{\"data\":{\"url\":\"https://blob.example.com/test.xml\"}}");
        var message = ServiceBusModelFactory.ServiceBusReceivedMessage(body: body);
        var actions = new Mock<ServiceBusMessageActions>().Object;
        var context = new Mock<FunctionContext>().Object;

        _executor.Setup(e => e.ExecuteAsync(
            It.IsAny<ServiceBusReceivedMessage>(), It.IsAny<ServiceBusMessageActions>(),
            It.IsAny<FunctionContext>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<Func<string, string, List<LogMessage>, Task<ProcessingResult>>>()))
            .Returns(Task.CompletedTask);

        var sut = CreateSut();
        await sut.RunAsync(message, actions, context);

        _executor.Verify(e => e.ExecuteAsync(
            message, actions, context, "EAII-283", nameof(CorporateItemToSorted),
            It.IsAny<Func<string, string, List<LogMessage>, Task<ProcessingResult>>>()),
            Times.Once);
    }
}
```

Note `ServiceBusModelFactory.ServiceBusReceivedMessage(body: ...)` — the real, correct way to
construct a fake Service Bus message for a test; don't hand-roll one.

### 2. Service-level test (`Tests/.../Services/<Name>ServiceTests.cs`)

Tests the actual business logic. Mocks only the *I/O-boundary* dependencies (Blob, Http,
Gating), uses the **real** transform service (no mock — transform logic is pure and worth
testing for real, not stubbing out the thing under test):

```csharp
public class CorporateItemToSortedServiceTests
{
    private readonly Mock<IBlobService> _blobService = new();
    private readonly Mock<ISortedGatingService> _gatingService = new();
    private readonly Mock<ISortedHttpService> _sortedHttpService = new();
    private readonly SortedCorporateTransformService _transformService = new();   // real, not mocked
    private readonly TelemetryClient _telemetryClient = new(new TelemetryConfiguration());
    private readonly Mock<ILogger<CorporateItemToSortedService>> _logger = new();

    private const string SampleCorporateXml = """<STEP-ProductInformation>...</STEP-ProductInformation>""";

    [Fact]
    public async Task ProcessAsync_WhenSortedUnavailable_ShouldReturnSkipped() { /* gating false → Skipped, not Failed */ }

    [Fact]
    public async Task ProcessAsync_WhenSortedReturnsSuccess_ShouldReturnSuccess() { /* happy path */ }

    [Fact]
    public async Task ProcessAsync_ValidCorporateXml_ShouldTransformAndPostJsonToSorted()
    {
        // ...capture the payload sent to _sortedHttpService via a Moq .Callback(...)...
        capturedContentType.Should().Be("application/json");
        capturedPayload.Should().Contain("\"itemNumber\":\"682179\"");   // asserts against REAL sample data values
    }
}
```

Key real-world habits worth copying into generated tests:
- **Sample payloads are realistic, inline C# 11 raw string literals** (`"""..."""`), not
  external fixture files, for the simple cases — fixture *folders* (see below) are reserved for
  larger/parameterized cases.
- Assertions check for **specific field values from the sample data** (e.g.
  `"\"itemNumber\":\"682179\""`), not just "no exception was thrown" — this is what makes a test
  actually catch a transform regression.
- The "unavailable → Skipped" case is tested explicitly and separately from the failure case —
  gating and true failure are different, both-tested outcomes, not folded together.

## Fixture-folder tests (data-driven, for larger real-sample coverage)

Both repos also have a `*FixtureFolderTests.cs` per interface (e.g.
`CorporateItemToIndiPIMFixtureFolderTests.cs`, `SortedSupplierTransformServiceFixtureFolderTests.cs`)
— a data-driven test that iterates every sample file in a `Fixtures/<Interface>/` folder and
runs the transform against each one, rather than one hardcoded inline sample per `[Fact]`. Use
this pattern when a transform has many real-world input variants worth covering (STIBO record
type variations, optional-field combinations) rather than writing one `[Fact]` per variant.

## Corpus → `ais-unit-test-cases` action items

- Replace the skill's `Assert.*`-based example with the real FluentAssertions style shown above.
- Add the Function-test / Service-test **split** as a required pattern for any Function App
  target, not a single combined test class.
- Reference the fixture-folder pattern as the option for data-driven coverage once a transform
  has more than a handful of input variants.
- Applied to `ais-unit-test-cases/SKILL.md`'s "ADO Test Plan Integration" section.
