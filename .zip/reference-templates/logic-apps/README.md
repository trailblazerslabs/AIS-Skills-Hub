# Logic App Templates

Skeleton files for Logic App Standard workspace assets.

| File | Use |
|---|---|
| `workflow.template.json` | Starting point for a new `workflow.json` |
| `connections.template.json` | Starting point for `connections.json` connection entry |
| `parameters.template.json` | Starting point for `parameters.json` parameter entry |

Copy to `outputs/<InterfaceID>/LogicApp/` and replace every `<PLACEHOLDER>` value.
