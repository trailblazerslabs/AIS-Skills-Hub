namespace Metcash.AIS.<DOMAIN>.<INTERFACE_NAME>
{
    public class <INTERFACE_NAME>Transformer
    {
        /// <summary>
        /// Transforms the input payload and returns a wrapped TransformationOutput.
        /// Replace the body with the actual transformation logic.
        /// </summary>
        public TransformationOutput<<INTERFACE_NAME>Output> Transform(<INTERFACE_NAME>Input input)
        {
            // TODO: Implement transformation logic.
            // Example: sort by a key, group by a field, map fields to target schema.
            var outputItems = input.Items
                .OrderBy(x => x.<SORT_KEY_1>)
                .ThenBy(x => x.<SORT_KEY_2>)
                .Select(x => new <INTERFACE_NAME>OutputItem
                {
                    // TODO: Map fields from input to output
                    Id = x.Id
                })
                .ToList();

            return new TransformationOutput<<INTERFACE_NAME>Output>
            {
                Data = new <INTERFACE_NAME>Output { Items = outputItems },
                Success = true
            };
        }
    }
}
