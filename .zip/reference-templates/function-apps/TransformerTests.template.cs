using Xunit;

namespace Metcash.AIS.<DOMAIN>.<INTERFACE_NAME>.Tests
{
    public class <INTERFACE_NAME>TransformerTests
    {
        private readonly <INTERFACE_NAME>Transformer _transformer = new();

        [Fact]
        public void Transform_ValidInput_ReturnsSuccess()
        {
            var input = new <INTERFACE_NAME>Input
            {
                Items = new List<<INTERFACE_NAME>InputItem>
                {
                    // TODO: Add representative test items
                    new() { Id = "1", <SORT_KEY_1> = "B" },
                    new() { Id = "2", <SORT_KEY_1> = "A" }
                }
            };

            var result = _transformer.Transform(input);

            Assert.True(result.Success);
            Assert.NotNull(result.Data);
            Assert.Equal(2, result.Data.Items.Count);
        }

        [Fact]
        public void Transform_EmptyItems_ReturnsEmptyOutput()
        {
            var input = new <INTERFACE_NAME>Input { Items = new List<<INTERFACE_NAME>InputItem>() };

            var result = _transformer.Transform(input);

            Assert.True(result.Success);
            Assert.Empty(result.Data.Items);
        }

        [Fact]
        public void Transform_SortsItemsByExpectedKey()
        {
            var input = new <INTERFACE_NAME>Input
            {
                Items = new List<<INTERFACE_NAME>InputItem>
                {
                    new() { Id = "1", <SORT_KEY_1> = "Z" },
                    new() { Id = "2", <SORT_KEY_1> = "A" }
                }
            };

            var result = _transformer.Transform(input);

            Assert.Equal("A", result.Data.Items[0].<SORT_KEY_1>);
            Assert.Equal("Z", result.Data.Items[1].<SORT_KEY_1>);
        }
    }
}
