using Newtonsoft.Json;

namespace Metcash.AIS.<DOMAIN>.<INTERFACE_NAME>
{
    public class <INTERFACE_NAME>Input
    {
        [JsonProperty("items")]
        public List<<INTERFACE_NAME>InputItem> Items { get; set; } = new();
    }

    public class <INTERFACE_NAME>InputItem
    {
        // TODO: Add properties matching the source payload schema.
        // Use [JsonProperty("fieldName")] to map camelCase JSON to PascalCase C#.
        [JsonProperty("id")]
        public string Id { get; set; } = string.Empty;

        [JsonProperty("<SORT_KEY_1_JSON>")]
        public string <SORT_KEY_1> { get; set; } = string.Empty;

        [JsonProperty("<SORT_KEY_2_JSON>")]
        public string <SORT_KEY_2> { get; set; } = string.Empty;
    }
}
