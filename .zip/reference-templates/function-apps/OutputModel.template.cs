using Newtonsoft.Json;

namespace Metcash.AIS.<DOMAIN>.<INTERFACE_NAME>
{
    public class <INTERFACE_NAME>Output
    {
        [JsonProperty("items")]
        public List<<INTERFACE_NAME>OutputItem> Items { get; set; } = new();
    }

    public class <INTERFACE_NAME>OutputItem
    {
        // TODO: Add properties matching the target payload schema.
        [JsonProperty("id")]
        public string Id { get; set; } = string.Empty;

        // Add mapped output fields here
    }
}
