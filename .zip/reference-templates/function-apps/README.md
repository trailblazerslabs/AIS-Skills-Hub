# Function App Templates

Skeleton C# .NET 8 files for local transformation functions inside a Logic App Standard workspace.

| File | Use |
|---|---|
| `Function.template.cs` | HTTP-triggered function entry point |
| `Transformer.template.cs` | Transformation service class |
| `InputModel.template.cs` | Typed input model |
| `OutputModel.template.cs` | Typed output model |
| `TransformerTests.template.cs` | xUnit test class skeleton |

Copy to `outputs/<InterfaceID>/Function/<InterfaceName>/` and replace every `<PLACEHOLDER>` value.
Do **not** create a new `.csproj` — reuse the existing one from the reference workspace.
