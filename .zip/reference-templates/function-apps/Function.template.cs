using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;

namespace Metcash.AIS.<DOMAIN>.<INTERFACE_NAME>
{
    public class <INTERFACE_NAME>Function
    {
        private readonly ILogger<<INTERFACE_NAME>Function> _logger;
        private readonly <INTERFACE_NAME>Transformer _transformer;

        public <INTERFACE_NAME>Function(
            ILogger<<INTERFACE_NAME>Function> logger,
            <INTERFACE_NAME>Transformer transformer)
        {
            _logger = logger;
            _transformer = transformer;
        }

        [Function("<INTERFACE_NAME>")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("[{InterfaceId}] Transform started.", "<INTERFACE_ID>");
            try
            {
                var body = await req.ReadAsStringAsync();
                var input = JsonConvert.DeserializeObject<<INTERFACE_NAME>Input>(body)
                    ?? throw new ArgumentException("Empty or invalid input payload.");

                var result = _transformer.Transform(input);

                var response = req.CreateResponse(HttpStatusCode.OK);
                await response.WriteAsJsonAsync(result);
                _logger.LogInformation("[{InterfaceId}] Transform completed successfully.", "<INTERFACE_ID>");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[{InterfaceId}] Transform failed.", "<INTERFACE_ID>");
                var error = req.CreateResponse(HttpStatusCode.InternalServerError);
                await error.WriteAsJsonAsync(new { error = ex.Message, interfaceId = "<INTERFACE_ID>" });
                return error;
            }
        }
    }
}
