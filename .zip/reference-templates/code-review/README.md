# Code Review Templates

Template for the AIS code review report, including build/check evidence, unit-test status,
production comparison provenance, a scored quality checklist, and a separate gate verdict.

| File | Use |
|---|---|
| `review-report.template.md` | Structured review findings report |

Populate it as `outputs/<InterfaceID>/code-review-report.md`. Record exact build/test commands and
results; never mark missing evidence as passed. Critical/High findings or failed mandatory checks
block PASS regardless of the percentage.
