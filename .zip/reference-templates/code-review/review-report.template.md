# Code Review Report: <INTERFACE_ID>

**Review Date:** <DATE>
**Reviewer:** <REVIEWER>
**Interface:** <INTERFACE_NAME> (<INTERFACE_ID>)
**Repo / branch / commit:** <REPO> / <BRANCH> / <SHA>
**TSD review:** <score>/100 — <PASS / BLOCKED> (<report path>)
**Production comparison:** <baseline repo + origin/main SHA; report path>
**Build status:** <PASS / FAIL / NOT RUN / N/A with reason>
**Unit-test status:** <CSV coverage / code-level test command-result / ADO case status / execution status>
**Verdict:** PASS / PASS WITH FINDINGS / FAIL

---

## Build and Test Evidence

| Gate | Command / artifact | Result | Evidence path / run id | Notes |
|---|---|---|---|---|
| Production-calibrated checker | `check_<artifact>.py ...` | PASS / FAIL / N/A | <report> | <errors/warnings> |
| Production comparison | `compare_logicapp.py ...` or equivalent | PASS / FINDINGS / N/A | <report + baseline SHA> | <intentional differences separated from defects> |
| Build / package | <exact command and configuration> | PASS / FAIL / NOT RUN / N/A | <log/run id> | <warnings, target framework> |
| Unit-test cases | `unit-test-cases.csv` and TSD traceability | PASS / FAIL / NOT STARTED / N/A | <path> | <scenario coverage and gaps> |
| Code-level unit tests | <exact command> | PASS / FAIL / NOT RUN / N/A | <TRX/log/run id> | <passed/failed/skipped> |
| ADO test cases / non-prod execution | <status and link> | PASS / FAIL / NOT STARTED / N/A | <ADO IDs/log> | Do not imply runtime execution from unit tests |

Missing or unverified evidence is **NOT RUN**, never PASS. Explain every N/A.

## Quality Score

Score each dimension only from cited evidence. N/A items require a reason and are removed from
the denominator; missing evidence scores zero. Percentage = awarded applicable points / maximum
applicable points × 100, rounded to a whole percentage.

| Dimension | Max | Awarded | Evidence / comments |
|---|---:|---:|---|
| Functional correctness and TSD/Mapping traceability | 20 | <0-20> | <evidence> |
| Production structure, naming, parameters and environment configuration | 15 | <0-15> | <checker/comparison> |
| Reliability, retries, failure handling and settlement/replay | 15 | <0-15> | <tests/code paths> |
| Security, identity, secret handling and data protection | 15 | <0-15> | <evidence> |
| SMC observability and operational diagnostics | 10 | <0-10> | <evidence> |
| Build, static checks and package integrity | 10 | <0-10> | <build/check logs> |
| Unit-test coverage and result status | 15 | <0-15> | <CSV/test results> |
| **Total** | **100** | **<total>** | |

**Quality percentage:** <total>%
**Gate disposition:** PASS / PASS WITH FINDINGS / BLOCKED

Any Critical/High finding, failed checker/build, or applicable required unit tests not passing
blocks PASS regardless of percentage. Target at least 90% with no unresolved Critical/High
finding. A score never overrides a hard blocker or deployment authorization.

---

## Findings

| # | Severity | Dimension | File / Location | Finding | Recommendation |
|---|---|---|---|---|---|
| 1 | High / Medium / Low | <DIMENSION> | <FILE_PATH> | <FINDING_DESCRIPTION> | <RECOMMENDATION> |

> **Severity:**
> - **Critical** — Active credential exposure, likely severe data loss, or unsafe production mutation; immediate stop.
> - **High** — Security risk, data loss potential, or blocks correct operation. Must fix before merging.
> - **Medium** — Standards violation. Must fix before release.
> - **Low** — Improvement recommendation. Does not block release.

---

## Category Summary

| Dimension | Status | Finding Count |
|---|---|---|
| Interface ID and Structure | Pass / Fail | 0 |
| Naming Conventions | Pass / Fail | 0 |
| Logic App Workflow Quality | Pass / Fail / N/A | 0 |
| Function App Code Quality | Pass / Fail / N/A | 0 |
| ADF Pipeline Quality | Pass / Fail / N/A | 0 |
| Security (OWASP Top 10) | Pass / Fail | 0 |
| Observability (SMC) | Pass / Fail | 0 |
| Unit Test Cases | Pass / Fail | 0 |

---

## Approved Patterns

- <List what was done correctly>

---

## Required Actions Before Merge

- [ ] <Action for each High/Medium finding>
