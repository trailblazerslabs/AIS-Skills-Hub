# ADF Templates

Skeleton JSON files for Azure Data Factory pipeline assets.

| File | Use |
|---|---|
| `pipeline.template.json` | ADF pipeline with SMC log activities |
| `dataset.template.json` | Parameterized dataset (Blob / Delimited Text) |
| `linkedservice-blob-mi.template.json` | Blob Storage linked service using Managed Identity |

Copy to `outputs/<InterfaceID>/ADF/` subfolders and replace every `<PLACEHOLDER>` value.
Never hardcode storage keys — always use Managed Identity in linked services.
