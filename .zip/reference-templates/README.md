# Reference Templates

Boilerplate templates for Metcash AIS Azure Integration interfaces.
Each skill loads from the subfolder matching its domain.

> **Usage:** Copy the relevant template to `outputs/<InterfaceID>/`, rename it, and fill in the `<PLACEHOLDER>` values. Never edit these source templates directly.

| Folder | Skill | Contents |
|---|---|---|
| `logic-apps/` | `ais-logicapp-codegen` | workflow.json, connections.json, parameters.json skeletons |
| `function-apps/` | `ais-functionapp-codegen` | C# function entry point, transformer, model, test class |
| `adf/` | `ais-datafactory-codegen` | Pipeline, dataset, linked service JSON skeletons |
| `documentation/` | `ais-documentation` | Spec, assumptions, data-flow markdown templates |
| `tests/` | `ais-unit-test-cases` | unit-test-cases CSV template |
| `code-review/` | `ais-code-review` | Review report template |
