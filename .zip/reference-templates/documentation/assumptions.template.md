# Assumptions: <INTERFACE_ID>

Generated: <DATE>
Author: <AUTHOR>

| # | Assumption | Impact if Wrong | Status |
|---|---|---|---|
| 1 | <Describe the assumption, e.g. "Source payload always contains at least one item"> | <What breaks if this is incorrect> | Open / Confirmed |
| 2 | <Next assumption> | <Impact> | Open |

## Notes

- Open assumptions must be confirmed before the interface is released to UAT.
- Update Status to `Confirmed` once verified with the source/target system owner.
- Add new rows as assumptions are discovered during development or review.
