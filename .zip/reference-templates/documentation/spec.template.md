# Technical Specification: <INTERFACE_NAME> (<INTERFACE_ID>)

## Overview

| Field | Value |
|---|---|
| Interface ID | <INTERFACE_ID> |
| Interface Name | <INTERFACE_NAME> |
| Source System | <SOURCE_SYSTEM> |
| Target System | <TARGET_SYSTEM> |
| Pattern | Logic App Standard / Logic App + Function App / ADF |
| Trigger Type | HTTP / Service Bus / Timer / Blob |
| Author | <AUTHOR> |
| Date | <DATE> |
| Status | Draft / Review / Approved |

## Data Flow

> Describe the end-to-end message path: where it originates, how it is triggered,
> what transformation occurs, and where it lands.

1. **Trigger** — <SOURCE_SYSTEM> sends a `<EVENT_NAME>` event to `<TRIGGER_ENDPOINT>`.
2. **Receive** — Logic App `<WORKFLOW_NAME>` picks up the message.
3. **Transform** — Function App `<FUNCTION_NAME>` sorts / maps / filters the payload.
4. **Deliver** — Transformed payload sent to `<TARGET_ENDPOINT>` in `<TARGET_SYSTEM>`.
5. **Error** — Failed messages dead-lettered to `<DLQ_NAME>`; SMC alert fired.

## Field Mapping

| Source Field | Source Type | Target Field | Target Type | Transformation | Notes |
|---|---|---|---|---|---|
| `<sourceField>` | string | `<targetField>` | string | Direct copy | |
| `<sourceField2>` | decimal | `<targetField2>` | string | Format `#,##0.00` | |

## Non-Functional Requirements

| Dimension | Requirement |
|---|---|
| Payload size | <e.g. Typical 50KB, max 1MB> |
| Daily volume | <e.g. 5,000 messages/day> |
| Peak throughput | <e.g. 100 messages/minute> |
| Latency SLA | <e.g. < 30 seconds end-to-end> |
| Reliability | <e.g. At-least-once delivery> |
| Retention | <e.g. 7 days in dead-letter queue> |

## Error Handling

| Scenario | Handling |
|---|---|
| Invalid payload | Return HTTP 400; log to SMC; do not forward |
| Target unavailable | Retry 3× with 30s back-off; dead-letter after 3 failures |
| Transformation error | Return HTTP 500; log full exception to SMC; dead-letter message |

## Observability (SMC)

| Log Point | Stage | Fields Logged |
|---|---|---|
| Workflow entry | `Entry` | interfaceId, correlationId, payloadSize |
| Transform complete | `Transform` | interfaceId, itemCount |
| Workflow exit (success) | `ExitSuccess` | interfaceId, duration |
| Workflow exit (failure) | `ExitFailure` | interfaceId, errorMessage |

## Assumptions

See [assumptions.md](assumptions.md).
