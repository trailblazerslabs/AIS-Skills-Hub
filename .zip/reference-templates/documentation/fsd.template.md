# Functional Specification Document (FSD)
## <INTERFACE_NAME> — <INTERFACE_ID>

---

| Field | Value |
|---|---|
| Interface ID | <INTERFACE_ID> |
| Interface Name | <INTERFACE_NAME> |
| Author | <AUTHOR> |
| Date | <DATE> |
| Version | 1.0 |
| Status | Draft / Review / Approved |
| Reviewed By | <REVIEWER> |
| Approved By | <APPROVER> |

---

## 1. Business Purpose

> Describe why this interface exists. What business problem does it solve?
> One to three paragraphs summarising the business context, value delivered,
> and how it fits into broader business processes.

<BUSINESS_PURPOSE_DESCRIPTION>

---

## 2. Stakeholders

| Role | Name / Team | Responsibility |
|---|---|---|
| Business Owner | <BUSINESS_OWNER> | Approves requirements and acceptance criteria |
| Source System Owner | <SOURCE_OWNER> | Provides source data and schema |
| Target System Owner | <TARGET_OWNER> | Consumes data and defines target schema |
| Integration Developer | Squad 20 | Builds and maintains the interface |
| QA / Tester | <QA_TEAM> | Validates against acceptance criteria |

---

## 3. Business Process Overview

> Describe the end-to-end business process this interface participates in.
> Use a numbered list to describe each step from a business perspective
> (not a technical perspective — save technical details for the TSD).

1. **Initiation** — <Describe what triggers the business process, e.g., "A purchase order is raised in <SOURCE_SYSTEM>.">
2. **Data Preparation** — <Describe any business preparation steps before the interface is involved.>
3. **Integration Trigger** — <Describe what causes this interface to be invoked, e.g., "The order is confirmed and an event is raised.">
4. **Data Delivery** — <Describe what the interface delivers and to whom.>
5. **Confirmation / Outcome** — <Describe expected confirmation or downstream action.>

---

## 4. Trigger Event

| Field | Value |
|---|---|
| Trigger Type | HTTP Request / Scheduled / Event / Message |
| Trigger Source | <SOURCE_SYSTEM> |
| Trigger Description | <DESCRIBE_THE_TRIGGER_EVENT> |
| Trigger Frequency | Real-time / Scheduled (e.g., daily at 02:00 AEST) / On-demand |
| Expected Volume | <NUMBER> messages/events per day |
| Peak Load | <NUMBER> messages/events per hour at peak |

---

## 5. Source System

| Field | Value |
|---|---|
| System Name | <SOURCE_SYSTEM_NAME> |
| System Type | ERP / CRM / API / Database / File / Message Queue |
| Data Format | JSON / XML / CSV / Flat File / EDI |
| Protocol | HTTPS / SFTP / AMQP / Database Query |
| Source Team | <SOURCE_TEAM_CONTACT> |
| Environment URLs | dev: <DEV_URL> / sit: <SIT_URL> / uat: <UAT_URL> / prd: <PRD_URL> |

### Source Data Description

> High-level description of the data sent from the source system.
> List the key business entities and their purpose. Detailed field mappings go in the TSD.

| Business Entity | Description | Key Fields |
|---|---|---|
| <ENTITY_NAME> | <ENTITY_DESCRIPTION> | <KEY_FIELD_LIST> |

---

## 6. Target System

| Field | Value |
|---|---|
| System Name | <TARGET_SYSTEM_NAME> |
| System Type | ERP / CRM / API / Database / File / Message Queue |
| Data Format | JSON / XML / CSV / Flat File / EDI |
| Protocol | HTTPS / SFTP / AMQP / Database Write |
| Target Team | <TARGET_TEAM_CONTACT> |
| Environment URLs | dev: <DEV_URL> / sit: <SIT_URL> / uat: <UAT_URL> / prd: <PRD_URL> |

### Target Data Description

> High-level description of the data expected by the target system.

| Business Entity | Description | Required Fields |
|---|---|---|
| <ENTITY_NAME> | <ENTITY_DESCRIPTION> | <REQUIRED_FIELD_LIST> |

---

## 7. Business Rules

> List all business rules that the integration must enforce. Number each rule.
> Rules here drive validation and transformation logic in the TSD and code.

| # | Rule | Source | Priority |
|---|---|---|---|
| BR-001 | <DESCRIBE_BUSINESS_RULE_1> | <STAKEHOLDER_OR_SYSTEM> | Must Have / Should Have / Nice to Have |
| BR-002 | <DESCRIBE_BUSINESS_RULE_2> | <STAKEHOLDER_OR_SYSTEM> | Must Have |
| BR-003 | <DESCRIBE_BUSINESS_RULE_3> | <STAKEHOLDER_OR_SYSTEM> | Should Have |

---

## 8. Data Scope and Filtering

> Describe any filtering, selection criteria, or data scope rules the interface must apply.
> For example: "Only process orders with status = CONFIRMED" or "Exclude cancelled lines."

| # | Filter / Scope Rule | Field | Condition |
|---|---|---|---|
| F-001 | <DESCRIBE_FILTER_1> | <FIELD_NAME> | <CONDITION, e.g., equals "ACTIVE"> |
| F-002 | <DESCRIBE_FILTER_2> | <FIELD_NAME> | <CONDITION> |

---

## 9. Error Scenarios (Business View)

> Describe what should happen from a business perspective when errors occur.
> Technical implementation of these scenarios goes in the TSD.

| # | Error Scenario | Expected Business Behaviour |
|---|---|---|
| E-001 | Source sends invalid or incomplete data | Reject message; notify source team via <CHANNEL> |
| E-002 | Target system is unavailable | Retry and alert operations team; do not lose message |
| E-003 | Transformation produces no output | Log and alert; do not silently drop message |
| E-004 | <ADDITIONAL_SCENARIO> | <EXPECTED_BEHAVIOUR> |

---

## 10. Acceptance Criteria

> Define the conditions that must be true for this interface to be accepted as complete.
> Use Given / When / Then or plain numbered statements.

| # | Acceptance Criterion | Test Approach |
|---|---|---|
| AC-001 | Given a valid <SOURCE_EVENT>, when the interface processes it, then the data appears in <TARGET_SYSTEM> within <LATENCY_SLA>. | System integration test |
| AC-002 | Given an invalid payload, when the interface receives it, then an error is logged and the source team is notified. | Negative test |
| AC-003 | Given the target system is unavailable, when the interface attempts delivery, then the message is not lost and delivery is retried. | Resilience test |
| AC-004 | <ADDITIONAL_CRITERION> | <TEST_APPROACH> |

---

## 11. Out of Scope

> List explicitly what this interface does NOT do, to prevent scope creep.

- <OUT_OF_SCOPE_ITEM_1>
- <OUT_OF_SCOPE_ITEM_2>
- <OUT_OF_SCOPE_ITEM_3>

---

## 12. Assumptions

> List any assumptions made during the creation of this FSD. Each assumption should be
> confirmed before development begins or flagged as a risk.

| # | Assumption | Risk if Wrong | Status |
|---|---|---|---|
| A-001 | <ASSUMPTION_1> | <RISK_DESCRIPTION> | Open / Confirmed |
| A-002 | <ASSUMPTION_2> | <RISK_DESCRIPTION> | Open |

---

## 13. Dependencies

| Dependency | Type | Owner | Status |
|---|---|---|---|
| <DEPENDENCY_1> | API / Service / Schema / Config | <OWNER_TEAM> | Available / Pending |
| <DEPENDENCY_2> | API / Service / Schema / Config | <OWNER_TEAM> | Pending |

---

## 14. Change History

| Version | Date | Author | Change Summary |
|---|---|---|---|
| 1.0 | <DATE> | <AUTHOR> | Initial draft |
