# Data Flow: <INTERFACE_NAME> (<INTERFACE_ID>)

## Diagram

```mermaid
flowchart LR
    Source(["<SOURCE_SYSTEM>"])
    Trigger["Logic App\n<WORKFLOW_NAME>"]
    Transform["Function App\n<FUNCTION_NAME>"]
    Target(["<TARGET_SYSTEM>"])
    DLQ[("Dead Letter\nQueue")]
    SMC["SMC\nAlert"]

    Source -->|"<EVENT / TRIGGER>"| Trigger
    Trigger -->|"Raw payload"| Transform
    Transform -->|"Transformed payload"| Target
    Trigger -.->|"Failure"| DLQ
    Transform -.->|"Error"| SMC
```

## Flow Description

| Step | Component | Action |
|---|---|---|
| 1 | <SOURCE_SYSTEM> | Sends `<EVENT_NAME>` to `<TRIGGER_ENDPOINT>` |
| 2 | Logic App `<WORKFLOW_NAME>` | Receives trigger, logs entry to SMC |
| 3 | Function App `<FUNCTION_NAME>` | Transforms payload (sort / map / filter) |
| 4 | Logic App `<WORKFLOW_NAME>` | Delivers result to `<TARGET_ENDPOINT>` |
| 5 | Logic App (error path) | Dead-letters message; fires SMC alert |
