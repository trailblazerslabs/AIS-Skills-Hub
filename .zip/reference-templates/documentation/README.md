# Documentation Templates

Markdown templates for AIS interface documentation artifacts.

| File | Use |
|---|---|
| `fsd.template.md` | **Functional Specification Document** — business rules, trigger events, acceptance criteria (mandatory before code generation) |
| `tsd.template.md` | **Technical Specification Document** — architecture pattern, field mappings, API contracts, NFRs, SMC logging (optional but recommended) |
| `spec.template.md` | Combined technical specification (lighter alternative to TSD) |
| `assumptions.template.md` | Assumption log |
| `data-flow.template.md` | Data flow diagram (Mermaid) |

Copy to `outputs/<InterfaceID>/` and replace every `<PLACEHOLDER>` value.

## Workflow

1. Complete **FSD** (`fsd.template.md`) — required before any code generation begins.
2. Optionally complete **TSD** (`tsd.template.md`) — adds field mappings and technical detail.
3. Run the `ais-design-intake` skill to parse both documents and produce a Design Intake Questionnaire.
4. Pass the intake summary to `ais-logicapp-codegen`, `ais-functionapp-codegen`, or `ais-datafactory-codegen`.
