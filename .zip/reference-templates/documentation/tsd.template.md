# Technical Specification Document (TSD)
## <INTERFACE_NAME> — <INTERFACE_ID>

---

| Field | Value |
|---|---|
| Interface ID | <INTERFACE_ID> |
| Interface Name | <INTERFACE_NAME> |
| FSD Reference | [FSD — <INTERFACE_ID>](fsd.md) |
| Author | <AUTHOR> |
| Date | <DATE> |
| Version | 1.0 |
| Status | Draft / Review / Approved |
| Reviewed By | <REVIEWER> |
| Approved By | <APPROVER> |

---

## 1. Architecture Pattern

| Field | Value |
|---|---|
| Approved Pattern | Logic App Standard only / Logic App Standard + Function App / ADF / ADF + Logic App |
| Pattern Rationale | <WHY_THIS_PATTERN_WAS_CHOSEN> |
| NFR Reference | Approved NFR recommendation dated <DATE> |
| Trigger Type | HTTP / Service Bus Topic / Timer / Blob Storage |
| Processing Style | Synchronous / Asynchronous / Batch |

### Component Diagram

```mermaid
flowchart LR
    Source([<SOURCE_SYSTEM>]) -->|<PROTOCOL>| Trigger[Logic App Trigger\n<WORKFLOW_NAME>]
    Trigger --> Transform[<TRANSFORM_STEP\ne.g. Function App / inline action>]
    Transform --> Target([<TARGET_SYSTEM>])
    Trigger -.->|Error| DLQ[Dead Letter Queue\n<DLQ_NAME>]
    Transform -.->|Error| SMC[SMC Alert]
```

---

## 2. Azure Components

| Component | Azure Resource Type | Resource Name | Resource Group | Notes |
|---|---|---|---|---|
| Workflow | Logic App Standard | `<LOGIC_APP_NAME>` | `<RESOURCE_GROUP>` | Hosts all workflows for this interface |
| Transformation | Function App (co-located) | `<FUNCTION_PROJECT_NAME>` | — | Co-located in Logic App workspace |
| Message Queue | Azure Service Bus | `<SERVICEBUS_NAMESPACE>` | `<RESOURCE_GROUP>` | Trigger topic/queue |
| Storage | Azure Blob Storage | `<STORAGE_ACCOUNT_NAME>` | `<RESOURCE_GROUP>` | For blob triggers or large payloads |
| API Gateway | Azure API Management | `<APIM_NAME>` | `<RESOURCE_GROUP>` | If HTTP trigger is exposed externally |

---

## 3. Workflow Design

### 3.1 Workflow Name and Location

| Field | Value |
|---|---|
| Workflow Name | `<WorkflowName>` |
| File Path | `LogicApp/<WorkflowName>/workflow.json` |
| Trigger | <HTTP \| ServiceBusTrigger \| Recurrence \| BlobCreated> |
| Trigger Endpoint / Topic | `<ENDPOINT_OR_TOPIC_NAME>` |

### 3.2 Action Chain

> List each action in order. Every non-first action must declare `runAfter`.

| Step | Action Name | Action Type | Description | runAfter |
|---|---|---|---|---|
| 1 | `Log_Interface_Start` | HTTP / SMC Log | Log entry point; capture correlationId, payloadSize | Trigger |
| 2 | `Parse_Input` | Parse JSON | Parse and validate source payload | `Log_Interface_Start` |
| 3 | `<TRANSFORM_ACTION>` | Call Function / Compose | Apply business rules; call Function App if required | `Parse_Input` |
| 4 | `Call_Target` | HTTP / Service Bus Send | Send transformed payload to target | `<TRANSFORM_ACTION>` |
| 5 | `Log_Interface_End` | SMC Log | Log success; duration; item count | `Call_Target` |
| 6 | `Log_Interface_Error` | SMC Log | Log failure; error message; raw payload | Failed path |

### 3.3 App Settings Keys

| Key Name | Environment | Description |
|---|---|---|
| `<KEY_NAME_1>` | All | <DESCRIPTION> |
| `<SERVICEBUS_CONNECTION_KEY>` | All | Service Bus namespace connection for trigger/send |
| `<TARGET_API_URL_KEY>` | Per environment | Target system base URL |
| `<SMC_QUEUE_KEY>` | Per environment | SMC log queue connection string |

---

## 4. Function App Design

> Complete this section only if the approved architecture includes a local transformation function.
> If the pattern is Logic App Standard only, mark this section as N/A.

### 4.1 Function Details

| Field | Value |
|---|---|
| Function Name | `<InterfaceName>Function` |
| Project | Existing `Function/` project in reference workspace |
| Namespace | `<ROOT_NAMESPACE>.<INTERFACE_AREA>` |
| Trigger | HTTP (called from Logic App action) |
| Returns | `TransformationOutput<T>` envelope |

### 4.2 Transformation Logic

| Transformation | Description | Input Field(s) | Output Field(s) |
|---|---|---|---|
| <TRANSFORM_1> | <DESCRIPTION, e.g., Sort lines by StoreNumber ascending> | <INPUT_FIELDS> | <OUTPUT_FIELDS> |
| <TRANSFORM_2> | <DESCRIPTION, e.g., Group header + lines by OrderNumber> | <INPUT_FIELDS> | <OUTPUT_FIELDS> |
| <TRANSFORM_3> | <DESCRIPTION, e.g., Map source status code to target status string> | <SOURCE_STATUS> | <TARGET_STATUS> |

### 4.3 File Structure

```
outputs/<INTERFACE_ID>/Function/
└── <InterfaceName>/
    ├── <InterfaceName>Function.cs
    ├── Models/
    │   ├── <InterfaceName>Input.cs
    │   └── <InterfaceName>Output.cs
    └── Services/
        └── <InterfaceName>Transformer.cs
```

---

## 5. ADF Pipeline Design

> Complete this section only if the approved architecture includes Azure Data Factory.
> If the pattern does not use ADF, mark this section as N/A.

### 5.1 Pipeline Overview

| Field | Value |
|---|---|
| Pipeline Name | `pl_<domain>_<source>_to_<target>_<description>` |
| Integration Runtime | AutoResolveIntegrationRuntime / `<SELF_HOSTED_IR_NAME>` |
| Trigger Type | Schedule / Tumbling Window / Storage Event / Manual |
| Trigger Schedule | `<CRON_EXPRESSION_OR_DESCRIPTION>` |

### 5.2 Pipeline Steps

| Step | Activity Name | Activity Type | Source Dataset | Sink Dataset | Description |
|---|---|---|---|---|---|
| 1 | `<ACTIVITY_NAME_1>` | Copy / Lookup / ForEach | `<SOURCE_DS>` | `<SINK_DS>` | <DESCRIPTION> |
| 2 | `<ACTIVITY_NAME_2>` | Copy / Stored Procedure | — | `<SINK_DS>` | <DESCRIPTION> |

### 5.3 Linked Services

| Name | Type | Authentication | Resource |
|---|---|---|---|
| `ls_<source_name>` | Azure Blob / SQL / REST | Managed Identity | `<RESOURCE_NAME>` |
| `ls_<target_name>` | Azure Blob / SQL / REST | Managed Identity | `<RESOURCE_NAME>` |

### 5.4 Datasets

| Name | Linked Service | Format | Container / Table | Parameters |
|---|---|---|---|---|
| `ds_<source_name>` | `ls_<source_name>` | JSON / CSV / Parquet | `<CONTAINER_OR_TABLE>` | `folderPath`, `fileName` |
| `ds_<target_name>` | `ls_<target_name>` | JSON / CSV / Parquet | `<CONTAINER_OR_TABLE>` | `folderPath`, `fileName` |

---

## 6. Field Mapping

> This is the authoritative field mapping table. Every source field that appears in the output
> must have a row here. Reference the FSD business rules (BR-NNN) where applicable.

| # | Source Field | Source Type | Target Field | Target Type | Transformation | Business Rule | Notes |
|---|---|---|---|---|---|---|---|
| 1 | `<sourceField1>` | string | `<targetField1>` | string | Direct copy | — | |
| 2 | `<sourceField2>` | decimal | `<targetField2>` | string | Format as `#,##0.00` | BR-001 | |
| 3 | `<sourceField3>` | string | `<targetField3>` | string | Map via lookup table | BR-002 | See mapping table below |
| 4 | `<sourceField4>` | datetime | `<targetField4>` | string | Format `yyyy-MM-ddTHH:mm:ssZ` | — | UTC always |
| 5 | — | — | `<derivedField>` | string | Set to hardcoded value `"<VALUE>"` | BR-003 | No source equivalent |

### 6.1 Code / Status Value Mapping

| Source Value | Target Value | Description |
|---|---|---|
| `<SRC_VALUE_1>` | `<TGT_VALUE_1>` | <DESCRIPTION> |
| `<SRC_VALUE_2>` | `<TGT_VALUE_2>` | <DESCRIPTION> |

---

## 7. API Contracts

### 7.1 Source Payload Schema (Inbound)

```json
{
  "<rootElement>": {
    "<field1>": "<string>",
    "<field2>": 0,
    "<nestedArray>": [
      {
        "<arrayField1>": "<string>",
        "<arrayField2>": "<string>"
      }
    ]
  }
}
```

### 7.2 Target Payload Schema (Outbound)

```json
{
  "<rootElement>": {
    "<targetField1>": "<string>",
    "<targetField2>": 0,
    "<targetArray>": [
      {
        "<targetArrayField1>": "<string>",
        "<targetArrayField2>": "<string>"
      }
    ]
  }
}
```

### 7.3 Target API Endpoint (if HTTP delivery)

| Field | Value |
|---|---|
| Method | POST / PUT / PATCH |
| URL | `@{parameters('<TARGET_URL_PARAM>')}/<path>` |
| Auth | Managed Identity / API Key (stored in Key Vault) / OAuth2 |
| Success Response | HTTP 200 / 201 |
| Error Response | HTTP 4xx / 5xx → trigger retry / dead-letter |

---

## 8. Non-Functional Requirements

| Dimension | Requirement | Source (FSD / NFR) |
|---|---|---|
| Payload size | Typical <SIZE>; max <MAX_SIZE> per message | FSD §4 |
| Daily volume | <NUMBER> messages/day | FSD §4 |
| Peak throughput | <NUMBER> messages/minute at peak | FSD §4 |
| Latency SLA | End-to-end < <SECONDS> seconds | FSD §10 AC-001 |
| Reliability | At-least-once delivery | FSD §9 E-002 |
| Retention (DLQ) | <DAYS> days before discard | FSD §9 E-002 |
| Availability | 99.9% uptime target | Platform SLA |

---

## 9. Error Handling

| Scenario | Detection | Action | Alert |
|---|---|---|---|
| Invalid / malformed payload | Schema validation failure | Return HTTP 400; log to SMC; do not forward | No — bad data is caller's problem |
| Target unavailable (HTTP 5xx) | HTTP response code | Retry 3× with 30s exponential back-off; dead-letter after final failure | Yes — SMC alert `<ALERT_NAME>` |
| Target unavailable (timeout) | HTTP timeout > 30s | Same retry/dead-letter as above | Yes |
| Transformation error | Unhandled exception in Function App | Return HTTP 500; log full stack trace to SMC; dead-letter source message | Yes |
| Service Bus DLQ threshold | >10 messages in DLQ | SMC alert fires | Yes — SMC alert `<DLQ_ALERT_NAME>` |

### Retry Policy

| Setting | Value |
|---|---|
| Retry count | 3 |
| Retry interval | 30 seconds |
| Back-off type | Exponential |
| Max delay | 5 minutes |

---

## 10. Observability (SMC Logging)

> All logging uses the SMC (Metcash Service Management Centre) structured log format.
> Every Logic App workflow must log at minimum: Entry, ExitSuccess, and ExitFailure.

| Log Point | Stage | Action Name | Fields Logged |
|---|---|---|---|
| Workflow entry | Entry | `Log_Interface_Start` | interfaceId, correlationId, payloadSizeBytes, sourceSystem |
| Transform complete | Transform | `Log_Transform_Complete` | interfaceId, itemCount, transformDurationMs |
| Target call success | Exit | `Log_Interface_End` | interfaceId, totalDurationMs, targetStatusCode |
| Any failure | Error | `Log_Interface_Error` | interfaceId, errorMessage, errorCode, rawPayload (truncated) |
| DLQ message | Error | `Log_DLQ_Message` | interfaceId, messageId, failureReason |

### SMC Queue Names

| Environment | Queue Name |
|---|---|
| SIT | `<SMC_QUEUE_SIT>` |
| UAT | `<SMC_QUEUE_UAT>` |
| PPD | `<SMC_QUEUE_UAT>` (PPD maps to UAT SMC) |
| PRD | `<SMC_QUEUE_PRD>` |

---

## 11. Security

| Requirement | Implementation |
|---|---|
| Service-to-service auth | Managed Identity — no connection strings or keys in config |
| Secrets storage | Azure Key Vault — reference via `@Microsoft.KeyVault(...)` in app settings |
| Inbound HTTP auth | SAS token / Managed Identity / APIM subscription key |
| Data in transit | TLS 1.2 minimum on all connections |
| PII handling | <DESCRIBE_PII_FIELDS_AND_MASKING_STRATEGY_OR_N/A> |
| OWASP Top 10 | Input validated at workflow entry; no SQL / expression injection paths |

---

## 12. Deployment Configuration

### 12.1 ADO Pipeline Reference

| Pipeline | File | Variable Group |
|---|---|---|
| CI build | `<YAML_FILE_PATH>` | `vg-<domain>-<env>` |
| CD deploy | `<YAML_FILE_PATH>` | `vg-<domain>-<env>` |

### 12.2 Environment App Settings

| Setting Key | DEV | SIT | UAT | PRD |
|---|---|---|---|---|
| `<KEY_NAME_1>` | `<DEV_VALUE>` | `<SIT_VALUE>` | `<UAT_VALUE>` | `<PRD_VALUE>` |
| `<TARGET_URL_KEY>` | `<DEV_URL>` | `<SIT_URL>` | `<UAT_URL>` | `<PRD_URL>` |

---

## 13. Test Scenarios

> High-level technical test scenarios. Detailed test cases go in `unit-test-cases.csv`.

| # | Scenario | Input | Expected Output | Type |
|---|---|---|---|---|
| T-001 | Happy path — valid payload | Sample JSON matching source schema | Payload delivered to target; HTTP 200 returned | Happy path |
| T-002 | Invalid payload — missing required field | JSON missing `<REQUIRED_FIELD>` | HTTP 400; SMC error logged; message not forwarded | Negative |
| T-003 | Target unavailable — first attempt | Valid payload; target returns HTTP 503 | Retry triggered; no data loss | Resilience |
| T-004 | Empty collection | Valid payload with empty `<ARRAY_FIELD>` | Interface handles gracefully; no NullRef; logged | Edge case |
| T-005 | <ADDITIONAL_SCENARIO> | <INPUT> | <EXPECTED_OUTPUT> | <TYPE> |

---

## 14. Assumptions

| # | Assumption | Risk if Wrong | Status |
|---|---|---|---|
| A-001 | <TECHNICAL_ASSUMPTION_1> | <RISK> | Open / Confirmed |
| A-002 | <TECHNICAL_ASSUMPTION_2> | <RISK> | Open |

---

## 15. Change History

| Version | Date | Author | Change Summary |
|---|---|---|---|
| 1.0 | <DATE> | <AUTHOR> | Initial draft |
