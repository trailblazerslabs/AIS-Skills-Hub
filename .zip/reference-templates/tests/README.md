# Test Templates

CSV template for AIS unit test cases.

| File | Use |
|---|---|
| `unit-test-cases.template.csv` | Test case matrix for Logic App, Function App, and ADF interfaces |

Copy to `outputs/<InterfaceID>/unit-test-cases.csv`, fill in all `<PLACEHOLDER>` values,
and add rows for happy path, error path, boundary, and business logic scenarios.
