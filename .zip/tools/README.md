# SMC DEV Issues

Fetches matching DEV failure-handling records for an interface ID through an authenticated Edge session. It optionally filters the POST `/api/failure-handling` request by an Observation ID, then GETs `/api/failure-handling?Id=<id>` for each returned item to capture full error details. Detail GETs run with a maximum concurrency of five. A completed export includes a `trace` summary grouped by Observation ID. This is an SMC failure-record trace only; successful runtime hops require their own telemetry. It uses a tested 100-record page size and a 5000-page safety limit; completion is based on a short filtered page, not `totalCount` (which may not be interface-filtered). An incomplete export or any failed detail GET exits with a nonzero status. It does not read, print, or persist cookies; the browser sends its own session automatically. Results are written to `%USERPROFILE%\smc-issues`.

The `ai_user` cookie shown in the browser's cURL example is empty (`ai_user=`) and is not needed for authentication. Do not copy cookies into the script or share session-cookie values.

## One-time Edge setup

Edge must be started with remote debugging enabled. A normal Edge process cannot be attached to after it has started. Close Edge, then start it with:

```powershell
$edge = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
& $edge --remote-debugging-port=9222
```

Sign in to SMC in that Edge session if prompted. Keep that Edge process open while running the fetch command. The script never terminates Edge.

Some current Edge versions only allow remote debugging with a non-default user-data directory. If Edge rejects the command above, use a dedicated persistent profile instead:

```powershell
$edge = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
$profile = Join-Path $env:LOCALAPPDATA 'SMC-Issues-Edge'
& $edge --remote-debugging-port=9222 "--user-data-dir=$profile"
```

That profile requires a one-time SMC sign-in; later runs reuse its session until it expires.

## Install and run

From the repository root:

```powershell
npm --prefix tools install
npm --prefix tools run fetch -- EAII-367
```

To scope the list to one Observation ID, pass it after the interface ID:

```powershell
npm --prefix tools run fetch -- EAII-367 22998012-4afa-4866-9520-5e26f86f2447
```

The script opens the DEV failure-handling page in a new Edge tab, calls the confirmed same-origin POST endpoint, and saves matching records plus page counts under `%USERPROFILE%\smc-issues`. If the API returns `401` or `403`, complete sign-in in the opened tab and press Enter in the terminal; the failed page is then retried.

For a bounded diagnostic run, set `SMC_MAX_PAGES=1` in PowerShell before running the fetch command. The output still contains the API's reported total and marks the result incomplete if additional pages remain. `SMC_PAGE_SIZE` can override the default page size; 100 was accepted during validation.

The output's `trace` contains `observationId`, `interfaceId`, `environment`, `complete`, and
`events` with error time, stage, SMC record ID, resource/run identifiers, message, exception, and
log fields. For example:

```json
{
	"trace": {
		"observationId": "22998012-4afa-4866-9520-5e26f86f2447",
		"interfaceId": "EAII-367",
		"environment": "Dev",
		"scope": "SMC failure-handling records only; successful runtime hops require their own telemetry.",
		"complete": true,
		"eventCount": 1,
		"events": [
			{
				"observationId": "22998012-4afa-4866-9520-5e26f86f2447",
				"errorDate": "2026-10-12T12:45:23Z",
				"stageName": "Blob Upload Operation Failed",
				"recordId": 10998810,
				"resourceType": "Azure APIM",
				"resourceRunId": "22998012-4afa-4866-9520-5e26f86f2447",
				"message": "<payload reference>",
				"exceptionMessage": "<error details>",
				"logMessage": "<stage status details>"
			}
		]
	}
}
```