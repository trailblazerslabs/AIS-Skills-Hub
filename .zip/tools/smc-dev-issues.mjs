import { mkdir, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { chromium } from 'playwright-core';

const interfaceId = process.argv[2]?.toUpperCase();
const observationId = process.argv[3] ?? null;
const cdpPort = process.env.SMC_EDGE_CDP_PORT ?? '9222';
const smcOrigin = 'https://t3-met-smcui-dev-ae-webapp.met-ase-dev-ae-ase01.appserviceenvironment.net';

if (!interfaceId || !/^EAII-\d+$/.test(interfaceId)) {
  console.error('Usage: npm run fetch -- EAII-367 [observation-id]');
  process.exit(2);
}
if (observationId && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(observationId)) {
  console.error('The optional observation-id must be a GUID.');
  process.exit(2);
}

let browser;
try {
  browser = await chromium.connectOverCDP(`http://127.0.0.1:${cdpPort}`);
} catch {
  console.error(`Could not attach to Edge on port ${cdpPort}. Start Edge with remote debugging enabled, then retry.`);
  console.error('See tools/README.md for the one-time setup. This script will not close or restart Edge.');
  process.exit(1);
}

const context = browser.contexts()[0];
if (!context) {
  console.error('No Edge browser context is available on the remote debugging connection.');
  process.exit(1);
}

const page = await context.newPage();
const targetUrl = new URL('/failure-handling', smcOrigin);
targetUrl.searchParams.set('interfaceId', interfaceId);
targetUrl.searchParams.set('environment', 'Dev');
if (observationId) targetUrl.searchParams.set('observationId', observationId);
const pageSize = Number.parseInt(process.env.SMC_PAGE_SIZE ?? '100', 10);
const maxPages = Number.parseInt(process.env.SMC_MAX_PAGES ?? '5000', 10);

if (!Number.isInteger(pageSize) || pageSize < 1 || !Number.isInteger(maxPages) || maxPages < 1) {
  console.error('SMC_PAGE_SIZE and SMC_MAX_PAGES must be positive integers.');
  process.exit(2);
}

try {
  await page.goto(targetUrl.href, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

  if (new URL(page.url()).origin !== smcOrigin) {
    const prompt = readline.createInterface({ input: stdin, output: stdout });
    await prompt.question('Complete sign-in in the Edge tab, then press Enter here. ');
    prompt.close();
    await page.goto(targetUrl.href, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
  }

  const listRecords = new Map();
  const detailedRecords = new Map();
  const pages = [];
  let reachedLastPage = false;
  let repeatedPage = false;
  let detailFailures = 0;
  let responseShape;
  let reportedTotalCount;

  for (let pageNumber = 1; pageNumber <= maxPages; pageNumber += 1) {
    console.log(`Requesting DEV issues page ${pageNumber}...`);
    let result = await requestIssuesPage(page, pageNumber, pageSize, interfaceId, observationId);
    if (!result.ok && (result.status === 401 || result.status === 403)) {
      const prompt = readline.createInterface({ input: stdin, output: stdout });
      await prompt.question('Complete SMC sign-in in the Edge tab, then press Enter here. ');
      prompt.close();
      await page.goto(targetUrl.href, { waitUntil: 'domcontentloaded', timeout: 60000 });
      await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
      result = await requestIssuesPage(page, pageNumber, pageSize, interfaceId, observationId);
    }
    if (!result.ok) {
      throw new Error(`SMC API returned HTTP ${result.status}: ${result.error}`);
    }

    if (pageNumber === 1) {
      responseShape = getResponseShape(result.data);
      reportedTotalCount = findTotalCount(result.data);
      console.log(`API response shape: ${JSON.stringify(responseShape)}`);
      if (reportedTotalCount !== undefined) console.log(`API reports ${reportedTotalCount} total record(s).`);
    }

    const pageRecords = collectMatchingRecords(result.data, interfaceId, observationId);
    const recordsBeforePage = listRecords.size;
    for (const record of pageRecords) {
      const recordId = getRecordId(record);
      if (recordId === undefined) throw new Error('A list item did not contain a numeric id.');
      listRecords.set(String(recordId), record);
    }
    const newRecords = listRecords.size - recordsBeforePage;
    if (newRecords === 0 && pageRecords.length >= pageSize) {
      repeatedPage = true;
      pages.push({ pageNumber, status: result.status, returnedRecords: pageRecords.length, newRecords, detailsFetched: 0 });
      break;
    }

    let detailResults = await fetchPageDetails(page, pageRecords);
    logDetailResponseSummary(detailResults);
    if (detailResults.some(detail => detail.status === 401 || detail.status === 403)) {
      await promptForSignIn(page, targetUrl);
      detailResults = await fetchPageDetails(page, pageRecords);
      logDetailResponseSummary(detailResults);
    }

    let pageDetailFailures = 0;
    for (let index = 0; index < pageRecords.length; index += 1) {
      const listRecord = pageRecords[index];
      const recordId = getRecordId(listRecord);
      const detailResult = detailResults[index];
      const detailPayload = detailResult.data?.data;
      const detailSucceeded = detailResult.ok && detailResult.data?.success === true &&
        detailPayload !== null && typeof detailPayload === 'object';
      if (!detailSucceeded) {
        pageDetailFailures += 1;
        detailedRecords.set(String(recordId), {
          id: recordId,
          listRecord,
          detailStatus: detailResult.status,
          detailResponse: detailResult.data,
          detailError: detailResult.error || detailResult.data?.message || 'Detail response was unsuccessful.'
        });
        continue;
      }

      detailedRecords.set(String(recordId), {
        id: recordId,
        listRecord,
        detailStatus: detailResult.status,
        detailResponse: detailResult.data
      });
    }
    detailFailures += pageDetailFailures;
    pages.push({
      pageNumber,
      status: result.status,
      returnedRecords: pageRecords.length,
      newRecords,
      detailsFetched: pageRecords.length - pageDetailFailures,
      detailFailures: pageDetailFailures
    });

    if (pageRecords.length < pageSize) {
      reachedLastPage = true;
      break;
    }
  }

  const outputDirectory = path.join(os.homedir(), 'smc-issues');
  await mkdir(outputDirectory, { recursive: true });
  const outputPath = path.join(outputDirectory, `${interfaceId}-DEV-${new Date().toISOString().replaceAll(':', '-')}.json`);
  const complete = reachedLastPage && !repeatedPage && detailFailures === 0;
  await writeFile(outputPath, `${JSON.stringify({
    interfaceId,
    observationId,
    environment: 'Dev',
    pageUrl: targetUrl.href,
    capturedAt: new Date().toISOString(),
    paginationComplete: reachedLastPage,
    complete,
    repeatedPage,
    reportedTotalCount,
    responseShape,
    pages,
    totalRecords: detailedRecords.size,
    detailFailures,
    trace: buildObservationTrace(interfaceId, observationId, detailedRecords, complete),
    records: [...detailedRecords.values()]
  }, null, 2)}\n`, 'utf8');

  console.log(`Fetched details for ${detailedRecords.size} DEV record(s) across ${pages.length} page(s); detail failures: ${detailFailures}.`);
  console.log(`Saved: ${outputPath}`);
  if (!complete) {
    console.error(repeatedPage
      ? 'The API repeated a page; saved records may be incomplete. See response shape metadata in the output.'
      : detailFailures > 0
        ? 'One or more detail requests failed or did not match; the output is incomplete.'
        : `Stopped after ${maxPages} page(s); saved records may be incomplete.`);
    process.exitCode = 1;
  }
} finally {
  await page.close().catch(() => {});
  await browser.close().catch(() => {});
}

async function requestIssuesPage(page, pageNumber, pageSize, targetInterfaceId, targetObservationId) {
  const payload = {
    Pagination: {
      PageNumber: pageNumber,
      PageSize: pageSize,
      OrderColumn: null,
      OrderDirection: 'desc'
    },
    DateRange: null,
    Environment: 'Dev',
    BusinessProcessIds: null,
    ApplicationIds: null,
    InterfaceIds: null,
    ReferenceKeys: null,
    Tags: null,
    ObservationId: targetObservationId,
    ErrorCode: null,
    SearchTerm: null,
    GroupingId: null,
    CorrelationProperties: null,
    StageName: null,
    IncidentNumber: null,
    InterfaceName: null,
    InterfaceDataStore: null,
    InterfaceType: null,
    BusinessProcessName: null,
    InterfaceId: targetInterfaceId
  };

  return page.evaluate(async ({ endpoint, requestBody }) => {
    let response;
    try {
      response = await fetch(endpoint, {
        method: 'POST',
        credentials: 'include',
        headers: { accept: '*/*', 'content-type': 'application/json' },
        body: JSON.stringify(requestBody),
        signal: AbortSignal.timeout(30000)
      });
    } catch (error) {
      return { ok: false, status: 0, data: null, error: error.message };
    }
    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
    return {
      ok: response.ok,
      status: response.status,
      data,
      error: data === null ? text.slice(0, 300) : ''
    };
  }, { endpoint: `${smcOrigin}/api/failure-handling`, requestBody: payload });
}

async function fetchPageDetails(page, pageRecords) {
  const results = Array(pageRecords.length);
  let nextIndex = 0;
  const workers = Array.from({ length: Math.min(5, pageRecords.length) }, async () => {
    while (nextIndex < pageRecords.length) {
      const index = nextIndex;
      nextIndex += 1;
      const recordId = getRecordId(pageRecords[index]);
      results[index] = await requestFailureDetail(page, recordId);
    }
  });
  await Promise.all(workers);
  return results;
}

function logDetailResponseSummary(results) {
  const summary = new Map();
  for (const result of results) {
    const shape = getResponseShape(result.data).type;
    const key = `${result.status}:${shape}`;
    summary.set(key, (summary.get(key) ?? 0) + 1);
  }
  console.log(`GET detail response summary: ${JSON.stringify(Object.fromEntries(summary))}`);
  const firstObject = results.find(result => result.data && typeof result.data === 'object')?.data;
  if (firstObject && !Array.isArray(firstObject)) {
    console.log(`GET detail response keys: ${JSON.stringify(Object.keys(firstObject))}`);
  }
}

async function requestFailureDetail(page, recordId) {
  return page.evaluate(async ({ endpoint }) => {
    let response;
    try {
      response = await fetch(endpoint, {
        method: 'GET',
        credentials: 'include',
        headers: { accept: '*/*' },
        signal: AbortSignal.timeout(30000)
      });
    } catch (error) {
      return { ok: false, status: 0, data: null, error: error.message };
    }
    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
    return {
      ok: response.ok,
      status: response.status,
      data,
      error: data === null ? text.slice(0, 300) : ''
    };
  }, { endpoint: `${smcOrigin}/api/failure-handling?Id=${encodeURIComponent(recordId)}` });
}

async function promptForSignIn(page, targetUrl) {
  const prompt = readline.createInterface({ input: stdin, output: stdout });
  await prompt.question('Complete SMC sign-in in the Edge tab, then press Enter here. ');
  prompt.close();
  await page.goto(targetUrl.href, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
}

function collectMatchingRecords(data, targetInterfaceId, targetObservationId) {
  const records = new Map();
  visit(data, value => {
    if (!isRecordForInterface(value, targetInterfaceId, targetObservationId)) return;
    const serialized = JSON.stringify(value);
    records.set(serialized, value);
  });
  return [...records.values()];
}

function getResponseShape(data) {
  if (Array.isArray(data)) return { type: 'array', length: data.length };
  if (data && typeof data === 'object') {
    return {
      type: 'object',
      keys: Object.keys(data),
      itemsCount: Array.isArray(data.items) ? data.items.length : undefined,
      pageNumber: data.pageNumber,
      pageSize: data.pageSize,
      totalCount: data.totalCount
    };
  }
  return { type: data === null ? 'null' : typeof data };
}

function findTotalCount(data) {
  let total;
  visit(data, value => {
    if (total !== undefined) return;
    const entry = Object.entries(value).find(([key, item]) =>
      ['TOTALCOUNT', 'TOTALRECORDS', 'TOTALITEMS', 'RECORDCOUNT'].includes(
        key.toUpperCase().replaceAll(/[^A-Z]/g, '')
      ) && Number.isFinite(Number(item)));
    if (entry) total = Number(entry[1]);
  });
  return total;
}

function isRecordForInterface(value, targetInterfaceId, targetObservationId = null) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const entries = Object.entries(value);
  const interfaceMatches = entries.some(([key, item]) =>
    key.toUpperCase().replaceAll(/[^A-Z]/g, '').includes('INTERFACEID') &&
    String(item).toUpperCase() === targetInterfaceId);
  const environment = entries.find(([key]) =>
    key.toUpperCase().replaceAll(/[^A-Z]/g, '') === 'ENVIRONMENT')?.[1];
  const recordObservationId = entries.find(([key]) =>
    key.toUpperCase().replaceAll(/[^A-Z]/g, '') === 'OBSERVATIONID')?.[1];

  return interfaceMatches && (environment === undefined || String(environment).toUpperCase() === 'DEV') &&
    (!targetObservationId || String(recordObservationId).toLowerCase() === targetObservationId.toLowerCase());
}

function buildObservationTrace(targetInterfaceId, targetObservationId, records, complete) {
  const entries = [...records.values()];
  return {
    observationId: targetObservationId,
    interfaceId: targetInterfaceId,
    environment: 'Dev',
    scope: 'SMC failure-handling records only; successful runtime hops require their own telemetry.',
    complete,
    eventCount: entries.length,
    events: entries.map(record => {
      const listRecord = record.listRecord;
      const detail = record.detailResponse?.data ?? {};
      return {
        observationId: listRecord.observationId ?? targetObservationId,
        errorDate: listRecord.errorDate ?? null,
        stageName: listRecord.stageName ?? null,
        status: listRecord.queueStatus ?? null,
        recordId: record.id,
        resourceType: detail.resourceType ?? listRecord.resourceType ?? null,
        resourceName: detail.resourceName ?? null,
        resourceRunId: detail.resourceRunID ?? listRecord.resourceRunID ?? null,
        message: detail.message ?? null,
        exceptionMessage: detail.exceptionMessage ?? null,
        logMessage: detail.logMessage ?? null
      };
    })
  };
}

function visit(value, callback) {
  if (Array.isArray(value)) {
    for (const item of value) visit(item, callback);
    return;
  }
  if (!value || typeof value !== 'object') return;
  callback(value);
  for (const item of Object.values(value)) visit(item, callback);
}

function getRecordId(record) {
  return Object.entries(record).find(([key, value]) =>
    key.toUpperCase().replaceAll(/[^A-Z]/g, '') === 'ID' && value !== null && value !== undefined)?.[1];
}

