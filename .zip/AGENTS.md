# AGENTS.md — Metcash AIS Azure Integration Skills Hub

Template for configuring AI coding agent behavior in Metcash AIS projects.
Copy this file to your project root and adjust the active skills for your task.

---

## What's Inside This Repository

| Asset | Count | Description |
|---|---|---|
| Skills | 24 | Domain-specific knowledge for AIS Azure Integration development, incl. TSD generation, codegen readiness, SMC failure retrieval, test execution/results, and "way of working" ADO/CLI skills |
| Squad 20 Skills | 9 | Engineering domain knowledge from Squad 20 repo scan (ADO work-items/PR conventions moved into `.github/skills/`) |
| Agent Personas | 0 (archived) | Superseded by the skills above — see `archive/github-agents-superseded-by-skills/` |
| Prompts | 13 | Slash-command prompt templates (`.github/prompts/*.prompt.md`) for SDLC and review tasks |
| TIBCO Skills | 3 | TIBCO-to-Azure conversion workflow (NFR → Converter → Deployment) |
| MCP Config | 1 | `.vscode/mcp.json` pre-configured with 6 MCP servers |
| Review Gates | 1 corpus | `review-gates/README.md` indexes approved evidence and scored human review gates |

---

## Skill Catalog

### AIS Integration Skills

| Skill | Trigger | Description |
|---|---|---|
| `ais-design-intake` | "no TSD and none will be generated", "skip TSD generation" | **No-TSD EXCEPTION path only** — use ONLY after the user explicitly confirms no TSD will ever be produced for this interface. The default for every new interface is `metcash-tsd-generator` → `ais-codegen-readiness`. Fetches FSD via Atlassian MCP, infers technical decisions, produces Design Intake Questionnaire |
| `metcash-tsd-generator` | "create a TSD", "generate a technical specification", "produce TSD from FSD" | Generates the full §1–§15 TSD from FSD + Mapping + Mapping Manifest + walkthrough transcript |
| `ais-codegen-readiness` | "ready to generate code", "codegen readiness", "resolve repo and resource name" | **TSD-exists path** — resolves repo/resource name/field-mapping/TIBCO cross-check; replaces `ais-design-intake` once a TSD exists |
| `ais-documentation` | "generate documentation", "create spec", "interface spec" | Generate technical specs, data flow docs, assumption logs |
| `ais-logicapp-codegen` | "generate logic app", "create workflow", "logic app code" | Generate Logic App Standard assets; always run production checker + `origin/main` comparison and record code-quality report |
| `ais-functionapp-codegen` | "generate function app", "create function", "transformation code" | Generate C# .NET 10 Function App transformation code |
| `ais-datafactory-codegen` | "generate ADF", "data factory pipeline", "ADF pipeline" | Generate Azure Data Factory pipelines, datasets, linked services |
| `ais-unit-test-cases` | "generate test cases", "unit test", "test scenarios" | Prepare coverage intake and stop for approval before CSV; separate approval before ADO Test Plan/Suites/Cases |
| `ais-test-execution` | "run the unit tests", "execute test cases", "trigger a test run" | Fire each test case against a deployed non-prod resource (Azure CLI/HTTP), capture the real outcome |
| `ais-test-results-to-ado` | "record test results", "upload results to ado", "close the test run" | Record outcomes against the existing ADO Test Plan, complete the run, comment on the work item |
| `ais-code-review` | "code review", "review my workflow", "validate my code" | Review Logic Apps, Function Apps, and ADF against AIS standards |
| `ais-deployment-runsheet` | "deployment runsheet", "runsheet", "how to deploy", "deployment checklist" | Create/update Confluence runsheets via Atlassian MCP; validate pipelines via ADO MCP |
| `ais-runsheet-review` | "review this runsheet", "runsheet quality review", "check runsheet against TSD and code" | Review existing runsheets against the approved TSD, refreshed code/pipeline evidence, and deployment checklist |
| `ais-debug-azure` | "debug", "investigate failure", "logic app failed", "diagnose", "troubleshoot" | Investigate Logic App / Function App / ADF / Service Bus failures; produces diagnosis report |
| `ais-smc-failure-retrieval` | "retrieve SMC errors before unit tests", "get SMC baseline after ADO suite", "trace SMC by Observation ID" | Required DEV execution preflight after ADO suite completion and before the first test trigger; optional Observation ID trace |
| `mcp-usage-guide` | "which MCP", "use MCP", "MCP routing", "connect to ADO", "connect to confluence" | Reference guide for all 6 MCP servers — when and where to use each |
| `azure-devops-work-items` | "work item", "EAII", "variable group", "ado pipeline" | "Way of working": EAII ID format, variable groups, agent pools, SonarQube |
| `azure-devops-repository-pr` | "pull request", "create PR", "branch naming", "PR title" | "Way of working": branch/PR conventions, creating branches and PRs via ADO MCP |
| `ais-daily-start` | "daily start", "start of day", "morning check", "check my repos" | "Way of working": auth health + git status for every cloned Metcash repo — no MCP/ADO calls, no network fetch by default |
| `confluence-publish-rich-content` | "publish this to Confluence", "update the Confluence page with the latest TSD" | Publish markdown with tables, code blocks and diagram images to a Confluence page through browser automation (clipboard rich paste) when no MCP write path works |
| `skill-creator` | "create a skill", "add a new skill", "skill template" | Guide for creating new skills for this repository |

### TIBCO Conversion Skills (run in order)

| Step | Skill | When to Use |
|---|---|---|
| 1 | `tibco-azure-nfr-recommendation` | Always first — collect NFR, produce architecture recommendation |
| 2 | `tibco-azure-converter` | After NFR approved — generate Logic App workspace code |
| 3 | `tibco-azure-deployment-guidance` | When deployment planning is requested |

### Squad 20 Engineering Skills

Domain knowledge derived from scanning Squad 20 repositories in METCASHDevOps.
Load the appropriate skill before generating or reviewing any Squad 20 integration code.

| Skill | Trigger | Description |
|---|---|---|
| `squad20-engineering-overview` | "squad 20", "ais tech stack", "platform overview" | Overall tech stack, domains, environments, integration patterns |
| `squad20-naming-conventions` | "naming convention", "resource name", "what should I name" | Azure resource, pipeline, code, and topic/queue naming |
| `logic-app-skill` | "logic app standard", "workflow.json", "connections.json" | Workspace layout, connections, parameters, workflow naming |
| `azure-function-skill` | "function app", "program.cs", "ismclogger", "net 8 function" | Program.cs DI, SMC injection, function trigger file structure |
| `azure-data-factory-skill` | "ADF pipeline", "linked service", "pl_ naming", "delta pipeline" | Pipeline/linked service/dataset naming, factory structure |
| `azure-service-bus-skill` | "service bus", "topic name", "queue name", "sbt naming" | Namespace, topic/queue patterns, SMC queue env mapping |
| `api-management-apiops-skill` | "APIM", "APIOps", "add API", "named value", "policy fragment" | gen-3 APIOps structure, API/backend/named-value naming |
| `squad20-platform-domain-patterns` | "B2B", "B2C", "enabling platform", "RMN", "which repo" | Domain-level repos, APIs, backends, patterns |
| `squad20-scan-summary` | "scan summary", "what repos were scanned", "what patterns exist" | Scan status, gaps, skill files created |

---

## Agent Personas — archived, use skills instead

This repo previously defined 10 role-specific `.agent.md` personas (`integration-developer`,
`solution-architect`, `code-reviewer`, `planner`, plus 6 Squad 20-specific agents for Logic
App/Function/ADF/APIOps/work-items/PR creation). They're archived at
`archive/github-agents-superseded-by-skills/` (2026-09-19) — nothing in
`.github/copilot-instructions.md` (the file Copilot Chat actually reads for skill discovery) or
the portal ever pointed to `.github/agents/`, and several had drifted out of sync with the real
pipeline (stale `outputs/`-for-code guidance, stale .NET version). Use the equivalent skill
directly instead — see the Skill Catalog above and
`archive/github-agents-superseded-by-skills/README.md` for the full persona-to-skill mapping.

---

## MCP Servers

Six MCP servers are configured in `.vscode/mcp.json`. Load `mcp-usage-guide` for full details.

| Server | Purpose | When to Activate |
|---|---|---|
| `microsoft/azure-devops-mcp-metcash` | ADO work items, repos, PRs, test plans, pipelines, wikis | Any task involving ADO |
| `com.atlassian/atlassian-mcp-server-metcash` | Confluence FSD/TSD reading, documentation creation, runsheets | Any task involving Confluence |
| `github` | TIBCO legacy source repos, reference workspace reading | Any TIBCO migration task |
| `azure-sql-b2b-ut1` | Azure SQL queries (B2B UT1 environment) | Debugging or data validation in UT1 |
| `microsoft-docs` | Azure Logic App, ADF, Function App API schemas | Code generation requiring schema validation |
| `memory` | Session context persistence across multi-step sessions | All multi-step sessions |

---

## Selective Context Injection

> **Important:** Load only the skills your current task needs.
> Loading all skills at once dilutes agent attention and wastes tokens.

### Example: End-to-end — TSD through unit testing (recommended order)
```
skills: metcash-tsd-generator → ais-codegen-readiness → ais-logicapp-codegen → ais-functionapp-codegen
        → ais-unit-test-cases → ais-test-execution → ais-test-results-to-ado
```

### Example: New AIS interface from scratch (default path — always start here)
```
skills: metcash-tsd-generator → ais-codegen-readiness → ais-logicapp-codegen → ais-functionapp-codegen → ais-unit-test-cases
```

### Example: New AIS interface — no-TSD exception path (ONLY after explicit user confirmation no TSD will ever be produced)
```
skills: ais-design-intake → ais-logicapp-codegen → ais-functionapp-codegen → ais-unit-test-cases
```

### Example: TIBCO conversion workflow
```
skills: tibco-azure-nfr-recommendation → tibco-azure-converter → (tibco-azure-deployment-guidance)
```

### Example: Code review task
```
skills: ais-code-review
```

### Example: Debug a failing Logic App or ADF pipeline
```
skills: ais-debug-azure, mcp-usage-guide, azure-local-auth
```

### Example: New Squad 20 Logic App interface
```
skills: squad20-engineering-overview, logic-app-skill, squad20-naming-conventions, azure-service-bus-skill
```

### Example: Add new API to APIM
```
skills: api-management-apiops-skill, squad20-naming-conventions
```

### Excluding skills
Remove skill references from your agent configuration or `.github/copilot-instructions.md`
to prevent them loading. Keep only what the current sprint or task requires.

---

## Repository Structure

```text
.
├── AGENTS.md                          ← This file (agent config template)
├── README.md
├── review-gates/                     ← Approved-evidence corpus index and scored review gates
│   ├── README.md
│   └── templates/                    ← TSD and environment runsheet review templates
├── .github/
│   ├── copilot-instructions.md        ← Skill routing, global rules, and MCP routing table
│   ├── prompts/                       ← Reusable slash-command prompts
│   │   ├── convert-tibco.prompt.md
│   │   ├── code-review.prompt.md
│   │   └── documentation.prompt.md
│   └── skills/                        ← All skill SKILL.md files (24)
│       ├── ais-design-intake/         ← Step 1: Intake (Atlassian MCP)
│       ├── metcash-tsd-generator/     ← FSD + Mapping + Manifest + transcript → TSD
│       ├── ais-codegen-readiness/     ← TSD-exists path: resolve repo/resource name, TIBCO cross-check
│       ├── ais-documentation/         ← Spec and doc generation (Atlassian MCP)
│       ├── ais-logicapp-codegen/      ← Logic App code generation (ADO MCP)
│       ├── ais-functionapp-codegen/   ← Function App code generation (ADO MCP)
│       ├── ais-datafactory-codegen/   ← ADF pipeline generation (ADO MCP)
│       ├── ais-unit-test-cases/       ← Test case CSV + ADO Test Plan (ADO MCP)
│       ├── ais-test-execution/        ← Run tests against a deployed non-prod resource
│       ├── ais-test-results-to-ado/   ← Record outcomes, close the ADO Test Run
│       ├── ais-code-review/           ← Code review against AIS standards
│       ├── ais-deployment-runsheet/    ← Confluence runsheets (Atlassian MCP + ADO MCP)
│       ├── ais-runsheet-review/        ← Active and retrospective runsheet review skill
│       ├── ais-debug-azure/           ← Azure resource debugging (Azure CLI + SQL MCP)
│       ├── ais-smc-failure-retrieval/ ← SMC DEV issue export via authenticated Edge
│       ├── azure-local-auth/          ← "Way of working": local Azure/CLI authentication
│       ├── mcp-builder/               ← "Way of working": MCP usage guide (all 6 servers)
│       ├── azure-devops-work-items/   ← "Way of working": ADO backlog conventions
│       ├── azure-devops-repository-pr/← "Way of working": branch + PR conventions
│       ├── confluence-publish-rich-content/ ← Publish rich markdown to Confluence (browser automation)
│       ├── skill-creator/             ← Guide for creating new skills
│       ├── tibco-azure-nfr-recommendation/ ← TIBCO NFR analysis (GitHub MCP)
│       ├── tibco-azure-converter/     ← TIBCO-to-Azure code generation (GitHub + ADO MCP)
│       └── tibco-azure-deployment-guidance/ ← Post-conversion deployment planning
├── skills/                            ← Squad 20 domain knowledge files (9)
│   ├── squad20-engineering-overview.md
│   ├── squad20-naming-conventions.md
│   ├── logic-app-skill.md
│   ├── azure-function-skill.md
│   ├── azure-data-factory-skill.md
│   ├── azure-service-bus-skill.md
│   ├── api-management-apiops-skill.md
│   ├── squad20-platform-domain-patterns.md
│   └── squad20-scan-summary.md
├── archive/                            ← Superseded/unrelated files kept out of the way
│   ├── skills-temp/                    ← Stray cloudinary report, unrelated to any skill
│   └── doc-temp-eaii-374-superseded-drafts/ ← Draft single-page diagrams superseded by tsd/EAII-374/
├── .vscode/
│   └── mcp.json                       ← 6 MCP server configurations
├── outputs/                           ← DOCUMENTS ONLY (questionnaires, tests, reports) —
│   └── EAII-*/                          never generated code; code goes into a real repo clone
│                                        at C:\Users\<you>\source\repos\<TargetRepo>\ instead
│                                        (see code-corpus/index.md for the clone convention)
└── reference-templates/               ← Reference templates for code generation and code review
    ├── logic-apps/workflow.template.json
    ├── function-apps/
    ├── adf/
    ├── documentation/
    ├── code-review/review-report.template.md
    └── tests/unit-test-cases.template.csv
```

---

## Adding New Skills

Follow the `skill-creator` skill guide in `.github/skills/skill-creator/SKILL.md`.

Quick checklist:
- [ ] Skill file at `.github/skills/<skill-name>/SKILL.md`
- [ ] YAML frontmatter with `name`, `description` (include USE FOR / DO NOT USE FOR)
- [ ] Add `## MCP Servers Used in This Skill` section with tool mapping table
- [ ] Reference templates in `assets/` if applicable
- [ ] Entry added to AGENTS.md Skill Catalog above
- [ ] Skill registered in `.github/copilot-instructions.md`
