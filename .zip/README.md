# Metcash AIS Skills Hub

Skills, custom agents, prompts, and MCP configurations for AI coding agents working on
Metcash Azure Integration Services (AIS) interfaces.

> **New here?** Go straight to **[portal/index.html](portal/index.html)** — open it in a browser for the
> interactive Developer Portal with copy-paste prompts and "Open in VS Code" buttons for every skill.

> **Use skills selectively.** Load only the skills your current task needs.
> Loading all skills causes context dilution and wasted tokens.

---

## Quick Start

1. Open **GitHub Copilot Chat** in VS Code (`Ctrl+Shift+P` → **GitHub Copilot: Open Chat**).
2. Type `/` to see all available slash-command prompts from this repository.
3. For a new interface: type `/new-interface EAII-<number>` and follow the guided workflow.
4. For TIBCO conversion: use `/convert-tibco EAII-<number>`.
5. For reviews: use `/tsd-review`, `/build-review`, `/code-review`, or `/runsheet-review` as appropriate.
6. For Azure auth setup: use `/azure-auth`.

Interface IDs must use `EAII-{number}` format (example: `EAII-107`).

---

## What's Inside

| Asset | Count | Description |
|---|---|---|
| AIS Integration Skills | 16 | TSD generation, design intake, codegen readiness, Logic Apps, Function Apps, ADF, docs, tests, test execution, test results, review, debug, SMC failure retrieval, deployment runsheet, skill-creator |
| TIBCO Conversion Skills | 3 | NFR recommendation → code generation → deployment guidance |
| Azure Auth Skill | 1 | Local Azure authentication setup via VS Code + Azure CLI |
| MCP Usage Guide | 1 | Which of the 6 MCP servers to use for every engineering activity |
| Squad 20 "Way of Working" Skills | 11 | Naming conventions, workspace patterns, Service Bus, APIM, ADO work items, ADO PR/branch |
| Slash-Command Prompts | 13 | `/new-interface`, `/design-intake`, `/create-tsd`, `/tsd-review`, `/build-review`, `/unit-test-cases`, `/documentation`, `/code-review`, `/runsheet-review`, `/convert-tibco`, `/deployment-runsheet`, `/azure-auth`, `/daily-start` |
| Developer Portal | 1 | [portal/index.html](portal/index.html) — interactive browser portal with copy/send buttons |
| MCP Config | 1 | `.vscode/mcp.json` — 6 servers: ADO, Atlassian, GitHub, Azure SQL, Microsoft Docs, memory |

---

## Skill Catalog

### AIS Integration Skills

| Skill | Slash Command | Trigger Phrases | Description |
|---|---|---|---|
| `ais-design-intake` | `/design-intake` | "read FSD", "design intake", "load spec", "generate from FSD" | **No-TSD path only.** Reads FSD, infers technical decisions, produces Design Intake Questionnaire |
| `metcash-tsd-generator` | `/create-tsd` | "create a TSD", "generate a technical specification", "produce TSD from FSD" | Generates the full §1–§15 TSD from FSD + Mapping + Mapping Manifest + walkthrough transcript |
| `ais-codegen-readiness` | — | "ready to generate code", "codegen readiness", "resolve repo and resource name" | **TSD-exists path.** Resolves repo/resource name, field-mapping cross-check, TIBCO cross-check — replaces `ais-design-intake` once a TSD exists |
| `ais-documentation` | `/documentation` | "generate documentation", "create spec", "interface documentation" | Generate technical specs, data flow docs, assumption logs |
| `ais-logicapp-codegen` | — | "generate logic app", "create workflow", "workflow json" | Generate Logic App Standard workflows and connections |
| `ais-functionapp-codegen` | — | "generate function app", "transformation code", "C# function" | Generate C# .NET 8 local transformation functions |
| `ais-datafactory-codegen` | — | "generate ADF", "data factory pipeline", "bulk data movement" | Generate ADF pipelines, datasets, MI-authenticated linked services |
| `ais-unit-test-cases` | `/unit-test-cases` | "generate test cases", "unit test", "test scenarios" | Generate unit-test-cases.csv + create ADO Test Plan/Suite/Cases |
| `ais-test-execution` | — | "run the unit tests", "execute test cases", "trigger a test run" | Fire each test case against a deployed non-prod resource, capture the real outcome |
| `ais-test-results-to-ado` | — | "record test results", "upload results to ado", "close the test run" | Record outcomes against the existing ADO Test Plan, complete the run, comment on the work item |
| `ais-code-review` | `/code-review` | "code review", "review my workflow", "security review" | Review code against AIS standards and OWASP Top 10 |
| `ais-deployment-runsheet` | `/deployment-runsheet` ⚡ | "deployment runsheet", "runsheet", "how to deploy" | Create Confluence runsheet with Azure CLI validation steps |
| `ais-runsheet-review` | — | "review this runsheet", "runsheet quality review", "check runsheet against TSD and code" | Review existing runsheets against approved design, latest code/pipeline evidence, and the environment checklist |
| Review Gates | — | "TSD review", "code review score", "PRD readiness" | Curated approved-evidence corpus, scored review checklists, comment resolution, and environment/PRD deployment gates (`review-gates/README.md`) |
| `ais-debug-azure` | — | "debug", "investigate failure", "diagnose", "troubleshoot" | Investigate Logic App/Function App/ADF/Service Bus failures, produce a diagnosis report |
| `ais-smc-failure-retrieval` | — | "retrieve SMC errors before unit tests", "get SMC baseline after ADO suite", "trace SMC by Observation ID" | Required DEV execution preflight after ADO suite completion and before the first test trigger; optional Observation ID trace |
| `skill-creator` | — | "create a skill", "add a new skill", "write a SKILL.md" | Guide for extending this skills repository |
| `azure-local-auth` | `/azure-auth` ⚡ | "azure auth", "az login", "connect to azure" | Set up local Azure auth for Copilot + MCP servers |
| `mcp-usage-guide` | — | "which MCP", "use MCP", "MCP routing" | Which of the 6 MCP servers to use for every engineering activity |

> ⚡ = prompt includes **Azure CLI** commands — run from Metcash Dev Box or Azure Cloud Shell.

### TIBCO Conversion Skills (run in order)

| Step | Skill | Slash Command | When to Use |
|---|---|---|---|
| 1 | `tibco-azure-nfr-recommendation` | `/convert-tibco` | Always first — NFR analysis and architecture recommendation |
| 2 | `tibco-azure-converter` | (continues from step 1) | After NFR approved — generate Logic App workspace code |
| 3 | `tibco-azure-deployment-guidance` | — (no slash command; `/deployment-runsheet` is the separate AIS-generic skill) | When deployment planning is requested |

### Squad 20 "Way of Working" Skills

Engineering domain knowledge plus day-to-day ADO/CLI operations — not code generation.

| Skill | Trigger Phrases | Description |
|---|---|---|
| `squad20-engineering-overview` | "squad 20", "ais tech stack", "platform overview" | Overall tech stack, platform domains, environment structure |
| `squad20-naming-conventions` | "naming convention", "resource name", "what should I name" | Azure resource, pipeline, topic/queue, code naming |
| `logic-app-skill` | "logic app standard", "workflow.json", "connections.json" | Workspace layout (Pattern A/B), connections, parameters, workflow naming |
| `azure-function-skill` | "function app", "program.cs", "ismclogger" | Program.cs DI, SMC injection, trigger file structure |
| `azure-data-factory-skill` | "ADF pipeline", "linked service", "pl_ naming" | Pipeline/linked service/dataset naming, parent-child patterns |
| `azure-service-bus-skill` | "service bus", "topic name", "queue name", "sbt naming" | Namespace, topic/queue naming, SMC queue env mapping |
| `api-management-apiops-skill` | "APIM", "APIOps", "add API", "named value" | gen-3 APIOps folder structure, API/backend/named-value naming |
| `azure-devops-work-items` | "work item", "EAII", "variable group", "ado pipeline" | EAII ID format, variable groups, agent pools, SonarQube |
| `azure-devops-repository-pr` | "pull request", "create PR", "branch naming" | Branch/PR conventions, creating branches and PRs via ADO MCP |
| `squad20-platform-domain-patterns` | "B2B", "B2C", "enabling platform", "RMN", "which repo" | Domain-level repos, APIs, backends, patterns per domain |
| `squad20-scan-summary` | "scan summary", "what repos were scanned" | Scan status, gaps, skill files created |

---

## Workflow Diagrams

### New AIS Interface (TSD → Code → Review → Deployment)

```
metcash-tsd-generator  (FSD + Mapping + Manifest + transcript → TSD)
        │
        ▼
 /tsd-review (human checklist and approval; automated TSD score stays separate)
        │
        ▼
ais-codegen-readiness  (TSD exists → resolve repo/resource name/TIBCO cross-check; STOP for approval)
        │           (no TSD at all → /design-intake instead, infers from FSD alone)
        ▼
Codegen Readiness Questionnaire  (outputs/EAII-NNN/codegen-readiness-questionnaire.md)
        │        — resolves + clones the real target repo to C:\Users\<you>\source\repos\<Repo>,
        │          creates feature/EAII-NNN-<description>, runs the Kudu tcpping pre-check
        │        — or Design Intake Questionnaire (outputs/EAII-NNN/design-intake-questionnaire.md) for the no-TSD path
        │
        ├──► ais-logicapp-codegen ──────────────────────────┐   (writes into the repo clone
        ├──► ais-functionapp-codegen  (if transformation)   ┤    above, never into outputs/ —
        └──► ais-datafactory-codegen  (if batch/bulk)       ┘    outputs/ stays documents-only)
                                                             │
                                        /unit-test-cases  ◄─┘   (approval before CSV; separate approval before ADO)
                                                │
                                        ais-test-execution        (run against non-prod)
                                                │
                                        ais-test-results-to-ado   (record outcomes, close run)
                                                │
                                        /documentation
                                                │
                                        /build-review (local evidence)
                                                │
                                         /code-review
                                                │
                                    /deployment-runsheet → /runsheet-review (per environment)
                                                │
                                  azure-devops-repository-pr (branch + PR)
```

### TIBCO to Azure Conversion

```
/convert-tibco  →  tibco-azure-nfr-recommendation  →  tibco-azure-converter  →  /deployment-runsheet
```

---

## Repository Structure

```text
.
├── AGENTS.md                          ← Agent configuration template
├── README.md                          ← This file
├── Doc/
│   └── Presentations/
│       └── PRESENTATION.md            ← Skills Hub presentation (2 slides — Marp compatible)
├── review-gates/                     ← Review corpus, scoring rules and human gate templates
│   ├── README.md
│   └── templates/                    ← TSD and per-environment runsheet review checklists
├── portal/
│   └── index.html                     ← Interactive Developer Portal (open in browser)
├── .github/
│   ├── copilot-instructions.md        ← Skill routing and global rules
│   ├── prompts/                       ← 9 slash-command prompt files (type / in Copilot Chat)
│   │   ├── new-interface.prompt.md    ← /new-interface   end-to-end workflow
│   │   ├── design-intake.prompt.md    ← /design-intake   FSD/TSD validation
│   │   ├── create-tsd.prompt.md       ← /create-tsd      FSD + Mapping + Manifest + transcript → TSD
│   │   ├── unit-test-cases.prompt.md  ← /unit-test-cases
│   │   ├── documentation.prompt.md    ← /documentation
│   │   ├── code-review.prompt.md      ← /code-review
│   │   ├── convert-tibco.prompt.md    ← /convert-tibco
│   │   ├── deployment-runsheet.prompt.md ← /deployment-runsheet  ⚡ Azure CLI
│   │   └── azure-auth.prompt.md       ← /azure-auth  ⚡ Azure CLI
│   └── skills/                        ← 24 SKILL.md packages
│       ├── ais-design-intake/         ← No-TSD path: FSD-only intake
│       ├── metcash-tsd-generator/     ← FSD + Mapping + Manifest + transcript → TSD
│       ├── ais-codegen-readiness/     ← TSD-exists path: resolve repo/resource name, TIBCO cross-check
│       ├── ais-documentation/
│       ├── ais-logicapp-codegen/
│       ├── ais-functionapp-codegen/
│       ├── ais-datafactory-codegen/
│       ├── ais-unit-test-cases/
│       ├── ais-test-execution/        ← Run tests against a deployed non-prod resource
│       ├── ais-test-results-to-ado/   ← Record outcomes, close the ADO Test Run
│       ├── ais-code-review/
│       ├── ais-deployment-runsheet/
│       ├── ais-runsheet-review/
│       ├── ais-debug-azure/
│       ├── ais-smc-failure-retrieval/ ← SMC DEV issue export via authenticated Edge
│       ├── azure-local-auth/          ← "Way of working": CLI/MCP login
│       ├── mcp-builder/               ← "Way of working": mcp-usage-guide
│       ├── azure-devops-work-items/   ← "Way of working": ADO backlog conventions
│       ├── azure-devops-repository-pr/← "Way of working": branch + PR conventions
│       ├── skill-creator/
│       ├── tibco-azure-converter/
│       ├── tibco-azure-nfr-recommendation/
│       └── tibco-azure-deployment-guidance/
├── skills/                            ← 9 Squad 20 domain-knowledge reference files
├── archive/                           ← Superseded/unrelated files kept out of the way
├── .vscode/
│   └── mcp.json                       ← MCP server configurations
├── outputs/                           ← DOCUMENTS ONLY — never generated code
│   └── EAII-*/
│       ├── codegen-readiness-questionnaire.md   ← ais-codegen-readiness (TSD-exists path)
│       ├── design-intake-questionnaire.md          ← ais-design-intake (no-TSD path)
│       ├── unit-test-cases.csv
│       ├── test-execution-log.md
│       ├── test-results-summary.md
│       ├── spec.md / change-summary.md / data-flow.md
│       └── assumptions.md
│                                      ← Generated CODE goes into a real repo clone instead:
│                                        C:\Users\<you>\source\repos\<TargetRepo>\, on branch
│                                        feature/EAII-<number>-<description> — see
│                                        code-corpus/index.md for the clone convention
└── reference-templates/               ← Boilerplate templates per domain, including code review
        ├── logic-apps/
        ├── function-apps/
        ├── adf/
        ├── documentation/
        ├── tests/
        └── code-review/review-report.template.md
```

---

## Global Rules

- **`ais-design-intake` is mandatory before any code generation.** No code generation skill runs without a Design Intake Questionnaire.
- Interface IDs must match `EAII-{number}`. Never proceed without one.
- Never invent naming conventions — read the reference workspace first.
- Always generate `unit-test-cases.csv` alongside code outputs.
- Write all generated artifacts to `outputs/<InterfaceID>/`.
- Log all assumptions to `outputs/<InterfaceID>/assumptions.md`.
- SMC observability logging is required in all Logic App workflows and ADF pipelines.
- All service-to-service auth uses **Managed Identity** — never hardcoded connection strings.

---

## Adding New Skills

Follow the `skill-creator` skill guide in `.github/skills/skill-creator/SKILL.md`, then:

1. Create `.github/skills/<skill-name>/SKILL.md` with frontmatter (USE FOR / DO NOT USE FOR / Triggers)
2. Optionally create `.github/prompts/<skill-name>.prompt.md` for a VS Code slash command
3. Register in `.github/copilot-instructions.md`
4. Add a row to the Skill Catalog table above
5. Add a card to [portal/index.html](portal/index.html) in the `SKILLS` array
6. Add a row to `AGENTS.md`

---

## MCP Servers

Pre-configured in `.vscode/mcp.json`:

| Server | Purpose |
|---|---|
| `microsoft-docs` | Azure documentation — Logic Apps, Function Apps, ADF, Service Bus, Storage |
| `github` | Source repository access — TIBCO source and reference workspaces. **Requires `GITHUB_TOKEN` env var** |
| `memory` | Session context — persist interface state across multi-step sessions |

> **Admin Note:** The `github` MCP server requires a GitHub Personal Access Token.
> See [Doc/Presentations/PRESENTATION.md](Doc/Presentations/PRESENTATION.md) for the full list of admin-enabled blockers.