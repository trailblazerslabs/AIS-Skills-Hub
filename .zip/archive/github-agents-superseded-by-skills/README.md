# Archived — superseded by `.github/skills/`

These 10 `.agent.md` files were an earlier "GitHub Copilot custom agent" approach, from before
the skills-based pipeline (`.github/copilot-instructions.md` + `.github/skills/*/SKILL.md`) was
built out. Archived 2026-09-19 because:

- Nothing in `.github/copilot-instructions.md` (the file Copilot actually reads to discover
  skills) or the portal (`portal/index.html`) points to this folder — it was never wired into
  the live copy-a-prompt-from-the-portal workflow.
- Three of them (`create-logic-app-agent.md`, `create-azure-function-agent.md`,
  `create-adf-pipeline-agent.md`) still told the agent to write generated code into
  `outputs/<InterfaceID>/` instead of a real repo clone — the exact bug fixed everywhere else
  in the skills pipeline this session — and were an active trap for anyone who opened them
  directly instead of using the corresponding `ais-*-codegen` skill.

Prefer the equivalent skill for each:

| Archived agent | Use instead |
|---|---|
| `create-logic-app-agent.md` | `ais-logicapp-codegen` |
| `create-azure-function-agent.md` | `ais-functionapp-codegen` |
| `create-adf-pipeline-agent.md` | `ais-datafactory-codegen` |
| `code-reviewer.agent.md` | `ais-code-review` |
| `azure-devops-workitem-agent.md` | `azure-devops-work-items` |
| `create-pull-request-agent.md` | `azure-devops-repository-pr` |
| `integration-developer.agent.md`, `planner.agent.md`, `solution-architect.agent.md` | No direct skill equivalent — kept for reference only, not actively maintained |
| `create-update-apiops-agent.md` | No direct skill equivalent yet — kept for reference only |
