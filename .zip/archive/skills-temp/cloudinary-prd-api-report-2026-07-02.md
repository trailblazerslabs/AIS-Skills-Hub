# Cloudinary PRD Function App — API Call Report

**Report Date:** 2026-07-02  
**Function App:** `t3-met-cloudinary-prd-ae-func`  
**Application Insights:** `t3-met-cloudinary-prd-ae-func-ai`  
**Log Analytics Workspace:** `t2-met-ais-prd-ae1-law` (`625214b6-8e44-4aa8-8ffa-ee0fde981deb`)  
**Resource Group:** `t3-met-ais-prd-ae1-rsg-b2b`  
**Subscription:** `COREIT-SERVICES-AIS-PRD` (`6cf73e4a-a0ad-47ec-8dc0-9ccb87d6a5ee`)  
**Backend Endpoint:** `https://api.cloudinary.com/v1_1/projectmerlin`

---

## 1. 7-Day Summary (25 Jun – 02 Jul 2026)

### Overall Totals

| Metric | Value |
|---|---|
| Total Calls | **223,059** |
| Successful (200) | **223,038** |
| Failed | **21** |
| Avg Duration | **886 ms** |

### By Operation (7-Day Total)

| Method | Endpoint | Total | Success | Failed | Avg Duration |
|---|---|---|---|---|---|
| POST | `/v1_1/projectmerlin/resources/search` | 189,269 | 189,269 | 0 | 856 ms |
| POST | `/v1_1/projectmerlin/image/upload` | 9,633 | 9,612 | **21** | 2,794 ms |
| POST | `/v1_1/projectmerlin/resources/image` | 8,083 | 8,083 | 0 | 426 ms |
| POST | `/v1_1/projectmerlin/image/tags` | 7,790 | 7,790 | 0 | 315 ms |
| POST | `/v1_1/projectmerlin/image/context` | 7,785 | 7,785 | 0 | 306 ms |
| DELETE | `/v1_1/projectmerlin/resources/image` | 499 | 499 | 0 | 939 ms |
| **TOTAL** | | **223,059** | **223,038** | **21** | |

### Daily Volume

| Date | Total Calls | Failed |
|---|---|---|
| 25 Jun | 12,833 | 0 |
| 26 Jun | 18,592 | **7** |
| 27 Jun | 11,223 | 0 |
| 28 Jun | 9,754 | 0 |
| 29 Jun | 50,310 | **2** |
| 30 Jun | 54,746 | 0 |
| 01 Jul | 49,578 | 0 |
| 02 Jul *(partial)* | 16,115 | **12** |

> ⚠️ Spike from 29 Jun onwards (~50K calls/day vs ~10–18K prior). All failures are on `POST /image/upload`.

---

## 2. Failure Summary

All 21 failures occurred on `POST /v1_1/projectmerlin/image/upload` only.

| Error Code | Meaning | Count | Dates |
|---|---|---|---|
| **420** | Rate Limiting (Too Many Requests) | **10** | 02 Jul 06:00–09:00 UTC |
| **400** | Bad Request | **7** | 26 Jun |
| **404** | Not Found | **4** | 26 Jun (2) + 02 Jul 02:00 (2) |

---

## 3. Hourly Report — 01 Jul (UTC)

> ✅ **01 July was completely clean — 49,578 calls, 0 failures.**

| Hour (UTC) | Method | Endpoint | Code | Total | Success | Failed |
|---|---|---|---|---|---|---|
| 00:00 | POST | `/resources/search` | 200 | 2,115 | 2,115 | 0 |
| 00:00 | POST | `/image/upload` | 200 | 6 | 6 | 0 |
| 00:00 | POST | `/resources/image` | 200 | 6 | 6 | 0 |
| 01:00 | POST | `/resources/search` | 200 | 2,235 | 2,235 | 0 |
| 01:00 | POST | `/image/upload` | 200 | 3 | 3 | 0 |
| 01:00 | POST | `/resources/image` | 200 | 2 | 2 | 0 |
| 01:00 | DELETE | `/resources/image` | 200 | 1 | 1 | 0 |
| 02:00 | POST | `/resources/search` | 200 | 2,108 | 2,108 | 0 |
| 02:00 | POST | `/image/upload` | 200 | 9 | 9 | 0 |
| 02:00 | POST | `/resources/image` | 200 | 9 | 9 | 0 |
| 03:00 | POST | `/resources/search` | 200 | 2,108 | 2,108 | 0 |
| 03:00 | POST | `/image/upload` | 200 | 2 | 2 | 0 |
| 03:00 | POST | `/resources/image` | 200 | 1 | 1 | 0 |
| 04:00 | POST | `/resources/search` | 200 | 2,132 | 2,132 | 0 |
| 04:00 | POST | `/image/upload` | 200 | 13 | 13 | 0 |
| 04:00 | POST | `/resources/image` | 200 | 8 | 8 | 0 |
| 05:00 | POST | `/resources/search` | 200 | 2,243 | 2,243 | 0 |
| 05:00 | POST | `/image/upload` | 200 | 21 | 21 | 0 |
| 05:00 | POST | `/resources/image` | 200 | 13 | 13 | 0 |
| 05:00 | DELETE | `/resources/image` | 200 | 8 | 8 | 0 |
| 06:00 | POST | `/resources/search` | 200 | 2,095 | 2,095 | 0 |
| 06:00 | POST | `/image/upload` | 200 | 13 | 13 | 0 |
| 06:00 | POST | `/resources/image` | 200 | 6 | 6 | 0 |
| 07:00 | POST | `/resources/search` | 200 | 1,338 | 1,338 | 0 |
| 07:00 | POST | `/image/upload` | 200 | 1 | 1 | 0 |
| 08:00–10:00 | — | *(no telemetry)* | — | — | — | — |
| 11:00 | POST | `/resources/search` | 200 | 928 | 928 | 0 |
| 11:00 | POST | `/image/upload` | 200 | 1 | 1 | 0 |
| 12:00 | POST | `/resources/search` | 200 | 1,237 | 1,237 | 0 |
| 12:00 | POST | `/image/upload` | 200 | 7 | 7 | 0 |
| 12:00 | POST | `/resources/image` | 200 | 6 | 6 | 0 |
| 13:00 | POST | `/resources/search` | 200 | 2,231 | 2,231 | 0 |
| 14:00 | POST | `/resources/search` | 200 | 2,102 | 2,102 | 0 |
| **15:00** ⚡ | POST | `/image/upload` | 200 | **2,150** | 2,150 | 0 |
| 15:00 | POST | `/resources/search` | 200 | 1,957 | 1,957 | 0 |
| 15:00 | POST | `/resources/image` | 200 | 1,783 | 1,783 | 0 |
| 15:00 | POST | `/image/tags` | 200 | 1,782 | 1,782 | 0 |
| 15:00 | POST | `/image/context` | 200 | 1,782 | 1,782 | 0 |
| 15:00 | DELETE | `/resources/image` | 200 | 111 | 111 | 0 |
| 16:00 | POST | `/resources/search` | 200 | 1,666 | 1,666 | 0 |
| 16:00 | POST | `/image/upload` | 200 | 267 | 267 | 0 |
| 16:00 | POST | `/image/context` | 200 | 250 | 250 | 0 |
| 16:00 | POST | `/image/tags` | 200 | 250 | 250 | 0 |
| 16:00 | POST | `/resources/image` | 200 | 249 | 249 | 0 |
| 16:00 | DELETE | `/resources/image` | 200 | 16 | 16 | 0 |
| 17:00 | POST | `/resources/search` | 200 | 2,232 | 2,232 | 0 |
| 18:00 | POST | `/resources/search` | 200 | 2,089 | 2,089 | 0 |
| 19:00 | POST | `/resources/search` | 200 | 1,633 | 1,633 | 0 |
| 19:00 | POST | `/image/upload` | 200 | 1 | 1 | 0 |
| 19:00 | POST | `/resources/image` | 200 | 1 | 1 | 0 |
| 20:00 | POST | `/resources/search` | 200 | 2,096 | 2,096 | 0 |
| 21:00 | POST | `/resources/search` | 200 | 2,083 | 2,083 | 0 |
| 21:00 | POST | `/image/upload` | 200 | 1 | 1 | 0 |
| 22:00 | POST | `/resources/search` | 200 | 2,004 | 2,004 | 0 |
| 22:00 | POST | `/image/upload` | 200 | 5 | 5 | 0 |
| 22:00 | DELETE | `/resources/image` | 200 | 2 | 2 | 0 |
| 23:00 | POST | `/resources/search` | 200 | 2,134 | 2,134 | 0 |
| 23:00 | POST | `/image/upload` | 200 | 16 | 16 | 0 |
| 23:00 | POST | `/resources/image` | 200 | 10 | 10 | 0 |

---

## 4. Hourly Report — 02 Jul (UTC, partial)

> ⚠️ **Failures begin at 02:00 (404) and rate limiting (420) starts at 06:00.**

| Hour (UTC) | Method | Endpoint | Code | Total | Success | Failed |
|---|---|---|---|---|---|---|
| 00:00 | POST | `/resources/search` | 200 | 2,129 | 2,129 | 0 |
| 00:00 | POST | `/image/upload` | 200 | 36 | 36 | 0 |
| 00:00 | POST | `/resources/image` | 200 | 25 | 25 | 0 |
| 00:00 | POST | `/image/tags` | 200 | 2 | 2 | 0 |
| 00:00 | POST | `/image/context` | 200 | 2 | 2 | 0 |
| 01:00 | POST | `/resources/search` | 200 | 2,010 | 2,010 | 0 |
| 01:00 | POST | `/image/upload` | 200 | 23 | 23 | 0 |
| 01:00 | POST | `/resources/image` | 200 | 13 | 13 | 0 |
| 02:00 | POST | `/resources/search` | 200 | 1,943 | 1,943 | 0 |
| 02:00 | POST | `/image/upload` | 200 | 20 | 20 | 0 |
| 02:00 | POST | `/resources/image` | 200 | 17 | 17 | 0 |
| 02:00 | POST | `/image/context` | 200 | 1 | 1 | 0 |
| 02:00 | POST | `/image/tags` | 200 | 1 | 1 | 0 |
| 02:00 | DELETE | `/resources/image` | 200 | 1 | 1 | 0 |
| **02:00** ⚠️ | **POST** | **`/image/upload`** | **404** | **2** | 0 | **2** |
| 03:00 | POST | `/resources/search` | 200 | 2,113 | 2,113 | 0 |
| 03:00 | POST | `/image/upload` | 200 | 7 | 7 | 0 |
| 03:00 | POST | `/resources/image` | 200 | 5 | 5 | 0 |
| 04:00 | POST | `/resources/search` | 200 | 2,102 | 2,102 | 0 |
| 04:00 | POST | `/image/upload` | 200 | 4 | 4 | 0 |
| 04:00 | POST | `/resources/image` | 200 | 4 | 4 | 0 |
| 05:00 | POST | `/resources/search` | 200 | 2,227 | 2,227 | 0 |
| 05:00 | POST | `/image/upload` | 200 | 3 | 3 | 0 |
| 06:00 | POST | `/resources/search` | 200 | 2,143 | 2,143 | 0 |
| 06:00 | POST | `/image/upload` | 200 | 73 | 73 | 0 |
| 06:00 | POST | `/resources/image` | 200 | 54 | 54 | 0 |
| 06:00 | POST | `/image/context` | 200 | 51 | 51 | 0 |
| 06:00 | POST | `/image/tags` | 200 | 51 | 51 | 0 |
| 06:00 | DELETE | `/resources/image` | 200 | 8 | 8 | 0 |
| **06:00** ⚠️ | **POST** | **`/image/upload`** | **420** | **6** | 0 | **6** |
| 07:00 | POST | `/resources/search` | 200 | 2,124 | 2,124 | 0 |
| 07:00 | POST | `/image/context` | 200 | 28 | 28 | 0 |
| 07:00 | POST | `/image/tags` | 200 | 28 | 28 | 0 |
| 07:00 | POST | `/resources/image` | 200 | 28 | 28 | 0 |
| 07:00 | POST | `/image/upload` | 200 | 20 | 20 | 0 |
| **07:00** ⚠️ | **POST** | **`/image/upload`** | **420** | **8** | 0 | **8** |
| 08:00 | POST | `/resources/search` | 200 | 2,083 | 2,083 | 0 |
| 08:00 | POST | `/image/tags` | 200 | 42 | 42 | 0 |
| 08:00 | POST | `/image/context` | 200 | 42 | 42 | 0 |
| 08:00 | POST | `/resources/image` | 200 | 42 | 42 | 0 |
| 08:00 | POST | `/image/upload` | 200 | 35 | 35 | 0 |
| 08:00 | DELETE | `/resources/image` | 200 | 6 | 6 | 0 |
| **08:00** ⚠️ | **POST** | **`/image/upload`** | **420** | **7** | 0 | **7** |
| 09:00 | POST | `/resources/search` | 200 | 1,672 | 1,672 | 0 |
| 09:00 | POST | `/resources/image` | 200 | 20 | 20 | 0 |
| 09:00 | POST | `/image/tags` | 200 | 20 | 20 | 0 |
| 09:00 | POST | `/image/context` | 200 | 20 | 20 | 0 |
| 09:00 | POST | `/image/upload` | 200 | 16 | 16 | 0 |
| **09:00** ⚠️ | **POST** | **`/image/upload`** | **420** | **4** | 0 | **4** |

---

## 5. KQL Queries Used

### Hourly breakdown by method, operation and result code
```kql
AppDependencies
| where TimeGenerated >= datetime(2026-07-01T00:00:00Z)
| where AppRoleName has 'cloudinary' and Target == 'api.cloudinary.com'
| extend method = tostring(split(Name, ' ')[0]), path = tostring(split(Name, ' ')[1])
| extend pathGroup = extract('^(/v1_1/[^/]+/[^/]+/[^/]+)', 1, path)
| summarize totalCalls=count(), successCalls=countif(Success==true), failedCalls=countif(Success==false)
    by bin(TimeGenerated, 1h), method, pathGroup, ResultCode
| order by TimeGenerated asc, totalCalls desc
```

### 7-day operation totals
```kql
AppDependencies
| where TimeGenerated > ago(7d)
| where AppRoleName has 'cloudinary' and Target == 'api.cloudinary.com'
| extend method = tostring(split(Name, ' ')[0]), path = tostring(split(Name, ' ')[1])
| extend pathGroup = extract('^(/v1_1/[^/]+/[^/]+/[^/]+)', 1, path)
| summarize totalCalls=count(), successCalls=countif(Success==true),
    failedCalls=countif(Success==false), avgDurationMs=round(avg(DurationMs),0)
    by method, pathGroup
| order by totalCalls desc
```

### Rate limiting failures detail
```kql
AppDependencies
| where TimeGenerated > ago(7d)
| where AppRoleName has 'cloudinary' and Target == 'api.cloudinary.com'
    and Success == false and ResultCode == '420'
| summarize count() by bin(TimeGenerated, 1h)
| order by TimeGenerated desc
```

---

## 6. Observations & Recommendations

| # | Observation | Recommendation |
|---|---|---|
| 1 | All **420 Rate Limit** errors are on `POST /image/upload` only, occurring in pairs (~2 concurrent calls per 15-min window) | Implement **retry with exponential backoff** + jitter on upload failures |
| 2 | Rate limiting started at **06:00 UTC on 02 Jul** and persisted for 4 consecutive hours (06–09) | Review Cloudinary account **rate limit quota** for `projectmerlin` cloud — may need quota increase |
| 3 | `/resources/search` dominates at **85% of all calls** (189K) with zero failures | No action needed; healthy |
| 4 | **Volume spike on 29 Jun** (~50K/day vs ~12–18K previously) correlates with start of rate limit issues | Investigate what triggered the increased load on 29 Jun |
| 5 | **08:00–10:00 UTC on 01 Jul** shows no telemetry | Check if function was stopped/restarted during this window |

---

*Report generated: 2026-07-02 | Source: Application Insights `t3-met-cloudinary-prd-ae-func-ai`*
