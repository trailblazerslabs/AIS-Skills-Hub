# TSD Review Checklist — {EAII-IDs} — {InterfaceName}

Review date: {date}  
Reviewer: {name}  
TSD revision/commit: {revision}  
Status: **IN REVIEW / BLOCKED / APPROVED FOR CODEGEN READINESS**

> This is a critical human review of the generated TSD. The `quality_review.py` score is recorded
> separately; it is not this review's score and neither score alone approves code generation.
> TSD approval permits the next questionnaire gate only. Codegen remains stopped until the
> readiness questionnaire is separately approved.

## Critical Findings

| # | Severity | TSD section / artifact | Evidence | Risk / impact | Required correction / owner | Blocks TSD approval? |
|---|---|---|---|---|---|---|
| 1 | Critical / High / Medium / Low | {location} | {citation/source} | {impact} | {action and owner} | Yes / No |

## Evidence and Score

Score each dimension only from cited evidence. Full points require the listed evidence to be
present and internally consistent. N/A requires a reason; unverified earns zero.

| Dimension | Max | Awarded | Evidence reviewed / comments |
|---|---:|---:|---|
| FSD scope, requirements, NFRs and source/target traceability | 25 | {0-25} | {FSD sections / traceability} |
| Architecture, process flow, state, transaction and failure behavior | 20 | {0-20} | {sections / diagrams / retry and settlement} |
| Field mappings, schemas, exceptions and TSD test scenarios | 20 | {0-20} | {raw mappings / manifest / §5.x.10.2} |
| Security, identity, secrets, network and SMC observability | 15 | {0-15} | {sections / controls / gaps} |
| Configuration, environments, operations, support, deployment and rollback | 10 | {0-10} | {sections / owners / procedures} |
| Document structure, references, diagrams and Word artifact | 10 | {0-10} | {lint, diagram, DOCX and rendering evidence} |
| **Total** | **100** | **{total}** | |

**TSD automated score (`quality_review.py`):** {score}/100; errors: {n}; justified warnings: {n}  
**Human review score:** {total}/100  
**Quality percentage:** `{total}%` (human review; do not average with automated score)

Dimension 2 (architecture, state, failure behavior) is awarded in full only if each item below is cited as
present in the TSD (`NOT PRESENT` is a finding; Critical when the interface is synchronous or high-volume):

- [ ] Sync vs async stated with the response-time budget; Logic App vs Function App choice has a reason (orchestration only; DB2/opaque connector; timeout/cancellation control).
- [ ] §4.5.1 retry table: explicit policy per action, never the platform default; none inside synchronous actions; max 2 for async calls internal to Azure (Logic App minimum interval 5 s) or the reason it differs; no retry on Stibo/PE procedure calls; reason per connector.
- [ ] Cumulative worst-case retry time is shown against the Service Bus PeekLock duration; lock raised or retries cut when exceeded.
- [ ] Stateless vs stateful chosen with a reason; stateful only if SMC resubmission is the recovery path; PeekLock with explicit complete/dead-letter and `maxDeliveryCount` stated; SMC load (2 entries per attempt) considered.
- [ ] Concurrency stated: trigger parallelism (max 100) with max waiting runs at the minimum (10), `maxConcurrentCalls`, one file/message at a time and a 2-3 s pause for targets that lock items (Stibo; DLQ replays included), only the operations present in the input invoked.
- [ ] Downstream limits: max concurrent connections to the target (e.g. PE/TIBCO 1000), App Service Plan sharing impact, timeout on every outbound call and how it is tested, long-running-thread handling if synchronous.
- [ ] Logic App design avoids chains of variable/compose actions (single initialisation / compose).
- [ ] §4.5 gives daily volume **and** peak window (or TBC with owner); performance-test plan: peak or compressed load, real files with distinct names, owner, ADO card, evidence for the CR, non-prod limitation recorded.

Dimension 6 (document structure, references, diagrams) is awarded in full only if each item below is cited as present:

- [ ] §1 Document Overview is a short overview only (what the document is about, purpose, scope, what the reader can expect); no detailed business or technical content.
- [ ] §4.1 Business Process does not repeat §1.1 or any other section; each fact appears once, with cross-references elsewhere.
- [ ] Progressive structure: overview, then scope, then the end-to-end system view, then detailed flows, processing logic and technical information in their own sections.
- [ ] §4.1 opens with a simple block diagram of the participating applications/systems and their high-level interaction, before any detailed flow or Azure-level diagram.
- [ ] The document is crisp and easy to scan: tables or lists over long paragraphs, no filler, no repeated paragraphs.
- [ ] Standalone text: no references to the questionnaire, gap or question ids (G1, Q2, TBC-1), §3A or transcript turns; each decision or open item is stated in plain words.
- [ ] Every image, including the FSD process diagram in §4.1.1, has a white background like the other diagrams (no black or transparent-rendered images).
- [ ] §5.x.4 GoAnywhere is a short description only (no requirements table; MFT-team owned, out of AIS scope) and states that the SMC ID generated by GoAnywhere is carried in the file name and used as `ParentObservationID` for the whole flow.

## Gate Decision

- [ ] PASS — score at least 90%, no unresolved Critical/High finding, mandatory evidence present
- [ ] PASS WITH FINDINGS — only non-blocking findings; each has owner and due point
- [ ] BLOCKED — unresolved Critical/High finding, missing evidence, or score below 90%

**Disposition:** {Approve TSD for codegen-readiness questionnaire only / Return for correction / Accept test-only draft, no codegen}

**Reviewer comments:**

- {critical observation, evidence, impact, and requested change}

**Sign-off:** {name/date}
