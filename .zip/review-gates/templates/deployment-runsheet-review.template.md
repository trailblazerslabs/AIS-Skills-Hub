# Deployment Runsheet Review — {EAII-IDs} — {InterfaceName} — {ENV}

Environment: {SIT / UAT-UT1 / PRD}  
Runsheet page/revision: {Confluence link and version}  
Review date: {date}  
Reviewer: {name}  
Status: **IN REVIEW / BLOCKED / APPROVED FOR THIS ENVIRONMENT ONLY**

> Complete this review independently for each SIT, UAT/UT1, and PRD runsheet before deployment.
> Approval applies only to this environment and runsheet revision. It is not pipeline execution
> approval and does not replace the separate PRD readiness runbook gate.

## Evidence Baseline

| Source | Revision / SHA / run | Location / evidence |
|---|---|---|
| Runsheet | {Confluence page version or export provenance} | {link/path} |
| Approved TSD | {title, revision, approval evidence} | {link/path} |
| Current code comparison baseline | {repository, `origin/main` SHA, refresh date} | {local repo / source paths} |
| Promotion candidate | {branch, artifact SHA/tag, build ID} | {pipeline run and artifact link} |
| Deployment pipeline | {definition/file and run ID} | {stage/approval evidence} |

`origin/main` is a comparison baseline, not proof of the artifact being deployed. In retrospective mode, label the review **RETROSPECTIVE — NOT DEPLOYMENT APPROVAL** and do not infer current Confluence approval or deployment state from an export.
For deployments spanning application, APIOps/API and IaC changes, record one evidence-baseline row and one pipeline/run reference for each independently promoted component. A successful application pipeline does not prove the API or infrastructure was deployed.

## Critical Findings

| # | Severity | Runsheet section / row | Evidence | Risk / impact | Required correction / owner | Blocks deployment? |
|---|---|---|---|---|---|---|
| 1 | Critical / High / Medium / Low | {location} | {evidence} | {impact} | {action / owner} | Yes / No |

## Mandatory Readiness Checklist

Award points proportionally to complete, evidence-backed subchecks within each dimension. State
the basis for partial credit in the evidence/comment column. Missing or unverified subchecks score
zero. N/A requires justification and evidence.

| Check | Points available | Points earned | Evidence / reviewer comment |
|---|---:|---:|---|
| Correct interface/environment/resource mapping and traceability to approved TSD, current code SHA, and exact promotion artifact/build | 15 | {0-15} | {TSD revision; repo/main SHA; artifact/build/pipeline evidence} |
| Pre-checks: access, dependencies, infrastructure, identity, secrets, networking and SMC | 20 | {0-20} | {verified evidence} |
| Pipeline/run plan matches the checked-in deployment YAML; sequence, owners, dependencies, schedule and change record are evidenced | 15 | {0-15} | {pipeline YAML/run and CR references} |
| Code review gate passed; required build/check results recorded; no unresolved blockers | 15 | {0-15} | {review report / build} |
| Unit-test status is explicit; required suite/results are recorded for this promotion | 15 | {0-15} | {CSV / ADO / execution evidence} |
| Post-deployment validation, monitoring, support contacts and communications are actionable | 10 | {0-10} | {checks / owners} |
| Rollback/recovery steps, trigger/ingress controls and data-reconciliation owner are explicit | 10 | {0-10} | {rollback evidence} |
| **Total** | **100** | **{earned}** | |

**Readiness percentage:** `{points awarded}/{applicable points} = {percent}%`  
**Required score:** 100% of applicable mandatory items.

## Gate Decision

- [ ] PASS — 100% mandatory readiness, no unresolved Critical/High finding, required reviewers signed
- [ ] BLOCKED — any mandatory item incomplete, required evidence absent, or Critical/High finding open

**Reviewer comments:**

- {finding, evidence, impact, owner, and blocking decision}

**Approver/sign-off:** {name/date}  
**Scope:** {this environment only; deployment execution separately authorized? Yes/No}
