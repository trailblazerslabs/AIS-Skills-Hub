# Runsheet Model Evaluation — {Case ID}

Case/input bundle revision: {identifier, revision, or hash}  
Prompt revision: {revision/hash}  
Evaluation mode: {BLIND / NON-BLIND; explain any prior exposure to gold examples}  
Candidate label: {A/B/Copilot/...}  
Model and version: {model/version}  
Run ID: {run number}  
Evaluator/date: {name/date}  
Approved TSD revision: {title/version/path}  
Code baseline: {repository, `origin/main` SHA/date}  
Promotion candidate: {branch, artifact/build ID, pipeline run evidence or TBD}  
Reference example(s): {source path(s), revision/date; not candidate inputs}

> This worksheet compares draft quality only. It is not the per-environment deployment review and does not approve publication or execution. A NON-BLIND result is diagnostic, not a model-ranking benchmark.

## Blocking Findings

| ID | Severity | Output location | Evidence/source conflict | Impact | Required correction | Failed run? |
|---|---|---|---|---|---|---|
| {R-01} | {Critical/High/Medium/Low} | {section/row} | {specific evidence} | {impact} | {correction} | {Yes/No} |

## Candidate Score

Award points only for present, accurate, evidence-backed content. An unsupported claim scores zero in the relevant check. Mark N/A only with a reason; calculate the percentage over applicable points.

| Dimension | Points | Score | Evidence/comment |
|---|---:|---:|---|
| Correct interface/environment/resource mapping, traceable TSD revision, current code SHA, and exact promotion artifact/version | 15 | {0-15} | {evidence} |
| Pre-checks: access, dependencies, infrastructure, identity, secrets, networking, and SMC where applicable | 20 | {0-20} | {evidence} |
| Each application/APIOps/IaC pipeline and run sequence matches checked-in YAML; owners, dependencies, schedule, and change record are evidenced | 15 | {0-15} | {evidence} |
| Code-review/build/check evidence and explicit unit-test status | 15 | {0-15} | {evidence} |
| Post-deployment validation, monitoring, support contacts, and communications | 15 | {0-15} | {evidence} |
| Rollback/recovery, trigger/ingress controls, and data-reconciliation ownership | 10 | {0-10} | {evidence} |
| Required sections, usable action tables, status discipline, and traceable source references | 10 | {0-10} | {evidence} |
| **Total** | **100** | **{total}** | |

Score = points awarded / applicable points × 100, rounded to a whole percentage.

## Gate-Relevant Checks

- [ ] No invented resource, endpoint, date, change record, owner, approval, test result, or pipeline outcome.
- [ ] No secret value, credential, access token, private key, or SAS token exposed.
- [ ] New/unexecuted actions start as `TODO`; no planned work is represented as complete.
- [ ] Mandatory evidence gaps and conflicting inputs are visible; blockers are not hidden or guessed away.
- [ ] Rollback/recovery is actionable or its non-applicability is supported by supplied evidence.
- [ ] Readiness is not represented as authorization to publish, execute, or deploy.

Any failed check above caused by a Critical/High issue fails the run regardless of score.

## Disposition

Score: {percent}%  
Blocking finding: {Yes/No}  
Run result: {PASS / FAIL / INCOMPLETE}  
Evaluator comments: {highest-impact findings and evidence}
