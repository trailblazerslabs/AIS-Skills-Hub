# EAII-304 - Liquor Suppliers to EIM - PRD Deployment Runsheet

> Local quality-evaluation draft only. Not published and not authorization to deploy. Target artifact/build, current CR, deployment window, owner roster and actual pipeline results were not supplied; affected actions remain TBD/BLOCKED.

## 1. Overview

| Field | Value | Evidence / owner |
|---|---|---|
| Interface | EAII-304 - IBA Directs ALM Orders / Liquor Suppliers to EIM | Approved TSD `TSD-EAII-304` |
| Environment | PRD | Evaluation case; no PRD deployment authorized |
| Change Request | TBD for a new promotion | Historical main-merge message references CHG0065195; confirm a current CR rather than reusing it |
| Deployment window | TBD | Release Manager |
| Promotion branch / artifact / build ID | BLOCKED - not supplied | Release owner / pipeline run |
| Implementers / reviewers / approvers | TBD | Interface delivery lead |

## Source and Release Baseline

| Source | Baseline | Use in this draft |
|---|---|---|
| TSD | `reference-corpus/converted/tsd/TSD-EAII-304/TSD-EAII-304.md` | Intended file flow, controls, resource inventory and test scenarios |
| Application code | `Metcah.AIS.B2B.IBADirects`, `main`, `20ef9a5369a8ea79223781ff4cc11886619f077e` | Current comparison baseline, not a promotion artifact |
| Application pipeline | `pipelines/gen3ibadirectsladep.yml` | .NET 8 function build/publish, workspace ZIP package, parameterized PRD stage |
| APIOps | `Metcash.AIS.APIOps`, `main`, `26815590f1d15ee94f602595ec8031a65e643d46` | `gen-3/tools/pipelines/run-publisher-prd.yaml`; `b2b-iba-directs-upload-v1` APIM artifact |
| Infrastructure | TSD names `metcash-ais-infrastructure` | Repository/revision not available locally; IaC pipeline and run are TBD |

### TSD-to-Code Differences Requiring Decision

| Item | Evidence | Required action | Status |
|---|---|---|---|
| PRD Logic App resource name differs between TSD §6.5 and the `logicAppName` set in the application pipeline | Approved TSD resource inventory vs `gen3ibadirectsladep.yml` PRD stage | Resource owner must confirm the target name and correct the controlling TSD/configuration before deployment | BLOCKED |
| TSD §6.5 API URL table has inconsistent hyperlink targets across environment rows | TSD export vs APIOps `b2b-iba-directs-upload-v1` specification/PRD parameters | APIOps owner must confirm the authoritative PRD host/path; do not copy the TSD hyperlinks into the deployment action | BLOCKED |

### Independently Deployed Components

| Component | Repository / pipeline | PRD gate | Artifact / run |
|---|---|---|---|
| Logic App + packaged PSV transformer | `Metcah.AIS.B2B.IBADirects`; `pipelines/gen3ibadirectsladep.yml` | .NET 8 Build, `deployPRD=true`, source branch `main`, stage `Prd` | Build ZIP `$(Build.BuildId).zip`; target build/run TBD |
| APIOps API | `Metcash.AIS.APIOps`; `gen-3/tools/pipelines/run-publisher-prd.yaml` | Confirm publisher selection and endpoint/resource decision for `b2b-iba-directs-upload-v1` | APIOps artifact/run TBD |
| Infrastructure/IaC | TSD names `metcash-ais-infrastructure`; local repository/pipeline not available | Confirm IaC is required for this release and identify approved pipeline | BLOCKED - repo revision/run unknown |

## 2. Release Note

Deploy the supplier upload and translation flow from the approved TSD: authenticated upload through APIM, file validation/staging, Service Bus routing, ZIP-to-PSV transformation and downstream delivery. The application pipeline builds the in-workspace `PSVTransformer`; it does not establish a separately approved Function App deployment unless the owner confirms one.

## 3. Review and Approval Matrix

| Name | Role | Review date | Decision / approval date | Evidence |
|---|---|---|---|---|
| TBD | Tech Lead | TBD | TODO | TSD/code-difference decisions |
| TBD | Solution Architect | TBD | TODO | Design approval |
| TBD | Developer reviewer | TBD | TODO | Application and APIOps PR review |
| TBD | PRD change approver | TBD | TODO | Current CR approval |

## 4. Pre-Checks

### 4a. Infrastructure and Security

| IS | Component | Required evidence | Owner | Status |
|---|---|---|---|---|
| IS-1 | APIM | Confirm API, operation, policy, backend, version set and PRD parameters match the approved endpoint | APIOps owner | BLOCKED - endpoint/resource discrepancy unresolved |
| IS-2 | Logic App and inline transformer | Confirm the actual PRD host name and packaged `PSVTransformer` version | App owner | BLOCKED - TSD/pipeline target-name discrepancy |
| IS-3 | Blob, Service Bus, Key Vault and Managed Identity | Verify PRD resources, private access and least-privilege roles; verify secret names only | Platform owner | TODO |
| IS-4 | SMC / Application Insights | Verify registration, telemetry and operational access | Operations owner | TODO |

### 4b. Pre-Check Actions

| No. | Action | Dependency | Owner | Status | Evidence / escalation |
|---:|---|---|---|---|---|
| 1 | Confirm approved TSD revision and resolve the resource-name and APIM endpoint differences above | Owner decisions | Tech Lead | BLOCKED | Update the controlling design and deployment inputs |
| 2 | Confirm current CR, deployment window, promotion branch, artifact/build ID and pipeline run | Change approval | Release owner | BLOCKED | No target promotion evidence supplied |
| 3 | Verify build result for the Function project and workspace package; attach test evidence for the exact artifact | Build/test reports | Test lead | BLOCKED | YAML builds/publishes the function but contains no test execution result |
| 4 | Verify PRD app settings and connections use approved Key Vault references and contain no secret values | Step 1 complete | Security owner | TODO | No secret values in the runsheet |
| 5 | Verify APIOps PRD parameter/artifact revision and publisher run | APIOps approval | APIOps owner | BLOCKED | API artifact exists in main; no run ID provided |

## 5. Implementation

The application pipeline's PRD stage is parameterized, requires a successful Build stage and `main`, builds the .NET 8 function component, packages the Logic App workspace, prepares PRD parameters/connections and app settings, and zip-deploys to the pipeline-selected host. Confirm the host-name discrepancy before triggering.

| No. | Action | Dependency | Owner | Status | Evidence / expected result |
|---:|---|---|---|---|---|
| 1 | Run the approved Build stage; capture source SHA, .NET build/publish logs and immutable ZIP artifact ID | PR and CR approved | Pipeline owner | TODO | Build/run link and artifact hash |
| 2 | Select `deployPRD`; verify source is `main` and PRD variable group/target name are approved | Step 1 and PRD approval | Pipeline owner | BLOCKED | `gen3ibadirectsladep.yml`, `Prd` stage |
| 3 | Apply PRD parameters/connections and deploy the ZIP package | Step 2 approved | App owner | TODO | Record exact target and observed result |
| 4 | Apply PRD app settings; verify secret references without copying secret values | Step 3 complete | App owner | TODO | Configuration validation evidence |
| 5 | Publish the APIOps API changes through the approved PRD process | APIOps approval and confirmed API endpoint | APIOps owner | BLOCKED | Use `gen-3/tools/pipelines/run-publisher-prd.yaml` and `b2b-iba-directs-upload-v1`; pipeline run/approval evidence missing |

## 6. Post-Implementation

| No. | Validation | Owner | Status | Evidence |
|---:|---|---|---|---|
| 1 | Verify APIM authentication/validation and the confirmed PRD backend route | APIOps owner | BLOCKED | Endpoint discrepancy must be resolved first |
| 2 | Verify upload, file routing, transformation, output, archive/error handling and telemetry against TSD test scenarios | Test lead | BLOCKED | Attach actual test results for this artifact |
| 3 | Confirm SMC/Application Insights monitoring, support handoff and stakeholder notice | Operations | TODO | Observed evidence and named contacts |
| 4 | Obtain environment readiness sign-off | Tech Lead / business owner | TODO | Named approval and date |

## 7. Rollback / Recovery

The exact previous application ZIP, APIOps revision, traffic/ingress disable action and file replay/reconciliation procedure are not established by the available source bundle. **BLOCKED** until the release owner documents and approves a tested rollback path for both the application and APIM changes.

| No. | Recovery action | Owner | Status | Evidence |
|---:|---|---|---|---|
| 1 | Identify previous approved application and APIOps artifacts | Release owners | BLOCKED | Artifact/revision references missing |
| 2 | Document and validate APIM disable/revert, app redeploy and safe file replay/reconciliation steps | Tech Lead / operations | BLOCKED | Approved procedure required |

## 8. Contacts and Review Record

Deployment lead, implementers, support and escalation contacts: **TBD**. Complete the PRD-specific checklist for the final Confluence page revision. This local candidate does not approve publication, pipeline execution, or deployment.