### Independently Deployed Components

| Component | Repository / pipeline | PRD gate | Artifact / run |
|---|---|---|---|
| Logic App | `Metcash.AIS.DATA.MetconnectSuppOnboarding`; `pipelines/gen3suppliercontractladep.yml` | `deployPRD=true`, source branch `main`, stage `Prd` | Build ZIP `$(Build.BuildId).zip`; target build/run TBD |
| APIOps API | `Metcash.AIS.APIOps`; `gen-3/tools/pipelines/run-publisher-prd.yaml` | Confirm publisher selection and approvals for `data-mdmsupplier-v1` | APIOps artifact/run TBD |
| Infrastructure/IaC | TSD names `metcash-ais-infrastructure`; local repository/pipeline not available | Confirm IaC is required for this release and identify approved pipeline | BLOCKED - repo revision/run unknown |

# EAII-297 - Metconnect to Supplier MDM - Get/Release Supplier Number - PRD Deployment Runsheet

> Local quality-evaluation draft only. Not published and not authorization to deploy. The runbook source artifact/build, current change record, deployment window, and approver roster were not supplied; affected actions remain blocked or TBD.

## 1. Overview

| Field | Value | Evidence / owner |
|---|---|---|
| Interface | EAII-297 - Metconnect to Supplier MDM - Get/Release Supplier Number | Approved TSD `TSD-EAII-297` |
| Environment | PRD | Evaluation case uses the PRD environment; no deployment is authorized |
| Change Request | TBD for a new promotion | A historical main-merge message references CHG0065195; confirm a new/current CR with Change Manager |
| Deployment window | TBD | Release Manager |
| Promotion branch / artifact / build ID | BLOCKED - not supplied | Release owner / pipeline run |
| Author / implementers / reviewers | TBD | Interface delivery lead |

## Source and Release Baseline

| Source | Baseline | Use in this draft |
|---|---|---|
| TSD | `reference-corpus/converted/tsd/TSD-EAII-297/TSD-EAII-297.md` | Intended process, resources, security, test scenarios, environment migration |
| Application code | `Metcash.AIS.DATA.MetconnectSuppOnboarding`, `main`, `b594b934847a3154a0e52151ba09ddd0921d1766` | Current comparison baseline; not the promotion artifact |
| Application pipeline | `pipelines/gen3suppliercontractladep.yml` | Build ZIP stage and parameterized PRD stage |
| APIOps | `Metcash.AIS.APIOps`, `main`, `26815590f1d15ee94f602595ec8031a65e643d46` | `gen-3/tools/pipelines/run-publisher-prd.yaml`; `data-mdmsupplier-v1` API and `newsupplier` / `releasesupplier` operations |
| Infrastructure | TSD names `metcash-ais-infrastructure` | Local repository and IaC revision unavailable; provisioning sequence is TBD |

The approved TSD's §9.3 gives a generic environment-promotion statement. The application pipeline is the source for the concrete ZIP build and PRD stage. The current `main` SHAs above do not identify the package that a future pipeline run will deploy.

## 2. Release Note

Promote the stateless Supplier Number Management Logic App and its APIM operations for requesting and releasing reserved MDM supplier numbers. Scope and behavior follow TSD §5.1. Do not place MDM credentials or API keys in this page.

## 3. Review and Approval Matrix

| Name | Role | Review date | Decision / approval date | Evidence |
|---|---|---|---|---|
| TBD | Tech Lead | TBD | TODO | Link to approved TSD/code review |
| TBD | Solution Architect | TBD | TODO | Link to design approval |
| TBD | Developer reviewer | TBD | TODO | Link to PR/review |
| TBD | PRD change approver | TBD | TODO | Current CR approval |

## 4. Pre-Checks

### 4a. Infrastructure and Security

| IS | Component | Required evidence | Owner | Status |
|---|---|---|---|---|
| IS-1 | Logic App / App Service Plan | Confirm PRD resource `t3-met-data-suppliercontract-prd-ae-logic` and hosting plan against approved infrastructure revision | Infrastructure owner | TODO |
| IS-2 | Key Vault / Managed Identity | Verify required secret names and Key Vault Secrets User role; never copy secret values | Security / platform owner | TODO |
| IS-3 | APIM | Confirm `data-mdmsupplier-v1` and both operations, backend, policy and PRD parameters are approved | APIOps owner | BLOCKED - PRD publisher run and artifact not supplied |
| IS-4 | Network / telemetry | Verify private connectivity and Application Insights/SMC monitoring required by TSD §6.2-§6.5 and §5.1.8 | Platform owner | TODO |

### 4b. Pre-Check Actions

| No. | Action | Dependency | Owner | Start / end | Status | Evidence / escalation |
|---:|---|---|---|---|---|---|
| 1 | Confirm current approved TSD revision and resolve any TSD/code differences | TSD and refreshed code baseline | Tech Lead | TBD | TODO | TSD §9.3 is generic; record any approved deviation |
| 2 | Confirm current CR, PRD window, promotion branch, immutable artifact/build ID and pipeline run | Release approval | Release owner | TBD | BLOCKED | Required promotion evidence is missing |
| 3 | Confirm `deployPRD` selection and `main` source-branch condition for the application pipeline | CR approved | Pipeline owner | TBD | TODO | `gen3suppliercontractladep.yml`, `Prd` stage |
| 4 | Confirm PRD variable group, app settings and connection/parameter files contain no secret values | Pipeline selection | App owner | TBD | TODO | Review names/configuration only; verify secrets in approved Key Vault |
| 5 | Attach code-review/build/check and TSD §5.1.10.2 test results for this exact artifact | Promotion artifact identified | Test lead | TBD | BLOCKED | Pipeline YAML packages the Logic App; no test result or pipeline run was supplied |
| 6 | Confirm separate APIOps promotion and its artifact/run for `data-mdmsupplier-v1` | APIOps approval | APIOps owner | TBD | BLOCKED | API artifacts are present in main; PRD publisher run evidence is missing |

## 5. Implementation

Execute only after the change, artifact, prerequisite evidence and approvals are complete.

| No. | Action | Dependency | Owner | Status | Evidence / expected result |
|---:|---|---|---|---|---|
| 1 | Run the application pipeline Build stage to package the Logic App workspace as the `drop` ZIP artifact | Approved PR and CR | Pipeline owner | TODO | Record build ID, source SHA and artifact link |
| 2 | Select the PRD deployment parameter; verify the `Prd` stage is running from `main` | Build succeeded; PRD approval | Pipeline owner | BLOCKED | Do not trigger without explicit authorization |
| 3 | Apply the PRD package-preparation inputs (`parameters.prd.json`, `connections.prd.json`) and deploy the ZIP | Step 2 approved | App owner | TODO | Record observed deployment result and target resource |
| 4 | Apply PRD app settings through the pipeline template | Step 3 complete | App owner | TODO | Confirm settings names and Key Vault references; do not record secret values |
| 5 | Promote the approved APIOps API artifact using the PRD publisher process | APIOps approval and target artifact confirmed | APIOps owner | BLOCKED | `gen-3/tools/pipelines/run-publisher-prd.yaml`; definition/run/approval evidence is not supplied |

## 6. Post-Implementation

| No. | Validation | Owner | Status | Evidence |
|---:|---|---|---|---|
| 1 | Verify both supplier-number workflows are enabled and healthy | App owner | TODO | Runtime/configuration check |
| 2 | Execute the approved TSD §5.1.10.2 scenarios for request, release, authentication failures and MDM failures | Test lead | BLOCKED | Attach actual test results; scenarios alone are not execution evidence |
| 3 | Verify correlated Application Insights and SMC observations without payload/secret leakage | Operations | TODO | Observed telemetry and support handoff |
| 4 | Obtain environment readiness sign-off | Tech Lead / business owner | TODO | Named approval and date |

### Communications

| Audience | Message | Owner | Status |
|---|---|---|---|
| Business / operations | Deployment start, outcome, blockers and next testing step | Release lead | TODO |

## 7. Rollback / Recovery

Decision trigger and decision owner: TBD. The exact previous application artifact, APIOps revision, rollback command, and data/reprocessing procedure are not identified by the supplied TSD/code baseline. **BLOCKED** until the Release and APIOps owners document and approve those steps. Do not treat “fresh deployment” as proof that all dependent API changes need no rollback.

| No. | Recovery action | Owner | Status | Evidence |
|---:|---|---|---|---|
| 1 | Identify and retain the previous approved Logic App artifact and APIOps revision | Release / APIOps owners | BLOCKED | Previous artifact/revision not supplied |
| 2 | Document and test the approved revert/disable sequence and verify data/request recovery | Tech Lead | BLOCKED | Owner decision and recovery evidence required |

## 8. Contacts and Review Record

Deployment lead, implementers, on-call support and escalation contacts: **TBD**. Complete the per-environment review checklist for the final Confluence page revision before any deployment. This draft is not an approval to publish, trigger a pipeline, or deploy.