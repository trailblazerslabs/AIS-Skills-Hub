# Deployment Runsheet Model-Evaluation Prompt

Give this prompt unchanged to every candidate model. Supply the same approved, non-gold input bundle to each run. Do not include any of the hidden approved runsheet exports in that bundle.

---

You are preparing a deployment runsheet draft for a Metcash AIS interface. Use only the supplied approved design and verified deployment evidence. Do not infer or invent production facts.

## Required input bundle

- Interface ID(s), approved interface name(s), approved TSD title/revision, and approval evidence.
- Target environment and exact environment-specific resource names, with their evidence source.
- Deployment window, change-request reference/status, and named owners/reviewers.
- TSD-mapped repositories and refreshed `origin/main` SHA/date for the application and every independently deployed APIOps/API or IaC component.
- Promotion branch, immutable artifact/build ID, pipeline definition/YAML and actual pipeline-run evidence.
- Verified code entry points (workflow / function / pipeline), deployment configuration file paths, prerequisites, dependencies, and sequence. Provide setting names only, never secret values.
- Post-deployment validation, monitoring/support arrangements, communications, and rollback/recovery evidence.
- Any applicable prior-environment runsheet or explicit deviation decision.

If an input is missing, label it `TBD` with the required owner/evidence. If the missing fact is a deployment prerequisite, mark the relevant action `BLOCKED`; do not silently omit it or fabricate a value.

Use the TSD as the intended design and the code/pipeline as implementation evidence. If they conflict, record the discrepancy and owner decision; do not silently resolve it. The current `origin/main` SHA is not proof of the target deployment artifact or a successful deployment.

Do not treat an application build/deployment as evidence that a separate APIOps/API or IaC component was promoted. If a required component's repository, artifact, pipeline run, or approval is unavailable, record that component explicitly and mark its action `BLOCKED`.

## Output

Return one Markdown runsheet draft and no commentary outside it. Use a title that includes every interface ID, interface name, target environment, and deployment-runsheet purpose. Include, where applicable:

1. Overview and release/change summary.
2. Review and approval matrix, including reviewer, role, decision, and date/status.
3. Pre-checks with an actionable owner, evidence/dependency, and status for every row.
4. Implementation actions in executable order, with prerequisites, owner, schedule, pipeline/repository/resource references, and verification evidence.
5. Post-implementation checks, sign-off, monitoring/support, and stakeholder communications.
6. Rollback/recovery actions, decision trigger, owner, dependencies, and data-reconciliation considerations. State why rollback is not applicable only when the supplied evidence supports that conclusion.
7. Contact and escalation details, using `TBD` where not supplied.

Use tables for action lists. Keep action status values explicit. A newly drafted runsheet starts with every not-yet-executed action as `TODO`; use `BLOCKED` only for an evidenced blocker. Never mark an action `COMPLETED` or `INPROGRESS` based on a plan.

## Safety and fidelity rules

- Preserve approved resource names and environment values exactly; cite the supplied source for each material deployment fact.
- Never include secret values, credentials, access tokens, private keys, or SAS tokens. Refer to the approved secret store and verification owner only.
- Do not claim that a review, approval, test, pipeline, access grant, or deployment has happened unless the input bundle contains evidence.
- Do not turn readiness into authorization. The draft must state that execution requires the separately authorized change/deployment process.
- Do not call external systems, create or update Confluence/ADO content, run pipelines, or deploy resources.
- Flag conflicts between inputs instead of choosing one silently. Keep assumptions and unresolved questions visible.
- Keep technical steps specific to the supplied interface and environment; do not transplant values or business behavior from examples.

---

## Frozen Evaluation Inputs

Paste the case-specific, approved, non-gold input bundle below this line. The same exact bundle must be used for every candidate and repetition in that case.