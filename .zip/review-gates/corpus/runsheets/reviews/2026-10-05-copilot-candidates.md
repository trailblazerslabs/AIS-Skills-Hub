# Retrospective Runsheet Candidate Review — 2026-10-05

**Mode:** NON-BLIND diagnostic review. The reviewer had already read the three approved runsheet exports and TSDs before generating these candidates. Scores are not a blind model benchmark, active deployment review, or deployment approval.

**Candidate inputs:** Approved TSDs listed in the corpus index; refreshed application `origin/main` snapshots; refreshed APIOps `origin/main` snapshot; checked-in application pipeline YAML. No current change records, release windows, reviewer rosters, target promotion artifacts/build IDs, pipeline run results, IaC repository snapshot, or execution test results were supplied.

## Results

| Case | Candidate | Score | Review disposition |
|---|---|---:|---|
| EAII-297 | [Copilot candidate](../candidates/copilot/EAII-297.md) | 67/100 | INCOMPLETE - evidence gaps block any active gate |
| EAII-304 | [Copilot candidate](../candidates/copilot/EAII-304.md) | 62/100 | BLOCKED - unresolved TSD/code discrepancies and evidence gaps |
| EAII-301 / 302 / 516 / 517 | [Copilot candidate](../candidates/copilot/EAII-301_302_516_517.md) | 68/100 | BLOCKED - TSD/code open items and evidence gaps |

Scores use `review-gates/templates/runsheet-model-eval.template.md`. An explicit `TBD/BLOCKED` earns no readiness points, but is safer than inventing a production fact. A low document-quality score does not mean deployment itself failed; it means the candidate is not a complete, evidence-backed deployment plan.

## EAII-297

| Dimension | Earned / available | Basis |
|---|---:|---|
| Interface/environment/resources and TSD/code/artifact traceability | 10/15 | Correct TSD, application SHA, workflow names, APIOps artifact and app/APIOps pipeline paths; actual promotion artifact/run and IaC evidence missing |
| Pre-checks | 14/20 | Covers identity, Key Vault, APIM, networking and telemetry; access checks and live prerequisite evidence remain TBD |
| Pipeline, owners, dependencies, schedule, CR | 12/15 | Maps separate Logic App and APIOps publisher pipelines and PRD gates; CR/window/owners and actual app/APIOps runs absent |
| Code review, build/check and unit-test evidence | 6/15 | Build/package mechanics identified; no observed build, code-review result or executed unit-test results |
| Post-deployment validation and support | 11/15 | Workflow/APIM health, test scenarios, telemetry and sign-off are actionable; named support roster and actual evidence missing |
| Rollback/recovery | 5/10 | Correctly blocks for unknown previous artifact/API revision and recovery sequence; no tested procedure supplied |
| Structure, statuses and traceability | 9/10 | Required sections, source paths and TODO/BLOCKED discipline present |
| **Total** | **67/100** | |

**High findings:** R297-01 - Current CR, window, promotion branch, immutable artifact/build and actual pipeline run are not supplied; blocks active deployment review. R297-02 - APIOps publication and any IaC action are separate from the Logic App pipeline; their actual runs/approvals are not supplied. R297-03 - No build/check or executed test result exists for the target artifact.

## EAII-304

| Dimension | Earned / available | Basis |
|---|---:|---|
| Interface/environment/resources and TSD/code/artifact traceability | 8/15 | Correct interface, code/APIOps SHAs and pipeline paths; TSD/pipeline Logic App target-name discrepancy remains unresolved and artifact/run absent |
| Pre-checks | 13/20 | Covers APIM, app/transformer, blob, Service Bus, identity and telemetry; target resource decision and live evidence missing |
| Pipeline, owners, dependencies, schedule, CR | 12/15 | Maps separate app and APIOps publisher YAMLs; unresolved target decision, CR/window/owners and actual runs absent |
| Code review, build/check and unit-test evidence | 6/15 | Build steps identified; no observed build, test run or code-review result for the promotion artifact |
| Post-deployment validation and support | 10/15 | Covers APIM, upload/translation/archive/error, SMC and sign-off; observations and contact roster remain TBD |
| Rollback/recovery | 4/10 | Blocks because prior app/APIOps artifacts, ingress control and file replay/reconciliation are not evidenced |
| Structure, statuses and traceability | 9/10 | Complete sections, explicit interface scope and TODO/BLOCKED discipline |
| **Total** | **62/100** | |

**High findings:** R304-01 - TSD §6.5 Logic App resource name conflicts with the PRD target configured by the current pipeline; the owner must resolve and update the controlling artifact before deployment. R304-02 - The TSD's PRD APIM endpoint table contains inconsistent hyperlink targets; APIOps owner must confirm the authoritative host/path. R304-03 - App and APIOps target artifacts/runs, current CR/window, and executed tests are missing. The candidate correctly keeps these unresolved rather than copying a conflicting endpoint.

## EAII-301 / 302 / 516 / 517

| Dimension | Earned / available | Basis |
|---|---:|---|
| Interface/environment/resources and TSD/code/artifact traceability | 10/15 | Maps four IDs to shared repository, services, Function pipeline and APIOps/SMC baseline; artifact and scope decisions remain open |
| Pre-checks | 14/20 | Covers hosting/SKU, Service Bus, Blob retention, target auth, RBAC/network, SMC and per-interface readiness; live evidence missing |
| Pipeline, owners, dependencies, schedule, CR | 12/15 | Maps Function App gate and separates shared APIM/SMC dependency; release metadata and actual run missing |
| Code review, build/check and unit-test evidence | 7/15 | Pipeline build mechanics and absence of `dotnet test` step surfaced; no separate test result or code-review evidence supplied |
| Post-deployment validation and support | 11/15 | Separates validation by interface and includes telemetry/support sign-off; actual results and named contacts missing |
| Rollback/recovery | 5/10 | Explicitly blocks for prior artifact, route controls, replay and reconciliation procedure |
| Structure, statuses and traceability | 9/10 | Combined-interface mapping, source paths, evidence gaps and status discipline present |
| **Total** | **68/100** | |

**High findings:** R301-01 - TSD §9.1 still says the Function repository/pipeline is to be created, while the refreshed code repo and pipeline exist; TSD owner must confirm/update this stale open item. R301-02 - The hosting plan/SKU remains unresolved in the TSD and must be confirmed against approved infrastructure evidence. R301-03 - Target artifact, CR/window, actual pipeline run, code-review result and executed test results are not supplied. The four interface outcomes need independent validation and owner sign-off.

## Comparison With Existing Approved Exports

- All three exports have the expected broad sections: overview, release note, review/approval, pre-checks, implementation, post-implementation, rollback, contacts and communications.
- The historical sheets contain completed/not-started action states, dated rows and named participants. Those are historical facts; the new candidates correctly use TODO/BLOCKED and do not transplant those identities, dates, CRs or completion states.
- The combined example has additional multi-interface deployment/RBAC detail. The generated combined candidate preserves four interface mappings and separates interface validation while retaining a shared Function App pipeline.
- The candidates improve traceability by recording TSD and code revisions and flagging TSD/code conflicts. They do not yet match the historical sheets' populated owners, schedule, change approvals, pipeline run links or completed outcomes because current run-specific evidence was not in the input bundle.
- No candidate is approved for Confluence publication or deployment. The source exports were inspected in this session, so these scores must not be reported as blind model-comparison results.

## Iteration Outcomes

1. Added separate application/APIOps/IaC evidence rows to the generation template, generator skill and reviewer checklist; no one pipeline run may stand in for another.
2. Added the refreshed APIOps `main` SHA and the verified `gen-3/tools/pipelines/run-publisher-prd.yaml` path to the corpus/candidates. The candidates still mark actual APIOps runs as missing.
3. Added independently deployed component maps; pipeline-traceability scores increased by one or two points, while missing CR/artifact/run/test/rollback evidence remains blocking.
4. Added the EAII-304 Logic App resource-name and APIM endpoint discrepancies to the candidate and block disposition instead of silently selecting a value.
5. Kept missing IaC repo/run, CR, schedule, approver, promotion artifact, build/test outcome and rollback details visible as TBD/BLOCKED.

**Execution boundary:** No Azure pipeline was run, no build or test suite was executed, no Confluence/ADO page was written, and no deployment was performed.