# Deployment Runsheet Corpus

This is a provenance and structure index for the user-designated approved PRD runsheet examples. It is a prompt-evaluation corpus, not fine-tuning data. The original Confluence exports remain in `Doc/Temp/Runsheets`; their full production details are intentionally not duplicated into this directory.

## Source Inventory

| Example | Local source | Shape observed | Notes |
|---|---|---|---|
| EAII-297 | `Doc/Temp/Runsheets/EAII-297+-+Metconnect+to+Supplier+MDM+-+Get_Clear+Supplier+Number+-+Prod+Deployment+Runsheet.doc` | Single-interface PRD | Overview, release note, review/approval matrix, pre-checks, implementation, post-implementation, rollback, contacts, communications |
| EAII-304 | `Doc/Temp/Runsheets/EAII-304+-+Liquor+Suppliers+to+EIM+-+Prod+Deployment+Runsheet.doc` | Single-interface PRD | Same broad section pattern; action detail and Confluence formatting differ from EAII-297 |
| EAII-301 / 302 / 516 / 517 | `Doc/Temp/Runsheets/📋PRD-Deployment+Runsheet-EAII-301,+EAII-302,+EAII-516,+EAII-517.doc` | Combined-interface PRD | Adds interface-specific deployment steps and RBAC verification; section hierarchy differs from the two single-interface examples |

All three `.doc` files are Confluence `multipart/related` MHTML exports, not binary Word documents. The repository converter is `reference-corpus/_tools/mhtml_to_md.py`. For inspection, convert them to a temporary directory; do not overwrite or normalize the originals. The exports observed for this inventory were dated 5 October 2026. The user identified these pages as approved references; the export files alone do not establish the Confluence approval state or page revision.

## Paired TSD and Code References

The following approved TSDs and refreshed local `origin/main` snapshots were cross-checked on 5 October 2026. The SHA is a code comparison baseline only; no build or pipeline run was executed for this review.

| Interfaces | Approved TSD | Application repository / `origin/main` SHA | Application pipeline / entry point | APIOps baseline (when applicable) |
|---|---|---|---|---|
| EAII-297 | `reference-corpus/converted/tsd/TSD-EAII-297/TSD-EAII-297.md` | `Metcash.AIS.DATA.MetconnectSuppOnboarding` / `b594b934847a3154a0e52151ba09ddd0921d1766` | `pipelines/gen3suppliercontractladep.yml`; `GetNewSupplierNumber` and `ReleaseReservedSupplierNumber` Logic App workflows | `Metcash.AIS.APIOps` / `26815590f1d15ee94f602595ec8031a65e643d46`; `data-mdmsupplier-v1`; `gen-3/tools/pipelines/run-publisher-prd.yaml` |
| EAII-304 | `reference-corpus/converted/tsd/TSD-EAII-304/TSD-EAII-304.md` | `Metcah.AIS.B2B.IBADirects` / `20ef9a5369a8ea79223781ff4cc11886619f077e` | `pipelines/gen3ibadirectsladep.yml`; `LiquorSuppliersToEIM` workflow and `PSVTransformer` function | `Metcash.AIS.APIOps` / `26815590f1d15ee94f602595ec8031a65e643d46`; `b2b-iba-directs-upload-v1`; `gen-3/tools/pipelines/run-publisher-prd.yaml` |
| EAII-301 / 302 / 516 / 517 | `reference-corpus/converted/tsd/TSD-EAII-301_302_516_517/TSD-EAII-301_302_516_517.md` | `Metcash.AIS.Data.MDMSupplierInfo` / `ad805a42382cd0d6c823ea67de4b01e7e6523949` | `pipelines/g3datamdmfnapp.yml`; MDMSupplierInfo Function App and shared services | TSD references APIM for SMC; confirm whether an `smc-v1` APIOps promotion is in scope before adding a publisher action |

The combined-interface TSD still says in §9.1 that the MDMSupplierInfo repository is to be created. The current main repository and pipeline now exist. Treat that as a TSD-to-code discrepancy that requires an owner decision when preparing a new runsheet; do not repeat the stale open item as the deployment plan.

## What the Corpus Supports

- Common PRD section and table patterns, including review and approval, pre-checks, implementation, post-implementation, rollback, contacts, and communications.
- Variation between a single-interface sheet and a combined-interface sheet.
- Historical examples of action sequencing, ownership, dependencies, status use, and operational detail.

The examples contain production names, people, dates, change records, endpoints, resource identifiers, and secret names. Keep them as hidden local references. Never put their contents in the candidate-generation prompt, and never copy their environment-specific values into a new runsheet. All observed exports are PRD, so they do not establish SIT or UAT/UT1-specific coverage.

## Benchmark Limitation

The approved TSDs and refreshed `origin/main` code snapshots are now paired in this corpus. The exports still lack complete generation inputs for a fresh deployment run (for example, the target promotion artifact/build/run, current change record, schedule, and reviewer roster). This session has also already inspected the source runsheets, so any Copilot comparison produced here is explicitly non-blind and diagnostic only. Do not publish a blind model ranking or claim deployment readiness from this exercise. For a future blind benchmark, freeze the missing inputs and run candidates in fresh sessions that do not contain the gold exports.

Do not call this fine-tuning. This is a prompt/model evaluation process. The 2026-10-05 Copilot candidate review is explicitly non-blind because the evaluator had already inspected the gold exports; it is diagnostic evidence only, not a model ranking or deployment approval. A future blind benchmark still needs frozen target promotion evidence, current change/schedule/owner inputs, repeated runs per model, and fresh candidate sessions without gold exposure.

## Evaluation Procedure

1. Prepare at least two approved input bundles that represent different runsheet shapes; include non-PRD examples before claiming environment coverage beyond PRD.
2. Freeze the prompt, inputs, and applicable scoring rules. Do not show candidates the gold export for their case.
3. Run each candidate model at least three times per case, using the same model version/settings where available. Record model/version, prompt revision, input-bundle revision, and run ID.
4. Blind-label candidate outputs before scoring. Score every run against the same 100-point worksheet; report findings and score variance, not just an average.
5. Treat any invented production value, false completion/approval claim, exposed secret value, missing viable rollback, or other Critical/High blocker as a failed run regardless of percentage. A score never approves a deployment runsheet.
6. Consider models tied when mean scores differ by fewer than five points. Resolve ties using consistency, latency/cost, and human preference. Model selection requires explicit user approval.

The normal per-environment deployment-runsheet review remains a separate gate: 100% of applicable mandatory checks, required evidence and signatures, and no unresolved Critical/High findings. Passing this benchmark does not authorize publication, pipeline execution, or deployment.

## Latest Candidate Review

The non-blind Copilot comparison, per-case scores, findings, source revisions, and execution boundary are recorded in [`reviews/2026-10-05-copilot-candidates.md`](reviews/2026-10-05-copilot-candidates.md). Candidate drafts are under `candidates/copilot/`. Treat them as local evaluation artifacts only; none is approved for Confluence publication or deployment.
