# AIS Review Gates and Evidence Corpus

This folder defines the human review gates that sit between generated lifecycle artifacts. It is a curated index into checked-in approved evidence, not model fine-tuning and not a copied duplicate of the source documents. Reviewers must cite the source/version used and fetch external Confluence evidence for the interface/environment under review.

## Gate Sequence

1. **TSD review** — after TSD generation and machine quality checks, before codegen readiness. The reviewer records findings, score, and explicit disposition in `outputs/<EAII-ID>/tsd-review-checklist.md`.
2. **Code review** — after code generation and build/tests, before merge/release consideration. The report includes static checker results, build result, unit-test status, findings, and score in `outputs/<EAII-ID>/code-review-report.md`.
3. **Environment deployment-runsheet review** — required independently before each SIT, UAT/UT1, and PRD deployment. Record environment-specific readiness and reviewer sign-off in `outputs/<EAII-ID>/deployment-runsheet-review-<ENV>.md`.
4. **PRD readiness runbook review** — required before PRD deployment or before labeling an interface “Ready for PRD”. Record readiness in `outputs/<EAII-ID>/prd-deployment-readiness-runbook.md`. Readiness is not authorization to deploy; PRD deployment requires separate explicit approval.

Unit-test CSV generation and ADO case creation retain their two separate questionnaire gates. Code review reports unit-test/build status; they do not substitute for test execution or results recording.

## Score and Disposition Rules

- Each gate template defines a 100-point weighted checklist. Score = earned applicable points / applicable points × 100, rounded to a whole percentage.
- Mark an item N/A only with a reason and evidence. Unverified/missing evidence earns zero; do not mark it N/A merely because it was not checked.
- A percentage is a review aid, not a substitute for findings or a reviewer decision. Report findings first, with severity and evidence.
- Any Critical/High finding, failed mandatory automated gate, failed build, required unit tests not passing, or incomplete mandatory deployment prerequisite blocks PASS regardless of score.
- TSD and code-review target: at least 90%, with no unresolved Critical/High findings. Medium findings remain release blockers unless the accountable owner explicitly accepts them and records that disposition.
- Deployment-runsheet and PRD-readiness gates: 100% of applicable mandatory checks, all required approvals recorded, no unresolved Critical/High findings. No percentage can authorize deployment.
- Preserve the tool-native TSD `quality_review.py` score separately from the human TSD review score. Do not average them: they measure different things.

## Curated Evidence Corpus

Use these in priority order and record exact path, revision/date, and applicability in each review report.

| Evidence | Location | Use |
|---|---|---|
| Approved TSD exemplars | `reference-corpus/converted/tsd/` | Structure, requirements traceability, architecture, operations, assumptions, diagrams |
| TSD canonical structure and known defects | `.github/skills/metcash-tsd-generator/references/01-canonical-structure.md`, `10-known-defects-in-approved-tsds.md` | Mandatory sections and defects to avoid |
| TSD post-generation review checklist | `.github/skills/metcash-tsd-generator/references/11-post-generation-checklist.md` | Automated/content/code-reconciliation evidence before TSD review |
| TSD scoring rules | `.github/skills/metcash-tsd-generator/tools/tsd_lint/quality_review.py`, `kb-checklist.json` | Reproducible mechanical/KB scoring; keep separate from human review |
| Production code snapshot | `code-corpus/production-snapshot.md` | Current `origin/main` repo/SHA, live vs non-live distinction, calibrated checker references |
| Production Logic App patterns | `code-corpus/patterns/02-logic-app-pattern.md` and `.github/skills/ais-logicapp-codegen/tools/check_logicapp.py` | Workflow structure, SMC, parameters, settings, connection conventions |
| Production comparison utility | `.github/skills/ais-logicapp-codegen/tools/compare_logicapp.py` | Action/connector/configuration comparison; diagnostic, not a single quality score |
| Reviewed code example with build/test status | `outputs/EAII-533/code-review-report.md` | Real findings, severity, `dotnet build`, and unit-test evidence; example only, not universal architecture truth |
| Test-case and ADO-readiness example | `outputs/EAII-533/unit-test-cases.csv`, `outputs/EAII-533/unit-test-readiness-questionnaire.md` | Scenario traceability and separate CSV/ADO approval artifacts |
| Deployment-runsheet examples | `.github/skills/ais-deployment-runsheet/SKILL.md` references to approved UT1/SIT/PRD Confluence examples | Retrieve the relevant MAP page through Atlassian MCP at review time; do not treat an un-fetched link as reviewed evidence |
| User-designated approved PRD runsheet corpus | `review-gates/corpus/runsheets/README.md`; source exports in `Doc/Temp/Runsheets/` | Hidden local references paired with approved TSDs/current code; target release inputs are incomplete, so this session's comparison is non-blind and diagnostic only |
| Runsheet model-evaluation prompt and worksheet | `review-gates/corpus/runsheets/model-eval/PROMPT.md`, `review-gates/templates/runsheet-model-eval.template.md` | Fixed prompt and blind scoring process; benchmark score is separate from deployment approval |
| Non-blind Copilot candidate review | `review-gates/corpus/runsheets/reviews/2026-10-05-copilot-candidates.md` | Scores candidate drafts against the approved examples; records findings and explicit no-deployment boundary |
| Interface-specific evidence | `tsd/<EAII-ID>/`, `outputs/<EAII-ID>/`, resolved target repo branch, ADO pipeline/test results, relevant Confluence pages | The controlling design, implementation, test and deployment evidence for the current gate |

Do not copy an exemplar's environment values, business rules, endpoints, secrets, or names into another interface. Use exemplars for structure and patterns; the current approved TSD and verified interface evidence control business behavior.

## Review Comment Standard

Every non-passing comment includes: severity, checklist dimension, exact file/section/action, evidence, impact, required correction or owner decision, and whether it blocks this gate. Distinguish defects from TBCs, intentional design deviations, and unavailable evidence. Never report a test/build/deployment as passed unless a real result was observed.

## Comment Resolution and Re-review

1. List Critical/High findings first, then Medium/Low and informational observations. Every finding has a stable ID and blocking disposition.
2. The owner records the correction commit/revision or documented owner decision beside each finding; do not silently delete or rewrite a finding.
3. Re-run the affected automated checks and regression tests. The reviewer marks each finding Resolved, Accepted with named approver/rationale, or Open, with evidence.
4. Recalculate the percentage from the final checklist. Any open Critical/High finding or hard-gate failure remains BLOCKED even if the score is 100%.
5. Record final reviewer/approver, date, artifact SHA/revision, percentage, verdict, and next authorized phase in the per-interface `outputs/<EAII-ID>/status.md`.
